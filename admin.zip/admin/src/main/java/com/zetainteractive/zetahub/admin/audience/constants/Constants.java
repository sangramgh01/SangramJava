/**
 * Constants.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.constants;

import java.util.Arrays;
import java.util.List;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jun 27, 2016 6:48:33 PM
 * @Version	     : 1.7 
 * @Description  : "Constants" is used to maintain Audience module related Constants
 * 
 **/

public class  Constants {
	
	//Data source & profile column sync status
	public static final char COMPLETED = 'C';
	public static final char PROGRESS = 'P';
	public static final char ERRORED = 'E';
	public static final char FIRST_TIME_SYNC_ERRORED = 'F';
	public static final char YES = 'Y';
	public static final char NO = 'N';
	public static final int BASE_TABLE = 0;
	public static final int DIMENTION_TABLE = 1;
	public static final String EXCEPTION = "Exception occuured";
	

	public static final int STRING = 0;
	public static final int BIGINT = 1;
	public static final int FLOAT = 2;
	public static final int DATETIME = 3;
	public static final int BOOLEAN = 4;
	public static final int INT = 5;
	public static final int BYTEINT = 6;
	public static final int EMAIL = 7;
	public static final int SMS = 8;
	public static final int TIMESTAMP = 9;
	public static final int DATE = 10;
	public static final int TIME = 11;
	public static final int DECIMAL = 12;
	public static final int DOUBLE = 13;	
	
	public static final String SYNC_DATA_SOURCE = "syncDataSource";
	
	public static String PHYSICAL_COLUMN_NAME = "PhysicalColumnName";
	public static String PHYSICAL_TABLE_NAME = "PhysicalTableName";
	public static String PHYSICAL_TABLE_ID = "PhysicalTableId";
	public static String COLUMN_DATA_TYPE = "ColumnDataType";
	public static String AUDIENCE_MEMBER_ID = "AUDIENCE_MEMBER_ID";
	
	public static String ADMIN = "ADMIN";

	
	public static String getDataType(int datatype) {
        String dataTypeStr = null;
        switch(datatype) {
	        case STRING:
	              dataTypeStr = "String";
	              break;
	        case BIGINT:
	              dataTypeStr = "Big Integer";
	              break;
	        case FLOAT:
	            dataTypeStr = "Float";
	            break;
	        case DATETIME:
	            dataTypeStr = "DateTime";
	            break;
	        case DATE:
	            dataTypeStr = "Date";
	            break;
	        case TIME:
	            dataTypeStr = "Time";
	            break;    
	        case BOOLEAN:
	            dataTypeStr = "Boolean";
	            break;
	        case BYTEINT:
	            dataTypeStr = "Byte Integer";
	            break;
	        case INT:
	            dataTypeStr = "Integer";
	            break;
	        case TIMESTAMP:
	        	dataTypeStr = "TimeStamp";
	            break;
	        case DECIMAL:
	        	dataTypeStr = "Decimal";
	            break;
	        case DOUBLE:
	        	dataTypeStr = "Double";
	            break; 
	        default:
	    }
        
        return dataTypeStr;
	}
	
	/*
	 * Vertica server supports data type aliases for integer, float and numeric types. However, it processes and reports them as its basic types (INT8, FLOAT8, and NUMERIC).
	 * Please refer to https://my.vertica.com/docs/5.0/HTML/Master/1229.htm, https://my.vertica.com/docs/4.1/HTML/Master/13172.htm, https://my.vertica.com/docs/5.0/HTML/Master/2587.htm
	 * Getting 'DATA_TYPE' gives data type name along with size leaving us with incorrect results, for better results we will be processing 'DATA_TYPE_ID'.
	 * This code is an extract from method 'getTypeName' in class 'com.vertica.util.TypeUtils'.
	 * Binary data types & Interval data type being ignored and returned as String type.
	 */		
	public static int getDataTypeForVerticadb(int datatype) {		
		switch (datatype) {
			case 5:/*Boolean*/
				return BOOLEAN;
			case 6:/*Integer*/
				return BIGINT;
			case 7:/*Double*/
				return DOUBLE;
			case 8:/*Char*/
				return STRING;
			case 4:
			case 9:/*Varchar*/
				return STRING;
			case 115:/*Long Varchar*/
				return STRING;
			case 10:/*Date*/
				return DATE;
			case 11:/*Time*/
				return TIME;
			case 15:/*TimeTz*/
				return STRING;
			case 12:/*Timestamp*/
				return TIMESTAMP;
			case 13:/*TimestampTz*/
				return STRING;
			case 14:
			case 114:/*Interval*/
				return STRING;				
			case 117:/*Binary*/
				return STRING;
			case 17:/*Varbinary*/
				return STRING;
			case 116:/*Long Varbinary*/
				return STRING;
			case 16:/*Numeric*/
				return DECIMAL;
		}
		return STRING;
	}
	
	public static int getAudienceType(String audienceType) {
		int audiceTypeId = 0;
		switch (audienceType) {
		case "System":
			audiceTypeId = 0;
			break;
		case "Custom":
			audiceTypeId = 1;
			break;

		default:
		}

		return audiceTypeId;
	}
	
	public static List<String> AUDIENCE_COLUMNS = Arrays.asList("audiencename", "departmentid", "audiencetype", "createdby", "updatedby", "createdate", "updatedate");
	
}

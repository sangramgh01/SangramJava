/**
 * AudienceColumnTypeController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceColumnTypeService;
import com.zetainteractive.zetahub.admin.audience.validator.ColumnTypeValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @Author : dilleswara.doppa
 * @Created On : Jul 1, 2016 2:28:50 PM
 * @Version : 1.7
 * @Description : "AudienceColumnTypeController" is used for Column Type data model
 * 
 **/
@RestController
@RequestMapping(value = "/audienceColumnType")
public class AudienceColumnTypeController {
	/** The logger. */
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	private AudienceColumnTypeService audienceColumnTypeService;
	@Autowired
	private ColumnTypeValidator columnTypeValidator;
	
	@Autowired
	MessageSource messageSource;

	/**
	 * Save column type model.
	 *
	 * @param columnTypeModelBO the column type model bo
	 * @return the long
	 * @throws AudienceException the audience exception
	 */
	@RequestMapping("/saveColumnType")
	@HystrixCommand
	public ResponseEntity<?> saveColumnTypeModel(@RequestBody ColumnTypeModelBO columnTypeModelBO,BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: saveColumnTypeModel()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		columnTypeValidator.validate(columnTypeModelBO, bindingResult);
		if(bindingResult.hasErrors()){
			resp.addErrors(bindingResult, "Invalid Data");
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Long>(audienceColumnTypeService.saveColumnTypeModel(columnTypeModelBO),  HttpStatus.OK);
	}

	/**
	 * Update column type model.
	 *
	 * @param columnTypeModelBO the column type model bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping("/updateColumnType")
	public ResponseEntity<?> updateColumnTypeModel(@RequestBody ColumnTypeModelBO columnTypeModelBO,BindingResult bindingResult
			,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: updateColumnTypeModel()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		columnTypeValidator.validate(columnTypeModelBO, bindingResult);
		if(bindingResult.hasErrors()){
			resp.addErrors(bindingResult, "Invalid Data");
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Boolean>(audienceColumnTypeService.updateColumnTypeModel(columnTypeModelBO),  HttpStatus.OK);
	}

	/**
	 * Delete column type model.
	 *
	 * @param columntypeid the columntypeid
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteColumnType/{columnTypeId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteColumnTypeModel(@PathVariable Long columnTypeId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: deleteColumnTypeModel()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		return new ResponseEntity<Boolean>(audienceColumnTypeService.deleteColumnTypeModel(columnTypeId), HttpStatus.OK);
	}

	/*
	 * Find all column type model.
	 *
	 * @return the list
	 * 
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findAllColumnTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAllColumnTypeModel(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findAllColumnTypeModel()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		return new ResponseEntity<List<ColumnTypeModelBO>>(audienceColumnTypeService.findAllColumnTypeModel(),
				HttpStatus.OK);
	}

	/**
	 * Find column type model by id.
	 *
	 * @param columntypeid
	 *            the columntypeid
	 * @return the column type model bo
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findColumnTypeById/{columntypeid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findColumnTypeModelById(@PathVariable Long columntypeid,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findColumnTypeModelById()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		return new ResponseEntity<ColumnTypeModelBO>(audienceColumnTypeService.findColumnTypeModelById(columntypeid),
				HttpStatus.OK);
	}

}

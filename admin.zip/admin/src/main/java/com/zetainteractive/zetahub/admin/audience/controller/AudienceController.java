/**
 * AudienceController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.AudienceKeyColumnsBO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.commons.enums.SourceTypes;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.file.service.FileService;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;
import com.zetainteractive.zetahub.securityclient.authorize.Authorizer;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 1, 2016 6:32:20 PM
 * @Version : 1.7
 * @Description : "AudienceController" is used for Audience related REST methods
 *              implementation
 * 
 **/
@RestController
@RequestMapping("/audience")
public class AudienceController {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	private AudienceService audienceService;
	@Autowired
	private FileService fileService;
	@Autowired
	MessageSource messageSource;

	/**
	 * Save audience metadata.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveAudience", method = RequestMethod.POST)
	public ResponseEntity<?> saveAudience(@RequestBody AudienceBO audienceBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {ZetaUtil.getHelper().setLoggingContextKey(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceBO.getAudienceId()==null?0:audienceBO.getAudienceId());}},"{", "}"));} catch (Exception e) {}
		logger.info("Start  :saveAudience()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Long audienceId = null;
		try {
			audienceId = audienceService.saveAudience(audienceBO,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			audienceBO.setAudienceId(audienceId);
		} catch (AudienceException ex) {
			logger.error("Error occurred while saving audience details", ex);
			resp.addError("Error occurred while saving audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.info("End  : saveAudience()");
		return new ResponseEntity<AudienceBO>(audienceBO, HttpStatus.OK);
	}

	/**
	 * Save audience.
	 *
	 * @param audienceBO
	 *            the audience bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/updateAudience", method = RequestMethod.POST)
	public ResponseEntity<?> updateAudience(@RequestBody AudienceBO audienceBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {ZetaUtil.getHelper().setLoggingContextKey(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceBO.getAudienceId());}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : updateAudience()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean updatedStatus = false;
		try {
			updatedStatus = audienceService.updateAudience(audienceBO,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<Boolean>(updatedStatus, HttpStatus.OK);
		} catch (AudienceException ex) {
			logger.error("Error occurred while updating audience details", ex);
			resp.addError("Error occurred while updating audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * delete audience.
	 *
	 * @param audienceBO
	 *            the audience bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteAudience/{audienceId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteAudience(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : deleteAudience()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean deleteStatus = false;
		try {
			deleteStatus = audienceService.deleteAudience(audienceId);
			return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleteing audience details", ex);
			resp.addError("Error occurred while deleteing audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * Delete multiple audiences.
	 *
	 * @param audienceIds the audience ids
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteMultipleAudiences/{audienceIds}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteMultipleAudiences(@PathVariable String audienceIds,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceIds);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : deleteMultipleAudiences()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean deleteStatus = false;
		try {
			if(audienceIds == null) {
				throw new AudienceException("AU0048"); 
			}
			List<Long> selectedAudienceIdList = Stream.of(audienceIds.split(","))
			        .map(Long::parseLong)
			        .collect(Collectors.toList());
			for (Long audienceId : selectedAudienceIdList) {
				 audienceService.deleteAudience(audienceId);
			}
			deleteStatus = true;
			return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleteing audience details", ex);
			resp.addError("Error occurred while deleteing audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceIds},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Find all audiences.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(value = "/listAudience/{departmentId}", method = RequestMethod.GET)
	public ResponseEntity<?> listAudience(@PathVariable Long departmentId, @RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAllAudiences()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			if(departmentId != null && departmentId <=0)
				throw new AudienceException("AU0081");
			MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
            headersMap.add("X-XSS-Protection", "1; mode=block");
            return new ResponseEntity<List<AudienceBO>>(audienceService.listAudience(departmentId),headersMap, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find all audiences.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(value = "/listAudience", method = RequestMethod.GET)
	public ResponseEntity<?> listAudience( @RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAllAudiences()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			
			MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
            headersMap.add("X-XSS-Protection", "1; mode=block");
            return new ResponseEntity<List<AudienceBO>>(audienceService.listAudience(),headersMap, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}


	/**
	 * Find audience metadata.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(value = "/findAudienceById/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAudienceById(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAudienceById()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<AudienceBO>(audienceService.findAudienceById(audienceId), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Find audience metadata by name.
	 *
	 * @param physicalTableName
	 *            the physical table name
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findAudienceByName/{audienceName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAudienceByName(@PathVariable String audienceName,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAudienceByName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<AudienceBO>(audienceService.findAudienceByName(audienceName), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details by name", ex);
			resp.addError("Error occurred while fetching audience details by name",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Checks if is audience exist.
	 *
	 * @param audienceName
	 *            the audience name
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isAudienceExist/{audienceName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isAudienceExist(@PathVariable String audienceName,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAudienceByName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<Boolean>(audienceService.isAudiencesNameExists(audienceName), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is audience exist.
	 *
	 * @param audienceName
	 *            the audience name
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isAudienceExistWithNameAndID/{audienceName}/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isAudienceExistWithNameAndID(@PathVariable String audienceName, @PathVariable Long audienceId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : isAudienceExistWithNameAndID()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			logger.debug("Audience Id ------------->"+audienceId);
			logger.debug("Audience Name ------------->"+audienceName);
			return new ResponseEntity<Boolean>(audienceService.isAudiencesNameExistsByNameAndId(audienceName, audienceId), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalColumnsByAudienceId/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsByAudienceIdAndPhyTableId(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsByAudienceIdAndPhyTableId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			resultLogicalColumnBOList = audienceService.getLogicalColumnsByAudienceId(audienceId);
			return new ResponseEntity<List<LogicalColumnBO>>(resultLogicalColumnBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @param physicalTableId the physical table id
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(path = "/getLogicalColumnsByAudienceIdAndPhyTableId/{audienceId}/{physicalTableId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsByAudienceIdAndPhyTableId(@PathVariable Long audienceId, @PathVariable Long physicalTableId,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsByAudienceIdAndPhyTableId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			resultLogicalColumnBOList = audienceService.getLogicalColumnsByAudienceIdAndPhyTableId(audienceId, physicalTableId);
			return new ResponseEntity<List<LogicalColumnBO>>(resultLogicalColumnBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId,physicalTableId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @param physicalTableId the physical table id
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(path = "/getLogicalColumnsByAudienceIdAndPhyTableName/{audienceId}/{physicalTableName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsByAudienceIdAndPhyTableName(@PathVariable Long audienceId, @PathVariable String physicalTableName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsByAudienceIdAndPhyTableId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			resultLogicalColumnBOList = audienceService.getLogicalColumnsByAudienceIdAndPhyTableName(audienceId, physicalTableName);
			return new ResponseEntity<List<LogicalColumnBO>>(resultLogicalColumnBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId,physicalTableName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @param logicalTableName the logical table name
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalColumnsByAudienceIdAndTableName/{audienceId}/{physicalTableId}/{logicalTableName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsByAudienceIdAndPhyTableId(@PathVariable Long audienceId, @PathVariable String logicalTableName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsByAudienceIdAndPhyTableId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			resultLogicalColumnBOList = audienceService.getLogicalColumnsByAudienceIdAndLogicalTableName(audienceId, logicalTableName);
			return new ResponseEntity<List<LogicalColumnBO>>(resultLogicalColumnBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId,logicalTableName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical table by audience id and logical table name.
	 *
	 * @param audienceId the audience id
	 * @param logicalTableName the logical table name
	 * @return the logical table by audience id and logical table name
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalTableByAudIdAndLTableName/{audienceId}/{logicalTableName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalTableByAudienceIdAndLogicalTableName(@PathVariable Long audienceId, @PathVariable String logicalTableName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsByAudienceIdAndPhyTableId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		LogicalTableBO logicalTableBO = null;
		try {
			logicalTableBO = audienceService.getLogicalTableByAudienceIdAndLogicalTableName(audienceId, logicalTableName);
			return new ResponseEntity<LogicalTableBO>(logicalTableBO, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId,logicalTableName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical columns base by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the logical columns base by audience id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalColumnsBaseByAudienceId/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsBaseByAudienceId(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsBaseByAudienceId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			resultLogicalColumnBOList = audienceService.getBaseLogicalColumnsByAudienceId(audienceId);
			return new ResponseEntity<List<LogicalColumnBO>>(resultLogicalColumnBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the logical columns base by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the logical columns base by audience id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/fetchingAndCheckingLogicalColumnsUsage/{audienceIds}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> verifyAudienceUsage(@PathVariable String audienceIds, @RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {
			logger.setContextString(
					new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String, Object>(3) {
						{
							put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());
							put("UID", ZetaUtil.getHelper().getUser().getUserID());
							put("AUDIENCEID", audienceIds);
						}
					}, "{", "}"));
		} catch (Exception e) {
		}
		logger.info("Start : verifyAudienceUsage()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007",
							new Object[] {
									com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE },
							LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Map<String, Boolean> checkAudienceDetailsMap = new HashMap<>();
		try {
			logger.debug("audienceId======================>" + audienceIds);
			if (audienceIds == null) {
				throw new AudienceException("E00002");
			} else {
				List<Long> audienceIdList = Stream.of(audienceIds.split(",")).map(Long::parseLong)
						.collect(Collectors.toList());
				for (Long audienceId : audienceIdList) {
					checkAudienceDetailsMap = audienceService.checkAudienceAssocation(audienceId);
				}
			}
			logger.info("End : verifyAudienceUsage()");
			return new ResponseEntity<>(checkAudienceDetailsMap, HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof AudienceException) {
				AudienceException ex = (AudienceException) e;
				errorcode = ((AudienceException) ex).getErrorCode();
			}
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			logger.error("Error occurred while verifying audience usage", e);
			resp.addError("Error occurred while verifying audience usage ",
					messageSource.getMessage(errorcode, new Object[] { audienceIds }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * checking dimention table usage audiences .
	 *
	 * @param audienceId,logicalTableName,logicalColumnNames
	 * 
	 * @return
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/checkingDimentionTableUsage/{audienceId}/{logicalTableName}/{logicalColumnNames}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> checkingDimentionTableUsage(@PathVariable Long audienceId,
			@PathVariable String logicalTableName, @PathVariable String logicalColumnNames,@RequestHeader HttpHeaders requestHeaders) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : checkingDimentionTableUsage()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(requestHeaders, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean resultvalue = false;
		String associatedCampaignNames = "";
		try {
			RestRequestHandler restHandler = new RestRequestHandler();
			String endPoint = ZetaUtil.getHelper().getEndpoint("conversation");
			Map<String,String> audienceDetails=new HashMap<>();
			audienceDetails.put("logicalTableName", logicalTableName);
			audienceDetails.put("logicalColumnName", logicalColumnNames);
			logger.debug("Verfying in symbol table :: "+logicalTableName+"  :: "+logicalColumnNames);
			HttpEntity entity =ZetaUtil.getHelper().getRestEntity(audienceDetails);
			ResponseEntity<?> response = restHandler.exchange(endPoint + "/getSysmbolsByLogicalTableNColumn",HttpMethod.POST, entity, Long.class);
			if (response.hasBody()) {				
				Long result = (Long) response.getBody();
				if(result > 0)
					resultvalue = true; 
			}			
		} catch (Exception ex) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Error occurred while checking dimention table usage audiences details ",
					messageSource.getMessage(((AudienceException) ex).getErrorCode(), new Object[] { audienceId },
							LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			logger.error("Error occurred while checkingDimentionTableUsage audience details", ex);
		}
		logger.info("End : checkingDimentionTableUsage()");
		return new ResponseEntity<Boolean>(resultvalue, HttpStatus.OK);
	}

	
	/**
	 * delete audience.
	 *
	 * @param audienceBO
	 *            the audience bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteDimensionTables/{audienceId}/{physicalTableId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteDimensionTables(@PathVariable Long audienceId,@PathVariable Long physicalTableId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : deleteDimensionTables()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean deleteStatus = false;
		try {
			deleteStatus = audienceService.deleteDimensionTables(audienceId, physicalTableId);
			return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleteing audience details", ex);
			resp.addError("Error occurred while deleteing audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Find all audiences by criteria.
	 *
	 * @param listingCriteria
	 *            the listing criteria
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findAudiencesByCriteria", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAllAudiencesByCriteria(@RequestBody AudienceSearchCriteria listingCriteria,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAllAudiencesByCriteria()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		ResponseObject resp = new ResponseObject();
		List<AudienceBO> audienceBOList = null;
		try {
			listingCriteria.setColumnNames(Constants.AUDIENCE_COLUMNS);
			audienceBOList = audienceService.findAllAudiences(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				if (bindingResult.hasErrors()) {
					resp.addErrors(bindingResult, "Invalid Data");
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
				}
			}
			return new ResponseEntity<List<AudienceBO>>(audienceBOList, HttpStatus.OK);
		} catch (AudienceException ex) {
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * Save audience metadata.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveOrUpdateDimensionTables", method = RequestMethod.POST)
	public ResponseEntity<?> saveOrUpdateDimensionTables(@RequestBody AudienceBO audienceBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceBO.getAudienceId());}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : saveOrUpdateDimensionTables()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		AudienceBO audienceDetails = null;
		try {
			if(audienceBO.getAudienceId() != 0){
				LogicalTableBO logicalTableBO = audienceService.getReceipentTableByAudienceId(audienceBO.getAudienceId());
				audienceBO.getLogicalTables().add(logicalTableBO);
			}
			boolean isSaveOrUpdate = audienceService.updateAudience(audienceBO,bindingResult);
			logger.debug("dimension table save/update status--------->"+isSaveOrUpdate);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AudienceException ex) {
			logger.error("Error occurred while saving audience details", ex);
			resp.addError("Error occurred while saving audience details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.info("End : saveOrUpdateDimensionTables()");
		return new ResponseEntity<AudienceBO>(audienceDetails, HttpStatus.OK);
	}
	/**
	 * find audiences total count.
	 *
	 * @param listingCriteria
	 *          
	 * @return audiences count
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/findAudiencesTotalCount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAudiencesTotalCount(@RequestBody AudienceSearchCriteria listingCriteria,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : findAudiencesTotalCount()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		return new ResponseEntity<>(audienceService.audiencesTotalCount(listingCriteria),HttpStatus.OK);
	}
	
	/**
	 * Gets the key columns by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the key columns by audience id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getAudienceDataByLTableAndLColumn/{audienceId}/{tableTypeParam}/{logicalTableName}/{logicalColumnName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAudienceDataByLTableAndLColumn(@PathVariable Long audienceId,@PathVariable String tableTypeParam,
			@PathVariable String logicalTableName,@PathVariable String logicalColumnName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getAudienceDataByLTableAndLColumn()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Map<String, String> physicalTableMap = new HashMap<String, String>();
		try {
			logger.debug("audienceId           -------------->"+audienceId);
			logger.debug("logicalColumnName   --------------->" + logicalColumnName);
			logger.debug("logicalTableName   ---------------->" + logicalTableName);
			Integer tableType = 0;
			if (tableTypeParam.equalsIgnoreCase(SourceTypes.DIMENSION.getSourceType())) {
				tableType = 1;
			}
			AudienceBO audienceObj = audienceService.findAudienceById(audienceId);
			if (audienceObj != null) {
				List<LogicalTableBO> logicalTableBOList = audienceObj.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableBOList) {
					if (logicalTableBO.getLogicalTableName().equalsIgnoreCase(logicalTableName)
							&& logicalTableBO.getTableType() == tableType) {
						physicalTableMap.put(Constants.PHYSICAL_TABLE_ID,
								String.valueOf(logicalTableBO.getPhysicalTableId()));
						physicalTableMap.put(Constants.PHYSICAL_TABLE_NAME, logicalTableBO.getPhysicalTableName());
						physicalTableMap.put(Constants.PHYSICAL_TABLE_ID, logicalTableBO.getPhysicalTableId().toString());
						if(logicalColumnName != null) {
							List<LogicalColumnBO> logicalColumnBOList = logicalTableBO.getLogicalColumns();
							for (LogicalColumnBO logicalColumnBO : logicalColumnBOList) {
								if (logicalColumnBO.getLogicalColumnName().equalsIgnoreCase(logicalColumnName)) {
									physicalTableMap.put(Constants.PHYSICAL_COLUMN_NAME,
											logicalColumnBO.getPhysicalColumnName());
									physicalTableMap.put(Constants.COLUMN_DATA_TYPE,Constants.getDataType(logicalColumnBO.getColumnDataType()));
								}
							}
						}
					}
				}
			}
			return new ResponseEntity<Map<String,String>>(physicalTableMap, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the key columns by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the key columns by audience id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getKeyColumnsByAudienceId/{audienceId}/{logicalTableName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getKeyColumnsByAudienceId(@PathVariable long audienceId,@PathVariable String logicalTableName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getKeyColumnsByAudienceId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		AudienceKeyColumnsBO audienceKeyColumnsBO = null;
		try {
			audienceKeyColumnsBO = audienceService.getKeyColumnsByAudienceId(audienceId,logicalTableName);
			return new ResponseEntity<AudienceKeyColumnsBO>(audienceKeyColumnsBO, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching audience details", ex);
			resp.addError("Error occurred while fetching audience details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the key columns by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the key columns by audience id
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalColumnsWithNullableFalgByAudienceId/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsWithNullableFalgByAudienceId(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getKeyColumnsByAudienceId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			AudienceBO audienceBO = audienceService.getLogicalColumnsWithNullableFalgByAudienceId(audienceId);
			return new ResponseEntity<AudienceBO>(audienceBO, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching get logical column details", ex);
			resp.addError("Error occurred while fetching get logical column details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * Gets the key columns by audience name.
	 *
	 * @param audienceId the audience name
	 * @return the key columns by audience name
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getLogicalColumnsWithNullableFalgByAudienceName/{audienceName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLogicalColumnsWithNullableFalgByAudienceName(@PathVariable String audienceName,@RequestHeader HttpHeaders headers)  throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : getLogicalColumnsWithNullableFalgByAudienceName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			AudienceBO audienceBO = audienceService.getLogicalColumnsWithNullableFalgByAudienceName(audienceName);
			return new ResponseEntity<AudienceBO>(audienceBO, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching get logical column details", ex);
			resp.addError("Error occurred while fetching get logical column details ",messageSource.getMessage(ex.getErrorCode(), new Object[] {audienceName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	private boolean authorize(HttpHeaders headers,String resourceName,String accessType)
	{
		// Authorization

		boolean isAuthorized = false;
		if(StringUtils.isBlank(headers.getFirst("userid"))||StringUtils.isBlank(headers.getFirst("customercode")))
		{
			return isAuthorized;
		}
		try
		{
			UserBO userBO = new UserBO();
			userBO.setUserID(StringUtil.isNotBlank(headers.getFirst("userid"))
					? Integer.valueOf(headers.getFirst("userid")) : 0);
			Authorizer securityClient = new Authorizer(
					ZetaUtil.getHelper().getEndpoint(com.zetainteractive.zetahub.securityclient.constants.Constants.SECURITY_ENDPOINT),
					userBO, 
					headers.getFirst("customercode"));
			isAuthorized = securityClient.hasResourePermission(accessType, resourceName);

		} catch (Exception e)
		{
			e.printStackTrace();
			logger.error("Failed to authorize user request",e);
		}
		return isAuthorized;
	}
	@HystrixCommand
	@RequestMapping(value = "/getAudienceMetaDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAudienceMetaDetails(@RequestHeader HttpHeaders headers){
		logger.debug("Begin :: "+getClass().getName()+"  ::getAudienceMetaDetails()");
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(audienceService.getAudienceMetaDetails(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			ResponseObject resp = new ResponseObject();
			resp.addError("Error","Error occurred while fetching audience meta details.");
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	

}

/**
 * AudienceDataSyncController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceDataSyncService;
import com.zetainteractive.zetahub.bootstarter.ZetaContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.DataSyncExecutionStatusBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jun 29, 2016 12:29:58 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceDataSyncController" is used for syncronization of Audience Metadata from Wharehouse DB to Customer DB 
 * 
 **/
@RestController
public class AudienceDataSyncController {
	
	/** The logger. */
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	AudienceDataSyncService audienceDataSyncService;
	@Autowired
	MessageSource messageSource;
	/**
	 * System audience data sync.
	 *
	 * @param requestType the request type
	 * @return the response entity
	 * @throws Exception 
	 */
	@HystrixCommand
	@RequestMapping(value = "/systemAudienceDataSync/{requestType}/{departmentId}", method = RequestMethod.GET)
	public ResponseEntity<?> systemAudienceDataSync(@PathVariable String requestType,@PathVariable Long departmentId,@RequestHeader HttpHeaders headers) throws Exception{
		try {ZetaUtil.getHelper().setLoggingContextKey(new TagReplacement().replace(LoggerConstants.DATA_SYNC.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : syncDataSource()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007", new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE },
					LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		String dataSyncStatus = null;
		try {
			logger.debug("request type----------------------->"+requestType);
			ZetaContext context = ZetaUtil.getHelper();
			UserBO userObj = context.getUser();
			String userName = context.getUser().getUserName();
			String customercode = context.getCustomerID();
			String whSchemaUrl = context.getConfig().getConfigValueString("warehouse-db-url", "");
			String contextKey=ZetaUtil.getHelper().getLoggingContextKey();
			logger.info("whSchemaUrl===========================>"+whSchemaUrl);
            
           
			if(requestType != null && requestType.equalsIgnoreCase("sync")){
				 logger.debug("System audience data sync process initiated");
				    int dataSourceId = 2;  // Temporarily hard coded
					if(dataSourceId == 0 ){
						throw new AudienceException("AU0039");
					}else{
						char syncStatus = audienceDataSyncService.getDataSourceSyncStatus(dataSourceId);
						if(syncStatus == Constants.PROGRESS){
							dataSyncStatus="Started. Already Inprogress.";
							resp.addError("Error occurred while running audience data sync service ",messageSource.getMessage("AU0039", new Object[] {},LocaleContextHolder.getLocale()));
							resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
							return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						Runnable syncDataTask = () -> {
							try {
								//Added to Resolve Context Initialization issues
								logger.debug("Initializing Thread Context With CustomerCode - "+customercode);
								logger.debug("Initializing Thread Context With User - "+userObj.getUserName() + " - "+userObj.getUserID());
								
								ZetaContext zetaContext = ZetaUtil.getHelper(customercode, null);
								zetaContext.setUser(userObj);
								ZetaUtil.getHelper().setLoggingContextKey(contextKey);
								if (whSchemaUrl != null) {
									String whSchemaName = null;
									if(whSchemaUrl.indexOf("&") != -1) {
										whSchemaName = whSchemaUrl.substring(whSchemaUrl.indexOf("=") + 1,whSchemaUrl.indexOf("&"));
									}else{
										whSchemaName = whSchemaUrl.substring(whSchemaUrl.indexOf("=") + 1);
									}
									logger.debug("userName ------->" + userName);
									logger.info("whSchemaName ------->" + whSchemaName);
									logger.info("=====> sync data source start :: " + new Date());
									audienceDataSyncService.syncAudienceMetaData(dataSourceId,whSchemaName,userName,departmentId);
									logger.info("=====> sync data source end :: " + new Date());
								}else{
									logger.error("Warehouse DB details not found");
								}
							} catch (Exception e) {
								logger.error("Error occurred while syncDataSource", e);
							}
						};
						new Thread(syncDataTask).start();
				}
			}
		} catch (AudienceException ex) {
			String errorCode = ex.getErrorCode();
			if(errorCode == null) {
				errorCode = "AU0012";
				logger.error("Datasource configuration is missing. Please contact your administrator.",ex);
			}else if(errorCode == "AU0039"){
				logger.error("Datasource sync service is in progress. Please try after some time.",ex);
			}
			resp.addError("Error occurred while running audience data sync service ",messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.info("Ends : syncDataSource()");
		return new ResponseEntity<String>(dataSyncStatus, HttpStatus.OK);
	}
	
	
	
	
	/**
	 * Method Name 	: syncDataSource
	 * Description 	: The Method "syncDataSource" is used to sync the data source from warehouse to customer database
	 * Date    		: Jun 29, 2016, 6:54:30 PM
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws Exception 
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(path = "/syncProfileColumns/{audienceId}", method = RequestMethod.GET)
	public ResponseEntity<?> syncProfileColumns(@PathVariable long audienceId,@RequestHeader HttpHeaders headers) throws Exception{
		try {ZetaUtil.getHelper().setLoggingContextKey(new TagReplacement().replace(LoggerConstants.PROFILE_SYNC.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", audienceId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start : syncProfileColumns()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007", new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE },
					LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		String dataSyncStatus = null;
		Map<String,String> resultMap = new HashMap<String,String>();
		try {
			logger.debug("audienceId ------------------->"+audienceId);
			String contextKey=ZetaUtil.getHelper().getLoggingContextKey();
			ZetaContext context = ZetaUtil.getHelper();
			UserBO userObj = context.getUser();
			String customercode = context.getCustomerID();
			int dataSourceId = 2;
			if(dataSourceId == 0 ){
				logger.info("Datasource Id is missing. Please check data source id.");
				throw new AudienceException("AU0029");
			}
			else
			{
				DataSyncExecutionStatusBO datasourceSyncExecution = audienceDataSyncService.findDataSourceSyncStatus(dataSourceId);
				logger.debug("profileSyncStatus------------------------------>"+datasourceSyncExecution.getProfileSyncStatus());
				if(datasourceSyncExecution.getDataSourceSyncStatus() == Constants.PROGRESS){
					resp.addError("Error occurred while running audience data sync service ",messageSource.getMessage("AU0039", new Object[] {},LocaleContextHolder.getLocale()));
					resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				if(datasourceSyncExecution.getDataSourceSyncStatus() == ' ' || datasourceSyncExecution.getDataSourceSyncStatus() == Constants.FIRST_TIME_SYNC_ERRORED){
					resp.addError("Datasource tables are not available. Please sync datasource before syncing profile columns",messageSource.getMessage("AU0031", new Object[] {},LocaleContextHolder.getLocale()));
					resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				if(datasourceSyncExecution.getProfileSyncStatus() == Constants.PROGRESS){
					resp.addError("Profile Column sync service is in progress. Please try after some time ",messageSource.getMessage("AU0032", new Object[] {},LocaleContextHolder.getLocale()));
					resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				Runnable syncDataTask = () -> { 
					try {
						//Added to Resolve Context Initialization issues
						logger.debug("Initializing Thread Context With CustomerCode - "+customercode);
						logger.debug("Initializing Thread Context With User - "+userObj.getUserName() + " - "+userObj.getUserID());
						
						ZetaContext zetaContext = ZetaUtil.getHelper(customercode, null);
						zetaContext.setUser(userObj);	
						ZetaUtil.getHelper().setLoggingContextKey(contextKey);
						
	              	  logger.info("=====> sync profile columns start :: "+new Date());
	              	  audienceDataSyncService.syncProfileColumns(audienceId,dataSourceId);
	                  logger.info("=====> sync profile columns end :: "+new Date());
	              }
	              catch(Exception e) {
	            	  logger.error("Error occurred while syncProfileColumns", e);
	              }
				};
				new Thread(syncDataTask).start();
			}
			dataSyncStatus="Inprogress";
			resultMap.put("result", dataSyncStatus);
		} catch (AudienceException ex) {
			String errorCode = ex.getErrorCode();
			if(errorCode == null) {
				ex.printStackTrace(); // to be removed after testing
				errorCode = "AU0024";
			}
			if(errorCode == "AU0029"){
				logger.error("Datasource configuration is missing. Please contact your administrator.",ex);
			}
			else if(errorCode == "AU0031"){
				logger.error("Datasource tables are not available. Please sync datasource before syncing profile columns.",ex);
			}
			else if(errorCode == "AU0032"){
				logger.error("Profile Column sync service is in progress. Please try again later.",ex);
			}
			else if(errorCode == "AU0039"){
				logger.error("Datasource sync service is in progress. Please try after some time.",ex);
			}else{
				logger.error("Unknown exception occured ::",ex);
			}
			resp.addError("Error occurred while running profileable column sync service ",messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.info("Ends: syncProfileColumns()");
		return new ResponseEntity<Map<String,String>>(resultMap, HttpStatus.OK);
	}

}

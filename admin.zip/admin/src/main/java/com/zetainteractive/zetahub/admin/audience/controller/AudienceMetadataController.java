/**
 * AudienceMetadataController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceMetadataService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ColumnStatCountBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 29, 2016 4:01:54 PM
 * @Version : 1.7
 * @Description : "AudienceMetadataController" is used for Physical Tables & Physical Columns Data persistence
 * 
 **/
@RestController
@RequestMapping("/physicalTables")
public class AudienceMetadataController {

	/** The logger. */
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	private AudienceMetadataService audienceMetadataService;
	@Autowired
	MessageSource messageSource;

	/**
	 * Save physical tables.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/savePhysicalTable", method = RequestMethod.POST)
	public ResponseEntity<?> savePhysicalTable(@RequestBody PhysicalTableBO physicalTableBO,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: savePhysicalTable()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Long physicalTableId = null;
		try {
			physicalTableId = audienceMetadataService.savePhysicalTable(physicalTableBO, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			
		}catch (AudienceException ex) {
			logger.error("Error occurred while saving physical table details", ex);
			resp.addError("Error occurred while saving physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("End :: savePhysicalTable()");
		return new ResponseEntity<Long>(physicalTableId, HttpStatus.OK);
	}

	/**
	 * Update physical tables.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(value = "/updatePhysicalTable", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updatePhysicalTable(@RequestBody PhysicalTableBO physicalTableBO,BindingResult bindingResult,@RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: updatePhysicalTable()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean updateStatus = false;
		try {
			updateStatus = audienceMetadataService.updatePhysicalTable(physicalTableBO,bindingResult);
			if(bindingResult.hasErrors()){
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<Boolean>(updateStatus, HttpStatus.OK);
		} catch (AudienceException ex) {
			logger.error("Error occurred while updating physical table details", ex);
			resp.addError("Error occurred while updating physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		

	}

	/**
	 * Delete physical tables.
	 *
	 * @param physicalTableId
	 *            the physical table id
	 * @return the response entity
	 * @throws AudienceException
	 */
	@HystrixCommand
	@RequestMapping(path = "/deletePhysicalTable/{physicalTableId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deletePhysicalTable(@PathVariable Long physicalTableId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: deletePhysicalTable()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<Boolean>(audienceMetadataService.deletePhysicalTable(physicalTableId), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleting physical table details", ex);
			resp.addError("Error occurred while deleting physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {physicalTableId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}

	/**
	 * Find physical tables.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findPhysicalTableById/{physicalTableId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findPhysicalTableById(@PathVariable Long physicalTableId,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findPhysicalTableById()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<PhysicalTableBO>(audienceMetadataService.findPhysicalTableId(physicalTableId), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching physical table details", ex);
			resp.addError("Error occurred while fetching physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {physicalTableId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Find physical tables by name.
	 *
	 * @param physicalTableName
	 *            the physical table name
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findPhysicalTableByName/{physicalTableName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findPhysicalTableByName(@PathVariable String physicalTableName,@RequestHeader HttpHeaders headers)
			throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findPhysicalTableByName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<PhysicalTableBO>(audienceMetadataService.findPhysicalTableByName(physicalTableName), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching physical table details", ex);
			resp.addError("Error occurred while fetching physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {physicalTableName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * List all physical tables
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/listPhysicalTables", method = RequestMethod.GET)
	public ResponseEntity<?> listPhysicalTables(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: listPhysicalTables()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<List<PhysicalTableBO>>(audienceMetadataService.listPhysicalTables(), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching physical table details", ex);
			resp.addError("Error occurred while fetching physical table details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find physical (staging) tables.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findStagingTables", method = RequestMethod.GET)
	public ResponseEntity<?> findStagingTables(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findStagingTables()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			return new ResponseEntity<List<PhysicalTableBO>>(audienceMetadataService.listStatingTables(), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching stating table details", ex);
			resp.addError("Error occurred while fetching stating table details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Find physical tables not mapped to any Audience.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findPhysicalTablesNotMappedInAudiences", method = RequestMethod.GET)
	public ResponseEntity<?> findPhysicalTablesNotMappedInAudiences(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findPhysicalTablesNotMappedInAudiences()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
		
			return new ResponseEntity<List<PhysicalTableBO>>(audienceMetadataService.findPhysicalTablesNotMappedInAudiences(false), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching physical table details", ex);
			resp.addError("Error occurred while fetching physical table details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find physical tables not mapped to any Audience.
	 *
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findPhysicalTablesForDimensionsInAudiences", method = RequestMethod.GET)
	public ResponseEntity<?> findPhysicalTablesForDimensionsInAudiences(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: findPhysicalTablesNotMappedInAudiences()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers,
				com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
		
			return new ResponseEntity<List<PhysicalTableBO>>(audienceMetadataService.findPhysicalTablesNotMappedInAudiences(true), HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching physical table details", ex);
			resp.addError("Error occurred while fetching physical table details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the stats counts list.
	 *
	 * @param physicalTableId the physical table id
	 * @param physicalColumnName the physical column name
	 * @return the stats counts list
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(path = "/getStatCountsList/{physicalTableId}/{physicalColumnName}", method = RequestMethod.GET)
	public ResponseEntity<?> getStatsCountsList(@PathVariable Long physicalTableId, @PathVariable String physicalColumnName,@RequestHeader HttpHeaders headers) throws AudienceException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :: getStatsCountsList()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<ColumnStatCountBO>  statCountsList = null;
		try {
			logger.debug("Physical Table ID:------------->"+physicalTableId);
			logger.debug("Physical Column Name:------------->"+physicalColumnName);
			statCountsList= audienceMetadataService.getStatsCountsList(physicalTableId, physicalColumnName);
			return new ResponseEntity<List<ColumnStatCountBO>>(statCountsList, HttpStatus.OK);
		} catch (AudienceException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching stat counts details", ex);
			resp.addError("Error occurred while fetching stat counts  details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {physicalTableId,physicalColumnName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Gets the max profile column fetch counts 
	 *
	 * @return the max profile column fetch count, config property value
	 * 
	 */
	@HystrixCommand
	@RequestMapping(path = "/getProfileColumnMaxFetchCount", method = RequestMethod.GET)
	public ResponseEntity<?> getProfileColumnMaxFetchCount(@RequestHeader HttpHeaders headers)
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.AUDIENCE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("AUDIENCEID", 0);}},"{", "}"));} catch (Exception e) {}
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE,
				com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ", messageSource.getMessage("E00007",
					new Object[] { com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_AUDIENCE }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try 
		{
			return new ResponseEntity<Integer>(ZetaUtil.getHelper().getConfig().getConfigValueInt("profile-column-max-count", 2500), HttpStatus.OK);
		} 
		catch (Exception ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching profile max count max limit", ex);
			resp.addError("Error occurred while fetching profile max count max limit",null);
			resp.setHttpStatusCode(HttpStatus.OK.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.OK);
		}
	}
	
}

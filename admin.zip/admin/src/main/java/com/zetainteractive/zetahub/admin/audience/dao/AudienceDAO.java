/**
 * AudienceDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao;

import java.util.List;
import java.util.Map;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 28, 2016 4:30:18 PM
 * @Version : 1.7
 * @Description : "AudienceDAO" is used for Audience records persistence
 * 
 **/

public interface AudienceDAO {

	/**
	 * Save audience.
	 *
	 * @param audienceBO the audience bo
	 * @return the long
	 * @throws AudienceException the audience exception
	 */
	public Long saveAudience(AudienceBO audienceBO) throws AudienceException;

	/**
	 * Update audience.
	 *
	 * @param audienceBO the audience bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean updateAudience(AudienceBO audienceBO) throws AudienceException;

	/**
	 * Delete audience.
	 *
	 * @param audienceId the audience bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean deleteAudience(Long audienceId) throws AudienceException;

	/**
	 * Find all audience.
	 *
	 * @param audienceBO the audience bo
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<AudienceBO> findAllAudience() throws AudienceException; 
	
	/**
	 * 
	 * 
	 * 
	 * Method Name 	: findAllAudience
	 * Description 	: The Method "findAllAudience" is used for 
	 * Date    		: 25 Jan 2018, 16:14:44
	 * @param audienceIds
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<AudienceBO>
	 * @throws 		:
	 */
	public List<AudienceBO> findAllAudience(List<Long> audienceIds) throws AudienceException;
	
	

	/**
	 * Find audience by id.
	 *
	 * @param audienceId the audience id
	 * @return the audience bo
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO findAudienceById(Long audienceId) throws AudienceException;
	
	/**
	 * Find audience by name.
	 *
	 * @param audienceName the audience name
	 * @return the audience bo
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO findAudienceByName(String audienceName) throws AudienceException;
	/**
	 * Find audience Name Exist or not.
	 *
	 * @param audienceName the audience name
	 * @return the audience bo
	 * @throws AudienceException the audience exception
	 */ 
	public Boolean isAudiencesNameExists(String audienceName) throws AudienceException;
	
	/**
	 * Find all audiences.
	 *
	 * @param listingCriteria the listing criteria
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<AudienceBO> findAllAudiences(AudienceSearchCriteria listingCriteria) throws AudienceException;
	/**
	 * Find audiences listingCriteria.
	 *
	 * @param listingCriteria the listing criteria
	 * @return audiencesTotalCount
	 * @throws AudienceException the audience exception
	 */
	public Long audiencesTotalCount(AudienceSearchCriteria listingCriteria) throws AudienceException;

	/**
	 * 
	 * Method Name 	: isAudiencesNameExistsWithNameAndId
	 * Description 	: The Method "isAudiencesNameExistsWithNameAndId" is used for 
	 * Date    		: Jul 22, 2016, 8:16:36 PM
	 * @param audienceName
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		: 
	 */
	public Boolean isAudiencesNameExistsWithNameAndId(String audienceName, Long audienceId) throws AudienceException;

	/**
	 * 
	 * 
	 * Method Name 	: getAudienceMetaDetails
	 * Description 	: The Method "getAudienceMetaDetails" is used for getting name and audienceId 
	 * Date    		: 23 Jan 2018, 13:01:53
	 * @return
	 * @param  		:
	 * @return 		: List<Map<String,Object>>
	 * @throws 		:
	 */
	public List<Map<String, Object>> getAudienceMetaDetails();
	/**
	 * 
	 * 
	 * Method Name 	: getAudienceNamesByIds
	 * Description 	: The Method "getAudienceNamesByIds" is used for getting audience names based on audience ids 
	 * Date    		: 23 Jan 2018, 14:36:40
	 * @param ids
	 * @return
	 * @param  		:
	 * @return 		: Map<Long,String>
	 * @throws 		:
	 */
	public Map<Long, String> getAudienceNamesByIds(List<Long> ids);

	public Map<String, Boolean> checkAudienceAssocation(Long audienceId) throws AudienceException;
	

}

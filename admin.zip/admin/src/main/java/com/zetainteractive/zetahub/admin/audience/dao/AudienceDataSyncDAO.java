/**
 * AudienceDataSyncDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/
package com.zetainteractive.zetahub.admin.audience.dao;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;

/**
 * 
 * @Author : venu.gudibena
 * @Created On : Jun 28, 2016 12:55:43 AM
 * @Version : 1.7
 * @Description : "AudienceDataSyncDAO" is used for
 * 
 **/

public interface AudienceDataSyncDAO {

	/**
	 * 
	 * Method Name : getWarehouseDataSourceId Description : The Method
	 * "getWarehouseDataSourceId" is used to get data source id Date : Jun 29,
	 * 2016, 7:23:29 PM
	 * 
	 * @param custcode
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : int
	 * @throws :
	 */
	public int getWarehouseDataSourceId(String custcode) throws AudienceException;
}

/**
 * AudienceMetaDataDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 24, 2016 6:30:43 PM
 * @Version : 1.7
 * @Description : "AudienceMetaDataDAO" is used for Physical Tables & columns persistence
 * 
 **/

public interface AudienceMetadataDAO {

	/**
	 * Save audience meta data.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return 
	 * @throws AudienceException
	 *             the audience exception
	 */
	public Long savePhysicalTable(PhysicalTableBO physicalTableBO) throws AudienceException;

	/**
	 * 
	 * 
	 * Method Name : updateAudienceMetadata Description : The Method
	 * "updateAudienceMetadata" is used for Date : Jun 27, 2016, 6:57:15 PM
	 * 
	 * @param physicalTableBO
	 * @throws AudienceException
	 * @param :
	 * @return : void
	 * @throws :
	 */
	public Boolean updatePhysicalTable(PhysicalTableBO physicalTableBO) throws AudienceException;

	/**
	 * 
	 * 
	 * Method Name : removeAudienceMetadata Description : The Method
	 * "removeAudienceMetadata" is used for Date : Jun 27, 2016, 7:02:11 PM
	 * 
	 * @param physicalTableId
	 * @throws AudienceException
	 * @param :
	 * @return : void
	 * @throws :
	 */
	public Boolean deletePhysicalTable(Long physicalTableId) throws AudienceException;

	/**
	 * 
	 * 
	 * Method Name : listAudienceMetadata Description : The Method
	 * "listAudienceMetadata" is used for Date : Jun 27, 2016, 7:03:41 PM
	 * 
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : List<PhysicalTableBO>
	 * @throws :
	 */
	public List<PhysicalTableBO> listPhysicalTables() throws AudienceException;
	
	/**
	 * Find audience metadata.
	 *
	 * @param physicalTableIdSet the physical table id set
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<PhysicalTableBO> findPhysicalTables(Set<Long> physicalTableIdSet,boolean isDimension) throws AudienceException;
	
	/**
	 * Find audience metadata.
	 * @param physicalTableIdSet the physical table id set
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public Map<Long, PhysicalTableBO> findPhysicalTablesByIds(Set<Long> physicalTableIdSet) throws AudienceException ;
	
	
	/**
	 * Find audience metadata by id.
	 *
	 * @param physicalTableId the physical table id
	 * @return the physical table bo
	 * @throws AudienceException the audience exception
	 */
	public PhysicalTableBO findPhysicalTableById(Long physicalTableId) throws AudienceException;

	/**
	 * 
	 * Method Name : findAudienceMetadataByName Description : The Method
	 * "findAudienceMetadataByName" is used for Date : Jun 29, 2016, 5:45:45 PM
	 * 
	 * @param physicalTableName
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : PhysicalTableBO
	 * @throws :
	 */
	public PhysicalTableBO findPhysicalTableByName(String physicalTableName) throws AudienceException;
	
	/**
	 * Gets the physical table id.
	 *
	 * @param physicalTableName the physical table name
	 * @return the physical table id
	 * @throws AudienceException the audience exception
	 */
	public Long getPhysicalTableId(String physicalTableName) throws AudienceException;

	/**
	 * 
	 * Method Name 	: listAudienceMetadata
	 * Description 	: The Method "listAudienceMetadata" is used for 
	 * Date    		: Jul 13, 2016, 3:12:46 PM
	 * @param tableType
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<PhysicalTableBO>
	 * @throws 		: 
	 */
	public List<PhysicalTableBO> listPhysicalTablesByTableType(String tableType) throws AudienceException;
}

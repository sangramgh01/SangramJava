/**
 * WarehouseDataExplorerDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao;

import java.util.List;
import java.util.Map;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : venu.gudibena
 * @Created On : Jun 28, 2016 5:10:03 PM
 * @Version : 1.7
 * @Description : "WarehouseDataExplorerDAO" is used for
 * 
 **/

public interface AudienceWarehouseMetaDataDAO {
	// public Map<Long, List<PhysicalColumnStatRecords>>
	// getProfileableColumnValues(Map<Long, PhysicalColumnBO> physicalColumnMap)
	// throws AudienceException;
	public List<PhysicalTableBO> getAudiencePhysicalTableMetaData(int dataSourceId, String schemaName, String userName)
			throws AudienceException;
	public Map<String, List<PhysicalColumnBO>> getProfileableColumnValues(Map<String,List<PhysicalColumnBO>> profileColumnsMap) throws AudienceException;
	
	public boolean isTableNameExist(String tableName) throws AudienceException;
	public List<String> getEmailDataByTableName(String tableName) throws AudienceException;
	public List<CustomColumnDefinitionBO> getTableColumns(String tableName)throws AudienceException;
}

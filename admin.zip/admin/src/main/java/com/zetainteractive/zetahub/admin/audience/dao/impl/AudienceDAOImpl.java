/**
 * AudienceDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceMetadataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.rowmapper.AudienceRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnNullableMixIn;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 28, 2016 4:35:09 PM
 * @Version : 1.7
 * @Description : "AudienceDAOImpl" is used for Audience persistence
 * 
 **/
@Component
@Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AudienceDAOImpl implements AudienceDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private AudienceMetadataDAO audienceMetadataDAO;
	

	/**
	 * 
	 * Method Name : saveAudience Description : The Method "saveAudience" is
	 * used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */

	@Override
	public Long saveAudience(AudienceBO audienceBO) throws AudienceException {
		logger.debug("Start : saveAudience()");
		String query = "INSERT INTO AUD_AUDIENCE (audiencename, departmentid, audiencetype, audiencemapping, isdefault, audiencestatus, createdby, updatedby, createdate, updatedate) values (?,?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";
		ObjectMapper objectMapper = new ObjectMapper();
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
			UserBO userBO = ZetaUtil.getHelper().getUser();
			List<LogicalTableBO> tableList = audienceBO.getLogicalTables();
			for (LogicalTableBO logicalTableBO : tableList) {
				logicalTableBO.setCreatedBy(userBO != null ? userBO.getUserName() : Constants.ADMIN);
				logicalTableBO.setUpdatedBy(userBO != null ? userBO.getUserName() : Constants.ADMIN);
				logicalTableBO
						.setCreateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
				logicalTableBO
						.setUpdateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));

				if (logicalTableBO.getPhysicalTableId() != null && logicalTableBO.getPhysicalTableId() > 0) {
					PhysicalTableBO ptBO = audienceMetadataDAO
							.findPhysicalTableById(logicalTableBO.getPhysicalTableId());
					if (ptBO != null) {
						logicalTableBO.setPhysicalTableName(ptBO.getPhysicalTableName());
					}
				}
			}

			objectMapper.addMixIn(LogicalColumnBO.class, PhysicalColumnNullableMixIn.class);
			String jsonLogicalTables = objectMapper.writeValueAsString(audienceBO.getLogicalTables());
			final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement pstmt = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
					pstmt.setString(1, audienceBO.getAudienceName());
					pstmt.setLong(2, audienceBO.getDepartmentId());
					pstmt.setInt(3, audienceBO.getAudienceType());
					pstmt.setString(4, jsonLogicalTables);
					pstmt.setString(5, String.valueOf(audienceBO.getIsDefault()));
					pstmt.setString(6, String.valueOf(audienceBO.getAudienceStatus()));
					pstmt.setString(7, userBO != null ? userBO.getUserName() : Constants.ADMIN);
					pstmt.setString(8, userBO != null ? userBO.getUserName() : Constants.ADMIN);

					return pstmt;
				}
			};
			jdbcTemplate.update(pstmtCreator, keyHolder);
			return keyHolder.getKey() != null ? keyHolder.getKey().longValue() : 0L;
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION, ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : updateAudience Description : The Method "updateAudience" is
	 * used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Boolean
	 * @throws AudienceException
	 */

	@Override
	public Boolean updateAudience(AudienceBO audienceBO) throws AudienceException {
		logger.info("Begin : updateAudience() for audience id::"+(audienceBO!=null?audienceBO.getAudienceId():""));
		logger.info("Audience info,departmentid:"+(audienceBO!=null?audienceBO.getDepartmentId()+";audiencetype:"+audienceBO.getAudienceType()+";audiencename:"+audienceBO.getAudienceName()+";":""));
		String query = "UPDATE  AUD_AUDIENCE set audiencename=?, departmentid=?, audiencetype=?, audiencemapping=?, isdefault=?, audiencestatus=?, updatedby=?, updatedate=utc_timestamp() WHERE audienceid=?";
		logger.info("Audience update query:"+query);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			UserBO userBO = ZetaUtil.getHelper().getUser();
			Date currentDateInUTC = CommonUtil.toUTC(new Date().getTime(),
					TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()));
			AudienceBO audienceBOObj = findAudienceById(audienceBO.getAudienceId());
			if (audienceBOObj != null) {
				List<LogicalTableBO> tableList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : tableList) {
					int countOfTableAvlilable = 0;
					List<LogicalTableBO> logicalTableBOObjList = audienceBOObj.getLogicalTables();
					for (LogicalTableBO logicalTableBOObj : logicalTableBOObjList) {
						if (logicalTableBO.getLogicalTableName()
								.equalsIgnoreCase(logicalTableBOObj.getLogicalTableName())) {
							countOfTableAvlilable++;
							logicalTableBO.setCreateDate(logicalTableBOObj.getCreateDate());
						}
						logicalTableBO.setCreatedBy(logicalTableBOObj.getCreatedBy());
					}
					if (countOfTableAvlilable == 0) {
						logicalTableBO.setCreateDate(currentDateInUTC);
					}
					logicalTableBO.setUpdatedBy(userBO != null ? userBO.getUserName() : Constants.ADMIN);
					logicalTableBO.setUpdateDate(currentDateInUTC);
				}
			}
			objectMapper.addMixIn(LogicalColumnBO.class, PhysicalColumnNullableMixIn.class);
			String jsonLogicalTables = objectMapper.writeValueAsString(audienceBO.getLogicalTables());
			String createdby = userBO != null ? userBO.getUserName() : Constants.ADMIN;
			Object[] args = new Object[] { audienceBO.getAudienceName(), audienceBO.getDepartmentId(),
					audienceBO.getAudienceType(), jsonLogicalTables, String.valueOf(audienceBO.getIsDefault()),
					String.valueOf(audienceBO.getAudienceStatus()), createdby,

					audienceBO.getAudienceId() };
			try 
			{
				//Add previous/existing audience record into History table to track Audience changes
				logger.info("Updating audience for audienceid:"+audienceBO.getAudienceId()+";updated by:"+createdby+";updated date in UTC:"+currentDateInUTC);
				auditAudienceChanges(audienceBO.getAudienceId());
			} catch (Exception e)
			{
				logger.error("Failed to audit current audience while updating audience for audience id:"+audienceBO.getAudienceId(),e);;
			}
			int status = jdbcTemplate.update(query, args);
			if (status != 0) {
				logger.info("Audience record updated with id=" + audienceBO.getAudienceId());
				return true;
			} else {
				logger.warn("No Audience record found with id=" + audienceBO.getAudienceId());
				return false;
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION, ex);
			logger.warn("Failed to update Audience ::"+audienceBO);
			throw new AudienceException("E00002", ex);
		}

	}
	
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	private void auditAudienceChanges(Long audienceId)
	{
		final String query = "insert into HIS_AUD_AUDIENCE select * from AUD_AUDIENCE where audienceid=?";
		Object[] args = new Object[] {  audienceId };
		jdbcTemplate.update(query, args);
	}

	/**
	 * 
	 * Method Name : deleteAudience Description : The Method "deleteAudience" is
	 * used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Boolean
	 * @throws AudienceException
	 */

	@Override
	public Boolean deleteAudience(Long audienceId) throws AudienceException {
		logger.debug("Start : deleteAudience()");
		String query = "DELETE FROM AUD_AUDIENCE WHERE AUDIENCEID = ?";
		try {
			try 
			{
				logger.info("Deleting audience for audience id:"+audienceId);
				auditAudienceChanges(audienceId);
			} catch (Exception e)
			{
				logger.error("Failed to audit current audience while deleting audience id:"+audienceId,e);
			}
			int status = jdbcTemplate.update(query, audienceId);
			if (status != 0) {
				logger.info("Audience record deleted with id=" + audienceId);
				return true;
			} else {
				logger.warn("No Audience found deleted id=" + audienceId);
				return false;
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION, ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : findAllAudience Description : The Method "findAllAudience"
	 * is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return List<AudienceBO>
	 * @throws AudienceException
	 */

	@Override
	public List<AudienceBO> findAllAudience(List<Long> audienceIds) throws AudienceException {
		logger.debug("Start : findAllAudience(List<Long> audienceIds)");
		List<AudienceBO> audienceBOList = null;
		String query = "SELECT * FROM AUD_AUDIENCE";
		try {
			if(audienceIds !=null && !audienceIds.isEmpty()){
				StringBuilder condition=new StringBuilder(" WHERE audienceid in (");
				for (Long id: audienceIds)
					condition.append(id).append(",");
				audienceBOList = jdbcTemplate.query(query+condition.toString().substring(0, condition.toString().length()-1)+")", new AudienceRowMapper());
			}else
				audienceBOList = jdbcTemplate.query(query, new AudienceRowMapper());
		} catch (Exception ex) {
			if(ex.getMessage() != null && ex.getMessage().contains("Could not get JDBC Connection"))
				throw new AudienceException("AU0079", ex);
			logger.error("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findAllAudience(List<Long> audienceIds)");
		return audienceBOList;
	}
	@Override
	public List<AudienceBO> findAllAudience() throws AudienceException {
		return findAllAudience(null);
	}
	 
		
	/**
	 * 
	 * Method Name : findAudienceById Description : The Method
	 * "findAudienceById" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceId
	 * @return AudienceBO
	 * @throws AudienceException
	 */

	@Override
	public AudienceBO findAudienceById(Long audienceId) throws AudienceException {
		logger.debug("Start : findAudienceById()");
		AudienceBO audienceBO = null;
		String query = "SELECT * FROM AUD_AUDIENCE WHERE AUDIENCEID = ?";
		try {
			Object[] args = new Object[] { audienceId };
			audienceBO = jdbcTemplate.queryForObject(query, args, new AudienceRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return audienceBO;
		} catch (Exception ex) {
			if(ex.getMessage() != null && ex.getMessage().contains("Could not get JDBC Connection"))
				throw new AudienceException("AU0079", ex);
			logger.error("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findAudienceById()");
		return audienceBO;

	}

	/**
	 * 
	 * Method Name : findAudienceByName Description : The Method
	 * "findAudienceByName" is used for Date : Jul 2, 2016, 12:34:01 PM
	 * 
	 * @param audienceName
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public AudienceBO findAudienceByName(String audienceName) throws AudienceException {
		logger.debug("Start : findAudienceByName()");
		AudienceBO audienceBO = null;
		String query = "SELECT * FROM AUD_AUDIENCE WHERE AUDIENCENAME=?";
		try {
			logger.debug("Audience Name:" + audienceName);
			Object[] args = new Object[] { audienceName };
			audienceBO = jdbcTemplate.queryForObject(query, args, new AudienceRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			return audienceBO;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findAudienceByName()");
		return audienceBO;
	}

	/**
	 * This method is used to verify whether any Audience is there with given
	 * name
	 * 
	 * @param audienceName
	 * @return
	 * @throws AudienceException
	 */
	@Override
	public Boolean isAudiencesNameExists(String audienceName) throws AudienceException {
		logger.debug("Begin: isAudiencesNameExists("+audienceName+")");
		String query = "select * from AUD_AUDIENCE where UPPER(AUDIENCENAME)=UPPER(?)";
		Boolean nameExists = false;
		List<?> nameList = null;
		try {
			Object[] param = { audienceName };
			nameList = jdbcTemplate.queryForList(query, param);
			if (nameList != null && nameList.size() > 0) {
				nameExists = true;
			}
		} catch (Exception ex) {
			logger.error("Error occurred while while checking audience exists with name", ex);
			throw new AudienceException("E00002", ex);
		}
		return nameExists;
	}

	/**
	 * 
	 * Method Name : isAudiencesNameExistsWithNameAndId Description : The Method
	 * "isAudiencesNameExistsWithNameAndId" is used for Date : Jul 22, 2016,
	 * 8:20:14 PM
	 * 
	 * @param audienceName
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 */
	@Override
	public Boolean isAudiencesNameExistsWithNameAndId(String audienceName, Long audienceId) throws AudienceException {
		logger.debug("Begin: isAudiencesNameExistsWithNameAndId(" + audienceName + "," + audienceId + ")");
		String query = "SELECT * from AUD_AUDIENCE where UPPER(AUDIENCENAME)=UPPER(?) AND AUDIENCEID!=? ";
		Boolean nameExists = false;
		List<?> nameList = null;
		try {
			//String audienceStatus = "I"; // InActive
			Object[] param = { audienceName, audienceId };
			nameList = jdbcTemplate.queryForList(query, param);
			if (nameList != null && nameList.size() > 0) {
				nameExists = false;
			} else {
				nameExists = true;
			}
		} catch (Exception ex) {
			logger.debug("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		return nameExists;
	}

	/**
	 * 
	 * Method Name : findAllAudiences Description : The Method
	 * "findAllAudiences" is used for Date : Jul 6, 2016, 8:09:59 PM
	 * 
	 * @param listingCriteria
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<AudienceBO> findAllAudiences(AudienceSearchCriteria listingCriteria) throws AudienceException {
		logger.debug("Start : findAllAudience()");
		List<AudienceBO> audienceBOList = null;
		String query = null;
		List params = new ArrayList();
		String queryBuilder = prepareQuery(listingCriteria.getSortUsing(), listingCriteria.getSortBy());

		try {
			params.add(Constants.getAudienceType(listingCriteria.getAudienceType()));
			String inCondition = "NOT IN (?)";
			if (listingCriteria.getAudienceType().equalsIgnoreCase("CUSTOM")) {
				params.set(0, Constants.getAudienceType("SYSTEM"));
				inCondition = "IN (?)";
			}
			StringBuilder idCondition=new StringBuilder(" audienceid in (");
			for (Long id : listingCriteria.getAudienceIds() ){
				idCondition.append("?,");
				params.add(id);
			}
			Long limit = (listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize();
			if (!listingCriteria.getNameLike().equals("")) {
				params.add("%" + listingCriteria.getNameLike() + "%");
				params.add(limit);
				params.add(listingCriteria.getPageSize());

				query = "SELECT * FROM AUD_AUDIENCE WHERE AUDIENCETYPE " + inCondition +" AND "+idCondition.toString().substring(0, idCondition.toString().length()-1)+")"
						+ " AND AUDIENCENAME LIKE ?  "+ queryBuilder + " LIMIT ? ,?";
			} else {

				params.add(limit);
				params.add(listingCriteria.getPageSize());
				query = "SELECT * FROM AUD_AUDIENCE WHERE AUDIENCETYPE " + inCondition + " AND "+idCondition.toString().substring(0, idCondition.toString().length()-1)+")"
						+ queryBuilder	+ "  LIMIT ? ,?";
			}
			logger.info(query);

			audienceBOList = jdbcTemplate.query(query, params.toArray(), new AudienceRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			ex.printStackTrace();
			return audienceBOList;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findAllAudience()");
		return audienceBOList;
	}

	/**
	 * 
	 * Method Name : findAllAudiences Description : The Method
	 * "findAllAudiences" is used for Date : Jul 6, 2016, 8:09:59 PM
	 * 
	 * @param listingCriteria
	 * @return
	 * @throws AudienceException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Long audiencesTotalCount(AudienceSearchCriteria listingCriteria) throws AudienceException {
		logger.debug("Start :audiencesTotalCount()");
		Long audienceCount = 0L;
		String query = null;
		List params = new ArrayList();
		String queryBuilder = prepareQuery(listingCriteria.getSortUsing(), listingCriteria.getSortBy());
		try {
			params.add(Constants.getAudienceType(listingCriteria.getAudienceType()));
			String inCondition = "NOT IN (?)";
			if (listingCriteria.getAudienceType().equalsIgnoreCase("CUSTOM")) {
				params.set(0, Constants.getAudienceType("SYSTEM"));
				inCondition = "IN (?)";
			}
			StringBuilder idCondition=new StringBuilder(" audienceid in (");
			for (Long id : listingCriteria.getAudienceIds() ){
				idCondition.append("?,");
				params.add(id);
			}
			if (!listingCriteria.getNameEquals().equals("")) {
				params.add(listingCriteria.getNameEquals());
				params.add((listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize());
				params.add(listingCriteria.getPageSize());
				query = "SELECT count(1) FROM AUD_AUDIENCE WHERE AUDIENCETYPE " + inCondition + " AND AUDIENCENAME= ? "
						+ queryBuilder + "  LIMIT ?, ?";
			} else if (listingCriteria.getNameLike() != null) {
				params.add("%" + listingCriteria.getNameLike() + "%");
				query = "SELECT count(1) FROM AUD_AUDIENCE WHERE AUDIENCETYPE " + inCondition+" AND "+idCondition.toString().substring(0, idCondition.toString().length()-1)+")"
						+ " AND AUDIENCENAME LIKE ? ";
			} else {
				query = "SELECT count(1) FROM AUD_AUDIENCE WHERE AUDIENCETYPE " + inCondition + " AND "+idCondition.toString().substring(0, idCondition.toString().length()-1)+")";
			}

			audienceCount = jdbcTemplate.queryForObject(query, params.toArray(), Long.class);
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			ex.printStackTrace();
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching audience records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : audiencesTotalCount()");
		return audienceCount;
	}
	
	/**
	 * 
	 * Method Name : prepareQuery
	 *  Description : this method prepare and returns query
	 * 
	 * 
	 * @param sortUsing,sortBy
	 * @return
	 * 
	 */

	private String prepareQuery(String sortUsing, String sortBy) {
		String sortByValue = null;
		StringBuilder queryBuilder = new StringBuilder();
		if (sortUsing != null && !sortUsing.isEmpty()) {
			switch (sortUsing.toLowerCase().replaceAll("\\s+", "")) {
			case "audiencename":
				sortByValue = "audiencename";
				break;
			case "createdate":
				sortByValue = "createdate";
				break;
			case "createdby":
				sortByValue = "createdby";
				break;

			default:
				sortByValue = "audiencename";
			}
		}

		return queryBuilder.append(" ORDER BY ").append(sortByValue).append(" ")
				.append(sortBy.equalsIgnoreCase("ASC") ? "ASC" : "DESC").toString();
	}
	
	@Override
	public List<Map<String,Object>> getAudienceMetaDetails(){
		return jdbcTemplate.queryForList("SELECT audiencename as audienceName,audienceid as audienceId,audiencetype as audienceType from AUD_AUDIENCE");
	}
	@Override
	public Map<Long,String> getAudienceNamesByIds(List<Long> ids){
		if(ids !=null && !ids.isEmpty()){
			StringBuilder params=new StringBuilder();
			for (Long id : ids)
				params.append(id).append(",");
			
			return jdbcTemplate.query("SELECT audiencename,audienceid from AUD_AUDIENCE WHERE audienceid in ("+params.toString().substring(0,params.toString().length()-1)+")",
					 new ResultSetExtractor<Map<Long, String>>() {
				public Map<Long,String> extractData(ResultSet rs) throws SQLException {
					Map<Long,String> map = new HashMap<>();
					while (rs.next()) {
						map.put(rs.getLong("audienceid"), rs.getString("audiencename"));
					}
					return map;
				}
			});
		}
		return null;
		
	}
    /**
     * 
     * @param audienceId
     * @return
     * @throws AudienceException
     */
	@Override
	public Map<String, Boolean> checkAudienceAssocation(Long audienceId) throws AudienceException {
		logger.info("Begin :: checkAudienceAssocation(audienceID :" + audienceId);
		Boolean usedAudienceinFileDef = Boolean.FALSE;
		Boolean usedAudienceinContent = Boolean.FALSE;
		Boolean usedAudienceinConv = Boolean.FALSE;
		Boolean usedAudienceinWebpage = Boolean.FALSE;
		Map<String, Boolean> checkAudienceDetailsMap = new HashMap<>();
		long start = System.currentTimeMillis();
		NumberFormat formatter = new DecimalFormat("#0.00000");
		try {
			try {
				String query = "select 1 from CNV_CONVERSATION where workflowjson like '%\"audienceID\":" + audienceId
						+ ",%' limit 1";
				Long convCount = jdbcTemplate.queryForObject(query, Long.class);
				if (convCount > 0) {
					usedAudienceinConv = Boolean.TRUE;
				}
			} catch (EmptyResultDataAccessException ex) {
			}
			try {
				Long contentCount = jdbcTemplate.queryForObject(
						"select 1 from CNT_TEMPLATE where audienceid = ? limit 1", Long.class,
						new Object[] { audienceId });
				if (contentCount > 0) {
					usedAudienceinContent = Boolean.TRUE;
				}
			} catch (EmptyResultDataAccessException ex) {
			}
			try {
				Long webpageCount = jdbcTemplate.queryForObject("select 1 from WEB_PAGE where audienceid = ? limit 1",
						Long.class, new Object[] { audienceId });
				if (webpageCount > 0) {
					usedAudienceinWebpage = Boolean.TRUE;
				}
			} catch (EmptyResultDataAccessException ex) {
			}
			try {
				Long filesCount = jdbcTemplate.queryForObject(
						"select 1 from LFD_FILEDEFINITION where audienceid = ? limit 1", Long.class,
						new Object[] { audienceId });
				if (filesCount > 0) {
					usedAudienceinFileDef = Boolean.TRUE;
				}
			} catch (EmptyResultDataAccessException ex) {
			}
			logger.debug("Audience search queries execution time is :: " + formatter.format((System.currentTimeMillis() - start) / 1000d)
					+ " seconds");
			logger.info("Audience mapped in conversations :" + usedAudienceinConv+", contents :"+usedAudienceinContent+", webpages :"+usedAudienceinWebpage+", file/list :"+usedAudienceinFileDef);
			checkAudienceDetailsMap.put("usedAudienceinFileDef", usedAudienceinFileDef);
			checkAudienceDetailsMap.put("usedAudienceinConv", usedAudienceinConv);
			checkAudienceDetailsMap.put("usedAudienceinContent", usedAudienceinContent);
			checkAudienceDetailsMap.put("usedAudienceinWebpage", usedAudienceinWebpage);

		} catch (Exception ex) {
			logger.error("Error occurred while checking audience assocation", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.info("End :: checkAudienceAssocation(audienceID ::" + audienceId);
		return checkAudienceDetailsMap;
	}

}

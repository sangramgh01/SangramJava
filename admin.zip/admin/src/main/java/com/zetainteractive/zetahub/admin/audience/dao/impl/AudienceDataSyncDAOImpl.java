/**
 * AudienceDataSyncDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.dao.AudienceDataSyncDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

/**
 * 
 * @Author : venu.gudibena
 * @Created On : Jun 28, 2016 1:01:51 PM
 * @Version : 1.7
 * @Description : "AudienceDataSyncDAOImpl" is used for get the warehouse datasource id
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class AudienceDataSyncDAOImpl implements AudienceDataSyncDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * Method Name : getWarehouseDataSourceId Description : The Method
	 * "getWarehouseDataSourceId" is used for Date : Jun 28, 2016, 2:43:24 PM
	 * 
	 * @param custcode
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public int getWarehouseDataSourceId(String custCode) throws AudienceException {
		logger.debug("Start :getWarehouseDataSourceId(custcode)");
		int dataSourceId = 0;
		try {
			logger.debug("custCode ::"+custCode);
			String query = "SELECT ID FROM HUB_WH_SOURCE where STATUS = 'A' AND CUSTCODE = '" + custCode + "'";
			logger.info("Query for get warhouse datasource id :: " + query);
			dataSourceId = jdbcTemplate.queryForObject(query, Integer.class);
		} catch (Exception e) {
			logger.error("Error occurred while while fetching warehouse data source id",e);
			throw new AudienceException("E00002", e);
		}
		logger.debug("End  :getWarehouseDataSourceId(custcode)");
		return dataSourceId;
	}

}

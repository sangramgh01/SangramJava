/**
 * AudienceMetaDataDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceMetadataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.rowmapper.PhysicalTableRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 24, 2016 6:31:24 PM
 * @Version : 1.7
 * @Description : "AudienceMetaDataDAOImpl" is used for Physical Tables & columns records persistence
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class AudienceMetadataDAOImpl implements AudienceMetadataDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * Method Name : saveAudienceMetaData Description : The Method
	 * "saveAudienceMetaData" is used for Date : Jun 27, 2016, 12:14:03 PM
	 * 
	 * @param physicalTableBO
	 * @throws AudienceException
	 * @return : Long
	 */
	@Override
	public Long savePhysicalTable(PhysicalTableBO physicalTableBO) throws AudienceException {
		logger.debug("Start : saveAudienceMetaData()");
		String query = "INSERT INTO AUD_PHYSICALTABLE (datasourceid, schemaname, tablename, tabletype, metadata, "
				+ "createdby, updatedby, createdate, updatedate) values (?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";
		ObjectMapper objectMapper = new ObjectMapper();
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
			long phyiscalTableID = 0;
			String findDuplicateTableQuery = "SELECT physicaltableid FROM AUD_PHYSICALTABLE where UPPER(tablename) = ?";
			try 
			{
				phyiscalTableID = jdbcTemplate.queryForObject(findDuplicateTableQuery, Long.class,physicalTableBO.getPhysicalTableName().toUpperCase());
			} catch (Exception e) 
			{
				//Duplicate table ignore
			}
			if(phyiscalTableID > 0)
			{
				logger.warn("Duplicate table found for :"+physicalTableBO.getPhysicalTableName()+" : Ignore");
				return phyiscalTableID;  // If duplicate table name finds
			}
			String jsonPhysicalColumns = objectMapper.writeValueAsString(physicalTableBO.getPhysicalColumns());
			final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
			{
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException
				{
					PreparedStatement pstmt = con.prepareStatement(query,
																   Statement.RETURN_GENERATED_KEYS);
					pstmt.setInt(1,physicalTableBO.getDataSourceId());
					pstmt.setString(2, physicalTableBO.getSchemaName());
					pstmt.setString(3, physicalTableBO.getPhysicalTableName());
					pstmt.setString(4, physicalTableBO.getTableType());
					pstmt.setString(5, jsonPhysicalColumns);
					pstmt.setString(6, physicalTableBO.getCreatedBy());
					pstmt.setString(7, physicalTableBO.getUpdatedBy());
				
					return pstmt;
				}
			};
			jdbcTemplate.update(pstmtCreator,keyHolder);
			logger.info("New table :"+physicalTableBO.getPhysicalTableName()+" : saved.");
			return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
		} catch (Exception ex) {
			logger.error("Error occurred while while saving physical record",ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : updateAudienceMetadata Description : The Method
	 * "updateAudienceMetadata" is used for Date : Jun 27, 2016, 7:04:03 PM
	 * 
	 * @param physicalTableBO
	 * @throws AudienceException
	 */
	@Override
	public Boolean updatePhysicalTable(PhysicalTableBO physicalTableBO) throws AudienceException {
		logger.debug("Start : updatePhysicalTable()");
		String query = "UPDATE AUD_PHYSICALTABLE SET datasourceid= ?, schemaname=?, tabletype=?, metadata=?, "
				+ "updatedby=?,updatedate=utc_timestamp() WHERE physicaltableid = ?";
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			String jsonPhysicalColumns = objectMapper.writeValueAsString(physicalTableBO.getPhysicalColumns());
			Object[] args = new Object[] {physicalTableBO.getDataSourceId(),
					physicalTableBO.getSchemaName(),
					physicalTableBO.getTableType(), 
					jsonPhysicalColumns,
					physicalTableBO.getUpdatedBy(), 
					
					physicalTableBO.getPhysicalTableId() };
			int status = jdbcTemplate.update(query, args);
			if(status !=0){
				logger.debug("Physical Table record updated with id="+physicalTableBO.getPhysicalTableId());
				return true;
			}else {
				logger.debug("No Physical Table found with id="+physicalTableBO.getPhysicalTableId());
				return false;
			}
		} catch (Exception ex) {
			logger.error("Error occurred while while updating physical record",ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : deletePhysicalTable Description : The Method
	 * "deletePhysicalTable" is used for Date : Jun 27, 2016, 7:04:03 PM
	 * 
	 * @param physicalTableId
	 * @throws AudienceException
	 */

	@Override
	public Boolean deletePhysicalTable(Long physicalTableId) throws AudienceException {
		logger.debug("Start : deletePhysicalTable()");
		String query = "DELETE FROM AUD_PHYSICALTABLE WHERE physicaltableid = ?";
		try {
			logger.debug("Physical Table ID ===========>"+physicalTableId);
			int status = jdbcTemplate.update(query, physicalTableId);
			if(status !=0){
				logger.debug("AudienceMetadaata record deleted with id="+physicalTableId);
				return true;
			}else {
				logger.debug("No AudienceMetadaata found deleted id="+physicalTableId);
				return false;
			}
		} catch (Exception ex) {
			logger.error("Error occurred while while deleting physical record",ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : listAudienceMetadata Description : The Method
	 * "listAudienceMetadata" is used for Date : Jun 27, 2016, 7:04:03 PM
	 * 
	 * @return List<PhysicalTableBO>
	 * @throws AudienceException
	 */
	@Override
	public List<PhysicalTableBO> listPhysicalTables() throws AudienceException {
		logger.debug("Start : listPhysicalTables()");
		List<PhysicalTableBO> physicalTableBOList = null;
		String query = "SELECT * FROM AUD_PHYSICALTABLE";
		try {
			physicalTableBOList = jdbcTemplate.query(query, new PhysicalTableRowMapper());
			if(physicalTableBOList!= null && physicalTableBOList.size() == 0){
				throw new AudienceException("AU0046");
			}
		} catch (EmptyResultDataAccessException etdae) {
			return physicalTableBOList;
		}catch (Exception ex) {
			logger.error("Error occurred while while fetching physical table records",ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends :: listPhysicalTables()");
		return physicalTableBOList;
	}
	
	
	/**
	 * List physical tables.
	 *
	 * @param tableType the table type
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	@Override
	public List<PhysicalTableBO> listPhysicalTablesByTableType(String tableType) throws AudienceException {
		logger.debug("Start :: listPhysicalTablesByTableType()");
		List<PhysicalTableBO> physicalTableBOList = null;
		String query = "SELECT * FROM AUD_PHYSICALTABLE WHERE TABLETYPE=?";
		try {
			logger.debug("Physical Table Type ======>"+tableType);
			Object[] args = new Object[] {tableType};
			physicalTableBOList = jdbcTemplate.query(query, args, new PhysicalTableRowMapper());
		} catch (EmptyResultDataAccessException etdae) {
			logger.error("No records found with provided physical table type="+tableType);
			return physicalTableBOList;
		}catch (Exception ex) {
			logger.error("Error occurred while while fetching physical table records",ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : listPhysicalTablesByTableType()");
		return physicalTableBOList;
	}
	
	/**
	 * 
	 * Method Name 	: findAudienceMetadata
	 * Description 		: The Method "findAudienceMetadata" is used for 
	 * Date    			: Jul 2, 2016, 12:47:45 PM
	 * @param physicalTableIdSet
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	public List<PhysicalTableBO> findPhysicalTables(Set<Long> physicalTableIdSet,boolean isDimension) throws AudienceException {
		logger.debug("Start : findPhysicalTables(physicalTableIdSet)");
		List<PhysicalTableBO> physicalTableBOList = null;
		try {
			String ids = StringUtils.join(physicalTableIdSet, ',');
			String query = "SELECT * FROM AUD_PHYSICALTABLE WHERE" + (isDimension ? "":" PHYSICALTABLEID NOT IN ("+ids+") AND ")+ " tabletype !='STAGING'";//PHYSICALTABLEID NOT IN ("+ids+") AND
			logger.debug("Physictal Table IDs:"+ids);
			physicalTableBOList = jdbcTemplate.query(query,  new PhysicalTableRowMapper());
		} catch (EmptyResultDataAccessException etdae) {
			etdae.printStackTrace();
			logger.error("No records found with provided physical table ID's="+physicalTableIdSet);
			return physicalTableBOList;
		}catch (Exception ex) {
			logger.error("Error occurred while while fetching physical table records",ex);
			throw new AudienceException("E00002", ex);
		}
		return physicalTableBOList;
		
	}
	
	/**
	 * Method Name 	: findAudienceMetadata
	 * Description 		: The Method "findAudienceMetadata" is used for 
	 * Date    			: May 12, 2017
	 * @param physicalTableIdSet
	 * @return 
	 * @throws AudienceException
	 */
	@Override
	public Map<Long, PhysicalTableBO> findPhysicalTablesByIds(Set<Long> physicalTableIdSet) throws AudienceException {
		logger.info("Begin : findPhysicalTablesByIds(physicalTableIdSet)");
		List<PhysicalTableBO> physicalTableBOList = null;
		Map<Long, PhysicalTableBO> physicalTableBOMap = new HashMap<>();
		try {
			String ids = StringUtils.join(physicalTableIdSet, ',');
			logger.debug("Physictal Table IDs:"+ids);
			String query = "SELECT * FROM AUD_PHYSICALTABLE WHERE PHYSICALTABLEID IN ("+ids+")";
			physicalTableBOList = jdbcTemplate.query(query,new PhysicalTableRowMapper());
			
			for (PhysicalTableBO physicalTableBO : physicalTableBOList) {
				physicalTableBOMap.put(physicalTableBO.getPhysicalTableId(), physicalTableBO);
			}
		} catch (EmptyResultDataAccessException etdae) {
			etdae.printStackTrace();
			logger.error("Exception occured : "+physicalTableIdSet,etdae);
			return physicalTableBOMap;
		}catch (Exception ex) {
			logger.error("Exception occured : "+physicalTableIdSet,ex);
			throw new AudienceException("E00002", ex);
		}
		logger.info("End : findPhysicalTablesByIds(physicalTableIdSet)");
		return physicalTableBOMap;
	}

	/**
	 * 
	 * Method Name 	: findAudienceMetadataById
	 * Description 		: The Method "findAudienceMetadataById" is used for 
	 * Date    			: Jun 28, 2016, 4:07:54 PM
	 * @param physicalTableId
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	public PhysicalTableBO findPhysicalTableById(Long physicalTableId) throws AudienceException {
		logger.debug("Start : findPhysicalTableById()");
		PhysicalTableBO physicalTableBO = null;
		String query = "SELECT physicaltableid, datasourceid, schemaname, tablename, tabletype, metadata, createdby, "
				+ "updatedby, createdate, updatedate FROM AUD_PHYSICALTABLE where physicaltableid =?";
		try {
			logger.debug("Physical Table ID=================>" + physicalTableId);
			Object[] args = new Object[] { physicalTableId };
			physicalTableBO = jdbcTemplate.queryForObject(query, args, new PhysicalTableRowMapper());
		} catch (EmptyResultDataAccessException etdae) {
			logger.warn("No records found with provided physical table ID ="+physicalTableId);
			return physicalTableBO;
		} catch (IncorrectResultSizeDataAccessException irsdae) {
			logger.error("Incorrect audience result size: expected 1, actual more", irsdae);
			throw new AudienceException("AU0044", irsdae);
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching physical table records", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findPhysicalTableById()");
		return physicalTableBO;
	}

	/**
	 * 
	 * Method Name 	: findAudienceMetadataByName
	 * Description 		: The Method "findAudienceMetadataByName" is used for 
	 * Date    			: Jun 29, 2016, 5:48:14 PM
	 * @param physicalTableName
	 * @return PhysicalTableBO
	 * @throws AudienceException
	 */
	@Override
	public PhysicalTableBO findPhysicalTableByName(String physicalTableName) throws AudienceException {
		logger.debug("Start : findPhysicalTableByName()");
		PhysicalTableBO physicalTableBO = null;
		String query = "SELECT physicaltableid, datasourceid, schemaname, tablename, tabletype, metadata,"
				+ " createdby, updatedby, createdate, updatedate FROM AUD_PHYSICALTABLE where UPPER(tablename) = ?";
		try {
			logger.debug("PhysicalTableName============>"+physicalTableName);
			Object[] args = new Object[] {physicalTableName.trim().toUpperCase()};
			physicalTableBO = jdbcTemplate.queryForObject(query, args, new PhysicalTableRowMapper());
		} catch (EmptyResultDataAccessException etdae) {
			logger.warn("No records found with provided physical table name ="+physicalTableName);
			return physicalTableBO;
		}catch(IncorrectResultSizeDataAccessException irsdae){
			logger.error("Incorrect audience result size: expected 1, actual more",irsdae);
			throw new AudienceException("AU0044", irsdae);
		}catch (Exception ex) {
			logger.error("Error occurred while while fetching physical table record", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends : findPhysicalTableByName()");
		return physicalTableBO;
	}

	/**
	 * 
	 * Method Name 	: findAudienceMetadataByName
	 * Description 		: The Method "findAudienceMetadataByName" is used for 
	 * Date    			: Jun 29, 2016, 5:48:14 PM
	 * @param physicalTableName
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	public Long getPhysicalTableId(String physicalTableName) throws AudienceException {
		logger.debug("Start : getPhysicalTableId()");
		long id = 0;
		logger.debug("PhysicalTableName=========>"+physicalTableName);
		PhysicalTableBO physicalTableBO = findPhysicalTableByName(physicalTableName);
		if(physicalTableBO != null && physicalTableBO.getPhysicalTableId() != 0){
			id = physicalTableBO.getPhysicalTableId();
		}
		logger.debug("End : getPhysicalTableId()");
		return id;
	}
}

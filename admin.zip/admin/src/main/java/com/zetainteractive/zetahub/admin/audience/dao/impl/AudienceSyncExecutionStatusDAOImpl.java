/**
 * AudienceSyncExecutionStatusDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.dao.AudienceSyncExecutionStatusDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.rowmapper.AudienceSyncExecutionStatusRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.DataSyncExecutionStatusBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 28, 2016 2:22:40 PM
 * @Version : 1.7
 * @Description : "AudienceSyncExecutionStatusDAOImpl" is used for Audience sync
 *              execution status tracking persistence
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class AudienceSyncExecutionStatusDAOImpl implements AudienceSyncExecutionStatusDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * Method Name : saveSyncExecutionStatus Description : The Method
	 * "saveSyncExecutionStatus" is used for Date : Jun 28, 2016, 2:23:07 PM
	 * 
	 * @param syncExecBO
	 * @throws AudienceException
	 * @return : Long
	 * @throws :
	 */

	@Override
	public Long saveSyncExecutionStatus(DataSyncExecutionStatusBO syncExecBO) throws AudienceException {
		logger.debug("Start :: saveSyncExecutionStatus()");
		String query = "INSERT INTO AUD_DATASOURCE_SYNC ( datasourceid,datasourcesyncstatus,profilesyncstatus,datasourcelastsyncdate,profilecolumnlastsyncdate) "
				+ "VALUES (?,?,?,?,?)";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		try {
			final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
			{
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException
				{
					PreparedStatement pstmt = con.prepareStatement(query,
																   Statement.RETURN_GENERATED_KEYS);
					pstmt.setInt(1,syncExecBO.getDataSourceId());
					pstmt.setString(2, String.valueOf(syncExecBO.getDataSourceSyncStatus()));
					pstmt.setString(3, String.valueOf(syncExecBO.getProfileSyncStatus()));
					pstmt.setTimestamp(4, syncExecBO.getDataSourceLastSyncDate() != null ? currentTime : null );
					pstmt.setTimestamp(5, syncExecBO.getProfileColumnLastSyncDate() != null ? currentTime: null );
					return pstmt;
				}
			};
			jdbcTemplate.update(pstmtCreator,keyHolder);
			return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
		} catch (Exception ex) {
			logger.error("Error occurred while while saving sync execution record", ex);
			ex.printStackTrace();
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : updateSyncExecutionStatus Description : The Method
	 * "updateSyncExecutionStatus" is used for Date : Jun 28, 2016, 2:23:07 PM
	 * 
	 * @param syncExecBO
	 * @return : Boolean
	 * @throws AudienceException
	 */

	@Override
	public Boolean updateSyncExecutionStatus(DataSyncExecutionStatusBO syncExecBO) throws AudienceException {
		logger.debug("Start :: updateSyncExecutionStatus()");
		String query = "UPDATE AUD_DATASOURCE_SYNC SET dataSourceId =?, dataSourceLastSyncDate=?,profileColumnLastSyncDate =?, dataSourceSyncStatus=? ,profilesyncstatus=? WHERE  datasourcesyncid = ?";
		try {
			Object[] args = new Object[] { 
					syncExecBO.getDataSourceId(), 
					syncExecBO.getDataSourceLastSyncDate(),
					syncExecBO.getProfileColumnLastSyncDate(), 
					String.valueOf(syncExecBO.getDataSourceSyncStatus()),
					String.valueOf(syncExecBO.getProfileSyncStatus()), 
					syncExecBO.getDataSyncStatusId() };
			int status = jdbcTemplate.update(query, args);
			if (status != 0) {
				logger.debug("Data sync execution status record updated with id=" + syncExecBO.getDataSyncStatusId());
				return true;
			} else {
				logger.debug("No Data sync execution status record found  id=" + syncExecBO.getDataSyncStatusId());
				return false;
			}
		} catch (Exception ex) {
			logger.error("Error occurred while while updating sync execution record", ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : findSyncExecutionStatus Description : The Method
	 * "findSyncExecutionStatus" is used for Date : Jun 28, 2016, 2:23:07 PM
	 * 
	 * @param syncId
	 * @throws AudienceException
	 * @return : DataSyncExecutionStatusBO
	 */

	@Override
	public DataSyncExecutionStatusBO findSyncExecutionStatus(Long syncId) throws AudienceException {
		logger.debug("Start :: findSyncExecutionStatus()");
		String query = "SELECT * FROM AUD_DATASOURCE_SYNC WHERE dataSyncStatusId = ?";
		DataSyncExecutionStatusBO syncObj = null;
		try {
			logger.debug("DataSyncId:" + syncId);
			syncObj = (DataSyncExecutionStatusBO) jdbcTemplate.queryForObject(query, new Object[] { syncId },
					new BeanPropertyRowMapper<DataSyncExecutionStatusBO>(DataSyncExecutionStatusBO.class));
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching sync execution record", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends :: findSyncExecutionStatus()");
		return syncObj;

	}

	/**
	 * 
	 * Method Name : deleteSyncExecutionStatus Description : The Method
	 * "deleteSyncExecutionStatus" is used for Date : Jun 28, 2016, 2:23:07 PM
	 * 
	 * @param syncId
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public Boolean deleteSyncExecutionStatus(Long syncId) throws AudienceException {
		logger.debug("Start :: deleteSyncExecutionStatus()");
		String query = "DELETE FROM AUD_DATASOURCE_SYNC WHERE  dataSyncStatusId = ?)";
		try {
			logger.debug("DataSyncStatusExecutionID:" + syncId);
			int status = jdbcTemplate.update(query, syncId);
			if (status != 0) {
				logger.debug("Data sync execution status record deleted with id=" + syncId);
				return true;
			} else {
				logger.debug("No Data sync execution status record found deleted id=" + syncId);
				return false;
			}
		} catch (Exception ex) {
			logger.error("Error occurred while while deleting sync execution record", ex);
			throw new AudienceException("E00002", ex);
		}

	}

	/**
	 * 
	 * Method Name : findSyncExecutionStatusByDataSource Description : The
	 * Method "findSyncExecutionStatusByDataSource" is used for Date : Jun 29,
	 * 2016, 6:57:52 PM
	 * 
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */
	@Override
	public DataSyncExecutionStatusBO findSyncExecutionStatusByDataSource(int dataSourceId) throws AudienceException {
		logger.debug("Start  :: findSyncExecutionStatusByDataSource(dataSourceId)");
		String query = "SELECT * FROM AUD_DATASOURCE_SYNC WHERE datasourceId = ?";
		DataSyncExecutionStatusBO syncObj = null;
		try {
			logger.debug("Data source ID ======>"+dataSourceId);
			logger.debug("Query for sync execution status info :" + query + " data source id :: " + dataSourceId);
			syncObj = (DataSyncExecutionStatusBO) jdbcTemplate.queryForObject(query, new Object[] { dataSourceId },
					new AudienceSyncExecutionStatusRowMapper());
		} catch(EmptyResultDataAccessException erdae){
			logger.info("Data sync execution record not found. Creating new entry.");
		}
		catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Error occurred while while fetching sync execution record", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends :: findSyncExecutionStatusByDataSource(dataSourceId)");
		return syncObj;
	}

	/**
	 * 
	 * Method Name : getDataSourceSyncStatus Description : The Method
	 * "getDataSourceSyncStatus" is used for Date : Jun 28, 2016, 2:54:15 PM
	 * 
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public char getDataSourceSyncStatus(int dataSourceId) throws AudienceException {
		logger.debug("Start :: getDataSourceSyncInfo(dataSourceId)");
		char syncStatus = ' ';
		DataSyncExecutionStatusBO dataSyncExecutionStatusBO = findSyncExecutionStatusByDataSource(dataSourceId);
		if(dataSyncExecutionStatusBO!= null) {
		  syncStatus = dataSyncExecutionStatusBO.getDataSourceSyncStatus();
		}
		logger.debug("End :: getDataSourceSyncInfo(dataSourceId)");
		return syncStatus;
	}
	
	/**
	 * 
	 * Method Name : getDataSourceSyncStatus Description : The Method
	 * "getDataSourceSyncStatus" is used for Date : Jun 28, 2016, 2:54:15 PM
	 * 
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public char getProfileSyncStatus(int dataSourceId) throws AudienceException {
		logger.debug("Start :: getProfileSyncStatus(dataSourceId)");
		char syncStatus = ' ';
		try {
			logger.debug("dataSourceId =============>" + dataSourceId);
			DataSyncExecutionStatusBO dataSyncExecutionStatusBO = findSyncExecutionStatusByDataSource(dataSourceId);
			syncStatus = dataSyncExecutionStatusBO.getProfileSyncStatus();
		} catch (EmptyResultDataAccessException erdae) {
			logger.error("Incorrect result size: expected 1, actual 0", erdae);
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching profile sync status", ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("End :: getProfileSyncStatus(dataSourceId)");
		return syncStatus;
	}
}

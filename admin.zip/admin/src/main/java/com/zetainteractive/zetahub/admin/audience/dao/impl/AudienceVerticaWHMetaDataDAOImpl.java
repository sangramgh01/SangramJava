/**
 * AudienceWarehouseMetaDataDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceWarehouseMetaDataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ColumnStatCountBO;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.commons.enums.TemplateCodes;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * 
 * @Author : venu.gudibena
 * @Created On : Jun 28, 2016 5:51:45 PM
 * @Version : 1.7
 * @Description : "AudienceWarehouseMetaDataDAOImpl" is used for
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class AudienceVerticaWHMetaDataDAOImpl implements AudienceWarehouseMetaDataDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("whJdbc")
	private JdbcTemplate whJdbcTemplate;
	
	private RestRequestHandler restHandler = new RestRequestHandler();

	/**
	 * 
	 * 
	 * Method Name : getAudiencePhysicalTableMetaData Description : The Method
	 * "getAudiencePhysicalTableMetaData" is used for Date : Jun 29, 2016,
	 * 11:55:53 AM
	 * 
	 * @param dataSourceId
	 * @param schemaName
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : List<PhysicalTableBO>
	 * @throws :
	 */
	public List<PhysicalTableBO> getAudiencePhysicalTableMetaData(int dataSourceId, String schemaName, String userName)
			throws AudienceException {
		logger.debug("Begin: getAudiencePhysicalTableMetaData()");
		List<PhysicalTableBO> physicalTableBOs = new ArrayList<>();
		try {
			physicalTableBOs.addAll(getTableMetaData(dataSourceId, schemaName, userName));
			physicalTableBOs.addAll(getViewMetaData(dataSourceId, schemaName, userName));
		} catch (AudienceException e) {
			logger.error("Error occured while fetching table and meta info", e);
             throw e;
		}
		logger.debug("End: getAudiencePhysicalTableMetaData()");
		return physicalTableBOs;
	}

	/**
	 * 
	 * 
	 * Method Name : getTableMetaData Description : The Method
	 * "getTableMetaData" is used for Date : Jun 29, 2016, 11:56:00 AM
	 * 
	 * @param dataSourceId
	 * @param schemaName
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : List<PhysicalTableBO>
	 * @throws :
	 */
	public List<PhysicalTableBO> getTableMetaData(int dataSourceId, String schemaName, String userName) throws AudienceException {
		logger.info("Begin: getTableMetaData(dataSourceId :"+dataSourceId+",schemaName :"+schemaName+",userName :"+userName+")");
		PhysicalTableBO physicalTableBO = null;
		PhysicalColumnBO physicalColumnBO = null;
		Map<String, PhysicalTableBO> tablesMap = null;
		Integer dataSize = 0;
		try {
			tablesMap = new HashMap<>();
			// Begin :: Get all tables info from vertica
			String query = "SELECT t.TABLE_SCHEMA,t.TABLE_NAME,c.COLUMN_NAME,c.IS_NULLABLE,c.COLUMN_DEFAULT,c.CHARACTER_MAXIMUM_LENGTH,c.DATA_TYPE_ID,c.NUMERIC_SCALE FROM v_catalog.tables AS t,v_catalog.columns AS c WHERE t.TABLE_SCHEMA ='"
					+ schemaName + "' AND c.TABLE_SCHEMA='" + schemaName
					+ "' AND t.TABLE_SCHEMA=c.TABLE_SCHEMA AND t.TABLE_NAME =c.TABLE_NAME AND t.IS_SYSTEM_TABLE=false AND t.IS_TEMP_TABLE=false AND "
					+ notIncludedTables("t.TABLE_NAME", "TABLE") + " ORDER BY t.TABLE_NAME";
			logger.info("Vertica db meta information query for getting tables :: " + query);
			whJdbcTemplate.setFetchSize(200);
			List<Map<String, Object>> rows = whJdbcTemplate.queryForList(query);
			//List<String> stagingTablesList = new ArrayList<>();
			for (Map<String, Object> map : rows) {
				String tableName = map.get("TABLE_NAME").toString();
				if (!tablesMap.containsKey(tableName)) {
					logger.info("TABLE :: " + tableName);
					physicalTableBO = new PhysicalTableBO();
					physicalTableBO.setSchemaName(map.get("TABLE_SCHEMA").toString());
					physicalTableBO.setPhysicalTableName(tableName);
					physicalTableBO.setDataSourceId(dataSourceId);
					physicalTableBO.setTableType("TABLE");
					physicalTableBO.setPhysicalColumns(new ArrayList<>());
					physicalTableBO.setCreatedBy(userName);  
					physicalTableBO.setUpdatedBy(userName);  
					tablesMap.put(tableName, physicalTableBO);
				}

				logger.debug("Physical Column " + map.get("COLUMN_NAME").toString() + " preparation start for table "
						+ tableName);
				physicalColumnBO = new PhysicalColumnBO();
				if(map.get("CHARACTER_MAXIMUM_LENGTH") != null) {
				   dataSize = Integer.parseInt(map.get("CHARACTER_MAXIMUM_LENGTH").toString());
				}
				if (dataSize != 0 && dataSize != null) {
					physicalColumnBO.setColumnDataLength(dataSize);
				} else {
					physicalColumnBO.setColumnDataLength(400);
				}
				
				String physicalColumnName = map.get("COLUMN_NAME").toString();
				physicalColumnBO.setPhysicalColumnName(physicalColumnName);
				
				if(physicalColumnName.equalsIgnoreCase("BATCH_ID")  || physicalColumnName.equalsIgnoreCase("SRC_FILE_ID") ){
					tablesMap.get(tableName).setTableType("STAGING");
					//stagingTablesList.add(tableName);
				}
				
				if(Boolean.parseBoolean(map.get("IS_NULLABLE").toString()))	 {
				    physicalColumnBO.setIsNullable(Constants.YES);
				}
				physicalColumnBO.setOleDbtype("0");
				int scale = 0 ;
				if(map.get("NUMERIC_SCALE") != null) {
				   scale = (int) (long) map.get("NUMERIC_SCALE");
				}
				
				int dataTypeId = (int) (long) map.get("DATA_TYPE_ID");
				if(dataTypeId == 16 && scale == 0){
					dataTypeId = 6; // BigInteger
				}
				physicalColumnBO
						.setColumnDataType(Constants.getDataTypeForVerticadb(dataTypeId ));
				physicalTableBO.getPhysicalColumns().add(physicalColumnBO);
				
				Object obj = map.get("COLUMN_DEFAULT");
				if (obj != null && obj.toString().length() > 0) {
					String defaultValue = obj.toString();
					defaultValue = defaultValue
							.replaceAll("::(?i)(date|timestamp|time|boolean|timetz|int|float|timestamptz)", "");
					if(physicalColumnBO.getColumnDataType() == 10){
						defaultValue = defaultValue.replaceAll("'", "");
					}
					physicalColumnBO.setColumnDefaultValue(defaultValue);
				}
			}
			
			// End :: Get all tables info from vertica
		} catch (Exception e) {
			logger.error("Error occured while fetching TABLE and COLUMN info", e);
			throw new AudienceException("AU0015", e);
		}
		logger.info("Ends : getTableMetaData()");
		return new ArrayList<>(tablesMap.values());
	}

	/**
	 * 
	 * 
	 * Method Name : getViewMetaData Description : The Method "getViewMetaData"
	 * is used for Date : Jun 29, 2016, 11:56:08 AM
	 * 
	 * @param dataSourceId
	 * @param schemaName
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : List<PhysicalTableBO>
	 * @throws :
	 */
	public List<PhysicalTableBO> getViewMetaData(int dataSourceId, String schemaName,String userName) throws AudienceException {
		logger.info("Begin: getViewMetaData( dataSourceId :"+dataSourceId+",schemaName :"+schemaName+",userName :"+userName+")");
		PhysicalTableBO physicalTableBO = null;
		Map<String, PhysicalTableBO> tablesMap = null;
		Integer dataSize = 0;
		try {
			tablesMap = new HashMap<>();
			// Begin :: Get all views info from vertica
			String query = "SELECT t.TABLE_SCHEMA,t.TABLE_NAME,c.COLUMN_NAME,c.CHARACTER_MAXIMUM_LENGTH,c.DATA_TYPE_ID,c.NUMERIC_SCALE FROM v_catalog.views AS t,v_catalog.view_columns AS c WHERE t.TABLE_SCHEMA ='"
					+ schemaName + "' AND c.TABLE_SCHEMA='" + schemaName
					+ "' AND t.TABLE_SCHEMA=c.TABLE_SCHEMA AND t.TABLE_NAME=c.TABLE_NAME AND t.IS_SYSTEM_VIEW=false AND  "
					+ notIncludedTables("t.TABLE_NAME", "VIEW") + " ORDER BY t.TABLE_NAME";
			logger.info("Vertica db meta information query for getting views  :: " + query);
			whJdbcTemplate.setFetchSize(200);
			List<Map<String, Object>> rows = whJdbcTemplate.queryForList(query);
			for (Map<String, Object> map : rows) {
				String viewName = map.get("TABLE_NAME").toString();
				if (!tablesMap.containsKey(viewName)) {
					logger.info("VIEW :: " + viewName);
					physicalTableBO = new PhysicalTableBO();
					physicalTableBO.setSchemaName(map.get("TABLE_SCHEMA").toString());
					physicalTableBO.setPhysicalTableName(viewName);
					physicalTableBO.setDataSourceId(dataSourceId);
					physicalTableBO.setTableType("VIEW");
					physicalTableBO.setPhysicalColumns(new ArrayList<>());
					physicalTableBO.setCreatedBy(userName);  
					physicalTableBO.setUpdatedBy(userName);  
					tablesMap.put(viewName, physicalTableBO);
				}
				logger.debug("Preparing columns list for table " + viewName);
				PhysicalColumnBO physicalColumnBO = new PhysicalColumnBO();
				if(map.get("CHARACTER_MAXIMUM_LENGTH")!= null) {
					dataSize = Integer.parseInt(map.get("CHARACTER_MAXIMUM_LENGTH").toString());
				}
				if (dataSize != 0 && dataSize != null) {
					physicalColumnBO.setColumnDataLength(dataSize);
				} else {
					physicalColumnBO.setColumnDataLength(400);
				}
				physicalColumnBO.setPhysicalColumnName(map.get("COLUMN_NAME").toString());
				physicalColumnBO.setIsNullable(Constants.NO);
				physicalColumnBO.setColumnDefaultValue(null);
				physicalColumnBO.setOleDbtype("0");
				int scale = 0;
				if (map.get("NUMERIC_SCALE") != null) {
					scale = (int) (long) map.get("NUMERIC_SCALE");
				}
				int dataTypeId = (int) (long) map.get("DATA_TYPE_ID");
				if (dataTypeId == 16 && scale == 0) {
					dataTypeId = 6; // BigInteger
				}
				physicalColumnBO
						.setColumnDataType(Constants.getDataTypeForVerticadb(dataTypeId));
				physicalTableBO.getPhysicalColumns().add(physicalColumnBO);
			}
			// End :: Get all views info from vertica
		} catch (Exception e) {
			logger.error("Error occured while fetching VIEW and COLUMN info", e);
			throw new AudienceException("AU0015", e);
		}
		logger.info("Ends : getViewMetaData()");
		return new ArrayList<>(tablesMap.values());
	}

	/**
	 * Not included tables.
	 *
	 * @param columnName the column name
	 * @param type the type
	 * @return the string
	 */
	private String notIncludedTables(String columnName, String type) {
		String retValue = "";    // JIRA ticket reference ZHPE-13330
		String[] restrictedTableNames = { "'TARGET'", "'ADDRESS'", "'AUDIENCE_MEMBER'","'ADDRESS_EMAIL'","'ADDRESS_SMS'","'DOMAIN_OPTOUT_RULES'" };
		String[] restrictedTableNamesLike = { "'ADDRESS\\_%'", "'S\\_%'", "'%\\_BKUP'", "'WRK\\_%'", "'TEMP\\_%'",
				"'ADHOC\\_%'","'DATA\\_IMPORT\\_STAGING\\_TEMP\\_%'","'MVT\\_Email\\_CHANNELED\\_%'","'SAVE\\_SEGMENT\\_CHANNELED\\_%'",
				"'tmp\\_tVerticaBulkExec\\_%'","'RV\\_%'","'PMTA\\_RV\\_%'", "'%\\_TEMP'"};
		String[] restrictedViewNamesLike = {"'S\\_%'", "'%\\_BKUP'","'TEMP\\_%'","'SAVE_SEGMENT\\_%'",
				"'DATA\\_IMPORT\\_STAGING\\_TEMP\\_%'","'MVT\\_Email\\_CHANNELED\\_%'","'SAVE\\_SEGMENT\\_CHANNELED\\_%'",
				"'tmp\\_tVerticaBulkExec\\_%'","'RV\\_%'","'PMTA\\_RV\\_%'", "'%\\_TEMP'" };
		if (type.equalsIgnoreCase("TABLE")) {
			for (String tableNameLike : restrictedTableNamesLike) {
				retValue = retValue + columnName + " NOT LIKE " + tableNameLike + " AND ";
			}
			for (String tableName : restrictedTableNames) {
				retValue = retValue + columnName + " <> " + tableName + " AND ";
			}
		} else if (type.equalsIgnoreCase("VIEW")) {
			for (String viewNameLike : restrictedViewNamesLike) {
				retValue = retValue + columnName + " NOT LIKE " + viewNameLike + " AND ";
			}
		}
		retValue = retValue.substring(0, retValue.lastIndexOf(" AND "));
		return retValue;
	}
	
	
	/**
	 * 
	 * Method Name 	: getProfileableColumnValues
	 * Description 		: The Method "getProfileableColumnValues" is used for 
	 * Date    			: Aug 4, 2016, 3:13:55 PM
	 * @param profileColumnsMap
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	public Map<String, List<PhysicalColumnBO>> getProfileableColumnValues(Map<String,List<PhysicalColumnBO>> profileColumnsMap) throws AudienceException {
		logger.debug("Begin: getProfileableColumnValues()");
		try {

			Set<String> tableNames = profileColumnsMap.keySet();
			
			for (String tableName : tableNames) {
				List<PhysicalColumnBO> columns = profileColumnsMap.get(tableName);
				for (PhysicalColumnBO physicalColumnBO : columns) {
					try {
						String query  = "select %COLUMNNAME% as columnValue, count(*) as count from %TABLENAME% group by %COLUMNNAME% ORDER BY %COLUMNNAME% limit "+(ZetaUtil.getHelper().getConfig().getConfigValueInt("profile-column-max-count", 2500)+1) ;
						//Added +1 to max profile fetch count, to indicate few more left from fetch
						query = StringUtils.replace(query, "%COLUMNNAME%", physicalColumnBO.getPhysicalColumnName());
						query = StringUtils.replace(query, "%TABLENAME%", tableName);
						logger.debug(query);
						List<Map<String, Object>> rows = whJdbcTemplate.queryForList(query);
						List<ColumnStatCountBO> statsDetails = new ArrayList<>();
						logger.info(tableName + " : " + physicalColumnBO.getPhysicalColumnName());
						for (Map<String, Object> map : rows) {
							ColumnStatCountBO columnStatCountBO = new ColumnStatCountBO();
							columnStatCountBO.setStatCount(Integer.parseInt(map.get("count").toString()));
							if(map.get("columnValue") != null) {
							   columnStatCountBO.setStatValue(map.get("columnValue").toString());
							}else{
								columnStatCountBO.setStatValue("");
							}
							statsDetails.add(columnStatCountBO);
							if (columnStatCountBO.getStatCount() > 0) {
								logger.info("statValue :" + columnStatCountBO.getStatValue() + " : statCount :"
										+ columnStatCountBO.getStatCount());
							}
						}
						physicalColumnBO.setColumnStatCounts(statsDetails);
						if(rows.size()>ZetaUtil.getHelper().getConfig().getConfigValueInt("profile-column-max-count", 2500))
						{
							//Send notification mail..
							logger.info("Sending notification mail for exceeding max profile column fetch count for column:"+physicalColumnBO.getPhysicalColumnName()+",table name:"+tableName);
							sendNotificationMail(physicalColumnBO.getPhysicalColumnName(),tableName);
						}
					} catch (Exception e) {
						if (e instanceof com.vertica.support.exceptions.SyntaxErrorException
								|| e instanceof org.springframework.jdbc.BadSqlGrammarException) {
							logger.error("Relation :" + tableName + " does not exist in WarehouseDB");
						} else {
							logger.error("Unknown exception ::",e);
						}
					}
					
				}
			}
		}catch (Exception e) {
			logger.error("Error occured while getting Profileable Column values",e);
			throw new AudienceException("AU0027", e);
		}
		logger.info("Ends: getProfileableColumnValues()");
		return profileColumnsMap;
	}
	private void sendNotificationMail(String physicalColumnName,String whTableName)
	{
		try
		{
			NotificationInputBO notificationInputBO=prepareAudienceNotifcationInput(physicalColumnName,whTableName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(notificationInputBO);
			//
			restHandler.exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/notifications/sendnotification",HttpMethod.POST,entity,Object.class);
		} catch (Exception e)
		{
			logger.error("Exception occured while sending notification mail",e);
		}
	}
	private String getCurrentDateUTC()
	{
		TimeZone tz=TimeZone.getTimeZone("UTC");
		DateFormat df =DateFormat.getDateTimeInstance(
                DateFormat.FULL, 
                DateFormat.FULL, 
                Locale.ENGLISH);
		df.setTimeZone(tz);
		return df.format(new Date());
	}
	private NotificationInputBO prepareAudienceNotifcationInput(String physicalColumnName,String whTableName) throws Exception {
		NotificationInputBO notificationInputBO=new NotificationInputBO();
		notificationInputBO.setTemplateCode(TemplateCodes.AUDIENCE_WARNING.getValue());
		Map<String,String> templateValues = new HashMap<>();
		templateValues.put("status", "Completed");
		templateValues.put("completedon", getCurrentDateUTC());
		int allowedLimit = ZetaUtil.getHelper().getConfig().getConfigValueInt("profile-column-max-count", 2500);
		String msg ="While running a profile sync to populate a dropdown with available values, the attribute '"+physicalColumnName+"' returned more values than allowed (current number of values allowed:"+allowedLimit+" ). "
				+ "Please note that only "+allowedLimit+" values will be displayed to the user in the dropdown. "
						+ "Additional values may still be typed in. Allowed number of displayed values may be increased up to 2500 in Settings.";
		templateValues.put("message",msg);
		templateValues.put("type","Audience");
		templateValues.put("customercode",ZetaUtil.getHelper().getCustomerID());
		templateValues.put("modulename","audience");
		templateValues.put("columnname",physicalColumnName);
		templateValues.put("tablename",whTableName);
		notificationInputBO.setTemplateValues(templateValues);
		notificationInputBO.setEmailAdresses(ZetaUtil.getHelper().getUser().getEmailID());
		return notificationInputBO;	
	}
	
	/**
	 * 
	 * Method Name 	: isTableNameExist
	 * Description 		: The Method "isTableNameExist" is used for 
	 * Date    			: May 22, 2017, 2:55:20 PM
	 * @param tableName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	public boolean isTableNameExist(String tableName) throws AudienceException {
		logger.debug("Begin: isTableNameExist(tableName :"+tableName+")");
		try {
			// Begin :: Get all views info from vertica
			String query = "SELECT table_name FROM v_catalog.tables WHERE table_name = ?";
			logger.debug("Vertica db isTableNameExist   :: " + query);
			List<String> list = whJdbcTemplate.queryForList(query,new Object[]{tableName},String.class);
			if(list.size() > 0) return true;
			else return false;
		} catch (Exception e) {
			logger.error("Error occured while fetching table name::", e);
			return false;
		}
		
	}
	
	/**
	 * 
	 * Method Name 	: getEmailDataByTableName
	 * Description 		: The Method "getEmailDataByTableName" is used for 
	 * Date    			: May 22, 2017, 2:55:25 PM
	 * @param tableName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	public List<String> getEmailDataByTableName(String tableName) throws AudienceException{
		try {
			logger.debug("Begin: getEmailDataByTableName(tableName :"+tableName+")");
			String query = "SELECT EMAIL_ADDRESS FROM "+tableName;
			logger.info("Begin: query to get emails list ::"+query);
			return whJdbcTemplate.queryForList(query,String.class);
		} catch (Exception e) {
			logger.error("Exception occurred ::",e);
			throw new AudienceException("Exception occured while getting email data by table name :: ", e); 
		}
	}
	
	
	/**
	 * 
	 * Method Name 	: getTableColumns
	 * Description 		: The Method "getTableColumns" is used for 
	 * Date    			: May 22, 2017, 2:55:30 PM
	 * @param tableName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	public List<CustomColumnDefinitionBO> getTableColumns(String tableName)throws AudienceException{
		try {
			return whJdbcTemplate.query("select column_name,is_nullable from columns where TABLE_NAME = ?",new RowMapper<CustomColumnDefinitionBO>() {
				@Override
				public CustomColumnDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
					CustomColumnDefinitionBO bo = new CustomColumnDefinitionBO();
					bo.setPhysicalColumnName(rs.getString("column_name"));
					bo.setIsNullable(rs.getBoolean("is_nullable")?'N':'Y');
					return bo;
				}
			},tableName);
		} catch (Exception e) {
			logger.error("Exception occurred ::",e);
			throw new AudienceException("Exception occured while getTableColumns :: ", e); 
		}
	}
}

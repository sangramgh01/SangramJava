/**
 * ColumnTypeModelDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.ColumnTypeModelDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.rowmapper.ColumnTypeModelMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;

/**
 * 
 * @Author : Dilleswara.Doppa
 * @Created On : Jun 28, 2016 3:29:15 PM
 * @Version : 1.7
 * @Description : "ColumnTypeModelDAOImpl" is used for
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class ColumnTypeModelDAOImpl implements ColumnTypeModelDAO {
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	/**
	 * 
	 * Method Name : saveColumnTypeModel Description : The Method
	 * "saveColumnTypeModel" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	public Long saveColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException {
		logger.debug("Start ::saveColumnTypeModel()");
		String query = "INSERT INTO AUD_COLUMN_TYPE(columntype,columnvalue,columndatatype,databasetype,createdby,updatedby,createDate,updateDate) values (?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
			final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
			{
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException
				{
					PreparedStatement pstmt = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
					pstmt.setString(1,columnTypeModelBO.getColumnType());
					pstmt.setString(2,columnTypeModelBO.getColumnValue());
					pstmt.setInt(3,columnTypeModelBO.getColumnDataType());
					pstmt.setString(4, columnTypeModelBO.getDataBaseType());
					pstmt.setString(5, columnTypeModelBO.getCreatedBy());
					pstmt.setString(6, columnTypeModelBO.getUpdatedBy());
				
					return pstmt;
				}
			};
			jdbcTemplate.update(pstmtCreator,keyHolder);
			return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;

		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AudienceException("E00002", ex);

		}
	}

	/**
	 * 
	 * Method Name : updateColumnTypeModel Description : The Method
	 * "updateColumnTypeModel" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	public Boolean updateColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException {
		logger.debug("Start ::updateColumnTypeModel");
		String query = "UPDATE AUD_COLUMN_TYPE set columntype=?,columnvalue=?,columndatatype=?,"
				+ "databasetype=?,updatedby=?,updateDate=utc_timestamp() where columntypeid=?";
		try {
			Object[] args = new Object[] {

					columnTypeModelBO.getColumnType(), 
					columnTypeModelBO.getColumnValue(),
					columnTypeModelBO.getColumnDataType(), 
					columnTypeModelBO.getDataBaseType(),
					columnTypeModelBO.getUpdatedBy(), 
					
					columnTypeModelBO.getColumnTypeId() };
			int status = jdbcTemplate.update(query, args);
			if (status != 0) {
				logger.debug("ColumnTypeModel record updated with id=" + columnTypeModelBO.getColumnTypeId());
				return true;
			} else {
				logger.debug("No ColumnTypeModel record found with id=" + columnTypeModelBO.getColumnTypeId());
				return false;
			}

		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : deleteColumnTypeModel Description : The Method
	 * "deleteColumnTypeModel" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean deleteColumnTypeModel(Long columntypeid) throws AudienceException {
		logger.debug("Start ::deleteColumnTypeModel()");
		String query = "DELETE FROM AUD_COLUMN_TYPE where columntypeid=?";
		try {
			int status = jdbcTemplate.update(query, new Object[] { columntypeid });
			if (status != 0) {
				logger.debug("ColumnTypeModel record deleted with id=" + columntypeid);
				return true;
			} else {
				logger.debug("No ColumnTypeModel found deleted id=" + columntypeid);
				return false;
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AudienceException("E00002", ex);
		}
	}

	/**
	 * 
	 * Method Name : findAllColumnTypeModel Description : The Method
	 * "findAllColumnTypeModel" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	public List<ColumnTypeModelBO> findAllColumnTypeModel() throws AudienceException {

		logger.debug("Start ::findAllColumnTypeModel()");
		List<ColumnTypeModelBO> columnTypeModelBO = null;
		String query = "SELECT * FROM AUD_COLUMN_TYPE";
		try {
			columnTypeModelBO = jdbcTemplate.query(query, new ColumnTypeModelMapper());
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends ::findAllColumnTypeModel()");
		return columnTypeModelBO;

	}

	/**
	 * 
	 * Method Name : findColumnTypeModelById Description : The Method
	 * "findColumnTypeModelById" is used for Date : Jun 28, 2016, 4:36:11 PM
	 * 
	 * @param audienceBO
	 * @return Long
	 * @throws AudienceException
	 */
	@Override
	public ColumnTypeModelBO findColumnTypeModelById(Long columntypeid) throws AudienceException {
		logger.debug("Start ::findColumnTypeModelById()");
		ColumnTypeModelBO columnTypeModelBO = null;
		String query = "SELECT * FROM AUD_COLUMN_TYPE WHERE columntypeid=?";
		try {
			Object[] args = new Object[] { columntypeid };
			columnTypeModelBO = jdbcTemplate.queryForObject(query, args, new ColumnTypeModelMapper());
		} catch (Exception ex) {
            logger.error(Constants.EXCEPTION,ex);
			throw new AudienceException("E00002", ex);
		}
		logger.debug("Ends ::findColumnTypeModelById()");
		return columnTypeModelBO;
	}

}

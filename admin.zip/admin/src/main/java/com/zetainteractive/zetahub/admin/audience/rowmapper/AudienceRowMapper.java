/**
 * AudienceRowMapper.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jun 28, 2016 4:37:36 PM
 * @Version : 1.7
 * @Description : "AudienceRowMapper" is used for AudienceBO RowMapper
 * 
 **/

public class AudienceRowMapper implements RowMapper<AudienceBO> {

	/**
	 * 
	 * Method Name : mapRow Description : The Method "mapRow" is used for Date :
	 * Jun 28, 2016, 4:37:57 PM
	 * 
	 * @param rs
	 * @param rowNum
	 * @return AudienceBO
	 * @throws SQLException
	 */
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	@Override
	public AudienceBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		AudienceBO audienceBO = new AudienceBO();
		ObjectMapper mapper = new ObjectMapper();
		List<LogicalTableBO> logicalColBOList = null;
		String jsonString = null;
		try {
			audienceBO.setAudienceId(rs.getLong("audienceid"));
			audienceBO.setAudienceName(rs.getString("audiencename"));
			audienceBO.setAudienceType(rs.getInt("audiencetype"));
			if(rs.getString("isdefault") != null){
				audienceBO.setIsDefault(rs.getString("isdefault").charAt(0));
			}
			if(rs.getString("audiencestatus") != null){
				audienceBO.setAudienceStatus(rs.getString("audiencestatus").charAt(0));
			}
			audienceBO.setCreatedBy(rs.getString("createdby"));
			audienceBO.setUpdatedBy(rs.getString("updatedby"));
			audienceBO.setDepartmentId(rs.getLong("departmentid"));
			try {
				audienceBO.setCreatedDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(),
						TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				audienceBO.setUpdatedDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(),
						TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
				e.printStackTrace();
			}
			jsonString = rs.getString("audiencemapping");
			logicalColBOList = mapper.readValue(jsonString,
					mapper.getTypeFactory().constructCollectionType(List.class, LogicalTableBO.class));
			audienceBO.setLogicalTables(logicalColBOList);
		} catch (IOException e) {
			// Logger to be refactored
			e.printStackTrace();
			throw new SQLException("Unable to convert JSON Format, invalid JSON String :: "+jsonString, e);
		}
		return audienceBO;
	}

}

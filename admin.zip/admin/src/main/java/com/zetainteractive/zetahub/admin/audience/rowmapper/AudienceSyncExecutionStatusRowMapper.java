/**
 * AudienceSyncExecutionStatusRowMapper.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.commons.domain.DataSyncExecutionStatusBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jun 28, 2016 3:27:53 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceSyncExecutionStatusRowMapper" is used for RowMapper
 * 
 **/

public class AudienceSyncExecutionStatusRowMapper implements RowMapper<DataSyncExecutionStatusBO> {

	/**
	 * 
	 * Method Name 	: mapRow
	 * Description 		: The Method "mapRow" is used for 
	 * Date    			: Jun 28, 2016, 3:28:18 PM
	 * @param rs
	 * @param rowNum
	 * @return DataSyncExecutionStatusBO
	 * @throws SQLException
	 */
	
	@Override
	public DataSyncExecutionStatusBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		DataSyncExecutionStatusBO syncExeObj = new DataSyncExecutionStatusBO();
		syncExeObj.setDataSyncStatusId(rs.getLong("datasourcesyncid"));
		syncExeObj.setDataSourceId(rs.getInt("datasourceid"));
		syncExeObj.setDataSourceLastSyncDate(rs.getDate("datasourcelastsyncdate"));
		syncExeObj.setProfileColumnLastSyncDate(rs.getDate("profilecolumnlastsyncdate"));
		syncExeObj.setDataSourceSyncStatus(rs.getString("datasourcesyncstatus").charAt(0));
		if(rs.getString("profilesyncstatus").isEmpty()){
			syncExeObj.setProfileSyncStatus(' ');
		}else{
			syncExeObj.setProfileSyncStatus(rs.getString("profilesyncstatus").charAt(0));
		}
		return syncExeObj;
	}

}

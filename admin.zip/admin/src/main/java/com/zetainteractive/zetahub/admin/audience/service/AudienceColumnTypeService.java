/**
 * AudienceColumnTypeService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.service;

import java.util.List;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 1, 2016 11:42:14 AM
 * @Version	     : 1.7 
 * @Description  : "AudienceColumnTypeService" is used for 
 * 
 **/

public interface AudienceColumnTypeService {
	
	/**
	 * Save column type model.
	 *
	 * @param columnTypeModelBO the column type model bo
	 * @return the long
	 * @throws AudienceException the audience exception
	 */
	public Long saveColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException;
	
	/**
	 * Update column type model.
	 *
	 * @param columnTypeModelBO the column type model bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean updateColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException;
	
	/**
	 * Delete column type model.
	 *
	 * @param columntypeid the columntypeid
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean deleteColumnTypeModel(Long columntypeid) throws AudienceException;

	/**
	 * Find all column type model.
	 *
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<ColumnTypeModelBO> findAllColumnTypeModel() throws AudienceException;
	
	/**
	 * Find column type model by id.
	 *
	 * @param columntypeid the columntypeid
	 * @return the column type model bo
	 * @throws AudienceException the audience exception
	 */
	public ColumnTypeModelBO findColumnTypeModelById(Long columntypeid) throws AudienceException;


}

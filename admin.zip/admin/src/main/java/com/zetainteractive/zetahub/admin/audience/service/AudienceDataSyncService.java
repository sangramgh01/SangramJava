/**
 * AudienceDataSyncService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.service;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.DataSyncExecutionStatusBO;

/**
 * 
 * @Author	     : venu.gudibena
 * @Created On  : Jun 29, 2016 1:06:11 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceDataSyncService" is used to sync the data source from warehouse to customer database 
 * 
 **/


public interface AudienceDataSyncService {
	
	/**
	 * Sync audience meta data.
	 *
	 * @param dataSourceId the data source id
	 * @param whSchemaName the wh schema name
	 * @param userName the user name
	 * @throws AudienceException the audience exception
	 */
	public void syncAudienceMetaData(int dataSourceId,String whSchemaName,String userName,Long departmentID) throws AudienceException;
	
	/**
	 * Gets the warehouse data source id.
	 *
	 * @param custcode the custcode
	 * @return the warehouse data source id
	 * @throws AudienceException the audience exception
	 */
	public int getWarehouseDataSourceId(String custcode) throws AudienceException;
	
	/**
	 * Gets the data source sync status.
	 *
	 * @param dataSourceId the data source id
	 * @return the data source sync status
	 * @throws AudienceException the audience exception
	 */
	public char getDataSourceSyncStatus(int dataSourceId) throws AudienceException;
	
	/**
	 * Sync profile columns.
	 *
	 * @param audienceId the audience id
	 * @param dataSourceId the data source id
	 * @throws AudienceException the audience exception
	 */
	public void syncProfileColumns(long audienceId,int dataSourceId) throws AudienceException;
	
	/**
	 * Gets the profile sync status.
	 *
	 * @param dataSourceId the data source id
	 * @return the profile sync status
	 * @throws AudienceException the audience exception
	 */
	public char getProfileSyncStatus(int dataSourceId) throws AudienceException;
	/**
	 * 
	 * Method Name 	: findDataSourceSyncStatus
	 * Description 	: The Method "findDataSourceSyncStatus" is used for 
	 * Date    		: Jul 27, 2016, 2:17:24 PM
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: DataSyncExecutionStatusBO
	 * @throws 		: 
	 */
	DataSyncExecutionStatusBO findDataSourceSyncStatus(int dataSourceId) throws AudienceException;
}

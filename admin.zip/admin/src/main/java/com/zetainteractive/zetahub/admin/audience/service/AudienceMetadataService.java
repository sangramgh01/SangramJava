/**
 * AudienceMetadataService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.service;

import java.util.List;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.ColumnStatCountBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 1, 2016 11:46:48 AM
 * @Version : 1.7
 * @Description : "AudienceMetadataService" is used for
 * 
 **/

public interface AudienceMetadataService {

	/**
	 * Save audience metadata.
	 *
	 * @param physicalTableBO the physical table bo
	 * @return the long
	 * @throws AudienceException the audience exception
	 * @throws ValidationException 
	 */
	public Long savePhysicalTable(PhysicalTableBO physicalTableBO,BindingResult bindingResult) throws AudienceException;

	/**
	 * Update audience metadata.
	 *
	 * @param physicalTableBO the physical table bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean updatePhysicalTable(PhysicalTableBO physicalTableBO,BindingResult bindingResult) throws AudienceException;

	/**
	 * Delete audience metadata.
	 *
	 * @param physicalTableId the physical table id
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean deletePhysicalTable(Long physicalTableId) throws AudienceException;
	
	/**
	 * Find audience metadata by name.
	 *
	 * @param physicalTableName the physical table name
	 * @return the physical table bo
	 * @throws AudienceException the audience exception
	 */
	public PhysicalTableBO findPhysicalTableByName(String physicalTableName) throws AudienceException;
	
	/**
	 * Find audience metadata by id.
	 *
	 * @param physicalTableId the physical table id
	 * @return the physical table bo
	 * @throws AudienceException the audience exception
	 */
	public PhysicalTableBO findPhysicalTableId(Long physicalTableId) throws AudienceException;
	
	/**
	 * List audience metadata.
	 *
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<PhysicalTableBO> listPhysicalTables() throws AudienceException;
	
	/**
	 * Find physical tables not mapped in audiences.
	 *
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<PhysicalTableBO> findPhysicalTablesNotMappedInAudiences(boolean isDimension) throws AudienceException;
	
	/**
	 * Checks if is physical table exist with table name.
	 *
	 * @param tableName the table name
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean isPhysicalTableExistWithTableName(String physicalTableName) throws AudienceException;
	
	/**
	 * Checks if is physical column exist with column name.
	 *
	 * @param physicalColumnName the physical column name
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean isPhysicalColumnExistWithColumnName(String physicalColumnName) throws AudienceException;

	/**
	 * 
	 * Method Name 	: getStatsCountsList
	 * Description 	: The Method "getStatsCountsList" is used for 
	 * Date    		: Jul 13, 2016, 2:58:57 PM
	 * @param physicalTableId
	 * @param physicalColumnName
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<ColumnStatCountBO>
	 * @throws 		: 
	 */
	public List<ColumnStatCountBO> getStatsCountsList(Long physicalTableId, String physicalColumnName) throws AudienceException;

	/**
	 * 
	 * Method Name 	: listStatingTables
	 * Description 	: The Method "listStatingTables" is used for 
	 * Date    		: Jul 13, 2016, 3:14:09 PM
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<PhysicalTableBO>
	 * @throws 		: 
	 */
	public List<PhysicalTableBO> listStatingTables() throws AudienceException;

}

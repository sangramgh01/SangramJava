/**
 * AudienceService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.service;

import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.AudienceKeyColumnsBO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 1, 2016 1:18:16 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceService" is used for 
 * 
 **/

public interface AudienceService {
	
	/**
	 * Save audience.
	 *
	 * @param audienceBO the audience bo
	 * @return the long
	 * @throws AudienceException the audience exception
	 */
	public Long saveAudience(AudienceBO audienceBO,BindingResult bindingResult) throws AudienceException;

	/**
	 * Update audience.
	 *
	 * @param audienceBO the audience bo
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean updateAudience(AudienceBO audienceBO,BindingResult bindingResult) throws AudienceException;

	/**
	 * Delete audience.
	 *
	 * @param audienceId the audience id
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean deleteAudience(Long audienceId) throws AudienceException;
	
	/**
	 * Find audience by name.
	 *
	 * @param audienceName the audience name
	 * @return the audience bo
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO findAudienceByName(String audienceName) throws AudienceException;
	
	/**
	 * Find audience by id.
	 *
	 * @param audienceId the audience id
	 * @return the audience bo
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO findAudienceById(Long audienceId) throws AudienceException;
	
	/**
	 * List audience.
	 *
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<AudienceBO> listAudience(Long departmentId) throws AudienceException;
	
	public List<AudienceBO> listAudience()throws AudienceException;
	
	/**
	 * Checks if is audiences name exists.
	 *
	 * @param audienceName the audience name
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean isAudiencesNameExists(String audienceName) throws AudienceException;
	
	/**
	 * Checks if is logical table name exists.
	 *
	 * @param logicalTableName the logical table name
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean isLogicalTableNameExists(String logicalTableName) throws AudienceException;
	
	/**
	 * Checks if is logical column name exists.
	 *
	 * @param logicalColumnName the logical column name
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	public Boolean isLogicalColumnNameExists(String logicalColumnName) throws AudienceException;
	
	/**
	 * Find all audiences.
	 *
	 * @param listingCriteria the listing criteria
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	public List<AudienceBO> findAllAudiences(AudienceSearchCriteria listingCriteria,BindingResult bindingResult) throws AudienceException;

	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceIdAndPhyTableId
	 * Description 	: The Method "getLogicalColumnsByAudienceIdAndPhyTableId" is used for 
	 * Date    		: Jul 13, 2016, 2:18:42 PM
	 * @param audienceId
	 * @param physicalTableId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<LogicalColumnBO>
	 * @throws 		: 
	 */
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndPhyTableId(Long audienceId, Long physicalTableId)
			throws AudienceException;
	
	/**
	 * Gets the logical columns by audience id and logical table name.
	 *
	 * @param audienceId the audience id
	 * @param logicalTableName the logical table name
	 * @return the logical columns by audience id and logical table name
	 * @throws AudienceException the audience exception
	 */
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndLogicalTableName(Long audienceId, String logicalTableName) throws AudienceException;
	
	/**
	 * Gets the logical table by audience id and logical table name.
	 *
	 * @param audienceId the audience id
	 * @param logicalTableName the logical table name
	 * @return the logical table by audience id and logical table name
	 * @throws AudienceException the audience exception
	 */
	public LogicalTableBO getLogicalTableByAudienceIdAndLogicalTableName(Long audienceId, String logicalTableName) throws AudienceException;

	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceId
	 * Description 	: The Method "getLogicalColumnsByAudienceId" is used for 
	 * Date    		: Jul 13, 2016, 6:20:24 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<LogicalColumnBO>
	 * @throws 		: 
	 */
	public List<LogicalColumnBO> getLogicalColumnsByAudienceId(Long audienceId) throws AudienceException;

	/**
	 * 
	 * Method Name 	: getLogicalColumnsBaseByAudienceId
	 * Description 	: The Method "getLogicalColumnsBaseByAudienceId" is used for 
	 * Date    		: Jul 14, 2016, 2:20:22 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: List<LogicalColumnBO>
	 * @throws 		: 
	 */
	public List<LogicalColumnBO> getBaseLogicalColumnsByAudienceId(Long audienceId) throws AudienceException;
	
	
	/**
	 * Gets the dimension tables by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the dimension tables by audience id
	 * @throws AudienceException the audience exception
	 */
	public List<LogicalTableBO> getDimensionTablesByAudienceId(Long audienceId) throws AudienceException ;

	/**
	 * 
	 * Method Name 	: getReceipentTableByAudienceId
	 * Description 	: The Method "getReceipentTableByAudienceId" is used for 
	 * Date    		: Jul 19, 2016, 12:51:13 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: LogicalTableBO
	 */
	public LogicalTableBO getReceipentTableByAudienceId(Long audienceId) throws AudienceException;
	
	/**
	 * Audiences total count.
	 *
	 * @param listingCriteria the listing criteria
	 * @return the long
	 * @throws AudienceException the audience exception
	 */
	public Long audiencesTotalCount(AudienceSearchCriteria listingCriteria) throws AudienceException;

	/**
	 * 
	 * Method Name 	: deleteDimentionTables
	 * Description 	: The Method "deleteDimentionTables" is used for 
	 * Date    		: Jul 21, 2016, 4:23:16 PM
	 * @param audienceId
	 * @param physicalTableId
	 * @return
	 * @throws AudienceException
	 */
	public Boolean deleteDimensionTables(Long audienceId, Long physicalTableId) throws AudienceException;

	/**
	 * 
	 * Method Name 	: isAudiencesNameExistsByNameAndId
	 * Description 	: The Method "isAudiencesNameExistsByNameAndId" is used for 
	 * Date    		: Jul 22, 2016, 8:21:24 PM
	 * @param audienceName
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 */
	public Boolean isAudiencesNameExistsByNameAndId(String audienceName, Long audienceId) throws AudienceException;
	
	/**
	 * Gets the key columns by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the key columns by audience id
	 * @throws AudienceException the audience exception
	 */
	public AudienceKeyColumnsBO getKeyColumnsByAudienceId(Long audienceId,String logicalTableName) throws AudienceException;
	
	/**
	 * Gets the logical columns with nullable falg by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the logical columns with nullable falg by audience id
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO getLogicalColumnsWithNullableFalgByAudienceId(Long audienceId) throws AudienceException;

	/**
	 * Gets the logical columns with nullable falg by audience name.
	 *
	 * @param audienceId the audience name
	 * @return the logical columns with nullable falg by audience name
	 * @throws AudienceException the audience exception
	 */
	public AudienceBO getLogicalColumnsWithNullableFalgByAudienceName(String audienceName) throws AudienceException;

	/**
	 * 
	 * 
	 * Method Name 	: getAudienceMetaDetails
	 * Description 	: The Method "getAudienceMetaDetails" is used for getting name and audienceId 
	 * Date    		: 23 Jan 2018, 13:01:53
	 * @return
	 * @param  		:
	 * @return 		: List<Map<String,Object>>
	 * @throws 		:
	 */
	public List<Map<String,Object>> getAudienceMetaDetails();
	/**
	 * 
	 * 
	 * Method Name 	: getAudienceNamesByIds
	 * Description 	: The Method "getAudienceNamesByIds" is used for getting audience names based on ids
	 * Date    		: 23 Jan 2018, 14:40:29
	 * @param ids
	 * @return
	 * @param  		:
	 * @return 		: Map<Long,String>
	 * @throws 		:
	 */
	public Map<Long, String> getAudienceNamesByIds(List<Long> ids);

	public Map<String, Boolean> checkAudienceAssocation(Long audienceId) throws AudienceException;

	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceIdAndPhyTableName
	 * Description 	: The Method "getLogicalColumnsByAudienceIdAndPhyTableName" is used for 
	 * Date    		: May 23, 2018, 7:13:43 PM
	 * @param audienceId
	 * @param physicalTableName
	 * @return
	 * @param  		:
	 * @return 		: List<LogicalColumnBO>
	 * @throws 		: 
	 */
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndPhyTableName(Long audienceId, String physicalTableName) throws AudienceException;
}

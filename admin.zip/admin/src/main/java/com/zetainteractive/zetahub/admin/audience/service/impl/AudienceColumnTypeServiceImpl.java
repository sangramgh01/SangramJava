/**
 * AudienceColumnTypeServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.dao.ColumnTypeModelDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceColumnTypeService;
import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;
import org.springframework.retry.annotation.Backoff; 

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 1, 2016 11:42:48 AM
 * @Version : 1.7
 * @Description : "AudienceColumnTypeServiceImpl" is used for Audience Column Type DB related operations
 * 
 **/
@Component
public class AudienceColumnTypeServiceImpl implements AudienceColumnTypeService {

	@Autowired
	private ColumnTypeModelDAO columnTypeModelDAO;

	/**
	 * 
	 * Method Name : saveColumnTypeModel Description : The Method
	 * "saveColumnTypeModel" is used for Date : Jul 4, 2016, 6:33:43 PM
	 * 
	 * @param columnTypeModelBO
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Long saveColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException {
		return columnTypeModelDAO.saveColumnTypeModel(columnTypeModelBO);
	}

	/**
	 * 
	 * Method Name : updateColumnTypeModel Description : The Method
	 * "updateColumnTypeModel" is used for Date : Jul 4, 2016, 6:33:43 PM
	 * 
	 * @param columnTypeModelBO
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean updateColumnTypeModel(ColumnTypeModelBO columnTypeModelBO) throws AudienceException {
		return columnTypeModelDAO.updateColumnTypeModel(columnTypeModelBO);
	}

	/**
	 * 
	 * Method Name : findAllColumnTypeModel Description : The Method
	 * "findAllColumnTypeModel" is used for Date : Jul 4, 2016, 6:33:43 PM
	 * 
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<ColumnTypeModelBO> findAllColumnTypeModel() throws AudienceException {
		return columnTypeModelDAO.findAllColumnTypeModel();
	}

	/**
	 * 
	 * Method Name : findColumnTypeModelById Description : The Method
	 * "findColumnTypeModelById" is used for Date : Jul 4, 2016, 6:33:43 PM
	 * 
	 * @param columntypeid
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ColumnTypeModelBO findColumnTypeModelById(Long columntypeid) throws AudienceException {
		return columnTypeModelDAO.findColumnTypeModelById(columntypeid);
	}

	/**
	 * 
	 * Method Name : deleteColumnTypeModel Description : The Method
	 * "deleteColumnTypeModel" is used for Date : Jul 4, 2016, 6:35:32 PM
	 * 
	 * @param columntypeid
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean deleteColumnTypeModel(Long columntypeid) throws AudienceException {
		return columnTypeModelDAO.deleteColumnTypeModel(columntypeid);
	}

}

/**
 * AudienceDataSyncServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceDataSyncDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceMetadataDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceSyncExecutionStatusDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceWarehouseMetaDataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceDataSyncService;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.DataSyncExecutionStatusBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : venu.gudibena
 * @Created On : Jun 29, 2016 2:52:33 PM
 * @Version : 1.7
 * @Description : "AudienceDataSyncServiceImpl" is used for audience data sync from warehouse and also profile syncronization
 * 
 **/
@Component
@Scope(value="prototype")
public class AudienceDataSyncServiceImpl implements AudienceDataSyncService {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	AudienceDataSyncDAO audienceDataSyncDAO;

	@Autowired
	AudienceMetadataDAO audienceMetadataDAO;

	@Autowired
	AudienceWarehouseMetaDataDAO audienceWarehouseMetaDataDAO;

	@Autowired
	AudienceSyncExecutionStatusDAO audienceSyncExecutionStatusDAO;

	@Autowired
	AudienceDAO audienceDAO;
	@Autowired
	Environment env;

	/**
	 * 
	 * Method Name : syncAudienceMetaData Description : The Method
	 * "syncAudienceMetaData" is used to sync the data source from warehouse to
	 * customer database Date : Jun 29, 2016, 4:02:28 PM
	 * 
	 * @param dataSourceId
	 * @return : void
	 * @throws : AudienceException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public void syncAudienceMetaData(int dataSourceId,String whSchemaName,String userName,Long departmentID) throws AudienceException {
		logger.info("Begin :: syncAudienceMetaData("+dataSourceId+":"+whSchemaName+":"+userName+":"+departmentID);
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		boolean firstTimeSync = false;
		DataSyncExecutionStatusBO datasourceSyncExecution = null;
		try {
			logger.debug("Fetching DatasourceSyncExecution Details started using dataSourceId :: " + dataSourceId);
			datasourceSyncExecution = audienceSyncExecutionStatusDAO.findSyncExecutionStatusByDataSource(dataSourceId);
			if (datasourceSyncExecution == null) {
				datasourceSyncExecution = new DataSyncExecutionStatusBO();
				datasourceSyncExecution.setDataSourceId(dataSourceId);
				datasourceSyncExecution.setDataSourceLastSyncDate(currentTime);
				datasourceSyncExecution.setProfileColumnLastSyncDate(currentTime);
				datasourceSyncExecution.setDataSourceSyncStatus(Constants.PROGRESS);
				datasourceSyncExecution.setProfileSyncStatus(' ');
				audienceSyncExecutionStatusDAO.saveSyncExecutionStatus(datasourceSyncExecution);
				firstTimeSync = true;
			} else {
				if (datasourceSyncExecution.getDataSourceSyncStatus() == Constants.FIRST_TIME_SYNC_ERRORED) {
					firstTimeSync = true;
				}
				datasourceSyncExecution.setDataSourceLastSyncDate(currentTime);
				datasourceSyncExecution.setDataSourceSyncStatus(Constants.PROGRESS);
				datasourceSyncExecution.setProfileColumnLastSyncDate(datasourceSyncExecution.getProfileColumnLastSyncDate());
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
			}
			logger.debug("DatasourceSyncExecution first time sync :: " + firstTimeSync);
			//get WH schema name from Config server 
			
            logger.info("=============================>"+whSchemaName);
			List<PhysicalTableBO> physicalTableBOs = audienceWarehouseMetaDataDAO
					.getAudiencePhysicalTableMetaData(dataSourceId,whSchemaName,userName ); 
			for (PhysicalTableBO physicalTableBO : physicalTableBOs) {
				PhysicalTableBO physicalTableBoOld = audienceMetadataDAO.findPhysicalTableByName(physicalTableBO.getPhysicalTableName());
				if(null==physicalTableBoOld){
					logger.info("Save request for new table :"+physicalTableBO.getPhysicalTableName());
					audienceMetadataDAO.savePhysicalTable(physicalTableBO);
				}else{
					physicalTableBO.setPhysicalTableId(physicalTableBoOld.getPhysicalTableId());
					
					List<PhysicalColumnBO> physicalColBONewList = physicalTableBO.getPhysicalColumns();
					for (PhysicalColumnBO physicalColumnBO : physicalColBONewList) {
						String existingPhyColName = physicalColumnBO.getPhysicalColumnName();
						
						PhysicalColumnBO   resultColumnBO = physicalTableBoOld.getPhysicalColumns().stream() // Convert // to
								// steam
								.filter(x -> x.getPhysicalColumnName().equalsIgnoreCase(existingPhyColName)) //
								.findAny() // If 'findAny' then return found
								.orElse(null);
						
						if(resultColumnBO!= null) {
							physicalColumnBO.setColumnStatCounts(resultColumnBO.getColumnStatCounts());
						}
					}
					audienceMetadataDAO.updatePhysicalTable(physicalTableBO);
				}
			}
			logger.info("=========>In syncDataSource() sync dataSource is completed");
			datasourceSyncExecution = audienceSyncExecutionStatusDAO
					.findSyncExecutionStatusByDataSource(dataSourceId);
			if (datasourceSyncExecution != null) {
				datasourceSyncExecution.setDataSourceLastSyncDate(currentTime);
				datasourceSyncExecution.setProfileColumnLastSyncDate(datasourceSyncExecution.getProfileColumnLastSyncDate());
				datasourceSyncExecution.setDataSourceSyncStatus(Constants.COMPLETED);
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
			}
			logger.info(
					"In syncDataSource() DatasourceSyncExecutionDetails updating completed after syncDatasource process");
			if(!audienceDAO.isAudiencesNameExists("Email Address Audience")){
				audienceDAO.saveAudience(prepareSystemEmailAudienceBOForVerticadb(departmentID));
			}
			if(!audienceDAO.isAudiencesNameExists("Sms Audience")){
				audienceDAO.saveAudience(prepareSystemSMSAudienceBOForVerticadb(departmentID));
			}
		} catch (Exception e) {
			logger.debug("Exception occured while performing the data sync",e);
			try {
				if(datasourceSyncExecution == null){
					datasourceSyncExecution = new DataSyncExecutionStatusBO();
					datasourceSyncExecution.setProfileSyncStatus(' ');
				}
				if (firstTimeSync) {
					datasourceSyncExecution.setDataSourceSyncStatus(Constants.FIRST_TIME_SYNC_ERRORED);
				} else {
					datasourceSyncExecution.setDataSourceSyncStatus(Constants.ERRORED);
				}
				datasourceSyncExecution.setDataSourceLastSyncDate(currentTime);
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
			} catch (Exception ex) {
				logger.error("Error occured while saving the data source sync status", ex);
			}
			if(e instanceof AudienceException){
				logger.error("AudienceException occured while data sync ::",e);
				throw e;
			}
			else {
				logger.error("Unknown exception occured while data sync ::",e);
				throw new AudienceException("AU0012", null, e);
			}
		}
		logger.debug("End::syncAudienceMetaData(...)");
	}

	/**
	 * 
	 * Method Name : getWarehouseDataSourceId Description : The Method
	 * "getWarehouseDataSourceId" is used for Date : Jun 29, 2016, 2:55:22 PM
	 * 
	 * @param custcode
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int getWarehouseDataSourceId(String custcode) throws AudienceException {
		logger.info("Start : getWarehouseDataSourceId("+custcode+")");
		int dataSourceId = 0;
		try {
			logger.debug("custcode----------------->"+custcode);
			dataSourceId = audienceDataSyncDAO.getWarehouseDataSourceId(custcode);
		} catch (Exception e) {
			logger.error("Exception occured while fetching the Waehouse data source ID",e);
			throw new AudienceException("E00002", e);
		}
		logger.info("End : getWarehouseDataSourceId("+custcode+"))");
		return dataSourceId;
	}

	/**
	 * 
	 * Method Name : getDataSourceSyncStatus Description : The Method
	 * "getDataSourceSyncStatus" is used for Date : Jun 29, 2016, 2:55:22 PM
	 * 
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public char getDataSourceSyncStatus(int dataSourceId) throws AudienceException {
		logger.info("Start : getDataSourceSyncStatus(dataSourceId)");
		char syncStatus;
		try {
			logger.debug("Data source sync for the data source ID:"+dataSourceId);
			syncStatus = audienceSyncExecutionStatusDAO.getDataSourceSyncStatus(dataSourceId);
		} catch (Exception e) {
			logger.debug("Exception occured while fetching the data source sync status",e);
			throw new AudienceException("E00002", e);
		}
		logger.info("End : getDataSourceSyncStatus(dataSourceId)");
		return syncStatus;
	}
	
	/**
	 * Method Name : getDataSourceSyncStatus Description : The Method
	 * "getDataSourceSyncStatus" is used for Date : Jun 29, 2016, 2:55:22 PM.
	 *
	 * @param dataSourceId the data source id
	 * @return :
	 * @throws AudienceException the audience exception
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public DataSyncExecutionStatusBO findDataSourceSyncStatus(int dataSourceId) throws AudienceException {
		logger.info("Start : findDataSourceSyncStatus(dataSourceId)");
		DataSyncExecutionStatusBO dataSyncExecutionStatusBO = null;
		try {
			logger.debug("Data source sync for the data source ID:"+dataSourceId);
			dataSyncExecutionStatusBO = audienceSyncExecutionStatusDAO.findSyncExecutionStatusByDataSource(dataSourceId);
		} catch (Exception e) {
			logger.debug("Exception occured while fetching the data source sync status",e);
			throw new AudienceException("E00002", e);
		}
		logger.info("End : findDataSourceSyncStatus(dataSourceId)");
		return dataSyncExecutionStatusBO;
	}

	/**
	 * This method is used to prepare System audience insert objects
	 * 
	 * @param datasourceId
	 * @return
	 * @throws AdminException
	 */
	private AudienceBO prepareSystemEmailAudienceBOForVerticadb(Long departmentID) throws AudienceException {
		logger.debug("info :: prepareSystemEmailAudienceBOForVerticadb()");
		List<LogicalColumnBO> logicalColumnsList = new ArrayList<>();
        List<LogicalTableBO> logicalTablesList = new ArrayList<>();
		AudienceBO emailAudience = new AudienceBO();
		emailAudience.setAudienceName("Email Address Audience");
		emailAudience.setIsDefault(Constants.NO);
		emailAudience.setAudienceType(1);
		emailAudience.setAudienceStatus('A');
		emailAudience.setIsDefault('N');
		emailAudience.setCreatedDate(new Date());
    
		LogicalTableBO logicalTables = new LogicalTableBO();
		try {
			try {
				UserBO userObj = ZetaUtil.getHelper().getUser();
				if (userObj != null) {
					emailAudience.setDepartmentId(departmentID != null ? departmentID : userObj.getDepartmentID());
					emailAudience.setCreatedBy(userObj.getUserName());  
					emailAudience.setUpdatedBy(userObj.getUserName());  
				}
			} catch (Exception e) {
				logger.error("Exception while fetching the User object from Zeta Context ", e);
				throw new AudienceException("E00002");
			}
			logger.debug("Fetching audience meta data for AUDIENCE_EMAIL");
			PhysicalTableBO physicalTableBO = audienceMetadataDAO.findPhysicalTableByName("AUDIENCE_EMAIL");
			logger.debug("Preparing logical table data for AUDIENCE_EMAIL");
			logicalTables.setPhysicalTableId(physicalTableBO.getPhysicalTableId());
			logicalTables.setPhysicalTableName(physicalTableBO.getPhysicalTableName());
			logicalTables.setLogicalTableName("Email Address");
			logicalTables.setTableType(0);
			for (PhysicalColumnBO physicalColumnBO : physicalTableBO.getPhysicalColumns()) {
				LogicalColumnBO logicalColumns = new LogicalColumnBO();
				logicalColumns.setIsProfilable(Constants.NO);
				logicalColumns.setIsKeyColumn(Constants.NO);
				if (physicalColumnBO.getPhysicalColumnName().equals("AUDIENCE_MEMBER_ID")) {
					logicalColumns.setLogicalColumnName("Audience Member Id");
				} else if (physicalColumnBO.getPhysicalColumnName().equals("EMAIL_ADDRESS")) {
					logicalColumns.setLogicalColumnName("Email Address");
					logicalColumns.setIsKeyColumn(Constants.YES);
				} else if (physicalColumnBO.getPhysicalColumnName().equals("ACTIVE_IND")) {
					logicalColumns.setLogicalColumnName("Is Mailable");
					logicalColumns.setIsProfilable(Constants.YES);
				} else if (physicalColumnBO.getPhysicalColumnName().equals("EMAIL_DOMAIN_NAME")) {
					logicalColumns.setLogicalColumnName("Domain Name");
				} else if (physicalColumnBO.getPhysicalColumnName().equals("CREATION_DT")) {
					logicalColumns.setLogicalColumnName("CREATION_DT");
				} else if (physicalColumnBO.getPhysicalColumnName().equals("MODIFIED_DT")) {
					logicalColumns.setLogicalColumnName("MODIFIED_DT");
				}else{
					logicalColumns.setLogicalColumnName(physicalColumnBO.getPhysicalColumnName());
				}
				logicalColumns.setPhysicalColumnName(physicalColumnBO.getPhysicalColumnName());
				logicalColumns.setColumnDataType(physicalColumnBO.getColumnDataType());
				logicalColumnsList.add(logicalColumns);
			}
			logicalTables.setLogicalColumns(logicalColumnsList);
			logicalTablesList.add(logicalTables);
			emailAudience.setLogicalTables(logicalTablesList);
		} catch (AudienceException e) {
			logger.error("Exception while processing Email Audience ",e);
			throw e;
		}
		logger.info("End : prepareSystemEmailAudienceBOForVerticadb()");
		return emailAudience;
	}

	/**
	 * 
	 * Method Name : prepareSystemSMSAudienceBOForVerticadb Description : The
	 * Method "prepareSystemSMSAudienceBOForVerticadb" is used for Date : Jun
	 * 29, 2016, 6:27:41 PM
	 * 
	 * @param datasourceId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return : AudienceBO
	 * @throws :
	 */
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	private AudienceBO prepareSystemSMSAudienceBOForVerticadb(Long departmentID) throws AudienceException {
		logger.info("Start : prepareSystemSMSAudienceBOForVerticadb(departmentID ::"+departmentID+")");
		List<LogicalColumnBO> logicalColumnsList = null;
		 List<LogicalTableBO> logicalTablesList = null;
		LogicalTableBO logicalTables = null;
		AudienceBO smsAudience = new AudienceBO();
		smsAudience.setAudienceName("Sms Audience");
		smsAudience.setIsDefault(Constants.NO);
		smsAudience.setAudienceType(4);
		smsAudience.setAudienceStatus('A');
		smsAudience.setIsDefault('N');
		smsAudience.setCreatedDate(new Date());
		try {
			try {
				UserBO userObj = ZetaUtil.getHelper().getUser();
				if (userObj != null) {
					smsAudience.setDepartmentId(departmentID != null ? departmentID : userObj.getDepartmentID());
					smsAudience.setCreatedBy(userObj.getUserName());  
					smsAudience.setUpdatedBy(userObj.getUserName());  
				}
			} catch (Exception e) {
				logger.error("Exception while fetching the User object from Zeta Context ", e);
				throw new AudienceException("E00002");
			}
			logger.debug("Fetching audience meta data for AUDIENCE_SMS");
			PhysicalTableBO physicalTableBO = audienceMetadataDAO.findPhysicalTableByName("AUDIENCE_SMS");
			logger.debug("Preparing logical table data for AUDIENCE_SMS");
			logicalTables = new LogicalTableBO();
			logicalTables.setPhysicalTableId(physicalTableBO.getPhysicalTableId());
			logicalTables.setPhysicalTableName(physicalTableBO.getPhysicalTableName());
			logicalTables.setLogicalTableName("Sms");
			logicalTables.setTableType(0);
			logicalColumnsList = new ArrayList<>();
			logicalTablesList = new ArrayList<>();
			for (PhysicalColumnBO physicalColumnBO : physicalTableBO.getPhysicalColumns()) {
				LogicalColumnBO logicalColumns = new LogicalColumnBO();
				logicalColumns.setIsProfilable(Constants.NO);
				logicalColumns.setIsKeyColumn(Constants.NO);
				if (physicalColumnBO.getPhysicalColumnName().equals("AUDIENCE_MEMBER_ID")) {
					logicalColumns.setLogicalColumnName("Audience Member Id");
				} else if (physicalColumnBO.getPhysicalColumnName().equals("SMS_NUMBER")) {
					logicalColumns.setLogicalColumnName("SMS Number");
					logicalColumns.setIsKeyColumn(Constants.YES);
				} else if (physicalColumnBO.getPhysicalColumnName().equals("ACTIVE_IND")) {
					logicalColumns.setLogicalColumnName("Is Mailable");
					logicalColumns.setIsProfilable(Constants.YES);
				} else if (physicalColumnBO.getPhysicalColumnName().equals("CREATION_DT")) {
					logicalColumns.setLogicalColumnName("CREATION_DT");
				} else if (physicalColumnBO.getPhysicalColumnName().equals("MODIFIED_DT")) {
					logicalColumns.setLogicalColumnName("MODIFIED_DT");
				}else{
					logicalColumns.setLogicalColumnName(physicalColumnBO.getPhysicalColumnName());
				}
				logicalColumns.setPhysicalColumnName(physicalColumnBO.getPhysicalColumnName());
				logicalColumns.setColumnDataType(physicalColumnBO.getColumnDataType());
				logicalColumnsList.add(logicalColumns);
			}
			logicalTables.setLogicalColumns(logicalColumnsList);
			logicalTablesList.add(logicalTables);
			smsAudience.setLogicalTables(logicalTablesList);
		} catch (AudienceException e) {
			logger.error("Exception while processing SMS Audience ",e);
			throw e;
		}
		logger.info("Start : prepareSystemSMSAudienceBOForVerticadb()");
		return smsAudience;
	}

	/**
	 * Method Name 	: syncProfileColumns
	 * Description 		: The Method "syncProfileColumns" is used to run the profileable column sync service 
	 * Date    			: Jul 7, 2016, 2:57:38 PM
	 * @param audienceid
	 * @param dataSourceId
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		:
	 */
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public void syncProfileColumns(long audienceid,int dataSourceId) throws AudienceException {
		logger.info("Begin : syncProfileColumns(audienceid,dataSourceId)");
		DataSyncExecutionStatusBO datasourceSyncExecution = null;
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		if(audienceid < 0){
			logger.error("Invalid audience id");
			throw new AudienceException("AU0047");
		}
		try {
			logger.debug("dataSourceId------------------>"+dataSourceId);
			logger.debug("audienceid-------------------->"+audienceid);
			logger.debug("Fetching DatasourceSyncExecution Details started using dataSourceId :: " + dataSourceId);
			datasourceSyncExecution = audienceSyncExecutionStatusDAO.findSyncExecutionStatusByDataSource(dataSourceId);
			logger.debug("datasourceSyncExecution---------------->"+datasourceSyncExecution);
			if (datasourceSyncExecution != null) {
				datasourceSyncExecution.setProfileColumnLastSyncDate(currentTime);
				datasourceSyncExecution.setDataSourceLastSyncDate(datasourceSyncExecution.getDataSourceLastSyncDate());
				datasourceSyncExecution.setProfileSyncStatus(Constants.PROGRESS);
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
			} 
			List<AudienceBO> audienceList = new ArrayList<>();
			if(audienceid == 0){
				logger.info("Profile syncronization for all the audiences starts");
				audienceList = audienceDAO.findAllAudience();
			}else{
				logger.info("Profile sync for the Audience ID ::"+audienceid);
				AudienceBO audienceBO = audienceDAO.findAudienceById(audienceid);
				audienceList.add(audienceBO);
			}

			Set<Long> physicalIDMappedSet =new  HashSet<Long>();
			Map<Long,PhysicalTableBO> physicalTableBOMap = null;

			if(audienceList != null && audienceList.size()>0){
				for (AudienceBO audienceBO : audienceList) {
					List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
					for (LogicalTableBO logicalTableBO : logicalTableBOList) {
						physicalIDMappedSet.add(logicalTableBO.getPhysicalTableId());
					}
				}
				physicalTableBOMap = audienceMetadataDAO.findPhysicalTablesByIds(physicalIDMappedSet);

				for (AudienceBO audienceBO : audienceList) {
					for (LogicalTableBO logicalTableBO : audienceBO.getLogicalTables()) {
						List<LogicalColumnBO> logicalColumnBOs = logicalTableBO.getLogicalColumns();
						List<PhysicalColumnBO> profilableColumns = new ArrayList<>();
						Map<String,List<PhysicalColumnBO>> profileColumnsMap = new HashMap<>();
						PhysicalTableBO physicalTableBO = physicalTableBOMap.get(logicalTableBO.getPhysicalTableId());
						if(physicalTableBO!= null) {
							for (LogicalColumnBO logicalColumnBO : logicalColumnBOs) {
								if(logicalColumnBO.getIsProfilable()== Constants.YES){
									for (PhysicalColumnBO physicalColumnBO : physicalTableBO.getPhysicalColumns()) {
										if(physicalColumnBO.getPhysicalColumnName().equalsIgnoreCase(logicalColumnBO.getPhysicalColumnName())){
											profilableColumns.add(physicalColumnBO);
											logger.debug(physicalTableBO.getPhysicalTableName() +" : "+physicalColumnBO.getPhysicalColumnName());
										}
									}
								}
							}


							profileColumnsMap.put(physicalTableBO.getPhysicalTableName(), profilableColumns);
							logger.info("Profile updates for table :"+physicalTableBO.getPhysicalTableName()+" starts");
							Map<String,List<PhysicalColumnBO>> profileColumnsStatMap = audienceWarehouseMetaDataDAO.getProfileableColumnValues(profileColumnsMap);
							Set<String> tableNames =  profileColumnsStatMap.keySet();
							for (String physicalTableName : tableNames) {
								for (PhysicalColumnBO physicalColumnBO : physicalTableBO.getPhysicalColumns()) {
									for (PhysicalColumnBO statRecord : profileColumnsStatMap.get(physicalTableName)) {
										logger.debug("Creating/updating profile stat recrods for the physical column name ---->"+physicalColumnBO.getPhysicalColumnName());
										if(statRecord.getPhysicalColumnName().equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName())){
											physicalColumnBO.setColumnStatCounts(statRecord.getColumnStatCounts());
										}
									}
								}
								logger.debug("Before updating the physical table with stat records");
								audienceMetadataDAO.updatePhysicalTable(physicalTableBO);
							}
						}

					}
				}

			}     
			// update the profile sync status to COMPLETED
			datasourceSyncExecution = audienceSyncExecutionStatusDAO.findSyncExecutionStatusByDataSource(dataSourceId);
			if (datasourceSyncExecution != null) {
				datasourceSyncExecution.setProfileColumnLastSyncDate(currentTime);
				datasourceSyncExecution.setDataSourceLastSyncDate(datasourceSyncExecution.getDataSourceLastSyncDate());
				datasourceSyncExecution.setProfileSyncStatus(Constants.COMPLETED);
				logger.debug("Updating the Data sync execution station record to ---->"+datasourceSyncExecution.getProfileSyncStatus());
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
				logger.debug("Ends: updating the data sync execution status record");
			} 

		}catch (Exception ex) {
			logger.error("Exception occurred while processing profileable column sync service ::",ex);
			if(datasourceSyncExecution!=null){
				datasourceSyncExecution.setProfileColumnLastSyncDate(currentTime);
				datasourceSyncExecution.setProfileSyncStatus(Constants.ERRORED);
				audienceSyncExecutionStatusDAO.updateSyncExecutionStatus(datasourceSyncExecution);
			}
			throw new AudienceException("AU0024", null,ex);
		} 
	}

	/**
	 * 
	 * Method Name 	: getProfileSyncStatus
	 * Description 		: The Method "getProfileSyncStatus" is used for 
	 * Date    			: Jul 7, 2016, 11:51:46 AM
	 * @param dataSourceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		:
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public char getProfileSyncStatus(int dataSourceId) throws AudienceException{
		logger.info("Start : getProfileSyncStatus(dataSourceId)");
		char syncStatus;
		try {
			logger.debug("dataSourceId------------------>"+dataSourceId);
			syncStatus = audienceSyncExecutionStatusDAO.getProfileSyncStatus(dataSourceId);
		} catch (Exception e) {
			logger.error("Exception while getProfileSyncStatus ",e);
			throw new AudienceException("E00002", e);
		}
		logger.info("End  : getProfileSyncStatus(dataSourceId)");
		return syncStatus;
	}
	
	
}

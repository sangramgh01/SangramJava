/**
 * AudienceMetadataServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceMetadataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceMetadataService;
import com.zetainteractive.zetahub.admin.audience.validator.PhysicalTableValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.ColumnStatCountBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 1, 2016 11:47:03 AM
 * @Version : 1.7
 * @Description : "AudienceMetadataServiceImpl" is used for service implementatin for Audience Meatadata(Physical Tables & Physical Columns)
 * 
 **/
@Component
public class AudienceMetadataServiceImpl implements AudienceMetadataService {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	private AudienceMetadataDAO audienceMetadataDAO;
	@Autowired
	private AudienceDAO audienceDAO;
	@Autowired
	private PhysicalTableValidator physicalTableValidator;
	@Autowired
	MessageSource messageSource;

	/**
	 * Save audience metadata.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the long
	 * @throws AudienceException
	 *             the audienc
	 *             e exception
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Long savePhysicalTable(PhysicalTableBO physicalTableBO,BindingResult bindingResult) throws AudienceException {
		logger.debug("Begin ::  savePhysicalTable()");
		Long audienceId = 0L;
		try {
			physicalTableValidator.validate(physicalTableBO, bindingResult);
			if (!bindingResult.hasErrors()) {
				if(isPhysicalTableExistWithTableName(physicalTableBO.getPhysicalTableName())){
					throw new AudienceException("AU0042",null,Level.ERROR);
				}
				audienceId =  audienceMetadataDAO.savePhysicalTable(physicalTableBO);
			}
		} catch (AudienceException ex) {
			logger.error("Exception occured while saving the physical table record",ex);
			throw ex;
		}
		logger.debug("End :: savePhysicalTable()");
		return audienceId;
	}

	/**
	 * Update audience metadata.
	 *
	 * @param physicalTableBO
	 *            the physical table bo
	 * @return the boolean
	 * @throws AudienceException
	 *             the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean updatePhysicalTable(PhysicalTableBO physicalTableBO, BindingResult bindingResult)
			throws AudienceException {
		logger.debug("Begin :: updatePhysicalTable(physicalTableBO)");
		Boolean updateStatus = false;
		try {
			physicalTableValidator.validate(physicalTableBO, bindingResult);
			if(physicalTableBO.getPhysicalTableId()==null) {
				bindingResult.rejectValue("physicalTableId", messageSource.getMessage("AU0067",
						new Object[] { physicalTableBO.getDataSourceId() }, LocaleContextHolder.getLocale()));
			}
			if (!bindingResult.hasErrors()) {
				updateStatus = audienceMetadataDAO.updatePhysicalTable(physicalTableBO);
			}
		} catch (AudienceException ex) {
			logger.error("Exception occured while updating the physical table details", ex);
			throw ex;
		}
		logger.debug("End :: updatePhysicalTable()");
		return updateStatus;
	}

	/**
	 * 
	 * Method Name : deleteAudienceMetadata Description : The Method
	 * "deleteAudienceMetadata" is used for Date : Jul 1, 2016, 12:56:14 PM
	 * 
	 * @param physicalTableId
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean deletePhysicalTable(Long physicalTableId) throws AudienceException {
		logger.debug("Begin :: deletePhysicalTable(" + physicalTableId + ")");
		return audienceMetadataDAO.deletePhysicalTable(physicalTableId);
	}

	/**
	 * 
	 * Method Name : findAudienceMetadataByName Description : The Method
	 * "findAudienceMetadataByName" is used for Date : Jul 1, 2016, 1:03:39 PM
	 * 
	 * @param physicalTableName
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public PhysicalTableBO findPhysicalTableByName(String physicalTableName) throws AudienceException {
		logger.debug("Begin :: findPhysicalTableByName(" + physicalTableName + ")");
		return audienceMetadataDAO.findPhysicalTableByName(physicalTableName);
	}

	/**
	 * 
	 * Method Name : findAudienceMetadataById Description : The Method
	 * "findAudienceMetadataById" is used for Date : Jul 1, 2016, 1:03:39 PM
	 * 
	 * @param physicalTableId
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public PhysicalTableBO findPhysicalTableId(Long physicalTableId) throws AudienceException {
		logger.debug("Begin :: findPhysicalTableId(" + physicalTableId + ")");
		return audienceMetadataDAO.findPhysicalTableById(physicalTableId);
	}

	/**
	 * 
	 * Method Name : listAudienceMetadata Description : The Method
	 * "listAudienceMetadata" is used for Date : Jul 1, 2016, 1:03:39 PM
	 * 
	 * @param :
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<PhysicalTableBO> listPhysicalTables() throws AudienceException {
		logger.debug("Begin :: listPhysicalTables()");
		return audienceMetadataDAO.listPhysicalTables();
	}
	
	/**
	 * 
	 * Method Name 	: listStatingTables
	 * Description 		: The Method "listStatingTables" is used for 
	 * Date    			: Jul 13, 2016, 3:14:27 PM
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<PhysicalTableBO> listStatingTables() throws AudienceException {
		logger.debug("Begin :: listStatingTables()");
		String tableType = "STAGING";
		return audienceMetadataDAO.listPhysicalTablesByTableType(tableType);
	}
	
	/**
	 * Find physical columns by stating id.
	 *
	 * @param statingPhysicalTableId the stating physical table id
	 * @return the list
	 * @throws AudienceException the audience exception
	 */
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<PhysicalColumnBO> findPhysicalColumnsByStatingId(Long statingPhysicalTableId) throws AudienceException{
		logger.debug("Begin :: findPhysicalColumnsByStatingId()");
		List<PhysicalColumnBO> resultPhysicalColumnBOList = null;
		try {
			resultPhysicalColumnBOList = new ArrayList<PhysicalColumnBO>();
			PhysicalTableBO physicalTableBO = audienceMetadataDAO.findPhysicalTableById(statingPhysicalTableId);
			if(physicalTableBO != null) {
				resultPhysicalColumnBOList.addAll(physicalTableBO.getPhysicalColumns());
			}
			
		} catch (Exception e) {
			logger.error("Exception occured whilefinding physical columns by staging id", e);
			throw e;
		}
		logger.debug("Ends :: findPhysicalColumnsByStatingId()");
		return resultPhysicalColumnBOList;
		
	}

	/**
	 * 
	 * Method Name 	: findPhysicalTablesNotMappedInAudiences
	 * Description 		: The Method "findPhysicalTablesNotMappedInAudiences" is used for 
	 * Date    			: Jul 2, 2016, 12:38:30 PM
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<PhysicalTableBO> findPhysicalTablesNotMappedInAudiences(boolean isDimension) throws AudienceException {
		logger.debug("Begin :: findPhysicalTablesNotMappedInAudiences()");
		Set<Long> physicalIDMappedSet =new  HashSet<Long>();
		List<PhysicalTableBO> physicalTableBOList = null;
		try{
		List<AudienceBO> audienceList = audienceDAO.findAllAudience();
		for (AudienceBO audienceBO : audienceList) {
			List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
			for (LogicalTableBO logicalTableBO : logicalTableBOList) {
				if(logicalTableBO.getTableType()==0 || audienceBO.getAudienceType()==1)
					physicalIDMappedSet.add(logicalTableBO.getPhysicalTableId());
			}
		}
		physicalTableBOList = audienceMetadataDAO.findPhysicalTables(physicalIDMappedSet,isDimension);
		
		}catch(Exception e){
			logger.error("Exception occured while fetching physical tables not mapped in audiences",e);
			throw e;
		}
		logger.debug("Ends :: findPhysicalTablesNotMappedInAudiences()");
	  return physicalTableBOList;	
	}

	/**
	 * 
	 * Method Name 	: isPhysicalTableExistWithTableName
	 * Description 		: The Method "isPhysicalTableExistWithTableName" is used for 
	 * Date    			: Jul 4, 2016, 6:45:03 PM
	 * @param physicalTableName
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isPhysicalTableExistWithTableName(String physicalTableName) throws AudienceException {
		logger.debug("Begin  :: isPhysicalTableExistWithTableName("+physicalTableName+")");
		Boolean status = false;
		try {
			PhysicalTableBO  physicalTableBO = audienceMetadataDAO.findPhysicalTableByName(physicalTableName);
			if(physicalTableBO!= null){
				status = true;
			}
				
		} catch (Exception e) {
			logger.error(Constants.EXCEPTION, e);
			throw e;  
		}
		logger.debug("End :: isPhysicalTableExistWithTableName()");
		return status;
	}

	/**
	 * 
	 * Method Name 	: isPhysicalColumnExistWithColumnName
	 * Description 		: The Method "isPhysicalColumnExistWithColumnName" is used for 
	 * Date    			: Jul 4, 2016, 6:45:03 PM
	 * @param physicalColumnName
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isPhysicalColumnExistWithColumnName(String physicalColumnName) throws AudienceException {
		logger.debug("Begin :: isPhysicalColumnExistWithColumnName("+physicalColumnName+")");
		Boolean isExists= false;
		try {
			List<PhysicalTableBO> physicalTableList = audienceMetadataDAO.listPhysicalTables();
			physicalTableOuterLoop:
			for (PhysicalTableBO physicalTableBO : physicalTableList) {
				List<PhysicalColumnBO> physicalColumnList = physicalTableBO.getPhysicalColumns();
				for (PhysicalColumnBO physicalColumnBO : physicalColumnList) {
					if(physicalColumnBO.getPhysicalColumnName().equalsIgnoreCase(physicalColumnName)){
						isExists =true;
						break physicalTableOuterLoop;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while checking physical column exists",e);
			throw e;
		}
		return isExists;
		
	}
	
	/**
	 * Gets the stats counts list.
	 *
	 * @param physicalTableId the physical table id
	 * @param physicalColumnName the physical Column Name
	 * @return the stats counts list
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<ColumnStatCountBO> getStatsCountsList(Long physicalTableId, String physicalColumnName) throws AudienceException {
		logger.debug("Begin :: getStatsCountsList()");
		LinkedList<ColumnStatCountBO> resultStatsCountList = new LinkedList<ColumnStatCountBO>();
		try {
			PhysicalTableBO physicalTableBO = audienceMetadataDAO.findPhysicalTableById(physicalTableId);
			List<PhysicalColumnBO> physicalColumnBOList = physicalTableBO.getPhysicalColumns();
			for (PhysicalColumnBO physicalColumnBO : physicalColumnBOList) {
				if(physicalColumnBO!= null) {
					if(physicalColumnBO.getPhysicalColumnName().equalsIgnoreCase(physicalColumnName)){
						if(physicalColumnBO.getColumnStatCounts() != null){
							resultStatsCountList.addAll(physicalColumnBO.getColumnStatCounts());
						}
					}
				}
			}
		} catch (AudienceException ae) {
			logger.error("Exception occured while fetching the Column stat counts",ae);
			throw ae;
		}
		//Commented below block on 15-Feb-18 ZHPE-13509
		/*int maxFetchCount = 2501;
		try 
		{
			maxFetchCount = ZetaUtil.getHelper().getConfig().getConfigValueInt("profile-column-max-count", 2500)+1;
		} catch (Exception e)
		{
			logger.error("Unable to fetch max profile column fetch config property..",e);
		}
		if(resultStatsCountList.size()==maxFetchCount)
		{
			resultStatsCountList.removeLast();
		}*/
		logger.debug("End :: getStatsCountsList()");
		return resultStatsCountList;
		
	}
	
	
}

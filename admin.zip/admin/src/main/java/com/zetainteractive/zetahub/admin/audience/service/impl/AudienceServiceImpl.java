/**
 * AudienceServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceDAO;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceMetadataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceService;
import com.zetainteractive.zetahub.admin.audience.validator.AudienceValidator;
import com.zetainteractive.zetahub.admin.dao.DepartmentDao;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.AudienceKeyColumnsBO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.DimensionColumnMappingBO;
import com.zetainteractive.zetahub.commons.domain.KeyColumnsMappingBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 1, 2016 1:18:31 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceServiceImpl" is used for for Audience (Audience, Logical Tables, Logical Columns & Fact dimension) details persistence
 * 
 **/
@Component
public class AudienceServiceImpl implements AudienceService{
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	private AudienceDAO audienceDAO;
	@Autowired
	private AudienceValidator audienceValidator;
	@Autowired
	private ListingCriteriaValidator listingCriteriaValidator;
	@Autowired
	private AudienceMetadataDAO audienceMetadataDAO;
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	DepartmentDao departmentDao;
	/**
	 * 
	 * Method Name 	: saveAudience
	 * Description 		: The Method "saveAudience" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @param audienceBO
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Long saveAudience(AudienceBO audienceBO,BindingResult bindingResult) throws AudienceException {
		logger.info("Begin: saveAudience()");
		Long audienceId = 0L;
		try {
			audienceValidator.validate(audienceBO, bindingResult);
			if (!bindingResult.hasErrors()) {
				if(audienceDAO.isAudiencesNameExists(audienceBO.getAudienceName())){
					throw new AudienceException("AU0011",null,Level.ERROR);
				}
				if(audienceBO.getIsDefault() != 'Y' || audienceBO.getIsDefault() != 'N') {
					audienceBO.setIsDefault('N');
				}
				audienceId =  audienceDAO.saveAudience(audienceBO);
			}
		} catch (AudienceException ex) {
			logger.error("Exception occured while saving the Audience details",ex);
			throw ex;
		}
		logger.info("End: saveAudience()");
		return audienceId;
	}

	/**
	 * 
	 * Method Name 	: updateAudience
	 * Description 		: The Method "updateAudience" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @param audienceBO
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean updateAudience(AudienceBO audienceBO,BindingResult bindingResult) throws AudienceException {
		logger.info("Begin: updateAudience()");
		Boolean updateStatus = false;
		Timestamp updateDate = new Timestamp(System.currentTimeMillis());
		try {
			UserBO userBO = ZetaUtil.getHelper().getUser();
			audienceValidator.validate(audienceBO, bindingResult);
			if(audienceBO.getAudienceId()==null) {
				bindingResult.rejectValue("audienceId", messageSource.getMessage("AU0053",
						new Object[] { audienceBO.getAudienceId() }, LocaleContextHolder.getLocale()));
			}
			AudienceBO existingAudienceBO =  findAudienceById(audienceBO.getAudienceId()) ;
			List<LogicalColumnBO> existingBaseLogicalColumns =getBaseLogicalColumnsListByAudience(existingAudienceBO);
			List<LogicalTableBO> logicalTableList = audienceBO.getLogicalTables();
			// Key Column changes validation starts..			
			if (!bindingResult.hasErrors()) {
				for(LogicalColumnBO existinglogicalcolumnBO:existingBaseLogicalColumns){
					//logUpdatedChanges(existinglogicalcolumnBO,logicalTableList);
					if(existinglogicalcolumnBO.getIsKeyColumn()=='Y'){
						for(LogicalTableBO logicalTableBO:logicalTableList){
							if(logicalTableBO.getTableType().equals(0)){
								for(LogicalColumnBO logicalcolumnBO:(logicalTableBO.getLogicalColumns())){
									if(logicalcolumnBO.getIsKeyColumn()!='Y' && (logicalcolumnBO.getPhysicalColumnName()).equals(existinglogicalcolumnBO.getPhysicalColumnName()) ){
										for(LogicalTableBO seconlogicalTableBO :logicalTableList){
											List<DimensionColumnMappingBO> listDimensionColumnMappingBOs=seconlogicalTableBO.getDimensionColumnMappings();
											if(listDimensionColumnMappingBOs!=null){
												for(DimensionColumnMappingBO dimensionColumnMappingBO:listDimensionColumnMappingBOs){
													if(dimensionColumnMappingBO.getBaseLogicalColumnName().equals(logicalcolumnBO.getPhysicalColumnName())){
														throw new AudienceException("AU0080");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				// Key Column changes validation end.				
               //Comparison starts for updating "baseLogicalColumnName" in "dimensionColumnMappings" when changed existing audience logical name
				List<LogicalColumnBO> baseLogicalColumns=getBaseLogicalColumnsListByAudience(audienceBO);
				if (!bindingResult.hasErrors()) {
					for(LogicalColumnBO existingBaseLogicalColumnBO:existingBaseLogicalColumns){
						for(LogicalColumnBO baseLogicalColumnBO:baseLogicalColumns){
							if((existingBaseLogicalColumnBO.getPhysicalColumnName().equals(baseLogicalColumnBO.getPhysicalColumnName()) ) && (!(existingBaseLogicalColumnBO.getLogicalColumnName()).equals(baseLogicalColumnBO.getLogicalColumnName()))){
								for(LogicalTableBO logicalTableBO:logicalTableList){
									if(logicalTableBO.getTableType()==Constants.DIMENTION_TABLE ){
										for(DimensionColumnMappingBO dimensionColumnMappingBO:logicalTableBO.getDimensionColumnMappings()){
											if(dimensionColumnMappingBO.getBaseLogicalColumnName().equals(existingBaseLogicalColumnBO.getLogicalColumnName())){
												dimensionColumnMappingBO.setBaseLogicalColumnName(baseLogicalColumnBO.getLogicalColumnName());
											}
										}
									}
								}
							}
						}
					}
				}
				//Base table logical column change updation ends.				
				for (LogicalTableBO logicalTableBO : logicalTableList){
				if(!isLogicalTableNameExists(logicalTableBO.getLogicalTableName())){
					logicalTableBO.setCreateDate(updateDate);
					logicalTableBO.setCreatedBy(userBO != null ?  userBO.getUserName() : Constants.ADMIN);
				}
				if(logicalTableBO.getPhysicalTableId() != null && logicalTableBO.getPhysicalTableId() > 0){
					PhysicalTableBO ptBO = audienceMetadataDAO.findPhysicalTableById(logicalTableBO.getPhysicalTableId());
					if(ptBO!=null) {
						logicalTableBO.setPhysicalTableName(ptBO.getPhysicalTableName());
					}
				}
				
			}
			if(audienceBO.getIsDefault() != 'Y' || audienceBO.getIsDefault() != 'N') {
				audienceBO.setIsDefault('N');
			}
			updateStatus = audienceDAO.updateAudience(audienceBO);
			
			}
		} catch (AudienceException ex) {
			logger.error("Exception occured while updating the Audience details",ex);
			throw ex;
		}catch (Exception ex) {
			logger.error("Exception occured while updating the Audience details",ex);
			throw new AudienceException("E00002");
		}
		logger.info("End: updateAudience()");
		return updateStatus;
	}

	/*private void logUpdatedChanges(LogicalColumnBO existinglogicalcolumnBO, List<LogicalTableBO> logicalTableList) {
		try{
		for (LogicalTableBO logicalTableBO : logicalTableList) {
			for (LogicalColumnBO logicalcolumnBO : (logicalTableBO.getLogicalColumns())) {
				if (existinglogicalcolumnBO.getPhysicalColumnName().equals(logicalcolumnBO.getPhysicalColumnName())) {
					if (!(logicalcolumnBO.getLogicalColumnName()
							.equals(existinglogicalcolumnBO.getLogicalColumnName()))) {
						logger.info("Updated logical column name from :"
								+ existinglogicalcolumnBO.getLogicalColumnName() + ", to:"
								+ logicalcolumnBO.getLogicalColumnName());
					}
					if ((logicalcolumnBO.getIsKeyColumn() != (existinglogicalcolumnBO.getIsKeyColumn()))) {
						logger.info("Updated " + logicalcolumnBO.getLogicalColumnName()
								+ " column Key attribute from:" + existinglogicalcolumnBO.getIsKeyColumn()
								+ ", to : " + logicalcolumnBO.getIsKeyColumn());
					}
					if ((logicalcolumnBO.getIsProfilable() != (existinglogicalcolumnBO.getIsProfilable()))) {
						logger.info("Updated " + logicalcolumnBO.getLogicalColumnName()
								+ " column isProfilable from:" + existinglogicalcolumnBO.getIsProfilable()
								+ " , to : " + logicalcolumnBO.getIsProfilable());
					}
				}
			}
		}
		}
		catch(Exception e){
			logger.error("Exception occured while logUpdatedChanges", e);
		}
	}*/

	/**
	 * 
	 * Method Name 	: deleteAudience
	 * Description 		: The Method "deleteAudience" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean deleteAudience(Long audienceId) throws AudienceException {
		logger.info("Begin: deleteAudience()");
		Boolean deleteStatus = false;
		try {
			if (audienceId != null && audienceId > 0) {
				AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
				if (audienceBO == null) {
					throw new AudienceException("AU0048");
				}
				deleteStatus = audienceDAO.deleteAudience(audienceId);
			} else {
				throw new AudienceException("AU0047");
			}

		} catch (Exception ex) {
			logger.error("Exception occured while deleting the Audience details", ex);
			throw ex;
		}
		logger.info("Ends : deleteAudience()");
		return deleteStatus;
	}

	/**
	 * 
	 * Method Name 	: findAudienceByName
	 * Description 		: The Method "findAudienceByName" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @param audienceName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public AudienceBO findAudienceByName(String audienceName) throws AudienceException {
		logger.debug("Begin : findAudienceByName()");
		AudienceBO audienceBO = null;
		try {
			if (audienceName != null && !audienceName.isEmpty()) {
				audienceBO = audienceDAO.findAudienceByName(audienceName);
				if (audienceBO == null) {
					throw new AudienceException("AU0049");
				}
			} else {
				throw new AudienceException("AU0047");
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Audience details", ex);
			throw ex;
		}
		logger.debug("Ends : findAudienceByName()");
		return audienceBO;
	}

	/**
	 * 
	 * Method Name 	: findAudienceById
	 * Description 		: The Method "findAudienceById" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public AudienceBO findAudienceById(Long audienceId) throws AudienceException {
		logger.debug("Begin : findAudienceById()");
		AudienceBO audienceBO = null;
		try {
			logger.debug("Audience ID ::" + audienceId);
			if (audienceId != null && audienceId > 0) {
				audienceBO = audienceDAO.findAudienceById(audienceId);
				if (audienceBO == null) {
					throw new AudienceException("AU0048");
				}
				Collections.sort(audienceBO.getLogicalTables(), new DateComaparator<Object>());
				for (LogicalTableBO logicalTableBO : audienceBO.getLogicalTables()) {
					Collections.sort(logicalTableBO.getLogicalColumns(), new LogicalColumnsComaparator<Object>());
				}
			} else {
				throw new AudienceException("AU0047");
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Audience details by ID", ex);
			if (ex instanceof AudienceException) {
				AudienceException e = (AudienceException) ex;
				throw new AudienceException(e.getErrorCode());
			} else {
				throw ex;
			}
		}
		logger.debug("Ends : findAudienceById()");
		return audienceBO;
	}
	
	/**
	 * 
	 * @author Sailaja.Sama
	 *
	 * @param <T>
	 */
	class DateComaparator<T extends Object> implements Comparator<T> {
		@Override
		public int compare(T arg0, T arg1) {
			if (arg0 instanceof LogicalTableBO && arg1 instanceof LogicalTableBO) {
				return ((LogicalTableBO) arg0).getCreateDate().compareTo(((LogicalTableBO) arg1).getCreateDate());
			} 
			return 0;
		}

	}

	/**
	 * 
	 * Method Name 	: listAudience
	 * Description 		: The Method "listAudience" is used for 
	 * Date    			: Jul 1, 2016, 2:08:09 PM
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<AudienceBO> listAudience(Long departmentId) throws AudienceException {
		List<AudienceBO> audienceBos = null;
		try{
			List<Long> audienceIDs=getDepartmentSpecificAudienceIds(departmentId);
			if(audienceIDs != null && !audienceIDs.isEmpty())
				audienceBos = audienceDAO.findAllAudience(audienceIDs);
			if(audienceBos != null && !audienceBos.isEmpty()){
				for(AudienceBO audience : audienceBos){
					if(audience.getAudienceName()!=null)
						audience.setAudienceName(Jsoup.clean(audience.getAudienceName(), Whitelist.none()));
					if(audience.getCreatedBy()!=null)
						audience.setCreatedBy(Jsoup.clean(audience.getCreatedBy(), Whitelist.none()));
					if(audience.getUpdatedBy()!=null)
						audience.setUpdatedBy(Jsoup.clean(audience.getUpdatedBy(), Whitelist.none()));
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the listAudience() ", ex);
			if (ex instanceof AudienceException) {
				AudienceException e = (AudienceException) ex;
				throw new AudienceException(e.getErrorCode());
			} else {
				try {
					throw ex;
				} catch (Exception e) {
					logger.error(e.getMessage(),e);
				}
			}
		}
		return audienceBos;
	}
	
	public List<AudienceBO> listAudience() throws AudienceException{
		return audienceDAO.findAllAudience();
	}
	/**
	 * 
	 * Method Name 	: isAudiencesNameExists
	 * Description 		: The Method "isAudiencesNameExists" is used for 
	 * Date    			: Jul 4, 2016, 6:25:04 PM
	 * @param audienceName
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isAudiencesNameExists(String audienceName) throws AudienceException {
		logger.debug("Begin : isAudiencesNameExists()");
		Boolean isExists = false;
		try {
			logger.debug("Audience Name ---->" + audienceName);
			if (audienceName != null && !audienceName.isEmpty()) {
				isExists = audienceDAO.isAudiencesNameExists(audienceName);
			} else {
				throw new AudienceException("AU0047");
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Audience details by Name", ex);
			throw ex;
		}
		return isExists;
	}
	
	/**
	 * Checks if is audiences name exists by name and id.
	 *
	 * @param audienceName the audience name
	 * @param audienceId the audience id
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isAudiencesNameExistsByNameAndId(String audienceName, Long audienceId) throws AudienceException {
		logger.debug("Begin : isAudiencesNameExistsByNameAndId()");
		Boolean isExists = false;
		try {
			logger.debug("Audience Name ::" + audienceName);
			if (audienceName != null && !audienceName.isEmpty()) {
				isExists = audienceDAO.isAudiencesNameExistsWithNameAndId(audienceName, audienceId);
			} else {
				throw new AudienceException("AU0047");
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Audience details by Name", ex);
			throw ex;
		}
		return isExists;
	}

	/**
	 * 
	 * Method Name 	: isLogicalTableNameExists
	 * Description 		: The Method "isLogicalTableNameExists" is used for 
	 * Date    			: Jul 4, 2016, 7:15:07 PM
	 * @param logicalTableName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isLogicalTableNameExists(String logicalTableName) throws AudienceException {
		Boolean isExists = false;
		try {
			List<AudienceBO> audienceList = audienceDAO.findAllAudience();
			audienceOuterLoop: for (AudienceBO audienceBO : audienceList) {
				List<LogicalTableBO> logicalTableList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableList) {
					if (logicalTableBO.getLogicalTableName().equalsIgnoreCase(logicalTableName)) {
						isExists = true;
						break audienceOuterLoop;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while checking the logical table exists ::",e);
			throw e;
		}
		return isExists;
	}

	/**
	 * 
	 * Method Name : isLogicalColumnNameExists Description : The Method
	 * "isLogicalColumnNameExists" is used for Date : Jul 4, 2016, 7:15:08 PM
	 * 
	 * @param logicalColumnName
	 * @return
	 * @throws AudienceException
	 */

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean isLogicalColumnNameExists(String logicalColumnName) throws AudienceException {
		Boolean isExists = false;
		try {
			List<AudienceBO> audienceList = audienceDAO.findAllAudience();
			audienceOuterLoop: for (AudienceBO audienceBO : audienceList) {
				List<LogicalTableBO> logicalTableList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableList) {
					List<LogicalColumnBO> logicalColumnList = logicalTableBO.getLogicalColumns();
					for (LogicalColumnBO logicalColumnBO : logicalColumnList) {
						if (logicalColumnBO.getLogicalColumnName().equalsIgnoreCase(logicalColumnName)) {
							isExists = true;
							break audienceOuterLoop;
						}
					}

				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while fetching the Logical columns details",e);
			throw e;
		}
		return isExists;
	}
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @param physicalTableId the physical table id
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndPhyTableId(Long audienceId, Long physicalTableId) throws AudienceException{
		logger.debug("Begin : getLogicalColumnsByAudienceIdAndPhyTableId()");
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			logger.debug("AudienceID:"+audienceId+" : PhysicalTableId:"+physicalTableId);
			resultLogicalColumnBOList = new ArrayList<LogicalColumnBO>();
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if(audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableBOList) {
					if(logicalTableBO.getPhysicalTableId().equals(physicalTableId)){
						resultLogicalColumnBOList.addAll(logicalTableBO.getLogicalColumns());
					}
				}
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.info("End : getLogicalColumnsByAudienceIdAndPhyTableId()");
		return resultLogicalColumnBOList;
	}
	
	/**
	 * Gets the logical columns by audience id and phy table id.
	 *
	 * @param audienceId the audience id
	 * @param physicalTableId the physical table id
	 * @return the logical columns by audience id and phy table id
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndPhyTableName(Long audienceId, String physicalTableName)
			throws AudienceException {
		logger.debug("Begin : getLogicalColumnsByAudienceIdAndPhyTableName()");
		try {
			logger.info("AudienceID:" + audienceId + " : PhysicalTableName:" + physicalTableName);
			PhysicalTableBO physicalTableBO = audienceMetadataDAO.findPhysicalTableByName(physicalTableName);
			return getLogicalColumnsByAudienceIdAndPhyTableId(audienceId, physicalTableBO.getPhysicalTableId());
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION, ex);
			throw ex;
		}
	}
	
	
	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceId
	 * Description 		: The Method "getLogicalColumnsByAudienceId" is used for 
	 * Date    			: Jul 13, 2016, 6:20:43 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalColumnBO> getLogicalColumnsByAudienceId(Long audienceId) throws AudienceException{
		logger.debug("Begin : getLogicalColumnsByAudienceId()");
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			logger.debug("AudienceID:"+audienceId);
			resultLogicalColumnBOList = new ArrayList<LogicalColumnBO>();
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if(audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableBOList) {
						resultLogicalColumnBOList.addAll(logicalTableBO.getLogicalColumns());
				}
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION+"getLogicalColumnsByAudienceId()",ex);
			throw ex;
		}
		logger.info("End : getLogicalColumnsByAudienceId()");
		return resultLogicalColumnBOList;
	}
	
	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceId
	 * Description 		: The Method "getLogicalColumnsByAudienceId" is used for 
	 * Date    			: Jul 13, 2016, 6:20:43 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalColumnBO> getBaseLogicalColumnsByAudienceId(Long audienceId) throws AudienceException {
		logger.debug("Begin : getLogicalColumnsByAudienceId()");
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			logger.debug("AudienceID:" + audienceId);
			resultLogicalColumnBOList = new ArrayList<LogicalColumnBO>();
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				resultLogicalColumnBOList=getBaseLogicalColumnsListByAudience(audienceBO);
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.info("End : getLogicalColumnsByAudienceId()");
		return resultLogicalColumnBOList;
	}
	
	
	/**
	 * 
	 * Method Name 	: getDimensionTablesByAudienceId
	 * Description 		: The Method "getDimensionTablesByAudienceId" is used for 
	 * Date    			: Jul 20, 2016, 12:19:21 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalTableBO> getDimensionTablesByAudienceId(Long audienceId) throws AudienceException {
		logger.debug("Begin: getDimensionTablesByAudienceId()");
		List<LogicalTableBO> resultLogicalTableBOList = null;
		try {
			logger.debug("AudienceID:" + audienceId);
			resultLogicalTableBOList = new ArrayList<LogicalTableBO>();
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableBOList) {
					if (logicalTableBO.getTableType() == Constants.DIMENTION_TABLE) {
						resultLogicalTableBOList.add(logicalTableBO);
					}
				}
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.debug("End: getDimensionTablesByAudienceId()");
		return resultLogicalTableBOList;
	}
	
	/**
	 * Gets the receipent table by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the receipent table by audience id
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public LogicalTableBO getReceipentTableByAudienceId(Long audienceId) throws AudienceException {
		logger.debug("Begin: getReceipentTableByAudienceId()");
		LogicalTableBO resultLogicalTableBO= null;
		try {
			logger.info("AudienceID:" + audienceId);
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				resultLogicalTableBO = logicalTableBOList.stream()				   // Convert to steam
						.filter(x -> x.getTableType()== Constants.BASE_TABLE)	// 
						.findAny()									// If 'findAny' then return found
						.orElse(null);
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.debug("End: getReceipentTableByAudienceId()");
		return resultLogicalTableBO;
	}
	
	/**
	 * Gets the logical columns with nullable falg by audience id.
	 *
	 * @param audienceId the audience id
	 * @return the logical columns with nullable falg by audience id
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public AudienceBO getLogicalColumnsWithNullableFalgByAudienceId(Long audienceId) throws AudienceException {
		logger.debug("Begin: getLogicalColumnsWithNullableFalgByAudienceId()");
		String physicalTableName = null;
		AudienceBO audienceBO=null;
		List<LogicalTableBO> logicalTableBOList=null;
		PhysicalColumnBO physicalColumnBO = null;
		try {
			logger.debug("AudienceID:" + audienceId);
			audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO resultLogicalTableBO : logicalTableBOList){
					physicalTableName = resultLogicalTableBO.getPhysicalTableName();
					PhysicalTableBO phyTableBO = audienceMetadataDAO.findPhysicalTableByName(physicalTableName);
					List<LogicalColumnBO> logicalColumnList = resultLogicalTableBO.getLogicalColumns();
					for (LogicalColumnBO logicalColumnBO : logicalColumnList) {
						physicalColumnBO = getPhysicalColumnByColumn(phyTableBO, logicalColumnBO.getPhysicalColumnName());
						if (physicalColumnBO.getIsNullable() == Constants.YES) {
							logicalColumnBO.setPhysicalColumnNullable('Y');
						} else {
							logicalColumnBO.setPhysicalColumnNullable('N');
						}
						logicalColumnBO.setPhysicalColumnDataLength(physicalColumnBO.getColumnDataLength());
						logicalColumnBO.setColumnDefaultValue(physicalColumnBO.getColumnDefaultValue());
					}
				}
			}
			audienceBO.setLogicalTables(logicalTableBOList);
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.debug("End: getLogicalColumnsWithNullableFalgByAudienceId()");
		return audienceBO;
	}
	
	

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public AudienceBO getLogicalColumnsWithNullableFalgByAudienceName(String audienceName) throws AudienceException {
		logger.debug("Begin: getLogicalColumnsWithNullableFalgByAudienceName()");
		String physicalTableName = null;
		AudienceBO audienceBO=null;
		PhysicalColumnBO physicalColumnBO = null;
		try {
			logger.debug("AudienceID:" + audienceName);
			audienceBO = audienceDAO.findAudienceByName(audienceName);
			if (audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO resultLogicalTableBO : logicalTableBOList){
					physicalTableName = resultLogicalTableBO.getPhysicalTableName();
					PhysicalTableBO phyTableBO = audienceMetadataDAO.findPhysicalTableByName(physicalTableName);
					List<LogicalColumnBO> logicalColumnList = resultLogicalTableBO.getLogicalColumns();
					for (LogicalColumnBO logicalColumnBO : logicalColumnList) {
						physicalColumnBO = getPhysicalColumnByColumn(phyTableBO, logicalColumnBO.getPhysicalColumnName());
						if (physicalColumnBO.getIsNullable() == Constants.YES) {
							logicalColumnBO.setPhysicalColumnNullable('Y');
						} else {
							logicalColumnBO.setPhysicalColumnNullable('N');
						}
						logicalColumnBO.setPhysicalColumnDataLength(physicalColumnBO.getColumnDataLength());
						logicalColumnBO.setColumnDefaultValue(physicalColumnBO.getColumnDefaultValue());
					}
				}
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		logger.debug("End: getLogicalColumnsWithNullableFalgByAudienceName()");
		return audienceBO;
	}
	
	/**
	 * Gets the physical column by column.
	 *
	 * @param phyTableBO the phy table bo
	 * @param columnName the column name
	 * @return the physical column by column
	 */
	public PhysicalColumnBO getPhysicalColumnByColumn(PhysicalTableBO phyTableBO,String columnName){
		PhysicalColumnBO physicalColumnBO = null;
		try {
			
			List<PhysicalColumnBO> physicalColumnList = phyTableBO.getPhysicalColumns();
			physicalColumnBO = physicalColumnList.stream()				   // Convert to steam
					.filter(x -> x.getPhysicalColumnName().equalsIgnoreCase(columnName))	// 
					.findAny()									// If 'findAny' then return found
					.orElse(null);
					
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		return physicalColumnBO;
	}


	/**
	 * 
	 * Method Name 	: findAllAudiences
	 * Description 		: The Method "findAllAudiences" is used for 
	 * Date    			: Jul 6, 2016, 8:12:02 PM
	 * @param listingCriteria
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<AudienceBO> findAllAudiences(AudienceSearchCriteria listingCriteria,BindingResult bindingResult) throws AudienceException {
		List<AudienceBO> audienceList = null;
		try {
			listingCriteriaValidator.validate(listingCriteria, bindingResult);
			if (!bindingResult.hasErrors()) {
				if(listingCriteria.getDepartmentId() != null &&  listingCriteria.getDepartmentId() >0){
					List<Long> audienceIds=getDepartmentSpecificAudienceIds(listingCriteria.getDepartmentId());
					if(audienceIds != null && !audienceIds.isEmpty()){
						listingCriteria.setAudienceIds(audienceIds);
						audienceList =  audienceDAO.findAllAudiences(listingCriteria);
					}
				}else 
					throw new AudienceException("AU0081");
					
			}
		}catch(AudienceException ax){
			throw ax;
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw ex;
		}
		return audienceList;
	}

	/**
	 * 
	 * Method Name 	: getLogicalColumnsByAudienceIdAndLogicalTableName
	 * Description 		: The Method "getLogicalColumnsByAudienceIdAndLogicalTableName" is used for 
	 * Date    			: Jul 13, 2016, 2:20:55 PM
	 * @param audienceId
	 * @param logicalTableName
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<LogicalColumnBO> getLogicalColumnsByAudienceIdAndLogicalTableName(Long audienceId,
			String logicalTableName) throws AudienceException {
		logger.debug("Begin: getLogicalColumnsByAudienceIdAndLogicalTableName()");
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		try {
			logger.debug("AudienceID:" + audienceId + " : Logical Table Name:" + logicalTableName);
			resultLogicalColumnBOList = new ArrayList<LogicalColumnBO>();
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTableBOList) {
					if (logicalTableBO.getLogicalTableName().equalsIgnoreCase(logicalTableName)) {
						resultLogicalColumnBOList.addAll(logicalTableBO.getLogicalColumns());
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Logical columns details",ex);
			throw ex;
		}
		logger.debug("End: getLogicalColumnsByAudienceIdAndLogicalTableName()");
		return resultLogicalColumnBOList;
	}
	
	/**
	 * Gets the logical table by audience id and logical table name.
	 *
	 * @param audienceId the audience id
	 * @param logicalTableName the logical table name
	 * @return the logical table by audience id and logical table name
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public LogicalTableBO getLogicalTableByAudienceIdAndLogicalTableName(Long audienceId,
			String logicalTableName) throws AudienceException {
		logger.debug("Begin: getLogicalTableByAudienceIdAndLogicalTableName()");
		LogicalTableBO resultLogicalTableBO = null;
		try {
			logger.debug("AudienceID:" + audienceId + " : Logical Table Name:" + logicalTableName);
			AudienceBO audienceBO = audienceDAO.findAudienceById(audienceId);
			if (audienceBO != null) {
				List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
				resultLogicalTableBO = logicalTableBOList.stream()				   // Convert to steam
						.filter(x -> x.getLogicalTableName().equalsIgnoreCase(logicalTableName))	// 
						.findAny()									// If 'findAny' then return found
						.orElse(null);		
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the Logical table details",ex);
			throw ex;
		}
		logger.info("End: getLogicalTableByAudienceIdAndLogicalTableName()");
		return resultLogicalTableBO;
	}
	
	/**
	 * Delete dimention tables.
	 *
	 * @param audienceId the audience id
	 * @param physicalTableId the physical table id
	 * @return the boolean
	 * @throws AudienceException the audience exception
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Boolean deleteDimensionTables(Long audienceId,Long physicalTableId) throws AudienceException {
		logger.info("Begin: deleteDimentionTables()");
		Boolean updateStatus = false;
		LogicalTableBO logicalTableBOForDelete = null;
		try {
			logger.debug("Audience ID:"+audienceId+"-- PhysicalTableID :"+physicalTableId);
			AudienceBO audienceBO = findAudienceById(audienceId);
			if (audienceBO != null) {
				List<LogicalTableBO> logicalTablesBOList = audienceBO.getLogicalTables();
				for (LogicalTableBO logicalTableBO : logicalTablesBOList) {
					if(logicalTableBO.getTableType() == 1 && logicalTableBO.getPhysicalTableId().longValue() == physicalTableId.longValue()){
						logicalTableBOForDelete = logicalTableBO;
					}
				}
				/*updateStatus = logicalTablesBOList.removeIf(
						p -> p.getPhysicalTableId() == physicalTableId
						&& p.getTableType() == Constants.DIMENTION_TABLE);*/
				audienceBO.getLogicalTables().remove(logicalTableBOForDelete);
				audienceDAO.updateAudience(audienceBO);
				updateStatus = true;
			}
		} catch (Exception ex) {
			logger.error("Exception occured while deleting the dimention table details",ex);
			throw ex;
		}
		logger.info("End: deleteDimentionTables()");
		return updateStatus;
	}
	
	/**
	 * 
	 * Method Name 	: audiencesTotalCount
	 * Description 		: The Method "audiencesTotalCount" is used for 
	 * Date    			: Jul 13, 2016, 2:20:55 PM
	 * @param listingCriteria
	 * @return
	 * @throws AudienceException
	 */
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Long audiencesTotalCount(AudienceSearchCriteria listingCriteria) throws AudienceException {
		logger.debug("Begin: audiencesTotalCount()");
		Long audiencecount = null;
		try {
			logger.debug("AudienceSearchCriteria:" + listingCriteria);
			if(listingCriteria.getDepartmentId() != null &&  listingCriteria.getDepartmentId() >0){
				List<Long> audienceIds=getDepartmentSpecificAudienceIds(listingCriteria.getDepartmentId());
				if(listingCriteria.getNameLike()==null)
					listingCriteria.setNameLike("");
				/*My SQL Wild Card Characters in Like Operator*/
				listingCriteria.setNameLike(listingCriteria.getNameLike().replaceAll("_","\\\\_"));
				listingCriteria.setNameLike(listingCriteria.getNameLike().replaceAll("%","\\\\%"));
				if(audienceIds != null && !audienceIds.isEmpty()){
					listingCriteria.setAudienceIds(audienceIds);
					audiencecount = audienceDAO.audiencesTotalCount(listingCriteria);
				}
			}else
				throw new AudienceException("AU0081");
		} catch (Exception ex) {
			logger.error("Exception occured while audience count", ex);
			throw ex;
		}
		logger.debug("End: audiencesTotalCount()");
		return audiencecount;
	}

	/**
	 * 
	 * Method Name 	: getKeyColumnsByAudienceId
	 * Description 		: The Method "getKeyColumnsByAudienceId" is used for 
	 * Date    			: Aug 12, 2016, 1:48:11 PM
	 * @param audienceId
	 * @return
	 * @throws AudienceException
	 */
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public AudienceKeyColumnsBO getKeyColumnsByAudienceId(Long audienceId,String logicalTableName) throws AudienceException {
		logger.debug("Begin: getKeyColumnsByAudienceId()");
		List<KeyColumnsMappingBO> keyColumnsMappingBOList = null;
		AudienceKeyColumnsBO audienceKeyColumnsBO = null;
		KeyColumnsMappingBO keyColumnsMappingBO = null;
		try {
			logger.info("audienceId ::"+audienceId+" :: logicalTableName ::"+logicalTableName);
			LogicalTableBO baseLogicalTableBO = getReceipentTableByAudienceId(audienceId);
			
			List<LogicalTableBO> dimensionTablesList = getDimensionTablesByAudienceId(audienceId);
			LogicalTableBO dimensionTableBO = dimensionTablesList.stream() // to
					.filter(x -> x.getLogicalTableName().equalsIgnoreCase(logicalTableName)) //
					.findAny() // If 'findAny' then return found
					.orElse(null);
			if(dimensionTableBO != null) {
			
				audienceKeyColumnsBO =  new AudienceKeyColumnsBO();
				audienceKeyColumnsBO.setTableType("D");
				audienceKeyColumnsBO.setPhysicalTableId(dimensionTableBO.getPhysicalTableId());
				audienceKeyColumnsBO.setPhysicalTableName(dimensionTableBO.getPhysicalTableName());
				keyColumnsMappingBOList = new ArrayList<KeyColumnsMappingBO>();
				
				List<DimensionColumnMappingBO> dimensionColMappingBOList = dimensionTableBO.getDimensionColumnMappings();
				
				for (DimensionColumnMappingBO dimensionColumnMappingBO : dimensionColMappingBOList) {
						keyColumnsMappingBO = new KeyColumnsMappingBO();
						keyColumnsMappingBO.setDimensionPhysicalColumnName(
								getPhysicalColumnName(dimensionTableBO.getLogicalColumns(),
										dimensionColumnMappingBO.getDimensionColumnName()));
						keyColumnsMappingBO.setBasePhysicalColumnName(
								getPhysicalColumnName(baseLogicalTableBO.getLogicalColumns(),
										dimensionColumnMappingBO.getBaseLogicalColumnName()));
						keyColumnsMappingBOList.add(keyColumnsMappingBO);
				}
				audienceKeyColumnsBO.setKeyColumnsMappings(keyColumnsMappingBOList);
			}else{
				logger.info("Dimension table details not found with provided logical table name :"+logicalTableName);
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the key column details by audience id",ex);
			throw ex;
		}
		return audienceKeyColumnsBO;
	}
	
	/**
	 * Gets the physical column name.
	 *
	 * @param object the object
	 * @param logicalColumnName the logical column name
	 * @return the physical column name
	 */
	private String getPhysicalColumnName(Object object, String logicalColumnName) {
		String physicalColumnName = null;
		try {
			List<LogicalColumnBO> logicalColumnBOList = (List<LogicalColumnBO>) object;
			LogicalColumnBO logicalColumnBO = logicalColumnBOList.stream() // Convert 																		// to
																			// steam
					.filter(x -> x.getLogicalColumnName().equalsIgnoreCase(logicalColumnName)) //
					.findAny() // If 'findAny' then return found
					.orElse(null);
			if (logicalColumnBO != null) {
				physicalColumnName = logicalColumnBO.getPhysicalColumnName();
			}
		} catch (Exception e) {
			logger.error("Exception occured while fetching the physical column details", e);
			throw e;
		}
		return physicalColumnName;
	}
	
	@Override
	public List<Map<String,Object>> getAudienceMetaDetails(){
		return audienceDAO.getAudienceMetaDetails();
	}
	@Override
	public Map<Long,String> getAudienceNamesByIds(List<Long> ids){
		return audienceDAO.getAudienceNamesByIds(ids);
	}
	
	private List<Long> getDepartmentSpecificAudienceIds(Long departmentId){
		DepartmentSettings departmentSettings=departmentDao.getDeptSpecificProperty(com.zetainteractive.zetahub.admin.constants.Constants.DEPARTMENT_AUDIENCE_KEY, departmentId);
		if(departmentSettings != null && departmentSettings.getObjectValue() != null && departmentSettings.getObjectValue() instanceof List<?>){
			List<DeptAudienceBO> audienceBOs=(List<DeptAudienceBO>)departmentSettings.getObjectValue();
			return audienceBOs.stream().map(DeptAudienceBO :: getAudienceId).collect(Collectors.toList());
		}
		return null;
	}
	private List<LogicalColumnBO> getBaseLogicalColumnsListByAudience(AudienceBO audienceBO){
		List<LogicalColumnBO> logicalColumnsList=new ArrayList<LogicalColumnBO>();
		List<LogicalTableBO> logicalTableBOList = audienceBO.getLogicalTables();
		for (LogicalTableBO logicalTableBO : logicalTableBOList) {
			if (logicalTableBO.getTableType() == Constants.BASE_TABLE) {
				logicalColumnsList.addAll(logicalTableBO.getLogicalColumns());
			}
		}
		return logicalColumnsList;
	}

	@Override
	public Map<String, Boolean> checkAudienceAssocation(Long audienceId) throws AudienceException {
		return audienceDAO.checkAudienceAssocation(audienceId);
	}
	
	class LogicalColumnsComaparator<T extends Object> implements Comparator<T> {
		@Override
		public int compare(T arg0, T arg1) {
			if (arg0 instanceof LogicalColumnBO && arg1 instanceof LogicalColumnBO) {
				return ((LogicalColumnBO) arg0).getLogicalColumnName().toLowerCase().compareTo(((LogicalColumnBO) arg1).getLogicalColumnName().toLowerCase());
			} 
			return 0;
		}
	}
}

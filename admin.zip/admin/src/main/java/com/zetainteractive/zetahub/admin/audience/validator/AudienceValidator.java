/**
 * AudienceValidator.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 11, 2016 4:51:56 PM
 * @Version	     : 1.7 
 * @Description  : "AudienceValidator" is used for  Audience validations
 * 
 **/
@Component
public class AudienceValidator implements Validator{
	
	@Autowired
	MessageSource messageSource;
	@Autowired
	LogicalTableValidator logicalTableValidator;
	/** The pattern. */
	private Pattern pattern;
	/** The matcher. */
	private Matcher matcher;
	/** The audience name pattern. */
	 
	private final String AUDIENCE_NAME_PATTERN = "([0-9|a-z|A-Z|\\_|\\$|\\.|\\!|\\@|\\^|\\&|\\*|\\(|\\)|\\-|\\?|\\<|\\>|\\s])+";
	private final String LOGICAL_TABLE_COLUMN_NAME_PATTERN=".*[\\$|\\,|\\{|\\}|\\/|\"|\'|\\+]+.*";
	/**
	 * 
	 * Method Name 	: supports
	 * Description 		: The Method "supports" is used for 
	 * Date    			: Jul 11, 2016, 4:52:09 PM
	 * @param clazz
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public boolean supports(Class<?> clazz) {
		return AudienceBO.class.equals(clazz);
	}

	/**
	 * 
	 * Method Name 	: validate
	 * Description 		: The Method "validate" is used for 
	 * Date    			: Jul 11, 2016, 4:52:09 PM
	 * @param target
	 * @param errors
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public void validate(Object target, Errors errors) {
		AudienceBO audienceBO = (AudienceBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "audienceName", messageSource
				.getMessage("AU0050", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "audienceType", messageSource
				.getMessage("AU0051", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "audienceStatus", messageSource
				.getMessage("AU0052", new Object[] {}, LocaleContextHolder.getLocale()));
		//Start Validation for LogicalTable Name and LogicalColumn Name
		if(audienceBO != null && audienceBO.getLogicalTables() != null){
			List<LogicalTableBO>  logicalTableList = audienceBO.getLogicalTables();
			for (int idx = 0; idx < audienceBO.getLogicalTables().size(); idx++ ) {
				LogicalTableBO logicalTableBO = logicalTableList.get(idx);
				if(logicalTableBO != null && logicalTableBO.getLogicalTableName() != null){
					pattern = Pattern.compile(LOGICAL_TABLE_COLUMN_NAME_PATTERN);
					matcher = pattern.matcher(logicalTableBO.getLogicalTableName());
					if (matcher.matches()) {
						errors.rejectValue("logicalTables", messageSource.getMessage("AU0077",
								new Object[] {logicalTableBO.getLogicalTableName()}, LocaleContextHolder.getLocale()));
					}
					if(logicalTableBO.getLogicalColumns() != null)
						for (int columnIndex = 0; columnIndex < logicalTableBO.getLogicalColumns().size(); columnIndex++) {
							logicalTableBO.getLogicalColumns().get(columnIndex).getLogicalColumnName();
							pattern = Pattern.compile(LOGICAL_TABLE_COLUMN_NAME_PATTERN);
							matcher = pattern.matcher(logicalTableBO.getLogicalColumns().get(columnIndex).getLogicalColumnName());
							if (matcher.matches()) {
								errors.rejectValue("logicalTables", messageSource.getMessage("AU0078",
										new Object[] {logicalTableBO.getLogicalColumns().get(columnIndex).getLogicalColumnName()}, LocaleContextHolder.getLocale()));
							}
						}
						
				}
			}
		}// end Validation for LogicalTable Name and LogicalColumn Name

		// input string conatains valid audience name format
		if (audienceBO.getAudienceName() != null) {
			pattern = Pattern.compile(AUDIENCE_NAME_PATTERN);
			matcher = pattern.matcher(audienceBO.getAudienceName());
			if (!matcher.matches()) {
				errors.rejectValue("audienceName", messageSource.getMessage("AU0054",
						new Object[] {}, LocaleContextHolder.getLocale()));
			}

			// input string can not exceed 100 char
			if (audienceBO.getAudienceName() != null & audienceBO.getAudienceName().length() > 100) {
				errors.rejectValue("audienceName", messageSource.getMessage("AU0055",
						new Object[] {}, LocaleContextHolder.getLocale()));
			}
		}
		// validate the Logical Column Table data
		for (int idx = 0; idx < audienceBO.getLogicalTables().size(); idx++) {
			errors.pushNestedPath("logicalTables[" + idx + "]");
			ValidationUtils.invokeValidator(logicalTableValidator, audienceBO.getLogicalTables().get(idx), errors);
			errors.popNestedPath();
		}
	}

}

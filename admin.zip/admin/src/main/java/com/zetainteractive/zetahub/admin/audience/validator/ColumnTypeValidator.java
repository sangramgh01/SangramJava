/**
 * ColumnTypeValidator.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.audience.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 11, 2016 4:39:02 PM
 * @Version : 1.7
 * @Description : "ColumnTypeValidator" is used for Column Type Model validation
 * 
 **/
@Component
public class ColumnTypeValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports Description : The Method "supports" is used for
	 * Date : Jul 11, 2016, 4:39:19 PM
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return ColumnTypeModelBO.class.equals(clazz);

	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 11, 2016, 4:39:19 PM
	 * 
	 * @param target
	 * @param errors
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "columnType",
				messageSource.getMessage("AU0056", new Object[] {},
						LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "columnValue",
				messageSource.getMessage("AU0057", new Object[] {},
						LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "columnDataType",
				messageSource.getMessage("AU0058", new Object[] {},
						LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dataBaseType",
				messageSource.getMessage("AU0059", new Object[] {},
						LocaleContextHolder.getLocale()));

	}

}

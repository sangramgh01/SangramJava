/**
 * PhysicalColumnValidator.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 11, 2016 2:46:56 PM
 * @Version	     : 1.7 
 * @Description  : "PhysicalColumnValidator" is used for Physical Column Table validations
 * 
 **/
@Component
public class PhysicalColumnValidator implements Validator{
	
	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name 	: supports
	 * Description 		: The Method "supports" is used for 
	 * Date    			: Jul 11, 2016, 2:47:55 PM
	 * @param clazz
	 */
	
	@Override
	public boolean supports(Class<?> clazz) {
		return PhysicalColumnBO.class.equals(clazz);
	}

	/**
	 * 
	 * Method Name 	: validate
	 * Description 		: The Method "validate" is used for 
	 * Date    			: Jul 11, 2016, 2:47:55 PM
	 * @param target
	 * @param errors
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "physicalColumnName", messageSource.getMessage("AU0061", new Object[]{}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "columnDataType", messageSource.getMessage("AU0058", new Object[]{}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "columnDataLength", messageSource.getMessage("AU0065", new Object[]{}, LocaleContextHolder.getLocale()));
	}

	
}

/**
 * PhysicalTableValidator.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;

/**
 * 
 * @Author	     : Srinivasa.Katta
 * @Created On  : Jul 11, 2016 2:17:19 PM
 * @Version	     : 1.7 
 * @Description  : "PhysicalTableValidator" is used for  Physicl Table data validations
 * 
 **/
@Component
public class PhysicalTableValidator implements Validator{
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	PhysicalColumnValidator physicalColumnValidator;

	/**
	 * 
	 * Method Name 	: supports
	 * Description 		: The Method "supports" is used for 
	 * Date    			: Jul 11, 2016, 2:17:41 PM
	 * @param clazz
	 */
	
	@Override
	public boolean supports(Class<?> clazz) {
		return PhysicalTableBO.class.equals(clazz);
	}

	/**
	 * 
	 * Method Name 	: validate
	 * Description 		: The Method "validate" is used for 
	 * Date    			: Jul 11, 2016, 2:17:41 PM
	 * @param target
	 * @param errors
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public void validate(Object target, Errors errors) {
		PhysicalTableBO physicalTableBO = (PhysicalTableBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "physicalTableName",
				messageSource.getMessage("AU0069", new Object[] {},
						LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "schemaName", messageSource
				.getMessage("AU0070", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tableType", messageSource
				.getMessage("AU0071", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "createdBy", messageSource
				.getMessage("AU0072", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "updatedBy", messageSource
				.getMessage("AU0073", new Object[] {}, LocaleContextHolder.getLocale()));
		if (physicalTableBO.getDataSourceId() == null) {
			errors.rejectValue("departmentId", messageSource.getMessage("AU0074",
					new Object[] { physicalTableBO.getDataSourceId() }, LocaleContextHolder.getLocale()));
		}
		// validate the Physical Column Table data
		for (int idx = 0; idx < physicalTableBO.getPhysicalColumns().size(); idx++) {
			errors.pushNestedPath("physicalColumns[" + idx + "]");
			ValidationUtils.invokeValidator(physicalColumnValidator, physicalTableBO.getPhysicalColumns().get(idx),
					errors);
			errors.popNestedPath();
		}

	}

}

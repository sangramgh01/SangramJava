
package com.zetainteractive.zetahub.admin.constants;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 * Define all Admin constants here.
 */

public class Constants{
	
	/**
	 * No need to instantiate constant class
	 */
	private Constants(){
		
	}
	
	// Department object keys
	public static final String DEPARTMENT_PARAMETERS_KEY="PARAMETERS";
	public static final String DEPARTMENT_ADDRESSLIST_KEY="ADDRESSLIST";
	public static final String DEPARTMENT_UNSUBRULES_KEY="UNSUBRULES";
	public static final String DEPARTMENT_NOTIFICATIONS_KEY="NOTIFICATIONS";
	public static final String DEPARTMENT_GOOGLEANALYTICS_KEY="GOOGLEANALYTICS";
	public static final String DEPARTMENT_ADOBEANALYTICS_KEY="ADOBEANALYTICS";
	public static final String DEPARTMENT_OTHERWEBANALYTICS_KEY="OTHERWEBANALYTICS";
	public static final String DEPARTMENT_MOBILE_KEY="MOBILE";
	public static final String DEPARTMENT_AUDIENCE_KEY="AUDIENCES";
	public static final String NOTIFICATIONS_DISABLED="Disable";
	public static final String NOTIFICATIONS_STANDARD="Standard";
	public static final String NOTIFICATIONS_DETAILED="Detailed";
	public static final String NOTIFICATIONS_ERROR_ONLY="Error Only";
	public static final String FOLDER_TRASH="TRASH";
	public static final Character FOLDER_TYPE_ALL='A';
	public static final Character FOLDER_TYPE_REPORTS='R';
	
	
	//Customer object keys
	/*DomainBO, AddressTypeBO, MobileBO, FileSourceBO, DbSourceBO, UserAttributeBO,	EncryptionKeyBO, FileFormatBO*/
	
	public static final String CUSTOMER_ALL_KEY="ALL";
	public static final String CUSTOMER_DOMAIN_KEY="DOMAIN";
	public static final String CUSTOMER_ADDRESSTYPE_KEY="ADDRESSTYPE";
	public static final String CUSTOMER_MOBILE_KEY="MOBILE";
	public static final String CUSTOMER_FILESOURCE_KEY="FILESOURCE";
	public static final String CUSTOMER_DBSOURCE_KEY="DBSOURCE";
	public static final String CUSTOMER_USERATTRIBUTE_KEY="USERATTRIBUTE";
	public static final String CUSTOMER_ENCRYPTIONKEY_KEY="ENCRYPTIONKEY";
	public static final String CUSTOMER_FILEFORMAT_KEY="FILEFORMAT";
	public static final String CUSTOMER_RESTRICTEDDOMIAN_KEY="RESTRICTEDDOMIANS";
	
	
	public static final String SORT_LIST_USER = "user";

	public static final String SORT_LIST_DEPARTMENT = "department";

	public static final String ALL_CUSTOMERS = "ALL_CUSTOMERS";

	public static final char CONTENT_HTML = 'H';

	public static final char CONTENT_TEXT = 'T';

	public static final char CONTENT_AOL = 'O';

	public static final String STATUS_ACTIVE = "A";

	public static final String STATUS_INACTIVE = "I";

	public static final String ACTIVELIST = "LIST";

	public static final String ACTIVECAMPAIGN = "CAMPAIGN";

	public static final String ACTIVEALL = "ALL";

	public static final String ACTIVENONE = "NONE";
	
	//Added for Work flow process :START
	public static final char ACTIVITY_IN_PROGRESS = 'I';
	public static final char ACTIVITY_WAITING = 'W';
	public static final char ACTIVITY_COMPLETED = 'C';
	public static final char ACTIVITY_ERRORED = 'E';
	public static final char ACTIVITY_BLOCKED = 'B';
	public static final char ACTIVITY_STOPPED = 'S';
	public static final char ACTIVITY_RETRY = 'R';
	public static final char ACTIVITY_FAILED = 'F';
	public static final char ACTIVITY_SKIPPED = 'U';

	public static final String ACTIVITY_OBJECT_NOT_FOUND_MSG = "Unable to find the record for the search criteria";
	public static final String ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG = "No records available";
	public static final String ACTIVITY_OBJECT_NO_TRANSFORMS_FOUND_MSG ="No transforms available";
	public static final String ACTIVITY_UPDATE_NOT_FOUND_MSG = "Failed to update as it does not exists";
	public static final String ACTIVITY_FAIL_TO_RESTART_MSG = "Failed to restart the workflow as it does not exists with Errored Status";
	public static final String ACTIVITY_FAIL_TO_RESTART_COMP_WORKLOW_MSG = "Speciifed Work Flow has completed, Please specify errored work flow to start";
	public static final String ACTIVITY_REQUIRED_FIELDS_MSG = "Please provide required fields %s";
	public static final String ACTIVITY_SUCCESS_MSG = "Success";
	public static final String ACTIVITY_TRIGGERD_MSG = "Work flow activity triggered";
	public static final String ACTIVITY_SCHEDULED_MSG = "Work flow activity scheduled";
	public static final String ACTIVITY_FILEDEF_ERRORD = "Transform is not executed due to associated file definition error.";
	public static final String ACTIVITY_BLOCKED_MSG = "Activity blocked due to previous activity errored.";
	public static final String ACTIVITY_SCHEDULED_ERRMSG = "Acitivity blocked due to sql exception.";
	
	//Added for Work flow process :END
	
	public static String RESOURCE_BUNDLE = "Admin_ErrorMessages";
	
	public static List<String> ADM_DEPARTMENT_COLUMNS = Arrays.asList("departmentid", "departmentname", "approvalmandatory", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_SECURITYRULE_COLUMNS = Arrays.asList("securityruleid", "securityrulename", "securityrule", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_CONFIGURATION_COLUMNS = Arrays.asList("configurationid", "objectkey", "objectvalue");
	public static List<String> ADM_CONFIGURATION_ADDRESSTYPES_COLUMNS = Arrays.asList("name", "enable", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_CONFIGURATION_FILESOURCE_COLUMNS = Arrays.asList("filesourcename", "hostname", "port", "protocol","username", "password", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_CONFIGURATION_DBSOURCE_COLUMNS = Arrays.asList("dbsourcename", "hostname", "port","username", "password", "service", "dbvendor", "dbChracterSet", "schemaName", "createdby", "updatedby", "createdate", "updatedate");

	public static List<String> ADM_FOLDER_COLUMNS = Arrays.asList("folderid", "departmentid", "foldername", "type","parentfolderid", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_CATEGORY_COLUMNS = Arrays.asList("categoryid", "departmentid", "categorycode", "description","type", "createdby", "updatedby", "createdate", "updatedate");
	public static List<String> ADM_METERQUEUE_COLUMNS = Arrays.asList("meterqueueid", "meterqueuename", "status", "createdby", "updatedby", "createdate", "updatedate");
	
	public static final String CREATEDATE = "createdate";
	public static final String CREATEDBY = "createdby";
	
	public static String file_separator = System.getProperty("file.separator");
	public static String EBIZHOME = "E:\\";
	public static final String FILTER_APPENDING_PARAMETER="ZETA^^FILTER~~SOURCE_";
	
	public static String SYSTEM= "System";
	public static String CUSTOM= "Custom";
	
	
	public static String DBTYPE_MYSQL = "MYSQL";
	public static String MYSQL_URL = "jdbc:mysql://${IPADDRESS}:${PORT}/${SID}?autoReconnect=true&useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	public static String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
	
	public static String DBTYPE_ORACLE = "ORACLE";
	public static String ORACLE_URL = "jdbc:oracle:thin:@${IPADDRESS}:${PORT}:${SID}";
	public static String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	
	public static String DBTYPE_MSSQL = "MSSQL";
	public static String MSSQL_URL = "jdbc:jtds:sqlserver://${IPADDRESS}:${PORT}/${SID}";
	public static String MSSQL_DRIVER = "net.sourceforge.jtds.jdbc.Driver";
	
	public static String DBTYPE_TERADATA = "TERADATA";
	public static String TERADATA_URL = "jdbc:teradata://${SID}/";
	public static String TERADATA_DRIVER = "com.ncr.teradata.TeraDriver";
	
	public static String DBTYPE_NETEZZA = "NETEZZA";
	public static String NETEZZA_URL = "jdbc:netezza://${IPADDRESS}:${PORT}/${SID}";
	public static String NETEZZA_DRIVER = "org.netezza.Driver";
	
	public static String DBTYPE_POSTGRES = "POSTGRES";
	public static String POSTGRES_URL = "jdbc:postgresql://${IPADDRESS}:${PORT}/${SID}" ;
	public static String POSTGRES_DRIVER = "org.postgresql.Driver";
	
	public static String DBTYPE_VERTICA = "VERTICA";
	public static String VERTICA_URL = "jdbc:vertica://${IPADDRESS}:${PORT}/${SID}" ;
	public static String VERTICA_DRIVER = "com.vertica.jdbc.Driver";
	
	public static final String PGP = "PGP";
	public static final String GPG = "GPG";
	public static final char GENARATE = 'G';
	public static final char UPLOAD = 'U';

	public static final String HTTP_PROTOCOL = "HTTP";
	public static final String HTTPS_PROTOCOL = "HTTPS";
	public static final String FTP_PROTOCOL = "FTP";
	public static final String SFTP_PROTOCOL = "SFTP";
	public static final String SCP_PROTOCOL = "SCP";
	
	public static final String TEMPLATES_FOLDER = File.separator+"data"+File.separator+"templates";
	public static final char YES = 'Y';
	public static final char NO = 'N';
	
}
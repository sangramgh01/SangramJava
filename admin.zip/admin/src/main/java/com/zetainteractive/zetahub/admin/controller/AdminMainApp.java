package com.zetainteractive.zetahub.admin.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.zetahub.bootstarter.ZetaContext;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;

@Controller
public class AdminMainApp {

	@RequestMapping("/adminHome")
	@HystrixCommand
	public String adminHome() {
		return "adminhome";
	}

	@RequestMapping("/admin/init")
	@HystrixCommand
	public String initialize(Map<String,Object> map) {
		try{
			map.put("ENVIRONMENT_ADM", ZetaUtil.getHelper().getEnvironment());
		}catch (Exception e) {
			// TODO: handle exception
		}
		return "init";
	}
	
}

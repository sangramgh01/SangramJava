/**
 * ConfigurationController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.ConfigurationService;
import com.zetainteractive.zetahub.admin.util.encryptionutil.EncryptionUtil;
import com.zetainteractive.zetahub.admin.util.encryptionutil.GPGEncryptionUtil;
import com.zetainteractive.zetahub.admin.util.encryptionutil.PGPEncryptionUtil;
import com.zetainteractive.zetahub.admin.validators.EncryptionKeyValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AddressTypeBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DomainBO;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MultiUploadFormModel;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.commons.domain.RestrictedDomainsBO;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;
/**
 * 
 * @author Krishna.Polisetti
 * @version 1.7
 * @Created : 01/07/2016
 */
@RestController
public class ConfigurationController {
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	ConfigurationService configurationService;
	@Autowired
	MessageSource messageSource;
	@Autowired
	EncryptionKeyValidator keyValidator;
	public static final String RESOURCE_NAME_DOMAINS ="domains";
	public static final String RESOURCE_NAME_FILE_SOURCE ="filesource";
	public static final String RESOURCE_NAME_FILE_ENCRYPTION ="fileencryption";
	public static final String RESOURCE_NAME_DATABASE_SOURCE ="databasesource";
	public static final String RESOURCE_NAME_ADDRESS_TYPES ="addresstypes";
	/**
	 * Creates the encryption key.
	 *
	 * @param encryptionKeyBO the encryption key bo
	 * @return the response entity
	 *
	 */
	@HystrixCommand
	@RequestMapping(path="/createEncryptionKey",method=RequestMethod.POST)
	public  ResponseEntity<?> createEncryptionKey(@RequestBody final EncryptionKeyBO encryptionKeyBO,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :createEncryptionKey()");
		ResponseObject resp = new ResponseObject();
		Long encryptionKeyValue = 0L;
		
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"createEncryptionKey"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		
		try {
			encryptionKeyValue = configurationService.createEncryptionKey(encryptionKeyBO,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while creating Encryption Key", ex);
			resp.addError("Error occurred while creating Encryption Key",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("End :" + getClass().getName() + " :createEncryptionKey()");
		return new ResponseEntity<>(encryptionKeyValue, HttpStatus.OK);
	}
	
	/**
	 * Delete encryption key.
	 *
	 * @param encryptionKey the encryption key
	 * @return the response entity
	 * 
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteEncryptionKey/{encryptionKey}",method=RequestMethod.DELETE)
	public ResponseEntity<?>  deleteEncryptionKey(@PathVariable String encryptionKey,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :deleteEncryptionKey()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"deleteEncryptionKey"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		
		try {
			if(encryptionKey == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.deleteEncryptionKey(encryptionKey), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while deleting encryption key", ex);
			resp.addError("Error occurred while deleting encryption key",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {encryptionKey},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	/**
	 * List encryption keys.
	 *
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path="/listfileEncryptions",method=RequestMethod.GET)
	public ResponseEntity<?> listEncryptionKeys(@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listEncryptionKeys()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) 
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"listfileEncryptionKey"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
			try {
				return new ResponseEntity<>(configurationService.listEncryptionKeys(), HttpStatus.OK);
			} catch (AdminException ex) {
				logger.error("Error occurred while listing encryption keys", ex);
				resp.addError("Error occurred while listing encryption keys",messageSource.getMessage(ex.getErrorCode(), 
						new Object[] {},LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
	}
	
	
	/**
	 * Creates the db source.
	 *
	 * @param dbSource the db source
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/createDBSource", method = RequestMethod.POST)
	public ResponseEntity<?> createDBSource(@RequestBody DbSourceBO dbSource, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :createDBSource()");
		ResponseObject resp = new ResponseObject();
		Long configId = 0L;
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DATABASE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"createDBSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			configId = configurationService.createDBSource(dbSource, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while creating DBSource", ex);
			resp.addError("Error occurred while creating DBSource",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(configId, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param dbSourceName
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getDBSource/{dbSourceName}",method=RequestMethod.GET)
	public ResponseEntity<?> getDBSource(@PathVariable String dbSourceName,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :getDBSource()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DATABASE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getDBSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if(dbSourceName == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.getDBSource(dbSourceName), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching DBSource", ex);
			resp.addError("Error occurred while fetching DBSource",
					messageSource.getMessage(ex.getErrorCode(), new Object[] { dbSourceName }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	/**
	 * Delete db source.
	 *
	 * @param dbSourceName the db source name
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/deleteDBSource/{keyName}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteDBSource(@PathVariable String keyName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :deleteDBSource()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DATABASE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteDBSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (keyName == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.deleteDBSource(keyName), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while deleting the DBSource", ex);
			resp.addError("Error occurred while deleting the DBSource", messageSource.getMessage(ex.getErrorCode(),
					new Object[] { keyName }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * List db sources.
	 *
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/listDBSources", method = RequestMethod.GET)
	public ResponseEntity<?> listDBSources(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listDBSources()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DATABASE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"listDBSources"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.listDBSources(), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while listing the DBSource", ex);
			resp.addError("Error occurred while listing the DBSource",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * List file sources.
	 *
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/listFileSources", method = RequestMethod.GET)
	public ResponseEntity<?> listFileSources(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listDBSources()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"listFileSources"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.listFileSources(), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while listing the file sources", ex);
			resp.addError("Error occurred while listing the file sources",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Creates the file source.
	 *
	 * @param fileSource the file source
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/createFileSource", method = RequestMethod.POST)
	public ResponseEntity<?> createFileSource(@RequestBody FileSourceBO fileSource,BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :createFileSource()");
		ResponseObject resp = new ResponseObject();
		Long configId = 0L;
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"saveFileSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			configId = configurationService.createFileSource(fileSource,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while creating the file sources", ex);
			resp.addError("Error occurred while creating the file sources",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(configId, HttpStatus.OK);
	}
	
	/**
	 * Gets the file source.
	 *
	 * @param fileSourceName
	 *            the file source name
	 * @return the file source
	 */
	@HystrixCommand
	@RequestMapping(path = "/getFileSource/{fileSourceName:.+}", method = RequestMethod.GET)
	public ResponseEntity<?> getFileSource(@PathVariable String fileSourceName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :createFileSource()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"getFileSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		
		try {
			if (fileSourceName == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.getFileSource(fileSourceName), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching the file sources", ex);
			resp.addError("Error occurred while fetching the file sources",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Delete file source.
	 *
	 * @param fileSourceName the file source name
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/deleteFileSource/{keyName}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFileSource(@PathVariable String keyName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :deleteFileSource()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_SOURCE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"deleteFileSource"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (keyName == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.deleteFileSource(keyName), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while deleting the file sources", ex);
			resp.addError("Error occurred while deleting the file sources",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Save address type.
	 *
	 * @param addressTypeBO the address type bo
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/saveAddressType", method = RequestMethod.POST)
	public ResponseEntity<?> saveAddressType(@RequestBody AddressTypeBO addressTypeBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :saveAddressType()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_ADDRESS_TYPES, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"saveAddressType"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Long configId = 0L;
		try {
			configId = configurationService.saveAddressType(addressTypeBO,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while saving the address type", ex);
			resp.addError("Error occurred while saving the address type",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(configId, HttpStatus.OK);
	}
		
	/**
	 * List address types.
	 *
	 * @param result the result
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/listAddressTypes", method = RequestMethod.GET)
	public ResponseEntity<?> listAddressTypes(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listAddresstypes()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_ADDRESS_TYPES, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"listAddressTypes"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.listAddressTypes(), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while listing the addresstypes", ex);
			resp.addError("Error occurred while listing the addresstypes",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Used to get total number of addresstypes.
	 *
	 * @param listingCriteria the listing criteria
	 * @param bindingResult the binding result
	 * @return the total address types count
	 */
	@HystrixCommand
	@RequestMapping(path = "/getTotalAddressTypesCount", method = RequestMethod.POST)
	public ResponseEntity<?> getTotalAddressTypesCount(@RequestBody ListingCriteria listingCriteria,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :getTotalAddressTypesCount()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_ADDRESS_TYPES, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getTotalAddressTypesCount"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Long typesCount = 0L;
		try {
			listingCriteria.setColumnNames(Constants.ADM_CONFIGURATION_COLUMNS);
			typesCount = configurationService.getTotalAddressTypesCount(listingCriteria, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching the address types count", ex);
			resp.addError("Error occurred while fetching the address types count",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :getTotalAddressTypesCount()");
		return new ResponseEntity<>(typesCount, HttpStatus.OK);
	}
	
	
	/**
	 * List restricted domains.
	 *
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/listRestrictedDomains", method = RequestMethod.GET)
	public ResponseEntity<?> listRestrictedDomains(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listRestrictedDomains()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"listRestrictedDomains"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.listRestrictedDomains(), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching the restricted domains", ex);
			resp.addError("Error occurred while fetching the restricted domains",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * @param restrictedDomains
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "/updateRestrictedDomains", method = RequestMethod.POST)
	public ResponseEntity<?> updateRestrictedDomains(@RequestBody RestrictedDomainsBO restrictedDomains,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :listRestrictedDomains()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateRestrictedDomains"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.updateRestrictedDomains(restrictedDomains),
					HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while updating the restricted domains", ex);
			resp.addError("Error occurred while updating the restricted domains",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Save domain.
	 *
	 * @param domain
	 *            the domain
	 * @return the response entity
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")})
	@RequestMapping(path = "/saveDomain", method = RequestMethod.POST)
	public ResponseEntity<?> saveDomain(@RequestBody DomainBO domain, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :saveDomain()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"saveDomain"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Long configId = 0L;
		try {
			configId = configurationService.saveDomain(domain, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while saving the domain", ex);
			resp.addError("Error occurred while saving the domain",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(configId, HttpStatus.OK);
	}
	
	/**
	 * List domains.
	 *
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/listDomains", method = RequestMethod.GET)
	public ResponseEntity<?> listDomains(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :saveDomain()");
		ResponseObject resp = new ResponseObject();
		
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"listDomains"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.listDomains(), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while listing domains", ex);
			resp.addError("Error occurred while listing domains",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * 
	 * Method Name 	: deleteDomain
	 * Description 	: The Method "deleteDomain" is used for 
	 * Date    		: Jul 28, 2016, 8:44:15 PM
	 * @param domainCode
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * 
	 */
	@HystrixCommand
	@RequestMapping(path = "/deleteDomain", method = RequestMethod.POST)
	public ResponseEntity<?> deleteDomain(@RequestBody String code,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :deleteDomain()");
		ResponseObject resp = new ResponseObject();
		
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"deleteDomain"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (code == null) {
				throw new AdminException("WL3089");
			}
			return new ResponseEntity<>(configurationService.deleteDomain(code), HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while deleting the domain", ex);
			resp.addError("Error occurred while deleting the domain", messageSource.getMessage(ex.getErrorCode(),
					new Object[] { code }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
		
	/**
	 * 
	 * @param AddressTypeName
	 * @return
	 *
	 */
	@HystrixCommand
	@RequestMapping(path="/isAddressTypeExist/{addressTypeName}",method=RequestMethod.GET)
	public ResponseEntity<?> isAddressTypeExist(@PathVariable String addressTypeName,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_ADDRESS_TYPES, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"isAddressTypeExist"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		 try {
			 return new ResponseEntity<>(configurationService.isAddressTypeExist(addressTypeName),HttpStatus.OK);
		} catch (AdminException e) {
			logger.error("Error while checking if addresstype exists");
			resp.addError("Error while checking if addresstype exists",messageSource.getMessage(e.getErrorCode(),
					new Object[] {addressTypeName}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<>(resp,HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * 
	 * Method Name 	: getRestrictedDomainWithDepartmentList
	 * Description 	: The Method "getRestrictedDomainWithDepartmentList" is used for 
	 * Date    		: Jul 28, 2016, 8:43:54 PM
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(value = "/getRestrictedDomainWithDepartmentList", method = RequestMethod.GET)
	public ResponseEntity<?> getRestrictedDomainWithDepartmentList(@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :getRestrictedDomainWithDepartmentList()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getRestrictedDomainWithDepartmentList"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(configurationService.getRestrictedDomainsWithDepartmentsList(),
					HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching the domains count", ex);
			resp.addError("Error occurred while deleting the domain",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: downloadRSDomains
	 * Description 	: The Method "downloadRSDomains" is used for 
	 * Date    		: Jul 28, 2016, 8:43:46 PM
	 * @param response
	 * @throws IOException
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(value="/downloadRSDomains",method = RequestMethod.GET,produces = "application/vnd.ms-excel")
	public @ResponseBody void downloadRSDomains(HttpServletResponse response) throws IOException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Start :" + getClass().getName() + " :downloadRSDomains()");
		ResponseObject resp = new ResponseObject();
		
		StringBuffer sbContentDispValue = null;
		File file = new File("RestrictedDomains_"+System.currentTimeMillis()+".xls");
		InputStream input = null;
		try {
			ByteArrayOutputStream byteOutStream = configurationService.downloadRSDomains(); 
			input = new ByteArrayInputStream(byteOutStream.toByteArray());
			response.setHeader("Cache-Control", "max-age=0");
            response.setContentType("application/vnd.ms-excel");
            sbContentDispValue = new StringBuffer();
            sbContentDispValue.append("attachment");
            sbContentDispValue.append("; filename=");
            sbContentDispValue.append(file.getName());
            response.setHeader("Content-disposition", sbContentDispValue.toString());
            response.setContentLength(byteOutStream.size());
		  	FileCopyUtils.copy(input, response.getOutputStream());
			response.flushBuffer();
		}catch(AdminException e){
			logger.error("Error occurred while downloading RS domains", e);
			resp.addError("Error occurred while downloading RS domains",
					messageSource.getMessage(e.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
		}finally {  
			if(input != null) 
				input.close();
		} 
	}
	/**
	 * 
	 * 
	 * Method Name 	: saveRestrictedDomains
	 * Description 	: The Method "saveRestrictedDomains" is used for 
	 * Date    		: Jul 28, 2016, 8:43:37 PM
	 * @param file
	 * @return
	 * @throws IOException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(value="/saveRestrictedDomains",method = RequestMethod.POST, consumes = {"multipart/form-data" })
	public ResponseEntity<?>  saveRestrictedDomains(@RequestParam("file") MultipartFile file,@RequestHeader HttpHeaders headers) throws IOException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		List resultList = new ArrayList();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"saveRestrictedDomains"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (!file.isEmpty()) {
				 byte[] bytes = file.getBytes();
				 resultList = configurationService.saveRestrictedDomains(bytes);
		                 
		         return new ResponseEntity<>(resultList,HttpStatus.OK);
	        } else {
	        	resp.setMessage("Error occurred while uploading domains  because the file was empty.");
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
	        }

        }catch(AdminException ex){logger.error("Error occurred while fetching the domains count", ex);
			resp.addError("Error occurred while uploading domains",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	
	/**
	 * Upload private n public key files.
	 *
	 * @param file the file
	 * @param fileType the file type
	 * @param isFilter the is filter
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(value = "/uploadPrivateNPublicKeyFiles/{fileType}/{isFilter}", method = RequestMethod.POST, consumes = {"multipart/form-data"})
	public ResponseEntity<?> uploadPrivateNPublicKeyFiles(@RequestParam("file") MultipartFile file,
			@PathVariable("fileType") String fileType, @PathVariable("fileType") String isFilter,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"uploadPrivateNPublicKeyFiles"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		String msg = null;
		String fileName = null;
		String dirName = null;
		String filePath = null;
		String userTemp = null;
		try {
			if (file == null) {
				resp.addError("meaasge", "empty file content");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
			String userid = "ADMIN"; // To be fetched from Config ZetaContext object
			String ebizhome = System.getProperty("EBIZHOME");  // This need to be fetched from Config server
			if (ebizhome != null && !ebizhome.endsWith(Constants.file_separator)) {
				ebizhome = ebizhome + Constants.file_separator;
			}
			if (ebizhome != null) {
				userTemp = ebizhome + "temp" + Constants.file_separator;
			} else {
				userTemp = Constants.EBIZHOME + "temp" + Constants.file_separator;
			}
			String requestpath = userTemp;

			if (!requestpath.endsWith("/") && !requestpath.endsWith("\\")) {
				requestpath = requestpath + System.getProperty("file.separator");
			}
			File f1 = new File(requestpath + userid);
			if (!f1.isDirectory()) {
				f1.mkdirs();
			}
			File f2 = new File(requestpath + userid + System.getProperty("file.separator") + "list");
			if (!f2.isDirectory()) {
				f2.mkdirs();
			}

			dirName = requestpath + userid + System.getProperty("file.separator") + "list";

			String actualFileName = "";
			if (isFilter == null)
				actualFileName = Calendar.getInstance().getTimeInMillis() + fileName;
			if (isFilter != null && isFilter.equalsIgnoreCase("true")) {
				actualFileName = Constants.FILTER_APPENDING_PARAMETER + Calendar.getInstance().getTimeInMillis()
						+ fileName;
			}
			fileName = actualFileName;

			filePath = dirName + System.getProperty("file.separator") + fileName;

			if (!file.isEmpty()) {
				try {
					byte[] bytes = file.getBytes();
					fileName = file.getOriginalFilename();
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filePath)));
					stream.write(bytes);
					stream.close();
					msg = "You successfully uploaded " + fileName + " into " + dirName + "-uploaded !";
				} catch (IOException e) {
					msg = "You failed to upload " + fileName + " => " + e.getMessage();
					logger.error("Uploading file failed", e);
					throw new AdminException("FMJ0017");
				}
			} else {
				msg = "You failed to upload " + fileName + " because the file was empty.";
				logger.error(msg);
				throw new AdminException("FMJ0026");
			}
		} catch (AdminException ex) {
			resp.addError("Exception occured while uploading the files",
					messageSource.getMessage(ex.getErrorCode(), new Object[] { fileName }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}
	/**
	 * 
	 * 
	 * Method Name 	: saveActiveRestrictedDomainforDept
	 * Description 	: The Method "saveActiveRestrictedDomainforDept" is used for 
	 * Date    		: Jul 29, 2016, 8:46:40 PM
	 * @param restrictedDomainDeptList
	 * @return
	 * @throws IOException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "240000")})
	@RequestMapping(value="/saveActiveRestrictedDomainforDept",method = RequestMethod.POST)
	public ResponseEntity<?>  saveActiveRestrictedDomainforDept(@RequestBody List<Object> restrictedDomainDeptList,@RequestHeader HttpHeaders headers) throws IOException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_DOMAINS, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"saveActiveRestrictedDomainforDept"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		List newRestrictedDomainDeptList = new ArrayList();
		ObjectMapper mapper = new ObjectMapper();
		try {
			RestrictedDomainsBO rd = mapper.convertValue(restrictedDomainDeptList.get(0), RestrictedDomainsBO.class);
			newRestrictedDomainDeptList.add(rd);
			List<DepartmentBO> departments = new ArrayList<>();
			List<Map<String, Object>> dbList;
			List<DepartmentBO> list = new ArrayList<>();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			mapper.setDateFormat(df);
			
			dbList = (List<Map<String, Object>>) restrictedDomainDeptList.get(1);
			for (Map<String, Object> map : dbList) {
				DepartmentBO obj2 = mapper.convertValue(map, DepartmentBO.class);
				list.add(obj2);
			}
			newRestrictedDomainDeptList.add(list);
			Boolean result = configurationService.saveActiveRestrictedDomainforDept(newRestrictedDomainDeptList);
            return new ResponseEntity<>(result,HttpStatus.OK);

        }catch(AdminException ex){logger.error("Error occurred while fetching the domains count", ex);
			resp.addError("Error occurred while uploading domains",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
     * Download encryption keys.
     *
     * @param response the response
     * @param encryptionKeyName the encryption key name
     * @throws IOException Signals that an I/O exception has occurred.
     */
	 @HystrixCommand
     @RequestMapping(value = "/downloadEncryptionKeys/{encryptionKeyName}", method = RequestMethod.GET, produces = "text/plain")
     public @ResponseBody void downloadEncryptionKeys(HttpServletResponse response,@PathVariable String encryptionKeyName) throws IOException {
		 try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
           ResponseObject resp = new ResponseObject();
           EncryptionKeyBO keyBO = null;
           String privateKeyFilePath = null;
           String publicKeyFilePath = null;
           FileOutputStream fos = null;
           ZipOutputStream zos = null;
           try {
                 privateKeyFilePath = encryptionKeyName + "_" + "private.asc";
                 publicKeyFilePath = encryptionKeyName + "_" + "public.asc";

                 response.setHeader("Cache-Control", "max-age=0");
                 response.setContentType("text/plain");

                 List<EncryptionKeyBO> keysList = configurationService.listEncryptionKeys();
                 for (EncryptionKeyBO encryptionKeyBO : keysList) {
                       if (encryptionKeyBO.getEncryptionKeyName().trim().equalsIgnoreCase(encryptionKeyName.trim())) {
                             keyBO = encryptionKeyBO;
                       }
                 }
                 if (keyBO != null) {
                       File zipFile = File.createTempFile(encryptionKeyName + "" + System.currentTimeMillis(), ".zip");
                       byte[] privateKeyBuffer = keyBO.getPrivatekey().getBytes();
                       byte[] publicKeyBuffer = keyBO.getPublickey().getBytes();

                       fos = new FileOutputStream(zipFile);
                       zos = new ZipOutputStream(fos);
                       // Creating FilePath End Here
                       if (keyBO.getPrivatekey() != null) {

                             zos.putNextEntry(new ZipEntry(privateKeyFilePath));
                             zos.write(privateKeyBuffer);
                             zos.closeEntry();

                             zos.putNextEntry(new ZipEntry(publicKeyFilePath));
                             zos.write(publicKeyBuffer);
                             zos.closeEntry();
                             zos.close();
                             fos.close();
                             response.setHeader("Content-Length", String.valueOf(zipFile.length()));
                             response.setHeader("Content-Disposition",
                                         "attachment; filename=\"" + zipFile.getName() + ".zip" + "\"");
                             InputStream is = new FileInputStream(zipFile);
                             FileCopyUtils.copy(IOUtils.toByteArray(is), response.getOutputStream());
                             response.flushBuffer();
                       }
                       zipFile.deleteOnExit();
                 }

           } catch (AdminException e) {
                 logger.error("Error occurred while downloading key files", e);
                 resp.addError("Error occurred while downloading key files",
                             messageSource.getMessage(e.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
                 resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
           } finally {
                 if (zos != null) {
                       zos.close();
                 }
                 if (fos != null) {
                       fos.close();
                 }
           }
     }
     /**
      * Upload private n public key files.
      *
      * @param file the file
      * @param fileType the file type
      * @param isFilter the is filter
      * @return the response entity
      * @throws IOException 
       */
	  @HystrixCommand
      @RequestMapping(value = "/saveFileEncryptionForUpload", method = RequestMethod.POST, consumes = {"multipart/form-data" })
      public ResponseEntity<?> saveFileEncryptionForUpload(@ModelAttribute("uploadForm") MultiUploadFormModel uploadForm,
                  BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws IOException {
		  try {logger.setContextString(new TagReplacement().replace(LoggerConstants.CONFIGURATION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("CONFIGURATIONID", 0);}},"{", "}"));} catch (Exception e) {}
            ResponseObject resp = new ResponseObject();
        	if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
    		{
        		resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
    					new Object[] {"saveFileEncryptionForUpload"},LocaleContextHolder.getLocale()));
    			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
    			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
    		}
            Boolean uploadStatus = false;
            String fileName = null;
            try {
                  if (uploadForm == null) {
                        resp.addError("meaasge", "empty file content");
                        return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
                  }

                  MultipartFile privateKeyFile = uploadForm.getPrivateKeyfile();
                  MultipartFile publicKeyFile = uploadForm.getPublicKeyfile();

                  EncryptionKeyBO keyBO = new EncryptionKeyBO();
                  if(uploadForm.getKeyName().equalsIgnoreCase("undefined"))
                	  keyBO.setKeyName(null);
                  else
                	  keyBO.setKeyName(uploadForm.getKeyName());
                  keyBO.setEncryptionKeyName(uploadForm.getEncryptionKeyName());
                  keyBO.setEncryptionType(uploadForm.getEncryptionType());
                  keyBO.setRegistrationtype(uploadForm.getRegistrationtype());
                  keyBO.setPassphrase(uploadForm.getPassphrase());
                  keyBO.setKeysize(uploadForm.getKeysize());
                  
                  if (keyBO != null) {
                        logger.debug("key---------->" + keyBO.getEncryptionKeyName());

                        ByteArrayInputStream privateKeyStream = new ByteArrayInputStream(privateKeyFile.getBytes());
                        String privateKeyContent = IOUtils.toString(privateKeyStream, "UTF-8");
                        logger.debug("privateKey ---->" + privateKeyContent);
                        keyBO.setPrivatekey(privateKeyContent);

                        ByteArrayInputStream publicKeyStream = new ByteArrayInputStream(publicKeyFile.getBytes());
                        String publicKeyContent = IOUtils.toString(publicKeyStream, "UTF-8");
                        logger.debug("publicKeyContent ---->" + publicKeyContent);
                        keyBO.setPublickey(publicKeyContent);
                        configurationService.createEncryptionKey(keyBO, bindingResult);
                        if (bindingResult.hasErrors()) {
            				resp.addErrors(bindingResult, "Invalid Data");
            				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
            			}
                        uploadStatus = true;
                  }
            } catch (AdminException ex) {
                  ex.printStackTrace();
                  resp.addError("Exception occured while uploading the files",
                              messageSource.getMessage(ex.getErrorCode(), new Object[] { fileName }, LocaleContextHolder.getLocale()));
                  resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
                  return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(uploadStatus, HttpStatus.OK);
      }
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")}) 
    @RequestMapping(value = "/saveFileEncryptionForGenereate", method = RequestMethod.POST)
	public ResponseEntity<?> saveFileEncryptionForGenereate(@RequestBody final EncryptionKeyBO encryptionKeyBO,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME_FILE_ENCRYPTION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"saveFileEncryptionForGenereate"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Boolean uploadStatus = false;
		String fileName = null;
		try {
			if (encryptionKeyBO == null) {
				resp.addError("meaasge", "empty file content");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}

			EncryptionKeyBO keyBO = encryptionKeyBO;
			Map<String,String> keys = generateKeys(encryptionKeyBO, bindingResult,headers);
			/*Map<String,String> keys = new HashMap<>();
			keys.put("privateKey", "xyz");
			keys.put("publicKey", "xyz");*/
			if (!keys.isEmpty()) {
				keyBO.setPrivatekey(keys.get("privateKey"));
				keyBO.setPublickey(keys.get("publicKey"));
				configurationService.createEncryptionKey(keyBO, bindingResult);
			}
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				resp.setMessage("Error occured while Generating keys");
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ex) {
			ex.printStackTrace();
			resp.addError("Exception occured while uploading the files", messageSource.getMessage(ex.getErrorCode(),
					new Object[] { fileName }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(uploadStatus, HttpStatus.OK);
	}

	/**
	 * 
	 * Method Name 	: generateKeys
	 * Description 	: The Method "generateKeys" is used to return a list of public and private keys
	 * Date    		: Aug 4, 2016, 4:36:42 PM
	 * @return
	 * @param  		:
	 * @return 		: List<String>
	 * @throws AdminException 
	 *
	 */
	private Map<String, String> generateKeys(EncryptionKeyBO encryptionKeyBO, BindingResult errors,@RequestHeader HttpHeaders headers)
			throws AdminException {
		
		Map<String, String> keys = null;
		keyValidator.validate(encryptionKeyBO, errors);
		if (!errors.hasErrors()) {
			EncryptionUtil key = null;
			if (encryptionKeyBO.getEncryptionType().equalsIgnoreCase(Constants.PGP)) {
				key = new PGPEncryptionUtil();
			} else if (encryptionKeyBO.getEncryptionType().equalsIgnoreCase(Constants.GPG)) {
				key = new GPGEncryptionUtil();
			}
			if (key != null) {
				try {
					keys = key.generateKeys(encryptionKeyBO.getPassphrase(), encryptionKeyBO.getKeysize(),
							ZetaUtil.getHelper().getCustomerID(),
							ZetaUtil.getHelper().getConfig().getConfigValueString("admin-encryption-private-key-file",
									null)+"/privatekey"+Calendar.getInstance().getTimeInMillis()+".txt",
							ZetaUtil.getHelper().getConfig().getConfigValueString("admin-encryption-public-key-file",
									null)+"/publickey"+Calendar.getInstance().getTimeInMillis()+".txt");
				} catch (AdminException e) {
					logger.error("AdminException while generating keys :" + e.getMessage(), e);
					throw e;
				} catch (Exception e) {
					logger.error("Error occured while generating keys :" + e.getMessage(), e);
					throw new AdminException("ACF0033");
				}
			}
		}
		return keys;
	}
	      
      
	
}

/**
 * DepartmentController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.ws.rs.PathParam;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.service.GoogleAnalyticsService;
import com.zetainteractive.zetahub.admin.service.MobileService;
import com.zetainteractive.zetahub.admin.service.WebPageService;
import com.zetainteractive.zetahub.admin.userdepartment.service.UserDepartmentService;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AdobeAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.AdobeRunDetailsBO;
import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;
import com.zetainteractive.zetahub.commons.domain.ContentTemplateBO;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;
import com.zetainteractive.zetahub.commons.domain.GAAccount;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.TestGroup;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @author Krishna.Polisetti
 * @version 1.7
 * @Created : 29/06/2016
 */
@RestController
public class DepartmentController {
	
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	GoogleAnalyticsService googleAnalyticsService;
	
	private static final String DEFAULT_MESSAGE="Invalid Data";
	private static final String MOBILE_ERROR_MESSAGE = "Error while fetching Mobile data";
	private static final String MOBILE_LIST_SHORTCODE_MESSAGE = "Error while getting shortcodes";
	private static final String MOBILE_LIST_TESTGROUP_MESSAGE = "Error while getting group data";
	private static final String MOBILE_SAVE_TESTGROUP_MESSAGE = "Error while saving group data";

	
	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	MobileService mobileService;
	
	@Autowired
	WebPageService webPageService;
	
	@Autowired 
	UserDepartmentService userDepartmentService;
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	public final static String DEPARTMENT = "admin";
	
	/**
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path="getDepartment/{departmentId}",method=RequestMethod.GET)
	public ResponseEntity<?> getDepartment(@PathVariable Long departmentId,@RequestHeader HttpHeaders headers)throws Exception{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			DepartmentBO department = departmentService.getDepartment(departmentId);
			return new ResponseEntity<>(department, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching department details", ex);
			resp.addError("Error occurred while fetching department details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 */
	/*@HystrixCommand
	@RequestMapping(path="deleteDepartment/{departmentId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteDepartment(@PathVariable Long departmentId,@RequestHeader HttpHeaders headers){
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try {
			departmentService.deleteDepartment(departmentId);
			resp.setMessage("Department deleted successfully.");
		    resp.setHttpStatusCode(HttpStatus.OK.value());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while deleting department details", ex);
			resp.addError("Error occurred while deleting department details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}*/
	
	/**
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="isDepartmentExists/{departmentId}",method=RequestMethod.GET)
	public ResponseEntity<?> isDepartmentExists(@PathVariable Long departmentId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			Boolean exists = departmentService.isDepartmentExists(departmentId);
			return new ResponseEntity<>(exists, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching department details", ex);
			resp.addError("Error occurred while fetching department details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @param json
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="getDepartmentSpecificProperty",method=RequestMethod.POST)
	public ResponseEntity<?> getDepartmentSpecificProperty(@RequestBody Map<String,Object> json,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try{
			Long departmentId=Long.parseLong(json.get("departmentId").toString());
			ResponseObject resp=new ResponseObject();
			String propertyKey=json.get("propertyKey").toString();
			DepartmentSettings departmentSettings=departmentService.getDepartmentSpecificProperty(departmentId,propertyKey,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(departmentSettings, HttpStatus.OK);
		}catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Error while getting department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @param departmentSettings
	 * @param bindingResult
	 * @return
	 * @throws JsonProcessingException
	 */
	@HystrixCommand
	@RequestMapping(path="updateDepartmentSpecificProperty",method=RequestMethod.POST)
	public ResponseEntity<?> updateDepartmentSpecificProperty(@RequestBody DepartmentSettings departmentSettings,BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws JsonProcessingException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentSettings.getDepartmentID());}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try{
			departmentService.updateDepartmentSpecificProperty(departmentSettings,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else{
				resp.setMessage("Department Property updated successfully.");
			    resp.setHttpStatusCode(HttpStatus.OK.value());
			    return new ResponseEntity<>(resp, HttpStatus.OK);
			}
		}catch (AdminException ex) {
			resp.addError("Some thing went wrong while updating department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param listingCriteria
	 * @param result
	 * @return
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path="/listDepartments",method=RequestMethod.POST)
	public ResponseEntity<?> listDepartments(@RequestBody ListingCriteria listingCriteria,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			List<DepartmentBO> departmentsList=departmentService.listDepartments(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(departmentsList, HttpStatus.OK);
		}catch (AdminException ex) {
			resp.addError("Some thing went wrong while updating department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/departmentsTotalCount",method=RequestMethod.POST)
	public ResponseEntity<?> departmentsTotalCount(@RequestBody ListingCriteria listingCriteria,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try{
			Long recordCount=departmentService.departmentsTotalCount(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(recordCount, HttpStatus.OK);
		}catch (AdminException ex) {
			resp.addError("Error while get departments count :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param departmentName
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="departmentNameExists/{departmentName}",method=RequestMethod.GET)
	public ResponseEntity<?> departmentNameExists(@PathVariable String departmentName,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentName);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try{
			Boolean exists=departmentService.departmentNameExists(departmentName);
			return new ResponseEntity<>(exists,HttpStatus.OK);
		}catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching department details", ex);
			resp.addError("Error occurred while fetching department details",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param json
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="createDepartment",method=RequestMethod.POST)
	public ResponseEntity<?> createDepartment(@RequestBody Map<String,Object> json,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
	    try {
	    	String departmentName=json.get("departmentName").toString();
			Boolean approvalNeeded=Boolean.parseBoolean(json.get("approvalNeeded").toString());
			Boolean domainKeysNeeded=Boolean.parseBoolean(json.get("domainKeysNeeded").toString());
			DepartmentBO departmentBO=departmentService.createDepartment(departmentName, approvalNeeded, domainKeysNeeded, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(departmentBO,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while calling service for creating department :: ",e);
			bindingResult.reject(messageSource.getMessage("ADM056", new Object[] {},LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * @param departmentBO
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path="saveDepartment",method=RequestMethod.POST)
	public ResponseEntity<?> saveDepartment(@RequestBody DepartmentBO departmentBO,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentBO.getDepartmentID());}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			if(departmentBO.getDepartmentID() != null && departmentBO.getDepartmentID() > 0) {
				boolean isDeptAccess = userDepartmentService.checkDepartmentAccess((long) ZetaUtil.getHelper().getUser()
						.getUserID(), departmentBO.getDepartmentID());
				if(!isDeptAccess) {
					resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"department "+departmentBO.getDepartmentName()}, LocaleContextHolder.getLocale()));
					resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
					return new  ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
				}
			}
			Long departmentID=departmentService.saveDepartment(departmentBO,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(departmentID,HttpStatus.OK);
		}catch (AdminException ex) {
			resp.addError("Error while saving department :: ",messageSource.getMessage(ex.getErrorCode(),ex.getObject() != null ? ex.getObject() : new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			resp.addError("Error while saving department :: ",messageSource.getMessage(((AdminException) e).getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Save folder.
	 *
	 * @param folderBO the folder bo
	 * @param bindingResult the binding result
	 * @return the response entity
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(path = "/saveFolder", method = RequestMethod.POST)
	public ResponseEntity<?> saveFolder(@RequestBody FolderBO folderBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :saveFolder()");
		ResponseObject resp = new ResponseObject();
		FolderBO updatedFolder = null;
		try {
			updatedFolder = departmentService.saveFolder(folderBO, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ae) {
			logger.error("Error occurred while saving folder", ae);
			resp.addError("Error occurred while saving folder",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("End :" + getClass().getName() + " :saveFolder()");
		return new ResponseEntity<>(updatedFolder, HttpStatus.OK);
	}
	
	/**
	 * Gets the folder.
	 *
	 * @param folderId
	 *            the folder id
	 * @return the folder
	 */
	@HystrixCommand
	@RequestMapping(path = "/getFolder/{folderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getFolder(@PathVariable Long folderId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :getFolder()");
		ResponseObject resp = new ResponseObject();
		FolderBO folder = null;
		try {
			if (folderId == null) {
				throw new AdminException("WL3089");
			}
			folder = departmentService.getFolder(folderId);
			if (folder == null) {
				logger.error(" No Folder exists with the given ID.");
				throw new AdminException("F00049");
			}
		} catch (AdminException ae) {
			logger.error("Error occurred while fetching the folder", ae);
			resp.addError("Error occurred while fetching the folder",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :getFolder()");
		return new ResponseEntity<FolderBO>(folder, HttpStatus.OK);
	}
	
	/**
	 * List folders.
	 *
	 * @param listingCriteria the listing criteria
	 * @param bindingResult the binding result
	 * @return the response entity
	 */
	@CrossOrigin
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path = "/listFolders", method = RequestMethod.POST)
	public ResponseEntity<?> listFolders(@RequestBody FoldersListingCriteria listingCriteria, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :getFolder()");
		List<FolderBO> folderBOList = null;
		List<FolderBO> allFolders = new ArrayList<>();
		ResponseObject resp = new ResponseObject();
		try {
			listingCriteria.setColumnNames(Constants.ADM_FOLDER_COLUMNS);
			folderBOList = departmentService.listFolders(listingCriteria, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
			FolderBO folderBO = new FolderBO();
			DepartmentBO department = departmentService.getDepartment(listingCriteria.getDepartmentId());
			folderBO.setFoldername(department.getDepartmentName());
			folderBO.setFolderid(0L);
			allFolders.add(folderBO);
			allFolders.addAll(folderBOList); 
		} catch (AdminException ae) {
			logger.error("Error occurred while listing folders", ae);
			resp.addError("Error occurred while listing folders",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			logger.error("Error occurred while listing folders", e);
			bindingResult.reject(messageSource.getMessage("ADM057", new Object[] {},LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :listFolders()");
		return new ResponseEntity<List<FolderBO>>(allFolders, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param folderId
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")})
	@RequestMapping(path="/deleteFolder/{folderId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteFolder(@PathVariable Long folderId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :deleteFolder()");
		ResponseObject resp = new ResponseObject();
		Boolean deleteStatus = false;
		try{
			if (folderId == null) {
				throw new AdminException("WL3089");
			}
			deleteStatus = departmentService.deleteFolder(folderId);
		} catch (AdminException ae) {
			logger.error("Error occurred while deleting folder", ae);
			resp.addError("Error occurred while deleting folder",
					messageSource.getMessage(ae.getErrorCode(),ae.getObject(), LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
		logger.debug("Ends :" + getClass().getName() + " :deleteFolder()");
		return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param folderId
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")})
	@RequestMapping(path="/deleteFolders",method=RequestMethod.POST)
	public ResponseEntity<?> deleteFolders(@RequestBody Set<Long> folderIds,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :deleteFolders()");
		ResponseObject resp = new ResponseObject();
		Set<String> notDeletedFolders=new HashSet<>();
		try{
			for(Long folderId : folderIds){
				if (folderId == null) {
					throw new AdminException("WL3089");
				}
			}
			for(Long folderId : folderIds){
				try{
					departmentService.deleteFolder(folderId);
				}catch (AdminException ae) {
					if("ADM042".equalsIgnoreCase(ae.getErrorCode()) || "ADM043".equalsIgnoreCase(ae.getErrorCode()))
						throw ae;
					logger.error("Error occurred while deleting folder", ae);
					if(ae.getObject()!=null && ae.getObject().length>0)
						notDeletedFolders.add((String) ae.getObject()[0]);
				}
			}
			if(!notDeletedFolders.isEmpty()){
				Object[] param=new Object[1];
				param[0]="'"+StringUtils.join(notDeletedFolders, ", '")+"'";
				resp.addError("Couldn't delete these folders",messageSource.getMessage("ADM036",param,LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ae) {
			logger.error("Error occurred while deleting folders", ae);
			resp.addError("Error occurred while deleting folders",
					messageSource.getMessage(ae.getErrorCode(),ae.getObject(), LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
		logger.debug("Ends :" + getClass().getName() + " :deleteFolders()");
		resp.setMessage("Selected folders deleted successfully.");
	    resp.setHttpStatusCode(HttpStatus.OK.value());
		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param categoryBO
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(path = "/saveCategory", method = RequestMethod.POST)
	public ResponseEntity<?> saveCategory(@RequestBody CategoryBO categoryBO, BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws JsonParseException, JsonMappingException, IOException {
		MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
		headersMap.add("X-XSS-Protection", "1; mode=block");
		ObjectMapper mapper = new ObjectMapper();
		
	    //categoryBO = mapper.readValue(escapeSpecialChars(mapper.writeValueAsString(categoryBO)), CategoryBO.class)
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, headersMap,HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :saveCategory()");
		ResponseObject resp = new ResponseObject();
		CategoryBO updatedCategory = null;
		try {
			updatedCategory = departmentService.saveCategory(categoryBO, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp,headersMap, HttpStatus.BAD_REQUEST);
			}	
		} catch (AdminException ae) {
			logger.error("Error occurred while saving category", ae);
			resp.addError("Error occurred while saving category",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp,headersMap, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :saveCategory()");
		updatedCategory = mapper.readValue(escapeSpecialChars(mapper.writeValueAsString(updatedCategory)), CategoryBO.class);
		//updatedCategory = mapper.readValue(stripXSS(categoryBO), CategoryBO.class);
		return new ResponseEntity <CategoryBO> (updatedCategory,headersMap, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param categoryId
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getCategory/{categoryId}",method=RequestMethod.GET)
	public ResponseEntity<?> getCategory(@PathVariable Long categoryId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		CategoryBO categoryBO = null;
		try {
			if (categoryId == null) {
				throw new AdminException("WL3089");
			}
			categoryBO = departmentService.getCategory(categoryId);
			if (categoryBO == null) {
				logger.error(" No Category exists with the given ID.");
				throw new AdminException("F00051");
			}
		} catch (AdminException ae) {
			logger.error("Error occurred while fetching the category", ae);
			resp.addError("Error occurred while fetching the category",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :getCategory()");
		return new ResponseEntity<CategoryBO>(categoryBO, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param listingCriteria
	 * @param result
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(path="/listCategories",method=RequestMethod.POST)
	public ResponseEntity<?> listCategories(@RequestBody CategoriesListingCriteria listingCriteria,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :listCategories()");
		ResponseObject resp = new ResponseObject();
		List<CategoryBO> categoriesList = null;
		List<CategoryBO> allCategories = new ArrayList<>();
		try {
			categoriesList = departmentService.listCategories(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
			CategoryBO categoryBO = new CategoryBO();
			DepartmentBO department = departmentService.getDepartment(listingCriteria.getDepartmentId());
			categoryBO.setCategorycode(department.getDepartmentName());
			categoryBO.setCategoryid(0L);
			allCategories.add(categoryBO);
			allCategories.addAll(categoriesList);
		} catch (AdminException ae) {
			logger.error("Error occurred while listing categories", ae);
			resp.addError("Error occurred while listing categories",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}catch (Exception e) {
			logger.error("Error occurred while listing categories", e);
			bindingResult.reject(messageSource.getMessage("ADM058", new Object[] {},LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :listCategories()");
		return new ResponseEntity<List<CategoryBO>>(allCategories, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param categoryId
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")})
	@RequestMapping(path = "/deleteCategory/{categoryId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteCategory(@PathVariable Long categoryId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :deleteCategory()");
		ResponseObject resp = new ResponseObject();
		Boolean deleteStatus = false;
		try {
			if (categoryId == null) {
				throw new AdminException("WL3089");
			}
			deleteStatus = departmentService.deleteCategory(categoryId);
		} catch (AdminException ae) {
			logger.error("Error occurred while deleting category", ae);
			resp.addError("Error occurred while deleting category",
					messageSource.getMessage(ae.getErrorCode(),ae.getObject(), LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}

		logger.debug("Ends :" + getClass().getName() + " :deleteCategory()");
		return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param folderId
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "180000")})
	@RequestMapping(path="/deleteCategories",method=RequestMethod.POST)
	public ResponseEntity<?> deleteCategories(@RequestBody Set<Long> categoryIds,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :deleteCategories()");
		ResponseObject resp = new ResponseObject();
		Set<String> notDeletedCategories=new HashSet<>();
		try{
			for(Long categoryId : categoryIds){
				if (categoryId == null) {
					throw new AdminException("WL3089");
				}
			}
			for(Long categoryId : categoryIds){
				try{
					departmentService.deleteCategory(categoryId);
				}catch (AdminException ae) {
					if("ADM042".equalsIgnoreCase(ae.getErrorCode()) || "ADM043".equalsIgnoreCase(ae.getErrorCode()))
						throw ae;
					logger.error("Error occurred while deleting category", ae);
					if(ae.getObject()!=null && ae.getObject().length>0)
						notDeletedCategories.add((String) ae.getObject()[0]);
				}
			}
			if(!notDeletedCategories.isEmpty()){
				Object[] param=new Object[1];
				param[0]="'"+StringUtils.join(notDeletedCategories, ", '")+"'";
				resp.addError("Couldn't delete these categories",messageSource.getMessage("ADM040",param,LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		} catch (AdminException ae) {
			logger.error("Error occurred while deleting categories", ae);
			resp.addError("Error occurred while deleting categories",
					messageSource.getMessage(ae.getErrorCode(),ae.getObject(), LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
		logger.debug("Ends :" + getClass().getName() + " :deleteCategories()");
		resp.setMessage("Selected categories deleted successfully.");
	    resp.setHttpStatusCode(HttpStatus.OK.value());
		return new ResponseEntity<>(resp, HttpStatus.OK);
	}

	
	
	/**
	 * Check if category exists with type and dept.
	 *
	 * @param categoryName the category name
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return the response entity
	 */
	@HystrixCommand
	@RequestMapping(path = "/checkIfCategoryExists", method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> checkIfCategoryExistsWithTypeAndDept(@RequestBody Map<String,Object> json,BindingResult result,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :checkIfCategoryExistsWithTypeAndDept()");
		ResponseObject resp = new ResponseObject();
		Boolean ifExists = false;
		String type = null;
		String categoryCode =null;
		Long departmentId = null;
		Long categoryId = null;
		try {
			if (json.get("type") != null) {
				type = json.get("type").toString();
			}
			if (json.get("categoryCode") != null) {
				categoryCode = json.get("categoryCode").toString();
			}
			if (json.get("departmentId") != null) {
				departmentId = Long.parseLong(json.get("departmentId").toString());
			}
			if (json.get("categoryId") != null) {
				categoryId = Long.parseLong(json.get("categoryId").toString());
			}
			ifExists = departmentService.checkIfCategoryExistsWithTypeAndDept(categoryCode,type.charAt(0),departmentId,categoryId);
		} catch (AdminException ae) {
			logger.error("Error occurred while checking category exists with type and deparment", ae);
			resp.addError("Error occurred while checking category exists with type and deparment",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :checkIfCategoryExistsWithTypeAndDept()");
		return new ResponseEntity<Boolean>(ifExists, HttpStatus.OK);
		
	}
	
	/**
	 * Find category by type and dept.
	 *
	 * @param categoryName the category name
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return the category bo
	 */
	@HystrixCommand
	@RequestMapping(path = "/findCategoryByTypeAndDept", method = RequestMethod.POST)
	public ResponseEntity<?> findCategoryByTypeAndDept(@RequestBody Map<String,Object> json,BindingResult result,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :findCategoryByTypeAndDept()");
		ResponseObject resp = new ResponseObject();
		CategoryBO category = null;
		String type = null;
		String categoryCode =null;
		Long departmentId = null;
		try {
			if(json.get("type") == null || 
					json.get("categoryCode") == null || json.get("departmentId") == null ){
				throw new AdminException("WL3089");
			}
			if (json.get("type") != null) {
				type = json.get("type").toString();
			}
			if (json.get("categoryCode") != null) {
				categoryCode = json.get("categoryCode").toString();
			}
			if (json.get("departmentId") != null) {
				departmentId = Long.parseLong(json.get("departmentId").toString());
			}
			category = departmentService.findCategoryByTypeAndDept(type.charAt(0), categoryCode, departmentId);
		} catch (AdminException ae) {
			logger.error("Error occurred while finding category with type and deparment", ae);
			resp.addError("Error occurred while finding category with type and deparment",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :findCategoryByTypeAndDept()");
		return new ResponseEntity<CategoryBO>(category, HttpStatus.OK);
		
	}
			
	

	/**
	 * @param json
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "/checkIfFolderExists", method = RequestMethod.POST)
	public ResponseEntity<?> checkIfFolderExists(@RequestBody Map<String,Object> json,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :checkIfFolderExists()");
		ResponseObject resp = new ResponseObject();
		Boolean ifExists = false;
		String folderName;
		Character type;
		Long departmentId=0L;
		Long folderId=0L;
		try {
			if(json.get("folderName") == null)
				throw new AdminException("WL3089");
			else
			    folderName=json.get("folderName").toString();
			if(json.get("type") == null)
				throw new AdminException("WL3089");
			else
				type=json.get("type").toString().charAt(0);
			if(json.get("departmentId") == null)
				throw new AdminException("WL3089");
			else
				departmentId=Long.parseLong(json.get("departmentId").toString());
			if(json.get("folderId") == null)
				throw new AdminException("WL3089");
			else
				folderId=Long.parseLong(json.get("folderId").toString());
			ifExists = departmentService.checkIfFolderExists(folderName, type, departmentId, folderId);
		} catch (AdminException ae) {
			logger.error("Error occurred while checking folder exists with type and deparment", ae);
			resp.addError("Error occurred while checking folder exists with type and deparment",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :checkIfFolderExists()");
		return new ResponseEntity<Boolean>(ifExists, HttpStatus.OK);
	}
	

	/**
	 * @param json
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "/findFolder", method = RequestMethod.POST)
	public ResponseEntity<?> findFolder(@RequestBody Map<String,Object> json,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Start :" + getClass().getName() + " :findFolder()");
		ResponseObject resp = new ResponseObject();
		FolderBO folder = null;
		String folderName;
		Character type;
		Long departmentId=0L;
		try {
			if(json.get("folderName") == null)
				throw new AdminException("WL3089");
			else
			    folderName=json.get("folderName").toString();
			if(json.get("type") == null)
				throw new AdminException("WL3089");
			else
				type=json.get("type").toString().charAt(0);
			if(json.get("departmentId") == null)
				throw new AdminException("WL3089");
			else
				departmentId=Long.parseLong(json.get("departmentId").toString());
			folder = departmentService.findFolder(folderName, type, departmentId);
		} catch (AdminException ae) {
			logger.error("Error occurred while checking folder exists with type and deparment", ae);
			resp.addError("Error occurred while checking folder exists with type and deparment",
					messageSource.getMessage(ae.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.debug("Ends :" + getClass().getName() + " :findFolder()");
		return new ResponseEntity<FolderBO>(folder, HttpStatus.OK);
		
	}
	
	/**
	 * @param passedURL
	 * @param bindingResult
	 * @return
	 */
	@CrossOrigin
	@HystrixCommand
	@RequestMapping(path="validateDomain",method=RequestMethod.POST)
	public ResponseEntity<?> validateDomain(@RequestBody String passedURL,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
	    try {
	    	String domainURL=URLDecoder.decode(passedURL,Charset.defaultCharset().toString());
			//Replacing "//" with "/" 
			if(domainURL.indexOf("://") != -1){
				String[] parts = domainURL.split("://");
				domainURL = parts[0] + "://" + parts[1].replaceAll("//", "/");
			}
			
	        URL url = new URL(domainURL);
//	        IOUtils.toString(url,Charset.defaultCharset());
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setInstanceFollowRedirects(true);
			connection.connect();
			if (connection.getResponseCode() == 200
					|| (connection.getResponseCode() >= 300 && connection.getResponseCode() < 400)) {
				resp.setMessage("Passed URL is valid.");
		        resp.setHttpStatusCode(HttpStatus.OK.value());
		        return new ResponseEntity<>(resp, HttpStatus.OK);
			}else{
				resp.setMessage("Provide Valid Domain");
				resp.setHttpStatusCode(connection.getResponseCode());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
	    } catch (Exception ex) {
	    	logger.error("Error occurred while validating url", ex);
	    	bindingResult.reject(messageSource.getMessage("ADM018", new Object[]{passedURL},LocaleContextHolder.getLocale()),ex.getMessage());
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
	    }
	}
	
	/**
	 * This method is used to get the GA auhorization URL
	 * @param 
	 * @return authorized url string
	 * @throws EbizException
	 */
	@HystrixCommand
	@RequestMapping(path="getGAAuthURL",method=RequestMethod.GET)
	public ResponseEntity<?> getGAAuthURL(@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		HttpHeaders header = new HttpHeaders();
		try {
			String authURL = googleAnalyticsService.getGAAuthURL();
			header.setContentType(MediaType.TEXT_PLAIN);
			return new ResponseEntity<>(authURL, header, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching Google Authorization URL", ex);
			resp.addError("Error occurred while fetching Google Authorization URL",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			headers.setContentType(MediaType.APPLICATION_JSON);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param listingCriteria
	 * @param result
	 * @return
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path="/authorizeGA",method=RequestMethod.POST)
	public ResponseEntity<?> authorizeGA(@RequestBody GAAccount gaAccProObj,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		gaAccProObj=googleAnalyticsService.authorizeGoogleAnalyticsProfile(gaAccProObj, bindingResult);
		if (bindingResult.hasErrors()) {
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp,HttpStatus.BAD_REQUEST);
		}else
			return new ResponseEntity<>(gaAccProObj, HttpStatus.OK);
	}
	
	/**
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/uploadNow",method=RequestMethod.POST)
	public ResponseEntity<?> uploadNow(@RequestBody Long departmentId,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try{
			DepartmentBO department = departmentService.getDepartment(departmentId);
			if(department!=null){
				for(DepartmentSettings departmentSetting : department.getDepartmentSettings()){
					if(Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
						AdobeAnalyticsBO adobeAnalyticsBO=(AdobeAnalyticsBO) departmentSetting.getObjectValue();
						Boolean isInProgress=false;
						Boolean containsOnDemandEntry=false;
						for(AdobeRunDetailsBO runDetail : adobeAnalyticsBO.getRunDetails()){
							if(runDetail.getOnDemandUpload() && (runDetail.getStatus()=='W' || runDetail.getStatus()=='I')){
								containsOnDemandEntry=true;
								isInProgress=true;
							}
							else if(!runDetail.getOnDemandUpload() && runDetail.getStatus()=='I')
									isInProgress=true;
						}
						if(isInProgress)
							throw new AdminException("ADM041");
						else if(!containsOnDemandEntry){
							AdobeRunDetailsBO runDetail=new AdobeRunDetailsBO();
							runDetail.setOnDemandUpload(true);
							runDetail.setScheduleNextDue(new Date());
							runDetail.setStatus('W');
							adobeAnalyticsBO.getRunDetails().add(runDetail);
						}else{
							for(AdobeRunDetailsBO runDetail : adobeAnalyticsBO.getRunDetails()){
								if(runDetail.getOnDemandUpload())
									runDetail.setScheduleNextDue(new Date());
							}
						}
					}
				}
				departmentService.saveDepartment(department, bindingResult);
			}
		}catch(AdminException e){
			logger.error("Error while calling uploadNow :: ",e);
			bindingResult.reject(messageSource.getMessage(e.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			logger.error("Error while calling uploadNow :: ",e);
			bindingResult.reject(messageSource.getMessage("ADM059", new Object[] {},LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		resp.setMessage("Upload initiated for adobe analytics");
	    resp.setHttpStatusCode(HttpStatus.OK.value());
		return new ResponseEntity<>(resp, HttpStatus.OK);
	} 
	
	/**
	 * @param folderId
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="getConversationsByFolderId/{folderId}",method=RequestMethod.GET)
	public ResponseEntity<?> getConversationsByFolderId(@PathVariable Long folderId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		List<Conversation> conversationsList=null;
		try {
			conversationsList = departmentService.getConversationsByFolderId(folderId);
			return new ResponseEntity<>(conversationsList,HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching conversations", ex);
			resp.addError("Error occurred while fetching conversations",messageSource.getMessage(ex.getErrorCode(), new Object[]{},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param folderId
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="getContentsByFolderId/{folderId}",method=RequestMethod.GET)
	public ResponseEntity<?> getContentsByFolderId(@PathVariable Long folderId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		List<ContentTemplateBO> contentsList=null;
		try {
			contentsList = departmentService.getContentsByFolderId(folderId);
			return new ResponseEntity<>(contentsList,HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching contents", ex);
			resp.addError("Error occurred while fetching contents",messageSource.getMessage(ex.getErrorCode(),new Object[]{},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * @param departmentID
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "getMobileForDepartment", method = RequestMethod.POST)
	public ResponseEntity<?> getMobileForDepartment(@RequestBody Long departmentID, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentID);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			MobileBO mobileBO = mobileService.getMobileBOForDepartment(departmentID, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, MOBILE_ERROR_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(mobileBO, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching mobile bo", ex);
			resp.addError("Error occurred while fetching mobile bo",messageSource.getMessage(ex.getErrorCode(),new Object[]{},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param departmentID
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "listShortCodes", method = RequestMethod.POST)
	public ResponseEntity<?> listShortCodes(@RequestBody Long departmentID, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentID);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			List<ShortCode> shortCodes = mobileService.listShortCodes(departmentID, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, MOBILE_LIST_SHORTCODE_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(shortCodes, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while listing short codes", ex);
			resp.addError("Error occurred while listing short codes",messageSource.getMessage(ex.getErrorCode(),new Object[]{},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param departmentID
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "listTestGroups", method = RequestMethod.POST)
	public ResponseEntity<?> listTestGroups(@RequestBody Long departmentID, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentID);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			List<TestGroup> testGroups = mobileService.listTestGroups(departmentID, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, MOBILE_LIST_TESTGROUP_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(testGroups, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while listing test groups", ex);
			resp.addError("Error occurred while listing test groups",messageSource.getMessage(ex.getErrorCode(),new Object[]{},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param json
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "createTestGroup", method = RequestMethod.POST)
	public ResponseEntity<?> createTestGroup(@RequestBody Map<String, Object> json, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		ResponseObject resp = new ResponseObject();
		try {
			Long departmentID = Long.parseLong(json.get("departmentId").toString());
			List<TestGroup> newTestGroups = objectMapper.convertValue(json.get("testGroups"),
					new TypeReference<List<TestGroup>>() {
					});
			List<TestGroup> testGroups = mobileService.createTestGroup(departmentID, newTestGroups, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, MOBILE_SAVE_TESTGROUP_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(testGroups, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while calling service for creating test groups :: ", e);
			bindingResult.reject(messageSource.getMessage("ADM060", new Object[] {}, LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * @param json
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "updateTestGroup", method = RequestMethod.POST)
	public ResponseEntity<?> updateTestGroup(@RequestBody Map<String, Object> json, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ResponseObject resp = new ResponseObject();
		try {
			Long departmentID = Long.parseLong(json.get("departmentId").toString());
			List<TestGroup> newTestGroups = objectMapper.convertValue(json.get("testGroups"),
					new TypeReference<List<TestGroup>>() {
					});
			List<TestGroup> testGroups = mobileService.updateTestGroup(departmentID, newTestGroups, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, MOBILE_SAVE_TESTGROUP_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(testGroups, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while calling service for updating test groups :: ", e);
			bindingResult.reject(messageSource.getMessage("ADM061", new Object[] {}, LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * @param ids
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "deleteConversations", method = RequestMethod.POST)
	public ResponseEntity<?> deleteConversations(@RequestBody List<Long> ids, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		Boolean status = false;
		try {
			status = departmentService.deleteConversations(ids);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult,
						messageSource.getMessage("ADM076", new Object[] {}, LocaleContextHolder.getLocale()));
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			} else
				return new ResponseEntity<>(String.valueOf(status), HttpStatus.OK);
		} catch (AdminException e) {
			logger.error("Error while calling service to delete the conversations:: ", e);
			bindingResult.reject(messageSource.getMessage("ADM076", new Object[] {}, LocaleContextHolder.getLocale()));
			resp.addErrors(bindingResult,
					messageSource.getMessage(e.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param selectedTemplateIds
	 * @param selectedTemplateType
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "deleteContents", method = RequestMethod.POST)
	public ResponseEntity<?> deleteContents(@PathParam("selectedTemplateIds") String selectedTemplateIds,
			@PathParam("selectedTemplateType") String selectedTemplateType,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		Boolean status = false;
		try {
			status = departmentService.deleteContents(selectedTemplateIds, selectedTemplateType);
			return new ResponseEntity<>(String.valueOf(status), HttpStatus.OK);
		} catch (AdminException e) {
			logger.error("Error while calling service to delete the content:: ", e);
			resp.addError("Error while deleting the content",
					messageSource.getMessage(e.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param deptId
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "getTrashConversations/{deptId}", method = RequestMethod.GET)
	public ResponseEntity<?> getTrashConversations(@PathVariable Long deptId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		List<Conversation> conversationsList = null;
		try {
			conversationsList = departmentService.getTrashConversations(deptId);
			return new ResponseEntity<>(conversationsList, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching trashed conversations", ex);
			resp.addError("Error occurred while fetching trashed conversations",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @param folderId
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "getTrashContents/{folderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getTrashContents(@PathVariable Long folderId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		List<ContentTemplateBO> contentsList = null;
		try {
			contentsList = departmentService.getTrashContents(folderId);
			return new ResponseEntity<>(contentsList, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching contents", ex);
			resp.addError("Error occurred while fetching contents",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param convIds
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "restoreConversations", method = RequestMethod.POST)
	public ResponseEntity<?> restoreConversations(@RequestBody List<Long> convIds,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			String status = departmentService.restoreConversations(convIds);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while restoring trashed items", ex);
			resp.addError("Error occurred while restoring trashed items",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param contentIds
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "restoreContents", method = RequestMethod.POST)
	public ResponseEntity<?> restoreContents(@PathParam("selectedTemplateIds") String selectedTemplateIds,
			@PathParam("selectedTemplateType") String selectedTemplateType,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			Boolean status = departmentService.restoreContents(selectedTemplateIds, selectedTemplateType);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while restoring trashed items", ex);
			resp.addError("Error occurred while restoring trashed items",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param convIds
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "emptyTrashConversations", method = RequestMethod.POST)
	public ResponseEntity<?> emptyTrashConversations(@RequestBody List<Long> convIds,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			String status = departmentService.emptyTrashConversations(convIds);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while emptying the trashed items", ex);
			resp.addError("Error occurred while emptying trashed items",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param selectedTrashId
	 * @param selectedTemplateType
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path = "emptyTrashContents", method = RequestMethod.POST)
	public ResponseEntity<?> emptyTrashContents(@PathParam("selectedTrashId") String selectedTrashId,
			@PathParam("selectedTemplateType") String selectedTemplateType,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			Boolean status = departmentService.emptyTrashContents(selectedTrashId, selectedTemplateType);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while emptying trashed items", ex);
			resp.addError("Error occurred while emptying trashed items",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="saveDefaultWebPages/{departmentId}",method=RequestMethod.GET)
	public ResponseEntity<?> saveDefaultWebPages(@PathVariable Long departmentId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", departmentId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			webPageService.saveDefaultWebPages(departmentId);
			return new ResponseEntity<>("Default web pages created successfully.",HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while saving default web page templates.", ex);
			resp.addError("Error occurred while saving default web page templates.",messageSource.getMessage(ex.getErrorCode(), new Object[] {departmentId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
   public static ResponseEntity<?> stripCrossSiteScripting(Object object) {
    	
    	ObjectMapper mapperObj = new ObjectMapper();
    	String obj = null;
    	MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
		headersMap.add("X-XSS-Protection", "1; mode=block");
		try {
			obj = mapperObj.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
    	
        if (obj != null) {
            // Avoid null characters
            obj = obj.replaceAll("", "");

            // Avoid anything between script tags
            Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid anything in a src='...' type of expression
            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");

            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Remove any lonesome </script> tag
            scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Remove any lonesome <script ...> tag
            scriptPattern = Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid eval(...) expressions
            scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid expression(...) expressions
            scriptPattern = Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid javascript:... expressions
            scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid vbscript:... expressions
            scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
            obj = scriptPattern.matcher(obj).replaceAll("");

            // Avoid onload= expressions
            scriptPattern = Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            obj = scriptPattern.matcher(obj).replaceAll("");
        }
        return new ResponseEntity<>(obj, headersMap,HttpStatus.OK);
    }
   
   
   public static String stripXSS(Object object) {
   	
   	ObjectMapper mapperObj = new ObjectMapper();
   	String obj = null;
		try {
			obj = mapperObj.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
   	
       if (obj != null) {
           // NOTE: It's highly recommended to use the ESAPI library and uncomment the following line to
           // avoid encoded attacks.
           // value = ESAPI.encoder().canonicalize(value);

           // Avoid null characters
           obj = obj.replaceAll("", "");

           // Avoid anything between script tags
           Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid anything in a src='...' type of expression
           scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");

           scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Remove any lonesome </script> tag
           scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Remove any lonesome <script ...> tag
           scriptPattern = Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid eval(...) expressions
           scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid expression(...) expressions
           scriptPattern = Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid javascript:... expressions
           scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid vbscript:... expressions
           scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
           obj = scriptPattern.matcher(obj).replaceAll("");

           // Avoid onload= expressions
           scriptPattern = Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
           obj = scriptPattern.matcher(obj).replaceAll("");
       }
       return obj;
   }
   
   public static String escapeSpecialChars(String target){
       //Escaping Utf-7 special chars
       target = target.replaceAll("[^\\x00-\\x7F]", "");
       //Escaping html special chars
       target = target.replaceAll("<", "&lt;");
       target = target.replaceAll(">", "&gt;");
       target = target.replaceAll("&", "&amp;");
      // target = target.replaceAll("\"", "&quot;");
       target = target.replaceAll("\'", "&#39;");
       return target;
   }
   
   /**
	 * @param listingCriteria
	 * @param result
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getAllDepartments",method=RequestMethod.POST)
	public ResponseEntity<?> getAllDepartments(@RequestBody ListingCriteria listingCriteria,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			List<DepartmentBO> departmentsList=departmentService.getAllDepartments(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, DEFAULT_MESSAGE);
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else
				return new ResponseEntity<>(departmentsList, HttpStatus.OK);
		}catch (AdminException ex) {
			resp.addError("Some thing went wrong while updating department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	  /**
		 * @param listingCriteria
		 * @param result
		 * @return
		 */
		@HystrixCommand
		@RequestMapping(path="/getAllDepartmentSettings",method=RequestMethod.POST)
		public ResponseEntity<?> getAllDepartmentSettings(@RequestHeader HttpHeaders headers){
			logger.info("Start :" + getClass().getName() + " :getAllDepartmentSettings()");
			try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
			if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
				ResponseObject resp = new ResponseObject();
				resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
						new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
			}
			ResponseObject resp=new ResponseObject();
			try{
				logger.info("Before departmentService.getAllDepartmentSettings()....");
				List<DepartmentSettings> departmentSettingsList = departmentService.getAllDepartmentSettings();
				logger.info("After departmentService.getAllDepartmentSettings()....");
				return new ResponseEntity<>(departmentSettingsList, HttpStatus.OK);
			}catch (AdminException ex) {
				resp.addError("Some thing went wrong while updating department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		}
		
	@HystrixCommand
	@RequestMapping(path="/isDepartmentExistsByNameOrId",method=RequestMethod.POST)
	public ResponseEntity<?> isDepartmentExistsByNameOrId(@RequestBody Map<String,String> json,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			Boolean exists=departmentService.isDepartmentExistsByNameOrId(json);
			return new ResponseEntity<>(exists, HttpStatus.OK);
		}catch (AdminException ex) {
			resp.addError("Some thing went wrong while updating department specific property :: ",messageSource.getMessage(ex.getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: accessAudienceToAllDepartments
	 * Description 	: The Method "accessAudienceToAllDepartments" is used for providing audience access for all departments
	 * Date    		: 24 Jan 2018, 11:04:10
	 * @param audienceId
	 * @param headers
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	
	@HystrixCommand(commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "120000")})
	@RequestMapping(path="/accessAudienceToAllDepartments/{audienceId}",method=RequestMethod.POST)
	public ResponseEntity<?> accessAudienceToAllDepartments(@PathVariable Long audienceId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			return new ResponseEntity<>(departmentService.accessAudienceToAllDepartments(audienceId), HttpStatus.OK);
		}catch (Exception ex) {
			logger.error(ex.getMessage(),ex);
			resp.addError("Error ","Exception occurred while updating audience access to all departments.");
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: getDeptSpecificAudiences
	 * Description 	: The Method "getDeptSpecificAudiences" is used for 
	 * Date    		: 24 Jan 2018, 12:52:05
	 * @param departmentId
	 * @param headers
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(path="/getDeptSpecificAudiences/{departmentId}",method=RequestMethod.GET)
	public ResponseEntity<?> getDeptSpecificAudiences(@PathVariable Long departmentId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DEPARTMENT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("DEPARTMENTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, DEPARTMENT, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {DEPARTMENT},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp=new ResponseObject();
		try{
			return new ResponseEntity<>(departmentService.getDeptSpecificAudiences(departmentId), HttpStatus.OK);
		}catch (Exception ex) {
			logger.error(ex.getMessage(),ex);
			resp.addError("Error ","Exception occurred while fetching department specific audiences.");
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
}

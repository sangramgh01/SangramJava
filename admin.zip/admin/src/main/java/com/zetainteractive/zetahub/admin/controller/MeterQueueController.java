/**
 * MeterQueueController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.MeterQueueService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.MeterQueue;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @Author : srinivasa.katta
 * @Created On : Aug 2, 2016 12:00:54 PM
 * @Version : 1.7
 * @Description : "MeterQueueController" is used for meter queue REST API calls
 * 
 **/
@RestController
public class MeterQueueController {
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	private static final String RESOURCE_NAME = "admin";
	
	@Autowired
	MeterQueueService meterQueueService;
	@Autowired
	MessageSource messageSource;
	
	/**
	 * Save meter queue.
	 *
	 * @param meterQueue the meter queue
	 * @param bindingResult the binding result
	 * @return the response entity
	 * @throws AdminException the admin exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveMeterQueue/{isDefaultOverride}", method = RequestMethod.POST)
	public ResponseEntity<?> saveMeterQueue(@RequestBody MeterQueue meterQueue,@PathVariable Boolean isDefaultOverride,BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueue.getMeterQueueId());}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :saveMeterQueue()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"Throttle"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Integer meterQueueId = null;
		try {
			meterQueueId = meterQueueService.saveMeterQueue(meterQueue, isDefaultOverride, bindingResult);
			logger.debug("meterQueueId --------->"+meterQueueId);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			meterQueue.setMeterQueueId(meterQueue.getMeterQueueId());
		} catch (AdminException ex) {
			logger.error("Error occurred while saving meter queue details", ex);
			resp.addError("Error occurred while saving meter queue details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueue.getMeterQueueId()},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.info("End :" + getClass().getName() + " :saveMeterQueue()");
		return new ResponseEntity<MeterQueue>(meterQueue, HttpStatus.OK);
		
	}
	
	
	/**
	 * Delete meter queue.
	 *
	 * @param meterQueueId the meter queue id
	 * @return the response entity
	 * @throws AdminException the admin exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteMeterQueue/{meterQueueId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteMeterQueue(@PathVariable Integer meterQueueId,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueueId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :deleteMeterQueue()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "Throttle" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean deleteStatus = false;
		Map<String,Boolean> resultMap = new HashMap<String,Boolean>();
		try {
			if(meterQueueId == null || meterQueueId == 0) {
				throw new AdminException("MQ0005");
			}
			
			String associatedConversations = findAssociatedConversations(meterQueueId);
			if (associatedConversations != null && !associatedConversations.isEmpty()) {
				logger.error("Meter queue is associated with conversations :"+associatedConversations);
				throw new AdminException("MQ0008");
			}
			deleteStatus = meterQueueService.deleteMeterQueue(meterQueueId);
			resultMap.put("status", deleteStatus);
			return new ResponseEntity<Map<String,Boolean>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleteing meter queue details", ex);
			resp.addError("Error occurred while deleteing meter queue details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueueId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find meter queue by id.
	 *
	 * @param meterQueueId the meter queue id
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findMeterQueueById/{meterQueueId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findMeterQueueById(@PathVariable Integer meterQueueId,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueueId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :findMeterQueueById()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "findMeterQueueById" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			if(meterQueueId == null || meterQueueId == 0) {
				throw new AdminException("MQ0005");
			}
			return new ResponseEntity<MeterQueue>(meterQueueService.findMeterQueueById(meterQueueId), HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching meter queue by id ", ex);
			resp.addError("Error occurred while fetching meter queue by id",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueueId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find meter queue by name.
	 *
	 * @param meterQueueName
	 *            the meter queue name
	 * @return the response entity
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findMeterQueueByName/{meterQueueName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findMeterQueueByName(@PathVariable String meterQueueName,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueueName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :findMeterQueueByName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "findMeterQueueByName" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			logger.debug("meterQueueName -------------->"+meterQueueName);
			if (meterQueueName == null || meterQueueName.isEmpty()) {
				throw new AdminException("MQ0006");
			}
			return new ResponseEntity<MeterQueue>(meterQueueService.findMeterQueueByName(meterQueueName),
					HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching meter queue by name  ", ex);
			resp.addError("Error occurred while fetching meter queue by name", messageSource
					.getMessage(ex.getErrorCode(), new Object[] {meterQueueName}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is meter queue exists.
	 *
	 * @param meterQueueName the meter queue name
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isMeterQueueExists/{meterQueueName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isMeterQueueExists(@PathVariable String meterQueueName,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueueName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :isMeterQueueExists()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "isMeterQueueExists" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean isExists = false;
		Map<String,Boolean> resultMap = new HashMap<String,Boolean>();
		resultMap.put("isMeterQueue", isExists);
		try {
			if (meterQueueName == null || meterQueueName.isEmpty()) {
				throw new AdminException("MQ0006");
			}
			MeterQueue mq = meterQueueService.findMeterQueueByName(meterQueueName);
			if(mq != null) {
				isExists = true;
				resultMap.put("isMeterQueue", isExists);
			}
			return new ResponseEntity<Map<String,Boolean>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching meter queue details", ex);
			resp.addError("Error occurred while fetching meter queue details ",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueueName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is meter queue exists with name and id.
	 *
	 * @param meterQueueId the meter queue id
	 * @param meterQueueName the meter queue name
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isMeterQueueExistsWithNameAndId/{meterQueueId}/{meterQueueName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isMeterQueueExistsWithNameAndId(@PathVariable Integer meterQueueId, @PathVariable String meterQueueName,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", meterQueueId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :isMeterQueueExistsWithNameAndId()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "isMeterQueueExistsWithNameAndId" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean isExists = false;
		Map<String,Boolean> resultMap = new HashMap<String,Boolean>();
		resultMap.put("isMeterQueue", isExists);
		try {
			if (meterQueueName == null || meterQueueName.isEmpty()) {
				throw new AdminException("MQ0006");
			}
			isExists = meterQueueService.isMeterQueueExists(meterQueueName, meterQueueId);
			resultMap.put("isMeterQueue", isExists);
			return new ResponseEntity<Map<String,Boolean>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching meter queue details", ex);
			resp.addError("Error occurred while fetching meter queue details ",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueueName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is meter queue exists.
	 *
	 * @param meterQueueName the meter queue name
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isDefaultMeterQueueExistsForClient", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isDefaultMeterQueueExistsForClient(@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :isDefaultMeterQueueExistsForClient()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "isDefaultMeterQueueExistsForClient" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean isExists = false;
		Map<String,Boolean> resultMap = new HashMap<String,Boolean>();
		Integer customerID = null;
		try {
			customerID = new Integer(1); // temporarily hard coded need to get from Context object
			MeterQueue mq = meterQueueService.isDefaultMeterQueueExistsForClient(customerID);
			if(mq != null) {
				isExists = true;
			}
			resultMap.put("isMeterQueueExists", isExists);
			return new ResponseEntity<Map<String,Boolean>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching meter queue details", ex);
			resp.addError("Error occurred while fetching meter queue details ",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is default meter queue exists.
	 *
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/existingDefaultMeterQueueForClient", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> existingDefaultMeterQueueExistsForClient(@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :existingDefaultMeterQueueForClient()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "existingDefaultMeterQueueForClient" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Integer customerID = null;
		String meterQueueName = "";
		Map<String,String> resultMap = new HashMap<String,String>();
		try {
			customerID = new Integer(1); // temporarily hard coded need to get from Context object
			MeterQueue mq = meterQueueService.isDefaultMeterQueueExistsForClient(customerID);
			if(mq != null) {
				meterQueueName= mq.getMeterQueueName();
				resultMap.put("response", meterQueueName);
			}
			return new ResponseEntity<Map<String,String>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching default meter queue for client", ex);
			resp.addError("Error occurred while fetching default meter queue for client ",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {meterQueueName},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find meter queues by criteria.
	 *
	 * @param listingCriteria the listing criteria
	 * @param bindingResult the binding result
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/findMeterQueuesByCriteria", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findMeterQueuesByCriteria(@RequestBody AudienceSearchCriteria listingCriteria,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :findMeterQueuesByCriteria()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "findMeterQueuesByCriteria" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<MeterQueue> meterQueueList = null;
		try {
			listingCriteria.setColumnNames(Constants.ADM_METERQUEUE_COLUMNS);
			meterQueueList = meterQueueService.findMeterQueuesByCriteria(listingCriteria, bindingResult);
			if (bindingResult.hasErrors()) {
				if (bindingResult.hasErrors()) {
					resp.addErrors(bindingResult, "Invalid Data");
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
				}
			}
			return new ResponseEntity<List<MeterQueue>>(meterQueueList, HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching meter queue details", ex);
			resp.addError("Error occurred while fetching meter queue details ",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find meter queues by criteria.
	 *
	 * @param listingCriteria the listing criteria
	 * @param bindingResult the binding result
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/listMeterQueues", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> listMeterQueues(@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :listMeterQueues()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "listMeterQueues" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<MeterQueue> meterQueueList = null;
		try {
			
			meterQueueList = meterQueueService.listMeterQueues("ALL");
			if (meterQueueList.isEmpty()) {
				throw new AdminException("MQ0007");
			}
			return new ResponseEntity<List<MeterQueue>>(meterQueueList, HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching meter queue details", ex);
			resp.addError("Error occurred while fetching meter queue details ",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Find all active meter queues .
	 *
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/listActiveMeterQueues", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> listActiveMeterQueues(@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :listActiveMeterQueues()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "listActiveMeterQueues" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		List<MeterQueue> meterQueueList = null;
		try {
			meterQueueList = meterQueueService.listMeterQueues(Constants.STATUS_ACTIVE);
			if (meterQueueList.isEmpty()) {
				throw new AdminException("MQ0007");
			}
			return new ResponseEntity<List<MeterQueue>>(meterQueueList, HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching active meter queue details", ex);
			resp.addError("Error occurred while fetching activemeter queue details ",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Meter queue associated campaigns.
	 *
	 * @return the response entity
	 * @throws AudienceException the audience exception
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="120000")})
	@RequestMapping(value = "/meterQueueAssociatedCampaigns/{meterQueueId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> meterQueueAssociatedCampaigns(@PathVariable Integer meterQueueId,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :meterQueueAssociatedCampaigns()");
		ResponseObject resp = new ResponseObject();
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ",
					messageSource.getMessage("E00007", new Object[] { "Throttle" }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		String associatedCampaignNames = "";
		Map<String,String> resultMap = new HashMap<String,String>();
		try {
			logger.debug("meterQueueId----------------->"+meterQueueId);
			if(meterQueueId == null) {
				throw new AdminException("MQ0005");
			}
			associatedCampaignNames = findAssociatedConversations(meterQueueId);
			logger.debug("associatedCampaignNames --->"+associatedCampaignNames);
			resultMap.put("response", associatedCampaignNames);
		} catch (AdminException e) {
			logger.error("Error occurred while fetching meter queue associated campaigns", e);
			resp.addError("Error occurred while fetching meter queue associated campaigns ",
					messageSource.getMessage(e.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Map<String,String>>(resultMap, HttpStatus.OK);
		
	}
	
	/**
	 * Find associated conversations.
	 *
	 * @param meterQueueId
	 *            the meter queue id
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String findAssociatedConversations(Integer meterQueueId) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.METERQUEUE.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("METERQUEUEID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :findAssociatedConversations()");
		String associatedConversations = "";
		try {
			logger.debug("meterQueueId  ------>"+meterQueueId);
			RestRequestHandler restHandler = new RestRequestHandler();
			String endPoint = ZetaUtil.getHelper().getEndpoint("conversation");
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity entity = new HttpEntity<>(headers);
			ResponseEntity<List> response = restHandler.exchange(
					endPoint + "/Conversation/criteriaExist/throtling/" + String.valueOf(meterQueueId), HttpMethod.GET,
					entity, List.class);
			List<String> convNamesList  = response.getBody();
			if (convNamesList != null) {
				associatedConversations = String.join(",", convNamesList);
			}
		} catch (Exception ex) {
			logger.error("Exception", ex);
			throw new AdminException("MQ0010");
		}
		logger.info("Start :" + getClass().getName() + " :findAssociatedConversations()");
		return associatedConversations;
	}
	/*private boolean authorize(HttpHeaders headers,String resourceName,String accessType)
	{
		// Authorization

		boolean isAuthorized = false;
		if(StringUtils.isBlank(headers.getFirst("userid"))||StringUtils.isBlank(headers.getFirst("customercode")))
		{
			return isAuthorized;
		}
		try
		{
			UserBO userBO = new UserBO();
			userBO.setUserID(Integer.valueOf(headers.getFirst("userid")));
			Authorizer securityClient = new Authorizer(
					ZetaUtil.getHelper().getEndpoint(com.zetainteractive.zetahub.securityclient.constants.Constants.SECURITY_ENDPOINT),
					userBO, 
					headers.getFirst("customercode"));
			isAuthorized = securityClient.hasResourePermission(accessType, resourceName);

		} catch (Exception e)
		{
			e.printStackTrace();
			logger.error("Failed to authorize user request",e);
		}
		return isAuthorized;
	}*/
}

/**
 * UnsubsController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.UnsubsService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.commons.domain.Unsubs;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;
import com.zetainteractive.zetahub.securityclient.authorize.Authorizer;
import com.zetainteractive.zetahub.securityclient.constants.Constants;

/**
 * 
 * @Author	     : Dilleswara.Doppa
 * @Created On  : Aug 16, 2016 11:31:38 AM
 * @Version	     : 1.7 
 * @Description  : "UnsubsController" is used for 
 * 
 **/
@RestController
public class UnsubsController {
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	private static final String RESOURCE_NAME = "unsubs";
	
	@Autowired
	UnsubsService unsubsService;
	@Autowired
	MessageSource messageSource;
	
	private boolean authorize(HttpHeaders headers,String resourceName,String accessType)
	{
		// Authorization

		boolean isAuthorized = false;
		short execNormal = 0;
		if(StringUtils.isBlank(headers.getFirst("userid"))||StringUtils.isBlank(headers.getFirst("customercode")))
		{
			return isAuthorized;
		}
		try
		{
			/*ZetaContext ctx = ZetaUtil.getHelper();

			UserBO user = ctx.getUser();
			String custCode = ctx.getCustomerID();*/
			/*if (user == null)
			{
				UserBO userBO = new UserBO();
				userBO.setUserID(StringUtil.isNotBlank(headers.getFirst("userid"))
						? Integer.valueOf(headers.getFirst("userid")) : 0);
				user = userBO;
			}
			if (StringUtil.isBlank(custCode))
			{
				custCode = headers.getFirst("customercode");
			}*/
			UserBO userBO = new UserBO();
			userBO.setUserID(StringUtil.isNotBlank(headers.getFirst("userid"))
					? Integer.valueOf(headers.getFirst("userid")) : 0);
			Authorizer securityClient = new Authorizer(
					ZetaUtil.getHelper().getEndpoint(Constants.SECURITY_ENDPOINT),
					userBO, 
					headers.getFirst("customercode"));
			isAuthorized = securityClient.hasResourePermission(accessType, resourceName);

		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return isAuthorized;
	}
	/**
	 * 
	 * Method Name 	: saveUnsubs
	 * Description 	: The Method "saveUnsubs" is used for 
	 * Date    		: Aug 16, 2016, 12:30:38 PM
	 * @param unsub
	 * @param unsubType
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		: 
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveUnsubs/{unsubType}", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveUnsubs(@RequestBody Unsubs unsub,@PathVariable String unsubType,BindingResult bindingResult,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", unsub.getUnsubKeywordId());}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :saveUnsubs()");
		ResponseObject resp = new ResponseObject();
		Long unsubsid = null;
		//Authorization :START
		if(!AuthorizationUtil.authorize(headers,RESOURCE_NAME,Constants.ACCESSTYPE_CREATE))
		{
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		//Authorization : END
		try {
			unsubsid = unsubsService.saveUnsubs(unsub,unsubType, bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			unsub.setUnsubKeywordId(unsubsid);
		} catch (AdminException ex) {
			logger.error("Error occurred while saving unsub details", ex);
			resp.addError("Error occurred while saving unsub details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		logger.info("End :" + getClass().getName() + " :saveUnsubs()");
		return new ResponseEntity<Unsubs>(unsub, HttpStatus.OK);
	}
	
	/**
	 * 
	 * Method Name 	: deleteUnsubs
	 * Description 	: The Method "deleteUnsubs" is used for 
	 * Date    		: Aug 16, 2016, 12:30:57 PM
	 * @param unsubId
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		: 
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteUnsubs/{unsubKeywordId}/{unsubType}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteUnsubs(@PathVariable Long unsubKeywordId,@PathVariable String unsubType,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", unsubKeywordId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :deleteUnsubs()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, Constants.ACCESSTYPE_DELETE))
		{
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		
		
		Boolean deleteStatus = false;
		try {
			if(unsubKeywordId == null || unsubKeywordId == 0) {
				throw new AdminException("US0005");
			}
			deleteStatus = unsubsService.deleteUnsubs(unsubKeywordId,unsubType);
			return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while deleteing unsubs details", ex);
			resp.addError("Error occurred while deleteing unsubs details",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {unsubKeywordId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * Method Name 	: findUnsubById
	 * Description 	: The Method "findUnsubById" is used for 
	 * Date    		: Aug 16, 2016, 12:31:10 PM
	 * @param unsubId
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		: 
	 */
	@HystrixCommand
	@RequestMapping(value = "/findUnsubById/{unsubKeywordId}/{unsubType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findUnsubById(@PathVariable Long unsubKeywordId,@PathVariable String unsubType,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", unsubKeywordId);}},"{", "}"));} catch (Exception e) {}
		logger.warn("Start :" + getClass().getName() + " :findUnsubById()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, Constants.ACCESSTYPE_READ))
		{
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			if(unsubKeywordId == null || unsubKeywordId == 0) {
				throw new AdminException("US0005");
			}
			return new ResponseEntity<Unsubs>(unsubsService.findUnsubById(unsubKeywordId,unsubType), HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching unsubs by id ", ex);
			resp.addError("Error occurred while fetching unsubs by id",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {unsubKeywordId},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * 
	 * Method Name 	: findUnsubByName
	 * Description 	: The Method "findUnsubByName" is used for 
	 * Date    		: Aug 16, 2016, 12:31:14 PM
	 * @param keywordName
	 * @param ubsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		: 
	 */
	@HystrixCommand
	@RequestMapping(value = "/findUnsubByName/{unsubKeyword}/{ubsubType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findUnsubByName(@PathVariable String unsubKeyword,@PathVariable String ubsubType,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", unsubKeyword);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :findUnsubByName()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, Constants.ACCESSTYPE_READ))
		{
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		try {
			if (unsubKeyword == null || unsubKeyword.isEmpty()) {
				throw new AdminException("US0006");
			}
			return new ResponseEntity<Unsubs>(unsubsService.findUnsubByName(unsubKeyword,ubsubType),HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching unsubs by name  ", ex);
			resp.addError("Error occurred while fetching unsubs by name", messageSource
					.getMessage(ex.getErrorCode(), new Object[] { unsubKeyword }, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Checks if is unsubs exists.
	 *
	 * @param unsubKeyword the unsub keyword
	 * @param unsubKeywordId the unsub keyword id
	 * @param unsubType the unsub type
	 * @return the response entity
	 * @throws AdminException the admin exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/isUnsubsExists/{unsubKeyword}/{unsubKeywordId}/{unsubType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> isUnsubsExists(@PathVariable String unsubKeyword,@PathVariable Long unsubKeywordId,@PathVariable String unsubType,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", unsubKeywordId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :isUnsubsExists()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, Constants.ACCESSTYPE_READ))
		{
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		Boolean isExists = false;
		Map<String,Boolean> resultMap = new HashMap<String,Boolean>();
		try {
			logger.debug("unsubKeywordId---------------------->"+unsubKeywordId);
			logger.debug("unsubType     ---------------------->"+unsubType);
			if (unsubKeyword == null || unsubKeyword.isEmpty()) {
				throw new AdminException("US0006");
			}
			isExists = unsubsService.isUnsubsExists(unsubKeyword, unsubKeywordId, unsubType);
			
			resultMap.put("isUnsubs", isExists);
			return new ResponseEntity<Map<String,Boolean>>(resultMap, HttpStatus.OK);
		} catch (AdminException ex) {
			ResponseObject resp = new ResponseObject();
			logger.error("Error occurred while fetching unsubs details", ex);
			resp.addError("Error occurred while fetching unsubs details ",messageSource.getMessage(ex.getErrorCode(), 
					new Object[] {unsubKeyword},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * Method Name 	: listUnsubs
	 * Description 	: The Method "listUnsubs" is used for 
	 * Date    		: Aug 16, 2016, 12:31:19 PM
	 * @param fetchType
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		: 
	 */
	@HystrixCommand
	@RequestMapping(value = "/listUnsubs/{fetchType}/{unsubType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> listUnsubs(@PathVariable String fetchType,@PathVariable String unsubType,@RequestHeader HttpHeaders headers) throws AdminException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.UNSUBS.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("UNSUBID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Start :" + getClass().getName() + " :listUnsubs()");
		// Authorization :START
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, Constants.ACCESSTYPE_READ))
		{
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {RESOURCE_NAME},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		// Authorization : END
		ResponseObject resp = new ResponseObject();
		List<Unsubs> unsubsList = null;
		try {
			unsubsList = unsubsService.listUnsubs(fetchType, unsubType);
			return new ResponseEntity<List<Unsubs>>(unsubsList, HttpStatus.OK);
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching unsubs details", ex);
			resp.addError("Error occurred while fetching unsubs details ",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
}

package com.zetainteractive.zetahub.admin.dao;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;

/**
 * This Interface handles CATEGORIES persistence operations.
 * @author krishna.polisetti
 */
public interface CategoryDao {
	/**
	 * 
	 * @param categoryId
	 * @return
	 */
	public CategoryBO getCategory(Long categoryId);
	/**
	 * 
	 * @param categoryId
	 * @return
	 */
	public Boolean deleteCategory(Long categoryId);
	/**
	 * 
	 * @param categoryBO
	 * @return
	 * @throws JsonProcessingException 
	 */
	public Long saveCategory(CategoryBO categoryBO) throws JsonProcessingException;
	/**
	 * 
	 * @param orderBy
	 * @param sortBy
	 * @return
	 */
	public List<CategoryBO> listCategories(CategoriesListingCriteria listingCriteria);
	
	/**
	 * Find category by type and dept.
	 *
	 * @param categoryName the category name
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return the category bo
	 * @throws AdminException the admin exception
	 */
	public CategoryBO findCategoryByTypeAndDept(Character type, String categoryCode, Long deptId) throws AdminException;
	
	/**
	 * @param categoryCode
	 * @param type
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public Boolean checkIfCategoryExistsWithTypeAndDept(String categoryCode, Character type, Long deptId, Long categoryId) throws AdminException;
}

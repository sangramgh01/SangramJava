package com.zetainteractive.zetahub.admin.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.ConfigurationBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * This Interface handles Configuration persistence operations.
 * @author krishna.polisetti
 */
public interface ConfigurationDao {
	/**
	 * 
	 * @param objectKey
	 * @return
	 */
	public ConfigurationBO getConfigurations(String objectKey);
	/**
	 * 
	 * @param ConfigurationID
	 * @return
	 */
	public Boolean deleteConfiguration(Long configurationID);
	/**
	 * 
	 * @param configurationBO
	 * @return
	 * @throws JsonProcessingException 
	 * @throws DataAccessException 
	 */
	public Long saveConfigurations(ConfigurationBO configurationBO) throws DataAccessException, JsonProcessingException;
	/**
	 * 
	 * @param orderBy
	 * @param sortBy
	 * @return
	 */
	public List<ConfigurationBO> listConfigurations(ListingCriteria listingCriteria);
	/**
	 * 
	 * @param domainCode
	 * @return
	 * @throws AdminException
	 */
	Boolean verifyIsDomainUsed(String domainCode) throws Exception;
}

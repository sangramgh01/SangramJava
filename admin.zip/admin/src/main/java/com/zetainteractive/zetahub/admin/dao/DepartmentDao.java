package com.zetainteractive.zetahub.admin.dao;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * The Interface DepartmentDao handles all operations w.r.t ADM_DEPARTMENT, ADM_DEPARTMENTSETTING
 * @author lakshmi.medarametla
 */
public interface DepartmentDao {
	
	/**
	 * Gets the department.
	 * @param departmentID the department id
	 * @return the department
	 */
	public DepartmentBO getDepartment(Long departmentID);
	
	/**
	 * Delete department.
	 * @param departmentID the department id
	 */
	public void deleteDepartment(Long departmentID);
	
	/**
	 * Save department.
	 * @param departmentBO the department bo
	 * @return the long
	 * @throws JsonProcessingException 
	 */
	public Long saveDepartment(DepartmentBO departmentBO,boolean isUpdateAuditFields) throws JsonProcessingException;
	
	/**
	 * List departments.
	 * @param listingCriteria
	 * @return
	 */
	public List<DepartmentBO> listDepartments(ListingCriteria listingCriteria);
	
	/**
	 * Used to list total number of departments
	 * @param listingCriteria
	 * @return
	 */
	public Long departmentsTotalCount(ListingCriteria listingCriteria);
	
	/**
	 * @param departmentId
	 * @return
	 */
	public Boolean isDepartmentExists(Long departmentId);

	/**
	 * @param departmentId
	 * @return
	 */
	public List<DepartmentBO> getAllDepartments(ListingCriteria listingCriteria);
	/**
	 * @param departmentName
	 * @return
	 */
	public Boolean isDepartmentExistsByNameOrId(Map<String,String> json);

	public void addDeparmentToUser(Long departmentID) throws Exception;
	/**
	 * 
	 * 
	 * Method Name 	: getSpecificPropertys
	 * Description 	: The Method "getSpecificPropertys" is used for getting list of settings based on key name. 
	 * Date    		: 23 Jan 2018, 16:41:51
	 * @param keyName
	 * @return
	 * @param  		:
	 * @return 		: List<DepartmentSettings>
	 * @throws 		:
	 */
	public List<DepartmentSettings> getSpecificPropertys(String keyName);
	/**
	 * 
	 * 
	 * Method Name 	: batchUpdateDepartmentSettings
	 * Description 	: The Method "batchUpdateDepartmentSettings" is used for update batch of department settings at a time. 
	 * Date    		: 24 Jan 2018, 10:58:47
	 * @param departmentSettings
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: boolean
	 * @throws 		:
	 */
	public boolean batchUpdateDepartmentSettings(List<DepartmentSettings> departmentSettings) throws Exception;
	/**
	 * 
	 * 
	 * Method Name 	: getDeptSpecificProperty
	 * Description 	: The Method "getDeptSpecificProperty" is used for getting department specific property 
	 * Date    		: 24 Jan 2018, 11:30:21
	 * @param keyName
	 * @param departmentId
	 * @return
	 * @param  		:
	 * @return 		: DepartmentSettings
	 * @throws 		:
	 */
	public DepartmentSettings getDeptSpecificProperty(String keyName, Long departmentId);

	List<DepartmentSettings> getAllDepartmentSettings();
	
}

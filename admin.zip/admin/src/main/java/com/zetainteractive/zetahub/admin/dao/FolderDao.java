package com.zetainteractive.zetahub.admin.dao;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * This Interface handles FOLDERS persistence operations.
 * @author krishna.polisetti
 */
public interface FolderDao {
	/**
	 * 
	 * @param folderId
	 * @return
	 */
	public FolderBO getFolder(Long folderId);
	/**
	 * 
	 * @param folderId
	 * @return
	 */
	public Boolean deleteFolder(Long folderId);
	
	/**
	 * @param folderBO
	 * @return
	 */
	public Long saveFolder(FolderBO folderBO);
	/**
	 * 
	 * @param orderBy
	 * @param sortBy
	 * @return
	 */
	public List<FolderBO> listFolders(FoldersListingCriteria listingCriteria);
	/**
	 * 
	 * Method Name 	: checkIfFolderExists
	 * Description 	: The Method "checkIfFolderExists" is used for 
	 * Date    		: Jul 29, 2016, 3:37:29 PM
	 * @param folderName
	 * @param type
	 * @param deptId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		: 
	 */
	public Boolean checkIfFolderExists(String folderName, Character type, Long deptId, Long folderId) throws AdminException;
	/**
	 * 
	 * Method Name 	: findFolder
	 * Description 	: The Method "findFolder" is used for 
	 * Date    		: Jul 29, 2016, 4:10:48 PM
	 * @param folderName
	 * @param type
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public FolderBO findFolder(String folderName, Character type, Long deptId) throws AdminException;
}

/**
 * MeterQueueDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.dao;

import java.util.List;

import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MeterQueue;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Aug 1, 2016 6:17:57 PM
 * @Version : 1.7
 * @Description : "MeterQueueDAO" is used for throttling CURD operations
 * 
 **/

public interface MeterQueueDAO {

	/**
	 * Save meter queue.
	 *
	 * @param meterQueue
	 *            the meter queue
	 * @param isDefaultOverride 
	 * @return the long
	 * @throws Exception
	 */
	public Integer saveMeterQueue(MeterQueue meterQueue, Boolean isDefaultOverride) throws Exception;

	/**
	 * Delete meter queue.
	 *
	 * @param meterQueueId
	 *            the meter queue id
	 * @return the boolean
	 * @throws AudienceException 
	 * @throws Exception 
	 */
	public Boolean deleteMeterQueue(Integer meterQueueId) throws Exception;

	/**
	 * Find meter queue by id.
	 *
	 * @param meterQueueId
	 *            the meter queue id
	 * @return the meter queue
	 * @throws Exception 
	 */
	public MeterQueue findMeterQueueById(Integer meterQueueId) throws Exception;

	/**
	 * Find meter queue by name.
	 *
	 * @param meterQueueName            the meter queue name
	 * @return the meter queue
	 * @throws Exception the admin exception
	 */
	public MeterQueue findMeterQueueByName(String meterQueueName) throws Exception;

	/**
	 * Find meter queues by criteria.
	 *
	 * @param listingCriteria
	 *            the listing criteria
	 * @return the list
	 * @throws Exception 
	 */
	public List<MeterQueue> findMeterQueuesByCriteria(ListingCriteria listingCriteria) throws Exception;

	/**
	 * 
	 * Method Name 	: isMeterQueueExists
	 * Description 	: The Method "isMeterQueueExists" is used for 
	 * Date    		: Aug 4, 2016, 7:07:40 PM
	 * @param meterQueueName
	 * @param meterQueueId
	 * @return
	 * @param  		:
	 * @return 		: MeterQueue
	 * @throws 		: 
	 */
	public MeterQueue isMeterQueueExists(String meterQueueName, Integer meterQueueId) throws Exception;

	/**
	 * 
	 * Method Name 	: listMeterQueues
	 * Description 	: The Method "listMeterQueues" is used for 
	 * Date    		: Aug 4, 2016, 8:22:13 PM
	 * @param fetchType 
	 * @return
	 * @param  		:
	 * @return 		: List<MeterQueue>
	 * @throws 		: 
	 */
	public List<MeterQueue> listMeterQueues(String fetchType) throws Exception;

	/**
	 * 
	 * Method Name 	: isDefaultMeterQueueExistsForClient
	 * Description 	: The Method "isDefaultMeterQueueExistsForClient" is used for 
	 * Date    		: Aug 8, 2016, 3:24:09 PM
	 * @param customerID
	 * @return
	 * @param  		:
	 * @return 		: MeterQueue
	 * @throws 		: 
	 */
	public MeterQueue isDefaultMeterQueueExistsForClient(Integer customerID) throws Exception;

}

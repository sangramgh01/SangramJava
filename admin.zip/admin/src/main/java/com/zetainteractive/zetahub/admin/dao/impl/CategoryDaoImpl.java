/**
 * 
 */
package com.zetainteractive.zetahub.admin.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zetainteractive.zetahub.admin.dao.CategoryDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.CategoryRowMapper;
import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;

/**
 * @author Krishna.Polisetti
 *
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class CategoryDaoImpl implements CategoryDao {

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.CategoryDao#getCategory(java.lang.Long)
	 */
	@Override
	public CategoryBO getCategory(Long categoryId) {
		try{
			String sqlQuery = "SELECT categoryid, departmentid, categorycode, description, type, createdby, updatedby, createdate,updatedate "
					+ "FROM ADM_CATEGORY WHERE categoryid = "+categoryId;
			return jdbcTemplate.queryForObject(sqlQuery, new CategoryRowMapper());
		}catch(EmptyResultDataAccessException e){
			return null;
		}catch(Exception e){
			throw e;
		}
		
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.CategoryDao#deleteCategory(java.lang.Long)
	 */
	@Override
	public Boolean deleteCategory(Long categoryId) {
		// Please do check the category is associated with any campaign or report.
		String deleteQuery = "DELETE FROM ADM_CATEGORY WHERE categoryid = ?";
		int result = jdbcTemplate.update(deleteQuery,categoryId);
		return result>0;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.CategoryDao#saveCategory(com.zetainteractive.zetahub.commons.domain.CategoryBO)
	 */
	@Override
	public Long saveCategory(CategoryBO categoryBO) throws JsonProcessingException {
		
		/*Insert if categoryid is equal to 0 else update the customer setting*/
		if(categoryBO.getCategoryid() == null || categoryBO.getCategoryid()==0){
			
			KeyHolder keyHolder = new GeneratedKeyHolder();
			String insertQuery = "INSERT INTO ADM_CATEGORY (departmentid, categorycode, description, type, createdby, updatedby, createdate,updatedate) VALUES (?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";
			
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(insertQuery,Statement.RETURN_GENERATED_KEYS);
					ps.setLong(1, categoryBO.getDepartmentid());
					ps.setString(2,categoryBO.getCategorycode());
					ps.setString(3,categoryBO.getDescription());
					ps.setString(4, categoryBO.getType().toString());
					ps.setString(5,categoryBO.getCreatedBy());
					ps.setString(6,categoryBO.getUpdatedBy());
					return ps;
				}
			}, keyHolder);
			
			categoryBO.setCategoryid(keyHolder.getKey().longValue());
			 
		}else{
			jdbcTemplate.update("UPDATE ADM_CATEGORY SET departmentid = ?, categorycode = ?, description = ?, updatedby = ?,updateDate=UTC_TIMESTAMP() WHERE categoryid = ? ", 
					categoryBO.getDepartmentid(),categoryBO.getCategorycode(),categoryBO.getDescription(),categoryBO.getUpdatedBy(),categoryBO.getCategoryid());
		}
		
		return categoryBO.getCategoryid();
		 
	}

	@Override
	public List<CategoryBO> listCategories(CategoriesListingCriteria listingCriteria) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select * from ADM_CATEGORY where departmentid=? and type= ? order by ");
		

		switch (listingCriteria.getSortUsing().toLowerCase()) {
		case "categorycode":
			queryBuilder.append("categorycode");
			break;
		case "categoryid":
			queryBuilder.append("categoryid");
			break;
		case "departmentid":
			queryBuilder.append("departmentid");
			break;

		case "type":
			queryBuilder.append("type");
			break;
		case "createdby":
			queryBuilder.append("createdby");
			break;
		case "updatedby":
			queryBuilder.append("updatedby");
			break;
		case "createdate":
			queryBuilder.append("createdate");
			break;
		case "updatedate":
			queryBuilder.append("updatedate");
			break;
		}
		queryBuilder.append(" ");

		if (listingCriteria.getSortBy().equalsIgnoreCase("ASC")) {
			queryBuilder.append("ASC");
		} else {
			queryBuilder.append("DESC");
		}
		queryBuilder.append(" LIMIT ?,?");
		return jdbcTemplate.query(queryBuilder.toString(),
				new Object[] { listingCriteria.getDepartmentId(), String.valueOf(listingCriteria.getType()),
						(listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize(),
						listingCriteria.getPageSize() },
				new CategoryRowMapper());

	}

	/**
	 * 
	 * Method Name 	: findCategoryByTypeAndDept
	 * Description 		: The Method "findCategoryByTypeAndDept" is used for 
	 * Date    			: Jul 29, 2016, 5:12:01 PM
	 * @param categoryName
	 * @param type
	 * @param categoryCode
	 * @param deptId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public CategoryBO findCategoryByTypeAndDept(Character type, String categoryCode, Long deptId)
			throws AdminException {
		String query = "select * from ADM_CATEGORY where type=? AND categorycode=? AND departmentid=?";
		CategoryBO category = null;
		try {
			Object[] param = { String.valueOf(type), categoryCode, deptId };
			category = jdbcTemplate.queryForObject(query, param, new CategoryRowMapper());
		} catch(EmptyResultDataAccessException erdae){
			return null;
	    } catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return category;

	}

	@Override
	public Boolean checkIfCategoryExistsWithTypeAndDept(String categoryCode, Character type,Long deptId, Long categoryId) throws AdminException {
		String query = "select * from ADM_CATEGORY where type=? AND categorycode=? AND departmentid=? AND categoryid!=?";
		Boolean nameExists = false;
		List<?> nameList = null;
		try {
			Object[] param = { String.valueOf(type), categoryCode, deptId, categoryId };
			nameList = jdbcTemplate.queryForList(query, param);
			if (nameList != null && nameList.size() > 0) {
				nameExists = true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new AdminException("E00002", ex);
		}
		return nameExists;
	}

}

package com.zetainteractive.zetahub.admin.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.dao.ConfigurationDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.ConfigurationRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.ConfigurationBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * @author Krishna.Polisetti
 *
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class ConfigurationDaoImpl implements ConfigurationDao {

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	
	@Autowired
    @Qualifier("whJdbc")
    private JdbcTemplate whJdbcTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zetainteractive.zetahub.admin.dao.CustomerDao#getConfigurations(
	 * java.lang.String)
	 */
	@Override
	public ConfigurationBO getConfigurations(String objectKey) {
		try {
			String sqlQuery = "SELECT configurationid,objectkey,objectvalue,createdby,updatedby,createdate,updatedate "
					+ "FROM ADM_CONFIGURATION WHERE objectkey = ? ";

			return jdbcTemplate.queryForObject(sqlQuery, new Object[]{objectKey},new ConfigurationRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zetainteractive.zetahub.admin.dao.CustomerDao#deleteConfiguration(
	 * java.lang.Long)
	 */
	@Override
	public Boolean deleteConfiguration(Long configurationID) {
		String deleteQuery = "DELETE FROM ADM_CONFIGURATION WHERE configurationid = ?";
		int result = jdbcTemplate.update(deleteQuery, configurationID);
		return result > 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zetainteractive.zetahub.admin.dao.CustomerDao#saveConfigurations(
	 * com.zetainteractive.zetahub.admin.bo.ConfigurationsBO)
	 */
	@Override
	public Long saveConfigurations(ConfigurationBO configurationBO) throws JsonProcessingException {
		logger.debug("Start: Dao Impl -------------->");
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		String objectValue = objectMapper.writeValueAsString(configurationBO.getObjectValue());
		/*
		 * Insert if configurationid is equal to 0 else update the customer
		 * setting
		 */
		if (configurationBO.getConfigurationId() == 0) {
			logger.debug("getConfigurationId = 0 -------------->"+configurationBO.getConfigurationId());
			KeyHolder keyHolder = new GeneratedKeyHolder();
			String insertQuery = "INSERT INTO ADM_CONFIGURATION(objectkey, objectvalue, createdby, updatedby, createdate,updatedate) VALUES(?,?,?,?,utc_timestamp(),utc_timestamp())";

			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, configurationBO.getObjectKey());
					ps.setString(2, objectValue);
					ps.setString(3, configurationBO.getCreatedBy());
					ps.setString(4, configurationBO.getUpdatedBy());
				
					return ps;
				}
			}, keyHolder);
			
			logger.debug("insertQuery -------------->"+insertQuery);

			configurationBO.setConfigurationId(keyHolder.getKey().longValue());
			
		} else {
			logger.debug("getConfigurationId > 0 -------------->"+configurationBO.getConfigurationId());
			jdbcTemplate.update("UPDATE ADM_CONFIGURATION SET objectvalue=?, updatedby=?,updatedate=utc_timestamp() where configurationid=?",
					objectValue, configurationBO.getUpdatedBy(), configurationBO.getConfigurationId());
		}
		logger.debug("End Dao Impl > 0 -------------->"+configurationBO.getConfigurationId());
		return configurationBO.getConfigurationId();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zetainteractive.zetahub.admin.dao.CustomerDao#listConfigurations(
	 * com.zetainteractive.zetahub.admin.bo.ListingCriteria)
	 */
	@Override
	public List<ConfigurationBO> listConfigurations(ListingCriteria listingCriteria) {
		String sqlQuery = "select * from ADM_CONFIGURATION order by " + listingCriteria.getSortUsing() + " "
				+ listingCriteria.getSortBy() + " LIMIT "
				+ (listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize() + ","
				+ listingCriteria.getPageSize();

		return jdbcTemplate.query(sqlQuery, new ConfigurationRowMapper());
	}
	@Override
    public Boolean verifyIsDomainUsed(String domainCode) throws Exception {
        logger.debug("Start: verifyIsDomainUsed()");
        boolean isfound = false;
        try {
            String query = "select count(*) from RV_BLAST_SUMMARY where domain=?";
            isfound = whJdbcTemplate.queryForObject(query, Integer.class, domainCode) > 0;
        } catch (Exception ex) {
        	logger.error(ex.getMessage(),ex);
            throw ex;
        }
        logger.debug("Ends: verifyIsDomainUsed()");
        return isfound; 
    }
	
}

package com.zetainteractive.zetahub.admin.dao.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.DepartmentDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.DepartmentRowCallbackHandler;
import com.zetainteractive.zetahub.admin.rowmapper.DepartmentRowMapper;
import com.zetainteractive.zetahub.admin.rowmapper.DepartmentSettingsRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.KeyWord;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.TestGroup;

/**
 * The Interface DepartmentDao handles all operations w.r.t ADM_DEPARTMENT, ADM_DEPARTMENTSETTING
 * @author lakshmi.medarametla
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class DepartmentDaoImpl implements DepartmentDao{

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	
	/** The logger. */
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass());
	

	@Override
	public DepartmentBO getDepartment(Long departmentID) {
		logger.info("Getting department with departmentID :: "+departmentID);
		DepartmentRowCallbackHandler rowHandler = new DepartmentRowCallbackHandler();
		String sqlQuery = "select dept.departmentid,dept.departmentname,dept.domainkey,dept.approvalmandatory,dept.restricteddomainstatus as restrictedDomainsExists,dept.createdby as departmentCreatedBy,"
						  +"dept.updatedby as departmentUpdatedBy,dept.createdate as departmentCreatedDate,dept.updatedate as departmentUpdatedDate,"
						  +"settings.departmentsettingid,settings.objectkey,settings.objectvalue,settings.createdby as settingCreatedBy,settings.updatedby as settingUpdatedBy,"
						  +"settings.createdate as settingCreatedDate,settings.updatedate as settingUpdatedDate from ADM_DEPARTMENT dept LEFT JOIN ADM_DEPARTMENTSETTING settings"
						  +" ON settings.departmentid=dept.departmentid where dept.departmentid=?";
		jdbcTemplate.query(sqlQuery,rowHandler,departmentID);
		return rowHandler.getDepartment();
	}

	@Override
	// @Transactional
	public void deleteDepartment(Long departmentID) {
		logger.debug("Begin : com.zetainteractive.zetahub.admin.dao.impl.deleteDepartment(Long departmentID)");
		String deleteDepartmentSettings = "delete from ADM_DEPARTMENTSETTING where departmentid=?";
		String deleteDepartment = "delete from ADM_DEPARTMENT where departmentid=?";
		jdbcTemplate.update(deleteDepartmentSettings, departmentID);
		jdbcTemplate.update(deleteDepartment, departmentID);
		logger.debug("End : com.zetainteractive.zetahub.admin.dao.impl.deleteDepartment(Long departmentID)");
	}

	@Override
	public Long saveDepartment(DepartmentBO departmentBO,boolean isUpdateAuditFields) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		objectMapper.setDateFormat(sd);
		
		/* Begin :: Save Department */
		String departmentname = departmentBO.getDepartmentName();
		String approvalmandatory = BooleanUtils.isTrue(departmentBO.getApprovalMandatory())?"Y":"N";
		String domainKeysUsed = BooleanUtils.isTrue(departmentBO.getDomainKeysUsed())?"Y":"N";
		String updatedby = departmentBO.getUpdatedBy();
		String createdby = departmentBO.getCreatedBy();
		String restrictedDomainsExists = BooleanUtils.isTrue(departmentBO.getRestrictedDomainsExists())?"Y":"N";
		Timestamp createdate = new Timestamp(System.currentTimeMillis());
		if (departmentBO.getDepartmentID() != null && departmentBO.getDepartmentID() > 0) {
			if (isUpdateAuditFields){
				String updateQuery = "update ADM_DEPARTMENT set departmentname=?, approvalmandatory=?, "
						+ " updatedby=?, domainkey=?,restricteddomainstatus=?,updatedate=utc_timestamp() where departmentid=?";
				jdbcTemplate.update(updateQuery, departmentname, approvalmandatory, updatedby, domainKeysUsed,restrictedDomainsExists,departmentBO.getDepartmentID());
			}else{
				String updateQuery = "update ADM_DEPARTMENT set departmentname=?, approvalmandatory=?, "
						+ "  domainkey=?,restricteddomainstatus=? where departmentid=?";
				jdbcTemplate.update(updateQuery, departmentname, approvalmandatory,  domainKeysUsed,restrictedDomainsExists,departmentBO.getDepartmentID());
			}
		} else {
			KeyHolder keyHolder = new GeneratedKeyHolder();
			String insertQuery = "insert into ADM_DEPARTMENT(departmentname,approvalmandatory,"
					+ "updatedby,createdby,domainkey,createdate,updatedate) values(?,?,?,?,?,utc_timestamp(),utc_timestamp())";
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(insertQuery,Statement.RETURN_GENERATED_KEYS);
					ps.setString(1,departmentname);
					ps.setString(2,approvalmandatory);
					ps.setString(3,updatedby);
					ps.setString(4,createdby);
					ps.setString(5,domainKeysUsed);
					return ps;
				}
			}, keyHolder);
			departmentBO.setDepartmentID(keyHolder.getKey().longValue());
		}
		/* End :: Save Department */
		/*Begin :: Save Department Settings*/
		for(DepartmentSettings departmentSettings : departmentBO.getDepartmentSettings()){
			Long departmentid=departmentBO.getDepartmentID();
			Long departmentsettingid=departmentSettings.getDepartmentSettingId();
			String objectkey=departmentSettings.getObjectKey();
			String objectvalue=objectMapper.writeValueAsString(departmentSettings.getObjectValue());
			if(objectkey.equalsIgnoreCase("MOBILE"))
			{
				try {
					MobileBO mobileBO = objectMapper.readValue(objectvalue,MobileBO.class);
					List<ShortCode> listShortCode = mobileBO.getShortCodes();
					for (ShortCode shortCode : listShortCode) {
						shortCode.setCreateDate(CommonUtil.toUTC(shortCode.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						shortCode.setUpdateDate(CommonUtil.toUTC(shortCode.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						List<KeyWord> listKeyWord = shortCode.getKeyWords();
						for (KeyWord keyWord : listKeyWord) {
							keyWord.setCreateDate(CommonUtil.toUTC(keyWord.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							keyWord.setUpdateDate(CommonUtil.toUTC(keyWord.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						}
						departmentSettings.setObjectValue(mobileBO);
					}
					List<TestGroup> listtestGroup  = mobileBO.getTestGroups();
					for (TestGroup testGroup : listtestGroup) {
						if(testGroup.getCreateDate()==null&&testGroup.getUpdateDate()==null)
						{
							testGroup.setCreateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
							testGroup.setUpdateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
						}
						else if(testGroup.getCreateDate()!=null&&testGroup.getUpdateDate()!=null)
						{
							testGroup.setUpdateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
						}
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(objectkey.equals(Constants.DEPARTMENT_AUDIENCE_KEY)){
				TypeReference<List<DeptAudienceBO>> mapType = new TypeReference<List<DeptAudienceBO>>() {};
				try {
					List<DeptAudienceBO> deptAudienceBOs=objectMapper.readValue(objectMapper.writeValueAsString(departmentSettings.getObjectValue()),mapType);
					for(DeptAudienceBO deptAudienceBO: deptAudienceBOs)
						deptAudienceBO.setAudienceName(null);
					departmentSettings.setObjectValue(deptAudienceBOs);
				} catch (IOException e) {
					logger.error(e.getMessage(),e);
				}
			}
			String objectvalue1=objectMapper.writeValueAsString(departmentSettings.getObjectValue());
			String settingsCreatedBy=departmentBO.getCreatedBy();
			String settingsUpdatedBy=departmentBO.getUpdatedBy();
			if (departmentsettingid != null && departmentsettingid > 0) {
				String updateQuery = "update ADM_DEPARTMENTSETTING set departmentid=?, objectkey=?, objectvalue=?, "
									+"updatedby=?,updatedate=utc_timestamp() where departmentsettingid=?";
				jdbcTemplate.update(updateQuery, departmentid, objectkey, objectvalue1, updatedby, departmentsettingid);
				
			} else {
				String insertQuery = "insert into ADM_DEPARTMENTSETTING(departmentid,objectkey,objectvalue,"
									+"updatedby,createdate,createdby,updatedate) values(?,?,?,?,utc_timestamp(),?,utc_timestamp())";
				jdbcTemplate.update(insertQuery,departmentid,objectkey,objectvalue1,settingsUpdatedBy,settingsCreatedBy);
			}
		}
		/*End :: Save Department Settings*/
		return departmentBO.getDepartmentID();
	}

	@Override
	public List<DepartmentBO> listDepartments(ListingCriteria listingCriteria) {
		logger.debug("Begin : com.zetainteractive.zetahub.admin.dao.impl.listDepartments(ListingCriteria listingCriteria)");
		List<Object> params = null;
		int userID=0;
		try {
			userID = ZetaUtil.getHelper().getUser().getUserID();
		} catch (Exception e) {
			e.printStackTrace();
		}
		params = new ArrayList<>();
		String sqlQuery = "select * from ADM_DEPARTMENT where departmentid IN (Select departmentid from USER_DEPARTMENT where userid="+userID+") AND departmentname like ?";
		params.add("%" + listingCriteria.getNameLike() + "%");
		
		if (listingCriteria.getNameEquals() != null && listingCriteria.getNameEquals().trim().length()>0){
			sqlQuery += " and departmentname=? ";
			params.add(listingCriteria.getNameEquals());
		}
		if(listingCriteria.getSortUsing() != null && ("departmentname".equals(listingCriteria.getSortUsing())
				||listingCriteria.getSortUsing().equals("createdate")
				||listingCriteria.getSortUsing().equals("createdby"))){
			String sortBy = CommonUtil.getOrderByColumnName(listingCriteria.getSortUsing());
			if("asc".equalsIgnoreCase(listingCriteria.getSortBy()))
				sqlQuery += " order by "+sortBy+" asc";
			else
				sqlQuery += " order by "+sortBy+" desc";
		}
		sqlQuery += " LIMIT ?,?";
		params.add((listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize());
		params.add(listingCriteria.getPageSize());
		logger.debug("com.zetainteractive.zetahub.admin.dao.impl.listDepartments at line number 216: SQL QUERY :" +sqlQuery+" Params :" + "%" + listingCriteria.getNameLike() + "%,"+ ((listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize()+","+listingCriteria.getPageSize()) );
		return jdbcTemplate.query(sqlQuery, new DepartmentRowMapper(), params.toArray());
	}

	@Override
	public Long departmentsTotalCount(ListingCriteria listingCriteria) {
		String sqlQuery = "select count(1) from ADM_DEPARTMENT where departmentname like ?";
		return jdbcTemplate.queryForObject(sqlQuery,Long.class,"%"+listingCriteria.getNameLike()+"%");
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isDepartmentExists(Long departmentId) {
		String sqlQuery = "select count(1) from ADM_DEPARTMENT where departmentid=?";
		return jdbcTemplate.queryForObject(sqlQuery,Long.class,departmentId)>0;
	}

	@Override
	public List<DepartmentBO> getAllDepartments(ListingCriteria listingCriteria) {
		List<Object> params = null;
		int userID=0;
		try {
			userID = ZetaUtil.getHelper().getUser().getUserID();
		} catch (Exception e) {
			e.printStackTrace();
		}
		params = new ArrayList<>();
		String sqlQuery = "select * from ADM_DEPARTMENT where departmentname like ?";
		params.add("%" + listingCriteria.getNameLike() + "%");
		if (listingCriteria.getNameEquals() != null && listingCriteria.getNameEquals().trim().length()>0){
			sqlQuery += " and departmentname=? ";
			params.add(listingCriteria.getNameEquals());
		}
		if(listingCriteria.getSortUsing() != null && ("departmentname".equals(listingCriteria.getSortUsing())
				||listingCriteria.getSortUsing().equals("createdate")
				||listingCriteria.getSortUsing().equals("createdby"))){
			String sortBy = CommonUtil.getOrderByColumnName(listingCriteria.getSortUsing());
			if("asc".equalsIgnoreCase(listingCriteria.getSortBy()))
				sqlQuery += " order by "+sortBy+" asc";
			else
				sqlQuery += " order by "+sortBy+" desc";
		}
		sqlQuery += " LIMIT ?,?";
		params.add((listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize());
		params.add(listingCriteria.getPageSize());
		
		return jdbcTemplate.query(sqlQuery, new DepartmentRowMapper(), params.toArray());
	}

	@Override
	public List<DepartmentSettings> getAllDepartmentSettings(){
		return jdbcTemplate.query("SELECT * FROM ADM_DEPARTMENTSETTING where objectkey='NOTIFICATIONS' ", new  DepartmentSettingsRowMapper());
	}
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isDepartmentExistsByNameOrId(Map<String,String> json) {
		String sqlQuery = "select count(1) from ADM_DEPARTMENT where ";
		if(json.get("id") != null && !json.get("id").isEmpty()){
			sqlQuery = sqlQuery + "departmentid = ?";
			return jdbcTemplate.queryForObject(sqlQuery,Long.class,json.get("id"))>0;
		}else if(json.get("name") != null && !json.get("name").isEmpty()){
			sqlQuery = sqlQuery + "departmentname = ?";
			return jdbcTemplate.queryForObject(sqlQuery,Long.class,json.get("name"))>0;
		}
		return false;
	}

	@Override
	public void addDeparmentToUser(Long departmentID) throws Exception {
		logger.debug("Begin : com.zetainteractive.zetahub.admin.dao.impl.addDeparmentToUser(Long departmentID)");
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
				String insertQuery = "INSERT INTO USER_DEPARTMENT  (USERID, DEPARTMENTID, ISDEFAULT,"
						+ "CREATEDBY,UPDATEDBY,CREATEDATE,UPDATEDATE)" + "VALUES (?,?,?,?,?,UTC_TIMESTAMP,UTC_TIMESTAMP)";
				int userId =  ZetaUtil.getHelper().getUser().getUserID();
				String userName = ZetaUtil.getHelper().getUser().getUserName();
					jdbcTemplate.update(new PreparedStatementCreator() {
						@Override
						public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
							PreparedStatement pstmt = con.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
							pstmt.setLong(1, userId);
							pstmt.setLong(2, departmentID);
							pstmt.setString(3, String.valueOf('N'));
							pstmt.setString(4,userName);
							pstmt.setString(5, userName);
							return pstmt;
						}
					}, keyHolder);
			
			} catch (Exception ex) {
				logger.error("Exception in saveUserDept():: ", ex);
				throw new AdminException("ADM117",ex);
			}
		logger.debug("End : com.zetainteractive.zetahub.admin.dao.impl.addDeparmentToUser(Long departmentID)");
		
		
	}
	
	@Override
	public List<DepartmentSettings> getSpecificPropertys(String keyName){
		return jdbcTemplate.query("SELECT * FROM ADM_DEPARTMENTSETTING where objectkey=?",new Object[]{keyName}, new  DepartmentSettingsRowMapper());
	}
	
	@Override
	public boolean batchUpdateDepartmentSettings(List<DepartmentSettings> departmentSettings) throws Exception{
		
		String userName=ZetaUtil.getHelper().getUser().getUserName();
		ObjectMapper objectMapper=new ObjectMapper();
		String query="UPDATE ADM_DEPARTMENTSETTING SET objectkey=?,objectvalue=?,updatedby=?,updatedate=utc_timestamp() where departmentsettingid=?";
		 List<Object[]> inputList = new ArrayList<>();
	        for(DepartmentSettings departmentSetting:departmentSettings){
	            Object[] tmp = {departmentSetting.getObjectKey(),objectMapper.writeValueAsString(departmentSetting.getObjectValue()),userName,departmentSetting.getDepartmentSettingId()};
	            inputList.add(tmp);
	        }
		return jdbcTemplate.batchUpdate(query,inputList).length>0;
	}
	
	@Override
	public DepartmentSettings getDeptSpecificProperty(String keyName,Long departmentId){
		try {
			return jdbcTemplate.queryForObject("SELECT * FROM ADM_DEPARTMENTSETTING where objectkey=? and departmentid=?",new Object[]{keyName,departmentId}, new  DepartmentSettingsRowMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		
	}
}

/**
 * 
 */
package com.zetainteractive.zetahub.admin.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.dao.FolderDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.FolderRowMapper;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;

/**
 * @author Krishna.Polisetti
 *
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class FolderDaoImpl implements FolderDao {
	
	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.FolderDao#getFolder(java.lang.Long)
	 */
	@Override
	public FolderBO getFolder(Long folderId) {
		try{
			String sqlQuery = "SELECT folderid, departmentid, foldername, type, parentfolderid, createdby, updatedby, createdate, updatedate FROM ADM_FOLDER WHERE folderid= "+folderId;
			return jdbcTemplate.queryForObject(sqlQuery, new FolderRowMapper());	
		}catch(EmptyResultDataAccessException e){
			return null;
		}catch(Exception e){
			throw e;
		}
		
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.FolderDao#deleteFolder(java.lang.Long)
	 */
	@Override
	public Boolean deleteFolder(Long folderId) {
		// Please do check the folder is associated with any campaign or report and check if this is a parent folder.
		String deleteQuery = "DELETE FROM ADM_FOLDER WHERE folderid = ?";
		int result = jdbcTemplate.update(deleteQuery,folderId);
		return result>0;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.FolderDao#saveFolder(com.zetainteractive.zetahub.commons.domain.FolderBO)
	 */
	@Override
	public Long saveFolder(FolderBO folderBO){
		Timestamp createdate = new Timestamp(System.currentTimeMillis());
		/*Insert if folderid is equal to 0 else update the customer setting*/
		if(folderBO.getFolderid() == null || folderBO.getFolderid()==0){
			
			KeyHolder keyHolder = new GeneratedKeyHolder();
			
			String insertQuery = "INSERT INTO ADM_FOLDER (departmentid, foldername, type, parentfolderid, createdby, updatedby, createdate,updatedate) VALUES (?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";
			
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(insertQuery,Statement.RETURN_GENERATED_KEYS);
					ps.setLong(1, folderBO.getDepartmentid());
					ps.setString(2,folderBO.getFoldername());
					ps.setString(3,folderBO.getType().toString());
					ps.setLong(4, folderBO.getParentfolderid());
					ps.setString(5,folderBO.getCreatedBy());
					ps.setString(6,folderBO.getUpdatedBy());
					
					return ps;
				}
			}, keyHolder);
			
			 folderBO.setFolderid(keyHolder.getKey().longValue());
			 
		}else{
			jdbcTemplate.update("UPDATE ADM_FOLDER SET departmentid = ?, foldername = ?, parentfolderid = ?, updatedby = ?,updatedate=utc_timestamp() WHERE folderid = ?", 
					folderBO.getDepartmentid(),folderBO.getFoldername(),folderBO.getParentfolderid(),folderBO.getUpdatedBy(),folderBO.getFolderid());
			
		}
		
		return folderBO.getFolderid();
		 
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.dao.FolderDao#listFolders(com.zetainteractive.zetahub.commons.domain.ListingCriteria)
	 */
	@Override
	public List<FolderBO> listFolders(FoldersListingCriteria listingCriteria) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select * from ADM_FOLDER where departmentid=? and type=? order by  ");

		switch (listingCriteria.getSortUsing().toLowerCase()) {
		case "foldername":
			queryBuilder.append("foldername");
			break;
		case "folderid":
			queryBuilder.append("folderid");
			break;
		case "departmentid":
			queryBuilder.append("departmentid");
			break;

		case "type":
			queryBuilder.append("type");
			break;
		case "parentfolderid":
			queryBuilder.append("parentfolderid");
			break;
		case "createdby":
			queryBuilder.append("createdby");
			break;
		case "updatedby":
			queryBuilder.append("updatedby");
			break;
		case "createdate":
			queryBuilder.append("createdate");
			break;
		case "updatedate":
			queryBuilder.append("updatedate");
			break;
		}
		queryBuilder.append(" ");

		if (listingCriteria.getSortBy().equalsIgnoreCase("ASC")) {
			queryBuilder.append("ASC");
		} else {
			queryBuilder.append("DESC");
		}
		queryBuilder.append(" LIMIT ?,?");
		return jdbcTemplate.query(queryBuilder.toString(), new FolderRowMapper(), listingCriteria.getDepartmentId(),
				String.valueOf(listingCriteria.getType()),
				(listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize(), listingCriteria.getPageSize());

	}
	
	/**
	 * Check if folder exists with type and dept.
	 *
	 * @param folderName
	 *            the folder name
	 * @param type
	 *            the type
	 * @param deptId
	 *            the dept id
	 * @return the boolean
	 * @throws AdminException
	 *             the admin exception
	 */
	@Override
	public Boolean checkIfFolderExists(String folderName, Character type, Long deptId, Long folderId)
			throws AdminException {
		String query = "select * from ADM_FOLDER where UPPER(foldername)=UPPER(?) AND type=? AND departmentid=? AND folderid!=?";
		Boolean nameExists = false;
		List<?> nameList = null;
		try {
			Object[] param = { folderName, String.valueOf(type), deptId,folderId };
			nameList = jdbcTemplate.queryForList(query, param);
			if (nameList != null && nameList.size() > 0) {
				nameExists = true;
			}
		} catch (Exception ex) {
			throw new AdminException("E00002", ex);
		}
		return nameExists;

	}
	
	/**
	 * Check if folder exists with type and dept.
	 *
	 * @param folderName
	 *            the folder name
	 * @param type
	 *            the type
	 * @param deptId
	 *            the dept id
	 * @return the boolean
	 * @throws AdminException
	 *             the admin exception
	 */
	@Override
	public FolderBO findFolder(String folderName, Character type, Long deptId)
			throws AdminException {
		String query = "select * from ADM_FOLDER where UPPER(foldername)=UPPER(?) AND type=? AND departmentid=?";
		FolderBO folder = null;
		try {
			Object[] param = { folderName, String.valueOf(type), deptId };
			folder = jdbcTemplate.queryForObject(query, param, new FolderRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			return folder;
		} 
		catch (Exception ex) {
			throw ex;
		}
		return folder;

	}

}

/**
 * MeterQueueDAO.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.MeterQueueDAO;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.MeterQueueRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MeterQueue;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Aug 1, 2016 6:23:52 PM
 * @Version : 1.7
 * @Description : "MeterQueueDAO" is used for throttling CURD operations
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class MeterQueueDAOImpl implements MeterQueueDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * Method Name : saveMeterQueue Description : The Method "saveMeterQueue" is
	 * used for Date : Aug 1, 2016, 6:26:29 PM.
	 *
	 * @param meterQueue
	 *            the meter queue
	 * @return :
	 * @throws AdminException
	 *             the admin exception
	 */
	@Override
	public Integer saveMeterQueue(MeterQueue meterQueue, Boolean isDefaultOverride) throws Exception {
		logger.info("Start :" + getClass().getName() + " :saveMeterQueue()");
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
			UserBO userBO = ZetaUtil.getHelper().getUser();
			Timestamp currentDate = new Timestamp(System.currentTimeMillis());
			if (meterQueue.getMeterQueueId() != null && meterQueue.getMeterQueueId() > 0) {
				String updateQuery = "UPDATE ADM_METERQUEUE SET meterQueueName=?,maxRate00=?,maxRate01=?,maxRate02=?,maxRate03=?,	"
						+ "maxRate04=?,	maxRate05=?,	maxRate06=?,	maxRate07=?,	maxRate08=?,	maxRate09=?,	maxRate10=?,	maxRate11=?,	"
						+ "maxRate12=?,	maxRate13=?,	maxRate14=?,	maxRate15=?,	maxRate16=?,	maxRate17=?,	maxRate18=?,	maxRate19=?,	"
						+ "maxRate20=?,	maxRate21=?,	maxRate22=?,	maxRate23=?,	status=?,	isDefault=?, "
						+ "customerId=?,updatedBy=?,   updateDate=UTC_TIMESTAMP() WHERE	meterQueueId=? ";
						Object[] args = new Object[] { 
						meterQueue.getMeterQueueName(), 
						meterQueue.getMaxRate00()  != null ? meterQueue.getMaxRate00() : null,
						meterQueue.getMaxRate01()  != null ? meterQueue.getMaxRate01() : null, 
						meterQueue.getMaxRate02()  != null ? meterQueue.getMaxRate02() : null, 
						meterQueue.getMaxRate03()  != null ? meterQueue.getMaxRate03() : null,
						meterQueue.getMaxRate04()  != null ? meterQueue.getMaxRate04() : null, 
						meterQueue.getMaxRate05()  != null ? meterQueue.getMaxRate05() : null, 
						meterQueue.getMaxRate06()  != null ? meterQueue.getMaxRate06() : null,
						meterQueue.getMaxRate07()  != null ? meterQueue.getMaxRate07() : null, 
						meterQueue.getMaxRate08()  != null ? meterQueue.getMaxRate08() : null, 
						meterQueue.getMaxRate09()  != null ? meterQueue.getMaxRate09() : null,
						meterQueue.getMaxRate10()  != null ? meterQueue.getMaxRate10() : null, 
						meterQueue.getMaxRate11()  != null ? meterQueue.getMaxRate11() : null, 
						meterQueue.getMaxRate12()  != null ? meterQueue.getMaxRate12() : null,
						meterQueue.getMaxRate13()  != null ? meterQueue.getMaxRate13() : null, 
						meterQueue.getMaxRate14()  != null ? meterQueue.getMaxRate14() : null, 
						meterQueue.getMaxRate15()  != null ? meterQueue.getMaxRate15() : null,
						meterQueue.getMaxRate16()  != null ? meterQueue.getMaxRate16() : null, 
						meterQueue.getMaxRate17()  != null ? meterQueue.getMaxRate17() : null, 
						meterQueue.getMaxRate18()  != null ? meterQueue.getMaxRate18() : null,
						meterQueue.getMaxRate19()  != null ? meterQueue.getMaxRate19() : null, 
						meterQueue.getMaxRate20()  != null ? meterQueue.getMaxRate20() : null, 
						meterQueue.getMaxRate21()  != null ? meterQueue.getMaxRate21() : null,
						meterQueue.getMaxRate22()  != null ? meterQueue.getMaxRate22() : null, 
						meterQueue.getMaxRate23()  != null ? meterQueue.getMaxRate23() : null, 
						String.valueOf(meterQueue.getStatus()),
						String.valueOf(meterQueue.getIsDefault()), 
						meterQueue.getCustomerId(), 
						userBO != null ? userBO.getUserName() : "", 
					
						meterQueue.getMeterQueueId() };
				jdbcTemplate.update(updateQuery, args);
			} else {
				
				String insertQuery = "INSERT INTO ADM_METERQUEUE (meterQueueName,maxRate00,maxRate01,maxRate02,maxRate03,	"
						+ "maxRate04,	maxRate05,	maxRate06,	maxRate07,	maxRate08,	maxRate09,	maxRate10,	maxRate11,	"
						+ "maxRate12,	maxRate13,	maxRate14,	maxRate15,	maxRate16,	maxRate17,	maxRate18,	maxRate19,	"
						+ "maxRate20,	maxRate21,	maxRate22,	maxRate23,	status,	isDefault,	"
						+ "customerId,	createdBy,	updatedBy, createDate,	updateDate) "
						+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp())";

				final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator() {

					@Override
					public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
						PreparedStatement pstmt = con.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);

						pstmt.setString(1, meterQueue.getMeterQueueName());
						pstmt.setString(2, meterQueue.getMaxRate00() != null ? meterQueue.getMaxRate00() : null);
						pstmt.setString(3, meterQueue.getMaxRate01() != null ? meterQueue.getMaxRate01() : null );
						pstmt.setString(4, meterQueue.getMaxRate02() != null ? meterQueue.getMaxRate02() : null);
						pstmt.setString(5, meterQueue.getMaxRate03() != null ? meterQueue.getMaxRate03() : null);
						pstmt.setString(6, meterQueue.getMaxRate04() != null ? meterQueue.getMaxRate04() : null);
						pstmt.setString(7, meterQueue.getMaxRate05() != null ? meterQueue.getMaxRate05() : null);
						pstmt.setString(8, meterQueue.getMaxRate06() != null ? meterQueue.getMaxRate06() : null);
						pstmt.setString(9, meterQueue.getMaxRate07() != null ? meterQueue.getMaxRate07() : null);
						pstmt.setString(10, meterQueue.getMaxRate08() != null ? meterQueue.getMaxRate08() : null);
						pstmt.setString(11, meterQueue.getMaxRate09() != null ? meterQueue.getMaxRate09() : null);
						pstmt.setString(12, meterQueue.getMaxRate10() != null ? meterQueue.getMaxRate10() : null);
						pstmt.setString(13, meterQueue.getMaxRate11() != null ? meterQueue.getMaxRate11() : null);
						pstmt.setString(14, meterQueue.getMaxRate12() != null ? meterQueue.getMaxRate12() : null);
						pstmt.setString(15, meterQueue.getMaxRate13() != null ? meterQueue.getMaxRate13() : null);
						pstmt.setString(16, meterQueue.getMaxRate14() != null ? meterQueue.getMaxRate14() : null);
						pstmt.setString(17, meterQueue.getMaxRate15() != null ? meterQueue.getMaxRate15() : null);
						pstmt.setString(18, meterQueue.getMaxRate16() != null ? meterQueue.getMaxRate16() : null);
						pstmt.setString(19, meterQueue.getMaxRate17() != null ? meterQueue.getMaxRate17() : null);
						pstmt.setString(20, meterQueue.getMaxRate18() != null ? meterQueue.getMaxRate18() : null);
						pstmt.setString(21, meterQueue.getMaxRate19() != null ? meterQueue.getMaxRate19() : null);
						pstmt.setString(22, meterQueue.getMaxRate20() != null ? meterQueue.getMaxRate20() : null);
						pstmt.setString(23, meterQueue.getMaxRate21() != null ? meterQueue.getMaxRate21() : null);
						pstmt.setString(24, meterQueue.getMaxRate22() != null ? meterQueue.getMaxRate22() : null);
						pstmt.setString(25, meterQueue.getMaxRate23() != null ? meterQueue.getMaxRate23() : null);
						pstmt.setString(26, String.valueOf(meterQueue.getStatus()));
						pstmt.setString(27, String.valueOf(meterQueue.getIsDefault()));
						pstmt.setInt(28, meterQueue.getCustomerId());
						pstmt.setString(29, userBO != null ? userBO.getUserName() : "");
						pstmt.setString(30, userBO != null ? userBO.getUserName() : "");
					
						return pstmt;
					}
				};
				jdbcTemplate.update(pstmtCreator, keyHolder);
				if( meterQueue.getMeterQueueName() != null ){
					meterQueue.setMeterQueueId(jdbcTemplate.queryForObject("Select meterQueueid from ADM_METERQUEUE WHERE meterQueueName = ? limit 1", Integer.class,meterQueue.getMeterQueueName()));
				}

			}
			// if user select isDefault as 'Y' we need to make isDefault to 'N' to all other meter quete records for the client
			if (isDefaultOverride) {
				Object[] args = null;
				String isDefaultOverrideQuery = "UPDATE ADM_METERQUEUE SET isDefault='N', "
						+ " updatedBy=?  , updateDate=UTC_TIMESTAMP() WHERE customerId = ? AND meterQueueId !=? ";
				if (meterQueue.getMeterQueueId() != null && meterQueue.getMeterQueueId() > 0) {

					args = new Object[] { userBO != null ? userBO.getUserName() : "", meterQueue.getCustomerId(),
							meterQueue.getMeterQueueId() };
				} else {
					args = new Object[] { userBO != null ? userBO.getUserName() : "", meterQueue.getCustomerId(),
							keyHolder.getKey().intValue() };
				}
				jdbcTemplate.update(isDefaultOverrideQuery, args);
			}
		} catch (Exception ex) {
			logger.error("Exception ", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :saveMeterQueue()");
		return meterQueue.getMeterQueueId();
	}

	

	/**
	 * 
	 * Method Name : deleteMeterQueue Description : The Method
	 * "deleteMeterQueue" is used for Date : Aug 1, 2016, 6:26:29 PM
	 * 
	 * @param meterQueueId
	 * @return
	 * @param :
	 * @return :
	 * @throws AudienceException 
	 * @throws :
	 */

	@Override
	public Boolean deleteMeterQueue(Integer meterQueueId) throws Exception {
		logger.info("Start :" + getClass().getName() + " :deleteMeterQueue()");
		String query = "DELETE FROM ADM_METERQUEUE WHERE METERQUEUEID = ?";
		try {
			int status = jdbcTemplate.update(query, meterQueueId);
			if(status !=0){
				logger.debug("Meter queue record deleted with id="+meterQueueId);
				return true;
			}else {
				logger.debug("No Meter queue record found with id="+meterQueueId);
				return false;
			}
			
		} catch (Exception ex) {
			logger.error("Exception ", ex);
			throw ex;
		}
	}

	/**
	 * 
	 * Method Name : findMeterQueueById Description : The Method
	 * "findMeterQueueById" is used for Date : Aug 1, 2016, 6:26:29 PM
	 * 
	 * @param meterQueueId
	 * @return
	 * @param :
	 * @return :
	 * @throws AdminException 
	 * @throws :
	 */

	@Override
	public MeterQueue findMeterQueueById(Integer meterQueueId) throws Exception {
		logger.info("Start :" + getClass().getName() + " :findMeterQueueById()");
		MeterQueue meterQueue = null;
		String query = "SELECT * FROM ADM_METERQUEUE WHERE METERQUEUEID = ?";
		try {
			logger.debug("meterQueueId==============>"+meterQueueId);
			Object[] args = new Object[] { meterQueueId };
			meterQueue = jdbcTemplate.queryForObject(query, args, new MeterQueueRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return meterQueue;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching meter queue record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :findMeterQueueById()");
		return meterQueue;
	}

	/**
	 * 
	 * Method Name : findMeterQueueByName Description : The Method
	 * "findMeterQueueByName" is used for Date : Aug 1, 2016, 6:26:29 PM
	 * 
	 * @param meterQueueName
	 * @return
	 * @param :
	 * @return :
	 * @throws AdminException 
	 * @throws :
	 */

	@Override
	public MeterQueue findMeterQueueByName(String meterQueueName) throws Exception {
		logger.info("Start :" + getClass().getName() + " :findMeterQueueByName()");
		MeterQueue meterQueue = null;
		String query = "SELECT * FROM ADM_METERQUEUE WHERE METERQUEUENAME = ?";
		try {
			logger.debug("meterQueueName==============>"+meterQueueName);
			Object[] args = new Object[] { meterQueueName };
			meterQueue = jdbcTemplate.queryForObject(query, args, new MeterQueueRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return meterQueue;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching meter queue record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :findMeterQueueByName()");
		return meterQueue;
	}

	/**
	 * 
	 * Method Name : findMeterQueuesByCriteria Description : The Method
	 * "findMeterQueuesByCriteria" is used for Date : Aug 1, 2016, 6:26:29 PM
	 * 
	 * @param listingCriteria
	 * @return
	 * @param :
	 * @return :
	 * @throws AdminException
	 * @throws :
	 */

	@Override
	public List<MeterQueue> findMeterQueuesByCriteria(ListingCriteria listingCriteria) throws Exception{
		logger.info("Start :" + getClass().getName() + " :findMeterQueuesByCriteria()");
		List<MeterQueue> meterQueueList = null;
		try {
			if (listingCriteria != null) {
				logger.debug(listingCriteria.toString());
			}
			String sqlQuery = "select * from ADM_METERQUEUE WHERE METERQUEUENAME like ?";
			if (listingCriteria.getNameEquals() != null)
				sqlQuery += " and METERQUEUENAME=?";
			sqlQuery += " order by " + listingCriteria.getSortUsing() + " " + listingCriteria.getSortBy()
					+ " LIMIT ?,?";
			if (listingCriteria.getNameEquals() != null)
				meterQueueList = jdbcTemplate.query(sqlQuery, new MeterQueueRowMapper(),
						"%" + listingCriteria.getNameLike() + "%", listingCriteria.getNameEquals(),
						(listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize(),
						listingCriteria.getPageSize());
			else
				meterQueueList = jdbcTemplate.query(sqlQuery, new MeterQueueRowMapper(),
						"%" + listingCriteria.getNameLike() + "%",
						(listingCriteria.getPageNumber() - 1) * listingCriteria.getPageSize(),
						listingCriteria.getPageSize());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			return meterQueueList;
		} catch (Exception ex) {
			logger.error("Error occurred while while meter queue records", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :findMeterQueuesByCriteria()");
		return meterQueueList;
	}



	/**
	 * 
	 * Method Name 	: isMeterQueueExists
	 * Description 		: The Method "isMeterQueueExists" is used for 
	 * Date    			: Aug 4, 2016, 7:09:14 PM
	 * @param meterQueueName
	 * @param meterQueueId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public MeterQueue isMeterQueueExists(String meterQueueName, Integer meterQueueId) throws Exception {
		logger.info("Start :" + getClass().getName() + " :isMeterQueueExists()");
		MeterQueue meterQueue = null;
		String query = null;
		Object[] args = null;
		try {
			logger.debug("meterQueueName==============>" + meterQueueName);
			if (meterQueueId == null || meterQueueId == 0) {
				query = "SELECT * FROM ADM_METERQUEUE WHERE METERQUEUENAME = ?";
				args = new Object[] { meterQueueName };
			} else {
				query = "SELECT * FROM ADM_METERQUEUE WHERE METERQUEUENAME = ? AND METERQUEUEID != ?";
				args = new Object[] { meterQueueName, meterQueueId };
			}
			meterQueue = jdbcTemplate.queryForObject(query, args, new MeterQueueRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return meterQueue;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching meter queue record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :isMeterQueueExists()");
		return meterQueue;
	}



	/**
	 * Method Name 	: listMeterQueues
	 * Description 		: The Method "listMeterQueues" is used for 
	 * Date    			: Aug 4, 2016, 8:22:32 PM.
	 *
	 * @param fetchType the fetch type
	 * @return 		:
	 * @throws AdminException the admin exception
	 */
	
	@Override
	public List<MeterQueue> listMeterQueues(String fetchType) throws Exception {
		logger.info("Start :" + getClass().getName() + " :listMeterQueues()");
		List<MeterQueue> meterQueueList = null;
		String sqlQuery = "select * from ADM_METERQUEUE";
		try {
			if (fetchType.equalsIgnoreCase(Constants.STATUS_ACTIVE)) {
				sqlQuery += " WHERE STATUS='A' ORDER BY createdate DESC";
				logger.debug(sqlQuery);
				meterQueueList = jdbcTemplate.query(sqlQuery, new MeterQueueRowMapper());
			} else {
				meterQueueList = jdbcTemplate.query(sqlQuery, new MeterQueueRowMapper());
			}

		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			ex.printStackTrace();
			return meterQueueList;
		} catch (Exception ex) {
			logger.error("Error occurred while while meter queue records", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :listMeterQueues()");
		return meterQueueList;
	}


	/**
	 * 
	 * Method Name 	: isDefaultMeterQueueExistsForClient
	 * Description 		: The Method "isDefaultMeterQueueExistsForClient" is used for 
	 * Date    			: Aug 8, 2016, 3:24:35 PM
	 * @param customerID
	 * @return
	 * @throws AdminException
	 */
	
	@Override
	public MeterQueue isDefaultMeterQueueExistsForClient(Integer customerID) throws Exception {
		logger.info("Start :" + getClass().getName() + " :isDefaultMeterQueueExistsForClient()");
		MeterQueue meterQueue = null;
		String query = null;
		Object[] args = null;
		try {
			logger.debug("customerID==============>" + customerID);
			query = "SELECT * FROM ADM_METERQUEUE WHERE CUSTOMERID = ? AND ISDEFAULT = 'Y'";
			args = new Object[] { customerID };
            logger.debug(query);
			meterQueue = jdbcTemplate.queryForObject(query, args, new MeterQueueRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return meterQueue;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching meter queue record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :isDefaultMeterQueueExistsForClient()");
		return meterQueue;
	}

}

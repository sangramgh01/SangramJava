/**
 * UnsubDAOImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.dao.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.UnsubDAO;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.rowmapper.UnsubsRowMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.Unsubs;

/**
 * 
 * @Author : srinivasa.katta
 * @Created On : Aug 12, 2016 3:56:32 PM
 * @Version : 1.7
 * @Description : "UnsubDAOImpl" is used for unsun keywords CRUD operations
 * 
 **/
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class UnsubDAOImpl implements UnsubDAO {

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	
	@Autowired
	@Qualifier("whJdbc")
	private JdbcTemplate whJdbcTemplate;

	/**
	 * 
	 * Method Name : saveUnsubs Description : The Method "saveUnsubs" is used
	 * for Date : Aug 12, 2016, 3:56:47 PM
	 * 
	 * @param unsub
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public Long saveUnsubs(Unsubs unsub, String unsubType) throws Exception {
		logger.info("Start :" + getClass().getName() + " :saveUnsubs()");
		KeyHolder keyHolder = new GeneratedKeyHolder();
		Long unsubId = null;
		try {
			logger.debug("unsubType --------->"+unsubType);
			UserBO userBO = ZetaUtil.getHelper().getUser();
			String keyWordType;
			if (unsubType.equalsIgnoreCase(Constants.CUSTOM))
				keyWordType="CUS";
			else
				keyWordType="SYS";
			
			
			
			if (unsub.getUnsubKeywordId() != null && unsub.getUnsubKeywordId() > 0) {
				String updateQuery = "UPDATE UNSUB_KEYWORDS SET unsubkeyword=?,status=?, updatedBy=?, updateDate=getutcdate(),keyword_type=?,type=?,category=? WHERE unsubkeywordid=? ";
				Object[] args = new Object[] {
								unsub.getUnsubKeyword(),
								String.valueOf(unsub.getStatus()),
								userBO != null ? userBO.getUserName() : "",
								keyWordType,
								unsub.getType(),
								unsub.getCategory(),
								unsub.getUnsubKeywordId()
							};
				whJdbcTemplate.update(updateQuery, args);
				unsubId = unsub.getUnsubKeywordId();
			}else{
				//unsubId=whJdbcTemplate.queryForObject("SELECT nextval('UNSUB_KEYWORDS_SEQ')", Long.class);
				String insertQuery = "INSERT INTO UNSUB_KEYWORDS  (unsubkeyword,status,createdby,updatedby,createdate,updatedate,type,category,keyword_type) VALUES (?,?,?,?,getutcdate(),getutcdate(),?,?,?)";
				Object[] args = new Object[] {
								unsub.getUnsubKeyword(),
								String.valueOf(unsub.getStatus()),
								userBO != null ? userBO.getUserName() : "",
								userBO != null ? userBO.getUserName() : "",
								unsub.getType(),
								unsub.getCategory(),
								keyWordType
							};
				
				whJdbcTemplate.update(insertQuery, args);
				
				unsubId=isUnsubsExists(unsub.getUnsubKeyword(), null, unsubType,unsub.getCategory(),unsub.getType()).getUnsubKeywordId();
				
				
			}
		} catch (Exception ex) {
			logger.error("Exception ", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :saveUnsubs()");
		return unsubId;

	}

	/**
	 * 
	 * Method Name : deleteUnsubs Description : The Method "deleteUnsubs" is
	 * used for Date : Aug 12, 2016, 3:56:47 PM
	 * 
	 * @param unsubId
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public Boolean deleteUnsubs(Long unsubKeywordId, String unsubType) throws Exception {
		logger.info("Start :" + getClass().getName() + " :deleteUnsubs()");
		String query = null;
		int status = 0;
		logger.debug("unsubType ==============>"+unsubType);
		try {
			query = "DELETE FROM UNSUB_KEYWORDS WHERE unsubKeywordId = ?";
			status=whJdbcTemplate.update(query, unsubKeywordId);
			if (status != 0) {
				logger.debug("unsub record deleted with id=" + unsubKeywordId);
				return true;
			} else {
				logger.debug("No unsub record found with id=" + unsubKeywordId);
				return false;
			}

		} catch (Exception ex) {
			logger.error("Exception ", ex);
			throw ex;
		}

	}

	/**
	 * 
	 * Method Name : findUnsubById Description : The Method "findUnsubById" is
	 * used for Date : Aug 12, 2016, 3:56:47 PM
	 * 
	 * @param unsubId
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public Unsubs findUnsubById(Long unsubKeywordId, String unsubType) throws Exception {
		logger.info("Start :" + getClass().getName() + " :findUnsubById()");
		Unsubs unsub = null;
		String query=null;
		try {
			query = "SELECT * FROM UNSUB_KEYWORDS WHERE unsubKeywordId = ?";
			logger.debug("unsubId   ==============>"+unsubKeywordId);
			logger.debug("unsubType ==============>"+unsubType);
			Object[] args = new Object[] { unsubKeywordId };
			unsub = whJdbcTemplate.queryForObject(query, args, new UnsubsRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return unsub;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching unsub record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :findUnsubById()");
		return unsub;
	}

	/**
	 * 
	 * Method Name : findUnsubByName Description : The Method "findUnsubByName"
	 * is used for Date : Aug 12, 2016, 3:56:47 PM
	 * 
	 * @param keywordName
	 * @param ubsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public Unsubs findUnsubByName(String unsubKeyword, String unsubType) throws Exception {
		logger.info("Start :" + getClass().getName() + " :findUnsubByName()");
		Unsubs unsubs = null;
		String query=null;
		try {
			logger.debug("unsubKeyword==============>"+unsubKeyword);
			logger.debug("unsubType  ==============>"+unsubType);
			query = "SELECT * FROM UNSUB_KEYWORDS WHERE unsubKeyword = ?";
			Object[] args = new Object[] { unsubKeyword };
			unsubs = whJdbcTemplate.queryForObject(query, args, new UnsubsRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return unsubs;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching unsub record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :findUnsubByName()");
		return unsubs;

	}

	/**
	 * 
	 * Method Name 	: isUnsubsExists
	 * Description 	: The Method "isUnsubsExists" is used for 
	 * Date    		: Aug 12, 2016, 7:02:24 PM
	 * @param keywordName
	 * @param unsubId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		: 
	 */
	@Override
	public Unsubs isUnsubsExists(String unsubKeyword,Long unsubKeywordId, String unsubType,String category,String type) throws Exception{
		logger.info("Start :" + getClass().getName() + " :isUnsubsExists()");
		Unsubs unsubs = null;
		StringBuilder query = null;
		List<Object> params=new LinkedList<>();
		String finalQuery=null;
		try {
			logger.debug("keywordName==============>" + unsubKeyword);
			logger.debug("unsubType  ==============>"+unsubType);
			
			query =new StringBuilder().append( "SELECT * FROM UNSUB_KEYWORDS WHERE ");
			
			if (unsubKeywordId != null && unsubKeywordId > 0 ) {
				query.append(" unsubKeywordId != ?  AND ");
				params.add(unsubKeywordId);
			}
			if (type !=null ){
				query.append(" type = ?  AND ");
				params.add(type);
			}
			if (category !=null ){
				query.append(" category = ?  AND ");
				params.add(category);
			}
			
			if (unsubType !=null ){
				query.append(" keyword_type = ?  AND ");
				params.add("custom".equalsIgnoreCase(unsubType) ? "CUS" : "SYS");
			}
			
			if (unsubKeyword !=null ){
				query.append(" unsubkeyword = ?  ");
				params.add(unsubKeyword);
			}
			
			if (query.toString().trim().endsWith("AND"))
				finalQuery=query.toString().trim().substring(0, "AND".length());
			else
				finalQuery=query.toString().trim();
			
			unsubs = whJdbcTemplate.queryForObject(finalQuery+" LIMIT 1", params.toArray(), new UnsubsRowMapper());
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ");
			return unsubs;
		} catch (Exception ex) {
			logger.error("Error occurred while while fetching unsub record", ex);
			throw ex;
		}
		logger.info("Ends :" + getClass().getName() + " :isUnsubsExists()");
		return unsubs;
	}
	/**
	 * 
	 * Method Name : listUnsubs Description : The Method "listUnsubs" is used
	 * for Date : Aug 12, 2016, 3:56:47 PM
	 * 
	 * @param fetchType
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public List<Unsubs> listUnsubs(String fetchType, String unsubType) throws Exception {
		logger.debug("Start :" + getClass().getName() + " :listUnsubs()");
		List<Unsubs> unsubsList = null;
		String sqlQuery = null;
		try {
			logger.info("fetchType==============>" + fetchType);
			logger.info("unsubType==============>"+unsubType);
			sqlQuery = "select * from UNSUB_KEYWORDS";
			if (fetchType.equalsIgnoreCase(Constants.STATUS_ACTIVE)) {
				sqlQuery += " WHERE STATUS='A' ";
				if (unsubType.equalsIgnoreCase(Constants.CUSTOM)) {
					sqlQuery += " AND KEYWORD_TYPE='CUS'  ";
				}else{
					sqlQuery += " AND KEYWORD_TYPE='SYS'  ";
				}
			}else{
				if (unsubType.equalsIgnoreCase(Constants.CUSTOM)) {
					sqlQuery += " WHERE KEYWORD_TYPE='CUS'  ";
				}else{
					sqlQuery += " WHERE KEYWORD_TYPE='SYS'  ";
				}
			}
			sqlQuery += " ORDER BY createdate DESC";
			logger.info(sqlQuery);
			unsubsList = whJdbcTemplate.query(sqlQuery, new UnsubsRowMapper());
			
			if (unsubsList != null && unsubsList.size() > 0) {
				logger.info("UNSUB " + unsubType + " Count -------------------->" + unsubsList.size());
			} else {
				logger.info("UNSUB " + unsubType + " Count --------------------> No Records found");
			}
		} catch (EmptyResultDataAccessException ex) {
			logger.error("Incorrect result size ", ex);
			return unsubsList;
		} catch (Exception ex) {
			logger.error("Error occurred while while unsub records", ex);
			throw ex;
		}
		logger.debug("Ends :" + getClass().getName() + " :listUnsubs()");
		return unsubsList;

	}

}

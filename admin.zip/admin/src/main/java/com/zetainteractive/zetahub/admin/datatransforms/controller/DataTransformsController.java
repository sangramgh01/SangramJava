/**
 * DataTransformsController.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/
package com.zetainteractive.zetahub.admin.datatransforms.controller;

import java.sql.Timestamp;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.foundation.domain.CustomerBO;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.datatransforms.dao.DataTransformsDao;
import com.zetainteractive.zetahub.admin.datatransforms.exception.DataTransformsException;
import com.zetainteractive.zetahub.admin.datatransforms.exception.ErrorInformation;
import com.zetainteractive.zetahub.admin.notifications.service.WorkflowNotificationHandler;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.commons.domain.ResponseStatus;
import com.zetainteractive.zetahub.commons.domain.TimeZoneData;
import com.zetainteractive.zetahub.commons.domain.TransformActivity;
import com.zetainteractive.zetahub.commons.domain.TransformEditor;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor;
import com.zetainteractive.zetahub.commons.domain.WorkflowTransforms;
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger;
import com.zetainteractive.zetahub.commons.enums.NotificationStatusTypes;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * Rest API controller for data transforms component in admin module
 * @author Nagendra.Guttha
 * @since 1.7
 */
@RestController
@RequestMapping(value = "/datatransforms")
public class DataTransformsController
{
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();
	@Autowired
	private DataTransformsDao dataTransformsDao;
	
	@Autowired
	MessageSource messageSource;
	public static final String RESOURCE_NAME ="admin";
	
	@Autowired
	WorkflowNotificationHandler workflowNotificationHandler;
	
	
	//Get API calls
	/**
	 * Get all time zones for different regions
	 * @return time zone data -
	 * @throws DataTransformsException -
	 */
	@HystrixCommand
	@RequestMapping(path="/getTimeZones",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTimeZones() throws DataTransformsException
	{	
		
		try
		{
			logger.debug("Fetch time zones..");
			return new ResponseEntity<>(loadTimeZones(),HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in retrieving time zones ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="FMJ0012";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while fetching time zones ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/** Gives current date  */
	private Timestamp getCurrentDate(){
		return CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone());
	}
	
	/**
	 * Get All available data transforms
	 * @return list of transforms
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getAllTransforms",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllTransforms(@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getAllTransforms"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch all transforms ");
			final List<TransformEditor> response = dataTransformsDao.getAllTransforms();
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in retrieving all transforms ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching all transforms",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get transforms based on provided search criteria
	 * @param searchCriteria - search criteria
	 * @return list of transforms -
	 * @throws DataTransformsException -
	 */
	@HystrixCommand
	@RequestMapping(path="/getTransformsForSearchCriteria",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTransformsForSearchCriteria(@RequestBody final DTWSearchCriteria searchCriteria,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getTransformsForSearchCriteria"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch all transforms for search criteria");
			final List<TransformEditor> response = dataTransformsDao.getTransformsForSearchCriteria(searchCriteria);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NO_TRANSFORMS_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching transforms for search criteria ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching transforms for search criteria ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get All available workflows
	 * @return list of workflows
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getAllWorkflows",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllWorkflows(@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getAllWorkflows"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch all workflows");
			final List<DTWWorkflow> response = dataTransformsDao.getAllWorkflows();
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflows ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflows ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get all master workflows which are of triggered type
	 * @return list of triggered workflows
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getMasterWorkflows/{departmentId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getMasterWorkflows(@PathVariable("departmentId")long departmentId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {"getMasterWorkflows"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch all master workflows which are of type trigger");
			final List<DTWWorkflow> response = dataTransformsDao.getMasterWorkflows(departmentId);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching trigger type workflows ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching master workflows ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get All transforms associated with the workflow 
	 * @param workflowId - <br/>
	 * 					 workflow id 
	 * @return list of transforms
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getAssociatedTransforms/{workflowId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAssociatedTransforms(@PathVariable("workflowId")final Long workflowId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getAssociatedTransforms"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch all transforms for workflow id {}",workflowId);
			final List<TransformEditor> response = dataTransformsDao.getAssociatedTransforms(workflowId);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow transforms ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow transforms ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	/**
	 * Block or unblock workflow activity status  
	 * @param status - <br/>
	 * 					 status 
	 * @param message - <br/>
	 * 					 message
	 * @return state of status update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/blockOrUnBlockWorkFlowActivities/{status}/{message}",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> blockOrUnBlockWorkFlowActivities(@PathVariable("status")final String status,@PathVariable("message")final String message,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"blockOrUnBlockWorkFlowActivities"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Block or unblock activities for status {}",status);
			if(StringUtils.isBlank(status))
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"status"));
			}
			if(status.trim().length()>1||(!"W".equalsIgnoreCase(status.trim())&&!"B".equalsIgnoreCase(status.trim())))
			{
				throw new DataTransformsException("Invalid status value provided");
			}
			
			dataTransformsDao.blockOrUnBlockWorkFlowActivities(status,message);
			
			logger.debug("Successfully updated activities for status {}",status);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in updating workflow activity status ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while updating workflow activity status ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get all workflows based on the provided search criteria
	 * @param searchCriteria - search criteria
	 * @return list of workflows -
	 * @throws DataTransformsException -
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowsForSearchCriteria",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowsForSearchCriteria(@RequestBody final DTWSearchCriteria searchCriteria,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowsForSearchCriteria"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflows for search criteria");
			final List<DTWWorkflow> response = dataTransformsDao.getWorkflowsForSearchCriteria(searchCriteria);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflows for search criteria ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflows for search criteria ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Get All available workflow trigger schedules
	 * @param workflowId -workflow identifier
	 * @param fileDefId - file definition id
	 * @return list of workflow triggers
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowTriggers/{workflowId}/{fileDefId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowTriggers(@PathVariable("workflowId")final Long workflowId,@PathVariable("fileDefId")final Long fileDefId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowTriggers"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflow triggers for workflow id {} and  file definition id {}",workflowId,fileDefId);
			final List<WorkflowTrigger> response = dataTransformsDao.getWorkflowTriggers(workflowId, fileDefId);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow triggers ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow triggers ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get All created workflow activities for the scheduled workflow
	 * @param workflowId - <br/>
	 * 					 workflow id 
	 * @return list of workflow activities
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowActivity/{workflowId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowActivity(@PathVariable("workflowId")final Long workflowId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflow activity for workflow id {}",workflowId);
			final List<WorkflowActivity> response = dataTransformsDao.getWorkflowActivity(workflowId);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow activities ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow activities ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get all workflow activities based on the provided search criteria
	 * @param searchCriteria -
	 * @return list of workflow activities
	 * @throws DataTransformsException -
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowActivityForSearchCriteria",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowActivityForSearchCriteria(@RequestBody final DTWSearchCriteria searchCriteria,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowActivityForSearchCriteria"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			final List<WorkflowActivity> response = dataTransformsDao.getWorkflowActivityForSearchCriteria(searchCriteria);
			/*if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}*/
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow activities for search criteria ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow activities for search criteria ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get all transform activities created for workflow
	 * @param workflowActivityId - workflow activity id
	 * @param transformId - transform is associated with workflow
	 * @return list of transform activities created for workflow
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getTransformActivity/{workflowActivityId}/{transformId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTransformActivity(@PathVariable("workflowActivityId")final Long workflowActivityId,@PathVariable("transformId")final Long transformId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getTransformActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch transform activity for workflow activity id {} and transform id {}",workflowActivityId,transformId);
			final List<TransformActivity> response = dataTransformsDao.getTransformActivity(workflowActivityId,transformId);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception occured in fetching transform activity ",e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow activities for search criteria ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Get workflow which has activities
	 * @param workflowId - identifier
	 * @param workflowActivityId - activity identifier
	 * @return workflow
	 * @throws DataTransformsException -
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowWithActivities/{workflowId}/{workflowActivityId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowWithActivities(@PathVariable("workflowId")final Long workflowId,@PathVariable("workflowActivityId")final Long workflowActivityId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowWithActivities"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflow which has activities for workflow id {}",workflowId,workflowActivityId);
			final DTWWorkflow response = dataTransformsDao.getWorkflowWithActivities(workflowId,workflowActivityId);
			if(response==null)
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow which has workflow activities ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while fetching workflow which has workflow activities ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//Create API operations
	
	/**
	 * Persist transform into the database
	 * @param transform - transform which is going to save into database
	 * @return transform id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/createTransform",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveTransform(@RequestBody final TransformEditor transform,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		boolean isExist = false;
		
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"createTransform"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("saveTransform");
		try
		{
			event.addField("Create Transforms content received :: ",transform.getName());
			auditManager.audit(event);
			validateTransform(transform);
			if(transform.getName() != null && transform.getName().trim().length() > 0){
				isExist = dataTransformsDao.checkTransformNameExists(transform);
			}
			if(!isExist){
				logger.debug("Save transform for transform name {}",transform.getName());
				final Long id = dataTransformsDao.saveTransform(transform);
				logger.debug("Successfully saved transform for transform name {}",transform.getName());
				final ResponseStatus response = new ResponseStatus();
				response.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
				response.setId(id);
				return new ResponseEntity<>(response,HttpStatus.OK);
			}else{
				logger.debug("Transform with same name ",transform.getName()+" already exists");
				final ResponseStatus response = new ResponseStatus();
				response.setMessage("This transform name "+transform.getName()+" already exists,please enter another name.");
				return new ResponseEntity<>(response,HttpStatus.OK);
			}
			
		} catch (Exception e)
		{
			event.addField("Failed save Transform content received :: ",transform.getName());
			auditManager.audit(event);
			logger.error("Exception in saving transform ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while saving transform ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Persist workflow into the database
	 * @param workflow - workflow which is going to save into database
	 * @return workflow id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/createWorkflow",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveWorkflow(@RequestBody final DTWWorkflow workflow,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		boolean isExist = false;
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"createWorkflow"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("saveTransform");
		try
		{
			event.addField("Create workflow name content received :: ",workflow.getListWorkflowEditor()!=null?workflow.getListWorkflowEditor().getName():"");
			auditManager.audit(event);
			validateWorkflow(workflow);
			isExist = dataTransformsDao.checkWorkflowNameExists(workflow);
			if(!isExist){
				fillScheduleDetails(workflow.getListWorkflowEditor());
				logger.debug("Save workflow for workflow name {}",workflow.getListWorkflowEditor()!=null?workflow.getListWorkflowEditor().getName():"");
				final Long id = dataTransformsDao.saveWorkflow(workflow);
				logger.debug("Successfully saved workflow for workflow name {}",workflow.getListWorkflowEditor().getName());
				final ResponseStatus response = new ResponseStatus();
				response.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
				response.setId(id);
				return new ResponseEntity<>(response,HttpStatus.OK);
			}else{
				logger.debug("Workflow with same name ",workflow.getListWorkflowEditor().getName()+" already exists");
				final ResponseStatus response = new ResponseStatus();
				response.setMessage("This workflow name "+workflow.getListWorkflowEditor().getName()+" already exists, please enter another name.");
				return new ResponseEntity<>(response,HttpStatus.OK);
			}
		} catch (Exception e)
		{
			event.addField("Failed Save workflow name content received :: ",workflow.getListWorkflowEditor()!=null?workflow.getListWorkflowEditor().getName():"");
			auditManager.audit(event);
			logger.error("Exception in saving workflow ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while saving workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Persist workflow trigger into the database
	 * @param workflowTrigger - workflow trigger which is going to save into database
	 * @return workflow trigger id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/createWorkflowTrigger",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveWorkflowTrigger(@RequestBody final WorkflowTrigger workflowTrigger ,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"createWorkflowTrigger"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("saveWorkflowTrigger");
		try
		{
			event.addField("Create saveWorkflowTrigger content received :: ",workflowTrigger.getWorkflowId());
			auditManager.audit(event);
			validateWorkflowTrigger(workflowTrigger);
			logger.debug("Save workflow trigger for workflow id {}",workflowTrigger.getWorkflowId());
			final Long id = dataTransformsDao.saveWorkflowTrigger(workflowTrigger);
			final ResponseStatus response = new ResponseStatus();
			response.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			response.setId(id);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed saveWorkflowTrigger content received :: ",workflowTrigger.getWorkflowId());
			auditManager.audit(event);
			logger.error("Exception in saving workflow triggers ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while saving workflow triggers ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Persist workflow activity into the database
	 * @param workflowActivity - workflow activity which is going to save into database
	 * @return workflow activity id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/createWorkflowActivity",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveWorkflowActivity(@RequestBody final WorkflowActivity workflowActivity,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"createWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("saveWorkflowActivity");
		try
		{
			event.addField("Create saveWorkflowActivity content received :: ",workflowActivity.getWorkflowId());
			auditManager.audit(event);
			validateWorkflowActivity(workflowActivity);
			if(StringUtils.isBlank(workflowActivity.getCreatedby()))
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,
						"createdby"));
			}
			logger.debug("Save workflow activity for workflow id {}",workflowActivity.getWorkflowId());
			final Long id = dataTransformsDao.saveWorkflowActivity(workflowActivity);
			final ResponseStatus response = new ResponseStatus();
			response.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			response.setId(id);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed save Transform content received :: ",workflowActivity.getWorkflowId());
			auditManager.audit(event);
			logger.error("Exception in saving workflow activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while saving workflow activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Persist transform activity into the database
	 * @param transformActivity - transform activity which is going to save into database
	 * @return transform activity id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/createTransformActivity",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveTransformActivity(@RequestBody final TransformActivity transformActivity,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"createTransformActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("saveTransformActivity");
		try
		{
			event.addField("Create saveTransformActivity content received :: ",transformActivity.getId());
			auditManager.audit(event);
			validateTransformActivity(transformActivity);
			logger.debug("Save transform activity for transform activity id {}",transformActivity.getId());
			final Long id = dataTransformsDao.saveTransformActivity(transformActivity);
			final ResponseStatus response = new ResponseStatus();
			response.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			response.setId(id);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed save TransformActivity content received :: ",transformActivity.getId());
			auditManager.audit(event);
			logger.error("Exception in saving transform activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while saving transform activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// Update API operations
	/**
	 * Update transform entry in database
	 * @param transform - entry properties to change
	 * @return true for successful update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateTransform",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateTransform(@RequestBody final TransformEditor transform,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		boolean isExist = false;
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", transform.getId() != null ? transform.getId() : 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateTransform"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("updateTransform");
		try
		{
			event.addField("update Transforms content received :: ",transform.getId());
			auditManager.audit(event);
			if(transform.getId()==null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"id"));
			}
			validateTransform(transform);
			if(transform.getName() != null && transform.getName().trim().length() > 0){
				isExist = dataTransformsDao.checkTransformNameExists(transform);
			}
			if(!isExist){
				logger.debug("Update transform for transform id {}",transform.getId());
				final Boolean response = dataTransformsDao.updateTransform(transform);
					if(!response)
					{
						throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
					}
				logger.debug("Successfully updated transform for transform id {}",transform.getId());
				final ResponseStatus responseStatus = new ResponseStatus();
				responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
				responseStatus.setId(transform.getId());
				return new ResponseEntity<>(responseStatus,HttpStatus.OK);
			}else{
				logger.debug("Transform with same name ",transform.getName()+" already exists");
				final ResponseStatus response = new ResponseStatus();
				response.setMessage("This transform name "+transform.getName()+" already exists,please enter another name.");
				return new ResponseEntity<>(response,HttpStatus.OK);
			}
		} catch (Exception e)
		{
			event.addField("Failed update Transform content received :: ",transform.getId());
			auditManager.audit(event);
			logger.error("Exception in updating transform ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while updating transform ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Update workflow entry in database
	 * @param workflow - entry properties to change
	 * @return true for successful update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateWorkflow",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateWorkflow(@RequestBody final DTWWorkflow workflow,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		boolean isExist = false;
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflow.getId() != null ? workflow.getId() : 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateWorkflow"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("updateWorkflow");
		try
		{
			event.addField("Update Workflow content received :: ",workflow.getId());
			auditManager.audit(event);
			if(workflow.getId()==null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"id"));
			}
			validateWorkflow(workflow);
			isExist = dataTransformsDao.checkWorkflowNameExists(workflow);
			if(!isExist){
				fillScheduleDetails(workflow.getListWorkflowEditor());
				logger.debug("Update workflow for workflow id {}",workflow.getId());
				final Boolean response = dataTransformsDao.updateWorkflow(workflow);
				if(!response)
				{
					throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
				}
				logger.debug("Successfully updated workflow for workflow id {}",workflow.getId());
				final ResponseStatus responseStatus = new ResponseStatus();
				responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
				responseStatus.setId(workflow.getId());
				return new ResponseEntity<>(responseStatus,HttpStatus.OK);
			}else{
				logger.debug("Workflow with same name ",workflow.getListWorkflowEditor().getName()+" already exists");
				final ResponseStatus response = new ResponseStatus();
				response.setMessage("This workflow name "+workflow.getListWorkflowEditor().getName()+" already exists, please enter another name.");
				return new ResponseEntity<>(response,HttpStatus.OK);
			}
			
		} catch (Exception e)
		{
			event.addField("Failed Update Transform content received :: ",workflow.getId());
			auditManager.audit(event);
			logger.error("Exception in updating workflow  ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while updating workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Update workflow trigger entry in database
	 * @param workflowTrigger - entry properties to change
	 * @return true for successful update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateWorkflowTrigger",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateWorkflowTrigger(@RequestBody final WorkflowTrigger workflowTrigger,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowTrigger.getWorkflowId() != null ? workflowTrigger.getWorkflowId() : 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateWorkflowTrigger"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("updateWorkflowTrigger");
		try 
		{
			event.addField("Update WorkflowTrigger content received :: ",workflowTrigger.getId());
			auditManager.audit(event);
			if(workflowTrigger.getId()==null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"id"));
			}
			validateWorkflowTrigger(workflowTrigger);
			logger.debug("Update workflow trigger for id {}",workflowTrigger.getId());
			final Boolean response = dataTransformsDao.updateWorkflowTrigger(workflowTrigger);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully updated workflow trigger for id {}",workflowTrigger.getId());
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowTrigger.getId());
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Update WorkflowTrigger content received :: ",workflowTrigger.getId());
			auditManager.audit(event);
			logger.error("Exception in updating workflow trigger ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while updating workflow trigger ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Update workflow activity entry in database
	 * @param workflowActivity - entry properties to change
	 * @return true for successful update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateWorkflowActivity",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateWorkflowActivity(@RequestBody final WorkflowActivity workflowActivity,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowActivity.getWorkflowId() != null ? workflowActivity.getWorkflowId() : 0 );}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("updateWorkflowActivity");
		try
		{
			event.addField("Update WorkflowActivity  content received :: ",workflowActivity.getId());
			auditManager.audit(event);
			if(workflowActivity.getId()==null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"id"));
			}
			validateWorkflowActivity(workflowActivity);
			logger.debug("Update workflow activity for activity id {}",workflowActivity.getId());
			final Boolean response = dataTransformsDao.updateWorkflowActivity(workflowActivity);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully updated workflow activity for activity id {}",workflowActivity.getId());
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowActivity.getId());
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Update WorkflowActivity content received :: ",workflowActivity.getId());
			auditManager.audit(event);
			logger.error("Exception in updating workflow activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while updating workflow activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Update transform activity entry in database
	 * @param transformActivity - entry properties to change
	 * @return true for successful update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateTransformActivity",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateTransformActivity(@RequestBody final TransformActivity transformActivity,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", transformActivity.getTransformid() != null ? transformActivity.getTransformid() : 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateTransformActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("updateTransformActivity");
		try
		{
			event.addField("Update TransformActivity content received :: ",transformActivity.getId());
			auditManager.audit(event);
			if(transformActivity.getId()==null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,"id"));
			}
			validateTransformActivity(transformActivity);
			logger.debug("Update transform activity for activity id {}",transformActivity.getId());
			final Boolean response = dataTransformsDao.updateTransformActivity(transformActivity);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully updated transform activity for activity id {}",transformActivity.getId());
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(transformActivity.getId());
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Update TransformActivity content received :: ",transformActivity.getId());
			auditManager.audit(event);
			logger.error("Exception in updating transform activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while updating transform activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//Actions
	/**
	 * Restart failed workflow activity
	 * @param workflowActivity -workflow activity which is going to restart
	 * @return true for successful status update
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/restartWorkflowActivity",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> restartWorkflowActivity(@RequestBody final WorkflowActivity workflowActivity,@RequestHeader HttpHeaders headers,BindingResult bindingResult) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowActivity.getWorkflowId() != null ? workflowActivity.getWorkflowId() :0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"restartWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			validateRestartWorkflowActivity(workflowActivity);
			logger.debug("Restart workflow activity for activity id {}",workflowActivity.getId());
			final Boolean response = dataTransformsDao.restartWorkflowActivity(workflowActivity);
			if(!response)
			{
				String statusMsg = Constants.ACTIVITY_FAIL_TO_RESTART_MSG;
				try 
				{
					DTWSearchCriteria listCriteria = new DTWSearchCriteria();
					listCriteria.setId(workflowActivity.getId());
					List<WorkflowActivity> activityList = dataTransformsDao.getWorkflowActivityForSearchCriteria(listCriteria);
					if(activityList!=null && !activityList.isEmpty())
					{
						if(activityList.get(0).getStatus()==Constants.ACTIVITY_COMPLETED)
						{
							statusMsg = Constants.ACTIVITY_FAIL_TO_RESTART_COMP_WORKLOW_MSG;
						}
					}
				} catch (Exception e) 
				{
					logger.error("Failed to fetch workflow activity",e);
				}
				throw new DataTransformsException(statusMsg);
			}else{
				// Sending workflow notifications 
				Map<String,String> templateValues=getNotificationTemplateValues(workflowActivity.getWorkflowId());
				workflowNotificationHandler.sendEmailNotification(templateValues, NotificationStatusTypes.NOTIFICATION_RETRY.getValue(), bindingResult);
			}
			logger.debug("Successfully restarted workflow activity for activity id {}",workflowActivity.getId());
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowActivity.getId());
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception while restarting workflow activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while restarting workflow activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Cancel workflow activity
	 * @param workflowActivity - workflow activity which is about to cancel
	 * @return true for successful status update as stopped
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/cancelWorkflowActivity",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> cancelWorkflowActivity(@RequestBody final WorkflowActivity workflowActivity,@RequestHeader HttpHeaders headers,BindingResult bindingResult) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowActivity.getWorkflowId() != null ? workflowActivity.getWorkflowId() :0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"cancelWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			validateCancelWorkflowActivity(workflowActivity);
			logger.debug("Cancel workflow activity for activity id {}",workflowActivity.getId());
			final Boolean response = dataTransformsDao.cancelWorkflowActivity(workflowActivity);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}else{
				//Sending notifications
				Map<String,String> templateValues=getNotificationTemplateValues(workflowActivity.getWorkflowId());
				workflowNotificationHandler.sendEmailNotification(templateValues, NotificationStatusTypes.NOTIFICATION_CANCELLED.getValue(), bindingResult);
			}
			logger.debug("Successfully cancelled workflow activity for activity id {}",workflowActivity.getId());
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowActivity.getId());
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in cancel workflow activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while cancelling workflow activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	//Delete API calls
	
	/**
	 * Deletes transform entry in database
	 * @param transformId - row identifier
	 * @return true for successful delete
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteTransform/{transformId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteTransform(@PathVariable final Long transformId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", transformId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteTransform"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("deleteTransform");
		try
		{
			event.addField("Delete Transform content received :: ",transformId);
			auditManager.audit(event);
			logger.debug("Delete trnasform for transform id {}",transformId);
			final Boolean response = dataTransformsDao.deleteTransform(transformId);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully deleted transform for transform id {}",transformId);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(transformId);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Delete Transform content received :: ",transformId);
			auditManager.audit(event);
			logger.error("Exception in delete transform ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while delete transform ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Deletes workflow entry in database
	 * @param workflowId - row identifier
	 * @return true for successful delete
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteWorkflow/{workflowId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteWorkflow(@PathVariable final Long workflowId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteWorkflow"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("deleteWorkflow");
		try
		{
			event.addField("Delete Workflow content received :: ",workflowId);
			auditManager.audit(event);
			logger.debug("Delete workflow for workflow id {}",workflowId);
			final Boolean response = dataTransformsDao.deleteWorkflow(workflowId);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully deleted workflow for workflow id {}",workflowId);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowId);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Delete workflow content received :: ",workflowId);
			auditManager.audit(event);
			logger.error("Exception in delete workflow ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while delete workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Deletes workflow trigger entry in database
	 * @param workflowTriggerId - row identifier
	 * @return true for successful delete
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteWorkflowTrigger/{workflowTriggerId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteWorkflowTrigger(@PathVariable final Long workflowTriggerId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteWorkflowTrigger"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("deleteWorkflowTrigger");
		try
		{
			event.addField("Delete WorkflowTrigger content received :: ",workflowTriggerId);
			auditManager.audit(event);
			logger.debug("Delete workflow trigger for trigger id {}",workflowTriggerId);
			final Boolean response = dataTransformsDao.deleteWorkflowTrigger(workflowTriggerId);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully deleted workflow trigger for trigger id {}",workflowTriggerId);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowTriggerId);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Delete WorkflowTrigger content received :: ",workflowTriggerId);
			auditManager.audit(event);
			logger.error("Exception in delete workflow trigger ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while delete workflow trigger ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Deletes workflow activity entry in database
	 * @param workflowActivityId - row identifier
	 * @return true for successful delete
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteWorkflowActivity/{workflowActivityId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteWorkflowActivity(@PathVariable final Long workflowActivityId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("deleteWorkflowActivity");
		try
		{
			event.addField("Delete WorkflowActivity content received :: ",workflowActivityId);
			auditManager.audit(event);
			logger.debug("Delete workflow activity for activity id {}",workflowActivityId);
			final Boolean response = dataTransformsDao.deleteWorkflowActivity(workflowActivityId);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully deleted workflow activity for activity id {}",workflowActivityId);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(workflowActivityId);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Delete WorkflowActivity content received :: ",workflowActivityId);
			auditManager.audit(event);
			logger.error("Exception in delete workflow activity ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while delete workflow activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Deletes transform activity entry in database
	 * @param transformActivityId - row identifier
	 * @return true for successful delete
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/deleteTransformActivity/{transformActivityId}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteTransformActivity(@PathVariable final Long transformActivityId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.TRANSFORM.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("TRANSFORMID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"deleteTransformActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = audit("deleteTransformActivity");
		try
		{
			event.addField("Delete TransformActivity content received :: ",transformActivityId);
			auditManager.audit(event);
			logger.debug("Delete transform activity for activity id {}",transformActivityId);
			final Boolean response = dataTransformsDao.deleteTransformActivity(transformActivityId);
			if(!response)
			{
				throw new DataTransformsException(Constants.ACTIVITY_UPDATE_NOT_FOUND_MSG);
			}
			logger.debug("Successfully deleted the transform activity for activity id {}",transformActivityId);
			final ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setMessage(Constants.ACTIVITY_SUCCESS_MSG);
			responseStatus.setId(transformActivityId);
			return new ResponseEntity<>(responseStatus,HttpStatus.OK);
		} catch (Exception e)
		{
			event.addField("Failed Delete TransformActivity content received :: ",transformActivityId);
			auditManager.audit(event);
			logger.error("Exception in delete transform activity", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception occured while delete transform activity ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void validateTransform(final TransformEditor transform) throws DataTransformsException
	{
		if(transform.getName()==null||(transform.getCreatedby()==null&&transform.getUpdatedby()==null))
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG, " name,createdby/updatedby")); 
		}
	}
	
	private void validateWorkflow(final DTWWorkflow workflow) throws DataTransformsException
	{
		if(workflow.getListWorkflowEditor()==null||workflow.getListWorkflowEditor().getName()==null)
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG, " name")); 
		}
		if(workflow.getCreatedby()==null&&workflow.getUpdatedby()==null)
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG, " createdby/updatedby")); 
		}
	}
	
	private void validateWorkflowTrigger(final WorkflowTrigger workflowTrigger) throws DataTransformsException
	{
		if(workflowTrigger.getWorkflowId()==null||
		   workflowTrigger.getFileDefinitionId()==null||
		   (workflowTrigger.getCreatedby()==null&&workflowTrigger.getUpdatedby()==null))
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG, " workflowId,fileDefinitionId,createdby/updatedby")); 
		}
	}
	
	private void validateWorkflowActivity(final WorkflowActivity workflowActivity) throws DataTransformsException
	{
		if (workflowActivity.getWorkflowId() == null ||
			workflowActivity.getStatus() == null)
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,
						" workflowId,status"));
		}
	}
	
	private void validateTransformActivity(final TransformActivity transformActivity) throws DataTransformsException
	{
		if(transformActivity.getWorkflowactivityid()==null||transformActivity.getTransformid()==null)
		{
			throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG, " workflowactivityid,transformid")); 
		}
	}
	
	private void validateRestartWorkflowActivity(final WorkflowActivity workflowActivity) throws DataTransformsException
	{
		logger.info("Workflow activity id :: "+workflowActivity.getId()+" updated by :: "+workflowActivity.getUpdatedby());
		if (workflowActivity.getId() == null ||
			workflowActivity.getUpdatedby() == null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,
							" id,updatedby"));
			}
	}
	
	private void validateCancelWorkflowActivity(final WorkflowActivity workflowActivity) throws DataTransformsException
	{
		if (workflowActivity.getId() == null ||
			workflowActivity.getUpdatedby() == null)
			{
				throw new DataTransformsException(String.format(Constants.ACTIVITY_REQUIRED_FIELDS_MSG,
							" id,updatedby"));
			}
	}
	
	@ExceptionHandler(DataTransformsException.class)
	public ResponseEntity<ErrorInformation> genericExceptionHandler(final HttpServletRequest req, final Exception e) 
	{
		final ErrorInformation error = new ErrorInformation(e, req.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	private TimeZoneData loadTimeZones() throws Exception
	{
		TimeZoneData timeZoneData=null;
		try{
			timeZoneData = timeZoneData();
			List<Map<String,String>> regionIdsAndTimeZoneLst=new ArrayList<>();
			Set<Integer> offsetSet =new TreeSet<Integer>();
			for(String offset: timeZoneData.getOffsets())
			{
				offsetSet.add(Integer.valueOf(offset));
			}
			for(Integer offset: offsetSet)
			{
				for(int i=0;i<timeZoneData.getOffsets().length;i++)
				{
					if(offset==Integer.parseInt(timeZoneData.getOffsets()[i]))
					{
						Map<String,String> regionIdsAndTZObj = new HashMap<>();
						regionIdsAndTZObj.put("regionid", timeZoneData.getRegionIds()[i]);
						String replaceedRegion=timeZoneData.getRegionIds()[i];
						replaceedRegion=replaceedRegion.replace("_", " ");
						regionIdsAndTZObj.put("regionvalue", timeZoneData.getRegionsTimeZone()[i]+" "+ replaceedRegion);
						regionIdsAndTimeZoneLst.add(regionIdsAndTZObj);
					}
				}
			}
			timeZoneData.setRegionIdsAndTimeZoneLst(regionIdsAndTimeZoneLst);
		}catch (Exception e) {
			throw e;
		}
		return timeZoneData;
	}
	private TimeZoneData timeZoneData() throws Exception
	{
		TimeZoneData timeZoneData = new TimeZoneData();
		try
		{
			String[] timeZones = TimeZone.getAvailableIDs();
			Set<String> requiredTimeZones = new HashSet<>();
			int counter = 0;
			
			String region = null;
			String region_code = null;
			String region_zone = null;
			String region_offset = null;
			String offset = null;
			
			requiredTimeZones.add("Japan");
			requiredTimeZones.add("Europe/Paris");
			requiredTimeZones.add("Europe/London");
			requiredTimeZones.add("America/New_York");
			requiredTimeZones.add("America/Chicago");
			requiredTimeZones.add("America/Denver");
			requiredTimeZones.add("America/Los_Angeles");
			requiredTimeZones.add("US/Samoa");
			requiredTimeZones.add("US/Hawaii");
			requiredTimeZones.add("America/Sao_Paulo");
			requiredTimeZones.add("Atlantic/Azores");
			requiredTimeZones.add("Africa/Cairo");
			requiredTimeZones.add("Europe/Moscow");
			requiredTimeZones.add("Asia/Muscat");
			requiredTimeZones.add("Asia/Karachi");
			requiredTimeZones.add("Asia/Dhaka");
			requiredTimeZones.add("Asia/Bangkok");
			requiredTimeZones.add("Asia/Calcutta");
			requiredTimeZones.add("Australia/Sydney");
			requiredTimeZones.add("Asia/Kamchatka");
			requiredTimeZones.add("Pacific/Noumea");
			requiredTimeZones.add("US/Alaska");
			requiredTimeZones.add("America/Caracas");
			requiredTimeZones.add("America/Noronha");
			requiredTimeZones.add("Australia/Perth");
			requiredTimeZones.add("US/Arizona");
			requiredTimeZones.add("UTC");
			
			Map<String, String> requiredRegionCodes = new HashMap<>();
			
			requiredRegionCodes.put("SAMOA STANDARD TIME", "NAT");
			requiredRegionCodes.put("HAWAII STANDARD TIME", "AHST");
			requiredRegionCodes.put("ALASKA STANDARD TIME", "YST");
			//For LOS-Angles - Consider - Day Light - Scheme
			requiredRegionCodes.put("PACIFIC STANDARD TIME", "PST");
			requiredRegionCodes.put("PACIFIC DAYLIGHT TIME", "PDT");
			requiredRegionCodes.put("MOUNTAIN STANDARD TIME", "MST");
			//This will be in two modes - CST - CDT
			requiredRegionCodes.put("CENTRAL STANDARD TIME", "CST");
			requiredRegionCodes.put("CENTRAL DAYLIGHT TIME", "CDT");
			
			requiredRegionCodes.put("EASTERN STANDARD TIME", "EST");
			requiredRegionCodes.put("EASTERN DAYLIGHT TIME", "EDT");
			
			requiredRegionCodes.put("VENEZUELA TIME", "AST");
			requiredRegionCodes.put("ATLANTIC STANDARD TIME", "AZT");
			requiredRegionCodes.put("BRASILIA TIME", "BZT");
			requiredRegionCodes.put("AZORES TIME", "WAT");
			requiredRegionCodes.put("GREENWICH MEAN TIME", "UTC");
			requiredRegionCodes.put("CENTRAL EUROPEAN TIME", "BST");
			requiredRegionCodes.put("EASTERN EUROPEAN TIME", "EET");
			requiredRegionCodes.put("MOSCOW STANDARD TIME", "BGT");
			requiredRegionCodes.put("GULF STANDARD TIME", "R3T");
			requiredRegionCodes.put("PAKISTAN TIME", "R4T");
			requiredRegionCodes.put("INDIA STANDARD TIME", "IST");
			requiredRegionCodes.put("BANGLADESH TIME", "R5T");
			requiredRegionCodes.put("INDOCHINA TIME", "JVT");
			requiredRegionCodes.put("JAPAN STANDARD TIME", "JST");
			requiredRegionCodes.put("EASTERN STANDARD TIME (NEW SOUTH WALES)", "AEST");
			requiredRegionCodes.put("NEW CALEDONIA TIME", "R11S");
			requiredRegionCodes.put("PETROPAVLOVSK-KAMCHATSKI TIME", "NZT");
			requiredRegionCodes.put("FERNANDO DE NORONHA TIME", "FNT");
			
			Map<String, String> location_Names = new HashMap<>();
			
			location_Names.put("Japan", "Tokyo");
			location_Names.put("Asia/Calcutta", "India");
			location_Names.put("Asia/Kolkata", "India");
			location_Names.put("Europe/Paris", "Paris");
			location_Names.put("Europe/London", "London");
			location_Names.put("America/New_York", "New York");
			location_Names.put("America/Chicago", "Chicago");
			location_Names.put("America/Denver", "Denver");
			location_Names.put("America/Los_Angeles", "Los Angeles");
			location_Names.put("US/Samoa", "Samoa");
			location_Names.put("US/Hawaii", "Hawaii");
			location_Names.put("Canada/Atlantic", "Atalantic Ocean");
			location_Names.put("America/Sao_Paulo", "Sao Paulo");
			location_Names.put("Atlantic/Azores", "Azores");
			location_Names.put("Africa/Cairo", "Cairo");
			location_Names.put("Europe/Moscow", "Moscow");
			location_Names.put("Asia/Muscat", "Muscat");
			location_Names.put("Asia/Karachi", "Islamabad");
			location_Names.put("Asia/Dhaka", "Dhaka");
			location_Names.put("Asia/Bangkok", "Bangkok");
			location_Names.put("Australia/Perth", "Perth");
			location_Names.put("Australia/Sydney", "Sydney");
			location_Names.put("New Zealand / Wellington", "Wellington");
			location_Names.put("Asia/Kamchatka", "Kamchatka");
			location_Names.put("Pacific/Noumea", "Noumea");
			location_Names.put("US/Alaska", "Alaska");
			location_Names.put("America/Phoenix", "Phoenix");
			location_Names.put("America/Caracas", "Caracas");
			location_Names.put("America/Noronha", "Noronha");
			location_Names.put("US/Arizona", "Arizona");
			//These are the variables which will be carried to Server Side and placed in the Flex UI Vars
			String[] regionsTimeZone_codes = new String[requiredTimeZones.size()];
			String[] regionsTimeZone_offsets = new String[requiredTimeZones.size()];
			String[] regionsTimeZone = new String[requiredTimeZones.size()];
			String[] regions = new String[requiredTimeZones.size()];
			String[] offsets = new String[requiredTimeZones.size()];
			String[] regionIds = new String[requiredTimeZones.size()];
			
			String gmtResource = "GMT";
			
			for(int i=0;i<timeZones.length; i++)
			{
				if(requiredTimeZones.contains(timeZones[i]))
				{
					TimeZone tz = TimeZone.getTimeZone(timeZones[i]);
					
					int rawOffset = tz.getRawOffset();
					int hour = tz.inDaylightTime(new Date()) ? ( (rawOffset+ tz.getDSTSavings()) / (60*60*1000)) : rawOffset / (60*60*1000);
					int min = Math.abs(rawOffset / (60*1000)) % 60;
					NumberFormat nf = null;
					nf = NumberFormat.getInstance();
					nf.setMinimumIntegerDigits(2);
					String minFormat = nf.format(min);
					String hourFormat = nf.format(hour);
					String displayName = null;			

					if(hour > 0)
					{
						displayName = "("+gmtResource+" +"+hourFormat+":"+minFormat+") ";
					}
					else if(hour == 0 && min == 0)
					{
						displayName = "("+gmtResource+")";
					}
					else
					{
						displayName = "("+gmtResource+ " "+ hourFormat+":"+minFormat+") ";
					}
					
					region_zone = displayName + tz.getDisplayName(tz.inDaylightTime(new Date()), 0);
					if( hour > 0 )
						region_offset = "+"+hourFormat+":"+minFormat;
					else
						region_offset = hourFormat+":"+minFormat;
					region_code = tz.getDisplayName(tz.inDaylightTime(new Date()), 0);
					//Regarding the carcus timezone issue else condition is added
					//or when the timezone is GMT-5:30 or GMT-4:30 etc.,
					//the same doesn't occurs for positive values
					//old calculation is ((-4*60)+30) gives -210
					//new calculation gives ((-4*60)+(-1*30)) gives -270 which is expected
					 if(hour>0)
                         offset = Integer.toString((hour*60)+min);//+"";
					 else
                         offset = Integer.toString((hour*60)+(-1*min));//+"";
					//offset = ((hour*60)+min)+"";
					region = location_Names.get(tz.getID());
					
					offsets[counter] = offset;
					regions[counter] = region;
					regionsTimeZone_codes[counter] = region_code;
					regionsTimeZone_offsets[counter] = region_offset;
					regionsTimeZone[counter] = region_zone;
					regionIds[counter] = timeZones[i];
					
					counter++;
				}
				region = null;
				region_code = null;
				region_zone = null;
				region_offset = null;
				offset = null;
			}
			timeZoneData.setOffsets(offsets);
			timeZoneData.setRegions(regions);
			timeZoneData.setRegionsTimeZone(regionsTimeZone);
			timeZoneData.setRegionsTimeZone_codes(regionsTimeZone_codes);
			timeZoneData.setRegionsTimeZone_offsets(regionsTimeZone_offsets);
			timeZoneData.setRegionIds(regionIds);
		}
		catch(Exception e)
		{
			throw e;
		}
		return timeZoneData;
	}
	
	//This method will fill date details for workfloweditor schedule.
	private void fillScheduleDetails(WorkflowEditor schedule) throws Exception{
		if(schedule!=null && schedule.getSchedulesetting()=='Y'){
			convertToUTC(schedule);
			caluculateScheduleNextDue(schedule);
		}
	}
	
	//This method convert given time into UTC, schedulestartdate & scheduleenddate.
	private void convertToUTC(WorkflowEditor schedule){
		if(schedule.getScheduleStartDate()!=null)
			schedule.setScheduleStartDate(CommonUtil.toUTC(schedule.getScheduleStartDate().getTime(),TimeZone.getTimeZone(schedule.getTimezone())));
		if(schedule.getScheduleEndDate()!=null)
			schedule.setScheduleEndDate(CommonUtil.toUTC(schedule.getScheduleEndDate().getTime(),TimeZone.getTimeZone(schedule.getTimezone())));
	}
	
	//This method will caluculate schedulenextdue based on utc converted startdate & enddate.
	private void caluculateScheduleNextDue(WorkflowEditor schedule) throws Exception{
		Date serverNextSchDate;
		Date currentDate=Calendar.getInstance(TimeZone.getTimeZone(schedule.getTimezone())).getTime();
		Calendar cal = null;
		if(schedule.getFrequency()!=null) {
			serverNextSchDate=schedule.getScheduleStartDate();
			if(schedule.getFrequency() == 'W'||schedule.getFrequency()=='M'||schedule.getFrequency()=='N'){
				logger.info("Workflow Id: "+schedule.getWorkFlowId() + "serverNextSchDate" + serverNextSchDate +" currentDate"+ currentDate);
				while(serverNextSchDate.before(currentDate)){
					serverNextSchDate = CommonUtil.caluculateScheduleNextDue(schedule.getFrequency(), schedule.getIncludedays(), schedule.getMonthlyschdfreq(), schedule.getDayofeverymonth(), schedule.getMonthlyWeekFreq(), schedule.getMonthlyDayFreq(), serverNextSchDate, schedule.getFrquencyunit(),schedule.getTimezone());
				}
				logger.info("serverNextSchDate After Next Due: "+ serverNextSchDate);
				serverNextSchDate = CommonUtil.toUTC(serverNextSchDate.getTime(), TimeZone.getTimeZone(schedule.getTimezone()));
				logger.info("serverNextSchDate After Converted to UTC: "+ serverNextSchDate);

			}else if(schedule.getFrequency()=='D')
			{   cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
				cal.setTime(schedule.getScheduleStartDate());
			    Calendar present = new GregorianCalendar();
			    present.setTimeZone(TimeZone.getTimeZone("UTC"));
	        	present.setTime(getCurrentDate());
	        	 if((cal.get(Calendar.HOUR_OF_DAY) * 3600 + cal.get(Calendar.MINUTE)*60+cal.get(Calendar.SECOND)) < (present.get(Calendar.HOUR_OF_DAY)*3600+present.get(Calendar.MINUTE)*60+present.get(Calendar.SECOND))){
	        		 present.add(Calendar.DATE,1);
	        		 present.set(Calendar.HOUR_OF_DAY,cal.get(Calendar.HOUR_OF_DAY));
	        		 present.set(Calendar.MINUTE,cal.get(Calendar.MINUTE));
	        		 present.set(Calendar.SECOND,cal.get(Calendar.SECOND));
	        	 }
	        	 else{
	        		 present.set(Calendar.HOUR_OF_DAY,cal.get(Calendar.HOUR_OF_DAY));
	        		 present.set(Calendar.MINUTE,cal.get(Calendar.MINUTE));
	        		 present.set(Calendar.SECOND,cal.get(Calendar.SECOND));
	        	 }
				  serverNextSchDate = present.getTime();
				  logger.info("serverNextSchDate For Datily workflow : "+ serverNextSchDate); 
			}
			if(schedule.getFrequency()=='O' || schedule.getScheduleEndDate().compareTo(serverNextSchDate) >= 0)
					schedule.setSchedulenextdue(serverNextSchDate);
		}
	}
	
	/**
	 * Persist workflow into the database
	 * @param workflow - workflow which is going to save into database
	 * @return workflow id - auto generated primary key
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/updateWorkFlowSchedule",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateWorkFlowSchedule(@RequestBody final WorkflowEditor workflowEditor,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowEditor.getWorkFlowId() != null ? workflowEditor.getWorkFlowId() : 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateWorkFlowSchedule"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			Boolean isUpdated = dataTransformsDao.updateWorkFlowEditor(workflowEditor);
			return new ResponseEntity<>(isUpdated,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in updating workflow schedule", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Exception in updating workflow schedule ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@HystrixCommand
	@RequestMapping(path="/updateWorkFlowStatus",method=RequestMethod.POST)
	public ResponseEntity<?> updateWorkFlowStatus(@RequestBody Map<String, String> requestData,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", requestData.get("workFlowId") != null  ? requestData.get("workFlowId") : 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:updateWorkFlowStatus()");
		Long workFlowId;
		Character status;
		WorkflowEditor workFlowEditor=null;
		
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"updateWorkFlowStatus"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			workFlowId = Long.parseLong(requestData.get("workFlowId"));
			status = requestData.get("status").charAt(0);
			workFlowEditor=dataTransformsDao.getWorkFlowEditor(workFlowId);
			if(workFlowEditor!=null && workFlowEditor.getSchedulenextdue()!=null){
				if(workFlowEditor.getFrequency()!=null && (workFlowEditor.getFrequency()=='D' || workFlowEditor.getFrequency()=='W' || workFlowEditor.getFrequency()=='M' || workFlowEditor.getFrequency()=='N') && workFlowEditor.getScheduleEndDate().compareTo(workFlowEditor.getSchedulenextdue()) >= 0)
					workFlowEditor.setStatus('W');
				else
					workFlowEditor.setStatus(status);
			}else if(workFlowEditor!=null)
					workFlowEditor.setStatus(status);
			Boolean isUpdated = dataTransformsDao.updateWorkFlowEditorStatus(workFlowEditor.getWorkFlowScheduleId(), workFlowEditor.getStatus());
			return new ResponseEntity<Boolean>(isUpdated, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:updateWorkFlowStatus", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to update work flow editor status", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Get All available workflows
	 * @return list of workflows
	 * @throws DataTransformsException
	 */
	@HystrixCommand
	@RequestMapping(path="/getWorkflowById/{workflowId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkFlowById(@PathVariable("workflowId") Long workflowId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"getWorkflowById"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflow");
			DTWWorkflow response = dataTransformsDao.getWorkflowById(workflowId);
			if(response == null)
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@HystrixCommand
	@RequestMapping(path="/triggerWorkFlowActivity/{customerId}",method=RequestMethod.GET)
	public ResponseEntity<?> riggerWorkFlowActivity(@PathVariable("customerId") Long customerId) throws DataTransformsException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		HttpHeaders headers = new HttpHeaders();
		CustomerBO customerBO=null;
		RestRequestHandler restHandler = new RestRequestHandler();
		HttpEntity<?> entity = null;
		try{
			ZetaUtil.getHelper().getCustomerDataSource();
			entity = new HttpEntity<>(ZetaUtil.getHelper().getHeaders());
			customerBO=restHandler.exchange(ZetaUtil.getHelper().getEndpoint("security") + "/getCustomerByID/" + customerId, HttpMethod.GET, entity, CustomerBO.class).getBody();		
			restHandler.exchange(ZetaUtil.getHelper().getEndpoint("workflow")+"/datatransforms/triggerWorkFlowActivity/"+customerBO.getCustCode(), HttpMethod.GET, entity, Boolean.class);
			headers.setContentType(MediaType.TEXT_PLAIN);
			return new ResponseEntity<>("Workflows triggered successfully.", headers, HttpStatus.OK);
		}catch (Exception e){
			logger.error("Exception in triggering workflow ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String errorMsg = messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while triggering workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/getNotificationWorkflowMappings/{workFlowId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getNotificationWorkflowMappings(@PathVariable("workFlowId") Long workFlowId,@RequestHeader HttpHeaders headers) throws DataTransformsException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workFlowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] {"getNotificationWorkflowMappings"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Map<String,String> response=null;
		try {
			response =new HashMap<>();
			logger.debug("Fetch workflow");
			response=getNotificationTemplateValues(workFlowId);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e)
		{
			logger.error("Exception in fetching workflow ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflow ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	private AuditEvent audit(String actionName){
		AuditEvent event = new AuditEvent();
		event.setActor("DataTransformsController");
		event.setAction(actionName);
		return event;
	}
	
	private Map<String,String> getNotificationTemplateValues(long workFlowId) throws DataTransformsException{
		logger.debug("Begin :: "+getClass()+"  getNotificationTemplateValues(long workFlowId)");
		Map<String,String> response =new HashMap<>();
		DTWWorkflow dtwWorkflow = dataTransformsDao.getWorkflowById(workFlowId);
		if(dtwWorkflow == null){
			throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
		}
		if(dtwWorkflow.getListWorkflowEditor()!=null){
			response.put("name", dtwWorkflow.getListWorkflowEditor().getName());
			response.put("isEnable", String.valueOf(dtwWorkflow.getListWorkflowEditor().getEnablemode()));
		}
		if (dtwWorkflow.getMappingstep()!=null){
			StringBuilder workflowNames=new StringBuilder();
			StringBuilder transformNames=new StringBuilder();
			for(WorkflowTransforms workflowTransforms: dtwWorkflow.getMappingstep()){
				if (workflowTransforms.getType().equals("T")){
					transformNames.append(dataTransformsDao.getTransformById(workflowTransforms.getStepId()).getName()).append(",");
				}else{
					workflowNames.append(dataTransformsDao.getWorkFlowEditor(workflowTransforms.getStepId()).getName()).append(",");
				}
			}
			
			if (workflowNames.toString().length()>0){
				response.put("aworkflows", workflowNames.toString().substring(0, workflowNames.toString().length()-1));
			}else{
				response.put("aworkflows", "-");
			}
			if (transformNames.toString().length()>0){
				response.put("atransforms", transformNames.toString().substring(0, transformNames.toString().length()-1));
			}else{
				response.put("atransforms", "-");
			}
		}
		response.put("executedby", dtwWorkflow.getUpdatedby());
		response.put("departmentId", dtwWorkflow.getDepartmentId().toString());
		logger.debug("End :: "+getClass()+"  getNotificationTemplateValues(long workFlowId)");
		return response;
	}
	
	@HystrixCommand
	@RequestMapping(path="/getWorkflowsForAPI",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getWorkflowsForAPI(@RequestBody final DTWSearchCriteria searchCriteria,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowsForAPI"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try
		{
			logger.debug("Fetch workflows for search criteria");
			final List<DTWWorkflow> response = dataTransformsDao.getWorkflowsForAPI(searchCriteria);
			if(response.isEmpty())
			{
				throw new DataTransformsException(Constants.ACTIVITY_OBJECT_ALL_NOT_FOUND_MSG);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e){
			logger.error("Exception in fetching workflows for search criteria ", e);
			ResponseObject resp = new ResponseObject();
			String errorCode ="E00002";
			String localMsg = null;
			if(e instanceof DataTransformsException)
			{
				DataTransformsException de = (DataTransformsException)e;
				errorCode = de.getErrorCode();
				localMsg = de.getMessage();
			}
			final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
			resp.addError("Error occurred while fetching workflows for search criteria ",errorMsg);
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/getIsUsedInList/{workflowId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getIsUsedInList(@PathVariable("workflowId")final Long workflowId,@RequestHeader HttpHeaders headers) throws DataTransformsException
	{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", workflowId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try{
		
			Long response = dataTransformsDao.getIsUsedInList(workflowId);
			return new ResponseEntity<>(response,HttpStatus.OK);
		
	} catch (Exception e)
	{
		logger.error("Exception in getting workflow Id count ", e);
		ResponseObject resp = new ResponseObject();
		String errorCode ="E00002";
		String localMsg = null;
		if(e instanceof DataTransformsException)
		{
			DataTransformsException de = (DataTransformsException)e;
			errorCode = de.getErrorCode();
			localMsg = de.getMessage();
		}
		final String errorMsg = localMsg!=null?localMsg:messageSource.getMessage(errorCode, new Object[] {},LocaleContextHolder.getLocale());
		resp.addError("Error occurred while getting count for WorkFlowId ",errorMsg);
		resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	}
	/**
	 * 
	 * 
	 * Method Name 	: updateWorkFlowActivityStatus
	 * Description 	: The Method "updateWorkFlowActivityStatus" is used for 
	 * Date    		: 28 Jun 2018, 14:44:50
	 * @param customerId
	 * @param fromStatus
	 * @param toStatus
	 * @param userName
	 * @return
	 * @throws DataTransformsException
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(path="/updateWorkFlowActivityStatus/{activityId}/{fromStatus}/{toStatus}/{userName}",method=RequestMethod.PATCH)
	public ResponseEntity<?> updateWorkFlowActivityStatus(@PathVariable("activityId") Long activityId,@PathVariable("fromStatus") String fromStatus,@PathVariable("toStatus") String toStatus,@PathVariable("userName") String userName,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.WORK_FLOW.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("WORKFLOWID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, RESOURCE_NAME, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", new Object[] 
					{"getWorkflowActivity"},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		Boolean isUpdated=false;
		try{
			isUpdated=dataTransformsDao.updateWorkflowStatus(activityId, fromStatus, toStatus, userName);
			return new ResponseEntity<>(isUpdated,  HttpStatus.OK);
		}catch (Exception e){
			logger.error("Exception occurred while updating workflow.", e);
			ResponseObject resp = new ResponseObject();
			resp.addError("Exception occurred while updating workflow.",e.getMessage());
			resp.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}

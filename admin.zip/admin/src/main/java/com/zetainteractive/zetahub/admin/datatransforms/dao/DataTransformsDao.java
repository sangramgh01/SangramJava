package com.zetainteractive.zetahub.admin.datatransforms.dao;

import java.io.Serializable;
import java.util.List;

import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.TransformActivity;
import com.zetainteractive.zetahub.commons.domain.TransformEditor;
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor;
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger;
import com.zetainteractive.zetahub.admin.datatransforms.exception.DataTransformsException;


public interface DataTransformsDao extends Serializable
{
	
	/**
	 * Get All available data transforms
	 * @return list of active transforms
	 */
	List<TransformEditor> getAllTransforms();
	
	/**
	 * Lists all the transforms bases on the search criteria
	 * @param listCriteria - 
	 * @return List of Transforms -
	 * @throws DataTransformsException -
	 */
	List<TransformEditor> getTransformsForSearchCriteria(DTWSearchCriteria listCriteria) throws DataTransformsException;

	/**
	 * Get All available workflows
	 * @return list of active workflows
	 */
	List<DTWWorkflow> getAllWorkflows();
	
	/**
	 * Get all master workflows which are of triggered type
	 * @return list of triggered workflows
	 */
	List<DTWWorkflow> getMasterWorkflows(final long departmentId);
	
	/**
	 * Get All transforms associated with the workflow
	 * @return list of transforms
	 */
	List<TransformEditor> getAssociatedTransforms(Long workflowId)  throws DataTransformsException;
	
	/**
	 * Update all activities status to inverse respective to input. for instance, if input status is 'W' then change all activity status to 'B'
	 * @param status - 
	 * @param message -
	 * @return true for success for update
	 */
	Boolean blockOrUnBlockWorkFlowActivities(String status, String message);
	
	/**
	 * Lists all the workflows bases on the search criteria
	 * @param listCriteria - 
	 * @return List of Workflow
	 * @throws DataTransformsException -
	 */
	List<DTWWorkflow> getWorkflowsForSearchCriteria(final DTWSearchCriteria listCriteria) throws DataTransformsException;

	/**
	 * Get All available workflow trigger schedules
	 * @return list of workflow triggers
	 */
	List<WorkflowTrigger> getWorkflowTriggers(Long workflowId, Long fileDefId);

	/**
	 * Get All created workflow activities for the scheduled workflow
	 * @param workflowId - <br/>
	 * 					 workflow id 
	 * @return list of workflow activities
	 */
	List<WorkflowActivity> getWorkflowActivity(Long workflowId);
	
	/**
	 * Get all workflow activities for the specified search criteria
	 * @param listCriteria -
	 * @return list of workflow activities -
	 * @throws DataTransformsException -
	 */
	List<WorkflowActivity> getWorkflowActivityForSearchCriteria(DTWSearchCriteria listCriteria) throws DataTransformsException;

	/**
	 * Get all transform activities created for workflow
	 * @param workflowActivityId - workflow activity id
	 * @param transformId - transform is associated with workflow
	 * @return list of transform activities created for workflow
	 */
	List<TransformActivity> getTransformActivity(Long workflowActivityId, Long transformId);
	
	/**
	 * Get all transform activities created for workflow
	 * @param workflowActivityId - workflow activity id
	 * @return list of transform activities created for workflow
	 */
	List<TransformActivity> getTransformActivity(final Long workflowActivityId);
	
	/**
	 * This method is used to get  the  Workflow  Object by workflow Id and its activity
	 * @param workflowId
	 * @param activityId
	 * @return workflow
	 * @throws DataTransformsException
	 */
	DTWWorkflow getWorkflowWithActivities(long workflowId,long activityId) throws DataTransformsException;

	/**
	 * Persist transform into the database
	 * @param transform - transform which is going to save into database
	 * @return transform id - auto generated primary key
	 */
	Long saveTransform(TransformEditor transform);

	/**
	 * Persist workflow into the database
	 * @param workflow - workflow which is going to save into database
	 * @return workflow id - auto generated primary key
	 */
	Long saveWorkflow(DTWWorkflow workflow) throws DataTransformsException;

	/**
	 * Persist workflow trigger into the database
	 * @param workflowTrigger - workflow trigger which is going to save into database
	 * @return workflow trigger id - auto generated primary key
	 */
	Long saveWorkflowTrigger(WorkflowTrigger workflowTrigger);

	/**
	 * Persist workflow activity into the database
	 * @param workflowActivity - workflow activity which is going to save into database
	 * @return workflow activity id - auto generated primary key
	 */
	Long saveWorkflowActivity(WorkflowActivity workflowActivity) throws DataTransformsException;

	/**
	 * Persist transform activity into the database
	 * @param transformActivity - transform activity which is going to save into database
	 * @return transform activity id - auto generated primary key
	 */
	Long saveTransformActivity(TransformActivity transformActivity) throws DataTransformsException;

	/**
	 * Update transform entry in database
	 * @param transform - entry properties to change
	 * @return true for successful update
	 */
	Boolean updateTransform(TransformEditor transform);

	/**
	 * Update workflow entry in database
	 * @param workflow - entry properties to change
	 * @return true for successful update
	 */
	Boolean updateWorkflow(DTWWorkflow workflow) throws DataTransformsException;

	/**
	 * Update workflow trigger entry in database
	 * @param workflowTrigger - entry properties to change
	 * @return true for successful update
	 */
	Boolean updateWorkflowTrigger(WorkflowTrigger workflowTrigger);

	/**
	 * Update workflow activity entry in database
	 * @param workflowActivity - entry properties to change
	 * @return true for successful update
	 */
	Boolean updateWorkflowActivity(WorkflowActivity workflowActivity);

	/**
	 * Update transform activity entry in database
	 * @param transformActivity - entry properties to change
	 * @return true for successful update
	 */
	Boolean updateTransformActivity(TransformActivity transformActivity) throws DataTransformsException;
	
	/**
	 * Restart failed workflow activity
	 * @param workflowActivity -workflow activity which is going to restart
	 * @return true for successful status update
	 */
	Boolean restartWorkflowActivity(WorkflowActivity workflowActivity);
	
	/**
	 * Cancel workflow activity
	 * @param workflowActivity - workflow activity which is about to cancel
	 * @return true for successful status update as stopped
	 */
	Boolean cancelWorkflowActivity(WorkflowActivity workflowActivity);
	
	
	/**
	 * Deletes transform entry in database
	 * @param transformId - row identifier
	 * @return true for successful delete
	 */
	Boolean deleteTransform(Long transformId);

	/**
	 * Deletes workflow entry in database
	 * @param workflowId - row identifier
	 * @return true for successful delete
	 */
	Boolean deleteWorkflow(Long workflowId);

	/**
	 * Deletes workflow trigger entry in database
	 * @param workflowTriggerId - row identifier
	 * @return true for successful delete
	 */
	Boolean deleteWorkflowTrigger(Long workflowTriggerId);

	/**
	 * Deletes workflow activity entry in database
	 * @param workflowActivityId - row identifier
	 * @return true for successful delete
	 */
	Boolean deleteWorkflowActivity(Long workflowActivityId);

	/**
	 * Deletes transform activity entry in database
	 * @param transformActivityId - row identifier
	 * @return true for successful delete
	 */
	Boolean deleteTransformActivity(Long transformActivityId);

	/**
	 * @param workFlowEditor
	 * @return
	 */
	Boolean updateWorkFlowEditor(WorkflowEditor workFlowEditor);
	
	/**
	 * @param scheduleId
	 * @param status
	 * @return
	 */
	boolean updateWorkFlowEditorStatus(long scheduleId,char status); 
	/**
	 * @param DTWWorkflowId
	 * @return
	 */
	WorkflowEditor getWorkFlowEditor(Long DTWWorkflowId);
	
	/**
	 * get workflow by id
	 * @return workflow
	 * @throws DataTransformsException 
	 */
	public DTWWorkflow getWorkflowById(long workflowId) throws DataTransformsException;
	/**
	 * Getting transform based on transform id.
	 * @param transformId
	 * @return
	 */
	TransformEditor getTransformById(long transformId);
	
	public boolean checkTransformNameExists(TransformEditor transform)throws DataTransformsException;
	
	/**
	 * Lists all the workflows bases on the search criteria
	 * @param listCriteria - 
	 * @return List of Workflow
	 * @throws DataTransformsException -
	 */
	List<DTWWorkflow> getWorkflowsForAPI(final DTWSearchCriteria listCriteria) throws DataTransformsException;
	
	public boolean checkWorkflowNameExists(DTWWorkflow workflow) throws DataTransformsException;
	
	
	public Long getIsUsedInList(final Long workflowId) throws DataTransformsException;
	/**
	 * 
	 * 
	 * Method Name 	: updateWorkflowStatus
	 * Description 	: The Method "updateWorkflowStatus" is used for 
	 * Date    		: 28 Jun 2018, 14:50:10
	 * @param workflowActivityId
	 * @param fromStatus
	 * @param toStatus
	 * @param userName
	 * @return
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	Boolean updateWorkflowStatus(Long workflowActivityId, String fromStatus, String toStatus, String userName);
}
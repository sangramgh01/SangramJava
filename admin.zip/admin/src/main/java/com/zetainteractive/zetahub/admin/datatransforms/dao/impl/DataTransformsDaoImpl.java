/**
 * DataTransformsDaoImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/
package com.zetainteractive.zetahub.admin.datatransforms.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.datatransforms.dao.DataTransformsDao;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.TransformActivityRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.TransformEditorRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.WorkflowActivityRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.WorkflowEditorRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.WorkflowRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper.WorkflowTriggerRowMapper;
import com.zetainteractive.zetahub.admin.datatransforms.exception.DataTransformsException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow;
import com.zetainteractive.zetahub.commons.domain.NameMixIn;
import com.zetainteractive.zetahub.commons.domain.RunmodeMixIn;
import com.zetainteractive.zetahub.commons.domain.TransformActivity;
import com.zetainteractive.zetahub.commons.domain.TransformEditor;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor;
import com.zetainteractive.zetahub.commons.domain.WorkflowTransforms;
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger;
/**
 * Persistence layer for Data transformations and workflows component in Admin module
 * @author Nagendra.Guttha
 *
 */
@Repository(value="dataTransformsDao")
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class DataTransformsDaoImpl implements DataTransformsDao {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	final DateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	
	@Autowired
	@Qualifier("clientJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	MessageSource messageSource;

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getAllTransforms()
	 */
	@Override
	public List<TransformEditor> getAllTransforms()
	{
		List<TransformEditor> transformsList = jdbcTemplate.query(DataTransformsQueries.TRANSFORM_BY_ALL_QUERY+" order by transformid desc",
												new TransformEditorRowMapper());
		if(transformsList == null)
		{
			logger.debug("No transforms available");
			transformsList = Collections.emptyList();
		}
		return transformsList;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getTransformsForSearchCriteria(DTWSearchCriteria)
	 */
	public List<TransformEditor> getTransformsForSearchCriteria(DTWSearchCriteria listCriteria) throws DataTransformsException
	{ 
		List<Object> params = null;
		List<TransformEditor> transformsList=null;
		int totalsize = 0;
		final StringBuilder whereClauseBuilder = new StringBuilder();
		try
		{ 
			if(listCriteria == null)
			{				 
				logger.debug("No transforms available for search criteria, so returning all transforms");
				return getAllTransforms();
			}
			if(listCriteria.getId() < 0)
			{
				throw new DataTransformsException("HTE004",true);
			}
			params = new ArrayList<>();		   	
			String nameLike = listCriteria.getNamelike();
			if(nameLike != null && nameLike.trim().length()>0)
			{
				whereClauseBuilder.append("where name like ? ");
				params.add("%"+nameLike+"%");
			}
			if(listCriteria.getId() > 0)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" transformid = ? ");
				params.add(listCriteria.getId());
			}
			if(listCriteria.getCreatedFromDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" createdate >= ? ");
				params.add(sdf.format(CommonUtil.toUTC(listCriteria.getCreatedFromDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedFromdate()!= null)
			{	
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" updatedate >= ? ");
				params.add(sdf.format(CommonUtil.toUTC(listCriteria.getUpdatedFromdate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getCreatedToDate()!= null)
			{				
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" createdate <= ? ");
				params.add(sdf.format(CommonUtil.toUTC(listCriteria.getCreatedToDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedTodate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" updatedate <= ? ");
				params.add(sdf.format(CommonUtil.toUTC(listCriteria.getUpdatedTodate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getSortby() != null && (DTWSearchCriteria.SORTBY_CREATEDDATE.equals(listCriteria.getSortby())
													|| DTWSearchCriteria.SORTBY_LASTUPDATEON.equals(listCriteria.getSortby())
													|| DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())
													|| "transformid".equals(listCriteria.getSortby())||listCriteria.getSortby().equals("createdby")))
			{
				String sortBy = CommonUtil.getOrderByColumnName(listCriteria.getSortby());
				whereClauseBuilder.append("order by "+sortBy);
				if(DTWSearchCriteria.SORT_ASC.equalsIgnoreCase(listCriteria.getSortorder()))
					whereClauseBuilder.append(" asc ");
				else
					whereClauseBuilder.append(" desc ");
			}
			String finalCountQuery = new StringBuilder().append(DataTransformsQueries.TRANSFORM_COUNT_QUERY).append(whereClauseBuilder.toString()).toString();
			totalsize = jdbcTemplate.queryForObject(finalCountQuery, params.toArray(),Integer.class);
			logger.debug("Total transforms size {}",totalsize);
			if(listCriteria.getPageno()>0&&listCriteria.getPagesize()>0)
			{
				whereClauseBuilder.append(" LIMIT ? , ?");
				params.add((listCriteria.getPageno() - 1) * listCriteria.getPagesize());
				params.add(listCriteria.getPagesize());
			}
			String finalListQuery =new StringBuilder().append(DataTransformsQueries.TRANSFORM_BY_ALL_QUERY).append(whereClauseBuilder.toString()).toString();
			logger.debug("Transform search query {}",finalListQuery);
			transformsList = jdbcTemplate.query(finalListQuery, params.toArray(), new TransformEditorRowMapper());
			if(transformsList == null)
			{
				logger.debug("Transforms are not available");
				transformsList = Collections.emptyList();
			}
			
			if(!transformsList.isEmpty())
			{
				transformsList.get(0).setTotalsize(totalsize);
			}
					
		}catch (Exception ex)
		{
			throw new DataTransformsException(ex.getMessage(),ex);
		} 
		
		return transformsList;		
	}
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getAllWorkflows()
	 */
	@Override
	public List<DTWWorkflow> getAllWorkflows() {
		List<DTWWorkflow> workflowList = jdbcTemplate.query(DataTransformsQueries.WORKFLOW_BY_ALL_QUERY+")",
														 new WorkflowRowMapper());
		if(workflowList == null){
			workflowList = Collections.emptyList();
		}
		//Begin :: Changes for workflow scheduling.
		if(!workflowList.isEmpty()){
			for(DTWWorkflow workflow:workflowList )
				workflow.setListWorkflowEditor(getWorkFlowEditor(workflow.getId()));
		}
		//End :: Changes for workflow scheduling.
		return workflowList;
	}
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getMasterWorkflows()
	 */
	@Override
	public List<DTWWorkflow> getMasterWorkflows(final long departmentId)
	{
		final List<DTWWorkflow> workflowList = jdbcTemplate.query(DataTransformsQueries.WORKFLOW_BY_SCHEDULE_QUERY,new WorkflowRowMapper(),"T",departmentId);
		if(workflowList == null)
		{
			logger.debug("No master workflows exists");
			return Collections.emptyList();
		}
		final List<DTWWorkflow> masterWorkflowList = new ArrayList<>();
		for(DTWWorkflow workflow : workflowList)
		{
			if(workflow.getMappingstep()!=null&&!workflow.getMappingstep().isEmpty())
			{
				masterWorkflowList.add(workflow);
			}
		}
		//Begin :: Changes for workflow scheduling.
		if(!workflowList.isEmpty()){
			for(DTWWorkflow workflow:masterWorkflowList)
				workflow.setListWorkflowEditor(getWorkFlowEditor(workflow.getId()));
		}
		//End :: Changes for workflow scheduling.
		return masterWorkflowList;
	}
	
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.admin.datatransforms.dao.DataTransformsDao#blockOrUnBlockWorkFlowActivities(java.lang.String, java.lang.String)
	 */
	@Override
	public Boolean blockOrUnBlockWorkFlowActivities(final String status, final String message)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_ACTIVITY_BLOCK_STATUS_UPDATE_QUERY,
				status,
				message,
				"W".equalsIgnoreCase(status)?"B":"W"
				);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	
	public List<TransformEditor> getAssociatedTransforms(final Long workflowId) throws DataTransformsException
	{
		final Map<Long,List<TransformEditor>> workflowIdMap = new ConcurrentHashMap<>();
		final List<TransformEditor> transformList = new LinkedList<>();
		try
		{
			getWorkflowTransforms(workflowId,transformList,workflowIdMap);
		} catch (Exception e)
		{
			logger.error("Failed to fetch workflow transforms ",e);
			throw new DataTransformsException("HWE005",true);
		}
		return transformList;
	}
		
		
	private void getWorkflowTransforms(final Long workflowId,List<TransformEditor> transformList,final Map<Long,List<TransformEditor>> workflowIdMap) throws DataTransformsException
	{
		if(workflowIdMap.containsKey(workflowId)&&!workflowIdMap.get(workflowId).isEmpty())
		{
			transformList.addAll(workflowIdMap.get(workflowId));
			return;
		}
		workflowIdMap.putIfAbsent(workflowId,new LinkedList<>());
		System.out.println("Going to fetch transforms for workflow --"+workflowId);
		DTWWorkflow workflow = getWorkflowById(workflowId);
		if(workflow!=null)
		{
			List<WorkflowTransforms> stepList= workflow.getMappingstep();
			if(stepList!=null&&!stepList.isEmpty())
			{
				for(WorkflowTransforms workflowStep: stepList)
				{
					String stepType =workflowStep.getType();
					if("T".equalsIgnoreCase(stepType))
					{
						TransformEditor transform = getTransformById(workflowStep.getStepId());
						if(transform!=null)
						{
							transformList.add(transform);
							workflowIdMap.get(workflowId).add(transform);
						}
					}
					else if("W".equalsIgnoreCase(stepType))
					{
						getWorkflowTransforms(workflowStep.getStepId(),transformList,workflowIdMap);
					}
				}
			}
		}
	 }
	
	public DTWWorkflow getWorkflowById(long workflowId) throws DataTransformsException
	{
		DTWWorkflow dtwWorkflow=null;
		try {
			dtwWorkflow= jdbcTemplate.queryForObject(DataTransformsQueries.WORKFLOW_BY_ID_QUERY,
					 new WorkflowRowMapper(),
					 workflowId
					 );
			dtwWorkflow.setListWorkflowEditor(getWorkFlowEditor(workflowId));
			
		} catch (Exception e) {
			throw new DataTransformsException(e.getMessage());
		}
		return dtwWorkflow;
	}
	
	@Override
	public TransformEditor getTransformById(long transformId)
	{
		return jdbcTemplate.queryForObject(DataTransformsQueries.TRANSFORM_BY_ID_QUERY,
				 new TransformEditorRowMapper(),
				 transformId
				 );
	}
	
	private void populateWorkflowStepName(final DTWWorkflow workflow) throws DataTransformsException
	{
		final List<WorkflowTransforms> mappingTransformsList = workflow.getMappingstep();
		if(mappingTransformsList!=null&&!mappingTransformsList.isEmpty())
		{
			for(WorkflowTransforms mappingTransform:mappingTransformsList)
			{
				if(mappingTransform.getType()!=null&&"T".equals(mappingTransform.getType()))
				{
					final DTWSearchCriteria searchCriteria = new DTWSearchCriteria();
					searchCriteria.setId(mappingTransform.getStepId());
					final List<TransformEditor> transformList = getTransformsForSearchCriteria(searchCriteria);
					if(transformList!=null&&!transformList.isEmpty())
					{
						mappingTransform.setName(transformList.get(0).getName());
					}
				}
				else if(mappingTransform.getType()!=null&&"W".equals(mappingTransform.getType()))
				{
					WorkflowEditor workflowEditor = getWorkFlowEditor(mappingTransform.getStepId());
					mappingTransform.setName(workflowEditor.getName());
				}
			}
		}
	}
	  
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getWorkflowsForSearchCriteria(DTWSearchCriteria)
	 */
	public List<DTWWorkflow> getWorkflowsForSearchCriteria(DTWSearchCriteria listCriteria) throws DataTransformsException
	{ 
		
		List<DTWWorkflow> workflowEditorlists=null;
		String joinClause="";
		int totalsize = 0;
		final StringBuilder whereClauseBuilder = new StringBuilder();
		final DateFormat writeFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
		List<Object> params=new ArrayList<>();
		try
		{ 
			if(listCriteria == null){				 
				logger.debug("No Workflows exists for search criteria, so returning all workflows ");
				return getAllWorkflows();
			}
			if(listCriteria.getId() < 0){
				throw new DataTransformsException("HWE005",true);
			}
					   	
			if(listCriteria.getId() > 0){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.workflowid = ? ");
				params.add(listCriteria.getId());
				whereClauseBuilder.append(" ");
			}
			/*String nameLike = listCriteria.getNamelike();
			if(nameLike != null && nameLike.trim().length()>0){
				//name column in json value in data base table
				List<DTWWorkflow> workflows = getAllWorkflows();
				workflowEditorlists = new ArrayList<>();
				for(DTWWorkflow workflow: workflows){
					if(workflow.getListWorkflowEditor()!=null&&workflow.getListWorkflowEditor().getName()!=null
							&&workflow.getListWorkflowEditor().getName().toLowerCase().contains(nameLike.trim().toLowerCase()) && workflow.getDepartmentId().equals(listCriteria.getDepartmentId())){
						populateWorkflowStepName(workflow);
						workflowEditorlists.add(workflow);
					}
				}
				return workflowEditorlists;
			}*/
			if(listCriteria.getCreatedFromDate()!= null){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.createdate >= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedFromDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedFromdate()!= null){	
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				whereClauseBuilder.append(" w.updatedate >= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getUpdatedFromdate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getCreatedToDate()!= null){				
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.createdate <= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedToDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedTodate()!= null){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.updatedate <= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getUpdatedTodate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getDepartmentId()!= null)
			{
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.departmentid = ? ");
				params.add(listCriteria.getDepartmentId());
			}
			
			if(listCriteria.getSortby() != null && (DTWSearchCriteria.SORTBY_CREATEDDATE.equals(listCriteria.getSortby())
													|| "createdby".equals(listCriteria.getSortby())
													|| DTWSearchCriteria.SORTBY_LASTUPDATEON.equals(listCriteria.getSortby())
													|| DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())
													|| "workflowid".equals(listCriteria.getSortby().toLowerCase())))
			{
				String sort=CommonUtil.getOrderByColumnName(listCriteria.getSortby());
				if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
					joinClause=" left outer join DTW_WORKFLOWSCHEDULE ws on w.workflowid = ws.workflowid ) ";
				}else{
					joinClause=" ) ";
				}
				String nameLike = listCriteria.getNamelike();
				if(nameLike != null && nameLike.trim().length()>0 && joinClause.equals(" ) ")){
					joinClause = " left outer join DTW_WORKFLOWSCHEDULE ws on w.workflowid = ws.workflowid ) ";
					whereClauseBuilder.append(" and ws.name like '%"+nameLike+"%' ");
				}
				if(DTWSearchCriteria.SORT_ASC.equalsIgnoreCase(listCriteria.getSortorder())){
					whereClauseBuilder.append(" order by ");
					if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
						whereClauseBuilder.append("ws.");
					}else{
						whereClauseBuilder.append("w.");
					}
					whereClauseBuilder.append(sort);
					whereClauseBuilder.append(" asc ");
					
				} else{
					whereClauseBuilder.append(" order by ");
					if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
						whereClauseBuilder.append("ws.");
					}else{
						whereClauseBuilder.append("w.");
					}
					whereClauseBuilder.append(sort);
					whereClauseBuilder.append(" desc ");
				}
			}
			String baseQuery=new StringBuilder().append(DataTransformsQueries.WORKFLOW_COUNT_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			logger.debug("Count query :: "+baseQuery);
			totalsize = jdbcTemplate.queryForObject(baseQuery,params.toArray(), Integer.class);
			logger.debug("Total number of workflows {}",totalsize);
			if(listCriteria.getPageno()>0&&listCriteria.getPagesize()>0)
			{
				whereClauseBuilder.append(" LIMIT ");
				whereClauseBuilder.append((listCriteria.getPageno() - 1) * listCriteria.getPagesize());
				whereClauseBuilder.append(",");
				whereClauseBuilder.append(listCriteria.getPagesize());
			}
			baseQuery=new StringBuilder().append(DataTransformsQueries.WORKFLOW_BY_ALL_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			logger.debug("DTW workflows search query {} "+baseQuery);
			
			workflowEditorlists = jdbcTemplate.query(baseQuery,params.toArray(), new WorkflowRowMapper());
			if(workflowEditorlists == null){
				logger.debug("Workflows not exists for search criteria");
				workflowEditorlists = Collections.emptyList();
			}
			
			//Begin :: Changes for workflow scheduling.
			if(!workflowEditorlists.isEmpty()){
				for(DTWWorkflow workflow:workflowEditorlists )
					workflow.setListWorkflowEditor(getWorkFlowEditor(workflow.getId()));
			}
			//End :: Changes for workflow scheduling.
			
			if(!workflowEditorlists.isEmpty())
			{
				workflowEditorlists.get(0).setTotalsize(totalsize);
				for(DTWWorkflow workflow:workflowEditorlists )
				{
					List<WorkflowActivity> wfActivityList = getWorkflowActivity(workflow.getId());
					if(!wfActivityList.isEmpty())
					{
						workflow.setActivity(true);
					}
					populateWorkflowStepName(workflow);
				}
			}
		}catch (Exception ex)
		{
			throw new DataTransformsException(ex.getMessage(),ex);
		} 
		
		return workflowEditorlists;		
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getWorkflowTriggers
	 * (java.lang.Long, java.lang.Long)
	 */
	@Override
	public List<WorkflowTrigger> getWorkflowTriggers(final Long workflowId, final Long fileDefId)
	{
		List<WorkflowTrigger> workflowTriggerList = jdbcTemplate.query(DataTransformsQueries.WORKFLOW_TRIGGER_BY_ID_QUERY,
													new WorkflowTriggerRowMapper(),workflowId,fileDefId);
		if(workflowTriggerList == null)
		{
			logger.debug("Workflow triggers not exists ");
			workflowTriggerList = Collections.emptyList();
		}
		return workflowTriggerList;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getWorkflowActivity(java.lang.Long)
	 */
	@Override
	public List<WorkflowActivity> getWorkflowActivity(final Long workflowId)
	{
		List<WorkflowActivity> workflowActivityList = jdbcTemplate.query(DataTransformsQueries.WORKFLOW_ACTIVITY_BY_ID_QUERY,
														new WorkflowActivityRowMapper(),workflowId);
		if(workflowActivityList == null)
		{
			logger.debug("Workflow activities for worflow id {}",workflowId);
			workflowActivityList = Collections.emptyList();
		}
		if(!workflowActivityList.isEmpty()){
			WorkflowEditor workflowEditor = getWorkFlowEditor(workflowId);
			for(WorkflowActivity wa: workflowActivityList){
				wa.setHubListworkflowEditor(workflowEditor);
			}
		}
		return workflowActivityList;
	}
	
	@Override
	public Long getIsUsedInList(final Long workflowId) throws DataTransformsException
	{
		Long count = 0L;
		try{
	 count = jdbcTemplate.queryForObject(DataTransformsQueries.WORKFLOW_COUNT_BY_ID_QUERY, Long.class,new Object []{workflowId});
		}catch(EmptyResultDataAccessException e){
			logger.debug(" No records found with workflowId:"+workflowId);
		}catch (Exception ex){
		throw new DataTransformsException(ex.getMessage(),ex);
	   } 
		return count;
	}
	
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getWorkflowActivityForSearchCriteria(DTWSearchCriteria)
	 */
	public List<WorkflowActivity> getWorkflowActivityForSearchCriteria(DTWSearchCriteria listCriteria) throws DataTransformsException
	{ 
		List<Object> params = new ArrayList<>();
		List<WorkflowActivity> workflowActivityList=null;
		int totalsize = 0;
		final StringBuilder whereClauseBuilder = new StringBuilder();
		String joinClause = "";
		final DateFormat writeFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
		try{ 
			
			if(listCriteria == null)
			{				 
				listCriteria=new DTWSearchCriteria(); //No search criteria
			}
			if(listCriteria.getId() < 0)
			{
				throw new DataTransformsException("HWA001",true);
			}
			Long departmentId = listCriteria.getDepartmentId();		   	
			/*String nameLike = listCriteria.getNamelike();
			if(nameLike != null && nameLike.trim().length()>0)
			{
				
				workflowActivityList = new ArrayList<>();
				final List<DTWWorkflow> workflows = getAllWorkflows();
				for(DTWWorkflow workflow: workflows)
				{
					if(workflow.getListWorkflowEditor()!=null&&workflow.getListWorkflowEditor().getName()!=null
							&&workflow.getListWorkflowEditor().getName().toLowerCase().contains(nameLike.trim().toLowerCase()))
					{
						if(departmentId!=null&&departmentId>0&&
								workflow.getDepartmentId()!=null &&
								departmentId!=workflow.getDepartmentId())//Department is exists
						{
							continue; //Logged in User department is not workflow department.
						}
						workflowActivityList.addAll(getWorkflowActivity(workflow.getId()));
					}
				}
				
				
				return workflowActivityList;
				
				
			}*/
			if(listCriteria.getId() > 0)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				params.add(listCriteria.getId());
				whereClauseBuilder.append(" wa.workflowactivityid =? ");
			}
			char status = listCriteria.getStatus();
			if(status != ' ')
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.status =? ");
				params.add(String.valueOf(status));
			}
			if(listCriteria.getCreatedFromDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.createdate >=? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedFromDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedFromdate()!= null)
			{	
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.updatedate >=? ");
				params.add(CommonUtil.toUTC(listCriteria.getUpdatedFromdate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			}
			
			if(listCriteria.getCreatedToDate()!= null)
			{				
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.createdate <=? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedToDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedTodate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.updatedate <=? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getUpdatedTodate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getStartedFromDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.startedOn >=? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getStartedFromDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getStartedToDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.startedOn <=?");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getStartedToDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getCompletedFromDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.completedOn >=? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCompletedFromDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));	
			}
			
			if(listCriteria.getCompletedToDate()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.completedOn <=?");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCompletedToDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getWorkflowId() > 0)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.workflowId =?");
				params.add(listCriteria.getWorkflowId());
			}
			
			if(listCriteria.getStartedOn()!= null)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				whereClauseBuilder.append(" wa.startedOn =? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getStartedOn().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(departmentId!=null&&departmentId>0)
			{
				if(whereClauseBuilder.length()>0)
				{
					whereClauseBuilder.append(" and ");
				}
				else
				{
					whereClauseBuilder.append(" where ");
				}
				joinClause = " inner join DTW_WORKFLOW w on wa.workflowid=w.workflowid )"; 
				whereClauseBuilder.append(" w.departmentid=? ");
				params.add(departmentId);
			}
			if(listCriteria.getSortby() != null && (DTWSearchCriteria.SORTBY_CREATEDDATE.equals(listCriteria.getSortby())
					|| DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())
					|| "createdby".equals(listCriteria.getSortby())
					|| DTWSearchCriteria.SORTBY_STARTEDON.equals(listCriteria.getSortby())
					|| DTWSearchCriteria.SORTBY_COMPLETEDON.equals(listCriteria.getSortby())
					|| DTWSearchCriteria.SORTBY_STATUS.equals(listCriteria.getSortby())
					|| "workflowactivityid".equals(listCriteria.getSortby())
					))
			{
				String sortBy = CommonUtil.getOrderByColumnName(listCriteria.getSortby());
				if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
					joinClause=joinClause+" left outer join DTW_WORKFLOWSCHEDULE ws on wa.workflowid = ws.workflowid )";
				}else{
					if ("".equals(joinClause.trim()))
						joinClause=joinClause+" )) ";
					else
						joinClause=joinClause+" )";
				}
				String nameLike = listCriteria.getNamelike();
				if(nameLike != null && nameLike.trim().length()>0 && !joinClause.contains("DTW_WORKFLOWSCHEDULE")){
					joinClause=joinClause+" left outer join DTW_WORKFLOWSCHEDULE ws on wa.workflowid = ws.workflowid ";
					whereClauseBuilder.append(" and ws.name like '%"+nameLike+"%' ");
				}
				if(DTWSearchCriteria.SORT_ASC.equalsIgnoreCase(listCriteria.getSortorder()))
				{
				whereClauseBuilder.append(" order by ");
					if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
						whereClauseBuilder.append("ws."+sortBy);
					}else{
						whereClauseBuilder.append("wa."+sortBy);
					}
				whereClauseBuilder.append(" asc ");
				
				} else
				{
				whereClauseBuilder.append(" order by ");
					if(DTWSearchCriteria.SORTBY_NAME.equals(listCriteria.getSortby())){
						whereClauseBuilder.append("ws."+sortBy);
					}else{
						whereClauseBuilder.append("wa."+sortBy);
					}
				whereClauseBuilder.append(" desc ");
				}
			}
			String finalCountQuery = new StringBuilder().append(DataTransformsQueries.WORKFLOW_ACTIVITY_COUNT_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			totalsize = jdbcTemplate.queryForObject(finalCountQuery, Integer.class,params.toArray());
			logger.debug("Total number of workflow activities {}",totalsize);
			if(listCriteria.getPageno()>0&&listCriteria.getPagesize()>0)
			{
				whereClauseBuilder.append(" LIMIT ?,? ");
				params.add((listCriteria.getPageno() - 1) * listCriteria.getPagesize());
				params.add(listCriteria.getPagesize());
			}
			String finalListQuery = new StringBuilder().append(DataTransformsQueries.WORKFLOW_ACTIVITY_ALL_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			logger.debug("Workflow activity search query {}",finalListQuery);
			workflowActivityList = jdbcTemplate.query(finalListQuery, new WorkflowActivityRowMapper(), params.toArray());
			if(workflowActivityList == null)
			{
				workflowActivityList = Collections.emptyList();
			}
			
			if(!workflowActivityList.isEmpty())
			{
				workflowActivityList.get(0).setTotalsize(totalsize); //Total workflow activity count for UI grid
				Iterator<WorkflowActivity> workflowActivityItr=workflowActivityList.iterator();
				while(workflowActivityItr.hasNext())
				{
					WorkflowActivity wfActivity =  workflowActivityItr.next();
					final DTWWorkflow workflow = getWorkflowById(wfActivity.getWorkflowId());
					if(workflow!=null)
					{
						wfActivity.setHubListworkflowEditor(workflow.getListWorkflowEditor());
					}
				}
			}
		}catch (Exception ex){
			logger.error("Exception in search workflow activity {}",ex.getMessage(),ex);
			if(ex.getMessage() != null && ex.getMessage().contains("Could not get JDBC Connection"))
				throw new DataTransformsException("AU0079",true);
			else
				throw new DataTransformsException(ex.getMessage(),ex);
		} 
		
		return workflowActivityList;		
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getWorkflowWithActivities
	 * (java.lang.Long, java.lang.Long)
	 */
	public  DTWWorkflow getWorkflowWithActivities(long workflowId,long activityId) throws DataTransformsException
	{
		DTWWorkflow workflowEditorObj = null;
		try
		{
			logger.debug("Workflow which has activities for workflow id {}",workflowId);
			if(workflowId<=0)
			{
				throw new DataTransformsException("HWE005",true);
			}
			final DTWSearchCriteria listCriteria = new DTWSearchCriteria();
			listCriteria.setId(workflowId);
			final List<DTWWorkflow> workflows = getWorkflowsForSearchCriteria(listCriteria);
			if(workflows!=null&&!workflows.isEmpty())
			{
				workflowEditorObj = workflows.get(0);
			}
			if(workflowEditorObj==null)
			{
				throw new DataTransformsException("HWE006",true);
			}
			List<WorkflowTransforms> mappingTransformsList = workflowEditorObj.getMappingstep();
			workflowEditorObj.setListTransformActivities(new ArrayList<TransformActivity>());
			if(mappingTransformsList!=null&&!mappingTransformsList.isEmpty())
			{
				for(WorkflowTransforms mappingTransform: mappingTransformsList)
				{
					if("T".equals(mappingTransform.getType()))
					{
						List<TransformActivity> activityTransforms = jdbcTemplate.query(DataTransformsQueries.TRNSFORM_BY_ACTIVITY_QUERY,
								new TransformActivityRowMapper(),
								mappingTransform.getStepId(),
								activityId
								);
						workflowEditorObj.getListTransformActivities().addAll(activityTransforms);
					}
				}
			}
		}			
		catch (Exception ex)
		{
			logger.error("Exception in workflow for activities {} ", ex.getMessage(),ex);
			throw new DataTransformsException("E00002",true);
		} 
		return workflowEditorObj;
	}
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getTransformActivity
	 * (java.lang.Long, java.lang.Long)
	 */
	@Override
	public List<TransformActivity> getTransformActivity(final Long workflowActivityId, final Long transformId)
	{
		List<TransformActivity> transformActivityList = jdbcTemplate.query(DataTransformsQueries.TRANSFORM_ACTIVITY_BY_ID_TRANSFORM_ID_QUERY,
														new TransformActivityRowMapper(),workflowActivityId,transformId);
		if(transformActivityList == null)
		{
			logger.debug("Transform activities not exists for workflow activity id {} and transform id {}",workflowActivityId,transformId);
			transformActivityList = Collections.emptyList();
		}
		return transformActivityList;
	}
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#getTransformActivity
	 * (java.lang.Long)
	 */
	@Override
	public List<TransformActivity> getTransformActivity(final Long workflowActivityId)
	{
		List<TransformActivity> transformActivityList = jdbcTemplate.query(DataTransformsQueries.TRANSFORM_ACTIVITY_BY_ID_QUERY,
														new TransformActivityRowMapper(),workflowActivityId);
		if(transformActivityList == null)
		{
			logger.debug("Transform activities not exists for workflow activity id {}",workflowActivityId);
			transformActivityList = Collections.emptyList();
		}
		return transformActivityList;
	}
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#saveTransform
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.TransformEditor)
	 */
	@Override
	public Long saveTransform(final TransformEditor transform)
	{
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
		{
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException
			{
				PreparedStatement pstmt = con.prepareStatement(DataTransformsQueries.TRANSFORM_INSERT_QUERY,
															   Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, transform.getName());
				pstmt.setString(2, String.valueOf(transform.getUsetransaction()));
				pstmt.setString(3, transform.getTransform());
				pstmt.setString(4, transform.getCreatedby());
				pstmt.setString(5, StringUtils.isNotBlank(transform.getUpdatedby())?transform.getUpdatedby().trim():transform.getCreatedby());
				
				return pstmt;
			}
		};
		jdbcTemplate.update(pstmtCreator,keyHolder);
		return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
	}
	
	
	
	@Override
	public boolean checkTransformNameExists(TransformEditor transform) throws DataTransformsException {
		boolean isExist = false;
		String sqlQuery = null;
		Long recordCount = Long.valueOf(0l);
		if(transform.getId() == null || transform.getId() == 0){
			sqlQuery = "select count(name) from DTW_TRANSFORM where name = ?";
			recordCount = jdbcTemplate.queryForObject(sqlQuery, Long.class, transform.getName());
		}else{
			sqlQuery = "select count(name) from DTW_TRANSFORM where name = ? and transformid != ?";
			recordCount = jdbcTemplate.queryForObject(sqlQuery, Long.class, transform.getName(),transform.getId());
		}
		if(recordCount > 0)
			isExist = true;
		
		return isExist;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#saveWorkflow
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.Workflow)
	 */
	@Override
	public Long saveWorkflow(final DTWWorkflow workflow) throws DataTransformsException
	{
		Long workFlowId;
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
		{
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException
			{
				String workflowEditor = null;
				String mappingTransform = null;
				final ObjectMapper mapper = new ObjectMapper();
				try
				{
					mapper.addMixIn(WorkflowTransforms.class, NameMixIn.class);
					mapper.addMixIn(WorkflowEditor.class, RunmodeMixIn.class);
					workflowEditor = mapper.writeValueAsString(workflow.getListWorkflowEditor());
					mappingTransform = mapper.writeValueAsString(workflow.getMappingstep());
					
				} catch (JsonProcessingException e)
				{
					logger.error("Json parsing exception while saving workflow");
				}
				PreparedStatement pstmt = con.prepareStatement(DataTransformsQueries.WORKFLOW_INSERT_QUERY,
															   Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, mappingTransform);
				pstmt.setString(2, workflow.getCreatedby());
				pstmt.setString(3, StringUtils.isNotBlank(workflow.getUpdatedby())?workflow.getUpdatedby().trim():workflow.getCreatedby());
			
				pstmt.setString(4, workflow.getSchedule());
				pstmt.setLong(5, workflow.getDepartmentId());
				return pstmt;
			}
		};
		jdbcTemplate.update(pstmtCreator,keyHolder);
		//Begin :: Changes for workflow scheduling.
		workFlowId=keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
		WorkflowEditor workFlowEditor=workflow.getListWorkflowEditor();
		workFlowEditor.setWorkFlowId(workFlowId);
		saveWorkFlowEditor(workFlowEditor);
		//End :: Changes for workflow scheduling.
		return workFlowId;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#saveWorkflowTrigger
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowTrigger)
	 */
	@Override
	public Long saveWorkflowTrigger(final WorkflowTrigger workflowTrigger)
	{
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
		{
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException
			{
				PreparedStatement pstmt = con.prepareStatement(DataTransformsQueries.WORKFLOW_TRIGGER_INSERT_QUERY,
															   Statement.RETURN_GENERATED_KEYS);
				pstmt.setLong(1, workflowTrigger.getWorkflowId());
				pstmt.setLong(2, workflowTrigger.getFileDefinitionId());
				pstmt.setString(3, workflowTrigger.getCreatedby());
				
				return pstmt;
			}
		};
		jdbcTemplate.update(pstmtCreator,keyHolder);
		
		return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#saveWorkflowActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowActivity)
	 */
	@Override
	public Long saveWorkflowActivity(final WorkflowActivity workflowActivity) throws DataTransformsException
	{
		String timezone = getWorkflowTimezone(workflowActivity.getWorkflowId());
		
		if(StringUtils.isBlank(timezone))
		{
			throw new DataTransformsException("Unable to fetch timezone for workflow") ;
		}
		StringBuilder query=new StringBuilder("insert into DTW_WORKFLOWACTIVITY(WorkflowId,Status,Message,BatchIds,CreatedBy,createdate,updatedate");
		StringBuilder values = new StringBuilder("values (?,?,?,?,?,utc_timestamp(),utc_timestamp()");
		if (workflowActivity.getStartedOn() != null){
			query.append(",StartedOn");
			values.append(",utc_timestamp()");
		}
		if (workflowActivity.getStatus() == 'C' || workflowActivity.getStatus() == 'E'){
			query.append(",CompletedOn");
			values.append(",utc_timestamp()");
		}
		query.append(") ").append(values.toString()).append(")"); 
		
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
		{
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException
			{
				PreparedStatement pstmt = con.prepareStatement(query.toString(),
															   Statement.RETURN_GENERATED_KEYS);
				logger.info("   Batch ids ::   "+workflowActivity.getBatchids());
				pstmt.setLong(1, workflowActivity.getWorkflowId());
				pstmt.setString(2, String.valueOf(workflowActivity.getStatus()));
				pstmt.setString(3, workflowActivity.getMessage());
				pstmt.setString(4, workflowActivity.getBatchids());
				pstmt.setString(5, workflowActivity.getCreatedby());
				return pstmt;
			}
		};
		jdbcTemplate.update(pstmtCreator,keyHolder);
		return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#saveTransformActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.TransformActivity)
	 */
	@Override
	public Long saveTransformActivity(final TransformActivity transformActivity) throws DataTransformsException
	{
		
		DTWSearchCriteria criteria = new DTWSearchCriteria();
		criteria.setId(transformActivity.getWorkflowactivityid());
		String timezone = null;
		try
		{
			Long workflowid = getWorkflowActivityForSearchCriteria(criteria).get(0).getWorkflowId();
			timezone = getWorkflowTimezone(workflowid);
			
		} catch (Exception e1)
		{
			logger.error("unable to fetch workflowactivity for activity {}",transformActivity.getWorkflowactivityid());
		}
		
		
		if(StringUtils.isBlank(timezone))
		{
			throw new DataTransformsException("Unable to fetch timezone for workflow") ;
		}
		final String timeZone = timezone;
		final KeyHolder keyHolder = new GeneratedKeyHolder();
		final PreparedStatementCreator pstmtCreator = new PreparedStatementCreator()
		{
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException
			{
				PreparedStatement pstmt = con.prepareStatement(DataTransformsQueries.TRANSFORM_ACTIVITY_INSERT_QUERY,
															   Statement.RETURN_GENERATED_KEYS);
				pstmt.setLong(1, transformActivity.getWorkflowactivityid());
				pstmt.setLong(2, transformActivity.getTransformid());
				pstmt.setString(3, String.valueOf(transformActivity.getStatus()));
				pstmt.setString(4, transformActivity.getMessage());
				try {
					pstmt.setString(5, transformActivity.getStartedOn()!=null?sdf.format(CommonUtil.toUTC(transformActivity.getStartedOn().getTime(),TimeZone.getTimeZone(timeZone))):null);
					pstmt.setString(6, transformActivity.getCompletedOn()!=null?sdf.format(CommonUtil.toUTC(transformActivity.getCompletedOn().getTime(),TimeZone.getTimeZone(timeZone))):null);
				} catch (Exception e) {
					e.printStackTrace();
				}
				pstmt.setString(7, transformActivity.getCreatedby());
				
				return pstmt;
			}
		};
		jdbcTemplate.update(pstmtCreator,keyHolder);
		return keyHolder.getKey()!=null?keyHolder.getKey().longValue():0L;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#updateTransform
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.TransformEditor)
	 */
	@Override
	public Boolean updateTransform(final TransformEditor transform)
	{
	 int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.TRANSFORM_UPDATE_QUERY,
									transform.getName(),
									String.valueOf(transform.getUsetransaction()),
									transform.getTransform(),
									transform.getUpdatedby(),
									transform.getId()
									);
	 return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#updateWorkflow
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.Workflow)
	 */
	@Override
	public Boolean updateWorkflow(final DTWWorkflow workflow) throws DataTransformsException
	{
		String mappingTransform = null;
		final ObjectMapper mapper = new ObjectMapper();
		try
		{
			mapper.addMixIn(WorkflowTransforms.class, NameMixIn.class);
			mapper.addMixIn(WorkflowEditor.class, RunmodeMixIn.class);
			mappingTransform = mapper.writeValueAsString(workflow.getMappingstep());
		} catch (JsonProcessingException e)
		{
			throw new DataTransformsException("E00006",true);
		}
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_UPDATE_QUERY,
							mappingTransform,
							workflow.getUpdatedby(),
							workflow.getSchedule(),
							workflow.getDepartmentId(),
							workflow.getId()
						   );
		
		//Begin :: Changes for workflow scheduling.
		updateWorkFlowEditor(workflow.getListWorkflowEditor());
		//End :: Changes for workflow scheduling.
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#updateWorkflowTrigger
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowTrigger)
	 */
	@Override
	public Boolean updateWorkflowTrigger(final WorkflowTrigger workflowTrigger)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_TRIGGER_UPDATE_QUERY,
										workflowTrigger.getWorkflowId(),
										workflowTrigger.getFileDefinitionId(),
										workflowTrigger.getUpdatedby(),
										workflowTrigger.getId()
										);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	private String getWorkflowTimezone(Long workflowId)
	{
		String timezone = null;
		try
		{
			DTWWorkflow workflow = getWorkflowById(workflowId);
			if(workflow.getListWorkflowEditor().getRunmode()=='T')
			{
				timezone = "UTC";
			}
			else
			{
				timezone = workflow.getListWorkflowEditor().getTimezone();
			}
			
		} catch (Exception e1) 
		{
			logger.error("Failed to fetch workflow for id {}",workflowId);
		}
		return timezone;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#updateWorkflowActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowActivity)
	 */
	@Override
	public Boolean updateWorkflowActivity(final WorkflowActivity workflowActivity)
	{
		
		
		String timezone = getWorkflowTimezone(workflowActivity.getWorkflowId());
		
		if(StringUtils.isBlank(timezone))
		{
			return Boolean.FALSE;
		}
		StringBuilder query=new StringBuilder("update DTW_WORKFLOWACTIVITY set WorkflowId=?,Status=?,Message=?,BatchIds=?,UpdatedBy=?,updatedate=utc_timestamp()");
		
		if (workflowActivity.getStatus() == 'I'){
			query.append(",StartedOn=utc_timestamp() ");
		}else if(workflowActivity.getStatus() =='E' ||workflowActivity.getStatus() =='C'){
			query.append(",CompletedOn=utc_timestamp() ");
		}
		
		query.append(" where WorkflowActivityId=? ");
		
		int rowsUpdated=0;
		try {
			rowsUpdated = jdbcTemplate.update(query.toString(),
											workflowActivity.getWorkflowId(),
											String.valueOf(workflowActivity.getStatus()),
											workflowActivity.getMessage(),
											workflowActivity.getBatchids(),
											workflowActivity.getUpdatedby(),
											workflowActivity.getId()
											);
		} catch ( Exception e) {
			logger.error(e.getMessage(),e);
		} 
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#updateTransformActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.TransformActivity)
	 */
	@Override
	public Boolean updateTransformActivity(final TransformActivity transformActivity) throws DataTransformsException
	{
		DTWSearchCriteria criteria = new DTWSearchCriteria();
		criteria.setId(transformActivity.getWorkflowactivityid());
		String timezone = null;
		try
		{
			Long workflowid = getWorkflowActivityForSearchCriteria(criteria).get(0).getWorkflowId();
			timezone = getWorkflowTimezone(workflowid);
			
		} catch (Exception e1)
		{
			logger.error("unable to fetch workflowactivity for activity {}",transformActivity.getWorkflowactivityid());
		}
		
		
		if(StringUtils.isBlank(timezone))
		{
			throw new DataTransformsException("Unable to fetch timezone for workflow") ;
		}
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.TRANSFORM_ACTIVITY_UPDATE_QUERY,
										transformActivity.getWorkflowactivityid(),
										transformActivity.getTransformid(),
										String.valueOf(transformActivity.getStatus()),
										transformActivity.getMessage(),
										transformActivity.getStartedOn()!=null?sdf.format(CommonUtil.toUTC(transformActivity.getStartedOn().getTime(),TimeZone.getTimeZone(timezone))):null,
										transformActivity.getCompletedOn()!=null?sdf.format(CommonUtil.toUTC(transformActivity.getCompletedOn().getTime(),TimeZone.getTimeZone(timezone))):null,
										transformActivity.getUpdatedby(),
										transformActivity.getId()
										);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#restartWorkflowActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowActivity)
	 */
	@Override
	public Boolean restartWorkflowActivity(final WorkflowActivity workflowActivity) {
		
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_ACTIVITY_RESTART_QUERY,
				String.valueOf(Constants.ACTIVITY_RETRY),
				workflowActivity.getUpdatedby(),
				workflowActivity.getId(),
				String.valueOf(Constants.ACTIVITY_ERRORED)
				);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#cancelWorkflowActivity
	 * (com.zetainteractive.zetahub.conversations.admin.datatransforms.bo.WorkflowActivity)
	 */
	@Override
	public Boolean cancelWorkflowActivity(final WorkflowActivity workflowActivity) {
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_ACTIVITY_RESTART_QUERY,
											  String.valueOf(Constants.ACTIVITY_STOPPED),
											  workflowActivity.getUpdatedby(),
											  workflowActivity.getId(),
											  String.valueOf(workflowActivity.getStatus())
											 );
		if(rowsUpdated>0)
		{
			jdbcTemplate.update(DataTransformsQueries.WORKFLOW_ACTIVITY_CANCEL_QUERY,
											  String.valueOf(Constants.ACTIVITY_WAITING),
											  workflowActivity.getUpdatedby(),
											  String.valueOf(Constants.ACTIVITY_BLOCKED)
											 );
		}
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#deleteTransform(java.lang.Long)
	 */
	@Override
	public Boolean deleteTransform(final Long transformId)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.TRANSFORM_DELETE_QUERY,transformId);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#deleteWorkflow(java.lang.Long)
	 */
	@Override
	public Boolean deleteWorkflow(final Long workflowId)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_DELETE_QUERY,workflowId);
		//Begin :: Changes for workflow scheduling.
		deleteWorkFlowEditor(workflowId);
		//End :: Changes for workflow scheduling.
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#deleteWorkflowTrigger(java.lang.Long)
	 */
	@Override
	public Boolean deleteWorkflowTrigger(final Long workflowTriggerId)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_TRIGGER_DELETE_QUERY,workflowTriggerId);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#deleteWorkflowActivity(java.lang.Long)
	 */
	@Override
	public Boolean deleteWorkflowActivity(final Long workflowActivityId)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.WORKFLOW_ACTIVITY_DELETE_QUERY,workflowActivityId);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.zetahub.conversations.admin.datatransforms.dao.DataTransformsDao#deleteTransformActivity(java.lang.Long)
	 */
	@Override
	public Boolean deleteTransformActivity(final Long transformActivityId)
	{
		int rowsUpdated = jdbcTemplate.update(DataTransformsQueries.TRANSFORM_ACTIVITY_DELETE_QUERY,transformActivityId);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	public Boolean updateWorkFlowEditor(WorkflowEditor workFlowEditor){
		String updateQuery = "update DTW_WORKFLOWSCHEDULE set workflowid=?,name=?,schedulesetting=?,enablemode=?,"
				+ " runmode=?,frequency=?,timezone=?,schedulestartdate=?,scheduleenddate=?,schedulenextdue=?,frequencyunit=?,"
				+ " includedays=?,monthlyschdfreq=?,monthlyweekfreq=?,monthlydayfreq=?,dayofeverymonth=?,status=?,updatedby=?,updatedate = UTC_TIMESTAMP"
				+ " where workflowscheduleid=?";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		int rowsUpdated = jdbcTemplate.update(new PreparedStatementCreator() {
							@Override
							public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
								PreparedStatement ps = con.prepareStatement(updateQuery,Statement.RETURN_GENERATED_KEYS);
								ps.setLong(1, workFlowEditor.getWorkFlowId());
								ps.setString(2,workFlowEditor.getName());
								ps.setString(3,workFlowEditor.getSchedulesetting() != null ? workFlowEditor.getSchedulesetting() + "" : null);
								ps.setString(4,workFlowEditor.getEnablemode() != null ? workFlowEditor.getEnablemode() + "" : null);
								ps.setString(5,workFlowEditor.getRunmode() != null ? workFlowEditor.getRunmode() + "" : null);
								ps.setString(6,workFlowEditor.getFrequency() != null ? workFlowEditor.getFrequency() + "" : null);
								ps.setString(7,workFlowEditor.getTimezone());
							
								ps.setString(8,(workFlowEditor.getScheduleStartDate() != null)?(sdf.format(workFlowEditor.getScheduleStartDate())) : null);
								ps.setString(9,(workFlowEditor.getScheduleEndDate() != null)?(sdf.format(workFlowEditor.getScheduleEndDate())) : null);
								ps.setString(10,(workFlowEditor.getSchedulenextdue() != null)?(sdf.format(workFlowEditor.getSchedulenextdue())) : null);	
								
								ps.setLong(11,(workFlowEditor.getFrquencyunit() != null) ? workFlowEditor.getFrquencyunit() : 0);
								ps.setLong(12,(workFlowEditor.getIncludedays() != null) ? workFlowEditor.getIncludedays() : 0);
								ps.setString(13,(workFlowEditor.getMonthlyschdfreq() != null)? workFlowEditor.getMonthlyschdfreq() + "" : null);
								ps.setString(14,(workFlowEditor.getMonthlyWeekFreq() != null)? workFlowEditor.getMonthlyWeekFreq() + "" : null);
								ps.setString(15,(workFlowEditor.getMonthlyDayFreq() != null)? workFlowEditor.getMonthlyDayFreq() + "" : null);
								ps.setLong(16,(workFlowEditor.getDayofeverymonth() != null)? workFlowEditor.getDayofeverymonth() : 0);
								ps.setString(17,workFlowEditor.getStatus() != null ? workFlowEditor.getStatus() + "" : null);
								ps.setString(18,workFlowEditor.getUpdatedBy());
								ps.setLong(19,workFlowEditor.getWorkFlowScheduleId());
								return ps;
							}
						  },keyHolder);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	
	public boolean updateWorkFlowEditorStatus(long scheduleId,char status){
		String updateQuery = "update DTW_WORKFLOWSCHEDULE set status=?, updatedate = UTC_TIMESTAMP where workflowscheduleid=?";
		int rowsUpdated = jdbcTemplate.update(new PreparedStatementCreator() {
							@Override
							public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
								PreparedStatement ps = con.prepareStatement(updateQuery,Statement.RETURN_GENERATED_KEYS);
								ps.setString(1,status+"");
								ps.setLong(2,scheduleId);
								return ps;
							}
						  });
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	private Long saveWorkFlowEditor(WorkflowEditor workFlowEditor){
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String inserQuery = "insert into DTW_WORKFLOWSCHEDULE(workflowid,name,schedulesetting,enablemode,"
				+ " runmode,frequency,timezone,schedulestartdate,scheduleenddate,schedulenextdue,frequencyunit,"
				+ " includedays,monthlyschdfreq,monthlyweekfreq,monthlydayfreq,dayofeverymonth,status,createdby,updatedby,createdate,updatedate)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())";
		jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(inserQuery,Statement.RETURN_GENERATED_KEYS);
					ps.setLong(1, workFlowEditor.getWorkFlowId());
					ps.setString(2,workFlowEditor.getName());
					ps.setString(3,workFlowEditor.getSchedulesetting() != null ? workFlowEditor.getSchedulesetting() + "" : null);
					ps.setString(4,workFlowEditor.getEnablemode() != null ? workFlowEditor.getEnablemode() + "" : null);
					ps.setString(5,workFlowEditor.getRunmode() != null ? workFlowEditor.getRunmode() + "" : null);
					ps.setString(6,workFlowEditor.getFrequency() != null ? workFlowEditor.getFrequency() + "" : null);
					ps.setString(7,workFlowEditor.getTimezone());
					ps.setString(8,(workFlowEditor.getScheduleStartDate() != null)?(sdf.format(workFlowEditor.getScheduleStartDate())) : null);
					ps.setString(9,(workFlowEditor.getScheduleEndDate() != null)?(sdf.format(workFlowEditor.getScheduleEndDate())) : null);
					ps.setString(10,(workFlowEditor.getSchedulenextdue() != null)?(sdf.format(workFlowEditor.getSchedulenextdue())) : null);
					ps.setLong(11,(workFlowEditor.getFrquencyunit() != null) ? workFlowEditor.getFrquencyunit() : 0);
					ps.setLong(12,(workFlowEditor.getIncludedays() != null) ? workFlowEditor.getIncludedays() : 0);
					ps.setString(13,(workFlowEditor.getMonthlyschdfreq() != null)? workFlowEditor.getMonthlyschdfreq() + "" : null);
					ps.setString(14,(workFlowEditor.getMonthlyWeekFreq() != null)? workFlowEditor.getMonthlyWeekFreq() + "" : null);
					ps.setString(15,(workFlowEditor.getMonthlyDayFreq() != null)? workFlowEditor.getMonthlyDayFreq() + "" : null);
					ps.setLong(16,(workFlowEditor.getDayofeverymonth() != null)? workFlowEditor.getDayofeverymonth() : 0);
					ps.setString(17,workFlowEditor.getStatus() != null ? workFlowEditor.getStatus() + "" : null);
					ps.setString(18,workFlowEditor.getCreatedBy());
					ps.setString(19,workFlowEditor.getUpdatedBy());
					//ps.setTimestamp(20,new Timestamp(System.currentTimeMillis()));
					return ps;
				}
		},keyHolder);
		return keyHolder.getKey().longValue();
	}
	
	private Boolean deleteWorkFlowEditor(Long workFlowId){
		String deleteQuery="delete from DTW_WORKFLOWSCHEDULE where workflowid=?";
		int rowsUpdated = jdbcTemplate.update(deleteQuery,workFlowId);
		return rowsUpdated>0?Boolean.TRUE:Boolean.FALSE;
	}
	
	@Override
	public WorkflowEditor getWorkFlowEditor(Long DTWWorkflowId){
		try{
			String selectQuery="select * from DTW_WORKFLOWSCHEDULE where workflowid=?";
			WorkflowEditor workflowEditor=jdbcTemplate.queryForObject(selectQuery,new WorkflowEditorRowMapper(),DTWWorkflowId);
			convertToUserTimezone(workflowEditor);
			return workflowEditor;
		}
		catch (EmptyResultDataAccessException etdae) {
			return null;
		}catch (Exception ex) {
			logger.error("Error occurred while while fetching workfloweditor",ex);
			throw ex;
		}
	}
	
	private void convertToUserTimezone(WorkflowEditor schedule){
		if(schedule!=null && schedule.getSchedulesetting()=='Y'){
			if(schedule.getScheduleStartDate()!=null)
				schedule.setScheduleStartDate(CommonUtil.toLocalTime(schedule.getScheduleStartDate().getTime(),TimeZone.getTimeZone(schedule.getTimezone())));
			if(schedule.getScheduleEndDate()!=null)
				schedule.setScheduleEndDate(CommonUtil.toLocalTime(schedule.getScheduleEndDate().getTime(),TimeZone.getTimeZone(schedule.getTimezone())));
		}
	}
	
	public Map<String,String> getWorkFlowMappings(Long workflowId){
		Map<String,String> result=null;
		try {
			result =new HashMap<>();
			DTWWorkflow dtwWorkflow=getWorkflowById(workflowId);
			if(dtwWorkflow.getListWorkflowEditor()!=null){
				result.put("name", dtwWorkflow.getListWorkflowEditor().getName());
			}
			if (dtwWorkflow.getMappingstep()!=null){
				StringBuilder workflowNames=new StringBuilder();
				StringBuilder transformNames=new StringBuilder();
				for(WorkflowTransforms workflowTransforms: dtwWorkflow.getMappingstep()){
					if (workflowTransforms.getType().equals("T")){
						transformNames.append(getTransformById(workflowTransforms.getStepId()).getName()).append(",");
					}else{
						workflowNames.append(getWorkFlowEditor(workflowTransforms.getStepId()).getName()).append(",");
					}
				}
				
				if (workflowNames.toString().length()>0){
					result.put("aworkflows", workflowNames.toString().substring(0, workflowNames.toString().length()-1));
				}else{
					result.put("aworkflows", "-");
				}
				if (transformNames.toString().length()>0){
					result.put("atransforms", transformNames.toString().substring(0, transformNames.toString().length()-1));
				}else{
					result.put("atransforms", "-");
				}
			}
			
			result.put("executedby", dtwWorkflow.getUpdatedby());
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return result;
	}
	
	@Override
	public List<DTWWorkflow> getWorkflowsForAPI(DTWSearchCriteria listCriteria) throws DataTransformsException {
		List<DTWWorkflow> workflowEditorlists=null;
		String joinClause="";
		int totalsize = 0;
		final StringBuilder whereClauseBuilder = new StringBuilder();
		final DateFormat writeFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
		List<Object> params=new ArrayList<>();
		try
		{ 
			if(listCriteria == null){				 
				logger.debug("No Workflows exists for search criteria, so returning all workflows ");
				return getAllWorkflows();
			}
			if(listCriteria.getId() < 0){
				throw new DataTransformsException("HWE005",true);
			}
					   	
			if(listCriteria.getId() > 0){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.workflowid = ? ");
				params.add(listCriteria.getId());
				whereClauseBuilder.append(" ");
			}
			
			if(listCriteria.getCreatedFromDate()!= null){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.createdate >= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedFromDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedFromdate()!= null){	
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				whereClauseBuilder.append(" w.updatedate >= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getUpdatedFromdate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			
			if(listCriteria.getCreatedToDate()!= null){				
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.createdate <= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getCreatedToDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getUpdatedTodate()!= null){
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.updatedate <= ? ");
				params.add(writeFormat.format(CommonUtil.toUTC(listCriteria.getUpdatedTodate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()))));
			}
			if(listCriteria.getDepartmentId()!= null)
			{
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" w.departmentid = ? ");
				params.add(listCriteria.getDepartmentId());
			}
			String nameLike = listCriteria.getNamelike();
			if(nameLike != null && nameLike.trim().length()>0){
				joinClause=" left outer join DTW_WORKFLOWSCHEDULE ws on w.workflowid = ws.workflowid ) ";
				if(whereClauseBuilder.length()>0)
					whereClauseBuilder.append(" and ");
				else
					whereClauseBuilder.append(" where ");
				
				whereClauseBuilder.append(" ws.name LIKE ? ");
				params.add(nameLike);
			}else{
				joinClause=" ) ";
			}
			String baseQuery=new StringBuilder().append(DataTransformsQueries.WORKFLOW_COUNT_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			logger.debug("Count query :: "+baseQuery);
			totalsize = jdbcTemplate.queryForObject(baseQuery,params.toArray(), Integer.class);
			logger.debug("Total number of workflows {}",totalsize);
			if(listCriteria.getPageno()>0&&listCriteria.getPagesize()>0)
			{
				whereClauseBuilder.append(" LIMIT ");
				whereClauseBuilder.append((listCriteria.getPageno() - 1) * listCriteria.getPagesize());
				whereClauseBuilder.append(",");
				whereClauseBuilder.append(listCriteria.getPagesize());
			}
			baseQuery=new StringBuilder().append(DataTransformsQueries.WORKFLOW_BY_ALL_QUERY).append(joinClause).append(whereClauseBuilder.toString()).toString();
			logger.debug("DTW workflows search query {} "+baseQuery);
			
			workflowEditorlists = jdbcTemplate.query(baseQuery,params.toArray(), new WorkflowRowMapper());
			if(workflowEditorlists == null){
				logger.debug("Workflows not exists for search criteria");
				workflowEditorlists = Collections.emptyList();
			}
			
			//Begin :: Changes for workflow scheduling.
			if(!workflowEditorlists.isEmpty()){
				for(DTWWorkflow workflow:workflowEditorlists )
					workflow.setListWorkflowEditor(getWorkFlowEditor(workflow.getId()));
			}
			//End :: Changes for workflow scheduling.
			
			if(!workflowEditorlists.isEmpty())
			{
				workflowEditorlists.get(0).setTotalsize(totalsize);
				for(DTWWorkflow workflow:workflowEditorlists )
				{
					List<WorkflowActivity> wfActivityList = getWorkflowActivity(workflow.getId());
					if(!wfActivityList.isEmpty())
					{
						workflow.setActivity(true);
					}
					populateWorkflowStepName(workflow);
				}
			}
		}catch (Exception ex){
			if(ex.getMessage() != null && ex.getMessage().contains("Could not get JDBC Connection"))
				throw new DataTransformsException("AU0079",true);
			else
				throw new DataTransformsException(ex.getMessage(),ex);
		} 
		return workflowEditorlists;		
	}
	
	@Override
	public boolean checkWorkflowNameExists(DTWWorkflow workflow) throws DataTransformsException {
		boolean isExist = false;
		String sqlQuery = null;
		Long recordCount = Long.valueOf(0l);
		if(workflow.getId() == null || workflow.getId() == 0){
			sqlQuery = "select count(name) from DTW_WORKFLOWSCHEDULE where name = ?";
			recordCount = jdbcTemplate.queryForObject(sqlQuery, Long.class, workflow.getListWorkflowEditor().getName());
		}else{
			sqlQuery = "select count(ws.name) from DTW_WORKFLOW w inner join DTW_WORKFLOWSCHEDULE ws on ws.workflowid = w.workflowid where ws.name = ? and ws.workflowid != ?";
			recordCount = jdbcTemplate.queryForObject(sqlQuery, Long.class, workflow.getListWorkflowEditor().getName(),workflow.getId());
		}
		if(recordCount > 0)
			isExist = true;
		
		return isExist;
	}
	
	@Override
	public Boolean updateWorkflowStatus(Long workflowActivityId,String fromStatus,String toStatus,String userName){
		int count;
		if("I".equals(toStatus)){
			count=jdbcTemplate.update("UPDATE DTW_WORKFLOWACTIVITY SET STATUS=?,MESSAGE='Activity is in progress.',UPDATEDBY=? WHERE WORKFLOWACTIVITYID=? AND STATUS=?", new Object[]{toStatus,userName,workflowActivityId,fromStatus});
		}else{
			count=jdbcTemplate.update("UPDATE DTW_WORKFLOWACTIVITY SET STATUS=?,UPDATEDBY=? WHERE WORKFLOWACTIVITYID=? AND STATUS=?", new Object[]{toStatus,userName,workflowActivityId,fromStatus});
		}
		return count>0;
	}

	private final class DataTransformsQueries
	{
		//Get Queries
		private static final String TRANSFORM_BY_ALL_QUERY = "select TransformId,Name,UseTransaction,Transform,CreatedBy,UpdatedBy,createdate,updatedate from DTW_TRANSFORM ";
		
		private static final String TRANSFORM_BY_ID_QUERY = "select TransformId,Name,UseTransaction,Transform,CreatedBy,UpdatedBy,createdate,updatedate from DTW_TRANSFORM where TransformId=?";
		
		private static final String TRNSFORM_BY_ACTIVITY_QUERY = "select TA.TransformActvityId,TA.WorkflowActivityId,TA.StartedOn ,TA.CompletedOn,TA.TransformId,T.Name,TA.CreatedBy,TA.UpdatedBy,TA.createdate,TA.updatedate,TA.status,TA.message from DTW_TRANSFORM T join DTW_TRANSFORMACTVITY TA on TA.transformid=T.transformid where  TA.TransformId =? and TA.workflowactivityid=? ";
		
		private static final String TRANSFORM_COUNT_QUERY = "select count(transformid) from DTW_TRANSFORM ";
		
		private static final String WORKFLOW_BY_ALL_QUERY = "select w.WorkflowId,w.mappingstep,w.CreatedBy,w.UpdatedBy,w.createdate,w.updatedate,w.scheduletype,w.departmentid from (DTW_WORKFLOW w ";
		
		private static final String WORKFLOW_BY_ID_QUERY = "select WorkflowId,mappingstep,CreatedBy,UpdatedBy,createdate,updatedate,scheduletype,departmentid from DTW_WORKFLOW where workflowid=? ";
		
		private static final String WORKFLOW_BY_SCHEDULE_QUERY = "select WorkflowId,mappingstep,CreatedBy,UpdatedBy,createdate,updatedate,scheduletype,departmentid from DTW_WORKFLOW where scheduletype=? and departmentid=?";
		
		private static final String WORKFLOW_COUNT_QUERY = "select count(w.WorkflowId) from (DTW_WORKFLOW w ";
		
		private static final String WORKFLOW_TRIGGER_BY_ID_QUERY = "select WorkflowTriggerId,WorkflowId,FileDefinationId,CreatedBy,UpdatedBy,createdate,updatedate from DTW_WORKFLOWTRIGGER where WorkflowId =? and FileDefinationId=? order by createdate desc";
		
		private static final String WORKFLOW_ACTIVITY_BLOCK_STATUS_UPDATE_QUERY = "update DTW_WORKFLOWACTIVITY set Status=?,Message=?,updatedate=utc_timestamp() where Status=?";
		
		private static final String WORKFLOW_ACTIVITY_BY_ID_QUERY = "select WorkflowActivityId,WorkflowId,Status,Message,StartedOn,CompletedOn,BatchIds,CreatedBy,UpdatedBy,createdate,updatedate from DTW_WORKFLOWACTIVITY where WorkflowId=? order by createdate desc";
		
		private static final String WORKFLOW_ACTIVITY_ALL_QUERY = "select wa.WorkflowActivityId,wa.WorkflowId,wa.Status,wa.Message,wa.StartedOn,wa.CompletedOn,wa.BatchIds,wa.CreatedBy,wa.UpdatedBy,wa.createdate,wa.updatedate from ((DTW_WORKFLOWACTIVITY wa ";
		
		private static final String WORKFLOW_ACTIVITY_COUNT_QUERY = "select count(wa.WorkflowActivityId) from ((DTW_WORKFLOWACTIVITY wa ";
		
		private static final String TRANSFORM_ACTIVITY_BY_ID_TRANSFORM_ID_QUERY = "select '' as Name,TransformActvityId,WorkflowActivityId,TransformId,Status,Message,StartedOn,CompletedOn,CreatedBy,UpdatedBy,createdate,updatedate from DTW_TRANSFORMACTVITY where WorkflowActivityId=? and TransformId=? order by createdate desc";
		
		private static final String TRANSFORM_ACTIVITY_BY_ID_QUERY = "select '' as Name,TransformActvityId,WorkflowActivityId,TransformId,Status,Message,StartedOn,CompletedOn,CreatedBy,UpdatedBy,createdate,updatedate from DTW_TRANSFORMACTVITY where WorkflowActivityId=? order by createdate desc";
		
		
		//Insert Queries
		private static final String TRANSFORM_INSERT_QUERY = "insert into DTW_TRANSFORM (Name,UseTransaction,Transform,CreatedBy,UpdatedBy,createdate,updatedate) values (?,?,?,?,?,utc_timestamp(),utc_timestamp()); ";
		
		private static final String WORKFLOW_INSERT_QUERY = "insert into DTW_WORKFLOW (mappingstep,CreatedBy,UpdatedBy,scheduletype,departmentid,createdate,updatedate) values (?,?,?,?,?,utc_timestamp(),utc_timestamp());";
		
		private static final String WORKFLOW_TRIGGER_INSERT_QUERY = "insert into DTW_WORKFLOWTRIGGER(WorkflowId,FileDefinationId,CreatedBy,createdate,updatedate) values (?,?,?,utc_timestamp(),utc_timestamp()); ";
		
		private static final String WORKFLOW_ACTIVITY_INSERT_QUERY = "insert into DTW_WORKFLOWACTIVITY(WorkflowId,Status,Message,StartedOn,CompletedOn,BatchIds,CreatedBy,createdate,updatedate) values (?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp()); ";
		
		private static final String TRANSFORM_ACTIVITY_INSERT_QUERY = "insert into DTW_TRANSFORMACTVITY(WorkflowActivityId,TransformId,Status,Message,StartedOn,CompletedOn,CreatedBy,createdate,updatedate) values (?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp()); ";
		
		//Update Queries
		private static final String TRANSFORM_UPDATE_QUERY = "update DTW_TRANSFORM set Name=?,UseTransaction=?,Transform=?,UpdatedBy=?,updatedate=utc_timestamp() where TransformId =?;";
		
		private static final String WORKFLOW_UPDATE_QUERY = "update DTW_WORKFLOW set mappingstep=?,UpdatedBy=?,scheduletype=?,departmentid=?,updatedate=utc_timestamp()  where WorkflowId=?;";
		
		private static final String WORKFLOW_TRIGGER_UPDATE_QUERY = "update DTW_WORKFLOWTRIGGER set WorkflowId=?,FileDefinationId=?,UpdatedBy=?,updatedate=utc_timestamp() where WorkflowTriggerId=?";
		
		private static final String WORKFLOW_ACTIVITY_UPDATE_QUERY = "update DTW_WORKFLOWACTIVITY set WorkflowId=?,Status=?,Message=?,StartedOn=?,CompletedOn=?,BatchIds=?,UpdatedBy=?,updatedate=utc_timestamp()  where WorkflowActivityId=?";
		
		private static final String WORKFLOW_ACTIVITY_RESTART_QUERY = "update DTW_WORKFLOWACTIVITY set Status = ?,UpdatedBy=?,updatedate=utc_timestamp() where WorkflowActivityId = ? and Status=?;";
		
		private static final String WORKFLOW_ACTIVITY_CANCEL_QUERY = "update DTW_WORKFLOWACTIVITY set Status = ?,UpdatedBy=?,updatedate=utc_timestamp() where Status=? ;";
		
		private static final String TRANSFORM_ACTIVITY_UPDATE_QUERY = "update DTW_TRANSFORMACTVITY set WorkflowActivityId=?,TransformId=?,Status=?,Message=?,StartedOn=?,CompletedOn=?,UpdatedBy=?,updatedate=utc_timestamp() where TransformActvityId=?;";
		
		//Delete Queries
		private static final String TRANSFORM_DELETE_QUERY = "delete from DTW_TRANSFORM where TransformId =?;";
		
		private static final String WORKFLOW_DELETE_QUERY = "delete from DTW_WORKFLOW where WorkflowId=?;";
		
		private static final String WORKFLOW_TRIGGER_DELETE_QUERY = "delete from  DTW_WORKFLOWTRIGGER where WorkflowTriggerId=? ;";
		
		private static final String WORKFLOW_ACTIVITY_DELETE_QUERY = "delete from DTW_WORKFLOWACTIVITY where WorkflowActivityId=? ;";
		
		private static final String TRANSFORM_ACTIVITY_DELETE_QUERY = "delete from  DTW_TRANSFORMACTVITY where TransformActvityId=?; ";
		private static final String WORKFLOW_COUNT_BY_ID_QUERY = "SELECT COUNT(1) FROM LFD_FILEDEFINITION WHERE workflowid = ? AND STATUS != 'C' AND sendworkflow = 'Y'";
	}


}

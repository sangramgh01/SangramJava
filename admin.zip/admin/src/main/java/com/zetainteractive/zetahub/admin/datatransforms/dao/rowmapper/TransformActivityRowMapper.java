package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.TransformActivity;

public class TransformActivityRowMapper implements RowMapper<TransformActivity>
{
	final DateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	@Override
	public TransformActivity mapRow(ResultSet rs, int rowNum) throws SQLException {
		TransformActivity transform = new TransformActivity();
		
		transform.setId(rs.getLong("TransformActvityId"));
		transform.setWorkflowactivityid(rs.getLong("WorkflowActivityId"));
		transform.setTransformid(rs.getLong("TransformId"));
		transform.setStatus(rs.getString("Status").charAt(0));
		transform.setMessage(rs.getString("Message"));
		transform.setStartedOn(rs.getTimestamp("StartedOn"));
		transform.setCompletedOn(rs.getTimestamp("CompletedOn"));
		transform.setCreatedby(rs.getString("CreatedBy"));
		transform.setUpdatedby(rs.getString("UpdatedBy"));
		
		try {
			transform.setCreateddate(CommonUtil.toLocalTime(sdf.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			transform.setUpdateddate(CommonUtil.toLocalTime(sdf.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(rs.getString("Name")!=null)
		{
			transform.setName(rs.getString("Name"));
		}
		return transform;
	}
	
}

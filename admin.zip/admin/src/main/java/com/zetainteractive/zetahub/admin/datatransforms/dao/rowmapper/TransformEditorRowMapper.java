package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.TransformEditor;

/**
 * Row mapper for Transform table
 * @author Nagendra.Guttha
 *
 */
public class TransformEditorRowMapper implements RowMapper<TransformEditor>
{
	final DateFormat sd = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
		@Override
		public TransformEditor mapRow(ResultSet rs, int rowNum) throws SQLException {
			TransformEditor transform = new TransformEditor();
			
			transform.setId(rs.getLong("TransformId"));
			transform.setName(rs.getString("Name"));
			transform.setUsetransaction(rs.getString("UseTransaction").charAt(0));
			transform.setTransform(rs.getString("Transform"));
			transform.setCreatedby(rs.getString("CreatedBy"));
			transform.setUpdatedby(rs.getString("UpdatedBy"));
			
			try {
				transform.setCreateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				transform.setUpdateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			}  catch (Exception e) {
				e.printStackTrace();
			}
			return transform;
		}
		
}

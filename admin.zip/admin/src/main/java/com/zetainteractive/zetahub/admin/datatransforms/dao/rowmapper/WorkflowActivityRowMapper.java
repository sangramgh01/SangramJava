package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;

public class WorkflowActivityRowMapper implements RowMapper<WorkflowActivity>
{
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	final DateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	@Override
	public WorkflowActivity mapRow(ResultSet rs, int rowNum) throws SQLException {
		WorkflowActivity transform = new WorkflowActivity();
		transform.setId(rs.getLong("WorkflowActivityId"));
		transform.setWorkflowId(rs.getLong("WorkflowId"));
		transform.setStatus(rs.getString("Status").charAt(0));
		transform.setMessage(rs.getString("Message"));
		transform.setBatchids(rs.getString("BatchIds"));
		transform.setCreatedby(rs.getString("CreatedBy"));
		transform.setUpdatedby(rs.getString("UpdatedBy"));
		
		try {
			transform.setStartedOn(rs.getTimestamp("StartedOn") != null ? CommonUtil.toLocalTime(sdf.parse(rs.getString("StartedOn")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())) : null);
			transform.setCompletedOn(rs.getTimestamp("CompletedOn") != null ? CommonUtil.toLocalTime(sdf.parse(rs.getString("CompletedOn")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())) : null);
			transform.setCreateddate(CommonUtil.toLocalTime(sdf.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			transform.setUpdateddate(CommonUtil.toLocalTime(sdf.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return transform;
	}
	
}

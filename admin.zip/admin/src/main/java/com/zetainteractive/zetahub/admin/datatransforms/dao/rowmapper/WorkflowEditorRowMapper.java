package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor;

/**
 * @author Lakshmi.Medarametla
 *
 */
public class WorkflowEditorRowMapper implements RowMapper<WorkflowEditor>
{
	final DateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	@Override
	public WorkflowEditor mapRow(ResultSet rs, int rowNum) throws SQLException {
		WorkflowEditor workflowEditor = new WorkflowEditor();
		workflowEditor.setWorkFlowScheduleId(rs.getLong("workflowscheduleid"));
		workflowEditor.setWorkFlowId(rs.getLong("workflowid"));
		workflowEditor.setName(rs.getString("name"));
		workflowEditor.setStatus(rs.getString("status")==null?null:rs.getString("status").charAt(0));
		workflowEditor.setSchedulesetting(rs.getString("schedulesetting") != null ? rs.getString("schedulesetting").charAt(0) : null);
		workflowEditor.setEnablemode(rs.getString("enablemode") != null ? rs.getString("enablemode").charAt(0) : null);
		workflowEditor.setRunmode(rs.getString("runmode") != null ? rs.getString("runmode").charAt(0) : null);
		workflowEditor.setFrequency(rs.getString("frequency") != null ? rs.getString("frequency").charAt(0) : null);
		workflowEditor.setTimezone(rs.getString("timezone"));
		try {
			workflowEditor.setScheduleStartDate(StringUtils.isNotBlank(rs.getString("schedulestartdate"))?sdf.parse(rs.getString("schedulestartdate")):null);
		} catch (ParseException e) {}
		try {
			workflowEditor.setScheduleEndDate(StringUtils.isNotBlank(rs.getString("scheduleenddate"))?sdf.parse(rs.getString("scheduleenddate")):null);
		} catch (ParseException e) {}
		try {
			workflowEditor.setSchedulenextdue(StringUtils.isNotBlank(rs.getString("schedulenextdue"))?sdf.parse(rs.getString("schedulenextdue")):null);
		} catch (ParseException e) {}
		workflowEditor.setFrquencyunit(rs.getInt("frequencyunit"));
		workflowEditor.setIncludedays(rs.getInt("includedays"));
		workflowEditor.setMonthlyschdfreq((rs.getString("monthlyschdfreq") != null)? rs.getString("monthlyschdfreq").charAt(0) : '\0');
		workflowEditor.setMonthlyWeekFreq((rs.getString("monthlyweekfreq") != null)? rs.getString("monthlyweekfreq").charAt(0) : '\0');
		workflowEditor.setMonthlyDayFreq((rs.getString("monthlydayfreq") != null)? rs.getString("monthlydayfreq").charAt(0) : '\0');
		workflowEditor.setDayofeverymonth(rs.getInt("dayofeverymonth"));
		workflowEditor.setStatus(rs.getString("status")!=null?rs.getString("status").trim().charAt(0):'W');
		try {
			workflowEditor.setCreateDate(CommonUtil.toLocalTime(sdf.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			workflowEditor.setUpdateDate(CommonUtil.toLocalTime(sdf.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		workflowEditor.setCreatedBy(rs.getString("createdby"));
		workflowEditor.setUpdatedBy(rs.getString("updatedby"));
		return workflowEditor;
	}
	
}

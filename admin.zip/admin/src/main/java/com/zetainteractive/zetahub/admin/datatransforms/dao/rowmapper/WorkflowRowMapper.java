package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow;
import com.zetainteractive.zetahub.commons.domain.WorkflowTransforms;

public class WorkflowRowMapper implements RowMapper<DTWWorkflow>
{
	final DateFormat sd = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	@Override
	public DTWWorkflow mapRow(ResultSet rs, int rowNum) throws SQLException {
		DTWWorkflow workflow = new DTWWorkflow();
		workflow.setId(rs.getLong("WorkflowId"));
		ObjectMapper mapper = new ObjectMapper();
		try{
			List<WorkflowTransforms> mappingTransforms = mapper.readValue(rs.getString("mappingstep"), new TypeReference<List<WorkflowTransforms>>() {});
			workflow.setMappingstep(mappingTransforms);
			workflow.setSchedule(rs.getString("scheduletype"));
		} catch (IOException e) {
			e.printStackTrace(); //Log this
		}
		workflow.setDepartmentId(rs.getLong("departmentid"));
		workflow.setCreatedby(rs.getString("CreatedBy"));
		workflow.setUpdatedby(rs.getString("UpdatedBy"));
		try {
			workflow.setCreateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			workflow.setUpdateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		}  catch (Exception e) {
			e.printStackTrace();
		}
		return workflow;
	}
	
}

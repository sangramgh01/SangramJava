package com.zetainteractive.zetahub.admin.datatransforms.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger;

public class WorkflowTriggerRowMapper implements RowMapper<WorkflowTrigger>
{
	final DateFormat sd = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
	@Override
	public WorkflowTrigger mapRow(ResultSet rs, int rowNum) throws SQLException {
		WorkflowTrigger workflow = new WorkflowTrigger();
		workflow.setId(rs.getLong("WorkflowTriggerId"));
		workflow.setWorkflowId(rs.getLong("WorkflowId"));
		workflow.setFileDefinitionId(rs.getLong("FileDefinationId"));
		workflow.setCreatedby(rs.getString("CreatedBy"));
		workflow.setUpdatedby(rs.getString("UpdatedBy"));
		
		
		try {
			workflow.setCreateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			workflow.setUpdateddate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		workflow.setCreateddate(rs.getTimestamp("createdate"));
		workflow.setUpdateddate(rs.getTimestamp("updatedate"));
		return workflow;
	}
	
}

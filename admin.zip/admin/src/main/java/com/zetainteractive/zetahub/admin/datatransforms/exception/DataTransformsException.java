package com.zetainteractive.zetahub.admin.datatransforms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Generic exception class for data transforms
 * 
 * @author Nagendra.Guttha
 *
 */
@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR,reason="Exception occured in data transforms")
public class DataTransformsException extends Exception 
{
	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	private String message;
	
	public DataTransformsException()
	{
		super();
	}
	public DataTransformsException(String msg,Exception e)
	{
		super(msg,e);
		this.message = msg;
	}
	/**
	 * @param msg
	 */
	public DataTransformsException(String msg)
	{
		super(msg);
		this.message = msg;
	}
	
	/**
	 * @param msg
	 */
	public DataTransformsException(String pErrorCode,boolean isErrored)
	{
		if(isErrored)
		{
			this.errorCode = pErrorCode;
		}
		else
		{
			this.message =pErrorCode;
		}
		
	}
	
	/**
	 * 
	 * @param errorCode
	 */
	public DataTransformsException(String errorCode,Throwable t)
	{
		super(t);
		this.errorCode = errorCode;
	}
	/**
	 * @param e
	 */
	public DataTransformsException(Exception e)
	{
		super(e);
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getMessage()
	{
		return message;
	}
}

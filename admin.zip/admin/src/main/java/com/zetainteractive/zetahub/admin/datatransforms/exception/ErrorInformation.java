package com.zetainteractive.zetahub.admin.datatransforms.exception;

/**
 * Exception details to describe the failure cause
 * @author Nagendra.Guttha
 *
 */
public class ErrorInformation {

	private String requestedURI;
	private String exceptionMsg;
	public ErrorInformation(final Exception e, final String fromRequestURI)
	{
		this.setExceptionMsg(e.getMessage());
		this.setRequestedURI(fromRequestURI);
	}
	
	@Override
	public String toString()
	{
		return String.format("Exception due to :%s for the request URI : %s ",exceptionMsg,getRequestedURI());
	}
	public String getRequestedURI() {
		return requestedURI;
	}
	public void setRequestedURI(String requestedURI) {
		this.requestedURI = requestedURI;
	}

	public String getExceptionMsg() {
		return exceptionMsg;
	}

	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}
	

}

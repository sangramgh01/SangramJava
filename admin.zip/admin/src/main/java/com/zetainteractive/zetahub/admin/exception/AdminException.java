
package com.zetainteractive.zetahub.admin.exception;

import org.apache.log4j.Level;

/**
 * @author Lakshmi.Medarametla
 *
 */
public class AdminException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String dbMessage;
	Object[] object;
	Level level = Level.ERROR;
	boolean flag = false;

	/**
	 * @return Returns the errorMessage.
	 */

	public String getErrorMessage() {
		return getMessage();
	}

	/**
	 * No argument constructor.
	 */
	public AdminException() {
		super();
	}

	/**
	 * @param errorCode
	 *            error code
	 */
	public AdminException(String errorCode) {
		super(errorCode);
	}

	/**
	 * Constructor takes Error code and actual ex as arguments.
	 * 
	 * @param code
	 *            Error code
	 * @param ex
	 *            Actual Exception occured.
	 */
	public AdminException(String code, Throwable ex) {
		super(code, ex);
	}

	public String getErrorCode(){
		return super.getMessage();
	}
	
	/**
	 * @param code
	 * @param object
	 */
	public AdminException(String code, Object[] object) {
		super(code);
		this.object = object;
	}

	/**
	 * @param code
	 * @param ex
	 * @param object
	 * @param flag
	 */
	public AdminException(String code, Throwable ex, Object[] object, boolean flag) {
		super(code, ex);
		this.object = object;
		this.flag = flag;
	}

	/**
	 * @param code
	 * @param object
	 * @param level
	 * @param ex
	 */
	public AdminException(String code, Object[] object, Level level, Throwable ex) {
		super(code, ex);
		this.object = object;
		this.level = level;
	}

	public AdminException(String code, String locale, Object obj) {
		super(code);
	}

	/**
	 * @return Returns the dbMessage.
	 */
	public String getDbMessage() {
		return dbMessage;
	}

	/**
	 * @param dbMessage
	 *            The dbMessage to set.
	 */
	public void setDbMessage(String dbMessage) {
		this.dbMessage = dbMessage;
	}

	/**
	 * @return Returns the object.
	 */
	public Object[] getObject() {
		return object;
	}

	/**
	 * @param object
	 *            the object to set
	 */
	public void setObject(Object[] object) {
		this.object = object;
	}

	/**
	 * @return Returns the exception.
	 */
	public Throwable getException() {
		return super.getCause();
	}

	/**
	 * @return Returns the level.
	 */
	public Level getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            The level to set.
	 */
	public void setLevel(Level level) {
		this.level = level;
	}
}

package com.zetainteractive.zetahub.admin.file.validator;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.FileActivityBO;

@Component
public class FileActivityValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return FileActivityBO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		FileActivityBO bo = (FileActivityBO) target;
		if (bo.getFileDefinitionID() == null) {
			errors.rejectValue("filedefinitionid", messageSource.getMessage("FL0010",new Object[] { "filedefinitionid" }, LocaleContextHolder.getLocale()));
		}
		if (bo.getStatus() == null) {
			errors.rejectValue("status", messageSource.getMessage("FL0010", new Object[] { "status" },LocaleContextHolder.getLocale()));
		}
		if (bo.getStartedOn() == null) {
			errors.rejectValue("startedon", messageSource.getMessage("FL0010",new Object[] { "startedOn" }, LocaleContextHolder.getLocale()));
		}
		/*if (bo.getStartedOn() != null) {
			if(new Date().after(bo.getStartedOn())){
				errors.rejectValue("startedOn", messageSource.getMessage("FL0043",new Object[] { "startedOn" }, LocaleContextHolder.getLocale()));
			}
			
		}
		if (bo.getCompletedOn() != null) {
			if(new Date().after(bo.getCompletedOn())){
				errors.rejectValue("completedOn", messageSource.getMessage("FL0043",new Object[] { "completedOn" }, LocaleContextHolder.getLocale()));
			}
			
		}*/
		
	}

}

package com.zetainteractive.zetahub.admin.file.validator;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileFormatSpecBO;
import com.zetainteractive.zetahub.commons.domain.FileProcessingOptionsBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceSpecBO;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.file.constants.Constants;

@Component
public class FileValidator implements Validator {
	
	Logger logger = LoggerFactory.getLogger(getClass().getName());

	@Autowired
	MessageSource messageSource;

	@Override
	public boolean supports(Class<?> clazz) {
		return FileDefinitionBO.class.equals(clazz);
	}

	public void validateDataSource(String dataSource, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dataSource", messageSource
				.getMessage("file.dataSource.mandatory", new Object[] {}, LocaleContextHolder.getLocale()));
	}

	@Override
	public void validate(Object target, Errors errors) {
		FileDefinitionBO bo = (FileDefinitionBO) target;
		if(bo.getName() == null){
			errors.rejectValue("name", messageSource.getMessage("FL0010",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getName()!= null && (bo.getName().length() < 1 || bo.getName().length() >= 100)){
			errors.rejectValue("name", messageSource.getMessage("F00054",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if (bo.getFileType() == null || !(bo.getFileType() == Constants.FILE_TYPE_BASE || bo.getFileType() == Constants.FILE_TYPE_DIMENSION || bo.getFileType()== Constants.FILE_TYPE_UNSUB || bo.getFileType() == Constants.FILE_TYPE_RESUB || bo.getFileType() == Constants.FILE_TYPE_ADHOC)) {
			errors.rejectValue("fileType", messageSource.getMessage("FL0009",new Object[] { "fileType" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getFileType() != null && bo.getFileType() == Constants.FILE_TYPE_BASE && (bo.getAudienceID() == null || bo.getAudienceID()==0)){
			errors.rejectValue("audienceID", messageSource.getMessage("FL0010",new Object[] { "audienceId" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getTimeZone() == null){
			errors.rejectValue("timeZone", messageSource.getMessage("FL0010",new Object[] { "timeZone" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getFileType() != null && (bo.getFileType()== Constants.FILE_TYPE_UNSUB || bo.getFileType()== Constants.FILE_TYPE_RESUB )){
			if(bo.getChannelType() == null || !(bo.getChannelType() == 'E' || bo.getChannelType() == 'S')){
				errors.rejectValue("channelType", messageSource.getMessage("FL0020",new Object[] {"channelType"}, LocaleContextHolder.getLocale()));
			}
		}
		if(bo.getStatus()!=null && !(bo.getStatus()=='W' || bo.getStatus()=='B')){
			errors.rejectValue("status",messageSource.getMessage("FL0055", new Object[] {"status"}, LocaleContextHolder.getLocale()));
		}
		if (bo.getScheduleactivemode() == null || !(bo.getScheduleactivemode() == Constants.YES || bo.getScheduleactivemode() == Constants.NO)) {
			errors.rejectValue("scheduleactivemode", messageSource.getMessage("FL0011",new Object[] { "scheduleactivemode" }, LocaleContextHolder.getLocale()));
		}
		if (bo.getUseEncryption() == null || !(bo.getUseEncryption() == Constants.YES || bo.getUseEncryption() == Constants.NO)) {
			errors.rejectValue("useEncryption", messageSource.getMessage("FL0011",new Object[] { "useEncryption" }, LocaleContextHolder.getLocale()));
		}
		FileSourceSpecBO fileSource = (FileSourceSpecBO) bo.getFileSource();
		if(fileSource!=null){
			if(fileSource.getSourceType()==null || !(fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_SERVER || fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_DB || fileSource.getSourceType() == Constants.FILE_SOURCE_DESKTOP || fileSource.getSourceType() == Constants.FILE_SOURCE_LOCAL_SERVER)){
				errors.rejectValue("fileSource.sourceType", messageSource.getMessage("FL0022",new Object[] { "sourceType" }, LocaleContextHolder.getLocale()));
			}
			if(fileSource.getSourceType() != null && (fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_SERVER|| fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_DB)){
				if(fileSource.getSourceName()==null){
					errors.rejectValue("fileSource.sourceName", messageSource.getMessage("FL0010",new Object[] { "sourceType" }, LocaleContextHolder.getLocale()));
				}
				/*if(fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_SERVER && fileSource.getFolderPath() == null && !(fileSource.getSourceName().equalsIgnoreCase("http") || fileSource.getSourceName().equalsIgnoreCase("https"))){
					errors.rejectValue("fileSource.folderPath", messageSource.getMessage("FL0010",new Object[] { "folderPath" }, LocaleContextHolder.getLocale()));
				}*/
				if(fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_SERVER && fileSource.getFileNamePattern() == null){
					errors.rejectValue("fileSource.fileNamePattern", messageSource.getMessage("FL0010",new Object[] { "fileNamePattern" }, LocaleContextHolder.getLocale()));
				}
				if(fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_DB && fileSource.getQuery() == null){
					errors.rejectValue("fileSource.query", messageSource.getMessage("FL0010",new Object[] { "query" }, LocaleContextHolder.getLocale()));
				}
				/*if(fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_DB && fileSource.getSourceTable() == null){
					errors.rejectValue("fileSource.sourceTable", messageSource.getMessage("FL0010",new Object[] { "sourceTable" }, LocaleContextHolder.getLocale()));
				}*/
			}
			if(fileSource.getSourceType() != null && (fileSource.getSourceType() == Constants.FILE_SOURCE_REMOTE_SERVER || fileSource.getSourceType() == Constants.FILE_SOURCE_LOCAL_SERVER || fileSource.getSourceType() == Constants.FILE_SOURCE_DESKTOP)){
				FileFormatSpecBO fileFormat = (FileFormatSpecBO) bo.getFileFormatSpec();
				if(fileFormat!=null){
					if(fileFormat.getDelimiter() == null || !(fileFormat.getDelimiter().equalsIgnoreCase(",")|| fileFormat.getDelimiter().equalsIgnoreCase("Tab") ||fileFormat.getDelimiter().equalsIgnoreCase(";")|| fileFormat.getDelimiter().equalsIgnoreCase("|"))){
						errors.rejectValue("fileFormatSpec.delimiter", messageSource.getMessage("FL0023",new Object[] { "delimiter" }, LocaleContextHolder.getLocale()));
					}
					if(fileFormat.getTextQualifier() == null || !(fileFormat.getTextQualifier().equalsIgnoreCase("None")|| fileFormat.getTextQualifier().equalsIgnoreCase("'") ||fileFormat.getTextQualifier().equalsIgnoreCase("\""))){
						errors.rejectValue("fileFormatSpec.textQualifier", messageSource.getMessage("FL0024",new Object[] { "textQualifier" }, LocaleContextHolder.getLocale()));
					}
					if(fileFormat.getHeaderRowAtLine() == null || (fileFormat.getHeaderRowAtLine()<0)){
						errors.rejectValue("fileFormatSpec.headerRowAtLine", messageSource.getMessage("FL0025",new Object[] { "headerRowAtLine" }, LocaleContextHolder.getLocale()));
					}
					if(fileFormat.getDataStartsFromLine() == null || (fileFormat.getHeaderRowAtLine() !=null && fileFormat.getDataStartsFromLine()<= fileFormat.getHeaderRowAtLine())){
						errors.rejectValue("fileFormatSpec.dataStartsFromLine", messageSource.getMessage("FL0026",new Object[] { "dataStartsFromLine" }, LocaleContextHolder.getLocale()));
					}
					if(fileFormat.getHeaderInColumn() != null && !(fileFormat.getHeaderInColumn() == Constants.YES || fileFormat.getHeaderInColumn() == Constants.NO)){
						errors.rejectValue("fileFormatSpec.headerInColumn", messageSource.getMessage("FL0027",new Object[] { "headerInColumn" }, LocaleContextHolder.getLocale()));
					}
					if (bo.getMaxFiles()== null || bo.getMaxFiles()<=0) {
						errors.rejectValue("maxFiles", messageSource.getMessage("FL0025",new Object[] { "maxFiles" }, LocaleContextHolder.getLocale()));
					}
				}else{
					errors.rejectValue("fileFormatSpec", messageSource.getMessage("FL0021",new Object[] { "fileFormatSpec" }, LocaleContextHolder.getLocale()));
				}
				FileProcessingOptionsBO fileProcessing = (FileProcessingOptionsBO) bo.getFileProcessingOptions();
				if(fileProcessing!=null){
					if(fileProcessing.getIgnoreBadFiles()== null || !(fileProcessing.getIgnoreBadFiles() == Constants.YES || fileProcessing.getIgnoreBadFiles() == Constants.NO)){
						errors.rejectValue("fileProcessingOptions.ignoreBadFiles", messageSource.getMessage("FL0011",new Object[] { "ignoreBadFiles" }, LocaleContextHolder.getLocale()));
					}
					if(fileProcessing.getIgnoreBadRecords()== null || !(fileProcessing.getIgnoreBadRecords() == Constants.YES || fileProcessing.getIgnoreBadRecords() == Constants.NO)){
						errors.rejectValue("fileProcessingOptions.ignoreBadRecords", messageSource.getMessage("FL0011",new Object[] { "ignoreBadRecords" }, LocaleContextHolder.getLocale()));
					}
					if(fileProcessing.getPreserveOrder()== null || !(fileProcessing.getPreserveOrder() == Constants.YES || fileProcessing.getPreserveOrder() == Constants.NO)){
						errors.rejectValue("fileProcessingOptions.preserveOrder", messageSource.getMessage("FL0011",new Object[] { "preserveOrder" }, LocaleContextHolder.getLocale()));
					}
//					if(fileProcessing.getMergeDuplicates()== null || !(fileProcessing.getMergeDuplicates() == Constants.YES || fileProcessing.getMergeDuplicates() == Constants.NO)){
//						errors.rejectValue("fileProcessingOptions.mergeDuplicates", messageSource.getMessage("FL0011",new Object[] { "mergeDuplicates" }, LocaleContextHolder.getLocale()));
//					}
				}else{
					errors.rejectValue("fileProcessingOptions", messageSource.getMessage("FL0021",new Object[] { "fileProcessingOptions" }, LocaleContextHolder.getLocale()));
				}
			}
		}else{
			errors.rejectValue("fileSource", messageSource.getMessage("FL0021",new Object[] { "fileSource" }, LocaleContextHolder.getLocale()));
		}
		if (bo.getScheduleactivemode() != null && bo.getScheduleactivemode() == Constants.YES) {
			FileScheduleBO fileScheduleBO = bo.getFileScheduleBO();
			if (fileScheduleBO.getTimeZone() == null) {
				errors.rejectValue("fileScheduleBO.timeZone", messageSource.getMessage("FL0010",new Object[] { "timeZone" }, LocaleContextHolder.getLocale()));
			}
			else{
				//Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
				//Date currentDate = calendar.getTime();
				if (fileScheduleBO.getFrequency() == 'O' || fileScheduleBO.getFrequency() == 'N' || fileScheduleBO.getFrequency() == 'D' || fileScheduleBO.getFrequency() == 'W' || fileScheduleBO.getFrequency() == 'M' || fileScheduleBO.getFrequency() == 'I' ) {
					if(fileScheduleBO.getScheduleStartDate() != null){
						Date currentDate = getCurrentDate();
						Date selectdate = (Date) CommonUtil.toUTC(fileScheduleBO.getScheduleStartDate().getTime(), TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
						logger.info("FileValidator Class method   ::currentDate ::"+currentDate);
						logger.info("FileValidator Class method   ::selectdate ::"+selectdate);
						if (!(fileScheduleBO.getFrequency()=='I') && currentDate.after(selectdate)) {
							errors.rejectValue("fileScheduleBO.scheduleStartDate", messageSource.getMessage("FL0012",new Object[] {}, LocaleContextHolder.getLocale()));
						}
					}
					if (fileScheduleBO.getScheduleEndDate() != null && fileScheduleBO.getScheduleEndDate() != null && !(fileScheduleBO.getFrequency() == 'O')) {
						Date selectStartDate = (Date) CommonUtil.toUTC(fileScheduleBO.getScheduleStartDate().getTime(), TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
						Date selectEndDate = (Date) CommonUtil.toUTC(fileScheduleBO.getScheduleEndDate().getTime(), TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
						logger.info("FileValidator Class method   ::selectStartDate ::"+selectStartDate);
						logger.info("FileValidator Class method   ::selectEndDate ::"+selectEndDate);
						if (fileScheduleBO.getScheduleStartDate() != null && selectStartDate.after(selectEndDate)) {
							errors.rejectValue("fileScheduleBO.scheduleEndDate", messageSource.getMessage("FL0013",new Object[] {}, LocaleContextHolder.getLocale()));
						}
					}
					if(fileScheduleBO.getFrequency() == 'N' && (fileScheduleBO.getFrequencyUnit() == null || fileScheduleBO.getFrequencyUnit() <= 0 )){
							errors.rejectValue("fileScheduleBO.frequencyUnit", messageSource.getMessage("FL0014",new Object[] {"Execute every/Frequency unit","By Minutes"}, LocaleContextHolder.getLocale()));
					}
					if(fileScheduleBO.getFrequency() == 'W' && fileScheduleBO.getIncludeDays() <= 0 ){
						errors.rejectValue("fileScheduleBO.includeDays", messageSource.getMessage("FL0015",new Object[] {"Execute every","Incluede days","Weekly"}, LocaleContextHolder.getLocale()));
					}
					if (fileScheduleBO.getFrequency() == 'M' ){
						if(fileScheduleBO.getMonthlySchdFreq()!=null && (fileScheduleBO.getMonthlySchdFreq() == 'D' || fileScheduleBO.getMonthlySchdFreq()=='T')){
							if(fileScheduleBO.getMonthlySchdFreq() == 'D' && (fileScheduleBO.getDayOfEveryMonth() == null || (fileScheduleBO.getDayOfEveryMonth() <= 0 && fileScheduleBO.getDayOfEveryMonth() > 32))){
								errors.rejectValue("fileScheduleBO.dayOfEveryMonth", messageSource.getMessage("FL0016",new Object[] {"dayOfEveryMonth", "Monthly" }, LocaleContextHolder.getLocale()));
							}
							if(fileScheduleBO.getMonthlySchdFreq() == 'T' && (fileScheduleBO.getMonthlyWeekFreq() !=null && !(fileScheduleBO.getMonthlyWeekFreq()=='F' || fileScheduleBO.getMonthlyWeekFreq()=='S' || fileScheduleBO.getMonthlyWeekFreq()=='T' || fileScheduleBO.getMonthlyWeekFreq()=='O' || fileScheduleBO.getMonthlyWeekFreq()=='L'))){
								errors.rejectValue("fileScheduleBO.monthlyWeekFreq", messageSource.getMessage("FL0018",new Object[] {"monthlyWeekFreq","Monthly" }, LocaleContextHolder.getLocale()));
							}
							if(fileScheduleBO.getMonthlySchdFreq() == 'T' && (fileScheduleBO.getMonthlyDayFreq() !=null && !(fileScheduleBO.getMonthlyDayFreq()=='M' || fileScheduleBO.getMonthlyDayFreq()=='T' || fileScheduleBO.getMonthlyDayFreq()=='W' || fileScheduleBO.getMonthlyDayFreq()=='H' || fileScheduleBO.getMonthlyDayFreq()=='F' || fileScheduleBO.getMonthlyDayFreq()=='U' || fileScheduleBO.getMonthlyDayFreq()=='S'))){
								errors.rejectValue("fileScheduleBO.monthlyDayFreq", messageSource.getMessage("FL0019",new Object[] { "monthlyDayFreq","Monthly" }, LocaleContextHolder.getLocale()));
							}
						}else{
							errors.rejectValue("fileScheduleBO.monthlySchdFreq", messageSource.getMessage("FL0017",new Object[] {"monthlySchdFreq","Monthly"}, LocaleContextHolder.getLocale()));
						}
					}
				} else{
					errors.rejectValue("fileScheduleBO.frequency", messageSource.getMessage("FL0060",new Object[] {"frequency"}, LocaleContextHolder.getLocale()));
				}
			}
		}
		if (bo.getFileAction() == null || !(bo.getFileAction() == Constants.FILE_ACTION_STORE || bo.getFileAction() == Constants.FILE_ACTION_IMPORT)) {
			errors.rejectValue("fileAction", messageSource.getMessage("FL0028",new Object[] { "fileAction" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getTableName() == null && (bo.getFileType()!=null && bo.getFileType() == 'B') && bo.getIsFileTrigger() == 'Y' && bo.getFileAction() == Constants.FILE_ACTION_IMPORT) {
			errors.rejectValue("tableName", messageSource.getMessage("FL0010",new Object[] { "tableName" }, LocaleContextHolder.getLocale()));
		}
		if ((bo.getFileType()!=null && (bo.getFileType() == 'B' || bo.getFileType() == 'D')) && bo.getTableName()!=null && bo. getFileAction() != null && bo.getFileAction() == Constants.FILE_ACTION_IMPORT && !(bo.getFileType() != null && bo.getFileType() == Constants.FILE_TYPE_ADHOC )){
			if((bo.getTableDisposition() == null || !(bo.getTableDisposition().equalsIgnoreCase("APPEND")|| bo.getTableDisposition().equalsIgnoreCase("REPLACE")))) {
				errors.rejectValue("tableDisposition", messageSource.getMessage("FL0029",new Object[] { "tableDisposition" }, LocaleContextHolder.getLocale()));
			}
			/*if(bo.getTableName() == null ||  (bo.getTableName()!=null && bo.getTableName().trim().isEmpty())) {
				errors.rejectValue("tableName", messageSource.getMessage("FL0010",new Object[] { "tableName" }, LocaleContextHolder.getLocale()));
			}*/
		}
		if (bo.getSendWorkFlow() == null  || !(bo.getSendWorkFlow() == Constants.YES || bo.getSendWorkFlow() == Constants.NO)) {
			errors.rejectValue("sendWorkFlow", messageSource.getMessage("FL0011",new Object[] { "Send Workflow" }, LocaleContextHolder.getLocale()));
		}
		if (bo.getFileType() != null && bo.getFileType() == Constants.FILE_TYPE_DIMENSION ){
			if(bo.getSendWorkFlow()!=null && bo.getSendWorkFlow() == 'Y' && (bo.getWorkFlowID()==null || bo.getWorkFlowID()==0)){
				errors.rejectValue("workFlowID", messageSource.getMessage("FL0010",new Object[] {"WorkFlow"}, LocaleContextHolder.getLocale()));
			}
		}
		/*if (bo.getNotifications() !=null && bo.getNotifications().getSendNotification() == Constants.YES) {
			if(bo.getNotifications().getNotificationEmails() != null){
				ArrayList<String> emails = (ArrayList<String>) bo.getNotifications().getNotificationEmails();
				for(int i=0;i<emails.size();i++) {
					if (emails.get(i) != null && !emails.get(i).isEmpty() && !Constants.EMAIL_PATTERN.matcher(emails.get(i).trim()).matches()) {
						errors.rejectValue("notifications.notificationEmails["+i+"]", messageSource.getMessage("FL0064",new Object[] {}, LocaleContextHolder.getLocale()));
						break;
					}
				}
			}
		}*/
		if (bo.getIsFileTrigger() == null || !(bo.getIsFileTrigger() == Constants.YES || bo.getIsFileTrigger() == Constants.NO)) {
			errors.rejectValue("isFileTrigger", messageSource.getMessage("FL0011",new Object[] { "IsFileTrigger" }, LocaleContextHolder.getLocale()));
		}
		
		if(bo.getFileMapping() != null){
			if(!("NL".equalsIgnoreCase(bo.getFileMapping().getNullValueRepresentation()) || "ES".equalsIgnoreCase(bo.getFileMapping().getNullValueRepresentation()))){
				errors.rejectValue("fileMapping.nullValueRepresentation", messageSource.getMessage("FL0046",new Object[] { "nullValueRepresentation" }, LocaleContextHolder.getLocale()));
			}
			if(!("YESNO".equalsIgnoreCase(bo.getFileMapping().getBooleanFormat()) || "YN".equalsIgnoreCase(bo.getFileMapping().getBooleanFormat()) || "TF".equalsIgnoreCase(bo.getFileMapping().getBooleanFormat()) || "TRFL".equalsIgnoreCase(bo.getFileMapping().getBooleanFormat()) || "OZ".equalsIgnoreCase(bo.getFileMapping().getBooleanFormat()))){
				errors.rejectValue("fileMapping.booleanFormat", messageSource.getMessage("FL0044",new Object[] { "booleanFormat" }, LocaleContextHolder.getLocale()));
			}
			if(!("YMD".equalsIgnoreCase(bo.getFileMapping().getDateFormat()) || "YMDT".equalsIgnoreCase(bo.getFileMapping().getDateFormat()) || "DMY".equalsIgnoreCase(bo.getFileMapping().getDateFormat())
					|| "MDY".equalsIgnoreCase(bo.getFileMapping().getDateFormat()) || "MONDY".equalsIgnoreCase(bo.getFileMapping().getDateFormat()) || "DMONY".equalsIgnoreCase(bo.getFileMapping().getDateFormat()))){
				errors.rejectValue("fileMapping.dateFormat", messageSource.getMessage("FL0047",new Object[] { "dateFormat" }, LocaleContextHolder.getLocale()));
			}
			if(!(" ".equalsIgnoreCase(bo.getFileMapping().getDateDelimiter()) || "-".equalsIgnoreCase(bo.getFileMapping().getDateDelimiter()) || "/".equalsIgnoreCase(bo.getFileMapping().getDateDelimiter()))){
				errors.rejectValue("fileMapping.dateDelimiter", messageSource.getMessage("FL0045",new Object[] { "dateDelimiter" }, LocaleContextHolder.getLocale()));
			}
			if (bo.getFileMapping().getEnableScrubRules() == null || !(bo.getFileMapping().getEnableScrubRules() == Constants.YES || bo.getFileMapping().getEnableScrubRules() == Constants.NO)) {
				errors.rejectValue("fileMapping.enableScrubRules", messageSource.getMessage("FL0011",new Object[] { "enableScrubRules" }, LocaleContextHolder.getLocale()));
			}
			if((bo.getFileMapping().getEnableScrubRules() !=null && bo.getFileMapping().getEnableScrubRules() == Constants.YES) && bo.getFileMapping().getIncludeScrubRules()<=0){
				errors.rejectValue("fileMapping.includeScrubRules", messageSource.getMessage("FL0025",new Object[] { "includeScrubRules" }, LocaleContextHolder.getLocale()));
			}
			
		}else{
			errors.rejectValue("fileMapping", messageSource.getMessage("FL0021",new Object[] { "fileMapping" }, LocaleContextHolder.getLocale()));
		}
		
	}

	public void validateLogicalColumns(List<CustomColumnDefinitionBO> columnBOs, Object obj, Errors errors) {
		List<ColumnDefinitionBO> columnDefinitionBOs = null;
		if(obj instanceof FileDefinitionBO){
			if(((FileDefinitionBO)obj).getFileMapping()!=null)
			columnDefinitionBOs = ((FileDefinitionBO)obj).getFileMapping().getColumnDefinitionList();
		}else if(obj instanceof ListDefinitionBO){
			columnDefinitionBOs = ((ListDefinitionBO)obj).getColumnDefinitionList();
		}
		int count = 0;
		String message = "fileMapping.columnDefinitionList["+count+"]";
		if(obj instanceof ListDefinitionBO){
			message = "columnDefinitionList["+count+"]";
		}
		if(columnDefinitionBOs == null || columnDefinitionBOs.size() < 1){
			errors.rejectValue(message, messageSource.getMessage("FL0021", new Object[] {"Data mappings"},LocaleContextHolder.getLocale()));
			return;
		}
		if(columnBOs!=null && !columnBOs.isEmpty()){
		for (CustomColumnDefinitionBO columnBO : columnBOs) {
			if(columnBO.getDefaultValue() == null) {
			boolean containsKeyColumn = false;
			if (columnBO.getIsKeyColumn() == 'Y' || columnBO.getIsNullable() == 'N') {
				for (ColumnDefinitionBO columnDefinitionBO : columnDefinitionBOs) {
					if(columnBO.getPhysicalColumnName()!=null){
					if (columnDefinitionBO.getPhysicalColumnName() != null && columnBO.getPhysicalColumnName() !=null && columnDefinitionBO.getPhysicalColumnName().equalsIgnoreCase(columnBO.getPhysicalColumnName())) {
						containsKeyColumn = true;
					}
					}else
					{
						if (columnDefinitionBO.getLogicalColumnName() != null && columnBO.getLogicalColumnName() !=null && columnDefinitionBO.getLogicalColumnName().equalsIgnoreCase(columnBO.getLogicalColumnName())) {
							containsKeyColumn = true;
						}
					}
				}
			}
			if (!containsKeyColumn) {
				if(columnBO.getIsKeyColumn() == 'Y'){
					errors.rejectValue(message+".columnName", messageSource.getMessage("FL0033", new Object[] {columnBO.getLogicalColumnName()},
							LocaleContextHolder.getLocale()));
				}else if (columnBO.getIsNullable() == 'N'){
					errors.rejectValue(message+".columnName", messageSource.getMessage("FL0042", new Object[] {columnBO.getLogicalColumnName()},
							LocaleContextHolder.getLocale()));
				}
				
			}
			}
			count++;
		}
		}
		if(obj instanceof FileDefinitionBO){
			FileDefinitionBO bo = (FileDefinitionBO)obj;
			if(bo.getFileType() != null && (bo.getFileType() == 'U' || bo.getFileType() == 'R') && bo.getChannelType()!=null){
				boolean emailorSMSFlag = false;
				int mappingCount = 0;
				for (ColumnDefinitionBO columnDefinitionBO : columnDefinitionBOs) {
					if(("Email".equalsIgnoreCase(columnDefinitionBO.getColumnType()) && bo.getChannelType()=='E')||("SMS".equalsIgnoreCase(columnDefinitionBO.getColumnType())&& bo.getChannelType()=='S')){
						emailorSMSFlag = true;
						mappingCount ++;
					}
				}
				String columnType = bo.getChannelType()=='E'?"Email":"SMS";
				if(!emailorSMSFlag){
					errors.rejectValue(message+".columnName", messageSource.getMessage("FL0034", new Object[] {columnType},LocaleContextHolder.getLocale()));
				}
				if(mappingCount>1){
					errors.rejectValue(message+".columnName", messageSource.getMessage("FL0035", new Object[] {columnType},LocaleContextHolder.getLocale()));
				}
				
			}
		}else if(obj instanceof ListDefinitionBO){
			ListDefinitionBO bo = (ListDefinitionBO)obj;
			if(bo.getListType() != null && (bo.getListType() == 'U' || bo.getListType() == 'R')){
				boolean emailorSMSFlag = false;
				int mappingCount = 0;
				for (ColumnDefinitionBO columnDefinitionBO : columnDefinitionBOs) {
					if(("Email".equalsIgnoreCase(columnDefinitionBO.getColumnType())&&bo.getChannelType()=='E')||("SMS".equalsIgnoreCase(columnDefinitionBO.getColumnType()) && bo.getChannelType()=='S')){
						emailorSMSFlag = true;
						mappingCount ++;
					}
				}
				String columnType = bo.getChannelType()=='E'?"Email":"SMS";
				if(!emailorSMSFlag){
					errors.rejectValue("columnDefinitionList["+count+"].columnName", messageSource.getMessage("FL0034", new Object[] {columnType},LocaleContextHolder.getLocale()));
				}
				if(mappingCount>1){
					errors.rejectValue("columnDefinitionList["+count+"].columnName", messageSource.getMessage("FL0035", new Object[] {columnType},LocaleContextHolder.getLocale()));
				}
				
			}
		}
		
		Map<String,List<String>> logicalColumnsMap = new HashMap<String,List<String>>();
		Map<String,List<String>> columnTypeMap = new HashMap<String,List<String>>();
		for (ColumnDefinitionBO columnDefinitionBO : columnDefinitionBOs) {
			if(obj instanceof FileDefinitionBO){
				if(((FileDefinitionBO)obj).getFileType() != null && (((FileDefinitionBO)obj).getFileType() == 'U' || ((FileDefinitionBO)obj).getFileType() == 'R')){
					if(columnDefinitionBO.getAddressType() == null){
						continue;
					}
				}
			}
			if ((columnDefinitionBO.getIsCustomColumn() != null && columnDefinitionBO.getIsCustomColumn() == 'N'  && columnDefinitionBO.getLogicalColumnName() != null && !"Omit".equalsIgnoreCase(columnDefinitionBO.getLogicalColumnName()))) {
				String logicalColumn =columnDefinitionBO.getLogicalColumnName();
				if(logicalColumnsMap.get(logicalColumn)!=null){
					if(logicalColumn!=null && ("Email Address".equalsIgnoreCase(logicalColumn) || "SMS Number".equalsIgnoreCase(logicalColumn))){
						List<String> existingCategories = logicalColumnsMap.get(logicalColumn);
						for (String category : existingCategories) {
							if(columnDefinitionBO.getAddressType() == category){
								errors.rejectValue(message+".columnName", messageSource.getMessage("FL0037",new Object[] {logicalColumn}, LocaleContextHolder.getLocale()));
								break;
							}
						}
						existingCategories.add(columnDefinitionBO.getAddressType());
						logicalColumnsMap.put(logicalColumn, existingCategories);
					}else{
						errors.rejectValue(message+".columnName", messageSource.getMessage("FL0036",new Object[] {logicalColumn}, LocaleContextHolder.getLocale()));
					}
				}else{
					List<String> categoryTypeList = new ArrayList<String>();
					categoryTypeList.add(columnDefinitionBO.getAddressType());
					logicalColumnsMap.put(logicalColumn, categoryTypeList);
				}
			}else if (columnDefinitionBO.getIsCustomColumn() != null && columnDefinitionBO.getIsCustomColumn() == 'Y'){
				if("Email".equalsIgnoreCase(columnDefinitionBO.getColumnType()) ||"SMS".equalsIgnoreCase(columnDefinitionBO.getColumnType())){
					if(columnTypeMap.get(columnDefinitionBO.getColumnType())!=null){
							List<String> existingCategories = columnTypeMap.get(columnDefinitionBO.getColumnType());
							for (String category : existingCategories) {
								if(columnDefinitionBO.getAddressType().equals(category)){
									errors.rejectValue(message+".columnName", messageSource.getMessage("FL0038",new Object[] {columnDefinitionBO.getColumnType()}, LocaleContextHolder.getLocale()));
									break;
								}
							}
							existingCategories.add(columnDefinitionBO.getAddressType());
							columnTypeMap.put(columnDefinitionBO.getColumnType(), existingCategories);
					}else{
						List<String> categoryTypeList = new ArrayList<String>();
						categoryTypeList.add(columnDefinitionBO.getAddressType());
						columnTypeMap.put(columnDefinitionBO.getColumnType(), categoryTypeList);
					}
				}
			} 
		}
	}
	/** Gives current date  */
	private Timestamp getCurrentDate(){
		logger.info("FileValidator Class method getCurrentDate :: new Date()::"+new Date()+"  Calendar.getInstance().getTimeZone()"+Calendar.getInstance().getTimeZone());
		Date date = new Date();
		date.setSeconds(0);
		return  CommonUtil.toUTC(date.getTime(), Calendar.getInstance().getTimeZone());
	}
}

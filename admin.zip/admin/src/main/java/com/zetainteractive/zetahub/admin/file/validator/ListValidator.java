package com.zetainteractive.zetahub.admin.file.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;

/**
 * 
 * @author Venkata.Tummala
 *
 */
@Component
public class ListValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	@Override
	public boolean supports(Class<?> clazz) {
		return ListDefinitionBO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ListDefinitionBO bo = (ListDefinitionBO) target;
		if(bo.getName() == null){
			errors.rejectValue("name", messageSource.getMessage("FL0010",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getName()!= null && (bo.getName().length() < 1 || bo.getName().length() >= 100)){
			errors.rejectValue("name", messageSource.getMessage("F00054",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if(bo.getListType() == null || !(bo.getListType() == 'T' || bo.getListType() == 'G' || bo.getListType() == 'S' || bo.getListType() == 'U' || bo.getListType() == 'R')){
			errors.rejectValue("listType",messageSource.getMessage("FL0030", new Object[] {"listType"}, LocaleContextHolder.getLocale()));
		}
		if ((bo.getListType() != null && ( bo.getListType() == 'T' || bo.getListType() == 'G' || bo.getListType() == 'S') && bo.getAudienceID() == null)) {
			errors.rejectValue("audienceID",messageSource.getMessage("FL0010", new Object[] {"audienceID"}, LocaleContextHolder.getLocale()));
		}
		if ((bo.getListType() != null && ( bo.getListType() == 'U' || bo.getListType() == 'R') && (bo.getChannelType() == null))) {
			errors.rejectValue("channelType",messageSource.getMessage("FL0020", new Object[] {"channelType"}, LocaleContextHolder.getLocale()));
		}
		/*if((bo.getListType() != null && ( bo.getListType() == 'U' || bo.getListType() == 'R')) && (bo.getChannelType() != null && (bo.getChannelType() == 'E' || bo.getChannelType() == 'S'))){
			errors.rejectValue("channelType",messageSource.getMessage("FL0020", new Object[] {"channelType"}, LocaleContextHolder.getLocale()));
		}*/
		if (bo.getFolderID() == null) {
			bo.setFolderID(0L);
			//errors.rejectValue("folderID",messageSource.getMessage("FL0021", new Object[] {"folderID"}, LocaleContextHolder.getLocale()));
		}
		if (bo.getCategoryID() == null) {
			bo.setCategoryID(0L);
			//errors.rejectValue("categoryID",messageSource.getMessage("FL0021", new Object[] {"categoryID"}, LocaleContextHolder.getLocale()));
		}
		if(bo.getDeptID() == null){
			errors.rejectValue("deptID",messageSource.getMessage("FL0021", new Object[] {"deptID"}, LocaleContextHolder.getLocale()));
		}
		if (bo.getSourceType() == null || !(bo.getSourceType() == 'T' || bo.getSourceType() == 'F' || bo.getSourceType() == 'A')) {
			errors.rejectValue("sourceType",messageSource.getMessage("FL0031", new Object[] {"sourceType"}, LocaleContextHolder.getLocale()));
		}
		if (bo.getSourceType() != null && bo.getSourceType() == 'T' && (bo.getTableName()==null || "".equalsIgnoreCase(bo.getTableName().trim()))) {
			errors.rejectValue("tableName",messageSource.getMessage("FL0021", new Object[] {"tableName"}, LocaleContextHolder.getLocale()));
		}
		if (bo.getSourceType() != null && bo.getSourceType() == 'F' && bo.getFileDefinitionID()==null) {
			errors.rejectValue("fileDefinitionID",messageSource.getMessage("FL0021", new Object[] {"fileDefinitionID"}, LocaleContextHolder.getLocale()));
		}
		if(bo.getStatus()!=null && !(bo.getStatus()=='C' || bo.getStatus() == 'W' || bo.getStatus() == 'P')){
			errors.rejectValue("status",messageSource.getMessage("FL0052", new Object[] {"status"}, LocaleContextHolder.getLocale()));
		}
	}
}

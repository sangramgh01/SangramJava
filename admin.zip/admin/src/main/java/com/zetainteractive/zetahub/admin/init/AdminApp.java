package com.zetainteractive.zetahub.admin.init;

import java.util.Properties;

import javax.servlet.MultipartConfigElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.embedded.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;

import com.zetainteractive.zetahub.bootstarter.BootInitializer;

import net.jawr.web.servlet.JawrSpringController;

/**
 * The Class Application.
 */
@ComponentScan(basePackages = { "com.zetainteractive.zetahub.*" })
@SpringBootApplication
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
@EnableTransactionManagement
public class AdminApp {
	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */

	@Autowired
	Environment env;

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		BootInitializer.runApp(AdminApp.class, args);
		System.out.println("Application started");
	}

	@Bean
	public ReloadableResourceBundleMessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename("classpath:messages");
		messageSource.setCacheSeconds(60);
		return messageSource;
	}
	
	@Bean
	public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        factory.setFileSizeThreshold("128KB");
        factory.setMaxFileSize("300MB");
        factory.setMaxRequestSize("300MB");
        factory.setLocation(System.getProperty("java.io.tmpdir"));
        return factory.createMultipartConfig();
    }
	
	@Bean(name="jawrCssController")
	public JawrSpringController jawrCSSController(){
		JawrSpringController jawrSpringController = new JawrSpringController();
		jawrSpringController.setType("css");
		jawrSpringController.setConfigLocation("prod-jawr.conf");
		return jawrSpringController;
	}
	
	@Bean(name="jawrJsController")
	public JawrSpringController jawrJsController(){
		JawrSpringController jawrSpringController = new JawrSpringController();
		jawrSpringController.setType("js");
		jawrSpringController.setConfigLocation("prod-jawr.conf");
		return jawrSpringController;
	}
	
	@Bean(name="jawrHandlerMapping")
	public SimpleUrlHandlerMapping urlMapping() {
		SimpleUrlHandlerMapping simpleUrlHandlerMapping = new SimpleUrlHandlerMapping();
		simpleUrlHandlerMapping.setOrder(Ordered.HIGHEST_PRECEDENCE);
		Properties mappings = new Properties();
		mappings.setProperty("**/*loader.js", "jawrJsController");
		mappings.setProperty("**/*bundle.css", "jawrCssController");
		simpleUrlHandlerMapping.setMappings(mappings);
		return simpleUrlHandlerMapping;
	}
	
	

}

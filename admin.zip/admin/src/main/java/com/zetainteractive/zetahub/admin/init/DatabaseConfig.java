/**
 * DatabaseConfig.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.init;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariDataSource;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;


@Configuration
@EnableRetry
public class DatabaseConfig {
	@Autowired
	Environment env;

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	/**
	 * This method will create jdbcTemplate bean which will be autowired.
	 *
	 * @param dataSource the data source
	 * @return the jdbc template
	 * @throws Exception 
	 */
	@Bean(name = "clientJdbcTemplate")
	@Scope("prototype")
//	@Autowired
	public JdbcTemplate jdbcTemplate() throws Exception {
		return new JdbcTemplate(dataSource());
	}

	/**
	 * Will create data source here and pass it for creating jdbcTemplate and Transactions.
	 *
	 * @return the driver manager data source
	 * @throws Exception 
	 */
//	@Bean(name = "clientDbSource")
//	@Primary
/*	public DataSource dataSource() throws Exception {
		DataSource dataSource = null;
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("spring.datasource.driver-class-name"));
		dataSource.setUrl(env.getProperty("spring.datasource.url"));
		dataSource.setUsername(env.getProperty("spring.datasource.username"));
		dataSource.setPassword(env.getProperty("spring.datasource.password"));
		try {
			dataSource = ZetaUtil.getHelper().getCustomerDataSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return dataSource;
	}*/
	
	public DataSource dataSource() throws Exception {
		HikariDataSource dataSource = null;
		try {
			
			
			dataSource = new HikariDataSource();
			dataSource.setJdbcUrl("jdbc:mysql:loadbalance://ZHDEV1-XTRADB-VIP.bo3.e-dialog.com:3306/zhstgcust?useSSL=false&loadBalanceConnectionGroup=first&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&characterEncoding=UTF-8");
			dataSource.setUsername("zhstgcust");
			try {
				dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
				dataSource.setPassword("Feb@2017");
			} catch (Exception e) {
				logger.error("Exception", e);
			}
			// Maximum number of connections the pool will hold
			//Environment env = SpringApplicationContext.getContext().getBean(Environment.class);
			/*if (env.getProperty("spring.application.name") != null 
					&& env.getProperty("spring.application.name").contains("de-conversation-legacy"))
				dataSource.setMaximumPoolSize(16);
			else*/
			dataSource.setMaximumPoolSize(8);
			
			System.out.println();
			dataSource.setMinimumIdle(0);
			dataSource.setIdleTimeout(10000);
			
			//dataSource = ZetaUtil.getHelper().getCustomerDataSource();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return dataSource;
	}
	
	/**
	 * This method will create jdbcTemplate bean which will be autowired.
	 *
	 * @param dataSource the data source
	 * @return the jdbc template
	 * @throws Exception 
	 */
	@Bean(name = "whJdbc")
	@Scope("prototype")
//	@Autowired
	public JdbcTemplate whJdbcTemplate() throws Exception {
		return new JdbcTemplate(whDataSource());
	}
	
	/**
	 * Will create data source here and pass it for creating jdbcTemplate and Transactions.
	 *
	 * @return the driver manager data source
	 * @throws Exception 
	 */
//	@Bean(name = "whSource")
	public DataSource whDataSource() throws Exception {
		DataSource whDataSource = null;
		/*DriverManagerDataSource whDataSource = new DriverManagerDataSource();
		whDataSource.setDriverClassName(env.getProperty("spring.wh.datasource.driver-class-name"));
		whDataSource.setUrl(env.getProperty("spring.wh.datasource.url"));
		whDataSource.setUsername(env.getProperty("spring.wh.datasource.username"));
		whDataSource.setPassword(env.getProperty("spring.wh.datasource.password"));
		return whDataSource;*/
		try {
			whDataSource = ZetaUtil.getHelper().getWarehouseDataSource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return whDataSource;
	}
	
	@Bean
	@Scope(value="prototype")
    public PlatformTransactionManager txManager() throws Exception {
		logger.info("Preparing transaction manager for environment- "+ ZetaUtil.getHelper().getEnvironment() +" And customer-"
				+ZetaUtil.getHelper().getCustomerID());
        return new DataSourceTransactionManager(dataSource());
    }
	}

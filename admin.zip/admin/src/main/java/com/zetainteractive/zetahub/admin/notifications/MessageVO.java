package com.zetainteractive.zetahub.admin.notifications;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author sangram.panda
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MessageVO
{

	@JsonIgnore
	private String content;
	
	@JsonIgnore
	private String tid;
	
	private String from;
	
	private String to;
	
	private String body;
	
	//To hold call back url - used by service provider to send delivery statistics
	private String deliveryStatusUrl;
	
	//(maximum length of 64 characters) that will be returned with the delivery status to allow you to pass integration information.
	private String clientRef;
	

	public String getContent()
	{
		return this.content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getTid()
	{
		return this.tid;
	}

	public void setTid(String tid)
	{
		this.tid = tid;
	}

	public String getFrom()
	{
		return this.from;
	}

	public void setFrom(String from)
	{
		this.from = from;
	}

	public String getTo()
	{
		return this.to;
	}

	public void setTo(String to)
	{
		this.to = to;
	}

	public String getBody()
	{
		return body;
	}

	public void setBody(String body)
	{
		this.body = body;
	}

	public String getDeliveryStatusUrl()
	{
		return deliveryStatusUrl;
	}

	public void setDeliveryStatusUrl(String deliveryStatusUrl)
	{
		this.deliveryStatusUrl = deliveryStatusUrl;
	}

	public String getClientRef()
	{
		return clientRef;
	}

	public void setClientRef(String clientRef)
	{
		this.clientRef = clientRef;
	}
	
	
}

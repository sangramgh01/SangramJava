package com.zetainteractive.zetahub.admin.notifications;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.notifications.dao.NotificationDao;
import com.zetainteractive.zetahub.admin.notifications.exception.NotificationException;
import com.zetainteractive.zetahub.admin.notifications.service.NotificationService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.NotificationsBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;

@RestController
@RequestMapping("/notifications")
public class NotificationController {
	
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	NotificationDao notificationDao;
	
	@Autowired
	NotificationService notificationService;
	
	@Autowired
	MessageSource messageSource;
	
	@RequestMapping(method = RequestMethod.PUT, value = "/getallnotifications", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllNotifications(@RequestBody JSONObject search){
		try {
			return new ResponseEntity<Object>(notificationDao.getAllNotifications(search),HttpStatus.OK);
		} catch (NotificationException e) {
			ResponseObject resp = new ResponseObject();
			resp.addError("", messageSource.getMessage(e.getErrorCode(),new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(method = RequestMethod.GET, value = "/getnotificationsbyid/{notificationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getNotificationsById(@PathVariable long notificationId){
		try {
			return new ResponseEntity<Object>(notificationDao.getNotificationsById(notificationId),HttpStatus.OK);
		} catch (NotificationException e) {
			ResponseObject resp = new ResponseObject();
			resp.addError("", messageSource.getMessage(e.getErrorCode(),new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(method = RequestMethod.POST, value = "/savenotification", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveNotification(@RequestBody NotificationsBO bo){
		try {
			return new ResponseEntity<Object>(notificationDao.saveNotification(bo),HttpStatus.OK);
		} catch (NotificationException e) {
			ResponseObject resp = new ResponseObject();
			resp.addError("", messageSource.getMessage(e.getErrorCode(),new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(method = RequestMethod.POST, value = "/updatenotification", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateNotification(@RequestBody NotificationsBO bo){
		try {
			return new ResponseEntity<Object>(notificationDao.updateNotification(bo),HttpStatus.OK);
		} catch (NotificationException e) {
			ResponseObject resp = new ResponseObject();
			resp.addError("", messageSource.getMessage(e.getErrorCode(),new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@SuppressWarnings({ "unchecked" })
	@RequestMapping(method = RequestMethod.POST, value = "/sendnotification", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> sendNotification(@RequestBody NotificationInputBO jsonObj){
		logger.info("Inside:sendNotification()");
		try {
			Integer smtpTimeout = ZetaUtil.getHelper().getConfig().getConfigValueInt("mail-smtp-timeout", 2000);
            Integer connectionTimeout = ZetaUtil.getHelper().getConfig().getConfigValueInt("mail-smtp-connectiontimeout", 2000);
            String mailHost = ZetaUtil.getHelper().getConfig().getConfigValueString("mail-smtp-host", null);
			String from = ZetaUtil.getHelper().getConfig().getConfigValueString("mail-smtp-from", null);
			logger.info("mail.smtp.timeout ::"+smtpTimeout+"  mail.smtp.connectiontimeout ::"+connectionTimeout+" mail.smtp.host::"+mailHost+"   mail.smtp.from::"+from);
			notificationService.mailService(jsonObj,smtpTimeout,connectionTimeout,mailHost,from);
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":\"success\"}", JSONObject.class),HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:sendNotification", e);
			logger.info("Inside:sendNotification()");
			JSONObject error = new JSONObject();
			if(e instanceof NotificationException){
				error.put("response",messageSource.getMessage(((NotificationException)e).getErrorCode(),new Object[] {}, LocaleContextHolder.getLocale()));
			}else{			
				error.put("response", "error");
			}
			return new ResponseEntity<Object>(error,HttpStatus.OK);
		}
	}
	
	
}

package com.zetainteractive.zetahub.admin.notifications.dao;

import org.json.simple.JSONObject;

import com.zetainteractive.zetahub.admin.notifications.exception.NotificationException;

public interface NotificationDao {
	public Object getAllNotifications(JSONObject search) throws NotificationException;
	public Object getNotificationsById(long notificationId) throws NotificationException;
	public Object saveNotification(Object bo) throws NotificationException;
	public Object updateNotification(Object bo) throws NotificationException;
	public Object getNotificationByTemplateCode(String tempCode) throws NotificationException;
}

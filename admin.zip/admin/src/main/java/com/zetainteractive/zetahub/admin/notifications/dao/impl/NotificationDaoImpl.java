package com.zetainteractive.zetahub.admin.notifications.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.notifications.dao.NotificationDao;
import com.zetainteractive.zetahub.admin.notifications.exception.NotificationException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.NotificationsBO;

@Repository
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class NotificationDaoImpl implements NotificationDao{
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate template;
	
	@Override
	public Object getAllNotifications(JSONObject search) throws NotificationException{
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select notificationid,name,type,status,content,description,createdby,updatedby,createdate,updatedate from ADM_NOTIFICATION");
		if(search != null && search.size() > 0){
			List<String> keys = new ArrayList(search.keySet());
			for (int i = 0; i < keys.size(); i++) {
				if(i == 0)
					queryBuilder.append(" where ").append(keys.get(i)).append("='").append(search.get(keys.get(i))).append("'");
				else
					queryBuilder.append(" and ").append(keys.get(i)).append("='").append(search.get(keys.get(i))).append("'");
			}
		}
		return template.query(queryBuilder.toString(), new NotificationsRowMapper());
	}
	
	
	
	
	@Override
	public Object getNotificationsById(long notificationId) throws NotificationException{
		String query = "select notificationid,name,type,status,content,description,createdby,updatedby,createdate,updatedate from ADM_NOTIFICATION where notificationid = ?";
		return template.queryForObject(query, new NotificationsRowMapper(),notificationId);
	}
	@Override
	public Object saveNotification(Object obj) throws NotificationException{
		NotificationsBO bo = (NotificationsBO)obj;
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String query = "insert into ADM_NOTIFICATION(name,type,status,content,description,createdby,updatedby) values(?,?,?,?,?,?,?)";
		template.update(new PreparedStatementCreator() {
			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				PreparedStatement ps = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
				ps.setString(1,bo.getName());
				ps.setString(2,bo.getTemplateCode());
				ps.setString(3,bo.getStatus()+"");
				ps.setString(4,bo.getContentTemplate());
				ps.setString(5,bo.getDescription());
				ps.setString(6,bo.getCreatedBy());
				ps.setString(7,bo.getUpdatedBy());
				return ps;
			}
		}, keyHolder);
		bo.setNotificationId(keyHolder.getKey().longValue());
		return bo;
	}
	@Override
	public Object updateNotification(Object obj) throws NotificationException{
		NotificationsBO bo = (NotificationsBO)obj;
		StringBuilder queryBuilder = new StringBuilder();
		if(bo.getName() != null) queryBuilder.append("name=").append("'").append(bo.getName()).append("',");
		if(bo.getTemplateCode() != null) queryBuilder.append("type=").append("'").append(bo.getTemplateCode()).append("',");
		if(bo.getStatus() != null) queryBuilder.append("status=").append("'").append(bo.getStatus()).append("',");
		if(bo.getContentTemplate() != null) queryBuilder.append("content=").append("'").append(bo.getTemplateCode()).append("',");
		if(bo.getDescription() != null) queryBuilder.append("description=").append("'").append(bo.getDescription()).append("',");
		if(bo.getUpdatedBy() != null) queryBuilder.append("updatedby=").append("'").append(bo.getUpdatedBy()).append("',");
		if(bo.getCreatedBy() != null) queryBuilder.append("createdby=").append("'").append(bo.getCreatedBy()).append("'");
		int result = template.update("update ADM_NOTIFICATION set "+queryBuilder.toString()+ " where notificationid = ?",bo.getNotificationId());
		try {
			return new ObjectMapper().readValue("{\"response\":"+result+"}", JSONObject.class);
		} catch (Exception e) {
			throw new NotificationException();
		}
	}
	
	private class NotificationsRowMapper implements RowMapper<NotificationsBO>{
		@Override
		public NotificationsBO mapRow(ResultSet rs, int rowNum) throws SQLException {
			NotificationsBO bo = new NotificationsBO();
			bo.setNotificationId(rs.getLong("notificationid"));
			bo.setName(rs.getString("name"));
			bo.setTemplateCode(rs.getString("type"));
			bo.setStatus(rs.getString("status").charAt(0));
			bo.setContentTemplate(rs.getString("content"));
			bo.setDescription(rs.getString("description"));
			bo.setCreatedBy(rs.getString("createdby"));
			bo.setUpdatedBy(rs.getString("updatedby"));
			bo.setCreateDate(rs.getDate("createdate"));
			bo.setUpdateDate(rs.getDate("updatedate"));
			return bo;
		}
	}

	@Override
	public Object getNotificationByTemplateCode(String templateCode) throws NotificationException {
		try {
			String query = "select notificationid,name,type,status,content,description,createdby,updatedby,createdate,updatedate from ADM_NOTIFICATION where status = 'A' and type = ?";
			return template.queryForObject(query, new NotificationsRowMapper(),templateCode);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new NotificationException("FL0068");
		}
		
	}
	
}

package com.zetainteractive.zetahub.admin.notifications.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.zetainteractive.zetahub.admin.notifications.dao.NotificationDao;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.MailUtils;
import com.zetainteractive.zetahub.commons.domain.MailContentTypes;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.NotificationsBO;
import com.zetainteractive.zetahub.commons.domain.SendMailBO;

@Service	
public class NotificationService {
	
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	NotificationDao notificationDao;

	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public void mailService(NotificationInputBO input,Integer smtpTimeout,Integer connectionTimeout,String mailHost,String from) throws Exception {
		logger.debug("Inside:mailService()  Templete Code ::"+input.getTemplateCode());
		NotificationsBO bo = (NotificationsBO) notificationDao.getNotificationByTemplateCode(input.getTemplateCode());
		logger.debug("Email Address for notifications:: "+input.getEmailAdresses());
		logger.info("Inside:mailService()  Replaceing key value pairs are  ::"+input.getTemplateValues());
		replaceContent(bo, input.getTemplateValues());
		SendMailBO SendMailBO = new SendMailBO();
		SendMailBO.setEmailAddresses(Arrays.asList(Arrays.stream(input.getEmailAdresses().split(","))
		        .distinct()
		        .toArray(String[]::new)));
		SendMailBO.setSubject(getSubject(bo.getDescription(),input.getTemplateValues()));
		SendMailBO.setFrom(from);
		SendMailBO.setContentType(MailContentTypes.HTML);
		SendMailBO.setMailContent(bo.getContentTemplate());
		MailUtils mailUtils = new MailUtils();
		mailUtils.setSMTPProperties(smtpTimeout, connectionTimeout, mailHost);
		mailUtils.sendMail(SendMailBO);
	}
	private String getSubject(String description, Map<String, String> templateValues) {
		logger.info("Inside:mailService()  getSubject ::"+description);
		if(description !=null && description.trim().startsWith("CONVERSATION_")) {
			String conversationName = templateValues.get("conversationname");
			String subject = description.replace("CONVERSATION", conversationName);
			logger.info("Notification Subject after subject change: " + subject);
			return subject;
		}else {
			logger.info("Notification Subject without subject change: " + description);
			return description;	
		}
	}
	private void replaceContent(NotificationsBO boNotificationsBO,Map<String,String> replacer) throws Exception{
		String content = boNotificationsBO.getContentTemplate();
		if(replacer != null && replacer.size() > 0){
			content = StrSubstitutor.replace(content,replacer);
			content = StrSubstitutor.replace(content,replacer,"<<",">>");
		}
		if(content.contains("<<CMSIPADDRESS>>")){
			content = content.replace("<<CMSIPADDRESS>>", ZetaUtil.getHelper().getConfig().getConfigValueString("zetaBaseUrl", "null"));
		}
		boNotificationsBO.setContentTemplate(content);
	}

}

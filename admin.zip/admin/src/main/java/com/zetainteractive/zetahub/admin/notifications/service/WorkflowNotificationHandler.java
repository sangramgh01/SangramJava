package com.zetainteractive.zetahub.admin.notifications.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.CommonNotificationBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.NotificationStatus;
import com.zetainteractive.zetahub.commons.domain.Notifications;
import com.zetainteractive.zetahub.commons.enums.NotificationStatusTypes;
import com.zetainteractive.zetahub.commons.enums.TemplateCodes;

@Component
public class WorkflowNotificationHandler {
	
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	NotificationService notificationService;
	
	ZetaLogger logger = new ZetaLogger(getClass());
	
	public void sendEmailNotification(Map<String,String> templateValues,String status,BindingResult bindingResult){
		logger.debug("Begin :: "+getClass()+" sendEmailNotification(Map<String,String> templateValues,String status,BindingResult bindingResult)");
		try {
			Map<String,String> emailAddress=new HashMap<String,String>();
			DepartmentSettings departmentSettings=departmentService.getDepartmentSpecificProperty(Long.parseLong(templateValues.get("departmentId")), "NOTIFICATIONS",bindingResult);
			CommonNotificationBO commonNotificationBO=getNotificationStatus(departmentSettings, "Workflows");
			if (commonNotificationBO.getIsEnabled()){
				emailAddress=getDepartmentEmailDetails(commonNotificationBO, emailAddress);
				templateValues.put("modulename","workflow");
				sendNotification(emailAddress, status, templateValues,"Workflow");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		logger.debug("End :: "+getClass()+" sendEmailNotification(Map<String,String> templateValues,String status,BindingResult bindingResult)");
		
	}
	/**
	 * 
	 * 
	 * Method Name 	: sendCancelNotification
	 * Description 	: The Method "sendCancelNotification" is used for send email notification based on status 
	 * Date    		: 19 Sep 2017, 15:19:04
	 * @param fileDefinitionBO
	 * @param status
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	public void sendCancelNotification(FileDefinitionBO fileDefinitionBO,String status){
		try {
			Map<String,String> templateValues=new HashMap<>();
			Map<String,String> emailAddress=new HashMap<>();
			String type="";
			if(fileDefinitionBO.getNotifications() != null && fileDefinitionBO.getNotifications().getIsEnabled())
				emailAddress=getNotificationEmailDetails(fileDefinitionBO.getNotifications());
			BindingResult bindingResult= new DataBinder(fileDefinitionBO.getDepartmentID()).getBindingResult(); 
			DepartmentSettings departmentSettings=departmentService.getDepartmentSpecificProperty(fileDefinitionBO.getDepartmentID(), "NOTIFICATIONS",bindingResult);
			CommonNotificationBO commonNotificationBO=getNotificationStatus(departmentSettings, "Files");
			if (commonNotificationBO != null && commonNotificationBO.getIsEnabled())
				emailAddress=getDepartmentEmailDetails(commonNotificationBO, emailAddress);
			
			if(fileDefinitionBO.getFileType() == 'A'){
				templateValues.put("modulename","list");
				type="List";
			}else if(fileDefinitionBO.getFileType() == 'B'){
				templateValues.put("modulename","file");
				type="Base";
			}else if(fileDefinitionBO.getFileType() == 'D'){
				templateValues.put("modulename","file");
				type="Dimension";
			}else if(fileDefinitionBO.getFileType() == 'R'){
				templateValues.put("modulename","file");
				type="Resub";
			}else if(fileDefinitionBO.getFileType() == 'U'){
				templateValues.put("modulename","file");
				type="Unsub";
			}
			templateValues.put("value",fileDefinitionBO.getFileDefinitionID()+"");
			templateValues.put("departmentId", String.valueOf(fileDefinitionBO.getDepartmentID()));
			templateValues.put("name", fileDefinitionBO.getName());
			if(!emailAddress.isEmpty() && emailAddress.containsKey(status))
				sendNotification(emailAddress, status, templateValues,type);
			
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
	
	private void sendNotification(Map<String,String> emailAddress,String status,Map<String,String> templateValues,String type) throws Exception{
		if (emailAddress.containsKey(status) ){
			NotificationInputBO notificationInputBO=prepareWorkflowNotifcationInput(status, emailAddress, ZetaUtil.getHelper().getCustomerID(), templateValues,type);
			Integer smtpTimeout = ZetaUtil.getHelper().getConfig().getConfigValueInt("mail-smtp-timeout", 2000);
            Integer connectionTimeout = ZetaUtil.getHelper().getConfig().getConfigValueInt("mail-smtp-connectiontimeout", 2000);
            String mailHost = ZetaUtil.getHelper().getConfig().getConfigValueString("mail-smtp-host", null);
			String from = ZetaUtil.getHelper().getConfig().getConfigValueString("mail-smtp-from", null);
			logger.info("mail.smtp.timeout ::"+smtpTimeout+"  mail.smtp.connectiontimeout ::"+connectionTimeout+" mail.smtp.host::"+mailHost+"   mail.smtp.from::"+from);
			notificationService.mailService(notificationInputBO,smtpTimeout,connectionTimeout,mailHost,from);
		}
	}

	private CommonNotificationBO getNotificationStatus(DepartmentSettings departmentSettings,String notificationName){
		CommonNotificationBO commonNotificationBO=null;
		try {
			if (departmentSettings !=null ){
				ObjectMapper objectMapper=new ObjectMapper();
				NotificationBO notificationBO=objectMapper.convertValue(departmentSettings.getObjectValue(),NotificationBO.class);
				if (notificationBO !=null && notificationBO.getNotifications() !=null && !notificationBO.getNotifications().isEmpty()){
					for (CommonNotificationBO cmnNotificationBO: notificationBO.getNotifications()){
						if (cmnNotificationBO.getNotificationTypeName().equalsIgnoreCase(notificationName)){
							commonNotificationBO=cmnNotificationBO;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return commonNotificationBO;
	}
	
	private Map<String,String> getDepartmentEmailDetails(CommonNotificationBO commonNotificationBO,Map<String,String> emailAddresses) throws Exception {
		if (commonNotificationBO.getDefaultEmailAddresses() != null && !emailAddresses.containsKey("default"))
			emailAddresses.put("default", commonNotificationBO.getDefaultEmailAddresses());
		List<NotificationStatus> notificationStatusList=commonNotificationBO.getNotificationStatuses();
		for (NotificationStatus notificationStatus :notificationStatusList){
			if (notificationStatus.getIsEnabled()){
				if( notificationStatus.getEmailAddresses() !=null 
						&& (!emailAddresses.containsKey(notificationStatus.getName()) ||"-".equals(emailAddresses.get(notificationStatus.getName()))))	
						emailAddresses.put(notificationStatus.getName(), notificationStatus.getEmailAddresses());
				else if(!emailAddresses.containsKey(notificationStatus.getName()))
					emailAddresses.put(notificationStatus.getName(), "-");
			} 
			
		}
		return emailAddresses;	
	}
	
	/**
	 * 
	 * Method Name 	: prepareNotifcationInput
	 * Description 	: The Method "preparing notification input" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	private NotificationInputBO prepareWorkflowNotifcationInput(String status,Map<String,String> emailMap,String custCode,Map<String,String>  templateValues,String moduleName) throws Exception {
		StringBuilder emailAddresses=new StringBuilder();
		if (emailMap.containsKey("default"))
			emailAddresses.append(emailMap.get("default"));
		NotificationInputBO notificationInputBO=new NotificationInputBO();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if(status.equals("Retry" )){
			if(emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_RETRY.getValue())&&
					!emailMap.get(NotificationStatusTypes.NOTIFICATION_RETRY.getValue()).equals("-")){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_RETRY.getValue()));
				
			}
			notificationInputBO.setTemplateCode(TemplateCodes.WORKFLOW_RETRY.getValue());
			templateValues.put("status","Retry" );
			templateValues.put("retryon",dateFormat.format(new Date(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()).getTime()))+" UTC");
			
		}else if(status.equals("Cancelled") ){
			if(emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_CANCELLED.getValue()) && 
					!emailMap.get(NotificationStatusTypes.NOTIFICATION_CANCELLED.getValue()).equals("-")){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_CANCELLED.getValue()));
				
			}
			if("Workflow".equals(moduleName)){
				notificationInputBO.setTemplateCode(TemplateCodes.WORKFLOW_CANCEL.getValue());
				templateValues.put("cancelon",new Date().toString());
			}else{
				notificationInputBO.setTemplateCode(TemplateCodes.DATAIMPORT_CANCEL.getValue());
				templateValues.put("cancelon",dateFormat.format(new Date(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()).getTime()))+" UTC");
			}
				
			templateValues.put("status","Cancelled" );
			
		}
		templateValues.put("type",moduleName);
		templateValues.put("customercode",custCode);
		notificationInputBO.setTemplateValues(templateValues);
		notificationInputBO.setEmailAdresses(emailAddresses.toString());
		return notificationInputBO;	
	}
	
	public Map<String,String> getNotificationEmailDetails(Notifications notifications) throws Exception {
		Map<String,String> emailAddresses=new HashMap<>();
		if (notifications.getDefaultEmailAddresses() != null )
			emailAddresses.put("default", notifications.getDefaultEmailAddresses());
		List<NotificationStatus> notificationStatusList=notifications.getNotificationStatuses();
		for (NotificationStatus notificationStatus :notificationStatusList){
			if (notificationStatus.getIsEnabled()){
				if( notificationStatus.getEmailAddresses() !=null)
					emailAddresses.put(notificationStatus.getName(), notificationStatus.getEmailAddresses());
				else 
					emailAddresses.put(notificationStatus.getName(), "-");
			}
		}
		return emailAddresses;	
	}
}

package com.zetainteractive.zetahub.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;

/**
 * 
 * @author Krishna.Polisetti
 *
 */
public class CategoryRowMapper implements RowMapper<CategoryBO> {

	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	@Override
	public CategoryBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		CategoryBO categoryBO = new CategoryBO();
		categoryBO.setCategoryid(rs.getLong("categoryid"));
		categoryBO.setCategorycode(rs.getString("categorycode"));
		categoryBO.setDepartmentid(rs.getLong("departmentid"));
		categoryBO.setDescription(rs.getString("description"));
		categoryBO.setType(rs.getString("type").charAt(0));
		categoryBO.setCreatedBy(rs.getString("createdby"));
		try {
			categoryBO.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			categoryBO.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return categoryBO;
		
	}
	
	
}

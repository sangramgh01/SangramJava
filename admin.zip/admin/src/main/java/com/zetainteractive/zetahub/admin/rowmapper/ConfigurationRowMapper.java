package com.zetainteractive.zetahub.admin.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.commons.domain.ConfigurationBO;

/**
 * 
 * @author Krishna.Polisetti
 *
 */
public class ConfigurationRowMapper implements RowMapper<ConfigurationBO> {

	@Override
	public ConfigurationBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ConfigurationBO configurationBO = new ConfigurationBO();
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			configurationBO.setConfigurationId(rs.getLong("configurationid"));
			configurationBO.setObjectKey(rs.getString("objectkey"));
			configurationBO.setObjectValue(objectMapper.readValue(rs.getString("objectvalue"), Object.class));
			configurationBO.setCreatedBy(rs.getString("createdby"));
			configurationBO.setCreateDate(rs.getDate("createdate"));
			configurationBO.setUpdatedBy(rs.getString("updatedby"));
			configurationBO.setUpdateDate(rs.getDate("updatedate"));
		} catch (IOException e) {
			throw new SQLException("Unable to convert JSON, invalid value.", e);
		}
		return configurationBO;
		
	}
	
	
}

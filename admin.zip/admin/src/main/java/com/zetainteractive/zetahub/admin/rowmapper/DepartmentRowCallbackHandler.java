package com.zetainteractive.zetahub.admin.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang.BooleanUtils;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowCallbackHandler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AddressListBO;
import com.zetainteractive.zetahub.commons.domain.AdobeAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.GoogleAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.KeyWord;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.OtherWebAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.ParametersBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.UnsubRulesBO;

import ch.qos.logback.classic.Logger;

/**
 * @author Lakshmi.Medarametla
 *
 */
public class DepartmentRowCallbackHandler implements RowCallbackHandler {

	private DepartmentBO department;
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/** The logger. */
	Logger logger = (Logger) LoggerFactory.getLogger(getClass());
	@Override
	public void processRow(ResultSet rs) throws SQLException {
		try {
			/*Department loaded with default values*/
			if(department==null){
				this.department = new DepartmentBO();
				this.department.setDepartmentSettings(new ArrayList<DepartmentSettings>());
			}

			/*Begin :: Load Object Mapper*/
			ObjectMapper objectMapper = new ObjectMapper();
			TypeReference<List<DeptAudienceBO>> mapType = new TypeReference<List<DeptAudienceBO>>() {};
			objectMapper.setDateFormat(sd);
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			TypeFactory typeFactory = objectMapper.getTypeFactory();
			/*End :: Load Object Mapper*/
			
			/*Load Department Properties*/
			department.setDepartmentID(rs.getLong("departmentid"));
			department.setDepartmentName(rs.getString("departmentname"));
			department.setApprovalMandatory(BooleanUtils.toBoolean(rs.getString("approvalmandatory"),"Y","N"));
			department.setDomainKeysUsed(BooleanUtils.toBoolean(rs.getString("domainkey"),"Y","N"));
			department.setRestrictedDomainsExists(BooleanUtils.toBoolean(rs.getString("restrictedDomainsExists"),"Y","N"));
			department.setCreatedBy(rs.getString("departmentCreatedBy"));
			try {
				department.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("departmentCreatedDate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				department.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("departmentUpdatedDate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			}  catch (Exception e) {
				e.printStackTrace();
			}
			department.setUpdatedBy(rs.getString("departmentUpdatedBy"));
			/*Create And Load Settings Obj*/
			if(rs.getLong("departmentsettingid") > 0){
				DepartmentSettings deptSettings=new DepartmentSettings();
				deptSettings.setDepartmentID(rs.getLong("departmentid"));
				deptSettings.setDepartmentSettingId(rs.getLong("departmentsettingid"));
				deptSettings.setCreatedBy(rs.getString("settingCreatedBy"));
				deptSettings.setUpdatedBy(rs.getString("settingUpdatedBy"));
				try {
					deptSettings.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("settingCreatedDate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					deptSettings.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("settingUpdatedDate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				}  catch (Exception e) {
					e.printStackTrace();
				}
				/*Parse JSON of setting object into corresponding bo*/
				String objectkey = rs.getString("objectkey");
				String objectvalue = rs.getString("objectvalue");
				deptSettings.setObjectKey(objectkey);
				if (Constants.DEPARTMENT_PARAMETERS_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue, ParametersBO.class));
				else if (Constants.DEPARTMENT_ADDRESSLIST_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue, AddressListBO.class));
				else if (Constants.DEPARTMENT_UNSUBRULES_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue, UnsubRulesBO.class));
				else if (Constants.DEPARTMENT_NOTIFICATIONS_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue, NotificationBO.class));
				else if (Constants.DEPARTMENT_GOOGLEANALYTICS_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue,GoogleAnalyticsBO.class));
				else if (Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue,AdobeAnalyticsBO.class));
				else if (Constants.DEPARTMENT_OTHERWEBANALYTICS_KEY.equalsIgnoreCase(objectkey))
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue,OtherWebAnalyticsBO.class));
				else if (Constants.DEPARTMENT_MOBILE_KEY.equalsIgnoreCase(objectkey)){
					MobileBO mobileBO = objectMapper.readValue(objectvalue,MobileBO.class);
					for(ShortCode shortCode:mobileBO.getShortCodes()){
						try {
							shortCode.setCreateDate(CommonUtil.toLocalTime(shortCode.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							shortCode.setUpdateDate(CommonUtil.toLocalTime(shortCode.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							for(KeyWord keyWord:shortCode.getKeyWords()){
								keyWord.setCreateDate(CommonUtil.toLocalTime(keyWord.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								keyWord.setUpdateDate(CommonUtil.toLocalTime(keyWord.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								}
						
						    } catch (Exception e) {
							  e.printStackTrace();
						}
					}
					
					deptSettings.setObjectValue(mobileBO);
				}else if (Constants.DEPARTMENT_AUDIENCE_KEY.equalsIgnoreCase(objectkey) && objectvalue !=null){
					deptSettings.setObjectValue(objectMapper.readValue(objectvalue,mapType));
				}
					
				/*Add setting object into department list of setting objects*/
				department.getDepartmentSettings().add(deptSettings);
			}
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
			throw new SQLException("Unable to convert JSON, invalid value.", e);
		}
	}

	/**
	 * @return the department
	 */
	public DepartmentBO getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(DepartmentBO department) {
		this.department = department;
	}

}

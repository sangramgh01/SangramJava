package com.zetainteractive.zetahub.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.apache.commons.lang.BooleanUtils;
import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;

/**
 * Only map department properties but not settings.
 * @author Lakshmi.Medarametla
 */
public class DepartmentRowMapper implements RowMapper<DepartmentBO>{
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	@Override
	public DepartmentBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		DepartmentBO department=new DepartmentBO();
		try {
			department.setDepartmentID(rs.getLong("departmentid"));
			department.setDepartmentName(rs.getString("departmentname"));
			department.setApprovalMandatory(BooleanUtils.toBoolean(rs.getString("approvalmandatory"),"Y","N"));
			department.setDomainKeysUsed(BooleanUtils.toBoolean(rs.getString("domainkey"),"Y","N"));
			department.setRestrictedDomainsExists(BooleanUtils.toBoolean(rs.getString("restricteddomainstatus"),"Y","N"));
			department.setCreatedBy(rs.getString("createdby"));
			department.setUpdatedBy(rs.getString("updatedby"));
			try {
				department.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				department.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			throw new SQLException("Unable to prepare DepartmentBO.", e);
		}
		return department;
	}

}

/**
 * DepartmentSettingsRowMapper.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AddressListBO;
import com.zetainteractive.zetahub.commons.domain.AdobeAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.GoogleAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.KeyWord;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.OtherWebAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.ParametersBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.UnsubRulesBO;

/**
 * 
 * @Author	     : Sreekhar.Kandala
 * @Created On  : 23 Jan 2018 16:29:57
 * @Version	     : 1.7 
 * @Description  : "DepartmentSettingsRowMapper" is used for 
 * 
 **/

public class DepartmentSettingsRowMapper implements RowMapper<DepartmentSettings> {
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	ZetaLogger logger = new ZetaLogger(getClass());

	@Override
	public DepartmentSettings mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		DepartmentSettings deptSettings = new DepartmentSettings();
		ObjectMapper objectMapper = new ObjectMapper();
		TypeReference<List<DeptAudienceBO>> mapType = new TypeReference<List<DeptAudienceBO>>() {};
		objectMapper.setDateFormat(sd);
		try {

			deptSettings.setDepartmentID(rs.getLong("departmentid"));
			deptSettings.setDepartmentSettingId(rs.getLong("departmentsettingid"));
			deptSettings.setCreatedBy(rs.getString("createdby"));
			deptSettings.setUpdatedBy(rs.getString("updatedby"));
			try {
				deptSettings.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				deptSettings.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			}  catch (Exception e) {
				logger.error(e.getMessage(),e);
			}
			/*Parse JSON of setting object into corresponding bo*/
			String objectkey = rs.getString("objectkey");
			String objectvalue = rs.getString("objectvalue");
			deptSettings.setObjectKey(objectkey);
			if (Constants.DEPARTMENT_PARAMETERS_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue, ParametersBO.class));
			else if (Constants.DEPARTMENT_ADDRESSLIST_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue, AddressListBO.class));
			else if (Constants.DEPARTMENT_UNSUBRULES_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue, UnsubRulesBO.class));
			else if (Constants.DEPARTMENT_NOTIFICATIONS_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue, NotificationBO.class));
			else if (Constants.DEPARTMENT_GOOGLEANALYTICS_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue,GoogleAnalyticsBO.class));
			else if (Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue,AdobeAnalyticsBO.class));
			else if (Constants.DEPARTMENT_OTHERWEBANALYTICS_KEY.equalsIgnoreCase(objectkey))
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue,OtherWebAnalyticsBO.class));
			else if (Constants.DEPARTMENT_MOBILE_KEY.equalsIgnoreCase(objectkey)){
				MobileBO mobileBO = objectMapper.readValue(objectvalue,MobileBO.class);
				for(ShortCode shortCode:mobileBO.getShortCodes()){
					try {
						shortCode.setCreateDate(CommonUtil.toLocalTime(shortCode.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						shortCode.setUpdateDate(CommonUtil.toLocalTime(shortCode.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						for(KeyWord keyWord:shortCode.getKeyWords()){
							keyWord.setCreateDate(CommonUtil.toLocalTime(keyWord.getCreateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							keyWord.setUpdateDate(CommonUtil.toLocalTime(keyWord.getUpdateDate().getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							}
					
					    } catch (Exception e) {
					    	logger.error(e.getMessage(),e);
					}
				}
				
				deptSettings.setObjectValue(mobileBO);
			}else if (Constants.DEPARTMENT_AUDIENCE_KEY.equalsIgnoreCase(objectkey) && objectvalue !=null){
				deptSettings.setObjectValue(objectMapper.readValue(objectvalue,mapType));
			}
				
		} catch (IOException e) {
			throw new SQLException("Unable to convert JSON, invalid value.", e);
		}
		return deptSettings;
		
	}

}

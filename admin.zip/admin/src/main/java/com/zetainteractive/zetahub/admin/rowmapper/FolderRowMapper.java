package com.zetainteractive.zetahub.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.FolderBO;

/**
 * 
 * @author Krishna.Polisetti
 *
 */
public class FolderRowMapper implements RowMapper<FolderBO> {
	
	@Override
	public FolderBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		FolderBO folderBO = new FolderBO();
		folderBO.setFolderid(rs.getLong("folderid"));
		folderBO.setFoldername(rs.getString("foldername"));
		folderBO.setDepartmentid(rs.getLong("departmentid"));
		folderBO.setParentfolderid(rs.getLong("parentfolderid"));
		folderBO.setType(rs.getString("type").charAt(0));
		folderBO.setCreatedBy(rs.getString("createdby"));
		
		folderBO.setUpdatedBy(rs.getString("updatedby"));
		try {
			folderBO.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			folderBO.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return folderBO;
		
	}
	
	
}

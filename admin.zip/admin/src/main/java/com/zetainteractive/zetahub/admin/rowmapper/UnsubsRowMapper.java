/**
 * UnsubsRowMapper.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.Unsubs;

/**
 * 
 * @Author	     : Dilleswara.Doppa
 * @Created On  : Aug 12, 2016 5:28:18 PM
 * @Version	     : 1.7 
 * @Description  : "UnsubsRowMapper" is used for 
 * 
 **/

public class UnsubsRowMapper implements RowMapper<Unsubs>{
	
	/**
	 * 
	 * Method Name 	: mapRow
	 * Description 		: The Method "mapRow" is used for 
	 * Date    			: Aug 12, 2016, 5:33:47 PM
	 * @param rs
	 * @param rowNum
	 * @return
	 * @throws SQLException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	@Override
	public Unsubs mapRow(ResultSet rs, int rowNum) throws SQLException {
		Unsubs unsubs = new Unsubs();
		unsubs.setUnsubKeywordId(rs.getLong("unsubKeywordId"));
		unsubs.setUnsubKeyword(rs.getString("unsubKeyword"));
		unsubs.setStatus(rs.getString("status").charAt(0));
		unsubs.setCreatedBy(rs.getString("createdby"));
		unsubs.setUpdatedBy(rs.getString("updatedby"));
		unsubs.setType(rs.getString("type"));
		unsubs.setCategory(rs.getString("category"));
		try {
			unsubs.setCreateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("createdate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			unsubs.setUpdateDate(CommonUtil.toLocalTime(sd.parse(rs.getString("updatedate")).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return unsubs;
	}

}


/**
 * 
 */
package com.zetainteractive.zetahub.admin.service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.AddressTypeBO;
import com.zetainteractive.zetahub.commons.domain.ConfigurationBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.DomainBO;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.RestrictedDomainsBO;

/**
 * @author Krishna.Polisetti
 * @created on 01/07/2016
 * @desc ConfigurationService
 */
public interface ConfigurationService {
	
	
	/**
	 * 
	 * 
	 * Method Name 	: listEncryptionKeys
	 * Description 	: The Method "listEncryptionKeys" is used for 
	 * Date    		: Jul 29, 2016, 8:44:10 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<EncryptionKeyBO>
	 * @throws 		:
	 */
	public List<EncryptionKeyBO> listEncryptionKeys() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: createEncryptionKey
	 * Description 	: The Method "createEncryptionKey" is used for 
	 * Date    		: Jul 29, 2016, 8:44:15 PM
	 * @param encryptionKey
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long createEncryptionKey(EncryptionKeyBO encryptionKey,BindingResult bindingResult) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: deleteEncryptionKey
	 * Description 	: The Method "deleteEncryptionKey" is used for 
	 * Date    		: Jul 29, 2016, 8:44:20 PM
	 * @param encryptionKey
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean deleteEncryptionKey(String encryptionKey) throws AdminException;
	/* End of EncryptionKey */
	
	/* DBSource: listDbSources,getDBSource, createDBSource, deleteDBSource*/
	/**
	 * 
	 * 
	 * Method Name 	: listDBSources
	 * Description 	: The Method "listDBSources" is used for 
	 * Date    		: Jul 29, 2016, 8:44:26 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<DbSourceBO>
	 * @throws 		:
	 */
	public List<DbSourceBO> listDBSources()  throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: getDBSource
	 * Description 	: The Method "getDBSource" is used for 
	 * Date    		: Jul 29, 2016, 8:44:32 PM
	 * @param dbSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: DbSourceBO
	 * @throws 		:
	 */
	public DbSourceBO getDBSource(String dbSourceName)  throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: createDBSource
	 * Description 	: The Method "createDBSource" is used for 
	 * Date    		: Jul 29, 2016, 8:44:39 PM
	 * @param dbSource
	 * @param bindingResult 
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long createDBSource(DbSourceBO dbSource, BindingResult bindingResult) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: deleteDBSource
	 * Description 	: The Method "deleteDBSource" is used for 
	 * Date    		: Jul 29, 2016, 8:44:45 PM
	 * @param dbSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean deleteDBSource(String dbSourceName)  throws AdminException;
	/* End of DbSource */
	
	/* FileSource: listFileSources, getFileSource, createFileSource, deleteFileSource, getTotalFilesourceCount */
	/**
	 * 
	 * 
	 * Method Name 	: listFileSources
	 * Description 	: The Method "listFileSources" is used for 
	 * Date    		: Jul 29, 2016, 8:44:51 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<FileSourceBO>
	 * @throws 		:
	 */
	public List<FileSourceBO> listFileSources() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: getFileSource
	 * Description 	: The Method "getFileSource" is used for 
	 * Date    		: Jul 29, 2016, 8:44:56 PM
	 * @param fileSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: FileSourceBO
	 * @throws 		:
	 */
	public FileSourceBO getFileSource(String fileSourceName) throws AdminException ;
	/**
	 * 
	 * 
	 * Method Name 	: createFileSource
	 * Description 	: The Method "createFileSource" is used for 
	 * Date    		: Jul 29, 2016, 8:45:01 PM
	 * @param fileSource
	 * @param bindingResult 
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long createFileSource(FileSourceBO fileSource, BindingResult bindingResult) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: deleteFileSource
	 * Description 	: The Method "deleteFileSource" is used for 
	 * Date    		: Jul 29, 2016, 8:45:06 PM
	 * @param fileSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean deleteFileSource(String fileSourceName) throws AdminException;
	/* End of FileSource */
	
	/* Address Types: isAddressTypeExist, listAddressTypes, saveAddressType */
	/**
	 * 
	 * 
	 * Method Name 	: isAddressTypeExist
	 * Description 	: The Method "isAddressTypeExist" is used for 
	 * Date    		: Jul 29, 2016, 8:45:12 PM
	 * @param addressTypeName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean isAddressTypeExist(String addressTypeName) throws AdminException;
	
	/**
	 * 
	 * 
	 * Method Name 	: saveAddressType
	 * Description 	: The Method "saveAddressType" is used for 
	 * Date    		: Jul 29, 2016, 8:45:17 PM
	 * @param addressType
	 * @param bindingResult 
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long saveAddressType(AddressTypeBO addressType, BindingResult bindingResult) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: listAddressTypes
	 * Description 	: The Method "listAddressTypes" is used for 
	 * Date    		: Jul 29, 2016, 8:45:22 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<AddressTypeBO>
	 * @throws 		:
	 */
	public List<AddressTypeBO> listAddressTypes() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: getTotalAddressTypesCount
	 * Description 	: The Method "getTotalAddressTypesCount" is used for 
	 * Date    		: Jul 29, 2016, 8:45:26 PM
	 * @param listingCriteria
	 * @param result
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long getTotalAddressTypesCount(ListingCriteria listingCriteria, BindingResult result) throws AdminException;
	/* End of AddressType */
	
	/* Restricted Domains: getRestrictedDomains, updateRestrictedDomains, delete, download*/
	/**
	 * 
	 * 
	 * Method Name 	: listRestrictedDomains
	 * Description 	: The Method "listRestrictedDomains" is used for 
	 * Date    		: Jul 29, 2016, 8:45:31 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: RestrictedDomainsBO
	 * @throws 		:
	 */
	public RestrictedDomainsBO listRestrictedDomains() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: updateRestrictedDomains
	 * Description 	: The Method "updateRestrictedDomains" is used for 
	 * Date    		: Jul 29, 2016, 8:45:36 PM
	 * @param restrictedDomain
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long updateRestrictedDomains(RestrictedDomainsBO restrictedDomain) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: getRestrictedDomainsWithDepartmentsList
	 * Description 	: The Method "getRestrictedDomainsWithDepartmentsList" is used for 
	 * Date    		: Jul 29, 2016, 8:45:42 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List
	 * @throws 		:
	 */
	public List getRestrictedDomainsWithDepartmentsList() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: downloadRSDomains
	 * Description 	: The Method "downloadRSDomains" is used for 
	 * Date    		: Jul 29, 2016, 8:45:47 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: ByteArrayOutputStream
	 * @throws 		:
	 */
	public ByteArrayOutputStream downloadRSDomains() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: saveRestrictedDomains
	 * Description 	: The Method "saveRestrictedDomains" is used for 
	 * Date    		: Jul 29, 2016, 8:45:52 PM
	 * @param fileData
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List
	 * @throws 		:
	 */
	public List saveRestrictedDomains(byte[] fileData) throws AdminException;

	/* End of Restricted Domains */
	
	/* Domain: saveDomain, updateDomain, listDomains, deleteDomain, getTotalDomainsCount */
	/**
	 * 
	 * 
	 * Method Name 	: saveDomain
	 * Description 	: The Method "saveDomain" is used for 
	 * Date    		: Jul 29, 2016, 8:46:01 PM
	 * @param domain
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Long
	 * @throws 		:
	 */
	public Long saveDomain(DomainBO domain,BindingResult bindingResult) throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: listDomains
	 * Description 	: The Method "listDomains" is used for 
	 * Date    		: Jul 29, 2016, 8:46:06 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<DomainBO>
	 * @throws 		:
	 */
	public List<DomainBO> listDomains() throws AdminException;
	/**
	 * 
	 * 
	 * Method Name 	: deleteDomain
	 * Description 	: The Method "deleteDomain" is used for 
	 * Date    		: Jul 29, 2016, 8:46:11 PM
	 * @param code
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean deleteDomain(String code) throws AdminException;
	/**
	 * 
	 * Method Name 	: saveActiveRestrictedDomainforDept
	 * Description 	: The Method "saveActiveRestrictedDomainforDept" is used for 
	 * Date    		: Jul 29, 2016, 8:36:42 PM
	 * @param restrictedDomainDeptList
	 * @return
	 * @param  		:
	 * @return 		: List
	 * @throws AdminException 
	 * @throws 		: 
	 */
	public Boolean saveActiveRestrictedDomainforDept(List restrictedDomainDeptList) throws AdminException;
	
	
	

}


/**
 * 
 */
package com.zetainteractive.zetahub.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;
import com.zetainteractive.zetahub.commons.domain.ContentTemplateBO;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * @author Krishna.Polisetti
 *
 */
public interface DepartmentService {
	
	/**
	 * @param departmentId
	 * @param propertyKey
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public DepartmentSettings getDepartmentSpecificProperty(Long departmentId,String propertyKey,BindingResult bindingResult) throws AdminException;

	/**
	 * @param departmentSettings
	 * @param bindingResult
	 * @throws AdminException 
	 */
	public void updateDepartmentSpecificProperty(DepartmentSettings departmentSettings,BindingResult bindingResult) throws AdminException;
	 
	
	/**
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public DepartmentBO getDepartment(Long deptId) throws AdminException,Exception;
	
	/**
	 * @param deptId
	 * @throws AdminException
	 */
	public void deleteDepartment(Long deptId) throws AdminException;
	
	
	/**
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public Boolean isDepartmentExists(Long deptId) throws AdminException;
	
	/**
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public List<DepartmentBO> listDepartments(ListingCriteria listingCriteria,BindingResult bindingResult) throws AdminException;
	
	/**
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public Long departmentsTotalCount(ListingCriteria listingCriteria,BindingResult bindingResult) throws AdminException;
	
	
	/**
	 * @param departmentName
	 * @return
	 * @throws AdminException
	 */
	public Boolean departmentNameExists(String departmentName) throws AdminException;
	

	/**
	 * @param department
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 */
	public Long saveDepartment(DepartmentBO department,BindingResult bindingResult) throws AdminException;
	
	/**
	 * @param folder
	 * @param bindingResult
	 * @return FolderBO
	 */
	public FolderBO saveFolder(FolderBO folder,BindingResult bindingResult) throws AdminException;
	
	/**
	 * @param folderId
	 * @param exceptions
	 * @return FolderBO
	 * @throws AdminException 
	 */
	public FolderBO getFolder(Long folderId) throws AdminException;
	
	/**
	 * @param listingCriteria
	 * @param result 
	 * @return List<FolderBO>
	 */
	public List<FolderBO> listFolders(FoldersListingCriteria listingCriteria, BindingResult result) throws AdminException;
	
	/**
	 * @param folderId
	 * @return Boolean
	 */
	public Boolean deleteFolder(Long folderId) throws AdminException;
	
	/**
	 * @param category
	 * @param exceptions
	 * @return CategoryBO
	 */
	public CategoryBO saveCategory(CategoryBO category, BindingResult result) throws AdminException;
	
	/**
	 * @param categoryId
	 * @return CategoryBO
	 * @throws AdminException 
	 */
	public CategoryBO getCategory(Long categoryId) throws AdminException;
	
	/**
	 * @param listingCriteria
	 * @param errors
	 * @return
	 * @throws AdminException
	 */
	public List<CategoryBO> listCategories(CategoriesListingCriteria listingCriteria,Errors errors) throws AdminException;
	
	/**
	 * @param categoryId
	 * @return Boolean
	 * @throws AdminException 
	 */
	public Boolean deleteCategory(Long categoryId) throws AdminException;
	
	
	/**
	 * @param departmentName
	 * @param approvalNeeded
	 * @param domainKeysNeeded
	 * @param bindingResult
	 * @return
	 */
	public DepartmentBO createDepartment(String departmentName,Boolean approvalNeeded,Boolean domainKeysNeeded,BindingResult bindingResult);

	/**
	 * @param deptId
	 * @param errors
	 * @return
	 */
	public Boolean isDepartmentExists(Long deptId, Errors errors);
	
	/**
	 * @param departmentName
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public Boolean departmentNameExists(String departmentName,BindingResult bindingResult) throws AdminException;
	
	/**
	 * @param domainCode
	 * @param bindingResult
	 * @throws AdminException
	 */
	public void addDomainToDepartmentOptoutRules(String domainCode,BindingResult bindingResult) throws AdminException,Exception;
	
	/**
	 * @param domainCode
	 * @throws AdminException
	 */
	public void deleteDomainFromDepartmentOptoutRules(String domainCode) throws AdminException;
	
	/**
	 * Check if category exists with type and dept.
	 *
	 * @param categoryName the category name
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return the boolean
	 * @throws AdminException the admin exception
	 */
	public Boolean checkIfCategoryExistsWithTypeAndDept(String categoryCode,Character type,Long deptId, Long categoryId) throws AdminException ;
	
	/**
	 * Find category by type and dept.
	 *
	 * @param categoryName the category name
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return the category bo
	 * @throws AdminException the admin exception
	 */
	public CategoryBO findCategoryByTypeAndDept(Character type, String categoryCode, Long deptId)
			throws AdminException;
	
	/**
	 * Check if folder exists with type and dept.
	 *
	 * @param folderName the folder name
	 * @param type the type
	 * @param deptId the dept id
	 * @return the boolean
	 * @throws AdminException the admin exception
	 */
	public Boolean checkIfFolderExists(String folderName, Character type, Long deptId, Long folderId) throws AdminException;
	
	/**
	 * Find folder by type and dept.
	 *
	 * @param folderName the folder name
	 * @param type the type
	 * @param deptId the dept id
	 * @return the folder bo
	 * @throws AdminException the admin exception
	 */
	public FolderBO findFolder(String folderName, Character type, Long deptId) throws AdminException;
	
	/**
	 * @param folderId
	 * @return
	 * @throws AdminException
	 */
	public List<Conversation> getConversationsByFolderId(Long folderId) throws AdminException;
	
	/**
	 * @param folderId
	 * @return
	 * @throws AdminException
	 */
	public List<ContentTemplateBO> getContentsByFolderId(Long folderId) throws AdminException;
	
	/**
	 * 
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public List<Conversation> getTrashConversations(Long deptId) throws AdminException;
	
	/**
	 * 
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	public List<ContentTemplateBO> getTrashContents(Long folderId) throws AdminException;
	
	/**
	 * 
	 * @param convIds
	 * @return
	 * @throws AdminException
	 */
	public String restoreConversations(List<Long> convIds) throws AdminException;
	
	/**
	 * 
	 * @param contentIds
	 * @return
	 * @throws AdminException
	 */
	public Boolean restoreContents(String templateIds,String templateType) throws AdminException;
	
	/**
	 * 
	 * @param convIds
	 * @return
	 * @throws AdminException
	 */
	public String emptyTrashConversations(List<Long> convIds) throws AdminException;
	
	/**
	 * 
	 * @param selectedTrashId
	 * @param selectedTemplateType
	 * @return
	 * @throws AdminException
	 */
	public Boolean emptyTrashContents(String selectedTrashId,String selectedTemplateType) throws AdminException;
	
	/**
	 * 
	 * @param ids
	 * @return
	 * @throws AdminException
	 */
	public Boolean deleteConversations(List<Long> ids) throws AdminException;
	
	/**
	 * 
	 * @param ids
	 * @return
	 * @throws AdminException
	 */
	public Boolean deleteContents(String templateIds,String templateType) throws AdminException;
	/**
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public List<DepartmentBO> getAllDepartments(ListingCriteria listingCriteria, BindingResult bindingResult) throws AdminException;
	
	/**
	 * @param departmentName
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	public Boolean isDepartmentExistsByNameOrId(Map<String,String> json) throws AdminException;
	
	/**
	 * 
	 * 
	 * Method Name 	: isDepartmentExistsByNameOrId
	 * Description 	: The Method "isDepartmentExistsByNameOrId" is used for providing audience access to all departments.
	 * Date    		: 23 Jan 2018, 16:11:23
	 * @param json
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		:
	 */
	public Boolean accessAudienceToAllDepartments(Long audienceId) throws Exception;
	
	/**
	 * 
	 * 
	 * Method Name 	: getDeptSpecificAudiences
	 * Description 	: The Method "getDeptSpecificAudiences" is used for getting department specific audiences.
	 * Date    		: 24 Jan 2018, 11:21:24
	 * @param departmentId
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: List<DeptAudienceBO>
	 * @throws 		:
	 */
	public List<DeptAudienceBO> getDeptSpecificAudiences(Long departmentId) throws Exception;

	List<DepartmentSettings> getAllDepartmentSettings() throws AdminException;
}

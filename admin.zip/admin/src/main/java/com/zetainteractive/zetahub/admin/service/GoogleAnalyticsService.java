package com.zetainteractive.zetahub.admin.service;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.GAAccount;

/**
 * @author Lakshmi.Medarametla
 *
 */
public interface GoogleAnalyticsService {
	
	/**
	 * This method is used to get ga authorization url.
	 * @return
	 * @throws AdminException
	 */
	public String getGAAuthURL() throws AdminException;
	
	/**
	 * @param gaAccProObj
	 * @param bindingResult
	 * @return
	 */
	public GAAccount authorizeGoogleAnalyticsProfile(GAAccount gaAccProObj,BindingResult bindingResult);
}

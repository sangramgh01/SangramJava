/**
 * MeterQueueService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.service;

import java.util.List;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MeterQueue;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Aug 1, 2016 8:49:04 PM
 * @Version : 1.7
 * @Description : "MeterQueueService" is used for
 * 
 **/

public interface MeterQueueService {

	/**
	 * Save meter queue.
	 *
	 * @param meterQueue
	 *            the meter queue
	 * @param isDefaultOverride 
	 * @return the long
	 * @throws AdminException
	 */
	public Integer saveMeterQueue(MeterQueue meterQueue, Boolean isDefaultOverride, BindingResult result) throws AdminException;

	/**
	 * Delete meter queue.
	 *
	 * @param meterQueueId
	 *            the meter queue id
	 * @return the boolean
	 * @throws AdminException
	 * @throws AdminException 
	 */
	public Boolean deleteMeterQueue(Integer meterQueueId) throws  AdminException;

	/**
	 * Find meter queue by id.
	 *
	 * @param meterQueueId
	 *            the meter queue id
	 * @return the meter queue
	 * @throws AdminException
	 */
	public MeterQueue findMeterQueueById(Integer meterQueueId) throws AdminException;

	/**
	 * Find meter queue by name.
	 *
	 * @param meterQueueName
	 *            the meter queue name
	 * @return the meter queue
	 * @throws AdminException
	 */
	public MeterQueue findMeterQueueByName(String meterQueueName) throws AdminException;

	/**
	 * Checks if is meter queue exists.
	 *
	 * @param meterQueueName            the meter queue name
	 * @param meterQueueId the meter queue id
	 * @return the boolean
	 * @throws AdminException the admin exception
	 */
	public Boolean isMeterQueueExists(String meterQueueName,Integer meterQueueId) throws AdminException;
	/**
	 * 
	 * Method Name 	: findMeterQueuesByCriteria
	 * Description 	: The Method "findMeterQueuesByCriteria" is used for 
	 * Date    		: Aug 2, 2016, 11:55:07 AM
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: List<MeterQueue>
	 * @throws 		: 
	 */
	List<MeterQueue> findMeterQueuesByCriteria(ListingCriteria listingCriteria, BindingResult bindingResult)
			throws AdminException;

	/**
	 * Method Name 	: listMeterQueues
	 * Description 	: The Method "listMeterQueues" is used for 
	 * Date    		: Aug 4, 2016, 8:21:24 PM.
	 *
	 * @param fetchType the fetch type
	 * @return 		: List<MeterQueue>
	 * @throws AdminException the admin exception
	 */
	public List<MeterQueue> listMeterQueues(String fetchType) throws AdminException;

	/**
	 * 
	 * Method Name 	: isDefaultMeterQueueExistsForClient
	 * Description 	: The Method "isDefaultMeterQueueExistsForClient" is used for 
	 * Date    		: Aug 8, 2016, 3:22:57 PM
	 * @param customerID
	 * @return
	 * @param  		:
	 * @return 		: MeterQueue
	 * @throws 		: 
	 */
	public MeterQueue isDefaultMeterQueueExistsForClient(Integer customerID) throws AdminException;

}

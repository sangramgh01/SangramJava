package com.zetainteractive.zetahub.admin.service;

import java.util.List;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.TestGroup;

public interface MobileService {
	/**
	 * Get MobileBO for the given department
	 * 
	 * @param departmentId
	 * @param bindingResult
	 * @return
	 * @throws AdminException 
	 */
	MobileBO getMobileBOForDepartment(Long departmentId, BindingResult result) throws AdminException;

	/**
	 * Get list of mobile short codes for the given department
	 * 
	 * @param departmentId
	 * @param result
	 * @return
	 * @throws AdminException 
	 */
	List<ShortCode> listShortCodes(Long departmentId, BindingResult result) throws AdminException;

	/**
	 * create/update Mobile Group data for the given department
	 * 
	 * @param departmentId
	 * @param testGroups
	 * @param result
	 * @return
	 */
	List<TestGroup> createTestGroup(Long departmentId, List<TestGroup> testGroups, BindingResult result)throws Exception;

	/**
	 * Get mobile group data for the given department
	 * 
	 * @param departmentId
	 * @param result
	 * @return
	 * @throws AdminException 
	 */
	List<TestGroup> listTestGroups(Long departmentId, BindingResult result) throws AdminException;

	List<TestGroup> updateTestGroup(Long departmentID, List<TestGroup> newTestGroups, BindingResult bindingResult)throws Exception;
}

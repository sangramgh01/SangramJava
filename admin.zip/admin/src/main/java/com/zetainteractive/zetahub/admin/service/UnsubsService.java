/**
 * UnsubsService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.service;

import java.util.List;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.Unsubs;

/**
 * 
 * @Author : srinivasa.katta
 * @Created On : Aug 12, 2016 4:08:32 PM
 * @Version : 1.7
 * @Description : "UnsubsService" is used for
 * 
 **/

public interface UnsubsService {
	/**
	 * Save unsubs.
	 *
	 * @param unsub
	 *            the unsub
	 * @param unsubType
	 *            the unsub type
	 * @return the long
	 * @throws AdminException
	 *             the admin exception
	 */
	public Long saveUnsubs(Unsubs unsub, String unsubType, BindingResult bindingResult) throws AdminException;

	/**
	 * Delete unsubs.
	 *
	 * @param unsubId
	 *            the unsub id
	 * @return the boolean
	 * @throws AdminException
	 *             the admin exception
	 */
	public Boolean deleteUnsubs(Long unsubId, String unsubType) throws AdminException;

	/**
	 * Find unsub by id.
	 *
	 * @param unsubId
	 *            the unsub id
	 * @param unsubType
	 *            the unsub type
	 * @return the unsubs
	 * @throws AdminException
	 *             the admin exception
	 */
	public Unsubs findUnsubById(Long unsubId, String unsubType) throws AdminException;

	/**
	 * 
	 * Method Name : findUnsubByName Description : The Method "findUnsubByName"
	 * is used for Date : Aug 12, 2016, 7:05:17 PM
	 * 
	 * @param keywordName
	 * @param ubsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return : Unsubs
	 * @throws :
	 */

	public Unsubs findUnsubByName(String keywordName, String ubsubType) throws AdminException;

	/**
	 * 
	 * Method Name : isUnsubsExists Description : The Method "isUnsubsExists" is
	 * used for Date : Aug 12, 2016, 7:02:24 PM
	 * 
	 * @param keywordName
	 * @param unsubId
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return : Boolean
	 * @throws :
	 */
	public Boolean isUnsubsExists(String keywordName, Long unsubId,String unsubType) throws AdminException;

	/**
	 * 
	 * Method Name : listUnsubs Description : The Method "listUnsubs" is used
	 * for Date : Aug 12, 2016, 7:05:33 PM
	 * 
	 * @param fetchType
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return : List<Unsubs>
	 * @throws :
	 */
	public List<Unsubs> listUnsubs(String fetchType, String unsubType) throws AdminException;
}

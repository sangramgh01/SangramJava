package com.zetainteractive.zetahub.admin.service;

import com.zetainteractive.zetahub.admin.exception.AdminException;

/**
 * @author Lakshmi.Medarametla
 *
 */
public interface WebPageService {
	public Boolean saveDefaultWebPages(Long departmentID) throws AdminException;
}

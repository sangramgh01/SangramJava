
/**
 * 
 */
package com.zetainteractive.zetahub.admin.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.Vector;
import java.util.regex.Pattern;

import org.apache.log4j.Level;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.util.Base64;
import com.zetainteractive.fileutils.bo.FileUtilContext;
import com.zetainteractive.fileutils.exception.FileSystemUtilException;
import com.zetainteractive.fileutils.plugin.FileSystemUtilsPlugin;
import com.zetainteractive.fileutils.plugin.impl.FileSystemUtilPluginFactory;
import com.zetainteractive.fileutils.util.FileSystemTypeConstants;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.ConfigurationDao;
import com.zetainteractive.zetahub.admin.dao.DepartmentDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.ConfigurationService;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.util.AdminDependencyCalls;
import com.zetainteractive.zetahub.admin.util.ExportUtil.ExcelCell;
import com.zetainteractive.zetahub.admin.util.ExportUtil.ExportUtil;
import com.zetainteractive.zetahub.admin.validators.AddressTypeValidator;
import com.zetainteractive.zetahub.admin.validators.DbSourceValidator;
import com.zetainteractive.zetahub.admin.validators.DomainValidator;
import com.zetainteractive.zetahub.admin.validators.EncryptionKeyValidator;
import com.zetainteractive.zetahub.admin.validators.FileSourceValidator;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AddressTypeBO;
import com.zetainteractive.zetahub.commons.domain.CommonProperties;
import com.zetainteractive.zetahub.commons.domain.ConfigurationBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DomainBO;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.RestrictedDomainsBO;
import com.zetainteractive.zetahub.file.dao.FileDao;
import com.zetainteractive.zetahub.file.exception.FileException;
/**
 * @author Krishna.Polisetti
 *
 */
@Component
public class ConfigurationServiceImpl implements ConfigurationService {
	
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	ConfigurationDao configurationDao;
	@Autowired
	DepartmentService departmentService;
	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;
	@Autowired
	DepartmentDao departmentDao;
	@Autowired
	AddressTypeValidator addressTypeValidator;
	@Autowired
	EncryptionKeyValidator encryptionKeyValidator;
	@Autowired
	FileSourceValidator	fileSourceValidator;
	@Autowired
	DbSourceValidator dbSourceValidator;
	@Autowired
	DomainValidator domainValidator;
	@Autowired
	MessageSource messageSource;
	@Autowired
	FileDao fileDao;
	@Autowired
	AdminDependencyCalls adminDependencyCalls;

	/**
	 * Description: Generic method to return the list of objectkey values of
	 * generic type
	 * 
	 * For ex: getObjectKeyValues(ConfigurationBO cs,Class
	 * <FileFormatBO> className) returns list of FILEFORMAT key values.
	 * 
	 * @param cs
	 * @param className
	 * @return
	 */
	
	public <T extends Object> List<T> getObjectKeyValues(ConfigurationBO cs, Class<T> className) {
		logger.info("Begin:" + getClass().getName() + ":getObjectKeyValues()");
		List<Map<String, Object>> dbList;
		List<T> list = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		mapper.setDateFormat(df);
		if (cs != null) {
			dbList = (List<Map<String, Object>>) cs.getObjectValue();
			for (Map<String, Object> map : dbList) {
				T obj2 = mapper.convertValue(map, className);
				list.add(obj2);
			}
		}
		logger.info("End:" + getClass().getName() + ":getObjectKeyValues()");
		return list;
	}

	

	/**
	 * Method Name 	: listEncryptionKeys
	 * Description 		: The Method "listEncryptionKeys" is used for 
	 * Date    			: Jul 26, 2016, 4:24:37 PM.
	 *
	 * @return 		:
	 * @throws AdminException the admin exception
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<EncryptionKeyBO> listEncryptionKeys() throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":listEncryptionKeys()");
		List<EncryptionKeyBO> encKeyList = new ArrayList<>();
		try {
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_ENCRYPTIONKEY_KEY);
			if (cs != null) {
				encKeyList = getObjectKeyValues(cs, EncryptionKeyBO.class);
				 for(EncryptionKeyBO encryptionKeyBO:encKeyList){
					 try {
						 encryptionKeyBO.setCreateDate(CommonUtil.toLocalTime(encryptionKeyBO.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						 encryptionKeyBO.setUpdateDate(CommonUtil.toLocalTime(encryptionKeyBO.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					 } catch (Exception e) {
						e.printStackTrace();
					}
				 }
				
				
			}
			return encKeyList;
		} catch (Exception e) {
			logger.error("Exception occured while fetching encryption keys", e);
			e.printStackTrace();
			throw new AdminException("ACF0015",e);
		}

	}

	/**
	 * 
	 * Method Name 	: createEncryptionKey
	 * Description 		: The Method "createEncryptionKey" is used for to create Encryption Key
	 * Date    			: Jul 26, 2016, 3:52:29 PM
	 * @param encryptionKey
	 * @param bindingResult
	 * @return configurationID
	 * @throws AdminException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long createEncryptionKey(EncryptionKeyBO encryptionKey, BindingResult bindingResult) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":createEncryptionKey(encryptionKey)");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Create EncryptionKey"); 
		encryptionKeyValidator.validate(encryptionKey, bindingResult);
		ConfigurationBO cs = new ConfigurationBO();
		try {
			event.addField("Create EncryptionKey content received :: ",encryptionKey.getEncryptionKeyName());
			auditManager.audit(event);
			if (!bindingResult.hasErrors()) {
				List<EncryptionKeyBO> encKeyList = new ArrayList<>();
				cs = configurationDao.getConfigurations(Constants.CUSTOMER_ENCRYPTIONKEY_KEY);
				if (cs != null) {
					encKeyList = getObjectKeyValues(cs, EncryptionKeyBO.class);
					Boolean isEdit = false;
					// Return if encryption key already exists
					if (isEncryptionKeyExists(encKeyList, encryptionKey) && (encryptionKey.getCreateDate() == null &&   encryptionKey.getCreatedBy() == null) ) {
						logger.info("Encryption key already exists");
						bindingResult.rejectValue("encryptionKeyName",
								messageSource.getMessage("ACF0023", new Object[] {}, LocaleContextHolder.getLocale()));
						return -1L;
					}
					// Create or update the encryption key
					else {
						if (encryptionKey.getKeyName() != null) { // keyName will be null for new encryption key
							for (EncryptionKeyBO encKeyObj : encKeyList) {
								if (encKeyObj.getKeyName() == null) {
									encKeyObj.setKeyName(
											encKeyObj.getEncryptionKeyName() + "_" + System.currentTimeMillis());
								}
								if (encKeyObj.getKeyName().equalsIgnoreCase(encryptionKey.getKeyName())) {
									encKeyObj.setEncryptionKeyName(encryptionKey.getEncryptionKeyName());
									encKeyObj.setEncryptionType(encryptionKey.getEncryptionType());
									encKeyObj.setKeysize(encryptionKey.getKeysize());
									encKeyObj.setPassphrase(encryptionKey.getPassphrase());
									encKeyObj.setPublickey(encryptionKey.getPublickey());
									encKeyObj.setPrivatekey(encryptionKey.getPrivatekey());
									encKeyObj.setRegistrationtype(encryptionKey.getRegistrationtype());
									setCommonProperties(encKeyObj);
									isEdit = true;
									break;
								}
							}
						}
						// Create encryption key
						if (!isEdit) {
							setCommonProperties(encryptionKey);
							encryptionKey.setKeyName(
									encryptionKey.getEncryptionKeyName() + "_" + System.currentTimeMillis());
							encKeyList.add(encryptionKey);
							
						}
					}
				} // if(cs!=null)
				else {
					cs = new ConfigurationBO();
					cs.setObjectKey(Constants.CUSTOMER_ENCRYPTIONKEY_KEY);
					setCommonProperties(encryptionKey);
					encryptionKey.setKeyName(encryptionKey.getEncryptionKeyName() + "_" + System.currentTimeMillis());
					encKeyList.add(encryptionKey);
				}
				cs.setObjectValue((Object) encKeyList);
				setCommonProperties(cs);
				configurationDao.saveConfigurations(cs);

			}
		} catch (DataAccessException dae) {
			event.addField("Failed Create EncryptionKey content received :: ",encryptionKey.getEncryptionKeyName());
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while creating EncryptionKey", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Create EncryptionKey content received :: ",encryptionKey.getEncryptionKeyName());
			auditManager.audit(event);
			logger.error("JsonProcessingException while creating EncryptionKey", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		} catch (AdminException e) {
			event.addField("Failed Create EncryptionKey content received :: ",encryptionKey.getEncryptionKeyName());
			auditManager.audit(event);
			logger.error("Exception while saving EncryptionKey", e);
			e.printStackTrace();
			throw e;
		}
		logger.info("End:" + getClass().getName() + ":createEncryptionKey(encryptionKey)");
		return cs.getConfigurationId();
	}

	/**
	 * 
	 * Method Name : deleteEncryptionKey Description : The Method
	 * "deleteEncryptionKey" is used for Date : Jul 26, 2016, 4:12:52 PM
	 * 
	 * @param encryptionKey
	 * @return
	 * @param :
	 * @return :
	 * @throws AdminException
	 * @throws :
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteEncryptionKey(String encryptionKey) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":deleteEncryptionKey(encryptionKey)");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Delete EncryptionKey"); 
		Boolean result = false;
		try {
			event.addField("Delete EncryptionKey content received :: ",encryptionKey);
			auditManager.audit(event);
			if(fileDao.isFilEncryptionExist(encryptionKey)){
				return false;
			}else if (adminDependencyCalls.isFileEncryptionExistinConv(encryptionKey)){
				return false;
			}else{
				ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_ENCRYPTIONKEY_KEY);
				if (cs != null) {
					List<Map<String, String>> encKeyList = (List<Map<String, String>>) cs.getObjectValue();
					for (Map<String, String> enckeyMap : encKeyList) {
						if (enckeyMap.get("encryptionKeyName").equalsIgnoreCase(encryptionKey)) {
							encKeyList.remove(enckeyMap);
							result = true;
							break;
						}
					}
					cs.setObjectValue((Object) encKeyList);
					configurationDao.saveConfigurations(cs);
					return result;
				} else {
					logger.warn("Configuration object not found");
					return false;
			}
			}
		} catch (DataAccessException dae) {
			event.addField("Failed Delete EncryptionKey content received :: ",encryptionKey);
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while deleting EncryptionKey", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Delete EncryptionKey content received :: ",encryptionKey);
			auditManager.audit(event);
			logger.error("JsonProcessingException while deleting EncryptionKey", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		}catch (Exception dae) {
			
			throw new AdminException("E00001",dae);
		}
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<DbSourceBO> listDBSources() {
		List<DbSourceBO> dbList = new ArrayList<>();
		ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_DBSOURCE_KEY);
		if (cs != null) {
			 dbList = getObjectKeyValues(cs, DbSourceBO.class);
			 for(DbSourceBO dbSourceBO:dbList){
				 try {
					dbSourceBO.setCreateDate(CommonUtil.toLocalTime(dbSourceBO.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					dbSourceBO.setUpdateDate(CommonUtil.toLocalTime(dbSourceBO.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				 } catch (Exception e) {
					
					e.printStackTrace();
				}
			 }
				 
		}
		return dbList;
	}

	/**
	 * 
	 * Method Name 	: getDBSource
	 * Description 		: The Method "getDBSource" is used for 
	 * Date    			: Jul 26, 2016, 5:29:15 PM
	 * @param dbSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public DbSourceBO getDBSource(String dbSourceName) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":getDBSource(dbSourceName)");
		ConfigurationBO cs;
		List<DbSourceBO> dbList = new ArrayList<>();
		try {
			logger.info("dbSourceName  -------------->"+dbSourceName);
			cs = configurationDao.getConfigurations(Constants.CUSTOMER_DBSOURCE_KEY);
			if (cs != null) {
				dbList = getObjectKeyValues(cs, DbSourceBO.class);
				for (DbSourceBO dbSourceObj : dbList) {
					try {
						dbSourceObj.setCreateDate(CommonUtil.toLocalTime(dbSourceObj.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						dbSourceObj.setUpdateDate(CommonUtil.toLocalTime(dbSourceObj.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if (dbSourceObj.getDbSourceName().equalsIgnoreCase(dbSourceName)) {
						return dbSourceObj;
					}
				}
			}
		} catch (DataAccessException dae) {
			dae.printStackTrace();
			logger.error("Data Access Exception while creating EncryptionKey", dae);
			throw new AdminException("E00001",dae);
		}
		logger.info("End:" + getClass().getName() + ":getDBSource(dbSourceName)");
		return null;
	}

	/**
	 * 
	 * Method Name 	: createDBSource
	 * Description 		: The Method "createDBSource" is used for 
	 * Date    			: Jul 26, 2016, 5:24:22 PM
	 * @param dbSource
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long createDBSource(DbSourceBO dbSource, BindingResult bindingResult) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":createDBSource(dbSource)");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Create DBSource"); 
		ConfigurationBO cs = new ConfigurationBO();
		List<DbSourceBO> dbList = new ArrayList<>();
		try {
			event.addField("Create DBSource content received :: ",dbSource.getKeyName());
			auditManager.audit(event);
			dbSourceValidator.validate(dbSource, bindingResult);
			if (!bindingResult.hasErrors()) {
				cs = configurationDao.getConfigurations(Constants.CUSTOMER_DBSOURCE_KEY);
				if (cs != null) {
					Boolean isEdit = false;
					dbList = getObjectKeyValues(cs, DbSourceBO.class);

					// Return if DB source name already exists
					if (isDBSourceExists(dbList, dbSource)) {
						logger.info("DBsource already exists");
						bindingResult.rejectValue("dbSourceName",
								messageSource.getMessage("ACF0020", new Object[] {}, LocaleContextHolder.getLocale()));
						return -1L;
					}
					// Create or update the source
					else {
						if (testDBConnection(dbSource)) {
							if (dbSource.getKeyName() != null) { // keyName will
																	// be null
																	// for new
																	// sources
								for (DbSourceBO dbSourceObj : dbList) {
									if (dbSourceObj.getKeyName() == null) {
										dbSourceObj.setKeyName(
												dbSourceObj.getDbSourceName() + "_" + System.currentTimeMillis());
									}
									if (dbSourceObj.getKeyName().equalsIgnoreCase(dbSource.getKeyName())) {
										dbSourceObj.setDbSourceName(dbSource.getDbSourceName());
										dbSourceObj.setHostname(dbSource.getHostname());
										dbSourceObj.setPort(dbSource.getPort());
										dbSourceObj.setUsername(dbSource.getUsername());
										dbSourceObj.setPassword(dbSource.getPassword());
										dbSourceObj.setService(dbSource.getService());
										dbSourceObj.setDbvendor(dbSource.getDbvendor());
										dbSourceObj.setDbChracterSet(dbSource.getDbChracterSet());
										dbSourceObj.setSchemaName(dbSource.getSchemaName());
										setCommonProperties(dbSourceObj);
										isEdit = true;
										break;
									}
								}
							}

							// Create the source
							if (!isEdit) {
								setCommonProperties(dbSource);
								dbSource.setKeyName(dbSource.getDbSourceName() + "_" + System.currentTimeMillis());
								dbList.add(dbSource);
							}
						}
					}
				} else {
					cs = new ConfigurationBO();
					cs.setObjectKey(Constants.CUSTOMER_DBSOURCE_KEY);
					setCommonProperties(dbSource);
					dbSource.setKeyName(dbSource.getDbSourceName() + "_" + System.currentTimeMillis());
					dbList.add(dbSource);
				}
				cs.setObjectValue((Object) dbList);
				setCommonProperties(cs);
				configurationDao.saveConfigurations(cs);

			}
		} catch (DataAccessException dae) {
			event.addField("Failed Create DBSource content received :: ",dbSource.getKeyName());
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while creating DBSource", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Create DBSource content received :: ",dbSource.getKeyName());
			auditManager.audit(event);
			logger.error("JsonProcessingException while creating FileSource", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		}
		logger.info("End:" + getClass().getName() + ":createDBSource(dbSource)");
		return cs.getConfigurationId();
	}

	/**
	 * 
	 * Method Name 	: deleteDBSource
	 * Description 		: The Method "deleteDBSource" is used for 
	 * Date    			: Jul 26, 2016, 5:30:15 PM
	 * @param dbSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Boolean deleteDBSource(String keyName) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":deleteDBSource(keyName)");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Delete DBSource"); 
		ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_DBSOURCE_KEY);
		Boolean result = false;
		try {
			event.addField("Delete DBSource content received :: ",keyName);
			auditManager.audit(event);
			logger.info("keyName------------>"+keyName);
			if (cs != null) {
				List<Map<String, String>> dbList = (List<Map<String, String>>) cs.getObjectValue();
				for (Map<String, String> dbmap : dbList) {
					String sourceName=dbmap.get("dbSourceName");
					String value=dbmap.get("keyName");
					String[] key_name = value.split("\\_");
					int index=key_name.length;
					if (key_name[index-1].equalsIgnoreCase(keyName)){
						if(fileDao.veryfingFileSourceandDBSourceinFiles(sourceName,'B')){
							return false;
						}else{
							dbList.remove(dbmap);
							result = true;
							break;
						}
						
					}
				}
				cs.setObjectValue((Object) dbList);
				configurationDao.saveConfigurations(cs);
			}
		} catch (DataAccessException dae) {
			event.addField("Failed Delete DBSource content received :: ",keyName);
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while creating EncryptionKey", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Delete DBSource content received :: ",keyName);
			auditManager.audit(event);
			logger.error("JsonProcessingException while creating EncryptionKey", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		}
		logger.info("Ends:" + getClass().getName() + ":deleteDBSource(dbSourceName)");
		return result;
	}

	/**
	 * 
	 * Method Name 	: listFileSources
	 * Description 		: The Method "listFileSources" is used for 
	 * Date    			: Jul 26, 2016, 6:13:47 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<FileSourceBO> listFileSources() throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":listFileSources()");
		try {
			List<FileSourceBO> fsList = new ArrayList<>();
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_FILESOURCE_KEY);
			if (cs != null) {
				fsList = getObjectKeyValues(cs, FileSourceBO.class);
				 for(FileSourceBO fileSourceBO:fsList){
					 try {
						 fileSourceBO.setCreateDate(CommonUtil.toLocalTime(fileSourceBO.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						 fileSourceBO.setUpdateDate(CommonUtil.toLocalTime(fileSourceBO.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					 } catch (Exception e) {
						
						e.printStackTrace();
					}
				 }
			}
			return fsList;
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Exception while creating EncryptionKey", ex);
			throw new AdminException("E00002",ex);
		}
	}

	/**
	 * 
	 * Method Name 	: getFileSource
	 * Description 		: The Method "getFileSource" is used for 
	 * Date    			: Jul 26, 2016, 6:21:00 PM
	 * @param fileSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public FileSourceBO getFileSource(String fileSourceName) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":getFileSource()");
		ConfigurationBO cs;
		List<FileSourceBO> fsList = new ArrayList<>();
		try {
			logger.info("fileSourceName----------------->"+fileSourceName);
			cs = configurationDao.getConfigurations(Constants.CUSTOMER_FILESOURCE_KEY);
			if (cs != null) {
				fsList = getObjectKeyValues(cs, FileSourceBO.class);
				for (FileSourceBO fsObj : fsList) {
					
					 try {
						 fsObj.setCreateDate(CommonUtil.toLocalTime(fsObj.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						 fsObj.setUpdateDate(CommonUtil.toLocalTime(fsObj.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					 } catch (Exception e) {
						
						e.printStackTrace();
					}
					if (fsObj.getFileSourceName().equalsIgnoreCase(fileSourceName)) {
						return fsObj;
					}
				}
			}
		} catch (DataAccessException dae) {
			dae.printStackTrace();
			logger.error("Data Access Exception while fetching file source", dae);
			throw new AdminException("E00001",dae);
		}
		logger.info("Ends:" + getClass().getName() + ":getFileSource()");
		return null;
	}

	/**
	 * 
	 * Method Name 	: createFileSource
	 * Description 		: The Method "createFileSource" is used for 
	 * Date    			: Jul 26, 2016, 6:25:25 PM
	 * @param fileSource
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long createFileSource(FileSourceBO fileSource, BindingResult bindingResult) throws AdminException {
		logger.info("Create:" + getClass().getName() + ":createFileSource()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Create FileSource"); 
		ConfigurationBO cs = new ConfigurationBO();
		try {
			event.addField("Create FileSource content received :: ",fileSource.getKeyName());
			auditManager.audit(event);
			fileSourceValidator.validate(fileSource, bindingResult);
			if (!bindingResult.hasErrors()) {
				List<FileSourceBO> fsList = new ArrayList<>();
				cs = configurationDao.getConfigurations(Constants.CUSTOMER_FILESOURCE_KEY);
				if (cs != null) {
					Boolean isEdit = false;
					fsList = getObjectKeyValues(cs, FileSourceBO.class);
					// Return if file source name already exists
					if (isFileSourceExists(fsList, fileSource)) {
						logger.info("Filesource already exists");
						bindingResult.rejectValue("fileSourceName",
								messageSource.getMessage("ACF0019", new Object[] {}, LocaleContextHolder.getLocale()));
						return -1L;
					}
					// Create or update the source
					else {
						testConnection(fileSource);
						if (fileSource.getKeyName() != null) { // keyName will be null for new sources
							for (FileSourceBO fsObj : fsList) {
								if (fsObj.getKeyName() == null) {
									fsObj.setKeyName(fsObj.getFileSourceName() + "_" + System.currentTimeMillis());
								}
								if (fsObj.getKeyName().equalsIgnoreCase(fileSource.getKeyName())) {
									// Update the source
									fsObj.setFileSourceName(fileSource.getFileSourceName());
									fsObj.setHostname(fileSource.getHostname());
									fsObj.setPort(fileSource.getPort());
									fsObj.setUsername(fileSource.getUsername());
									fsObj.setPassword(fileSource.getPassword());
									fsObj.setProtocol(fileSource.getProtocol());
									fsObj.setPath(fileSource.getPath());
									setCommonProperties(fsObj);
									isEdit = true;
									break;
								}
							}
						}
						// Create the source
						if (!isEdit) {
							setCommonProperties(fileSource);
							fileSource.setKeyName(fileSource.getFileSourceName() + "_" + System.currentTimeMillis());
							fsList.add(fileSource);
						}
					}
				} else {
					cs = new ConfigurationBO();
					cs.setObjectKey(Constants.CUSTOMER_FILESOURCE_KEY);
					setCommonProperties(fileSource);
					fileSource.setKeyName(fileSource.getFileSourceName() + "_" + System.currentTimeMillis());
					fsList.add(fileSource);
				}
				cs.setObjectValue((Object) fsList);
				setCommonProperties(cs);
				configurationDao.saveConfigurations(cs);

			}
		} catch (DataAccessException dae) {
			event.addField("Failed Create FileSource content received :: ",fileSource.getKeyName());
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while creating FileSource", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Create FileSource content received :: ",fileSource.getKeyName());
			auditManager.audit(event);
			logger.error("JsonProcessingException while creating FileSource", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		}
		logger.info("Ends:" + getClass().getName() + ":createFileSource()");
		return cs.getConfigurationId();
	}

	/**
	 * 
	 * Method Name 	: deleteFileSource
	 * Description 		: The Method "deleteFileSource" is used for 
	 * Date    			: Jul 26, 2016, 6:26:13 PM
	 * @param fileSourceName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteFileSource(String keyName) throws AdminException {
		logger.info("Create:" + getClass().getName() + ":deleteFileSource()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Delete FileSource"); 
		Boolean result = false;
		try {
			event.addField("Delete FileSource content received :: ",keyName);
			auditManager.audit(event);
			logger.info("keyName  ------------------->"+keyName);
			
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_FILESOURCE_KEY);
			if (cs != null) {
				List<Map<String, String>> fsList = (List<Map<String, String>>) cs.getObjectValue();
				for (Map<String, String> fsmap : fsList) {
					String sourceName=fsmap.get("fileSourceName");
					String value=fsmap.get("keyName");
					String[] key_name = value.split("\\_");
					int index=key_name.length;
					if (key_name[index-1].equalsIgnoreCase(keyName)) {
						if(fileDao.veryfingFileSourceandDBSourceinFiles(sourceName,'R')){
							return false;
						}else{
							fsList.remove(fsmap);
							result = true;
							break;
						}
					}
				}
				cs.setObjectValue((Object) fsList);
				configurationDao.saveConfigurations(cs);
			}
			
		} catch (DataAccessException dae) {
			event.addField("Failed Delete FileSource content received :: ",keyName);
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while creating EncryptionKey", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Delete FileSource content received :: ",keyName);
			auditManager.audit(event);
			logger.error("JsonProcessingException while creating EncryptionKey", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		}
		logger.info("Ends:" + getClass().getName() + ":deleteFileSource()");
		return result;
	}

	/**
	 * 
	 * Method Name 	: isAddressTypeExist
	 * Description 		: The Method "isAddressTypeExist" is used for 
	 * Date    			: Jul 26, 2016, 6:42:40 PM
	 * @param addressTypeName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isAddressTypeExist(String addressTypeName) throws AdminException {
		logger.info("Start:" + getClass().getName() + ":isAddressTypeExist()");
		Boolean exists = false;
		ConfigurationBO cs;
		List<AddressTypeBO> addList = new ArrayList<>();
		try {
			logger.info("addressTypeName ------------------>" + addressTypeName);
			cs = configurationDao.getConfigurations(Constants.CUSTOMER_ADDRESSTYPE_KEY);
			if (cs != null) {
				addList = getObjectKeyValues(cs, AddressTypeBO.class);
				for (AddressTypeBO addObj : addList) {
					if (addObj.getName().equalsIgnoreCase(addressTypeName)) {
						exists = true;
						break;
					}
				}
			}
		} catch (DataAccessException dae) {
			dae.printStackTrace();
			logger.error("Data Access Exception while checking address type exist", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception e) {
			logger.error("Exception while  checking address type exist", e);
			throw new AdminException("ACF0021",e);
		}
		logger.info("Ends:" + getClass().getName() + ":isAddressTypeExist()");
		return exists;
	}

	/**
	 * 
	 * Method Name : listAddressTypes Description : The Method
	 * "listAddressTypes" is used for Date : Jul 26, 2016, 6:43:33 PM
	 * 
	 * @param listingCriteria
	 * @return
	 * @param :
	 * @return :
	 * @throws AdminException
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<AddressTypeBO> listAddressTypes()
			throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":listAddresstypes()");
		try {
			List<AddressTypeBO> addList = new ArrayList<>();
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_ADDRESSTYPE_KEY);
			if (cs != null) {
				addList = getObjectKeyValues(cs, AddressTypeBO.class);
				for(AddressTypeBO addressTypeBO:addList){
					 try {
						 addressTypeBO.setCreateDate(CommonUtil.toLocalTime(addressTypeBO.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						 addressTypeBO.setUpdateDate(CommonUtil.toLocalTime(addressTypeBO.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					 } catch (Exception e) {
						
						e.printStackTrace();
					}
				 }
			}
			return addList;
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Exception while creating EncryptionKey", ex);
			throw new AdminException("E00002",ex);
		}
		
	}

	/**
	 * 
	 * Method Name 	: saveAddressType
	 * Description 		: The Method "saveAddressType" is used for 
	 * Date    			: Jul 26, 2016, 6:41:28 PM
	 * @param addressType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long saveAddressType(AddressTypeBO addressType, BindingResult bindingResult) throws AdminException {
		logger.info("Start:" + getClass().getName() + ":saveAddressType()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Save AddressType"); 
		ConfigurationBO cs = new ConfigurationBO();
		List<AddressTypeBO> addList = new ArrayList<>();

		try {
			event.addField("Save AddressType content received :: ",addressType.getName());
			auditManager.audit(event);
			addressTypeValidator.validate(addressType, bindingResult);
			if (!bindingResult.hasErrors()) {
				cs = configurationDao.getConfigurations(Constants.CUSTOMER_ADDRESSTYPE_KEY);
				if (cs != null) {
					Boolean isEdit = false;
					addList = getObjectKeyValues(cs, AddressTypeBO.class);
					// Return if address type name already exists
					if (isAddressTypeExists(addList, addressType)) {
						logger.info("Address type name already exists");
						bindingResult.rejectValue("name",
								messageSource.getMessage("ACF0022", new Object[] {}, LocaleContextHolder.getLocale()));
						return -1L;
					}
					// Create or update the address type
					else {
						if (addressType.getKeyName() != null) { // keyName will
																// be null for
																// new address
																// types
							for (AddressTypeBO addObj : addList) {
								// Update the address type
								if (addObj.getKeyName().longValue()==addressType.getKeyName().longValue()) {
									addObj.setName(addressType.getName());
									addObj.setEnable(addressType.getEnable());
									addObj.setChannelType(addressType.getChannelType());
									setCommonProperties(addObj);
									isEdit = true;
									break;
								}
							}
						}
						// Create address type
						if (!isEdit) {
							setCommonProperties(addressType);
							long id = getAddressTypeKeyName(addList);
							addressType.setKeyName(++id);
							addList.add(addressType);
						}
					}
				} else {
					cs = new ConfigurationBO();
					cs.setObjectKey(Constants.CUSTOMER_ADDRESSTYPE_KEY);
					setCommonProperties(addressType);
					addressType.setKeyName(1L);
					addList.add(addressType);
				}
				cs.setObjectValue((Object) addList);
				setCommonProperties(cs);
				configurationDao.saveConfigurations(cs);

			}
		} catch (DataAccessException dae) {
			event.addField("Failed Save AddressType content received :: ",addressType.getName());
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while saving address types", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Save AddressType content received :: ",addressType.getName());
			auditManager.audit(event);
			logger.error("JsonProcessingException while saving address types", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		} catch (AdminException e) {
			event.addField("Failed Save AddressType content received :: ",addressType.getName());
			auditManager.audit(event);
			logger.error("Exception while creating saving address types", e);
			e.printStackTrace();
			throw e;
		}
		logger.info("Ends:" + getClass().getName() + ":saveAddressType()");
		return cs.getConfigurationId();
	}

	/**
	 * 
	 * Method Name 	: listRestrictedDomains
	 * Description 		: The Method "listRestrictedDomains" is used for 
	 * Date    			: Jul 26, 2016, 7:04:31 PM
	 * @return
	 * @throws AdminException
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public RestrictedDomainsBO listRestrictedDomains() throws AdminException {
		logger.info("Ends:" + getClass().getName() + ":listRestrictedDomains()");
		RestrictedDomainsBO rd = new RestrictedDomainsBO();
		ObjectMapper mapper = new ObjectMapper();
		try {
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
			if (cs != null) {
				rd = mapper.convertValue((Map<String, Object>) cs.getObjectValue(), RestrictedDomainsBO.class);
			}
		} catch (Exception ex) {
			logger.error("Exception while listing the restricted domains", ex);
			ex.printStackTrace();
			throw new AdminException("E00002",ex);
		}
		return rd;
	}

	/**
	 * Method Name 	: updateRestrictedDomains
	 * Description 		: The Method "updateRestrictedDomains" is used for 
	 * Date    			: Jul 26, 2016, 7:09:39 PM.
	 *
	 * @param restrictedDomains the restricted domains
	 * @return 		:
	 * @throws AdminException the admin exception
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long updateRestrictedDomains(RestrictedDomainsBO restrictedDomains) throws AdminException {
		logger.debug("Begin ::" + getClass().getName() + ":: updateRestrictedDomains(RestrictedDomainsBO restrictedDomains)");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Update Restricted Domains"); 
		ConfigurationBO cs = new ConfigurationBO();
		ObjectMapper mapper = new ObjectMapper();

		try {
			event.addField("Update Restricted Domains content received :: ",restrictedDomains.getDomains());
			auditManager.audit(event);
			cs = configurationDao.getConfigurations(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
			if (cs != null) {
				RestrictedDomainsBO rd = mapper.convertValue((Map<String, Object>) cs.getObjectValue(),
						RestrictedDomainsBO.class);
				restrictedDomains.setCreatedBy(rd.getCreatedBy());
				restrictedDomains.setCreateDate(rd.getCreateDate());
				restrictedDomains.setUpdateDate(new java.sql.Date(new java.util.Date().getTime()));
				cs.setObjectValue((Object) restrictedDomains);
				cs.setUpdatedBy(restrictedDomains.getUpdatedBy());
				configurationDao.saveConfigurations(cs);
			} else {
				cs = new ConfigurationBO();
				cs.setObjectKey(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
				restrictedDomains.setCreateDate(new java.sql.Date(new java.util.Date().getTime()));
				restrictedDomains.setUpdateDate(new java.sql.Date(new java.util.Date().getTime()));
				cs.setObjectValue((Object) restrictedDomains);
				cs.setCreatedBy(restrictedDomains.getCreatedBy());
				cs.setUpdatedBy(restrictedDomains.getCreatedBy());
				configurationDao.saveConfigurations(cs);
			}

		} catch (DataAccessException dae) {
			event.addField("Failed Update Restricted Domains content received :: ",restrictedDomains.getDomains());
			auditManager.audit(event);
			logger.error("Data Access Exception while updating the restricted domains "+dae.getMessage(), dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Update Restricted Domains content received :: ",restrictedDomains.getDomains());
			auditManager.audit(event);
			logger.error("JsonProcessingException while updating the restricted domains "+jpx.getMessage(), jpx);
			throw new AdminException("E00006",jpx);
		} catch (Exception e) {
			event.addField("Failed Update Restricted Domains content received :: "+e.getMessage(),restrictedDomains.getDomains());
			auditManager.audit(event);
			logger.error("Exception while updating the restricted domains", e);
			throw new AdminException("E00002",e);
		}
		logger.debug("End ::" + getClass().getName() + ":: updateRestrictedDomains(RestrictedDomainsBO restrictedDomains)");
		return cs.getConfigurationId();
	}



	/**
	 * 
	 * Method Name 	: saveDomain
	 * Description 		: The Method "saveDomain" is used for 
	 * Date    			: Jul 26, 2016, 7:13:36 PM
	 * @param domain
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Long saveDomain(DomainBO domain, BindingResult bindingResult) throws AdminException {
		logger.info("Starts:" + getClass().getName() + ":saveDomain()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Save Domain"); 
		ConfigurationBO cs = new ConfigurationBO();
		List<DomainBO> domainList = new ArrayList<>();
		try {
			event.addField("Save Domain content received :: ",domain.getKeyName());
			auditManager.audit(event);
			domainValidator.validate(domain, bindingResult);
			if (!bindingResult.hasErrors()) {
				cs = configurationDao.getConfigurations(Constants.CUSTOMER_DOMAIN_KEY);
				if (cs != null) {
					Boolean isEdit = false;
					domainList = getObjectKeyValues(cs, DomainBO.class);
					// Return if domain code already exists
					if (isDomainExists(domainList, domain)) {
						logger.info("Domain code already exists");
						bindingResult.rejectValue("code",
								messageSource.getMessage("ACF0017", new Object[] {}, LocaleContextHolder.getLocale()));
						return -1L;
					}
					// Create or update the domain
					else {
						if (domain.getKeyName() != null) { //keyName will be null for new domains
							for (DomainBO domainObj : domainList) {
								if(domainObj.getKeyName()==null)
									domainObj.setKeyName(domainObj.getCode()+"_"+System.currentTimeMillis());
								if (domainObj.getKeyName().equalsIgnoreCase(domain.getKeyName())) {
									// Update the domain
									domainObj.setCode(domain.getCode());
									domainObj.setDescription(domain.getDescription());
									domainObj.setPattern(domain.getPattern());
									domainObj.setRecordCount(domain.getRecordCount());
									domainObj.setStatus(domain.getStatus());
									domainObj.setSupportedFormat(domain.getSupportedFormat());
									setCommonProperties(domainObj);
									isEdit = true;
									break;
								}
							}
						}
						// Create domain
						if (!isEdit) {
							setCommonProperties(domain);
							domain.setKeyName(domain.getCode() + "_" + System.currentTimeMillis());
							domainList.add(domain);
							departmentService.addDomainToDepartmentOptoutRules(domain.getCode(), bindingResult);
						}

					}
				} // if(cs!=null)
				else {
					cs = new ConfigurationBO();
					cs.setObjectKey(Constants.CUSTOMER_DOMAIN_KEY);
					setCommonProperties(domain);
					domain.setKeyName(domain.getCode() + "_" + System.currentTimeMillis());
					domainList.add(domain);
					departmentService.addDomainToDepartmentOptoutRules(domain.getCode(), bindingResult);
				}
				cs.setObjectValue((Object) domainList);
				setCommonProperties(cs);
				configurationDao.saveConfigurations(cs);
			}
		} catch (DataAccessException dae) {
			event.addField("Failed Save Domain content received :: ",domain.getKeyName());
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while saving/updating the domains", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Save Domain content received :: ",domain.getKeyName());
			auditManager.audit(event);
			logger.error("JsonProcessingException while saving/updating the domains", jpx);
			throw new AdminException("E00006",jpx);
		} catch (AdminException e) {
			event.addField("Failed Save Domain content received :: ",domain.getKeyName());
			auditManager.audit(event);
			logger.error("Exception while updating the saving/updating the domains", e);
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			event.addField("Failed Save Domain content received :: ",domain.getKeyName());
			auditManager.audit(event);
			logger.error("Exception while updating the saving/updating the domains", e);
			e.printStackTrace();
			throw new AdminException("ACF0016",e);
		}
		logger.info("Ends:" + getClass().getName() + ":saveDomain()");
		return cs.getConfigurationId();
	}

	
	/**
	 * 
	 * Method Name 	: listDomains
	 * Description 		: The Method "listDomains" is used for 
	 * Date    			: Jul 26, 2016, 7:16:53 PM
	 * @return List<DomainBO>
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<DomainBO> listDomains() throws AdminException {
		List<DomainBO> domainList = new ArrayList<>();
		try {
			ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_DOMAIN_KEY);
			if (cs != null) {
				domainList = getObjectKeyValues(cs, DomainBO.class);
				for(DomainBO domainBO:domainList){
					 try {
						 domainBO.setCreateDate(CommonUtil.toLocalTime(domainBO.getCreateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
						 domainBO.setUpdateDate(CommonUtil.toLocalTime(domainBO.getUpdateDate().getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					 } catch (Exception e) {
						
						e.printStackTrace();
					}
				 }
			}
		} catch (DataAccessException dae) {
			dae.printStackTrace();
			logger.error("Data Access Exception while saving/updating the domains", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception e) {
			logger.error("Exception while listing the domains", e);
			e.printStackTrace();
			throw new AdminException("E00002",e);
		}
		return domainList;
	}

	
		
	/**
	 * Gets the total address types count.
	 *
	 * @param listingCriteria the listing criteria
	 * @param result the result
	 * @return the total address types count
	 * @throws AdminException the admin exception
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Long getTotalAddressTypesCount(ListingCriteria listingCriteria, BindingResult result) throws AdminException {
		logger.info("Start:" + getClass().getName() + ":getTotalAddressTypesCount()");
		List<Map<String, Object>> addressTypesList = new ArrayList<>();
		try {
			listingCriteriaValidator.validate(listingCriteria, result);
			if (!result.hasErrors()) {
				ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_ADDRESSTYPE_KEY);
				if (cs != null) {
					addressTypesList = (List<Map<String, Object>>) cs.getObjectValue();
				}
			}
		} catch (DataAccessException dae) {
			dae.printStackTrace();
			logger.error("Data Access Exception while fetching total address types count", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception e) {
			logger.error("Exception while fetching total address types count", e);
			e.printStackTrace();
			throw new AdminException("E00002",e);
		}
		logger.info("Ends:" + getClass().getName() + ":getTotalAddressTypesCount()");
		return Long.parseLong(addressTypesList.size() + "");
	}

	/**
	 * 
	 * 
	 * Method Name 	: testConnection
	 * Description 	: The Method "testConnection" is used for 
	 * Date    		: Jul 28, 2016, 8:41:51 PM
	 * @param fileSourceBO
	 * @return
	 * @throws FileSystemUtilException
	 * @throws FileException
	 * @throws Exception
	 * @param  		:
	 * @return 		: boolean
	 * @throws 		:
	 */
	private boolean testConnection(FileSourceBO fileSourceBO) throws AdminException{
		logger.info(
				"Begin: com.zetainteractive.zetahub.admin.service.impl.ConfigurationServiceImpl:testConnection(FileSourceBO)");

		FileSystemUtilsPlugin fileUtils = null;
		boolean testConnection = false;
		String password = null;
		byte[] decodedPassword;
		try {
			if (fileSourceBO == null) {
				throw new FileException("FL0002");
			}
			if (fileSourceBO.getProtocol().equalsIgnoreCase(Constants.HTTP_PROTOCOL)
					|| fileSourceBO.getProtocol().equalsIgnoreCase(Constants.HTTPS_PROTOCOL)) {
				fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.HTTP);
			} else if (fileSourceBO.getProtocol().equalsIgnoreCase(Constants.FTP_PROTOCOL)) {
				fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.FTP);
			} else if (fileSourceBO.getProtocol().equalsIgnoreCase(Constants.SFTP_PROTOCOL)) {
				fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SFTP);
			} else if (fileSourceBO.getProtocol().equalsIgnoreCase(Constants.SCP_PROTOCOL)) {
				fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SCP);
			}
			if (fileSourceBO.getPassword() != null) {
				decodedPassword = Base64.decode(fileSourceBO.getPassword().getBytes());
				password = new String(decodedPassword);
			}
			FileUtilContext fileUtilContext = new FileUtilContext(fileSourceBO.getHostname(),
					fileSourceBO.getUsername(), password, fileSourceBO.getPort(), 15000);
			logger.info("FileUtilContext: " + fileUtilContext);
			if (fileUtils != null) {
				if (fileSourceBO.getProtocol().equalsIgnoreCase(Constants.HTTP_PROTOCOL)
						|| fileSourceBO.getProtocol().equalsIgnoreCase(Constants.HTTPS_PROTOCOL)) {
					logger.info("Protocol:" + fileSourceBO.getProtocol());
					fileUtilContext.setUrlString(fileSourceBO.getHostname());
					fileUtils.setContext(fileUtilContext);
					fileUtils.connect();
					testConnection = true;
				} else {
					logger.info("Protocol:" + fileSourceBO.getProtocol());
					fileUtils.setContext(fileUtilContext);
					String userPath = fileUtils.getUserHome();
					logger.info("Connected");
					logger.info("user path:", userPath);
					fileSourceBO.setPath(userPath);
					testConnection = true;
				}
			}
		} catch (FileSystemUtilException | FileException | IOException e) {
			logger.error("Getting Connection Object : host : " + fileSourceBO.getHostname() + " protocol :" + fileSourceBO.getProtocol() + " port : " + fileSourceBO.getPort()
					+ " user : " + fileSourceBO.getUsername());
			e.printStackTrace();
			throw new AdminException("ACF0010", null, Level.FATAL, e);
		}
		logger.info("End: com.zetainteractive.zetahub.admin.service.impl.ConfigurationServiceImpl:testConnection(FileSourceBO)");
		return testConnection;
	}
	
	/**
     * This method is used to list restricted domains and departments list with dept desc having property type '400'
     * @return List
     * @throws EbizException
     */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
    public List getRestrictedDomainsWithDepartmentsList()throws AdminException
    {
		List list = new ArrayList();
		RestrictedDomainsBO restrictedDomain = new RestrictedDomainsBO();
		ObjectMapper mapper = new ObjectMapper();
		ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
		if (cs != null) {
			restrictedDomain = mapper.convertValue((Map<String, Object>) cs.getObjectValue(), RestrictedDomainsBO.class);
		}

		ListingCriteria listingCriteria=new ListingCriteria();
		listingCriteria.setSortBy("asc");
		listingCriteria.setNameLike("");
		listingCriteria.setPageNumber(1L);
		listingCriteria.setPageSize(Long.MAX_VALUE);
		listingCriteria.setSortUsing("departmentid");
		List departments = departmentDao.listDepartments(listingCriteria);
		
		list.add(restrictedDomain);
		list.add(departments);
		return list;
    }
    /**
     * 
     * 
     * Method Name 	: downloadRSDomains
     * Description 		: The Method "downloadRSDomains" is used for 
     * Date    			: Jul 28, 2016, 8:41:41 PM
     * @return
     * @throws AdminException
     * @param  		:
     * @return 		: 
     * @throws 		:
     */
    @Override
    @Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
    public ByteArrayOutputStream downloadRSDomains() throws AdminException
	{
    	Vector sheet = new Vector();
		Vector rowCellVector = null;
		ExcelCell cell = null;
		ByteArrayOutputStream baos=null;
		ExportUtil utilObj;
		
		rowCellVector = new Vector();
		cell = new ExcelCell();
		cell.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cell.setFontSize((short)10);
		cell.setFontname("Arial");
		cell.setCellStylePattern("headerStyle");
		cell.setValue("Restricted Domains");
		rowCellVector.add(cell);	//add cell to row  
        sheet.add(rowCellVector);	//add row to sheet
        
        try
        {
        	ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
        	ObjectMapper mapper = new ObjectMapper();
        	RestrictedDomainsBO restrictedDomain = null;
			if (cs != null) {
				restrictedDomain = mapper.convertValue((Map<String, Object>) cs.getObjectValue(), RestrictedDomainsBO.class);
			}
			
        	if(restrictedDomain!=null) 
        	{
				HashMap<String,Boolean> domains = restrictedDomain.getDomains();
        		
        		for (String domain : domains.keySet()) {

					rowCellVector = new Vector();
					cell = new ExcelCell();
					cell.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
					cell.setFontSize((short)10);
					cell.setFontname("Arial");
					cell.setCellStylePattern("dataStyle");
					if(domain!=null)
						cell.setValue(domain.toString());
					else
						cell.setValue("");
					rowCellVector.add(cell);	//add cell to row  
			        sheet.add(rowCellVector);	//add row to sheet
				
				}
        	} 
        	else 
        	{
				throw new AdminException("WC0006");
			}
        	
        	Vector collection=new Vector();
        	collection.add(sheet);
        	utilObj = new ExportUtil();
            baos = utilObj.exportToExcel(collection, null, false, 0, 0);
           
        }
        catch(AdminException ee){
            throw ee;
        }
        catch(Exception e){ 
        	e.printStackTrace();
        	new AdminException("FC0216", null, Level.FATAL, e);
        }
        
        return baos;
	}
    /**
     * 
     * 
     * Method Name 	: saveRestrictedDomains
     * Description 		: The Method "saveRestrictedDomains" is used for 
     * Date    			: Jul 28, 2016, 8:41:16 PM
     * @param filestream
     * @return
     * @throws AdminException
     * @param  		:
     * @return 		: 
     * @throws 		:
     */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public List saveRestrictedDomains(byte[] filestream) throws AdminException {
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Save Restricted Domains"); 
		LinkedHashMap<String,Boolean> domains = new LinkedHashMap<>();
		List resultList = new ArrayList<>();
		try
    	{
			event.addField("Save Restricted Domains content received :: ",filestream);
			auditManager.audit(event);
    		if (filestream != null && filestream.length > 0) {
				InputStream is = new ByteArrayInputStream(filestream);
				if (is != null) {
					Workbook wb = WorkbookFactory.create(is);
					if (wb != null) {
						int sheetCnt = wb.getNumberOfSheets();
						if (sheetCnt > 0) {
							// Get the first sheet data
							Sheet sheet = wb.getSheetAt(0);
							if (sheet != null) {
								int rowCnt = sheet.getLastRowNum();
								for (int j = 1; j <= rowCnt; j++) {
									Row row = sheet.getRow(j);
									if (row != null) {
										Cell cell = row.getCell(0);
										if (cell != null) {
											cell.setCellType(Cell.CELL_TYPE_STRING);
											if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
												String data = cell.getStringCellValue();
												if (data != null && data.trim().length() > 0) {
													data = data.trim().toLowerCase();
													domains.put(data,false);
												}
											} else {
												throw new AdminException("ACF0013");
											}
										}
									}
								}
								if(domains.size()>0){
									RestrictedDomainsBO restrictedDomain = new RestrictedDomainsBO();
									restrictedDomain.setDomains(domains);
									resultList = addRestrictedDomains(restrictedDomain);
								}
							}
						}
					}
				}
			}else{
				throw new AdminException("ACF0012");
			}
    		
    	}
    	catch (Exception e)
    	{
    		event.addField("Failed Save Restricted Domains content received :: ",filestream);
			auditManager.audit(event);
    		e.printStackTrace();
    		throw new AdminException("ACF0011",e);
		}
    	return resultList;
	}
	
	/**
	 * Method Name 	: addRestrictedDomains
	 * Description 		: The Method "addRestrictedDomains" is used for 
	 * Date    			: Jul 28, 2016, 5:09:39 PM.
	 *
	 * @param restrictedDomains the restricted domains
	 * @return 		:
	 * @throws AdminException the admin exception
	 */
	
	private List addRestrictedDomains(RestrictedDomainsBO newRestrictedDomainBO) throws AdminException {
		logger.debug("Begin ::" + getClass().getName() + ":updateRestrictedDomains()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Add Restricted Domains"); 
		ConfigurationBO cs = null;
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String,Boolean> restrictedDomains = newRestrictedDomainBO.getDomains();
		List<String> duplicateDomains = new ArrayList<>();
		List<Object> resultList = new ArrayList<>();
		try {
			event.addField("Add Restricted Domains content received :: ",newRestrictedDomainBO.getDomains());
			auditManager.audit(event);
			cs = configurationDao.getConfigurations(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
			if (cs != null) {
				RestrictedDomainsBO rd = mapper.convertValue(cs.getObjectValue(),RestrictedDomainsBO.class);
				setCommonProperties(rd);
				HashMap<String,Boolean> oldDomains = rd.getDomains();
				if(!oldDomains.isEmpty()){
					for (String domain : restrictedDomains.keySet()) {
						if(oldDomains.containsKey(domain)){
							duplicateDomains.add(domain);
						}else{
							oldDomains.put(domain,false);
						}
					}
					rd.setDomains(oldDomains);
				}else{
					rd.setDomains(restrictedDomains);
				}
				cs.setObjectValue((Object) rd);
				resultList.add(rd);
			} else {
				cs = new ConfigurationBO();
				cs.setObjectKey(Constants.CUSTOMER_RESTRICTEDDOMIAN_KEY);
				cs.setObjectValue((Object) newRestrictedDomainBO);
				resultList.add(newRestrictedDomainBO);
			}
			setCommonProperties(cs);
			//configurationDao.saveConfigurations(cs)
		} catch (DataAccessException dae) {
			event.addField("Failed Add Restricted Domains content received :: ",newRestrictedDomainBO.getDomains());
			auditManager.audit(event);
			logger.error("Data Access Exception while updating the restricted domains"+dae.getMessage(), dae);
			throw new AdminException("E00001",dae);
		}  catch (Exception e) {
			event.addField("Failed Add Restricted Domains content received :: ",newRestrictedDomainBO.getDomains());
			auditManager.audit(event);
			logger.error("Exception while updating the restricted domains "+e.getMessage(), e);
			throw new AdminException("E00002",e);
		}
		
		resultList.add(duplicateDomains);
		logger.debug("End ::" + getClass().getName() + ":updateRestrictedDomains()");
		return resultList;
	}
	
	private boolean testDBConnection(DbSourceBO dbsource) throws AdminException {
		logger.info(
				"Begin: com.zetainteractive.zetahub.admin.service.impl.ConfigurationServiceImpl: testDBConnection()");
		String url = null;
		String driver = null;
		String schemaName = null;
		String vendor = dbsource.getDbvendor();
		String db_Name = dbsource.getSchemaName();
		String host = dbsource.getHostname();
		short port = dbsource.getPort();
		String user = dbsource.getUsername();
		byte[] decodedPassword;
		boolean testConnection = false;
		Connection connection = null;
		try {
			if (vendor.equalsIgnoreCase(Constants.DBTYPE_MYSQL)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-url", 
						"jdbc:mysql://${IPADDRESS}:${PORT}/${SID}?autoReconnect=true&useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-driver", "com.mysql.cj.jdbc.Driver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_ORACLE)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-url", 
						"jdbc:oracle:thin:@${IPADDRESS}:${PORT}:${SID}");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-driver", "oracle.jdbc.driver.OracleDriver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_MSSQL)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-url",
						"jdbc:jtds:sqlserver://${IPADDRESS}:${PORT}/${SID}");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-driver", "net.sourceforge.jtds.jdbc.Driver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_TERADATA)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-url", "jdbc:teradata://${SID}/");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-driver", "com.ncr.teradata.TeraDriver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_NETEZZA)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-url", "jdbc:netezza://${IPADDRESS}:${PORT}/${SID}");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-driver", "org.netezza.Driver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_POSTGRES)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-url", "jdbc:postgresql://${IPADDRESS}:${PORT}/${SID}");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-driver", "org.postgresql.Driver");
			} else if (vendor.equalsIgnoreCase(Constants.DBTYPE_VERTICA)) {
				url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-url", "jdbc:vertica://${IPADDRESS}:${PORT}/${SID}");
				driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-driver", "com.vertica.jdbc.Driver");
				if (db_Name != null && db_Name.contains(".")) {
					schemaName = db_Name.split(Pattern.quote("."))[1];
					db_Name = db_Name.split(Pattern.quote("."))[0];
				}
			}
			logger.info("url:"+url);
			logger.info("driver:"+driver);
			url = CommonUtil.replaceValuesInStringTemplate(url, host, port, db_Name);
			if (vendor.equalsIgnoreCase(Constants.DBTYPE_VERTICA) && schemaName != null) {
				url = url + "?searchpath=" + schemaName;
			}
			Class.forName(driver).newInstance();
			decodedPassword = Base64.decode(dbsource.getPassword().getBytes());
			String password = new String(decodedPassword);
			connection = DriverManager.getConnection(url, user, password);
			testConnection = true;
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Getting Connection Object : vendor " + vendor + " host : " + host + " port : " + port
					+ " db_Name : " + db_Name + " user : " + user);
			throw new AdminException("ACF0010", null, Level.FATAL, e);
		}
		logger.info("End: com.zetainteractive.zetahub.admin.service.impl.ConfigurationServiceImpl:getConnection()");
		return testConnection;
	}

	/**
	 * 
	 * Method Name 	: saveActiveRestrictedDomainforDept
	 * Description 		: The Method "saveActiveRestrictedDomainforDept" is used for 
	 * Date    			: Jul 29, 2016, 8:37:13 PM
	 * @param restrictedDomainDeptList
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws AdminException 
	 * @throws 		: 
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	public Boolean saveActiveRestrictedDomainforDept(List restrictedDomainDeptList) throws AdminException {

		logger.info("Ends:" + getClass().getName() + ":saveActiveRestrictedDomainforDept()");
		AuditEvent event = new AuditEvent();
		event.setActor("ConfigurationServiceImpl");
		event.setAction("Save Active Restricted Domain for Dept"); 
		try {
			event.addField("Save Active Restricted Domain for Dept content received :: ",restrictedDomainDeptList);
			auditManager.audit(event);
			updateRestrictedDomains((RestrictedDomainsBO)restrictedDomainDeptList.get(0));
			List<DepartmentBO> departments = (List<DepartmentBO>) restrictedDomainDeptList.get(1);
			for (DepartmentBO departmentBO : departments) {
				DepartmentBO oldDepartmentBO = departmentService.getDepartment(departmentBO.getDepartmentID());
				oldDepartmentBO.setRestrictedDomainsExists(departmentBO.getRestrictedDomainsExists());
				departmentDao.saveDepartment(oldDepartmentBO,false);
			}
			
		} catch (DataAccessException dae) {
			event.addField("Failed Save Active Restricted Domain for Dept content received :: ",restrictedDomainDeptList);
			auditManager.audit(event);
			dae.printStackTrace();
			logger.error("Data Access Exception while updating the restricted domains", dae);
			throw new AdminException("E00001",dae);
		} catch (JsonProcessingException jpx) {
			event.addField("Failed Save Active Restricted Domain for Dept content received :: ",restrictedDomainDeptList);
			auditManager.audit(event);
			logger.error("JsonProcessingException while updating the restricted domains", jpx);
			jpx.printStackTrace();
			throw new AdminException("E00006",jpx);
		} catch (Exception e) {
			event.addField("Failed Save Active Restricted Domain for Dept content received :: ",restrictedDomainDeptList);
			auditManager.audit(event);
			logger.error("Exception while updating the restricted domains", e);
			e.printStackTrace();
			throw new AdminException("E00002",e);
		}
		return true;
	}	
	
	private Object setCommonProperties(CommonProperties cp) throws AdminException {
		java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
		try {
			if (cp.getCreatedBy() == null|| cp.getCreatedBy().length()==0) {
				cp.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			}
			
			if(cp.getCreateDate()== null){
				cp.setCreateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
				
			}
			cp.setUpdateDate(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()));
			
		
			
			cp.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdminException("ACF000",e);
		}
		return cp;
	}
	/**
	 * 
	 * @param domainList
	 * @param domain
	 * @return
	 */
	private Boolean isDomainExists(List<DomainBO> domainList, DomainBO domain) {
		logger.info("Start:" + getClass().getName() + ":isDomainExists()");
		Boolean exists = false;
		for (DomainBO domObj : domainList) {
			if (domObj.getCode() != null && (domObj.getCode().equalsIgnoreCase(domain.getCode()))) {
				if (domain.getKeyName() == null) {// Add operation
					exists = true;
					break;
				} else if (!domObj.getKeyName().equalsIgnoreCase(domain.getKeyName())) {//Edit operation
					exists = true;
					break;
				}
			}
		}
		logger.info("Ends:" + getClass().getName() + ":isDomainExists()");
		return exists;
	}
	/**
	 * 
	 * @param fsList
	 * @param fs
	 * @return
	 */
	private Boolean isFileSourceExists(List<FileSourceBO> fsList, FileSourceBO fs) {
		logger.info("Start:" + getClass().getName() + ":isFileSourceExists()");
		Boolean exists = false;
		for (FileSourceBO fsObj : fsList) {
			if (fsObj.getFileSourceName()!= null && (fsObj.getFileSourceName().equalsIgnoreCase(fs.getFileSourceName()))) {
				if (fs.getKeyName() == null) {// Add operation
					exists = true;
					break;
				} else if (!fsObj.getKeyName().equalsIgnoreCase(fs.getKeyName())) {//Edit operation
					exists = true;
					break;
				}
			}
		}
		logger.info("Ends:" + getClass().getName() + ":isFileSourceExists()");
		return exists;
	}
	/**
	 * 
	 * @param dbList
	 * @param dbSource
	 * @return
	 */
	private Boolean isDBSourceExists(List<DbSourceBO> dbList, DbSourceBO dbSource) {
		logger.info("Start:" + getClass().getName() + ":isDBSourceExists()");
		Boolean exists = false;
		for (DbSourceBO dbObj : dbList) {
			if (dbObj.getDbSourceName()!= null && (dbObj.getDbSourceName().equalsIgnoreCase(dbSource.getDbSourceName()))) {
				if (dbSource.getKeyName() == null) {// Add operation
					exists = true;
					break;
				} else if (!dbObj.getKeyName().equalsIgnoreCase(dbSource.getKeyName())) {//Edit operation
					exists = true;
					break;
				}
			}
		}
		logger.info("Ends:" + getClass().getName() + ":isDBSourceExists()");
		return exists;
	}
	/**
	 * 
	 * @param addList
	 * @param addressType
	 * @return
	 */
	private Boolean isAddressTypeExists(List<AddressTypeBO> addList, AddressTypeBO addressType) {
		logger.info("Start:" + getClass().getName() + ":isAddressTypeExists()");
		Boolean exists = false;
		for (AddressTypeBO addObj : addList) {
			if (addObj.getName()!= null && (addObj.getName().equalsIgnoreCase(addressType.getName()))) {
				if (addressType.getKeyName() == null) {// Add operation
					exists = true;
					break;
				} else if (addObj.getKeyName().longValue()!=addressType.getKeyName().longValue()) {//Edit operation
					exists = true;
					break;
				}
			}
		}
		logger.info("Ends:" + getClass().getName() + ":isAddressTypeExists()");
		return exists;
	}
	/**
	 * 
	 * @param encList
	 * @param enc
	 * @return
	 */
	private Boolean isEncryptionKeyExists(List<EncryptionKeyBO> encList, EncryptionKeyBO enc) {
		logger.info("Start:" + getClass().getName() + ":isEncryptionKeyExists()");
		Boolean exists = false;
		for (EncryptionKeyBO encObj : encList) {
			if (encObj.getEncryptionKeyName()!= null && (encObj.getEncryptionKeyName().equalsIgnoreCase(enc.getEncryptionKeyName()))) {
				if (enc.getKeyName() == null) {// Add operation
					exists = true;
					break;
				} else if (!encObj.getKeyName().equalsIgnoreCase(enc.getKeyName())) {//Edit operation
					exists = true;
					break;
				}
			}
		}
		logger.info("Ends:" + getClass().getName() + ":isEncryptionKeyExists()");
		return exists;
	}
	
	private long getAddressTypeKeyName(List<AddressTypeBO> addList){
		long id = -1L;
		AddressTypeBO addTypeBO = addList.get(addList.size()-1);
		if(addTypeBO!=null)
			id = addTypeBO.getKeyName().longValue();
		return id;
	}
	/**
	 * 
	 * Method Name 	: deleteDomain
	 * Description 		: The Method "deleteDomain" is used for 
	 * Date    			: Jul 26, 2016, 7:24:58 PM
	 * @param code
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
    public Boolean deleteDomain(String code) throws AdminException {
        logger.info("Start:" + getClass().getName() + ":deleteDomain()");
        AuditEvent event = new AuditEvent();
        event.setActor("ConfigurationServiceImpl");
        event.setAction("Delete Domain"); 
        boolean isexist = false;
            try {
                event.addField("Delete Domain content received :: ",code);
                auditManager.audit(event);
              if(configurationDao.verifyIsDomainUsed(code)){
                    return false;
                }else{
                    ConfigurationBO cs = configurationDao.getConfigurations(Constants.CUSTOMER_DOMAIN_KEY);
                    if(cs!=null){
                        List<Map<String, String>> domainList = (List<Map<String, String>>) cs.getObjectValue();
                        for (Map<String, String> domainMap : domainList) {
                            if (domainMap.get("code").equalsIgnoreCase(code)) {
                                domainList.remove(domainMap);
                                isexist = true;
                                break;
                            }
                        }
                        cs.setObjectValue((Object) domainList);
                        configurationDao.saveConfigurations(cs);
                        departmentService.deleteDomainFromDepartmentOptoutRules(code);
                    }
                }
                return isexist;
            } catch (DataAccessException dae) {
                event.addField("Failed Delete Domain content received :: ",code);
                auditManager.audit(event);
                dae.printStackTrace();
                logger.error("Data Access Exception while deleting the domain", dae);
                throw new AdminException("E00001",dae);
            } catch (Exception e) {
                event.addField("Failed Delete Domain content received :: ",code);
                auditManager.audit(event);
                logger.error("Exception while deleting the domain", e);
                e.printStackTrace();
                throw new AdminException("ACF0018",e);
            }
	}
}

	

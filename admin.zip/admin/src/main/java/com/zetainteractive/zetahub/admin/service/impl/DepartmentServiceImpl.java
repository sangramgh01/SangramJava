
/**
 * 
 */
package com.zetainteractive.zetahub.admin.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.ResponseObject;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.CategoryDao;
import com.zetainteractive.zetahub.admin.dao.DepartmentDao;
import com.zetainteractive.zetahub.admin.dao.FolderDao;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.service.WebPageService;
import com.zetainteractive.zetahub.admin.util.DepartmentUtil;
import com.zetainteractive.zetahub.admin.validators.CategoriesListingCriteriaValidator;
import com.zetainteractive.zetahub.admin.validators.CategoryValidator;
import com.zetainteractive.zetahub.admin.validators.DepartmentValidationService;
import com.zetainteractive.zetahub.admin.validators.DepartmentValidator;
import com.zetainteractive.zetahub.admin.validators.FolderValidator;
import com.zetainteractive.zetahub.admin.validators.FoldersListingCriteriaValidator;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.AdobeAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.AdobeRunDetailsBO;
import com.zetainteractive.zetahub.commons.domain.CampaignBO;
import com.zetainteractive.zetahub.commons.domain.CampaignCriteriaBO;
import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;
import com.zetainteractive.zetahub.commons.domain.ContentCriteriaBO;
import com.zetainteractive.zetahub.commons.domain.ContentTemplateBO;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.ConversationCriteriaBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.DomainOptoutRule;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;
import com.zetainteractive.zetahub.commons.domain.KeyWord;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.SmsCampaign;
import com.zetainteractive.zetahub.commons.domain.UnsubRulesBO;

/**
 * @author Lakshmi.Medarametla
 *
 */
@Component
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentDao departmentDao;
	
	@Autowired
	DepartmentUtil departmentUtil;

	@Autowired
	FolderDao folderDao;

	@Autowired
	CategoryDao categoryDao;

	@Autowired
	DepartmentValidationService departmentValidationService;

	@Autowired
	DepartmentValidator departmentValidator;

	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;

	@Autowired
	FolderValidator folderValidator;
	
	@Autowired
	FoldersListingCriteriaValidator foldersListingCriteriaValidator;
	
	@Autowired
	CategoriesListingCriteriaValidator categoriesListingCriteriaValidator;
	
	@Autowired
	CategoryValidator categoryValidator;
	
	@Autowired
	WebPageService webPageService;

	@Autowired
	MessageSource messageSource;
	
	private RestRequestHandler restHandler = new RestRequestHandler();
	
	ObjectMapper objectMapper = new ObjectMapper();

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	private String conversationEndPoint;
	private String contentEndPoint;
	
	public DepartmentServiceImpl() throws Exception{
		conversationEndPoint = ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation";
		contentEndPoint = ZetaUtil.getHelper().getEndpoint("content");
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public DepartmentSettings getDepartmentSpecificProperty(Long departmentId, String propertyKey, BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getDepartmentSpecificProperty()");
		DepartmentBO departmentBO = null;
		DepartmentSettings departmentPropertyObject = null;
		try {
			departmentValidationService.checkDepartmentId(departmentId, bindingResult);
			departmentValidationService.validateDepartmentPropertyKey(propertyKey, bindingResult);
			if (!bindingResult.hasErrors()) {
				departmentBO = getDepartment(departmentId);
				for (DepartmentSettings departmentSetting : departmentBO.getDepartmentSettings()) {
					if (departmentSetting.getObjectKey().equalsIgnoreCase(propertyKey.trim())) {
						departmentPropertyObject = departmentSetting;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while getting department specific property :: ", e);
			throw new AdminException("ADM064",e);
		}
		logger.debug("End :" + getClass().getName() + " :getDepartmentSpecificProperty()");
		return departmentPropertyObject;
	}
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public void updateDepartmentSpecificProperty(DepartmentSettings departmentSettingsNew,BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :updateDepartmentSpecificProperty()");
		DepartmentBO departmentBO = null;
		Boolean foundSettingInDepartment = false;
		try {
			departmentValidationService.checkDepartmentId(departmentSettingsNew.getDepartmentID(), bindingResult);
			if (!bindingResult.hasErrors()) {
				departmentBO = departmentDao.getDepartment(departmentSettingsNew.getDepartmentID());
				for (DepartmentSettings departmentSetting : departmentBO.getDepartmentSettings()) {
					if (departmentSetting.getDepartmentSettingId()
							.equals(departmentSettingsNew.getDepartmentSettingId())
							|| departmentSetting.getObjectKey()
									.equalsIgnoreCase(departmentSettingsNew.getObjectKey())) {
						departmentSetting.setObjectValue(departmentSettingsNew.getObjectValue());
						foundSettingInDepartment = true;
					}
				}
				if (foundSettingInDepartment)
					departmentDao.saveDepartment(departmentBO,true);
				else
					bindingResult.reject(
							messageSource.getMessage("ADM014", new Object[] {}, LocaleContextHolder.getLocale()),
							"Unable to save department settings.");
			}
		} catch (Exception e) {
			logger.error("Some thing went wrong while updating department specific property :: ", e);
			throw new AdminException("ADM065",e);
		}
		logger.debug("End :" + getClass().getName() + " :updateDepartmentSpecificProperty()");
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public DepartmentBO getDepartment(Long deptId) throws Exception {
		logger.debug("Start :" + getClass().getName() + " :getDepartment()");
		DepartmentBO departmentBO = null;
		try {
			if (deptId == null || deptId < 0)
				throw new AdminException("ADM005", new Object[] { deptId });
			departmentBO = departmentDao.getDepartment(deptId);
			/**Begin :: ZHPE-9327*/
			departmentUtil.addUncreatedSettings(departmentBO.getDepartmentSettings());
			/**End :: ZHPE-9327*/
			setUploadHoursMinutesFromDepartment(departmentBO);
		} catch (Exception e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM066",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :getDepartment()");
		return departmentBO;
	}
	
	private Object validateShortCodes(DepartmentSettings departmentSetting) throws Exception {
		logger.debug("Begin :" + getClass().getName() + " :validateShortCodes()");
		MobileBO mobileBO = (MobileBO) departmentSetting.getObjectValue();
		List<ShortCode> shortCodes = mobileBO.getShortCodes();
		List<CampaignBO> campaignList = listSMSCampaigns();
		if(campaignList!=null && !campaignList.isEmpty()){
			for(ShortCode shortCode : shortCodes){
				for (Object list : campaignList) {
					CampaignBO campaignBo = objectMapper.convertValue(list, CampaignBO.class);
					SmsCampaign smsCampaign = (SmsCampaign) campaignBo.getCampaign();
					if(smsCampaign.getShortcodeID() != null && smsCampaign.getShortcodeID().equals(shortCode.getShortCode())){
						shortCode.setIsUsedIncampaign(true);
					}
					for(KeyWord keyword : shortCode.getKeyWords()){
						if(smsCampaign.getKeywordID() != null && smsCampaign.getKeywordID().equals(keyword.getName())){
							keyword.setIsUsedIncampaign(true);
						}
					}
				}
			}
		}
		logger.debug("End :" + getClass().getName() + " :validateShortCodes()");
		return departmentSetting;
	}

	private void setScheduleNextDue(DepartmentBO departmentBO) throws IOException, JsonParseException, JsonMappingException{
		for(DepartmentSettings departmentSetting : departmentBO.getDepartmentSettings()){
			if(Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
				AdobeAnalyticsBO adobeAnalyticsBO=objectMapper.convertValue(departmentSetting.getObjectValue(),AdobeAnalyticsBO.class);
				AdobeRunDetailsBO neededRunDetail=null;
				for(AdobeRunDetailsBO runDetail : adobeAnalyticsBO.getRunDetails()){
					if(!runDetail.getOnDemandUpload())
						neededRunDetail=runDetail;
				}
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.HOUR_OF_DAY,adobeAnalyticsBO.getUploadHours());
				cal.set(Calendar.MINUTE,adobeAnalyticsBO.getUploadMinutes());
				if(neededRunDetail==null){
					neededRunDetail=new AdobeRunDetailsBO();
					neededRunDetail.setOnDemandUpload(false);
					neededRunDetail.setScheduleNextDue(cal.getTime());
					neededRunDetail.setStatus('W');
					adobeAnalyticsBO.getRunDetails().add(neededRunDetail);
				}else{
					neededRunDetail.setScheduleNextDue(cal.getTime());
				}
				departmentSetting.setObjectValue(adobeAnalyticsBO);
			}
		}
	}
	
	private void setUploadHoursMinutesFromDepartment(DepartmentBO departmentBO){
		for(DepartmentSettings departmentSetting : departmentBO.getDepartmentSettings()){
			if(Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
				AdobeAnalyticsBO adobeAnalyticsBO=(AdobeAnalyticsBO) departmentSetting.getObjectValue();
				AdobeRunDetailsBO neededRunDetail=null;
				for(AdobeRunDetailsBO runDetail : adobeAnalyticsBO.getRunDetails()){
					if(!runDetail.getOnDemandUpload())
						neededRunDetail=runDetail;
				}
				if(neededRunDetail!=null && neededRunDetail.getScheduleNextDue()!=null){
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(neededRunDetail.getScheduleNextDue());
					adobeAnalyticsBO.setUploadHours(calendar.get(Calendar.HOUR_OF_DAY));
					adobeAnalyticsBO.setUploadMinutes(calendar.get(Calendar.MINUTE));
				}
			}
		}
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public void deleteDepartment(Long deptId) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :deleteDepartment()");
		try {
			boolean exists = isDepartmentExists(deptId);
			if (!exists)
				throw new AdminException("ADM005", new Object[] { deptId });
			departmentDao.deleteDepartment(deptId);
		} catch (Exception e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM067",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :deleteDepartment()");
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isDepartmentExists(Long deptId) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :isDepartmentExists()");
		Boolean exists = false;
		try {
			if (deptId == null || deptId < 0)
				throw new AdminException("ADM005", new Object[] { deptId });
			exists = departmentDao.isDepartmentExists(deptId);
		} catch (Exception e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM068",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :isDepartmentExists()");
		return exists;
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<DepartmentBO> listDepartments(ListingCriteria listingCriteria, BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :listDepartments()");
		List<DepartmentBO> departmentsList = new ArrayList<>();
		try {
			listingCriteria.setColumnNames(Constants.ADM_DEPARTMENT_COLUMNS);
			listingCriteriaValidator.validate(listingCriteria, bindingResult);
			if (!bindingResult.hasErrors())
				departmentsList = departmentDao.listDepartments(listingCriteria);
		} catch (Exception e) {
			logger.error("Error while listing departments :: ", e);
			throw new AdminException("ADM069",e);
		}
		logger.debug("End :" + getClass().getName() + " :listDepartments()");
		return departmentsList;
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Long departmentsTotalCount(ListingCriteria listingCriteria, BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :departmentsTotalCount()");
		Long departmentRecordCount = 0L;
		try {
			listingCriteria.setColumnNames(Constants.ADM_DEPARTMENT_COLUMNS);
			listingCriteriaValidator.validate(listingCriteria, bindingResult);
			if (!bindingResult.hasErrors())
				departmentRecordCount = departmentDao.departmentsTotalCount(listingCriteria);
		} catch (Exception e) {
			logger.error("Error while get departments count :: ", e);
			throw new AdminException("ADM070",e);
		}
		logger.debug("End :" + getClass().getName() + " :departmentsTotalCount()");
		return departmentRecordCount;
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean departmentNameExists(String departmentName) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :departmentNameExists()");
		Boolean exists = false;
		try {
			if (departmentName == null || departmentName.trim().length() == 0)
				throw new AdminException("ADM007");
			ListingCriteria listingCriteria = new ListingCriteria();
			listingCriteria.setNameLike("");
			listingCriteria.setNameEquals(departmentName);
			listingCriteria.setPageNumber(1L);
			listingCriteria.setPageSize(Long.MAX_VALUE);
			listingCriteria.setSortBy("asc");
			listingCriteria.setSortUsing("departmentid");
			List<DepartmentBO> departments = departmentDao.listDepartments(listingCriteria);
			if (!departments.isEmpty())
				exists = true;
		} catch (Exception e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM071",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :departmentNameExists()");
		return exists;
	}
	
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	private Long saveDepartment(DepartmentBO department, BindingResult bindingResult,boolean isUpdateAudit) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :saveDepartment()");
		Long departmentID = 0L;
		Boolean isCreateDepartment=false;
		try {
			departmentValidator.validate(department, bindingResult);
			if (!bindingResult.hasErrors()){
				setScheduleNextDue(department);
				if(department.getDepartmentID()==null || department.getDepartmentID()==0)
					isCreateDepartment=true;
				departmentID = departmentDao.saveDepartment(department,isUpdateAudit);
				if(isCreateDepartment){
					createTrashFolders(departmentID);
					departmentDao.addDeparmentToUser(departmentID);
					webPageService.saveDefaultWebPages(departmentID);
				}
			}
		} catch(AdminException e){
			logger.error("Error while saving department :: ", e);
			throw e;
		} catch(DuplicateKeyException e){
			logger.error("Error while saving department :: ", e);
			throw new AdminException("ADM016", new Object[]{department.getDepartmentName()});
		}catch (Exception e) {
			logger.error("Error while saving department :: ", e);
			throw new AdminException("ADM072",e);
		}
		logger.debug("End :" + getClass().getName() + " :saveDepartment()");
		return departmentID;
	}
	
	@Override
	public Long saveDepartment(DepartmentBO department, BindingResult bindingResult) throws AdminException {
		return saveDepartment(department, bindingResult,true);
	}

	/**
	 * 
	 * Method Name : saveFolder Description : The Method "saveFolder" is used
	 * for folder saving Date : Jul 29, 2016, 3:21:00 PM
	 * 
	 * @param folder
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public FolderBO saveFolder(FolderBO folder, BindingResult errors) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :saveFolder()");
		FolderBO updatedFolder=null;
		long id = 0;
		boolean isUpdate = false;
		try {
			folderValidator.validate(folder, errors);
			if (!errors.hasErrors()) {
				if (!isDepartmentExists(folder.getDepartmentid())) {
					errors.rejectValue("departmentid",
							messageSource.getMessage("F00053", new Object[] {}, LocaleContextHolder.getLocale()));
				}
				DepartmentBO department= getDepartment(folder.getDepartmentid());
				if(department.getDepartmentName().equalsIgnoreCase(folder.getFoldername())){
					errors.rejectValue("departmentid",
							messageSource.getMessage("ADM114", new Object[] {folder.getFoldername()}, LocaleContextHolder.getLocale()));
				}
				if (folder.getFolderid() != null && folder.getFolderid() > 0) {
					FolderBO folderObj = folderDao.findFolder(folder.getFoldername(), folder.getType(),
							folder.getDepartmentid());
					if (folderObj != null && folderObj.getFolderid().equals(folder.getFolderid())) {
						isUpdate = true;
					}
				}
				if (!isUpdate && checkIfFolderExists(folder.getFoldername(), folder.getType(),
						folder.getDepartmentid(),folder.getFolderid())) {
					errors.rejectValue("foldername",
							messageSource.getMessage("ADM028", new Object[] {folder.getFoldername()}, LocaleContextHolder.getLocale()));
				}
				if (!errors.hasErrors()) {
					if(folder.getFolderid()!=null && folder.getFolderid() > 0)
						folder.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
					if(folder.getFolderid()==null || folder.getFolderid() <= 0)
						folder.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
					id = folderDao.saveFolder(folder);
					updatedFolder = folderDao.getFolder(id);
				}
			}
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while saving/updating folder", dae);
			throw new AdminException("E00001",dae);
		} catch(Exception e){
			logger.error("Unexpected error has occured while saving/updating folder", e);
			throw new AdminException("ADM073",e);
		}
		logger.debug("Ends :" + getClass().getName() + " :saveFolder()");
		return updatedFolder;
	}

	/**
	 * Check if folder exists with type and dept.
	 *
	 * @param folderName
	 *            the folder name
	 * @param type
	 *            the type
	 * @param departmentId
	 *            the department id
	 * @return the boolean
	 * @throws AdminException
	 */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean checkIfFolderExists(String folderName, Character type, Long departmentId, Long folderId)
			throws AdminException {
		return folderDao.checkIfFolderExists(folderName, type, departmentId,folderId);
	}

	/**
	 * 
	 * Method Name : getFolder Description : The Method "getFolder" is used for
	 * Date : Jul 29, 2016, 3:45:51 PM
	 * 
	 * @param folderId
	 * @param exceptions
	 * @return
	 * @throws AdminException
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public FolderBO getFolder(Long folderId) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getFolder()");
		FolderBO folder = null;
		try {
			folder = folderDao.getFolder(folderId);
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while fetching folder", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception jpx) {
			logger.error("Exception while while fetching folder", jpx);
			throw new AdminException("E00002",jpx);
		}
		logger.debug("Ends :" + getClass().getName() + " :getFolder()");
		return folder;
	}

	/**
	 * List folders.
	 *
	 * @param listingCriteria
	 *            the listing criteria
	 * @param result
	 *            the result
	 * @return the list
	 * @throws AdminException
	 *             the admin exception
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<FolderBO> listFolders(FoldersListingCriteria listingCriteria, BindingResult result) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getFolder()");
		List<FolderBO> folderBOList = null;
		try {
			listingCriteriaValidator.validate(listingCriteria, result);
			foldersListingCriteriaValidator.validate(listingCriteria, result);
			if (!result.hasErrors()) {
				folderBOList = folderDao.listFolders(listingCriteria);
			}
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while fetching folder", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception jpx) {
			logger.error("Exception while while fetching folder", jpx);
			throw new AdminException("E00002",jpx);
		}
		return folderBOList;
	}

	/**
	 * 
	 * Method Name : deleteFolder Description : The Method "deleteFolder" is
	 * used for Date : Jul 29, 2016, 4:54:55 PM
	 * 
	 * @param folderId
	 * @return
	 * @throws AdminException
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteFolder(Long folderId) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getFolder()");
		Boolean result = false;
		FolderBO folderObj = null;
		try {
			folderObj=getFolder(folderId);
			if (folderObj == null) {
				logger.error("No Folder exists with the given ID " + folderId);
				throw new AdminException("F00049");
			}
			checkForFolderDependents(folderObj);
			result = folderDao.deleteFolder(folderId);
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while deleting folder", dae);
			throw new AdminException("E00001",dae);
		} catch (AdminException ae) {
			logger.error("Exception while while deleting folder", ae);
			throw ae;
		} catch (Exception jpx) {
			logger.error("Exception while while deleting folder", jpx);
			throw new AdminException("E00002",jpx);
		}
		return result;
	}
	
	private void checkForFolderDependents(FolderBO folderObj) throws AdminException{
		List<ContentTemplateBO> contentList=getContentsByFolderId(folderObj.getFolderid());
		if(contentList!=null && contentList.size()>0)
			throw new AdminException("ADM035",new Object[]{folderObj.getFoldername()});
		List<Conversation> conversationsList=getConversationsByFolderId(folderObj.getFolderid());
		if(conversationsList!=null && conversationsList.size()>0)
			throw new AdminException("ADM034",new Object[]{folderObj.getFoldername()});
	}
	
	public List<Conversation> getConversationsByFolderId(Long folderId) throws AdminException{
		List<Conversation> conversationsList= new ArrayList<>();
		try{
			ConversationCriteriaBO conversationCriteria=new ConversationCriteriaBO();
			conversationCriteria.setFolderId(folderId);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(conversationCriteria);
			ResponseEntity<HashMap<String, Object>> conversationsMap= restHandler.exchange(conversationEndPoint+"/listConversations",HttpMethod.POST,entity,new ParameterizedTypeReference<HashMap<String, Object>>() {});
			if(conversationsMap != null){
				Map res = objectMapper.convertValue(conversationsMap.getBody(), HashMap.class);
				List list = objectMapper.convertValue(res.get("conversations"), List.class);
				for(int i=0; i<list.size();i++){
					conversationsList.add( objectMapper.convertValue(list.get(i), Conversation.class));
				}
			}
		}catch(Exception e){
			throw new AdminException("ADM042",e);
		}
		return conversationsList;
	}
	
	public List<ContentTemplateBO> getContentsByFolderId(Long folderId) throws AdminException{
		List<ContentTemplateBO> contentsList = new ArrayList<>();
		ResponseEntity<Map<String,Object>> retValue=null;
		try{
			ContentCriteriaBO contentCriteriaBO=new ContentCriteriaBO();
			contentCriteriaBO.setFolderId(folderId);
			contentCriteriaBO.setPageNumber(1L);
			contentCriteriaBO.setPageSize(Long.MAX_VALUE);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(contentCriteriaBO);
			retValue=restHandler.exchange(contentEndPoint+"/listcontent",HttpMethod.POST,entity,new ParameterizedTypeReference<Map<String, Object>>() {});
			Map res = objectMapper.convertValue(retValue.getBody(), HashMap.class);
			List list = objectMapper.convertValue(res.get("contentList"), List.class);
			for(int i=0; i<list.size();i++){
				contentsList.add( objectMapper.convertValue(list.get(i), ContentTemplateBO.class));
			}
		}catch(Exception e){
			throw new AdminException("ADM043",e);
		}
		return contentsList;
	}

	
	/**
	 * 
	 * Method Name : saveCategory Description : The Method "saveCategory" is
	 * used for Date : Jul 29, 2016, 5:28:25 PM
	 * 
	 * @param category
	 * @param result
	 * @return
	 * @throws AdminException
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public CategoryBO saveCategory(CategoryBO category, BindingResult result) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :saveCategory()");
		long id = 0;
		CategoryBO updatedCategory=null;
		boolean isUpdate = false;
		try {
			categoryValidator.validate(category, result);
			if (!result.hasErrors()) {
				if (!isDepartmentExists(category.getDepartmentid())) {
					result.rejectValue("departmentid",
							messageSource.getMessage("F00053", new Object[] {}, LocaleContextHolder.getLocale()));
				}
				DepartmentBO department= getDepartment(category.getDepartmentid());
				if(department.getDepartmentName().equalsIgnoreCase(category.getCategorycode())){
					result.rejectValue("departmentid",
							messageSource.getMessage("ADM115", new Object[] {category.getCategorycode()}, LocaleContextHolder.getLocale()));
				}
				if (category.getCategoryid() != null && category.getCategoryid() > 0) {
					CategoryBO categoryBOObj = categoryDao.findCategoryByTypeAndDept(
							category.getType(), category.getCategorycode(), category.getDepartmentid());
					//isUpdate = true;
					if (categoryBOObj != null && categoryBOObj.getCategoryid().equals(category.getCategoryid())) {
						isUpdate = true;
					}
				}
				if (!isUpdate && checkIfCategoryExistsWithTypeAndDept(category.getCategorycode(),category.getType(),category.getDepartmentid(), category.getCategoryid())) {
					result.rejectValue("categorycode",
							messageSource.getMessage("ADM031", new Object[] {category.getCategorycode()}, LocaleContextHolder.getLocale()));
				}
				if(!result.hasErrors()) {
				   if(category.getCategoryid()!=null && category.getCategoryid() > 0)
					   category.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
				   if(category.getCategoryid()==null || category.getCategoryid() <= 0)
					   category.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
				   id = categoryDao.saveCategory(category);
				   updatedCategory = categoryDao.getCategory(id);
				}
				if(updatedCategory != null){
					if(updatedCategory.getDescription()!=null)
						updatedCategory.setDescription(Jsoup.clean(updatedCategory.getDescription(), Whitelist.none()));
					if(updatedCategory.getCategorycode()!=null)
						updatedCategory.setCategorycode(Jsoup.clean(updatedCategory.getCategorycode(), Whitelist.none()));
					if(updatedCategory.getCreatedBy()!=null)
						updatedCategory.setCreatedBy(Jsoup.clean(updatedCategory.getCreatedBy(), Whitelist.none()));
					if(updatedCategory.getUpdatedBy()!=null)
						updatedCategory.setUpdatedBy(Jsoup.clean(updatedCategory.getUpdatedBy(), Whitelist.none()));
				}
			}
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while creating category", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception jpx) {
			logger.error("Exception while while creating category", jpx);
			throw new AdminException("E00002",jpx);
		}
		logger.debug("Ends :" + getClass().getName() + " :saveCategory()");
		return updatedCategory;
	}

	/**
	 * 
	 * Method Name : getCategory Description : The Method "getCategory" is used
	 * for Date : Jul 29, 2016, 5:38:15 PM
	 * 
	 * @param categoryId
	 * @return
	 * @throws AdminException
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public CategoryBO getCategory(Long categoryId) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getCategory()");
		CategoryBO category = null;
		try {
			category = categoryDao.getCategory(categoryId);
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while fetching category", dae);
			throw new AdminException("E00001",dae);
		} catch (Exception jpx) {
			logger.error("Exception while while fetching category", jpx);
			throw new AdminException("E00002",jpx);
		}
		logger.debug("Ends :" + getClass().getName() + " :getCategory()");
		return category;
	}

	/**
	 * 
	 * Method Name : listCategories Description : The Method "listCategories" is
	 * used for Date : Jul 29, 2016, 5:42:53 PM
	 * 
	 * @param listingCriteria
	 * @param bindingResult
	 * @return
	 * @throws AdminException
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<CategoryBO> listCategories(CategoriesListingCriteria listingCriteria, Errors errors)
			throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :listCategories()");
		List<CategoryBO> categoriesList = null;
		try {
			listingCriteria.setColumnNames(Constants.ADM_CATEGORY_COLUMNS);
			listingCriteriaValidator.validate(listingCriteria, errors);
			categoriesListingCriteriaValidator.validate(listingCriteria, errors);
			if (!errors.hasErrors())
				categoriesList = categoryDao.listCategories(listingCriteria);
		} catch (Exception jpx) {
			logger.error("Exception while while listing categories", jpx);
			throw new AdminException("E00002",jpx);
		}
		logger.debug("End :" + getClass().getName() + " :listCategories()");
		return categoriesList;
	}

	/**
	 * 
	 * Method Name : deleteCategory Description : The Method "deleteCategory" is
	 * used for Date : Jul 29, 2016, 5:45:25 PM
	 * 
	 * @param categoryId
	 * @return
	 * @throws AdminException
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteCategory(Long categoryId) throws AdminException {
		Boolean result = false;
		CategoryBO categoryBO = null;
		try {
			categoryBO=getCategory(categoryId);
			if (categoryBO == null) {
				logger.error("No Category exists with the given ID " + categoryId);
				throw new AdminException("F00051");
			}
			checkForCategoryDependents(categoryBO);
			result = categoryDao.deleteCategory(categoryId);
		} catch (DataAccessException dae) {
			logger.error("Data Access Exception while deleting category", dae);
			throw new AdminException("E00001",dae);
		} catch (AdminException ae) {
			logger.error("Exception while while deleting category", ae);
			throw ae;
		}  catch (Exception jpx) {
			logger.error("Exception while while deleting category", jpx);
			throw new AdminException("E00002",jpx);
		}
		return result;
	}

	private void checkForCategoryDependents(CategoryBO categoryBO) throws AdminException{
		List<ContentTemplateBO> contentList=getContentsByCategoryId(categoryBO.getCategoryid());
		if(contentList!=null && contentList.size()>0)
			throw new AdminException("ADM039",new Object[]{categoryBO.getCategorycode()});
		List<Conversation> conversationsList=getConversationsByCategoryId(categoryBO.getCategoryid());
		if(conversationsList!=null && conversationsList.size()>0)
			throw new AdminException("ADM038",new Object[]{categoryBO.getCategorycode()});
	}
	
	private List<Conversation> getConversationsByCategoryId(Long categoryId) throws AdminException{
		List<Conversation> conversationsList=new ArrayList<>();
		try{
			ConversationCriteriaBO conversationCriteria=new ConversationCriteriaBO();
			conversationCriteria.setCatCode(categoryId);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(conversationCriteria);
			ResponseEntity<Map<String, Object>> conversationsMap=restHandler.exchange(conversationEndPoint+"/listConversations",HttpMethod.POST,entity,new ParameterizedTypeReference<Map<String, Object>>() {});
			if(conversationsMap != null){
				Map res = objectMapper.convertValue(conversationsMap.getBody(), HashMap.class);
				List list = objectMapper.convertValue(res.get("conversations"), List.class);
				for(int i=0; i<list.size();i++){
					conversationsList.add( objectMapper.convertValue(list.get(i), Conversation.class));
				}
			}
		}catch(Exception e){
			throw new AdminException("ADM042",e);
		}
		return conversationsList;
	}
	
	private List<ContentTemplateBO> getContentsByCategoryId(Long categoryId) throws AdminException{
		List<ContentTemplateBO> contentsList = new ArrayList<>();
		ResponseEntity<Map<String,Object>> retValue=null;
		try{
			ContentCriteriaBO contentCriteriaBO=new ContentCriteriaBO();
			contentCriteriaBO.setCatCode(categoryId.toString());
			contentCriteriaBO.setPageNumber(1L);
			contentCriteriaBO.setPageSize(Long.MAX_VALUE);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(contentCriteriaBO);
			retValue=restHandler.exchange(contentEndPoint+"/listcontent",HttpMethod.POST,entity,new ParameterizedTypeReference<Map<String, Object>>() {});
			if(retValue != null){
				Map res = objectMapper.convertValue(retValue.getBody(), HashMap.class);
				List list = objectMapper.convertValue(res.get("contentList"), List.class);
				for(int i=0; i<list.size();i++){
					contentsList.add( objectMapper.convertValue(list.get(i), ContentTemplateBO.class));
				}
			}
		}catch(Exception e){
			throw new AdminException("ADM043",e);
		}
		return contentsList;
	}
	
	
	@Override
	public DepartmentBO createDepartment(String departmentName, Boolean approvalNeeded,Boolean domainKeysNeeded, BindingResult bindingResult) {
		logger.debug("Start :" + getClass().getName() + " :createDepartment()");
		try {
			departmentValidationService.checkDepartmentProperties(departmentName,bindingResult);
			if (!bindingResult.hasErrors()) {
				DepartmentBO departmentBO = new DepartmentBO();
				departmentBO.setDepartmentID(0L);
				departmentBO.setApprovalMandatory(approvalNeeded);
				departmentBO.setDepartmentName(departmentName.trim());
				departmentBO.setDomainKeysUsed(domainKeysNeeded);
				departmentBO.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
				departmentBO.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
				List<DepartmentSettings> departmentSettings = new ArrayList<>();
				departmentUtil.addNewDepartmentNotifications(departmentSettings);
				departmentUtil.addNewDepartmentAddressLists(departmentSettings);
				departmentUtil.addNewDepartmentParameters(departmentSettings);
				departmentUtil.addNewDepartmentUnsubRules(departmentSettings);
				departmentUtil.addNewDepartmentGoogleAnalytics(departmentSettings);
				departmentUtil.addNewDepartmentAdobeAnalytics(departmentSettings);
				departmentUtil.addNewDepartmentMobileDetails(departmentSettings);
				departmentUtil.addNewDepartmentOtherWebAnalytics(departmentSettings);
				departmentUtil.addNewDepartmentAudienceSettings(departmentSettings);
				departmentBO.setDepartmentSettings(departmentSettings);
				return departmentBO;
			}
		} catch (Exception e) {
			logger.error("Error while creating department :: ", e);
			bindingResult.reject(
					messageSource.getMessage("ADM056", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		logger.debug("End :" + getClass().getName() + " :createDepartment()");
		return null;
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isDepartmentExists(Long deptId, Errors errors) {
		logger.debug("Start :" + getClass().getName() + " :isDepartmentExists()");
		Boolean exists = false;
		try {
			if (deptId == null || deptId < 0){
				errors.reject(
						messageSource.getMessage("ADM005", new Object[] { deptId }, LocaleContextHolder.getLocale()),
						"Invalid DepartmentID Specified.");
			}
			if (!errors.hasErrors()) 
				exists = departmentDao.isDepartmentExists(deptId);
		} catch (Exception e) {
			logger.error("Some thing went wrong while checking whether the department exists or not :: ", e);
			errors.reject(
					messageSource.getMessage("ADM071", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		logger.debug("End :" + getClass().getName() + " :isDepartmentExists()");
		return exists;
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean departmentNameExists(String departmentName, BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :departmentNameExists()");
		Boolean exists = false;
		try {
			if (departmentName == null || departmentName.trim().length() == 0)
				bindingResult
						.reject(messageSource.getMessage("ADM007", new Object[] {}, LocaleContextHolder.getLocale()));
			if (!bindingResult.hasErrors()) {
				Map<String, String> deptNameMap = new HashMap<String, String>();
				deptNameMap.put("name", departmentName);
				exists = departmentDao.isDepartmentExistsByNameOrId(deptNameMap);
			}
		} catch (Exception e) {
			logger.error("Some thing went wrong while checking whether the department exists or not :: ", e);
			throw new AdminException("ADM071",e);
		}
		logger.debug("End :" + getClass().getName() + " :departmentNameExists()");
		return exists;
	}

	@Override
	public void addDomainToDepartmentOptoutRules(String domainCode, BindingResult bindingResult) throws AdminException,Exception {
		try {
			List<DepartmentBO> departmentsList = listDepartments(new ListingCriteria(), bindingResult);
			for (DepartmentBO department : departmentsList) {
				DepartmentBO fullDepartment = getDepartment(department.getDepartmentID());
				for (DepartmentSettings departmentSetting : fullDepartment.getDepartmentSettings()) {
					if (departmentSetting != null
							&& departmentSetting.getObjectKey().equalsIgnoreCase(Constants.DEPARTMENT_UNSUBRULES_KEY)) {
						UnsubRulesBO unsubrulesBO = (UnsubRulesBO) departmentSetting.getObjectValue();
						DomainOptoutRule rule = new DomainOptoutRule();
						rule.setDomainCode(domainCode);
						rule.setThreshold(5);
						rule.setType('S');
						rule.setIsEnabled(true);
						unsubrulesBO.getDomainOptoutRules().add(rule);
						rule = new DomainOptoutRule();
						rule.setDomainCode(domainCode);
						rule.setThreshold(3);
						rule.setType('N');
						rule.setIsEnabled(true);
						unsubrulesBO.getDomainOptoutRules().add(rule);
						rule = new DomainOptoutRule();
						rule.setDomainCode(domainCode);
						rule.setThreshold(1);
						rule.setType('H');
						rule.setIsEnabled(true);
						unsubrulesBO.getDomainOptoutRules().add(rule);
						rule = new DomainOptoutRule();
						rule.setDomainCode(domainCode);
						rule.setThreshold(10);
						rule.setType('B');
						rule.setIsEnabled(true);
						unsubrulesBO.getDomainOptoutRules().add(rule);
						List<DepartmentSettings> list=new ArrayList<>();
						list.add(departmentSetting);
						fullDepartment.setDepartmentSettings(list);
						saveDepartment(fullDepartment, bindingResult,false);
					}
				}
			}
		} catch (AdminException e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM074",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :addDomainToDepartmentOptoutRules()");
	}

	/**
	 * @param categoryCode
	 * @param type
	 * @param deptId
	 * @return
	 * @throws AdminException
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean checkIfCategoryExistsWithTypeAndDept(String categoryCode, Character type,Long deptId, Long categoryId) throws AdminException {
		return categoryDao.checkIfCategoryExistsWithTypeAndDept(categoryCode, type, deptId, categoryId);
	}

	/**
	 * Method Name : findCategoryByTypeAndDept Description : The Method
	 * "findCategoryByTypeAndDept" is used for Date : Jul 29, 2016, 5:24:15 PM.
	 *
	 * @param type the type
	 * @param categoryCode the category code
	 * @param deptId the dept id
	 * @return :
	 * @throws AdminException the admin exception
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public CategoryBO findCategoryByTypeAndDept(Character type, String categoryCode, Long deptId)
			throws AdminException {
		return categoryDao.findCategoryByTypeAndDept(type, categoryCode, deptId);
	}

	/**
	 * 
	 * Method Name : findFolder Description : The Method
	 * "findFolder" is used for Date : Jul 29, 2016, 5:24:15 PM
	 * 
	 * @param folderName
	 * @param type
	 * @param deptId
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public FolderBO findFolder(String folderName, Character type, Long deptId) throws AdminException {
		return folderDao.findFolder(folderName, type, deptId);
	}
	
	/**
	 * @param departmentID
	 * @throws Exception 
	 */
	public void createTrashFolders(Long departmentID) throws Exception{
		
		FolderBO trashAll=new FolderBO();
		trashAll.setDepartmentid(departmentID);
		trashAll.setFoldername(Constants.FOLDER_TRASH);
		trashAll.setType(Constants.FOLDER_TYPE_ALL);
		trashAll.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		trashAll.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		trashAll.setParentfolderid(0L);
		folderDao.saveFolder(trashAll);
		
		FolderBO trashReport=new FolderBO();
		trashReport.setDepartmentid(departmentID);
		trashReport.setFoldername(Constants.FOLDER_TRASH);
		trashReport.setType(Constants.FOLDER_TYPE_REPORTS);
		trashReport.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		trashReport.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		trashReport.setParentfolderid(0L);
		folderDao.saveFolder(trashReport);
	}
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public void deleteDomainFromDepartmentOptoutRules(String domainCode) throws AdminException {
		try {
			//Departments Listing
			ListingCriteria listingCriteria = new ListingCriteria();
			listingCriteria.setNameLike("");
			listingCriteria.setPageNumber(1L);
			listingCriteria.setPageSize(Long.MAX_VALUE);
			listingCriteria.setSortBy("asc");
			listingCriteria.setSortUsing("departmentid");
			List<DepartmentBO> departmentsList = departmentDao.listDepartments(listingCriteria);
			for (DepartmentBO department : departmentsList) {
				DepartmentBO fullDepartment = getDepartment(department.getDepartmentID());
				for (DepartmentSettings departmentSetting : fullDepartment.getDepartmentSettings()) {
					if (departmentSetting != null && departmentSetting.getObjectKey().equalsIgnoreCase(Constants.DEPARTMENT_UNSUBRULES_KEY)) {
						UnsubRulesBO unsubrulesBO = (UnsubRulesBO) departmentSetting.getObjectValue();
						List<DomainOptoutRule> neededRules=new ArrayList<>();
						for(DomainOptoutRule rule : unsubrulesBO.getDomainOptoutRules()){
							if(!rule.getDomainCode().equalsIgnoreCase(domainCode))
								neededRules.add(rule);
						}
						unsubrulesBO.setDomainOptoutRules(neededRules);
						List<DepartmentSettings> list=new ArrayList<>();
						list.add(departmentSetting);
						fullDepartment.setDepartmentSettings(list);
						departmentDao.saveDepartment(fullDepartment,false);
					}
				}
			}
		} catch (AdminException e) {
			throw e;
		}catch(Exception e){
			throw new AdminException("ADM075",e);
		}
		logger.debug("End :" + getClass().getName() + " :addDomainToDepartmentOptoutRules()");
	}

	@Override
	public Boolean deleteConversations(List<Long> ids) throws AdminException {
		try {
			Boolean IsDeleted =false;
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(ids);
			ResponseEntity<ResponseObject> response = restHandler.exchange(conversationEndPoint + "/deleteConversation",HttpMethod.POST,entity, ResponseObject.class);
			if(response != null && response.getBody().getMessage() !=null && response.getBody().getMessage().equals("true"))
				IsDeleted =true;
			return IsDeleted;
		} catch (Exception e) {
			throw new AdminException("ADM076", e);
		}
	}

	@Override
	public Boolean deleteContents(String templateIds, String templateType) throws AdminException {
		try {
			String url = contentEndPoint + "/trashContents";
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("selectedTemplateIds", templateIds);
			map.add("selectedTemplateType", templateType);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(map);
			ResponseEntity<Boolean> status = restHandler.exchange(url, HttpMethod.POST,entity, Boolean.class);
			return status.getBody();
		} catch (Exception e) {
			throw new AdminException("ADM076", e);
		}
	}

	@Override
	public List<Conversation> getTrashConversations(Long deptId) throws AdminException {
		logger.debug("Begin: getTrashConversations");
		try {
			String uri = conversationEndPoint + "/getTrashConversations/" + deptId;
			logger.debug("url:"+uri);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(null);
			logger.debug("Obtained Http Entity object");
			ResponseEntity<List> response = restHandler.exchange(uri, HttpMethod.GET, entity, List.class);
			List<Conversation> conversationList = response.getBody();
			logger.debug("Number of trashed conversations:"+conversationList.size());
			return conversationList;
		} catch (Exception e) {
			logger.error("Error while getting trashed conversations");
			throw new AdminException("ADM077", e);
		}
	}

	@Override
	public List<ContentTemplateBO> getTrashContents(Long folderId) throws AdminException {
		logger.debug("Begin: getTrashContents");
		List<ContentTemplateBO> contentList = new ArrayList<>();
		ResponseEntity<Map<String,Object>> retValue=null;
		try {
			ContentCriteriaBO contentCriteria = new ContentCriteriaBO();
			contentCriteria.setFolderId(folderId);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(contentCriteria);
			logger.debug("Obtained Http Entity object");
			retValue=restHandler .exchange(contentEndPoint+"/listcontent",HttpMethod.POST,entity,new ParameterizedTypeReference<Map<String, Object>>() {});
			if(retValue != null){
				Map res = objectMapper.convertValue(retValue.getBody(), HashMap.class);
				List list = objectMapper.convertValue(res.get("contentList"), List.class);
				for(int i=0; i<list.size();i++){
					contentList.add( objectMapper.convertValue(list.get(i), ContentTemplateBO.class));
				}
			}
			logger.debug("Number of trashed contents:"+contentList.size());
			return contentList;
		} catch (Exception e) {
			logger.error("Error while getting trashed content list");
			throw new AdminException("ADM077", e);
		}
	}

	@Override
	public String restoreConversations(List<Long> convIds) throws AdminException {
		try {
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(convIds);
			ResponseEntity<String> response = restHandler.exchange(conversationEndPoint + "/convRestoreFromTrash",HttpMethod.POST,entity,
					String.class);
			return response.getBody();
		} catch (Exception e) {
			throw new AdminException("ADM078", e);
		}
	}

	@Override
	public Boolean restoreContents(String templateIds, String templateType) throws AdminException {
		try {
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("selectedTemplateIds", templateIds);
			map.add("selectedTemplateType", templateType);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(map);
			String url = contentEndPoint + "/restoreContentsFromTrash";
			ResponseEntity<Boolean> response = restHandler.exchange(url, HttpMethod.POST,entity, Boolean.class);
			return response.getBody();
		} catch (Exception e) {
			throw new AdminException("ADM078", e);
		}
	}

	@Override
	public String emptyTrashConversations(List<Long> convIds) throws AdminException {
		try {
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(convIds);
			ResponseEntity<String> response =restHandler.exchange(conversationEndPoint + "/deleteConversation",HttpMethod.POST,entity,
					String.class);
			return response.getBody();
		} catch (Exception e) {
			throw new AdminException("ADM079", e);
		}
	}

	@Override
	public Boolean emptyTrashContents(String selectedTrashId, String selectedTemplateType) throws AdminException {
		try {
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("selectedTrashId", selectedTrashId);
			map.add("selectedTemplateType", selectedTemplateType);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(map);
			String url = contentEndPoint + "/emptyTrashContents";
			ResponseEntity<Boolean> response =restHandler.exchange(url, HttpMethod.POST,entity, Boolean.class);
			return response.getBody();
		} catch (Exception e) {
			throw new AdminException("ADM079", e);
		}
	}
	private List<CampaignBO> listSMSCampaigns() throws Exception {
		logger.debug("Begin :" + getClass().getName() + " :ListSMSCampaigns()");
		List<CampaignBO> campaignList =  new ArrayList<>();
		try {
			ResponseEntity<Object> result=null;
			CampaignCriteriaBO campaignCriteria = new CampaignCriteriaBO();
			campaignCriteria.setCampaignType("SMS");
			HttpEntity<Object> entity = new HttpEntity<>(campaignCriteria, ZetaUtil.getHelper().getHeaders());
            try{
            	result= restHandler.exchange(getEndPoint() + "/listAllCampaign",HttpMethod.POST, entity, Object.class);
            }catch(HttpClientErrorException e){
            	logger.debug("Empty campaignList is fetched :" + getClass().getName() + " :ListSMSCampaigns()");
            	return campaignList;
            }
			Map res = objectMapper.convertValue(result.getBody(), HashMap.class);
			campaignList = objectMapper.convertValue(res.get("result"),List.class);
		} catch (AdminException e) {
			throw e;
		}
		logger.debug("End :" + getClass().getName() + " :ListSMSCampaigns()");
		return campaignList;
	}
	
	private String getEndPoint() throws Exception{
		return ZetaUtil.getHelper().getEndpoint("conversation").toString(); 
	}
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<DepartmentBO> getAllDepartments(ListingCriteria listingCriteria, BindingResult bindingResult) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :listDepartments()");
		List<DepartmentBO> departmentsList = new ArrayList<>();
		try {
			listingCriteria.setColumnNames(Constants.ADM_DEPARTMENT_COLUMNS);
			listingCriteriaValidator.validate(listingCriteria, bindingResult);
			if (!bindingResult.hasErrors())
				departmentsList = departmentDao.getAllDepartments(listingCriteria);
		} catch (Exception e) {
			logger.error("Error while listing departments :: ", e);
			throw new AdminException("ADM069",e);
		}
		logger.debug("End :" + getClass().getName() + " :listDepartments()");
		return departmentsList;
	}
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<DepartmentSettings> getAllDepartmentSettings() throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getAllDepartmentSettings()");
		List<DepartmentSettings> departmentSettingsList = new ArrayList<>();
		try {
			departmentSettingsList = departmentDao.getAllDepartmentSettings();
		} catch (Exception e) {
			logger.error("Error while listing departments :: ", e);
			throw new AdminException("ADM069",e);
		}
		logger.debug("End :" + getClass().getName() + " :getAllDepartmentSettings()");
		return departmentSettingsList;
	}
	
	@Override
	public Boolean isDepartmentExistsByNameOrId(Map<String,String> json) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :isDepartmentExistsByName()");
		Boolean exists = false;
		try {
			/*if (departmentName == null || departmentName.isEmpty())
				throw new AdminException("ADM116", new Object[] { departmentName });*/
			exists = departmentDao.isDepartmentExistsByNameOrId(json);
		} catch (Exception e) {
			if (!AdminException.class.isInstance(e))
				throw new AdminException("ADM068",e);
			else
				throw e;
		}
		logger.debug("End :" + getClass().getName() + " :isDepartmentExistsByName()");
		return exists;
	}
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean accessAudienceToAllDepartments(Long audienceId) throws Exception{
		try {
			DeptAudienceBO deptAudienceBO=new DeptAudienceBO();
			deptAudienceBO.setAudienceId(audienceId);
			deptAudienceBO.setIsDefault(false);
			List<DepartmentSettings> updateDept=new ArrayList<>();
			List<DepartmentSettings> departmentSettings=departmentDao.getSpecificPropertys(Constants.DEPARTMENT_AUDIENCE_KEY);
			if (departmentSettings != null && !departmentSettings.isEmpty()){
				for (DepartmentSettings departmentSetting : departmentSettings){
					if (departmentSetting.getObjectValue() != null && departmentSetting.getObjectValue() instanceof List<?>){
						List<DeptAudienceBO> deptAudienceBOs=(List<DeptAudienceBO>)departmentSetting.getObjectValue();
						boolean isExist=false;
						for (DeptAudienceBO existingAudienceBO : deptAudienceBOs){
							if (existingAudienceBO.getAudienceId().equals(audienceId)){
								isExist=true;
								break;
							}
						}
						if(!isExist){
							deptAudienceBOs.add(deptAudienceBO);
							departmentSetting.setObjectValue(deptAudienceBOs);
							updateDept.add(departmentSetting);
						}
						
					}else{
						List<DeptAudienceBO> deptAudienceBOs=new ArrayList<>();
						deptAudienceBOs.add(deptAudienceBO);
						departmentSetting.setObjectValue(deptAudienceBOs);
					}
				}
				return !updateDept.isEmpty() ? departmentDao.batchUpdateDepartmentSettings(updateDept) : false;
			}
		} catch (Exception e) {
			throw e;
		}
		return false;
	}
	@Override
	public List<DeptAudienceBO> getDeptSpecificAudiences(Long departmentId) throws Exception{
		try {
			DepartmentSettings departmentSettings=departmentDao.getDeptSpecificProperty(Constants.DEPARTMENT_AUDIENCE_KEY, departmentId);
			if(departmentSettings != null && departmentSettings.getObjectValue() != null && departmentSettings.getObjectValue() instanceof List<?>){
				List<DeptAudienceBO> deptAudienceBOs=(List<DeptAudienceBO>)departmentSettings.getObjectValue();
				if(deptAudienceBOs != null && !deptAudienceBOs.isEmpty()){
					return departmentUtil.getDepartmentAudiences(deptAudienceBOs);
				}
			}
			return new ArrayList<>();
		} catch (Exception e) {
			throw e;
		}
	}
}

package com.zetainteractive.zetahub.admin.service.impl;

import java.io.IOException;
import java.net.NoRouteToHostException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLHandshakeException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.google.api.client.auth.oauth2.draft10.AccessTokenResponse;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessProtectedResource;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAuthorizationRequestUrl;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson.JacksonFactory;
import com.google.api.services.analytics.Analytics;
import com.google.api.services.analytics.model.Account;
import com.google.api.services.analytics.model.Accounts;
import com.google.api.services.analytics.model.Profile;
import com.google.api.services.analytics.model.Profiles;
import com.google.api.services.analytics.model.Webproperties;
import com.google.api.services.analytics.model.Webproperty;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.service.GoogleAnalyticsService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.GAAccount;
import com.zetainteractive.zetahub.commons.domain.GAAccountProfile;

/**
 * @author Lakshmi.Medarametla
 *
 */
@Component
public class GoogleAnalyticsServiceImpl implements GoogleAnalyticsService{

	
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	MessageSource messageSource;
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	@Override
	public String getGAAuthURL() throws AdminException {
		logger.debug("Begin :"+ getClass().getName()+":getGAAuthURL() ");
		String authURL = "";
		try {
			String clientId = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-app-client-id",null);
			if(clientId==null || "NA".equalsIgnoreCase(clientId))
				throw new AdminException("ADM050");
			String callBackURL = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-callbackurl",null);
			if(callBackURL==null || "NA".equalsIgnoreCase(callBackURL))
				throw new AdminException("ADM051");
			String scopeFromConfigServer=ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-scope",null);
			if(scopeFromConfigServer==null || "NA".equalsIgnoreCase(scopeFromConfigServer))
				throw new AdminException("ADM052");
			authURL = new GoogleAuthorizationRequestUrl(clientId, callBackURL,scopeFromConfigServer).build();
			authURL = authURL + "&access_type=offline&approval_prompt=force";
		}catch(AdminException ee){
			throw ee;
		}catch (Exception ex) {
			logger.error("Unabled to get GA Authorization URL :: ",ex);
			throw new AdminException("ADM019");
		}
		logger.debug("End :"+ getClass().getName()+":getGAAuthURL() ");
		return authURL;
	}
	
	
	@Override
	public GAAccount authorizeGoogleAnalyticsProfile(GAAccount gaAccProObj,BindingResult bindingResult){
		logger.debug("Begin :" + getClass().getName() + ": authorizeGoogleAnalyticsProfile()");
		String webSiteUtl = null;
		long profileId = 0;
		Long accountID = null;
		boolean isProfileExists = false;
		try {
			if (gaAccProObj != null && gaAccProObj.getAccountID() > 0) {
					accountID = gaAccProObj.getAccountID();
					List<GAAccountProfile> accProfiles = gaAccProObj.getGaAccountProfiles();
					try {
						logger.info("AccessToken::" + gaAccProObj.getAccessToken());
						NetHttpTransport netHttpTransport = new NetHttpTransport();
						JacksonFactory jacksonFactory = new JacksonFactory();
						String clientId = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-app-client-id",null);
						if(clientId==null || "NA".equalsIgnoreCase(clientId))
							bindingResult.reject(messageSource.getMessage("ADM050", new Object[] {},LocaleContextHolder.getLocale()));
						String callBackURL = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-callbackurl",null);
						if(callBackURL==null || "NA".equalsIgnoreCase(callBackURL))
							bindingResult.reject(messageSource.getMessage("ADM051", new Object[] {},LocaleContextHolder.getLocale()));
						String clientSecret = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-ga-app-client-secret", null);
						if(clientSecret==null || "NA".equalsIgnoreCase(clientSecret))
							bindingResult.reject(messageSource.getMessage("ADM053", new Object[] {},LocaleContextHolder.getLocale()));
						// Use the authorization code to get an access token and
						// a refresh token.
						// BugFix 17341 - Unable to add an account in GA
						// Integration even though valid details are provided.
						AccessTokenResponse response = null;
						try {
							response = new GoogleAccessTokenRequest.GoogleAuthorizationCodeGrant(netHttpTransport,
									jacksonFactory, clientId, clientSecret, gaAccProObj.getAccessToken(), callBackURL)
											.execute();
						} catch (Exception ioe) {
							logger.error("Error while autorizing GA Account :: ",ioe);
							throw ioe;
						}
						GoogleAccessProtectedResource googleAccessProtectedResource = new
						// BugFix 17341 - Unable to add an account in GA
						// Integration even though valid details are provided.
						GoogleAccessProtectedResource(response.accessToken, netHttpTransport, jacksonFactory, clientId,
								clientSecret, response.refreshToken);
						// BugFix 17415 - Unable to view the GA reports as
						// processing is getting errored due to '401
						// Unauthorized'.
						logger.info("Refreshing accesstoken: " + googleAccessProtectedResource.refreshToken());
						Analytics analytics = Analytics.builder(netHttpTransport, jacksonFactory)
								.setHttpRequestInitializer(googleAccessProtectedResource)
								.setApplicationName("TempTest")
								.build();

						Accounts accounts = analytics.management().accounts().list().execute();

						List<GAAccountProfile> profilesList = new ArrayList<>();

						for (Account account : accounts.getItems()) {
							if (Long.parseLong(account.getId()) == gaAccProObj.getAccountID()) {
								isProfileExists = true;

								gaAccProObj.setAccountID(Long.parseLong(account.getId()));
								gaAccProObj.setAccountName(account.getName());
								gaAccProObj.setGaAuthorized(true);
								gaAccProObj.setIsActive(true);
								// BugFix 17341 - Unable to add an account in GA
								// Integration even though valid details are
								// provided.
								gaAccProObj.setAccessToken(response.refreshToken);

								Webproperties webproperties = analytics.management().webproperties()
										.list(account.getId()).execute();

								// ZET #3546 fix : Unable to configure the ga
								// account
								if (webproperties.getItems() != null) {
									for (Webproperty webproperty : webproperties.getItems()) {

										webSiteUtl = webproperty.getWebsiteUrl();

										Profiles profiles = analytics.management().profiles()
												.list(account.getId(), webproperty.getId()).execute();
										// ZET #3546 fix : Unable to configure
										// the ga account
										if (profiles.getItems() != null) {
											for (int i = 0; i < profiles.getItems().size(); i++) {

												Profile profile = profiles.getItems().get(i);

												GAAccountProfile accountProfile = null;

												profileId = Long.parseLong(profile.getId());
												if (accProfiles != null && !accProfiles.isEmpty()) {
													for (GAAccountProfile accountProfile2 : accProfiles) {
														if (accountProfile2.getProfileID() == profileId) {
															accountProfile = accountProfile2;
															break;
														}
													}
												}

												if (accountProfile == null) {
													accountProfile = new GAAccountProfile();
												}
												accountProfile.setWebpropertyID(webproperty.getId());
												accountProfile.setWebpropertyName(webproperty.getName());
												accountProfile.setWebsiteURL(webSiteUtl);
												accountProfile.setProfileID(profileId);
												accountProfile.setProfileName(profile.getName());
												accountProfile.setIsActive(true);
												// BugFix 17310 - Reschedule is
												// not happened if engine_ga.sh
												// is errored due to Network
												// exceptions
												accountProfile.setRetryCount(0);
												if (i != 0) {
													accountProfile.setIsDefault(false);
												}
												profilesList.add(accountProfile);

											}
										}
									}
								}

								gaAccProObj.setGaAccountProfiles(profilesList);

								break;

							}
						}

						if (!isProfileExists)
							bindingResult.reject(messageSource.getMessage("ADM020", new Object[] {},LocaleContextHolder.getLocale()));
					} catch (HttpResponseException e) {
						logger.error("Error while authorizing GA Account Profile :: ",e);
						bindingResult.reject(messageSource.getMessage("ADM021", new Object[] {},LocaleContextHolder.getLocale()));
					} catch (IOException e) {
						logger.error("Error while authorizing GA Account Profile :: ",e);
						bindingResult.reject(messageSource.getMessage("ADM062", new Object[] {},LocaleContextHolder.getLocale()));
					}
			}
		} catch (Exception e) {
			// BugFix 17309: Start - Inappropriate alert is been displayed if
			// any network exceptions occur while trying to add GA account
			if (isNetworkFailure(e)) {
				logger.error("Error while authorizing GA Account Profile :: ",e);
				bindingResult.reject(messageSource.getMessage("ADM023", new Object[] {},LocaleContextHolder.getLocale()));
			} else {
				if (accountID != null) {
					Long[] obj = { accountID };
					logger.error("Error while authorizing GA Account Profile :: ",e);
					bindingResult.reject(messageSource.getMessage("ADM022", obj,LocaleContextHolder.getLocale()));
				} else {
					logger.error("Error while authorizing GA Account Profile :: ",e);
					bindingResult.reject(messageSource.getMessage("ADM022", new Object[] {},LocaleContextHolder.getLocale()));
				}
			}
			// BugFix 17309: End
		}
		logger.debug("End :" + getClass().getName() + ": authorizeGoogleAnalyticsProfile()");
		return gaAccProObj;
	}
	
	private boolean isNetworkFailure(Exception e){
		String errorMessage;
		boolean networkFailure = false;
		if(e instanceof UnknownHostException) { 
			String detailMessage = ((UnknownHostException)e).getMessage();
			logger.info("$Recoverable Error Occurred: "+ detailMessage);
			networkFailure = true;
		} else if(e instanceof SSLHandshakeException || e instanceof NoRouteToHostException || e instanceof SocketTimeoutException || e instanceof SocketException){
        	errorMessage = e.getMessage();
			logger.info("$Recoverable Error Occurred: "+ errorMessage);
			networkFailure = true;
        }
		return networkFailure;
	}
	
}

/**
 * MeterQueueServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.service.impl;

import java.util.List;

import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.dao.MeterQueueDAO;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.MeterQueueService;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.admin.validators.MeterQueueValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.MeterQueue;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Aug 1, 2016 8:51:25 PM
 * @Version : 1.7
 * @Description : "MeterQueueServiceImpl" is used for meter queue service implementation
 * 
 **/
@Component
public class MeterQueueServiceImpl implements MeterQueueService {
	
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	MeterQueueValidator meterQueueValidator;
	@Autowired
	MeterQueueDAO meterQueueDAO;
	@Autowired
	MessageSource messageSource;
	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;

	/**
	 * 
	 * Method Name 	: saveMeterQueue
	 * Description 		: The Method "saveMeterQueue" is used for 
	 * Date    			: Aug 1, 2016, 8:51:50 PM
	 * @param meterQueue
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	@Override
	public Integer saveMeterQueue(MeterQueue meterQueue, Boolean isDefaultOverride, BindingResult bindingResult) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":saveMeterQueue()");
		AuditEvent event = new AuditEvent();
		event.setActor("MeterQueueServiceImpl");
		event.setAction("Save MeterQueue"); 
		Integer meterQueueId = 0;
		try {
			event.addField("Save MeterQueue content received :: ",meterQueue.getMeterQueueName());
			auditManager.audit(event);
			meterQueueValidator.validate(meterQueue, bindingResult);
			if (!bindingResult.hasErrors()) {
					if (isMeterQueueExists(meterQueue.getMeterQueueName(),meterQueue.getMeterQueueId())) {
						logger.error("Meter queue already exists with the name");
						throw new AdminException("MQ0004");
					}
					if(meterQueue.getMeterQueueId() > 0){
						MeterQueue mq = meterQueueDAO.findMeterQueueById(meterQueue.getMeterQueueId());
						if(mq == null){
							logger.error("Meter queue not exists with the id "+meterQueue.getMeterQueueId());
							throw new AdminException("MQ0005");
						}
					}
				/*if(!isDefaultOverride){
					MeterQueue existingMeterQueueWithDefaultFlag = meterQueueDAO.isDefaultMeterQueueExistsForClient(meterQueue.getCustomerId());
					if(existingMeterQueueWithDefaultFlag != null){
						logger.error("Default meter queue already exists for the customer "+meterQueue.getMeterQueueId());
						throw new AdminException("MQ0008");
					}
				}*/
				meterQueueId = meterQueueDAO.saveMeterQueue(meterQueue, isDefaultOverride);
				logger.debug("Meter queue saved/updated succussfully");
			}
		} catch (Exception ex) {
			event.addField("Failed Save MeterQueue content received :: ",meterQueue.getMeterQueueName());
			auditManager.audit(event);
			logger.error("Exception occured while saving/updated the meter queue details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("End:" + getClass().getName() + ":saveMeterQueue()");
		return meterQueueId;

	}

	/**
	 * 
	 * Method Name : deleteMeterQueue Description : The Method
	 * "deleteMeterQueue" is used for Date : Aug 1, 2016, 8:51:50 PM
	 * 
	 * @param meterQueueId
	 * @return
	 * @throws AudienceException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteMeterQueue(Integer meterQueueId) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":deleteMeterQueue()");
		AuditEvent event = new AuditEvent();
		event.setActor("MeterQueueServiceImpl");
		event.setAction("Delete MeterQueue");
		Boolean deleteStatus = false;
		try {
			event.addField("Delete MeterQueue content received :: ",meterQueueId);
			auditManager.audit(event);
			logger.debug("meterQueueId==============="+meterQueueId);
			if (meterQueueId != null && meterQueueId > 0) {
				MeterQueue meterQueue = meterQueueDAO.findMeterQueueById(meterQueueId);
				if (meterQueue == null) {
					throw new AdminException("MQ0005");
				}
				deleteStatus = meterQueueDAO.deleteMeterQueue(meterQueueId);
			}

		} catch (Exception ex) {
			event.addField("Failed Delete MeterQueue content received :: ",meterQueueId);
			auditManager.audit(event);
			logger.error("Exception occured while deleting the meter queue details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":deleteMeterQueue()");
		return deleteStatus;
	}

	/**
	 * 
	 * Method Name : findMeterQueueById Description : The Method
	 * "findMeterQueueById" is used for Date : Aug 1, 2016, 8:51:50 PM
	 * 
	 * @param meterQueueId
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public MeterQueue findMeterQueueById(Integer meterQueueId) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":findMeterQueueById()");
		MeterQueue meterQueue = null;
		try {
			logger.debug("Audience ID ----------->" + meterQueueId);
			if (meterQueueId != null && meterQueueId > 0) {
				meterQueue = meterQueueDAO.findMeterQueueById(meterQueueId);
				if (meterQueue == null) {
					throw new AdminException("MQ0005");
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the meter queue details by ID", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":findMeterQueueById()");
		return meterQueue;
	}

	/**
	 * 
	 * Method Name : findMeterQueueByName Description : The Method
	 * "findMeterQueueByName" is used for Date : Aug 1, 2016, 8:51:50 PM
	 * 
	 * @param meterQueueName
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public MeterQueue findMeterQueueByName(String meterQueueName) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":findMeterQueueByName()");
		MeterQueue meterQueue = null;
		try {
			logger.debug("meterQueueName =============>"+meterQueueName);
			if (meterQueueName != null && !meterQueueName.isEmpty()) {
				meterQueue = meterQueueDAO.findMeterQueueByName(meterQueueName);
				if (meterQueue == null) {
					throw new AdminException("MQ0006");
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the meter queue details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":findMeterQueueByName()");
		return meterQueue;
	}

	/**
	 * 
	 * Method Name : findMeterQueuesByCriteria Description : The Method
	 * "findMeterQueuesByCriteria" is used for Date : Aug 1, 2016, 8:51:50 PM
	 * 
	 * @param listingCriteria
	 * @return
	 * @throws AdminException
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<MeterQueue> findMeterQueuesByCriteria(ListingCriteria listingCriteria,BindingResult bindingResult) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":findMeterQueuesByCriteria()");
		List<MeterQueue> meterQueueList = null;
		try {
			listingCriteriaValidator.validate(listingCriteria, bindingResult);
			if (!bindingResult.hasErrors()) {
				meterQueueList =  meterQueueDAO.findMeterQueuesByCriteria(listingCriteria);
			}
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":findMeterQueuesByCriteria()");
		return meterQueueList;

	}

	/**
	 * 
	 * Method Name 	: isMeterQueueExists
	 * Description 		: The Method "isMeterQueueExists" is used for 
	 * Date    			: Aug 1, 2016, 9:08:23 PM
	 * @param meterQueueName
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isMeterQueueExists(String meterQueueName,Integer meterQueueId) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":isMeterQueueExists()");
		Boolean isExists = false;
		try {
			logger.debug("meterQueueName=============>"+meterQueueName);
			logger.debug("meterQueueId  =============>"+meterQueueId);
			MeterQueue meterQueue = meterQueueDAO.isMeterQueueExists(meterQueueName,meterQueueId);
			if(meterQueue != null) {
				isExists = true;
			}
		} catch (Exception e) {
			logger.error(Constants.EXCEPTION,e);
			throw new AdminException("E00002", e);
		}
		logger.info("Ends:" + getClass().getName() + ":isMeterQueueExists()");
		return isExists;
	}

	/**
	 * 
	 * Method Name 	: listMeterQueues
	 * Description 		: The Method "listMeterQueues" is used for 
	 * Date    			: Aug 4, 2016, 8:21:41 PM
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<MeterQueue> listMeterQueues(String fetchType) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":listMeterQueues()");
		List<MeterQueue> meterQueueList = null;
		try {
				meterQueueList =  meterQueueDAO.listMeterQueues(fetchType);
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":listMeterQueues()");
		return meterQueueList;
	}

	/**
	 * 
	 * Method Name 	: isDefaultMeterQueueExistsForClient
	 * Description 		: The Method "isDefaultMeterQueueExistsForClient" is used for 
	 * Date    			: Aug 8, 2016, 3:23:29 PM
	 * @param customerID
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public MeterQueue isDefaultMeterQueueExistsForClient(Integer customerID) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":isDefaultMeterQueueExistsForClient()");
		try{
			return meterQueueDAO.isDefaultMeterQueueExistsForClient(customerID);
		}catch(Exception e){
			logger.error(Constants.EXCEPTION,e);
			throw new AdminException("E00002",e);
		}
	}
}

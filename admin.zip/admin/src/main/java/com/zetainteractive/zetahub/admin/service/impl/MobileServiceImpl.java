package com.zetainteractive.zetahub.admin.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.service.MobileService;
import com.zetainteractive.zetahub.admin.validators.DepartmentValidationService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.ShortCode;
import com.zetainteractive.zetahub.commons.domain.TestGroup;

@Component
public class MobileServiceImpl implements MobileService {

	@Autowired
	DepartmentService departmentService;

	@Autowired
	DepartmentValidationService departmentValidationService;

	@Autowired
	MessageSource messageSource;

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Override
	public MobileBO getMobileBOForDepartment(Long departmentID, BindingResult bindingResult) throws AdminException {
		DepartmentSettings departmentSettings=departmentService.getDepartmentSpecificProperty(departmentID, Constants.DEPARTMENT_MOBILE_KEY,
				bindingResult);
		if(departmentSettings!=null)
			return (MobileBO) departmentSettings.getObjectValue();
		return null;
	}

	@Override
	public List<ShortCode> listShortCodes(Long departmentID, BindingResult bindingResult) throws AdminException {
		MobileBO mobileBO = getMobileBOForDepartment(departmentID, bindingResult);
		List<ShortCode> shortCodes = new ArrayList<>();
		if (mobileBO != null) {
			for (ShortCode shortcode : mobileBO.getShortCodes())
				shortCodes.add(shortcode);
		}
		return shortCodes;
	}

	@Override
	public List<TestGroup> createTestGroup(Long departmentID, List<TestGroup> newGroupData,
			BindingResult bindingResult)throws Exception {
		logger.debug(" Start : "+this.getClass().getName()+" createTestGroup()");
		// Validate the data
		Boolean valid = validateTestGroup(departmentID, newGroupData, bindingResult, true);
		List<TestGroup> existingTestGroups = new ArrayList<>();
		if (valid) {
			// Get list of test groups
			MobileBO mobileBO = getMobileBOForDepartment(departmentID, bindingResult);
			DepartmentSettings ds = new DepartmentSettings();
			try {
				if (mobileBO != null) {
					if (mobileBO.getTestGroups() != null)
						for (TestGroup testGroup : mobileBO.getTestGroups())
							existingTestGroups.add(testGroup);

					// Check for duplicate mobile number
					boolean duplicateExists = false;
					for (TestGroup existingTestGroup : existingTestGroups) {
						for (TestGroup newTestGroup : newGroupData) {
							logger.debug("Check for duplicate mobile number  : "+newTestGroup.getMobileNumber());
							if (existingTestGroup.equals(newTestGroup)) {
								bindingResult.reject(messageSource.getMessage("ADM049",
										new Object[] { newTestGroup.getMobileNumber().toString() },
										LocaleContextHolder.getLocale()));
								duplicateExists = true;
								break;
							}
							else if(existingTestGroup.getCampaignId()==0&&
									existingTestGroup.getMobileNumber().equals(newTestGroup.getMobileNumber())){
								bindingResult.reject(messageSource.getMessage("ADM049",
										new Object[] { newTestGroup.getMobileNumber().toString() },
										LocaleContextHolder.getLocale()));
								duplicateExists = true;
								break;
							}
						}
					}
					if (!duplicateExists) {
						// If no duplicate mobile number then update common
						// properties(created by,created on,updated by,
						// updated on) and add testGroups to the existing group
						for (TestGroup newTestGroup : newGroupData) {
							newTestGroup.setCreateDate(new Date());
							newTestGroup.setUpdateDate(new Date());
							try {
								newTestGroup.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
								newTestGroup.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
							} catch (Exception e) {
								throw new AdminException("ACF000");
							}

						}

						if (existingTestGroups.isEmpty())
							existingTestGroups = new ArrayList<>(newGroupData);
						else
							existingTestGroups.addAll(newGroupData);

						// set mobileBO groupdata
						mobileBO.setTestGroups(existingTestGroups);

						// Save department
						DepartmentBO departmentBO = departmentService.getDepartment(departmentID);
						Long departmentSettingId = 0L;
						List<DepartmentSettings> departmentSettings = departmentBO.getDepartmentSettings();
						for (DepartmentSettings departmentSetting : departmentSettings) {
							if (departmentSetting.getObjectKey().equalsIgnoreCase(Constants.DEPARTMENT_MOBILE_KEY)) {
								departmentSettingId = departmentSetting.getDepartmentSettingId();
								break;
							}

						}
						ds.setDepartmentSettingId(departmentSettingId);
						ds.setDepartmentID(departmentID);
						ds.setObjectKey(Constants.DEPARTMENT_MOBILE_KEY);
						ds.setObjectValue(mobileBO);
						departmentService.updateDepartmentSpecificProperty(ds, bindingResult);

					}
				}
			} catch (AdminException e) {
				bindingResult.reject(messageSource.getMessage(e.getErrorCode(), new Object[] { departmentID },
						LocaleContextHolder.getLocale()));
			}
		}
		return existingTestGroups;
	}

	@Override
	public List<TestGroup> listTestGroups(Long departmentID, BindingResult bindingResult) throws AdminException {
		MobileBO mobileBO = getMobileBOForDepartment(departmentID, bindingResult);
		List<TestGroup> testGroups = new ArrayList<>();
		if (mobileBO != null && mobileBO.getTestGroups() != null)
			for (TestGroup testGroup : mobileBO.getTestGroups())
				testGroups.add(testGroup);
		return testGroups;
	}

	private Boolean validateTestGroup(Long departmentID, List<TestGroup> testGroups, BindingResult bindingResult,boolean isCreate) {
		Boolean valid = true;
		for (TestGroup testGroup : testGroups) {
			if (testGroup == null) {
				bindingResult.reject(messageSource.getMessage("Please enter group data ", new Object[] {},
						LocaleContextHolder.getLocale()));
				valid = false;
			} else if (testGroup.getFirstName().trim().length() == 0) {
				bindingResult
						.reject(messageSource.getMessage("ADM045", new Object[] {}, LocaleContextHolder.getLocale()));
				valid = false;
			} else if (testGroup.getLastName().trim().length() == 0) {
				bindingResult
						.reject(messageSource.getMessage("ADM046", new Object[] {}, LocaleContextHolder.getLocale()));
				valid = false;
			} else if (testGroup.getMobileNumber() == null) {
				bindingResult
						.reject(messageSource.getMessage("ADM047", new Object[] {}, LocaleContextHolder.getLocale()));
				valid = false;
			} else if (String.valueOf(testGroup.getMobileNumber()).length() < 10) {
				bindingResult
						.reject(messageSource.getMessage("ADM048", new Object[] {}, LocaleContextHolder.getLocale()));
				valid = false;
			}
		}
		if (valid && isCreate) {
			// Check if duplicate mobile number is entered
			Set<TestGroup> set = new HashSet<>();
			List<Long> defaultMobNums = new ArrayList<>();
			for (TestGroup tg : testGroups) {
				if (!set.add(tg)) {
					bindingResult.reject(messageSource.getMessage("ADM049", new Object[] { tg.getMobileNumber().toString() },
							LocaleContextHolder.getLocale()));
					valid = false;
					return valid;
				}
				//Group default mobile numbers which have capaignId 0
				if(tg.getCampaignId()==0)
					defaultMobNums.add(tg.getMobileNumber());
			}
			//Check if any mobile number is equal to default mobile number
			for(TestGroup tg : testGroups)
				for(Long defMobNum: defaultMobNums){
					if(tg.getCampaignId()!=0 && tg.getMobileNumber().longValue()==defMobNum.longValue()){
						bindingResult.reject(messageSource.getMessage("ADM049", new Object[] { tg.getMobileNumber().toString() },
								LocaleContextHolder.getLocale()));
						valid = false;
						return valid;
					}
				}
		}
		return valid;
	}

	@Override
	public List<TestGroup> updateTestGroup(Long departmentID, List<TestGroup> newTestGroups, BindingResult bindingResult)throws Exception {
		// Validate the data
		Boolean valid = validateTestGroup(departmentID, newTestGroups, bindingResult,false);
		List<TestGroup> existingGroupData = new ArrayList<>();
		if (valid) {
			// Get list of test groups
			MobileBO mobileBO = getMobileBOForDepartment(departmentID, bindingResult);
			DepartmentSettings ds = new DepartmentSettings();
			try {
				if (mobileBO != null) {
					if (newTestGroups != null){
						mobileBO.setTestGroups(newTestGroups);
					}
					// Save department
					DepartmentBO departmentBO = departmentService.getDepartment(departmentID);
					Long departmentSettingId = 0L;
					List<DepartmentSettings> departmentSettings = departmentBO.getDepartmentSettings();
					for (DepartmentSettings departmentSetting : departmentSettings) {
						if (departmentSetting.getObjectKey().equalsIgnoreCase(Constants.DEPARTMENT_MOBILE_KEY)) {
							departmentSettingId = departmentSetting.getDepartmentSettingId();
							break;
						}

					}
					ds.setDepartmentSettingId(departmentSettingId);
					ds.setDepartmentID(departmentID);
					ds.setObjectKey(Constants.DEPARTMENT_MOBILE_KEY);
					ds.setObjectValue(mobileBO);
					departmentService.updateDepartmentSpecificProperty(ds, bindingResult);

				}
			} catch (AdminException e) {
				bindingResult.reject(messageSource.getMessage(e.getErrorCode(), new Object[] { departmentID },
						LocaleContextHolder.getLocale()));
			}
		}
		return existingGroupData;
	}
}

/**
 * UnsubsServiceImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.service.impl;

import java.util.List;

import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.audience.constants.Constants;
import com.zetainteractive.zetahub.admin.dao.UnsubDAO;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.UnsubsService;
import com.zetainteractive.zetahub.admin.validators.UnsubsValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.Unsubs;


/**
 * 
 * @Author	   : Dilleswara.Doppa
 * @Created on : Aug 12, 2016 7:03:22 PM
 * @Version	   : 1.7
 * @Description: "UnsubsServiceImpl" is used for 
 * 
 **/
@Component
public class UnsubsServiceImpl implements UnsubsService{
	
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	UnsubsValidator unsubsValidator;
	@Autowired
	UnsubDAO unsubDAO;
	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name 	: saveUnsubs
	 * Description 		: The Method "saveUnsubs" is used for 
	 * Date    			: Aug 12, 2016, 4:09:28 PM
	 * @param unsub
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public Long saveUnsubs(Unsubs unsub, String unsubType, BindingResult bindingResult) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":saveUnsubs()");
		AuditEvent event = new AuditEvent();
		event.setActor("UnsubsServiceImpl");
		event.setAction("Save Unsubs"); 
		Long unsubId = 0L;
		try {
			event.addField("Save Unsubs content received :: ",unsub);
			auditManager.audit(event);
			unsubsValidator.validate(unsub, bindingResult);
			if (!bindingResult.hasErrors()) {
					if (isUnsubsExists(unsub.getUnsubKeyword(),unsub.getUnsubKeywordId(),unsubType,unsub.getCategory(),unsub.getType())) {
						logger.error("unsub  already exists with the name");
						throw new AdminException("US0003");
					}
					unsubId = unsubDAO.saveUnsubs(unsub, unsubType);
				logger.debug("unsib  saved/updated succussfully");
			}
		} catch (AdminException ex) {
			throw ex;
		} catch (Exception ex) {
			event.addField("Failed Save Unsubs content received :: ",unsub.getStatus());
			auditManager.audit(event);
			logger.error("Exception occured while saving/updated the unsub  details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("End:" + getClass().getName() + ":saveUnsubs()");
		return unsubId;
	}

	/**
	 * 
	 * Method Name 	: deleteUnsubs
	 * Description 		: The Method "deleteUnsubs" is used for 
	 * Date    			: Aug 12, 2016, 4:09:28 PM
	 * @param unsubId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteUnsubs(Long unsubKeywordId,String unsubType) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":deleteUnsubs()");
		AuditEvent event = new AuditEvent();
		event.setActor("UnsubsServiceImpl");
		event.setAction("Delete Unsubs"); 
		Boolean deleteStatus = false;
		try {
			event.addField("Delete Unsubs content received :: ",unsubKeywordId);
			auditManager.audit(event);
			logger.debug("unsubId==============="+unsubKeywordId);
			if (unsubKeywordId != null && unsubKeywordId > 0) {
				Unsubs unsubs = unsubDAO.findUnsubById(unsubKeywordId,unsubType);
				if (unsubs == null) {
					throw new AdminException("US0005");
				}
				deleteStatus = unsubDAO.deleteUnsubs(unsubKeywordId,unsubType);
			}

		} catch (Exception ex) {
			event.addField("Failed Delete Unsubs content received :: ",unsubKeywordId);
			auditManager.audit(event);
			logger.error("Exception occured while deleting the unsub details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":deleteMeterQueue()");
		return deleteStatus;
		
		
	}

	/**
	 * 
	 * Method Name 	: findUnsubById
	 * Description 		: The Method "findUnsubById" is used for 
	 * Date    			: Aug 12, 2016, 4:09:28 PM
	 * @param unsubId
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Unsubs findUnsubById(Long unsubId, String unsubType) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":findUnsubById()");
		Unsubs unsubs  = null;
		try {
			logger.debug("unsubId ----------->" + unsubId);
			if (unsubId != null && unsubId > 0) {
				unsubs = unsubDAO.findUnsubById(unsubId, unsubType);
				if (unsubs == null) {
					throw new AdminException("US0005");
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the meter queue details by ID", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":findMeterQueueById()");
		return unsubs;
	}

	/**
	 * 
	 * Method Name 	: findUnsubByName
	 * Description 		: The Method "findUnsubByName" is used for 
	 * Date    			: Aug 12, 2016, 4:09:28 PM
	 * @param keywordName
	 * @param ubsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Unsubs findUnsubByName(String unsubKeyword, String ubsubType) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":findUnsubByName()");
		Unsubs unsubs  = null;
		try {
			logger.debug("findUnsubByName =============>"+unsubKeyword);
			if (unsubKeyword != null && !unsubKeyword.isEmpty()) {
				unsubs = unsubDAO.findUnsubByName(unsubKeyword,ubsubType);
				if (unsubs == null) {
					throw new AdminException("US0006");
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while fetching the meter queue details", ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":findMeterQueueByName()");
		return unsubs;
		
		
	}
	
	public Boolean isUnsubsExists(String keywordName,Long unsubId, String unsubType) throws AdminException{
		return isUnsubsExists(keywordName, unsubId, unsubType,null,null);
	}
	/**
	 * 
	 * Method Name 	: isUnsubsExists
	 * Description 	: The Method "isUnsubsExists" is used for 
	 * Date    		: Aug 12, 2016, 7:02:24 PM
	 * @param keywordName
	 * @param unsubId
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: Boolean
	 * @throws 		: 
	 */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean isUnsubsExists(String keywordName,Long unsubId, String unsubType,String category,String type) throws AdminException{
		logger.info("Begin:" + getClass().getName() + ":isMeterQueueExists()");
		Boolean isExists = false;
		try {
			logger.debug("keywordName=============>"+keywordName);
			logger.debug("unsubId  =============>"+unsubId);
			Unsubs unsubs  = unsubDAO.isUnsubsExists(keywordName,unsubId,unsubType,category,type);
			if(unsubs != null) {
				isExists = true;
			}
		} catch (Exception e) {
			logger.error(Constants.EXCEPTION,e);
			throw new AdminException("E00002", e);
		}
		logger.info("Ends:" + getClass().getName() + ":isMeterQueueExists()");
		return isExists;
	}
	
	/**
	 * 
	 * Method Name 	: listUnsubs
	 * Description 		: The Method "listUnsubs" is used for 
	 * Date    			: Aug 12, 2016, 7:04:20 PM
	 * @param fetchType
	 * @param unsubType
	 * @return
	 * @throws AdminException
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<Unsubs> listUnsubs(String fetchType, String unsubType) throws AdminException {
		logger.info("Begin:" + getClass().getName() + ":listUnsubs()");
		List<Unsubs> unsubsList = null;
		try {
			unsubsList =  unsubDAO.listUnsubs(fetchType,unsubType);
		} catch (Exception ex) {
			logger.error(Constants.EXCEPTION,ex);
			throw new AdminException("E00002", ex);
		}
		logger.info("Ends:" + getClass().getName() + ":listMeterQueues()");
		return unsubsList;
	}

}

package com.zetainteractive.zetahub.admin.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.WebPageService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.Constants.WebPageConstants;
import com.zetainteractive.zetahub.commons.domain.WebPageBO;
import com.zetainteractive.zetahub.commons.domain.WebPageContentBO;
import com.zetainteractive.zetahub.commons.domain.WebPageEvent;
import com.zetainteractive.zetahub.commons.domain.WebPageMapping;
import com.zetainteractive.zetahub.commons.domain.WebPageRevisionBO;

/**
 * @author Lakshmi.Medarametla
 *
 */
@Component
public class WebPageServiceImpl implements WebPageService{
	
	private RestRequestHandler restHandler = new RestRequestHandler();
	private ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Override
	public Boolean saveDefaultWebPages(Long departmentID) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :saveDefaultWebPages(Long departmentID)");
		
		Boolean retValue=false;
		String folderPath;
		Map<String, String> contentsMap;
		try {
			folderPath = ZetaUtil.getHelper().getConfig().getConfigValueString("templates-folder", Constants.TEMPLATES_FOLDER);
			contentsMap=getTemplateContents(folderPath,StandardCharsets.UTF_8.toString());
			
			//Insert default Optout template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_OPTOUT,departmentID)){
				WebPageBO webPageOptout = getTemplateOptout(contentsMap);
				webPageOptout.setDepartmentID(departmentID);
				createWebPageTemplate(webPageOptout);
			}
			
			//Insert default Success template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_SUCCESS,departmentID)){
				WebPageBO webPageSuccess = getTemplateSuccess(contentsMap);
				webPageSuccess.setDepartmentID(departmentID);
				createWebPageTemplate(webPageSuccess);
			}
			
			//Insert default Error template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_ERROR,departmentID)){
				WebPageBO webPageError = getTemplateError(contentsMap);
				webPageError.setDepartmentID(departmentID);
				createWebPageTemplate(webPageError);
			}
			
			
			//Insert default Cancel template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_CANCEL,departmentID)){
				WebPageBO webPageCancel = getTemplateCancel(contentsMap);
				webPageCancel.setDepartmentID(departmentID);
				createWebPageTemplate(webPageCancel);
			}
			
			//Insert default Viral template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_VIRAL,departmentID)){
				WebPageBO webPageViral = getTemplateViral(contentsMap);
				webPageViral.setDepartmentID(departmentID);
				createWebPageTemplate(webPageViral);
			}
			
			//Insert default Registration template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_REG,departmentID)){
				WebPageBO webPageRegistration = getTemplateRegistration(contentsMap);
				//webPageRegistration.setDepartmentID(departmentID);
				//createWebPageTemplate(webPageRegistration);
			}
			
			//Insert default Preference template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_PREFERENCE,departmentID)){
				WebPageBO webPagePreference = getTemplatePreference(contentsMap);
				//webPagePreference.setDepartmentID(departmentID);
				//createWebPageTemplate(webPagePreference);
			}
			
			//Insert default Login Error template
			if(!checkIfWebPageTemplateExists(WebPageConstants.WEBPAGENAME_LOGIN_ERROR,departmentID)){
				WebPageBO webPageLoginError = getTemplateLoginError(contentsMap);
				webPageLoginError.setDepartmentID(departmentID);
				createWebPageTemplate(webPageLoginError);
			}
			
			retValue=true;
		} catch(AdminException e) {
			logger.error(e.getMessage(), e);
			throw e;
		} catch(Exception e){
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0001",e);
		}
		logger.debug("End :" + getClass().getName() + " :saveDefaultWebPages()");
		return retValue;
	}
	
	private Map<String, String> getTemplateContents(String folderPath, String charset) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateContents(String folderPath, String charset)");
		String fileSeparator = File.separator;
		String changedFolderPath = folderPath;
		Map<String, String> contentsMap = new HashMap<>();
		if(changedFolderPath == null)
				throw new AdminException("WP0004");
		else if(!changedFolderPath.endsWith(fileSeparator))
				changedFolderPath += fileSeparator;
		contentsMap.put(WebPageConstants.OPTOUT_CONTENT, getContentFromFile(changedFolderPath + WebPageConstants.OPTOUT_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.VIRAL_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.VIRAL_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.REG_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.REG_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.LOGIN_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.LOGIN_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.SUCCESS_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.SUCCESS_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.ERROR_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.ERROR_CONTENT + ".htm", charset));
		contentsMap.put(WebPageConstants.CANCEL_CONTENT, getContentFromFile(changedFolderPath + WebPageConstants.CANCEL_CONTENT +".htm", charset));
		contentsMap.put(WebPageConstants.LOGIN_ERROR_CONTENT, getContentFromFile(changedFolderPath +  WebPageConstants.LOGIN_ERROR_CONTENT + ".htm", charset));
		logger.debug("End :" + getClass().getName() + " :getTemplateContents()");
		return contentsMap;
	}
	
	/**
	 * Returns the content of the specified file
	 * @param fileName
	 * @return
	 * @throws EbizException 
	 * @throws IOException
	 */
	private String getContentFromFile(String fileName, String charset) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getContentFromFile(String fileName, String charset)");
		StringBuilder content = new StringBuilder("");
		String line = null;
		Object[] obj = null;
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			line = br.readLine();
			while(line != null) {
				content.append(line + "\n");
				line = br.readLine();
			}
			//Replace the charset in the default template
			String subString="<wpm_charset>";
			if(content.indexOf(subString) > -1)
				content.replace(content.indexOf(subString),content.indexOf(subString)+subString.length(),charset);
		} catch (FileNotFoundException fe) {
			obj = new Object[1];
			obj[0] = fileName;
			logger.error(fe.getMessage(), fe);
			throw new AdminException("WP0002", obj, null, fe);
		} catch (IOException ie) {
			obj = new Object[1];
			obj[0] = fileName;
			logger.error(ie.getMessage(), ie);
			throw new AdminException("WP0003", obj, null, ie);
		}
		logger.debug("End :" + getClass().getName() + " :getContentFromFile()");
		return content.toString();
	}
	
	private WebPageBO createWebPageTemplate(WebPageBO webPageBO) throws AdminException{
		logger.debug("Start :" + getClass().getName() + " :createWebPageTemplate(WebPageBO webPageBO)");
		ResponseEntity<WebPageBO> response;
		try{
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(webPageBO);
			response=restHandler .exchange(ZetaUtil.getHelper().getEndpoint("webpage")+"/createWebTemplates",HttpMethod.POST, entity, WebPageBO.class);
    	}catch(Exception e){
    		logger.error(e.getMessage(), e);
    		throw new AdminException("WP0006",e);
    	}
		logger.debug("End :" + getClass().getName() + " :createWebPageTemplate()");
		return response.getBody();
	}
	
	private void fillWebPageDetails(WebPageBO webPage) throws Exception{
		logger.debug("Start :" + getClass().getName() + " :fillWebPageDetails(WebPageBO webPage)");
		webPage.setDisplayName(webPage.getName());
		webPage.setIsDefault(Boolean.TRUE);
		webPage.setIsTemplate(Boolean.TRUE);
		webPage.setNumberOfTimesUsed(-1L);
		webPage.setAudienceID(0L);
		webPage.setCategoryID(0L);
		webPage.setFolderID(0L);
		webPage.setPreviousFolderID(0L);
		webPage.setLatestRevision(1L);
		webPage.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		webPage.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		logger.debug("End :" + getClass().getName() + " :fillWebPageDetails()");
	}
	
	private void fillWebPageRevisionDetails(WebPageRevisionBO revision) throws Exception{
		logger.debug("Start :" + getClass().getName() + " :fillWebPageRevisionDetails(WebPageRevisionBO revision)");
		revision.setRevision(1);
		revision.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		revision.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		logger.debug("End :" + getClass().getName() + " :fillWebPageRevisionDetails()");
	}
	
	/**
	 * Returns Optout WebPage
	 * @param charset
	 * @return
	 * @throws EbizException
	 */
	private WebPageBO getTemplateOptout(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateOptout(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_OPTOUT);
			webPage.setType(WebPageConstants.TYPE_OPTOUT);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentOptout=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.OPTOUT_CONTENT);
			webPageContentOptout.setContent(optoutContent);
			webPageContentOptout.setContentCategory(WebPageConstants.CATEGORY_OPTOUT);
			webPageContentOptout.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentOptout.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentOptout.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			List<WebPageEvent> webPageEvents=new ArrayList<>();
			WebPageEvent webPageEvent = getWebPageEvent("optout_option", "optout", WebPageConstants.EVENT_TYPE_SUCCESS, Constants.YES, WebPageConstants.TARGET_OPTION_SUCCESS, null);
			webPageEvents.add(webPageEvent);
			WebPageEvent webPageEvent1 = getWebPageEvent("donotoptout_option", "donot_optout", WebPageConstants.EVENT_TYPE_CONTINUE, Constants.YES, WebPageConstants.TARGET_OPTION_CANCEL, null);
			webPageEvents.add(webPageEvent1);
			WebPageEvent webPageEvent2 = getWebPageEvent(null, "Error", WebPageConstants.EVENT_TYPE_ERROR, Constants.YES, WebPageConstants.TARGET_OPTION_ERROR, null);
			webPageEvents.add(webPageEvent2);
			webPageContentOptout.setWebpageEventsList(webPageEvents);
			
			List<WebPageMapping> webPageMappings=new ArrayList<>();
			WebPageMapping webPageMapping = getWebPageMapping("email","email");
			webPageMappings.add(webPageMapping);
			webPageContentOptout.setWebpageMappingsList(webPageMappings);
			
			contents.add(webPageContentOptout);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateOptout()");
		return webPage;
	}
	
	private WebPageBO getTemplateViral(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateViral(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_VIRAL);
			webPage.setType(WebPageConstants.TYPE_VIRAL);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentViral=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.VIRAL_CONTENT);
			webPageContentViral.setContent(optoutContent);
			webPageContentViral.setContentCategory(WebPageConstants.CATEGORY_VIRAL);
			webPageContentViral.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentViral.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentViral.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			List<WebPageEvent> webPageEvents=new ArrayList<>();
			WebPageEvent webPageEvent = getWebPageEvent(null, "submitBtn", WebPageConstants.EVENT_TYPE_SUCCESS, Constants.NO, WebPageConstants.TARGET_OPTION_SUCCESS, null);
			webPageEvents.add(webPageEvent);
			WebPageEvent webPageEvent2 = getWebPageEvent(null, "Error", WebPageConstants.EVENT_TYPE_ERROR, Constants.NO, WebPageConstants.TARGET_OPTION_ERROR, null);
			webPageEvents.add(webPageEvent2);
			webPageContentViral.setWebpageEventsList(webPageEvents);
			
			List<WebPageMapping> webPageMappings=new ArrayList<>();
			WebPageMapping webPageMapping = getWebPageMapping("refer_email[]", "email");
			WebPageMapping webPageMapping1 = getWebPageMapping("refer_fname[]", "fname");
			WebPageMapping webPageMapping2 = getWebPageMapping("refer_lname[]", "lname");
			WebPageMapping webPageMapping3 = getWebPageMapping("refer_comments", "comments");
			webPageMappings.add(webPageMapping);
			webPageMappings.add(webPageMapping1);
			webPageMappings.add(webPageMapping2);
			webPageMappings.add(webPageMapping3);
			webPageContentViral.setWebpageMappingsList(webPageMappings);
			
			contents.add(webPageContentViral);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateViral()");
		return webPage;
	}
	
	private WebPageBO getTemplateRegistration(Map<String,String> contentsMap) throws AdminException {
		//TODO
		return null;
	}
	
	private WebPageBO getTemplatePreference(Map<String,String> contentsMap) throws AdminException {
		//TODO
		return null;
	}
	
	private WebPageBO getTemplateSuccess(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateSuccess(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_SUCCESS);
			webPage.setType(WebPageConstants.TYPE_SUCCESS);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentSuccess=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.SUCCESS_CONTENT);
			webPageContentSuccess.setContent(optoutContent);
			webPageContentSuccess.setContentCategory(WebPageConstants.CATEGORY_SUCCESS);
			webPageContentSuccess.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentSuccess.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentSuccess.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			contents.add(webPageContentSuccess);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateSuccess()");
		return webPage;
	}
	
	private WebPageBO getTemplateLoginError(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateLoginError(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_LOGIN_ERROR);
			webPage.setType(WebPageConstants.TYPE_LOGIN_ERROR);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentLoginError=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.LOGIN_ERROR_CONTENT);
			webPageContentLoginError.setContent(optoutContent);
			webPageContentLoginError.setContentCategory(WebPageConstants.CATEGORY_LOGIN_ERROR);
			webPageContentLoginError.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentLoginError.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentLoginError.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			contents.add(webPageContentLoginError);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateLoginError()");
		return webPage;
	}
	
	private WebPageBO getTemplateCancel(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateCancel(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_CANCEL);
			webPage.setType(WebPageConstants.TYPE_CANCEL);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentCancel=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.CANCEL_CONTENT);
			webPageContentCancel.setContent(optoutContent);
			webPageContentCancel.setContentCategory(WebPageConstants.CATEGORY_CANCEL);
			webPageContentCancel.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentCancel.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentCancel.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			contents.add(webPageContentCancel);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateCancel()");
		return webPage;
	}
	
	private WebPageBO getTemplateError(Map<String,String> contentsMap) throws AdminException {
		logger.debug("Start :" + getClass().getName() + " :getTemplateError(Map<String,String> contentsMap)");
		WebPageBO webPage = null;
		try {
			webPage = new WebPageBO();
			webPage.setName(WebPageConstants.WEBPAGENAME_ERROR);
			webPage.setType(WebPageConstants.TYPE_ERROR);
			fillWebPageDetails(webPage);
			
			List<WebPageRevisionBO> revisions=new ArrayList<>();
			WebPageRevisionBO revision=new WebPageRevisionBO();
			fillWebPageRevisionDetails(revision);
			
			List<WebPageContentBO> contents=new ArrayList<>();
			WebPageContentBO webPageContentError=new WebPageContentBO();
			String optoutContent = contentsMap.get(WebPageConstants.ERROR_CONTENT);
			webPageContentError.setContent(optoutContent);
			webPageContentError.setContentCategory(WebPageConstants.CATEGORY_ERROR);
			webPageContentError.setFileType(WebPageConstants.FILETYPE_HTML);
			webPageContentError.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
			webPageContentError.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
			
			contents.add(webPageContentError);
			revision.setContents(contents);
			revisions.add(revision);
			webPage.setRevisions(revisions);
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new AdminException("WP0005", e);
		}
		logger.debug("End :" + getClass().getName() + " :getTemplateError()");
		return webPage;
	}
	
	/**
	 * Returns WebPageMapping object
	 * @param mappingName
	 * @param name
	 * @return
	 * @throws Exception 
	 */
	private WebPageMapping getWebPageMapping(String mappingName, String name) throws Exception {
		logger.debug("Start :" + getClass().getName() + " :getWebPageMapping(String mappingName, String name)");
		WebPageMapping webPageMapping = new WebPageMapping();
		webPageMapping.setMappingname(mappingName);
		webPageMapping.setName(name);
		webPageMapping.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		webPageMapping.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		logger.debug("End :" + getClass().getName() + " :getWebPageMapping()");
		return webPageMapping;
	}
	
	/**
	 * Returns WebPageEvent object
	 * @param groupName
	 * @param eventName
	 * @param eventType
	 * @param isMultipleEvent
	 * @param targetOption
	 * @param targetUrl
	 * @return
	 * @throws Exception 
	 */
	private WebPageEvent getWebPageEvent(String groupName, String eventName, char eventType, char isMultipleEvent, char targetOption, String targetUrl) throws Exception {
		logger.debug("Start :" + getClass().getName() + " :getWebPageEvent(String groupName, String eventName, char eventType, char isMultipleEvent, char targetOption, String targetUrl)");
		WebPageEvent webPageEvent = new WebPageEvent();
		webPageEvent.setGroupname(groupName);
		webPageEvent.setEventname(eventName);
		webPageEvent.setEventtype(eventType);
		webPageEvent.setIsmultipleevent(isMultipleEvent);
		webPageEvent.setTargetoption(targetOption);
		webPageEvent.setTargeturl(targetUrl);
		webPageEvent.setCreatedBy(ZetaUtil.getHelper().getUser().getUserName());
		webPageEvent.setUpdatedBy(ZetaUtil.getHelper().getUser().getUserName());
		logger.debug("Start :" + getClass().getName() + " :getWebPageEvent()");
		return webPageEvent;
	}
	
	/**
	 * @param webPageBO
	 * @return
	 * @throws AdminException
	 */
	private Boolean checkIfWebPageTemplateExists(String webPageName,Long departmentId) throws AdminException{
		logger.debug("Start :" + getClass().getName() + " :checkIfWebPageTemplateExists(String webPageName,Long departmentId)");
		ResponseEntity<Boolean> response;
		Map<String,Object> jsonMap=new HashMap<>();
		try{
			jsonMap.put("webPageName", webPageName);
			jsonMap.put("deptID", departmentId);
			jsonMap.put("webPageID", 0L);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(jsonMap);
			response=restHandler .exchange(ZetaUtil.getHelper().getEndpoint("webpage")+"/webPageNameExists",HttpMethod.POST, entity, Boolean.class);
    	}catch(Exception e){
    		logger.error(e.getMessage(), e);
    		throw new AdminException("WP0007",e);
    	}
		logger.debug("End :" + getClass().getName() + " :checkIfWebPageTemplateExists()");
		return response.getBody();
	}
}

package com.zetainteractive.zetahub.admin.userdepartment.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.foundation.domain.ResponseObject;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.userdepartment.service.UserDepartmentService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * Rest Controller for user_department under Admin module
 * @author Ankush.Verman
 *
 */

@RestController
public class UserDepartmentController {

	/** The logger. */
	ZetaLogger logger= new ZetaLogger(getClass());
	
	@Autowired
	UserDepartmentService  userService;
	
	@Autowired
	MessageSource messageSource;
	 
	
	AuditManager auditManager = (AuditManager)AuditManager.getInstance();
	
	@HystrixCommand
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public ResponseEntity<?>  saveUserDept(@RequestBody UserBO user, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Begin : " + getClass().getName() + " :saveUserDept()");
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("saveUserDept()");
		
		try {
			Long userid = userService.saveUserDept(user);
			event.addField("username", user.getUserName());
			event.addField("userid", user.getUserID());
			event.addField("status", "UserDepts inserted");
			auditManager.audit(event);
			logger.debug("End : " + getClass().getName() + " :saveUserDept()");
			return new ResponseEntity<Long>(userid, HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("username", user.getUserName());
			event.addField("status", "User save failed");
			auditManager.audit(event);
			logger.error("Exception occurred while saving user",ex);
			resp.addError("saveUserDept()", "exception occurred+"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public ResponseEntity<?>  updateUserDept(@RequestBody UserBO user, BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID", 0);}},"{", "}"));} catch (Exception e) {}
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("Begin :" + getClass().getName() + " :updateUserDept()");
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("updateUserDept()");
		try {
		     boolean isUpdate = userService.updateUserDept(user);
		     event.addField("username", user.getUserName());
		     event.addField("userid", user.getUserID());
		     event.addField("status", "User updated successfully");
  			 auditManager.audit(event);
		     logger.debug("End : " + getClass().getName() + " :updateUserDept()");
			 return new ResponseEntity<String>(String.valueOf(isUpdate), HttpStatus.ACCEPTED);
		}catch(Exception ex) {
			event.addField("username", user.getUserName());
			event.addField("status", "User update failed");
			auditManager.audit(event);
			logger.error("Exception occurred while updating user",ex);
			resp.addError("updateUserDept()", "exception occurred+"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value="/getDeptIdByUserId/{userid}", method=RequestMethod.GET)
	public ResponseEntity<?>  getDeptIdByUserId(@PathVariable("userid")Long userid,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :getDeptIdByUserById()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("getDeptIdByUserId");
		try {
			long deptId = userService.getDeptIdByUserId(userid);
			event.addField("userid", userid);
			event.addField("status", "Dept fetch success");
			auditManager.audit(event);
			logger.debug("End : " + getClass().getName() + " :getDeptIdByUserById()");
			return new ResponseEntity<Long>(deptId,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept fetch failed");
			auditManager.audit(event);
			logger.error("Exception occurred while fetching departmentid",ex);
			resp.addError("getDeptIdByUserId()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value="/deleteDeptByUserId/{userid}", method=RequestMethod.GET)
	public ResponseEntity<?>  deleteDeptByUserId(@PathVariable("userid")Long userid,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :deleteDeptByUserId()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("deleteDeptByUserId");
		try {
			boolean status = userService.deleteUserDeptByUserId(userid);
			event.addField("userid", userid);
			event.addField("status", "Dept deleted successfully");
			auditManager.audit(event);
			logger.debug("End : " + getClass().getName() + " :deleteDeptByUserId()");
			return new ResponseEntity<Boolean>(status,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept deletion  failed");
			auditManager.audit(event);
			logger.error("Exception occurred while deleting deptid", ex);
			resp.addError("getDeptIdByUserId()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value="/getDeptIdListByUserId/{userid}", method=RequestMethod.GET)
	public ResponseEntity<?>  getDeptIdListByUserId(@PathVariable("userid")Long userid,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :getDeptIdListByUserId()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("deleteDeptByUserId");
		try {
			 List<Map<String, Object>> deptIdListByUserId = userService.getDeptIdListByUserId(userid);
			 event.addField("userid", userid);
			 event.addField("status", "Dept List fetched successfully");
			 auditManager.audit(event);
			 logger.debug("End : " + getClass().getName() + " :getDeptIdListByUserId()");
			 return new ResponseEntity<List<Map<String, Object>>>(deptIdListByUserId,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept List fetch failed");
			auditManager.audit(event);
			logger.error("Exception occurred while getting dept list", ex);
			resp.addError("getDeptIdByUserId()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@HystrixCommand
	@RequestMapping(value="/checkDepartmentAccess/{userid}/{departmentId}", method=RequestMethod.GET)
	public ResponseEntity<?>  checkDepartmentAccess(@PathVariable("userid")Long userid,@PathVariable("departmentId")Long departmentId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID",userid);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :checkDepartmentAccess()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("checkDepartmentAccess");
		try {
			 Boolean hasAccess = userService.checkDepartmentAccess(userid,departmentId);
			 event.addField("userid", userid);
			 event.addField("status", "Department has access "+hasAccess);
			 auditManager.audit(event);
			 logger.debug("End : " + getClass().getName() + " :checkDepartmentAccess()");
			 return new ResponseEntity<Boolean>(hasAccess,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept List fetch failed");
			auditManager.audit(event);
			logger.error("Exception occurred while verifying access", ex);
			resp.addError("checkDepartmentAccess()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value="/checkDepartmentAccessByName/{userid}/{departmentName:.+}", method=RequestMethod.GET)
	public ResponseEntity<?>  checkDepartmentAccessByName(@PathVariable("userid")Long userid,@PathVariable("departmentName")String departmentName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID",userid);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :checkDepartmentAccessByName()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("checkDepartmentAccessByName");
		try {
			 Boolean hasAccess = userService.checkDepartmentAccessByName(userid,departmentName);
			 event.addField("userid", userid);
			 event.addField("status", "Department has access "+hasAccess);
			 auditManager.audit(event);
			 logger.debug("End : " + getClass().getName() + " :checkDepartmentAccessByName()");
			 return new ResponseEntity<Boolean>(hasAccess,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept List fetch failed");
			auditManager.audit(event);
			logger.error("Exception occurred while verifying access", ex);
			resp.addError("checkDepartmentAccessByName()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@HystrixCommand
	@RequestMapping(value="/getDepartmentIdsByUserId/{userid}", method=RequestMethod.GET)
	public ResponseEntity<?>  getDepartmentIdsByUserId(@PathVariable("userid")Long userid,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.USER.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("USERID",userid);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Begin : " + getClass().getName() + " :getDepartmentIdsByUserId()");
		ResponseObject resp = new ResponseObject();
		if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007", 
					new Object[] {com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_ADMIN},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		AuditEvent event = new AuditEvent();
		event.setActor("UserDepartmentController");
		event.setAction("getDepartmentIdsByUserId");
		try {
			 List<Long> departmentIds = userService.getDepartmentIdsByUserId(userid);
			 event.addField("userid", userid);
			 event.addField("status", "Department id's successfully retrieved. ");
			 auditManager.audit(event);
			 logger.debug("End : " + getClass().getName() + " :getDepartmentIdsByUserId()");
			 return new ResponseEntity<List<Long>>(departmentIds,HttpStatus.OK);
		}catch(Exception ex) {
			event.addField("userid", userid);
			event.addField("status", "Dept fetch failed");
			auditManager.audit(event);
			logger.error("Exception occurred while getting dept list", ex);
			resp.addError("checkDepartmentAccess()", "Exception Occurred"+ex.getMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
}

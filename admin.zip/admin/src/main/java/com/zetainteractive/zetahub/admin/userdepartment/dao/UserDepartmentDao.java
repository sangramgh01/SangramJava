package com.zetainteractive.zetahub.admin.userdepartment.dao;



import java.util.List;
import java.util.Map;

import com.zetainteractive.foundation.domain.UserBO;



public interface UserDepartmentDao {

	/**
	 * 
	 * @param UserDeptBO
	 * @return
	 * @throws Exception 
	 */
	public Long saveUserDept(UserBO UserBO) throws  Exception;
	
	/**
	 * @param UserDeptBO
	 * @return
	 * @throws  Exception
	 */
	public boolean updateUserDept(UserBO UserBO) throws  Exception;
	/**
	 * 
	 * @param userID
	 * @return
	 */
	public Long getDeptIdByUserId(Long userID)throws  Exception;
	
	/**
	 * 
	 * @param userID
	 * @return
	 */
	public Boolean deleteUserDeptByUserId(Long userID)throws  Exception;
	/**
	 * 
	 * @param userID
	 * @return
	 */
	 public List<Map<String, Object>> getDeptIdListByUserId(Long userID) throws Exception;
	 /***
	  * 
	  * 
	  * Method Name 	: checkDepartmentAccess
	  * Description 	: The Method "checkDepartmentAccess" is used for user having access or not for particular department 
	  * Date    		: 17 Aug 2017, 14:25:37
	  * @param userID
	  * @param departmentId
	  * @return
	  * @throws Exception
	  * @param  		:
	  * @return 		: Boolean
	  * @throws 		:
	  */
	 public Boolean checkDepartmentAccess(Long userID, Long departmentId) throws Exception;
	 /***
	  * 
	  * 
	  * Method Name 	: checkDepartmentAccessByName
	  * Description 	: The Method "checkDepartmentAccess" is used for user having access or not for particular department 
	  * Date    		: 22 Aug 2017, 14:25:37
	  * @param userID
	  * @param departmentId
	  * @return
	  * @throws Exception
	  * @param  		:
	  * @return 		: Boolean
	  * @throws 		:
	  */
	 public Boolean checkDepartmentAccessByName(Long userID, String departmentName) throws Exception;
	 
	 /**
		 * 
		 * 
		 * Method Name 	: getDepartmentIdsByUserId
		 * Description 	: The Method "getDepartmentIdsByUserId" is used for getting list of department id's for particular user.
		 * Date    		: 17 Aug 2017, 18:12:03
		 * @param userID
		 * @return
		 * @throws Exception
		 * @param  		:
		 * @return 		: List<Long>
		 * @throws 		:
		 */
		public List<Long> getDepartmentIdsByUserId(Long userID) throws Exception;

		
}

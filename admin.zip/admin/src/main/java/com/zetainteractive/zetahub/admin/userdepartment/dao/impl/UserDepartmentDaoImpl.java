package com.zetainteractive.zetahub.admin.userdepartment.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.userdepartment.dao.UserDepartmentDao;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS)
public class UserDepartmentDaoImpl implements UserDepartmentDao {
	private static final Class<Long> List = null;

	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass());

	SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate jdbcTemplate;

	@Override
	public Long saveUserDept(UserBO userBO) throws Exception {
		logger.debug("Begin: " + getClass().getName() + " :saveUserDept()");

		String[] split = userBO.getListDepts().split(",");
		KeyHolder keyHolder = new GeneratedKeyHolder();
		Integer[] intarray = new Integer[split.length];

		try {
		for (String str : split) {
			String insertQuery = "INSERT INTO USER_DEPARTMENT  (USERID, DEPARTMENTID, ISDEFAULT,"
					+ "CREATEDBY,UPDATEDBY,CREATEDATE,UPDATEDATE)" + "VALUES (?,?,?,?,?,UTC_TIMESTAMP,UTC_TIMESTAMP)";

			if (userBO.getCreatedBy() == null)
				userBO.setCreatedBy("admin");
			if (userBO.getUpdatedBy() == null)
				userBO.setUpdatedBy("admin");
		
				jdbcTemplate.update(new PreparedStatementCreator() {
					@Override
					public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
						PreparedStatement pstmt = con.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
						pstmt.setLong(1, userBO.getUserID());
						pstmt.setLong(2, Integer.parseInt(str));

						if (str == split[0]) {
							pstmt.setString(3, String.valueOf('Y'));
						} else
							pstmt.setString(3, String.valueOf('N'));
						pstmt.setString(4, userBO.getCreatedBy());
						pstmt.setString(5, userBO.getUpdatedBy());
						return pstmt;
					}
				}, keyHolder);
			}
		
		} catch (DataIntegrityViolationException ex) {
			logger.error("Exception in saveUserDept():: ", ex);
			if (ex.getCause() instanceof SQLIntegrityConstraintViolationException) {
				throw new Exception("Duplicate entry for UserBO ' " + userBO.getUserID() + " '.", ex);
		}
		} catch (Exception ex) {
			logger.error("Exception in saveUserDept():: ", ex);
			throw new Exception("Exception in saveUserDept() :: " + ex.getMessage(), ex);
		}
		
		logger.debug("End : " + getClass().getName() + " :saveUserDept()");
		return keyHolder.getKey() != null ? keyHolder.getKey().longValue() : 0L;
	}

	@Override
	public boolean updateUserDept(UserBO userBO) throws Exception {
		logger.debug("Begin : " + getClass().getName() + " :updateUserDept()");
		int result = 0;
		if (userBO.getCreatedBy() == null)
			userBO.setCreatedBy("admin");
		if (userBO.getUpdatedBy() == null)
			userBO.setUpdatedBy("admin");

		String[] split = userBO.getListDepts().split(",");
		KeyHolder keyHolder = new GeneratedKeyHolder();

		String insertQuery = "INSERT INTO USER_DEPARTMENT  (USERID, DEPARTMENTID, ISDEFAULT,"
				+ "CREATEDBY,UPDATEDBY,CREATEDATE,UPDATEDATE)" + "VALUES (?,?,?,?,?,UTC_TIMESTAMP,UTC_TIMESTAMP)";

		try {
			
			String DELETEQUERY = "DELETE FROM USER_DEPARTMENT WHERE USERID =? ";
			jdbcTemplate.update(DELETEQUERY, userBO.getUserID());
			for (String str : split) {
				if (userBO.getCreatedBy() == null)
					userBO.setCreatedBy("admin");
				if (userBO.getUpdatedBy() == null)
					userBO.setUpdatedBy("admin");
					result = jdbcTemplate.update(new PreparedStatementCreator() {
						@Override
						public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
							PreparedStatement pstmt = con.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
							pstmt.setLong(1, userBO.getUserID());
							pstmt.setLong(2, Integer.parseInt(str));
	
							if (str == split[0]) {
								pstmt.setString(3, String.valueOf('Y'));
							} else
								pstmt.setString(3, String.valueOf('N'));
							pstmt.setString(4, userBO.getCreatedBy());
							pstmt.setString(5, userBO.getUpdatedBy());
							return pstmt;
						}
					}, keyHolder);
	
				}
			logger.debug("End : " + getClass().getName() + " :updateUserDept()");
			return result > 0;
		} catch (Exception ex) {
			logger.error("Exception in updateUserDept()::", ex);
			throw new Exception("Exception updateUserDept() ::" + ex.getMessage(), ex);
			
		}

	}

	@Override
	public Long getDeptIdByUserId(Long userID) throws Exception {
		logger.debug("Begin : "+getClass().getName() + " : getDeptIdByUserId()");
		String query = "SELECT DEPARTMENTID from USER_DEPARTMENT WHERE userid=? and ISDEFAULT='Y'";
		long deptId = 0;
		try {
			deptId = jdbcTemplate.queryForObject(query,Long.class,userID);
			logger.debug("End: "+getClass().getName() + " :getDeptIdByUserId()");
			return deptId;
		} catch (Exception e) {
			logger.error("Exception in getDeptIdByUserId() :: ", e);
			throw new Exception("Exception in getDeptIdByUserId() :: ", e);
		}
	}

	@Override
	public Boolean deleteUserDeptByUserId(Long userID) throws Exception {
		logger.debug("Begin : " + getClass().getName() + " : deleteUserDeptByUserId()");
		String query = "DELETE FROM USER_DEPARTMENT WHERE userid = ?";
		int update = 0;
		try {
			update = jdbcTemplate.update(query,userID);
			logger.debug("End : " + getClass().getName() + " : deleteUserDeptByUserId()");
			return update>0;
		} catch (Exception e) {
			logger.error("Exception in deleteUserDeptByUserId() :: ", e);
			throw new Exception("Exception in deleteUserDeptByUserId() :: ", e);
		}
	}
	@Override
	public List<Map<String, Object>> getDeptIdListByUserId(Long userID) throws Exception {
		logger.debug("Begin : "+ getClass().getName() + " : getDeptIdListByUserId()");
		String query = "SELECT * from USER_DEPARTMENT WHERE userid=? order by id ASC";
		List<Map<String, Object>> listOfDeptBo = new ArrayList<>();
		try {
			listOfDeptBo = jdbcTemplate.queryForList(query, userID);
			logger.debug("End : "+ getClass().getName() + " : getDeptIdListByUserId()");
			return listOfDeptBo;
		} catch (Exception e) {
			logger.error("Exception in getDeptIdListByUserId() :: ", e);
			throw new Exception("Exception in getDeptIdListByUserId() :: ", e);
		}
	}
	
	@Override
	public Boolean checkDepartmentAccess(Long userID,Long departmentId) throws Exception {
		logger.debug("Begin : "+ getClass().getName() + " : checkDepartmentAccess()");
		String query = "SELECT COUNT(*) from USER_DEPARTMENT WHERE userid=? AND DEPARTMENTID=? ";
		try {
			Long count = jdbcTemplate.queryForObject(query, new Object[]{userID,departmentId},Long.class);
			logger.debug("End : "+ getClass().getName() + " : checkDepartmentAccess()");
			return count>0;
		} catch (Exception e) {
			logger.error("Exception in checkDepartmentAccess() :: ", e);
			throw new Exception("Exception in checkDepartmentAccess() :: ", e);
		}
	}
	
	@Override
	public Boolean checkDepartmentAccessByName(Long userID,String departmentName) throws Exception {
		logger.debug("Begin : "+ getClass().getName() + " : checkDepartmentAccessByName()");
		String query = "SELECT COUNT(1) from USER_DEPARTMENT WHERE userid=? AND DEPARTMENTID IN (SELECT DEPARTMENTID FROM ADM_DEPARTMENT WHERE DEPARTMENTNAME=?)";
		try {
			Long count = jdbcTemplate.queryForObject(query, new Object[]{userID,departmentName},Long.class);
			logger.debug("End : "+ getClass().getName() + " : checkDepartmentAccess()");
			return count>0;
		} catch (Exception e) {
			logger.error("Exception in checkDepartmentAccessByName() :: ", e);
			throw new Exception("Exception in checkDepartmentAccessByName() :: ", e);
		}
	}
	
	@Override
	public List<Long> getDepartmentIdsByUserId(Long userID) throws Exception{
		logger.debug("Begin : "+ getClass().getName() + " : getDepartmentIdsByUserId()");
		String query = "SELECT departmentid from USER_DEPARTMENT WHERE userid=? ";
		try {
			List<Long> departmentIds=jdbcTemplate.queryForList(query, new Object[]{userID},Long.class);
			logger.debug("End : "+ getClass().getName() + " : getDepartmentIdsByUserId()");
			return departmentIds;
		} catch (Exception e) {
			logger.error("Exception in getDepartmentIdsByUserId() :: ", e);
			throw new Exception("Exception in getDepartmentIdsByUserId() :: ", e);
		}
	}

}

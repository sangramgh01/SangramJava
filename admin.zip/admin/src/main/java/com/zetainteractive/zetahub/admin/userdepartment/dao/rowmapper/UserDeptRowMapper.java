package com.zetainteractive.zetahub.admin.userdepartment.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

public class UserDeptRowMapper implements RowMapper<UserBO> {

	ZetaLogger logger = new ZetaLogger(getClass());
	
	@Override
	public UserBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		UserBO userDeptBO = new UserBO();
		
		//userDeptBO.setId(rs.getLong("ID"));
		userDeptBO.setUserID(rs.getInt("USERID"));
		userDeptBO.setDepartmentID(rs.getInt("DEPARTMENTID"));
		//userDeptBO.setIsDefault(rs.getString("ISDEFAULT").charAt(0));
		userDeptBO.setCreatedBy(rs.getString("CREATEDBY"));
		userDeptBO.setUpdatedBy(rs.getString("UPDATEDBY"));

		/** Converting timestamp from server timezone to local timezone *//*
		java.sql.Timestamp createDate = null, updateDate = null;
		try {
			TimeZone timeZone = TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone());
			createDate = rs.getTimestamp("CREATEDATE")==null?null:CommonUtil.toLocalTime(rs.getTimestamp("createdate").getTime(), timeZone);
			updateDate = rs.getTimestamp("UPDATEDATE")==null?null:CommonUtil.toLocalTime(rs.getTimestamp("updatedate").getTime(), timeZone);	
		} catch (Exception e1) {
			logger.error("Error occured while converting timestamp to user timezone: "+e1.getMessage());
		}*/
		if(rs.getString("createdate") != null)
			userDeptBO.setCreateDate(rs.getTimestamp("CREATEDATE"));
		
		if(rs.getString("updatedate") != null)
			userDeptBO.setUpdateDate(rs.getTime("UPDATEDATE"));
		return userDeptBO;
	}

}

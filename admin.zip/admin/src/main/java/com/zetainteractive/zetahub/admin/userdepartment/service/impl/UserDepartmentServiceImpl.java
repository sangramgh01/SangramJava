package com.zetainteractive.zetahub.admin.userdepartment.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.admin.userdepartment.dao.UserDepartmentDao;
import com.zetainteractive.zetahub.admin.userdepartment.service.UserDepartmentService;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

@Component
@Service
public class UserDepartmentServiceImpl implements UserDepartmentService{
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass());

	@Autowired
	UserDepartmentDao  userDao;
	
	
	@Override
	public Long saveUserDept(UserBO UserBO) throws Exception {
		return userDao.saveUserDept(UserBO);
	}

	@Override
	public boolean updateUserDept(UserBO userBO) throws Exception {
		return userDao.updateUserDept(userBO);
	}

	@Override
	public Long getDeptIdByUserId(Long userID) throws Exception {
		return userDao.getDeptIdByUserId(userID);
	}

	@Override
	public Boolean deleteUserDeptByUserId(Long userID) throws Exception {
		return userDao.deleteUserDeptByUserId(userID);
	}
	@Override
	public List<Map<String, Object>> getDeptIdListByUserId(Long userID) throws Exception{
		return userDao.getDeptIdListByUserId(userID);
	}

	@Override
	public Boolean checkDepartmentAccess(Long userID, Long departmentId) throws Exception {
		return userDao.checkDepartmentAccess(userID,departmentId);
		
	}
	@Override
	public Boolean checkDepartmentAccessByName(Long userID, String departmentName) throws Exception {
		return userDao.checkDepartmentAccessByName(userID,departmentName);
		
	}
	
	@Override
	public List<Long> getDepartmentIdsByUserId(Long userID) throws Exception{
		return userDao.getDepartmentIdsByUserId(userID);
	}

}

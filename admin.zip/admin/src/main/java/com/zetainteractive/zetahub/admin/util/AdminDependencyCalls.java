package com.zetainteractive.zetahub.admin.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.Node;
import com.zetainteractive.zetahub.commons.domain.TrackClicksBO;
import com.zetainteractive.zetahub.expression.exception.ExpressionException;

/**
 * 
 * @author Sangram.Panda
 *
 */
@Component
public class AdminDependencyCalls {
	
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	private RestRequestHandler restHandler = new RestRequestHandler();
	private String conversationEndPoint;
	private String securityEndPoint;
	
	/**
	 * @throws Exception
	 */
	public AdminDependencyCalls() throws Exception{
		securityEndPoint = ZetaUtil.getHelper().getEndpoint("security");
		conversationEndPoint = ZetaUtil.getHelper().getEndpoint("conversation");
	}
	
	/**
	 * @param listName
	 * @return
	 * @throws Exception
	 */
	public Boolean canDeleteList(String listName) throws Exception{
		logger.debug("Begin:: "+getClass().getName()+".canDeleteList(String listName)");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity<Object> entity = new HttpEntity<>(headers);
		ResponseEntity<Boolean> responseResult = restHandler.exchange(conversationEndPoint+"/canDeleteList/"+listName, HttpMethod.GET, entity,Boolean.class);
		logger.debug("End:: "+getClass().getName()+".canDeleteList(String listName)");
		return  responseResult.getBody();
	}
	/**
	 * getting userbo by username 
	 * @param userName
	 */
	public UserBO getUserBO(String userName) throws Exception{
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity<Object> entity = new HttpEntity<>(headers);
		UserBO user =  new RestRequestHandler().exchange(securityEndPoint + "/getUserByName/" + userName, HttpMethod.GET,
				entity, UserBO.class).getBody();
		return user;
	}
	/**
	 * Verifying filEncryptionKey is used in Conversation or not
	 * @param encryptionKey
	 * throws Exception
	 */
	public Boolean isFileEncryptionExistinConv(String encryptionKey) throws Exception{
		logger.debug("Begin:: "+getClass().getName()+".isFileEncryptionExistinConv(String encryptionKey)");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity<Object> entity = new HttpEntity<>(headers);
		ResponseEntity<Boolean> responseResult = restHandler.exchange(conversationEndPoint+"/Conversation"+"/isFileEncryptionExistinConv/"+encryptionKey, HttpMethod.GET, entity,Boolean.class);
		logger.debug("End:: "+getClass().getName()+".isFileEncryptionExistinConv(String encryptionKey)");
		return  responseResult.getBody();
	}
	
	/**
	 * For getting All touchpoints  using conversation id a rest call to conversation-manager
	 * @param conversation id
	 * throws Exception
	 * @throws Exception 
	 */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<Node> listAllTouchPoints(long convId) throws Exception{
		logger.debug("Start : listAllTouchPoints()");
		List<Node> touchPoints = null;
		try {
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity entity = new HttpEntity<>(headers);
			ResponseEntity<List<Node>> response;
			response = restHandler.exchange(
				ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/listAllTouchPoints/"+convId , HttpMethod.GET, entity,
			    new ParameterizedTypeReference<List<Node>>() {
			    });
			touchPoints = response.getBody();
		
		} catch (Exception e) {
			logger.debug("Exceptin in  : listAllTouchPoints()");
			throw e;
		}
		return touchPoints;
	}
	
	/**
	 * For getting conversation by name using through a rest call to conversation-manager
	 * @param conversation name
	 * throws Exception
	 * @throws Exception 
	 */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Conversation getConversationByName(String conversationName) throws Exception{
		logger.debug("Start : getConversationByName()");
		Conversation conversation=null;
		try{
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			Map<String,String> conversationData = new HashMap<>();
			conversationData.put("conversationName", conversationName+"");
			HttpEntity entity = new HttpEntity<>(conversationData,headers);
			ResponseEntity<Conversation> response = restHandler.exchange(
				ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/getConversationByName" , HttpMethod.POST, entity,
	            Conversation.class);
			conversation = response.getBody();
		}catch(Exception e){
			logger.debug("Exceptin in  : getConversationByName()");
			throw e;
		}
		return conversation;
	}
	
	
	/**
	 * For getting All the links and clicks information
	 * @param campaign id
	 * throws Exception
	 */
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public List<TrackClicksBO> getAllTrackClicks(String tracklinkUrlString) throws ExpressionException,Exception{
		logger.debug("Start : getAllTrackClicks()");
		try {
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity entity = new HttpEntity<>(headers);
			ResponseEntity<List<TrackClicksBO>> response = new RestRequestHandler().exchange(
        		ZetaUtil.getHelper().getEndpoint("conversation")+"/getAllTrackClicks/"+tracklinkUrlString , HttpMethod.GET, entity,
                    new ParameterizedTypeReference<List<TrackClicksBO>>() {
                    });
			
			return response.getBody();
		}
		catch (ExpressionException e) {
			logger.debug("Exceptin in  : getAllTrackClicks()");
			throw e;
		} catch (Exception e) {
			logger.debug("Exceptin in  : getAllTrackClicks()");
			throw e;
		}
		
	}
  
}

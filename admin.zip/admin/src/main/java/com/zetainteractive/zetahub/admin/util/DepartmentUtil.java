package com.zetainteractive.zetahub.admin.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.admin.audience.service.AudienceService;
import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.ConfigurationService;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AddressListBO;
import com.zetainteractive.zetahub.commons.domain.AdobeAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.CommonNotificationBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.DeptAudienceBO;
import com.zetainteractive.zetahub.commons.domain.DomainBO;
import com.zetainteractive.zetahub.commons.domain.DomainOptoutRule;
import com.zetainteractive.zetahub.commons.domain.GoogleAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.MobileBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.NotificationStatus;
import com.zetainteractive.zetahub.commons.domain.OtherWebAnalyticsBO;
import com.zetainteractive.zetahub.commons.domain.ParametersBO;
import com.zetainteractive.zetahub.commons.domain.ResponseDomain;
import com.zetainteractive.zetahub.commons.domain.UnsubRulesBO;

/**
 * @author Lakshmi.Medarametla
 *
 */
@Component
public class DepartmentUtil {
	
	@Autowired
	ConfigurationService configurationService;
	
	@Autowired
	AudienceService audienceService;
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentNotifications(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		Long departmentid = Long.valueOf(0L);
		Long departmentsettingid = Long.valueOf(0L);
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings){
			if(Constants.DEPARTMENT_NOTIFICATIONS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
				NotificationBO notificationBO = (NotificationBO)departmentSetting.getObjectValue();
				if(notificationBO.getNotifications() != null && !notificationBO.getNotifications().isEmpty()){
					exists=true;
				}else{
					departmentid = departmentSetting.getDepartmentID();
					departmentsettingid = departmentSetting.getDepartmentSettingId();
				}
			}
		}
		if(!exists){
			DepartmentSettings deptSetting = new DepartmentSettings();
			String[] types = {"Conversation","Files","Lists","Workflows","Reports"};
			String[] conversationStatuses = {"Activated","Deactivated","Waiting","Approved","Rejected","Ready","Executing","Completed","Errored","Skipped","Stopped"};
			String[] filesStatuses = {"Executing","Cancelled","Completed","Errored"};
			String[] listsStatuses = {"Executing","Completed","Errored"};
			String[] workflowsStatuses = {"Waiting","Ready","Executing","Completed","Errored","Skipped","Stopped","Cancelled"};
			NotificationBO notificationBo = new NotificationBO();
			CommonNotificationBO cnBO = null;
			List<CommonNotificationBO> notifications = new ArrayList<>(5);
			for(int i=0;i<types.length;i++){
				cnBO = new CommonNotificationBO();
				List<NotificationStatus> notificationStatuses = new ArrayList<>();
				cnBO.setNotificationTypeName(types[i]);
				cnBO.setIsEnabled(false);
				if(types[i].equals("Conversation")){
					for(int j=0;j<conversationStatuses.length;j++){
						NotificationStatus noteStat = new NotificationStatus();
						noteStat.setIsEnabled(false);
						noteStat.setName(conversationStatuses[j]);
						notificationStatuses.add(noteStat);
					}
				}else if(types[i].equals("Files")){
					for(int j=0;j<filesStatuses.length;j++){
						NotificationStatus noteStat = new NotificationStatus();
						noteStat.setIsEnabled(false);
						noteStat.setName(filesStatuses[j]);
						notificationStatuses.add(noteStat);
					}
				}else if(types[i].equals("Lists")){
					for(int j=0;j<listsStatuses.length;j++){
						NotificationStatus noteStat = new NotificationStatus();
						noteStat.setIsEnabled(false);
						noteStat.setName(listsStatuses[j]);
						notificationStatuses.add(noteStat);
					}
				}else if(types[i].equals("Workflows")){
					for(int j=0;j<workflowsStatuses.length;j++){
						NotificationStatus noteStat = new NotificationStatus();
						noteStat.setIsEnabled(false);
						noteStat.setName(workflowsStatuses[j]);
						notificationStatuses.add(noteStat);
					}
				}
				cnBO.setNotificationStatuses(notificationStatuses);
				notifications.add(cnBO);
			}
			notificationBo.setNotifications(notifications);
			if(departmentid > 0)
				deptSetting.setDepartmentID(departmentid);
			if(departmentsettingid > 0)
				deptSetting.setDepartmentSettingId(departmentsettingid);
			deptSetting.setObjectKey(Constants.DEPARTMENT_NOTIFICATIONS_KEY);
			deptSetting.setObjectValue(notificationBo);
			if(departmentSettings.size() > 0){
				for(int i=0;i<departmentSettings.size();i++){
					if(Constants.DEPARTMENT_NOTIFICATIONS_KEY.equalsIgnoreCase(departmentSettings.get(i).getObjectKey())){
						departmentSettings.remove(i);
						departmentSettings.add(i, deptSetting);
					}
				}
			}else{
				departmentSettings.add(deptSetting);
			}
		}
	}
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentAddressLists(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_ADDRESSLIST_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings addressList = new DepartmentSettings();
			addressList.setObjectKey(Constants.DEPARTMENT_ADDRESSLIST_KEY);
			addressList.setObjectValue(new AddressListBO());
			departmentSettings.add(addressList);
		}
	}
	
	/**
	 * @param departmentSettings
	 * @throws Exception 
	 */
	public void addNewDepartmentParameters(List<DepartmentSettings> departmentSettings) throws Exception{
		boolean exists=false;
		DepartmentSettings parameters=null;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings){
			if(Constants.DEPARTMENT_PARAMETERS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
				parameters=departmentSetting;
				exists=true;
			}
		}
		if(!exists){
			parameters = new DepartmentSettings();
			ParametersBO parametersBO = new ParametersBO();
			parametersBO.setTrackOpensDefault(ZetaUtil.getHelper().getConfig().getConfigValueBoolean("admin-track-opens-default",false));
			parametersBO.setTrackClicksDefault(ZetaUtil.getHelper().getConfig().getConfigValueBoolean("admin-track-clicks-default",false));
			parametersBO.setTrackOpensURL(ZetaUtil.getHelper().getConfig().getConfigValueString("admin-track-opens-url",null)); 
			parametersBO.setTrackClicksShortURL(ZetaUtil.getHelper().getConfig().getConfigValueString("admin-track-clicks-short-url",null));
			parametersBO.setTrackClicksLongURL(ZetaUtil.getHelper().getConfig().getConfigValueString("admin-track-clicks-long-url",null)); 
			parametersBO.setDefaultHostedEmailURL(ZetaUtil.getHelper().getConfig().getConfigValueString("de-hosted-url",null)); 
			parametersBO.setDefaultImageURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-image-url",null)); 
			parametersBO.setDefaultUnsubURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-optout-url",null)); 
			parametersBO.setDefaultWebpageURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-webpage-url",null)); 
			String[] smtpHeaders = new String[1];
			smtpHeaders[0] = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-default-smtp-header",null);
			if(smtpHeaders[0]==null || smtpHeaders[0].equalsIgnoreCase("NA"))
				smtpHeaders[0]="X-NA:NA";
			parametersBO.setSmtpHeaders(smtpHeaders);
			parametersBO.setCanEditCustomerDomainURL(ZetaUtil.getHelper().getConfig().getConfigValueBoolean("admin-can-edit-customer-domain-url",true));
			parametersBO.setCustomerDomainURL(ZetaUtil.getHelper().getConfig().getConfigValueString("admin-customer-domain-url",null));
			parameters.setObjectKey(Constants.DEPARTMENT_PARAMETERS_KEY);
			parameters.setObjectValue(parametersBO);
			departmentSettings.add(parameters);
		}else{
			ParametersBO parametersBO = (ParametersBO) parameters.getObjectValue();
			if(parametersBO.getDefaultHostedEmailURL() == null)
				parametersBO.setDefaultHostedEmailURL(ZetaUtil.getHelper().getConfig().getConfigValueString("de-hosted-url",null)); 
			if(parametersBO.getDefaultImageURL() == null)
				parametersBO.setDefaultImageURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-image-url",null)); 
			if(parametersBO.getDefaultUnsubURL() == null)
				parametersBO.setDefaultUnsubURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-optout-url",null)); 
			if(parametersBO.getDefaultWebpageURL() == null)	
				parametersBO.setDefaultWebpageURL(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-webpage-url",null)); 
			for(ResponseDomain responseDomain : parametersBO.getListOfResponseDomains()){
				if(responseDomain.getHostedemailurl() == null)
					responseDomain.setHostedemailurl(ZetaUtil.getHelper().getConfig().getConfigValueString("de-hosted-url",null)); 
				if(responseDomain.getImageurl() == null)
					responseDomain.setImageurl(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-image-url",null)); 
				if(responseDomain.getUnsuburl() == null)
					responseDomain.setUnsuburl(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-optout-url",null)); 
				if(responseDomain.getWebpageurl() == null)	
					responseDomain.setWebpageurl(ZetaUtil.getHelper().getConfig().getConfigValueString("rc-webpage-url",null)); 
			}
		}
	}
	
	/**
	 * @param departmentSettings
	 * @throws AdminException 
	 */
	public void addNewDepartmentUnsubRules(List<DepartmentSettings> departmentSettings) throws AdminException{
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_UNSUBRULES_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings unsubRules = new DepartmentSettings();
			UnsubRulesBO unsubrulesBO = new UnsubRulesBO();
			List<DomainBO> domainsList = configurationService.listDomains();
			for (DomainBO domain : domainsList) {
				if (domain.getStatus() == 'A') {
					DomainOptoutRule rule = new DomainOptoutRule();
					rule.setDomainCode(domain.getCode());
					rule.setThreshold(5);
					rule.setType('S');
					rule.setIsEnabled(true);
					unsubrulesBO.getDomainOptoutRules().add(rule);
					rule = new DomainOptoutRule();
					rule.setDomainCode(domain.getCode());
					rule.setThreshold(3);
					rule.setType('N');
					rule.setIsEnabled(true);
					unsubrulesBO.getDomainOptoutRules().add(rule);
					rule = new DomainOptoutRule();
					rule.setDomainCode(domain.getCode());
					rule.setThreshold(1);
					rule.setType('H');
					rule.setIsEnabled(true);
					unsubrulesBO.getDomainOptoutRules().add(rule);
					rule = new DomainOptoutRule();
					rule.setDomainCode(domain.getCode());
					rule.setThreshold(10);
					rule.setType('B');
					rule.setIsEnabled(true);
					unsubrulesBO.getDomainOptoutRules().add(rule);
				}
			}
			unsubRules.setObjectKey(Constants.DEPARTMENT_UNSUBRULES_KEY);
			unsubRules.setObjectValue(unsubrulesBO);
			departmentSettings.add(unsubRules);

		}
	}
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentGoogleAnalytics(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_GOOGLEANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings googleAnalytics = new DepartmentSettings();
			googleAnalytics.setObjectKey(Constants.DEPARTMENT_GOOGLEANALYTICS_KEY);
			googleAnalytics.setObjectValue(new GoogleAnalyticsBO());
			departmentSettings.add(googleAnalytics);
		}
	}
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentAdobeAnalytics(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_ADOBEANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings adobeAnalytics = new DepartmentSettings();
			adobeAnalytics.setObjectKey(Constants.DEPARTMENT_ADOBEANALYTICS_KEY);
			adobeAnalytics.setObjectValue(new AdobeAnalyticsBO());
			departmentSettings.add(adobeAnalytics);
		}
	}
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentOtherWebAnalytics(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_OTHERWEBANALYTICS_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings otherWebAnalytics = new DepartmentSettings();
			otherWebAnalytics.setObjectKey(Constants.DEPARTMENT_OTHERWEBANALYTICS_KEY);
			otherWebAnalytics.setObjectValue(new OtherWebAnalyticsBO());
			departmentSettings.add(otherWebAnalytics);
		}
	}
	
	/**
	 * @param departmentSettings
	 */
	public void addNewDepartmentMobileDetails(List<DepartmentSettings> departmentSettings){
		boolean exists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_MOBILE_KEY.equalsIgnoreCase(departmentSetting.getObjectKey()))
				exists=true;
		if(!exists){
			DepartmentSettings mobile = new DepartmentSettings();
			mobile.setObjectKey(Constants.DEPARTMENT_MOBILE_KEY);
			mobile.setObjectValue(new MobileBO());
			departmentSettings.add(mobile);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: addNewDepartmentAudienceSettings
	 * Description 	: The Method "addNewDepartmentAudienceSettings" is used for 
	 * Date    		: 23 Jan 2018, 15:12:43
	 * @param departmentSettings
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	public void addNewDepartmentAudienceSettings(List<DepartmentSettings> departmentSettings){
		boolean isExists=false;
		if(departmentSettings==null)
			departmentSettings=new ArrayList<>();
		for(DepartmentSettings departmentSetting : departmentSettings)
			if(Constants.DEPARTMENT_AUDIENCE_KEY.equalsIgnoreCase(departmentSetting.getObjectKey())){
				isExists=true;
				if (departmentSetting.getObjectValue() != null && departmentSetting.getObjectValue() instanceof List<?>){
					List<DeptAudienceBO> deptAudienceBOs=(List<DeptAudienceBO>)departmentSetting.getObjectValue();
					if(deptAudienceBOs != null && !deptAudienceBOs.isEmpty()){
						deptAudienceBOs=getDepartmentAudiences(deptAudienceBOs);
						departmentSetting.setObjectValue(deptAudienceBOs);
					}else{
						departmentSetting.setObjectValue(new ArrayList<DeptAudienceBO>());
					}
				}
				break;
			}
		if(!isExists){
			DepartmentSettings audienceSettings = new DepartmentSettings();
			audienceSettings.setObjectKey(Constants.DEPARTMENT_AUDIENCE_KEY);
			audienceSettings.setObjectValue(new ArrayList<DeptAudienceBO>());
			departmentSettings.add(audienceSettings);
		}
			
	}
	public void addUncreatedSettings(List<DepartmentSettings> departmentSettings) throws Exception{
		addNewDepartmentNotifications(departmentSettings);
		addNewDepartmentAddressLists(departmentSettings);
		addNewDepartmentParameters(departmentSettings);
		addNewDepartmentUnsubRules(departmentSettings);
		addNewDepartmentGoogleAnalytics(departmentSettings);
		addNewDepartmentAdobeAnalytics(departmentSettings);
		addNewDepartmentMobileDetails(departmentSettings);
		addNewDepartmentOtherWebAnalytics(departmentSettings);
		addNewDepartmentAudienceSettings(departmentSettings);
	}
	/**
	 * 
	 * 
	 * Method Name 	: getDepartmentAudiences
	 * Description 	: The Method "getDepartmentAudiences" is used for 
	 * Date    		: 24 Jan 2018, 11:47:20
	 * @param deptAudienceBOs
	 * @return
	 * @param  		:
	 * @return 		: List<DeptAudienceBO>
	 * @throws 		:
	 */
	public List<DeptAudienceBO> getDepartmentAudiences(List<DeptAudienceBO> deptAudienceBOs){
		List<Long> audienceIds=deptAudienceBOs.stream().map(DeptAudienceBO::getAudienceId).collect(Collectors.toList());
		Map<Long,String> audienceDetails=audienceService.getAudienceNamesByIds(audienceIds);
		for (DeptAudienceBO deptAudienceBO : deptAudienceBOs){
			deptAudienceBO.setAudienceName(audienceDetails.containsKey(deptAudienceBO.getAudienceId()) ? audienceDetails.get(deptAudienceBO.getAudienceId()) : "");
		}
		return deptAudienceBOs;
	}
}

/*
 * Created on Dec 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.zetainteractive.zetahub.admin.util.ExportUtil;

import java.util.Date;



/**
 * @author lgollapalli
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EbizCell 
{
    
    public static int FONTWEIGHT_NORMAL = 0;
    public static int FONTWEIGHT_BOLD = 1;
    public static int FONTSTYLE_NORMAL = 0;
    public static int FONTSTYLE_ITALIC = 1;
    public static int ALIGN_LEFT = 0;
    public static int ALIGN_RIGHT = 1;
    public static int ALIGH_CENTER=2;
 
    
    private int boldweight=EbizCell.FONTWEIGHT_NORMAL;
    private int fontstyle=EbizCell.FONTSTYLE_NORMAL;
    private String fontname;
    private int alignment=ALIGN_LEFT;
    private int mergestart=-1;
    private int mergeend=-1;
    private String value;
    private String integervalue;
    private String doublevalue;
    private Date datevalue;
    
    
    
    
    
    
	public String getIntegervalue() {
		return integervalue;
	}
	public void setIntegervalue(String integervalue) {
		this.integervalue = integervalue;
	}
	public String getDoublevalue() {
		return doublevalue;
	}
	public void setDoublevalue(String doublevalue) {
		this.doublevalue = doublevalue;
	}
	public Date getDatevalue() {
		return datevalue;
	}
	public void setDatevalue(Date datevalue) {
		this.datevalue = datevalue;
	}
    /**
     * @return Returns the mergeend.
     */
    public int getMergeend() {
        return mergeend;
    }
    /**
     * @param mergeend The mergeend to set.
     */
    public void setMergeend(int mergeend) {
        this.mergeend = mergeend;
    }
    /**
     * @return Returns the mergestart.
     */
    public int getMergestart() {
        return mergestart;
    }
    /**
     * @param mergestart The mergestart to set.
     */
    public void setMergestart(int mergestart) {
        this.mergestart = mergestart;
    }
    
    
   
    
    /**
     * @return Returns the value.
     */
    public String getValue() 
    {
        return value;
    }
    /**
     * @param value The value to set.
     */
    public void setValue(String value) {
        this.value = value;
    }
    /**
     * @return Returns the alignment.
     */
    public int getAlignment() {
        return alignment;
    }
    /**
     * @param alignment The alignment to set.
     */
    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }
    /**
     * @return Returns the boldweight.
     */
    public int getBoldweight() {
        return boldweight;
    }
    /**
     * @param boldweight The boldweight to set.
     */
    public void setBoldweight(int boldweight) {
        this.boldweight = boldweight;
    }
    /**
     * @return Returns the fontname.
     */
    public String getFontname() {
        return fontname;
    }
    /**
     * @param fontname The fontname to set.
     */
    public void setFontname(String fontname) {
        this.fontname = fontname;
    }
    /**
     * @return Returns the italic.
     */
    public int isItalic() {
        return fontstyle;
    }
    /**
     * @param italic The italic to set.
     */
    public void setItalic(int fontstyle) {
        this.fontstyle = fontstyle;
    }
    
    
    
    
    /**
     * @return Returns the fontstyle.
     */
    public int getFontstyle() {
        return fontstyle;
    }
    /**
     * @param fontstyle The fontstyle to set.
     */
    public void setFontstyle(int fontstyle) {
        this.fontstyle = fontstyle;
    }
}

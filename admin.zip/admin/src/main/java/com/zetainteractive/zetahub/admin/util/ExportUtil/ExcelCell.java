package com.zetainteractive.zetahub.admin.util.ExportUtil;
/**
 * 
 * @author Krishna.Polisetti
 *
 */
public class ExcelCell 
{
    
    public static int FONTWEIGHT_NORMAL = 0;
    public static int FONTWEIGHT_BOLD = 1;
    public static int FONTSTYLE_NORMAL = 0;
    public static int FONTSTYLE_ITALIC = 1;
    public static int ALIGN_LEFT = 0;
    public static int ALIGN_RIGHT = 1;
    public static int ALIGH_CENTER=2;
 
    
    private int boldweight = ExcelCell.FONTWEIGHT_NORMAL;
    private String fontname = "Arial";
    private int alignment=ALIGN_LEFT;
    private String value;
    private short fontSize = 10;
    private boolean isWrapText ; 
    private byte underLine ;
    
    private String cellStylePattern = null;
 
    /**
     * @return Returns the value.
     */
    public String getValue() 
    {
        return value;
    }
    /**
     * @param value The value to set.
     */
    public void setValue(String value) {
        this.value = value;
    }
    /**
     * @return Returns the alignment.
     */
    public int getAlignment() {
        return alignment;
    }
    /**
     * @param alignment The alignment to set.
     */
    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }
    /**
     * @return Returns the boldweight.
     */
    public int getBoldweight() {
        return boldweight;
    }
    /**
     * @param boldweight The boldweight to set.
     */
    public void setBoldweight(int boldweight) {
        this.boldweight = boldweight;
    }
    /**
     * @return Returns the fontname.
     */
    public String getFontname() {
        return fontname;
    }
    /**
     * @param fontname The fontname to set.
     */
    public void setFontname(String fontname) {
        this.fontname = fontname;
    }

    /**
     * @return Returns the fontSize.
     */
    public short getFontSize() {
        return fontSize;
    }
    /**
     * @param fontSize The fontSize to set.
     */
    public void setFontSize(short fontSize) {
        this.fontSize = fontSize;
    }
    /**
     * @return Returns the isWrapText.
     */
    public boolean isWrapText() {
        return isWrapText;
    }
    /**
     * @param isWrapText The isWrapText to set.
     */
    public void setWrapText(boolean isWrapText) {
        this.isWrapText = isWrapText;
    }
    /**
     * @return Returns the underLine.
     */
    public byte getUnderLine() {
        return underLine;
    }
    /**
     * @param underLine The underLine to set.
     */
    public void setUnderLine(byte underLine) {
        this.underLine = underLine;
    }
    /**
     * @return Returns the cellStylePattern.
     */
    public String getCellStylePattern() {
        return cellStylePattern;
    }
    /**
     * @param cellStylePattern The cellStylePattern to set.
     */
    public void setCellStylePattern(String cellStylePattern) {
        this.cellStylePattern = cellStylePattern;
    }
}

package com.zetainteractive.zetahub.admin.util.ExportUtil;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Vector;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class ExportUtil 
{
	
    private HashMap<String, HSSFCellStyle> cellStyleMap =  new LinkedHashMap();
    final public String DATA_STYLE="dataStyle";
    public String PERCENT_DATA_STYLE = "percentdataStyle";
    
    /**
     * This method is responsible to export collection information to ByteArrayOutputStream.
     * @param collection
     * @return
     * @throws EbizException
     * @throws Exception
     */
    @SuppressWarnings("deprecation")
	public ByteArrayOutputStream exportToExcel(Vector<?> collection, Vector<MergeCells> mergeVector, boolean isSecondSheetAvailable, int beginTabIndex, int endTabIndex) throws Exception 
    {
        HSSFSheet sheet = null;   
        HSSFSheet sheet1 = null;
        HSSFWorkbook workbook = null;        
        HSSFCellStyle cellStyle = null;
        HSSFFont fontstyle = null;
        ByteArrayOutputStream baos = null;
        int k = 0;
        int i = 0;
        Vector<?> sheetvec = null;
        Vector<?> tmp = null;
        boolean flag = false;
        
        try{
            workbook = new HSSFWorkbook();        
            baos = new ByteArrayOutputStream();
            org.apache.poi.hssf.util.Region region = new org.apache.poi.hssf.util.Region(0, (short)0, 0, (short)10);
            for(; k < collection.size(); k++){
                sheetvec = (Vector<?>) collection.get(k);
                //Create Sheet.
                sheet = workbook.createSheet();
                //Set merge portion for first column containing 10 cells when mergeVector is not null
                //This is to identify flow. MergeVector -> CSR:null, Reports: not null
                if(mergeVector != null){
                    sheet.addMergedRegion(region);
                }
                if(isSecondSheetAvailable){
                    sheet1 = workbook.createSheet();
                    sheet1.addMergedRegion(region);
                }
                
                //Create Rows
                for (; i < sheetvec.size(); i++){
                    tmp = (Vector<?>) sheetvec.get(i);
                    flag = false;                    
                    if(i >= beginTabIndex && i < endTabIndex){
                        flag = true;
                    }
                    createRow(workbook, sheet, sheet1, tmp, i, cellStyle, fontstyle, flag);
                }
            }
            
            
            //Below code is to span logic block name over 5 columns.
            //Not written in calling function as we have certain conditions based on mergeVector over here.
            if(mergeVector==null)
            	mergeVector=new Vector<MergeCells>();
            Vector<?> reportBlock = null;
            Vector<?> row=null;
            Boolean startOfLogicBlocks=false;
            Boolean endOfLogicBlocks=false;            
            for(k=0; k < collection.size() && !endOfLogicBlocks; k++){
                reportBlock = (Vector<?>) collection.get(k);              
                for (i=0; i < reportBlock.size(); i++){
                	row = (Vector<?>) reportBlock.get(i);
                	for(int j=0; j < row.size(); j++){
                		ExcelCell cell=(ExcelCell) row.get(j);
                		if(cell.getValue().equalsIgnoreCase("Logic Block"))
                			startOfLogicBlocks=true;
                		if(startOfLogicBlocks && row.size()==1){
                			 MergeCells mergeCell=new MergeCells();
                			 mergeCell.setBeginRow(i);
                			 mergeCell.setEndRow(i);
                			 mergeCell.setBegindColumn((short) 0);
                			 mergeCell.setEndColumn((short) 4);
                			 mergeVector.add(mergeCell);
                		}                		
                	}
                	if(row.size()==0 && startOfLogicBlocks){
                		endOfLogicBlocks=true;
                		startOfLogicBlocks=false;
                	}                		
                }
            }
            
            //End of code for spanning logic block name over 5 columns.
            
            
            
            
            //Merge the region for the sheets.
            if(mergeVector != null){
                MergeCells mergeCell = null;
                for(k = 0; k < mergeVector.size(); k++){
                    mergeCell = (MergeCells)mergeVector.get(k);
                    sheet.addMergedRegion(new org.apache.poi.hssf.util.Region(mergeCell.getBeginRow(), mergeCell.getBegindColumn(), mergeCell.getEndRow(),  mergeCell.getEndColumn()));
                    if(isSecondSheetAvailable){
                        sheet1.addMergedRegion(new org.apache.poi.hssf.util.Region(mergeCell.getBeginRow(), mergeCell.getBegindColumn(), mergeCell.getEndRow(),  mergeCell.getEndColumn()));
                    }
                }
            }
            
            //Write HSSFWorkbook to ByteArrayOutputStream.
            workbook.write(baos);
            baos.close();
        }
        catch(Exception e){
            throw e;
        }
        return baos;
    }
    
    
    /**
     * This is a private method to create a row in excel sheet
     * 
     * @param wb
     * @param sheet
     * @param fontstyle
     * @param cellStyle
     * @param tmp
     * @throws Exception
     */
    private void createRow(HSSFWorkbook workbook, HSSFSheet sheet, HSSFSheet sheet1, Vector<?> rowvec,int rowpos, HSSFCellStyle cellStyle, HSSFFont fontstyle, boolean flag) throws Exception 
    {
        try{
            HSSFRow row = null;            
            HSSFRow row1 = null;
            HSSFCell cell = null;
            ExcelCell xlcell = null;
            int j = 0;
            
            //Create row
            row = sheet.createRow((short)rowpos);
            if(sheet1 != null){
                row1 = sheet1.createRow((short)rowpos);
            }
            
            for(j = 0; j < rowvec.size(); j++){
                xlcell = (ExcelCell) rowvec.get(j);
                //case 1: Single sheet exists.
                //case 2: Double sheet for non-tabular data.
                //case 3: Double sheet for category header & data.
                //case 4: Double sheet for tabulat header.
                //flag is true for table data if col length lessthan 255.
                if(sheet1 == null){
                    createCell(workbook, sheet, row, xlcell, j, rowpos, cellStyle, fontstyle, cell);
                }else if(sheet1 != null && j <= 255 && !flag){                    
                    createCell(workbook, sheet, row, xlcell, j, rowpos, cellStyle, fontstyle, cell);
                    createCell(workbook, sheet1, row1, xlcell, j, rowpos, cellStyle, fontstyle, cell);
                }else  if(sheet1 != null && j <= 255 && flag){
                    //Table data begins.                    
                    createCell(workbook, sheet, row, xlcell, j, rowpos, cellStyle, fontstyle, cell);
                    //write table header for sheet1 also.
                    if(j == 0){                        
                        createCell(workbook, sheet1, row1, xlcell, j, rowpos, cellStyle, fontstyle, cell);
                    }
                }else{                    
                    createCell(workbook, sheet1, row1, xlcell, j%255, rowpos, cellStyle, fontstyle, cell);
                }
            }
        }
        catch(Exception e){
            throw e;
        }
        return;
    }
    
    /**
     * This is private method to create a cell
     * 
     * @param wb
     * @param sheet
     * @param row
     * @param xlcell
     * @param fontstyle
     * @param cellStyle
     * @param j
     * @throws Exception
     */
    @SuppressWarnings("deprecation")
	private void createCell(HSSFWorkbook workbook, HSSFSheet sheet, HSSFRow row, ExcelCell xlcell, int cellpos,int rowpos, HSSFCellStyle cellStyle, HSSFFont fontStyle, HSSFCell cell) throws Exception 
    {
        try{
            cell = row.createCell((short) cellpos);
            
            //1.Get the style if already exists
            //2.Else create the new one and return.
            if(cellStyleMap.get(xlcell.getCellStylePattern()) != null){
                cellStyle = (HSSFCellStyle)cellStyleMap.get(xlcell.getCellStylePattern());            
            }else{
            	//Create a cellStyle of type HSSFCellStyle

            	cellStyle = workbook.createCellStyle();
            	cellStyle.setWrapText(xlcell.isWrapText());
            	cellStyle.setAlignment((short)xlcell.getAlignment());

            	//Create a fontStyle of type HSSFFont
            	//Bug Fix 10726 : Start
            	//Desc : Unable to receive scheduled Summary data when excel format is selected while creating schedule for Campaign Summary Report 
            	if(xlcell.getCellStylePattern()!=null && !(xlcell.getCellStylePattern().equalsIgnoreCase(DATA_STYLE) || xlcell.getCellStylePattern().equalsIgnoreCase(PERCENT_DATA_STYLE))){
            		fontStyle = workbook.createFont();
            		fontStyle.setBoldweight((short)xlcell.getBoldweight());
            		fontStyle.setFontHeightInPoints(xlcell.getFontSize());
            		fontStyle.setUnderline(xlcell.getUnderLine());
            		cellStyle.setFont(fontStyle);
            	}
            	if(xlcell.getCellStylePattern()!=null &&  xlcell.getCellStylePattern().equalsIgnoreCase(PERCENT_DATA_STYLE)){
            		cellStyle.setDataFormat(workbook.createDataFormat().getFormat("0.00%"));
            	}
            	//Bug Fix 10726 : End
            	cellStyleMap.put(xlcell.getCellStylePattern(), cellStyle);

            }
            //Set cellStyle and encoding to cell of type HSSFCell
            cell.setCellStyle(cellStyle);
           // cell.setEncoding(HSSFCell.ENCODING_UTF_16);
            try{
                //Set the double/int value for cells having data.
               	cell.setCellValue(Double.parseDouble(xlcell.getValue()));
            }catch(Exception e){
                //Set the string value for cells having headers.
           		cell.setCellValue(new HSSFRichTextString(xlcell.getValue()));
            }
        }
        catch(Exception e){            
            throw e;
        }
        return;
    }
}

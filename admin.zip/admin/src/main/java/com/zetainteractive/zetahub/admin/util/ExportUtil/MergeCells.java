/**
 * @(#)MergeCells.java	 Created on Jan 18, 2007
 *
 * Copyright (c) 2005 OSI Technologies.
 * 253/A, Venkateshwara Colony, Road No. 12, Banjara Hills, Hyderabad,
 * A.P, 500 034, India.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of OSI
 * Technologies. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with OSI.
 */
package com.zetainteractive.zetahub.admin.util.ExportUtil;

/**
 * @author pragathi
 *
 * Entity for the merge cells
 */
public class MergeCells {
    
    int beginRow;
    short begindColumn;
    int endRow;
    short endColumn;
    
    /**
     * @return Returns the begindColumn.
     */
    public short getBegindColumn() {
        return begindColumn;
    }
    /**
     * @param begindColumn The begindColumn to set.
     */
    public void setBegindColumn(short begindColumn) {
        this.begindColumn = begindColumn;
    }
    /**
     * @return Returns the beginRow.
     */
    public int getBeginRow() {
        return beginRow;
    }
    /**
     * @param beginRow The beginRow to set.
     */
    public void setBeginRow(int beginRow) {
        this.beginRow = beginRow;
    }
    /**
     * @return Returns the endColumn.
     */
    public short getEndColumn() {
        return endColumn;
    }
    /**
     * @param endColumn The endColumn to set.
     */
    public void setEndColumn(short endColumn) {
        this.endColumn = endColumn;
    }
    /**
     * @return Returns the endRow.
     */
    public int getEndRow() {
        return endRow;
    }
    /**
     * @param endRow The endRow to set.
     */
    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }
}

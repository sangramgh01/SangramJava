package com.zetainteractive.zetahub.admin.util.encryptionutil;

import java.util.Map;

import com.zetainteractive.zetahub.admin.exception.AdminException;

public interface EncryptionUtil {
	public Map<String, String> generateKeys(String passphrase, int keySize, String custcode, String secretKeyFilePath,
			String publicKeyFilePath) throws AdminException;
}

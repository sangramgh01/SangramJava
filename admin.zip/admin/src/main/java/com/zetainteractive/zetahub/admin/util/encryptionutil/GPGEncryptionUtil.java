package com.zetainteractive.zetahub.admin.util.encryptionutil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

public class GPGEncryptionUtil implements EncryptionUtil {

	ZetaLogger logger = new ZetaLogger(getClass().getName());
	private String gpg_result;
	private int gpg_exitCode = -1;
	public String gpg_err;

	@Override
	public Map<String, String> generateKeys(String passphrase, int keySize, String custcode, String secretKeyFile,
			String publicKeyFile) throws AdminException {

		logger.debug("Begin GPG generateKeys");
		String optionsFile = null;
		String keyid = null;
		Boolean isResourceFile = true;

		try {
			// String createdirCmd = "mkdir -p "+System.getProperty("HOME") +
			// "/.gnupg";
			// String createdirCmd = "cmd.exe mkdir -p
			// "+System.getProperty("HOME") + "\\.gnupg";
			// logger.info("Execute " + createdirCmd);
			// Process p1 = Runtime.getRuntime().exec(createdirCmd);
			/**
			 * This code will replace the tags namely keysize,userid and
			 * passphrase in the GPGfileoptions file and generate the key using
			 * this file
			 */
			HashMap<String, Object> options = new HashMap<>();
			options.put("key_size", keySize + "");
			options.put("pass_phrase", passphrase);
			options.put("user_id", custcode);

			logger.debug("Read Resource file: /GPGfileoptions");
			String fileData = readFile("/GPGfileoptions", isResourceFile);

			Iterator optionsItr = options.keySet().iterator();
			String key = "";
			while (optionsItr.hasNext()) {
				key = optionsItr.next().toString();
				if (!fileData.contains("<<" + key + ">>")) {
					continue;
				}
				fileData = fileData.replace("<<" + key + ">>", options.get(key).toString().trim());
			}
			logger.debug("filedata:" + fileData);

			optionsFile = "/tmp/" + custcode + "/GPGfileoptions" + Math.random() + ".txt"; 
			String optionsPath = "/tmp/" + custcode;
			
			logger.debug("optionsFile: " + optionsFile);
			File path = new File(optionsPath);
			if (!path.isDirectory()) {
				path.mkdirs();
			}

			logger.debug("custcode::" + custcode);

			logger.debug("Writing into optionsfile");
			writeFile(fileData, optionsFile);

			// Generate the key
			String keyGenCmd = "gpg --batch --gen-key " + optionsFile;
			logger.debug("Executing" + keyGenCmd);
			Process p = Runtime.getRuntime().exec(keyGenCmd);
			logger.debug("Execution completed. Generated key!");
			int i = p.waitFor();
			if (i != 0) {
				logger.error("Execution returned value : " + i);
				throw new AdminException("EL1309", null, new Exception(keyGenCmd));
			}

			// Get the keyid
			logger.debug("Getting key id");
			keyid = getKeyIdFromRing(custcode);
			logger.info("keyid::" + keyid);

			// Delete if the public and private key files already exist
			logger.debug("Delete if the public and private key files already exist");
			File f;
			f = new File(secretKeyFile);
			if (f.exists()) {
				boolean isDeleted = f.delete();
				logger.debug(f + " isDeleted: " + isDeleted);
			}
			f = new File(publicKeyFile);
			if (f.exists()) {
				boolean isDeleted = f.delete();
				logger.debug(f + " isDeleted: " + isDeleted);
			}

			logger.info("publicKeyFile::" + publicKeyFile);
			
			File publicKeypath = new File(publicKeyFile.substring(0,publicKeyFile.lastIndexOf(File.separator)));
			if (!publicKeypath.isDirectory()) {
				publicKeypath.mkdirs();
			}

			// Export the public key
			String genPublickeyCmd = "gpg -a --output " + publicKeyFile + " --export " + keyid;
			logger.debug("Export PublickeyCommand::" + genPublickeyCmd);
			p = Runtime.getRuntime().exec(genPublickeyCmd);
			logger.debug("Executed: " + genPublickeyCmd);
			i = p.waitFor();
			if (i != 0) {
				logger.error("Command returned error code : " + i);
				throw new AdminException("EL1309", null, new Exception(genPublickeyCmd));
			}

			File secretKeypath = new File(secretKeyFile.substring(0,secretKeyFile.lastIndexOf(File.separator)));
			if (!secretKeypath.isDirectory()) {
				secretKeypath.mkdirs();
			}

			// Export the secret key
			String genSecretkeyfile = "gpg -a --output " + secretKeyFile + " --export-secret-key " + keyid;
			p = Runtime.getRuntime().exec(genSecretkeyfile);
			logger.debug("Executed " + genSecretkeyfile);
			i = p.waitFor();
			if (i != 0) {
				logger.error("Command returned error code : " + i);
				throw new AdminException("EL1309", null, new Exception(genSecretkeyfile));
			}

			isResourceFile = false;
			String publicKey = readFile(publicKeyFile, isResourceFile);
			String privateKey = readFile(secretKeyFile, isResourceFile);
			Map<String, String> keys = new HashMap<>();
			keys.put("privateKey", privateKey);
			keys.put("publicKey", publicKey);
			logger.info("!!!!!!End GPG generateKeys!!!!!!!!!!!");
			return keys;
		} catch (AdminException e) {
			logger.error("AdminException :" + e.getMessage(), e);
			throw e;
		} catch (InterruptedException e) {
			logger.error("Interrupted Exception : " + e.getMessage(), e);
			throw new AdminException("EL1309", null, e);
		} catch (IOException e) {
			logger.error("IOException : " + e.getMessage(), e);
			throw new AdminException("EL1310", null, e);
		} catch (Exception e) {
			logger.error("Exception : " +e.getMessage(), e);
			throw new AdminException("EL1311", null, e);
		} finally {
			try {
				if (optionsFile != null) {
					File f1 = new File(optionsFile);
					if (f1 != null) {
						f1.delete();
						f1 = null;
					}
				}
			} catch (Exception e1) {
				logger.error("WL1310", e1);
			}
		}

	}

	/**
	 * Reads the data from the file and returns the string
	 * 
	 * @param filename
	 * @param isResourceFile
	 * @return file string
	 * @throws AdminException
	 */
	private String readFile(String filename, boolean isResourceFile) throws AdminException {
		logger.info("Begin GPG readFile");
		logger.info("filename:" + filename); 
		String fileString = "";
		BufferedReader bReader;
		FileReader fReader = null;
		try {
			if (isResourceFile) {
				InputStream is = getClass().getResourceAsStream(filename);
				bReader = new BufferedReader(new InputStreamReader(is));
			} else {
				fReader = new FileReader(filename);
				bReader = new BufferedReader(fReader);
			}
			String line;
			while ((line = bReader.readLine()) != null) {
				fileString = fileString + line;
				fileString = fileString + "\n";
			}
			bReader.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new AdminException("EL1310", e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdminException("EL1311", e);
		}
		logger.info("End GPG readFile");
		return fileString;
	}

	/**
	 * Writes the String into the file specified.
	 * 
	 * @param fileData
	 * @param filename
	 * @throws AdminException
	 */
	private void writeFile(String fileData, String filename) throws AdminException {
		logger.info("Begin GPG writeFile");
		logger.info("filename:" + filename);
		try (FileWriter filewriter = new FileWriter(filename);
				BufferedWriter bWriter = new BufferedWriter(filewriter)) {
			bWriter.write(fileData);
			bWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
			throw new AdminException("EL1310", e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdminException("EL1311", e);
		}
		logger.info("End GPG writeFile");
	}

	/**
	 * This method is used to get the key if after generation of key and the
	 * keys are added in the key ring.
	 * 
	 * @param keysFile
	 * @param custcode
	 * @return
	 * @throws AdminException
	 */

	private String getKeyIdFromRing(String custcode) throws AdminException {
		logger.info("Begin: GPG getKeyIdFromRing(String custcode)");
		RandomAccessFile keyFile = null;
		String listKeysFile = null;
		try {
			listKeysFile = "/tmp/" + custcode + "/publickeys.txt";
			String getkeyslistCmd = "gpg --list-keys " + custcode;

			boolean success = runGnuPG(getkeyslistCmd, null, 'N');
			logger.info("success::" + success);
			logger.info("listKeysFile::" + listKeysFile);
			if (!success) {
				throw new AdminException("EL1314");
			}
			writeFile(gpg_result, listKeysFile);
			logger.info("written file data into " + listKeysFile);
			keyFile = new RandomAccessFile(listKeysFile, "rw");
			String line = "";
			String prevLine = "";
			String content = "";
			line = keyFile.readLine();
			logger.info("line: " + line);
			while (true) {
				if (line == null) {
					break;
				}
				if (line.contains(custcode)) {
					if (line.indexOf('/') > 0)
						content = line;
					else
						content = prevLine;
				} else {
					prevLine = line;
				}
				line = keyFile.readLine();
			}
			logger.info("Str$$$$::" + content);
			// get the last line which satisfies the condition
			// the last line will be as "pub EZAA1/AS78HS ----"
			// the code after the slash is the keyid
			if (content.length() > 0) {
				if (content.contains(custcode)) {
					logger.info("Str contains custcode");
					String[] str = content.split(" ");
					String substr = str[2].trim();
					substr = substr.substring(substr.indexOf('/') + 1, substr.length()).trim();
					return substr;
				} else {
					logger.info("Str does not contain custcode");
					String pubStr = content.substring(content.indexOf('/') + 1, content.length()).trim();
					String[] str = pubStr.split(" ");
					String substr = str[0];
					logger.info("pubStr::" + pubStr);
					logger.info("substr::" + substr);
					return substr;
				}
			}
		} catch (AdminException e) {
			throw e;
		} catch (IOException e) {
			throw new AdminException("EL1314", e);
		} catch (Exception e) {
			throw new AdminException("EL1319", e);
		} finally {
			try {
				if(keyFile!=null)
					keyFile.close();
				File f1 = new File(listKeysFile);
				f1.delete();
				f1 = null;
			} catch (Exception e1) {
				logger.warn("WL1310", e1);
			}
		}
		logger.info("End: GPG getKeyIdFromRing(String custcode)");
		return null;
	}

	/**
	 * Runs GnuPG external program
	 *
	 * @param commandArgs
	 *            command line arguments
	 * @param c
	 * @param inputStr
	 *            key ID of the key in GnuPG's key database
	 * @return true if success.
	 */
	private boolean runGnuPG(String fullCommand, String inputStr, char c) throws AdminException {
		logger.info("Begin: GPG runGnuPG()");
		Process p;
		logger.info(fullCommand);

		try {
			logger.debug("Executing " + fullCommand);
			p = Runtime.getRuntime().exec(fullCommand);
			logger.debug("Executing " + fullCommand + " completed");
		} catch (IOException io) {
			return false;
		}

		ProcessStreamReader psr_stdout = new ProcessStreamReader(p.getInputStream());
		ProcessStreamReader psr_stderr = new ProcessStreamReader(p.getErrorStream());
		logger.debug("starting processes");
		psr_stdout.start();
		psr_stderr.start();
		if (inputStr != null) {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
			try {
				if (c == 'E') {
					RandomAccessFile outFile = new RandomAccessFile(inputStr, "r");
					String line;
					while ((line = outFile.readLine()) != null) {
						out.write(line);
						out.write(10);
					}
					outFile.close();
				}
				if (c == 'D') {
					out.write(inputStr);
				}
				out.close();
			} catch (IOException io) {
				logger.error("Exception at write! " + io.getMessage(), io);
				return false;
			}
		}

		try {
			logger.debug("wait..");
			p.waitFor();
			logger.debug("After waiting done");
			psr_stdout.join();
			psr_stderr.join();
		} catch (InterruptedException i) {
			logger.error("Exception at waitfor! " + i.getMessage(), i);
			return false;
		}

		try {
			logger.info("Get exit code");
			gpg_exitCode = p.exitValue();
			logger.info("gpg_exitCode=" + gpg_exitCode);
			if (gpg_exitCode != 0) {
				String errorCode = "EL1346";
				if (gpg_exitCode == 2) {
					errorCode = "EL1349";
					logger.info("Invaid key");
				}
				gpg_err = psr_stderr.getString();

				if (gpg_err.contains("already in secret keyring")) {
					logger.info("gpg_err =" + gpg_err);
					return false;
				}
				throw new AdminException(errorCode, new Exception(fullCommand + gpg_err));
			}
		} catch (IllegalThreadStateException itse) {
			return false;
		}
		gpg_result = psr_stdout.getString();
		gpg_err = psr_stderr.getString();
		logger.info("gpr result:" + gpg_result);
		logger.info("gpr error:" + gpg_err);
		logger.info("End: GPG runGnuPG()");
		return true;
	}

	/**
	 * Reads an output stream from an external process. Implemented as a thread.
	 */
	class ProcessStreamReader extends Thread {
		StringBuffer stream;
		InputStreamReader in;

		static final int BUFFER_SIZE = 1024;

		/**
		 * Creates new ProcessStreamReader object.
		 * 
		 * @param in
		 */
		ProcessStreamReader(InputStream in) {
			super();
			this.in = new InputStreamReader(in);
			this.stream = new StringBuffer();
		}

		@Override
		public void run() {
			try {
				int read;
				char[] c = new char[BUFFER_SIZE];
				logger.info("reading from stream");
				while ((read = in.read(c, 0, BUFFER_SIZE - 1)) > 0) {
					stream.append(c, 0, read);
					if (read < 4)
						break;
				}
				logger.debug("Read stream  : " + stream.toString());
			} catch (IOException io) {
				logger.error("Exception at read! " + io.getMessage(), io);
			}
		}

		String getString() {
			return stream.toString();
		}
	}

	public static void main(String[] args) throws Exception {
		System.setProperty("HOME", "D:\\temp\\keys");
		GPGEncryptionUtil util = new GPGEncryptionUtil();
		System.out.println("Start main");
		try {
			/*
			 * util.generateKeys("passcode",1024,"C710",
			 * "D:/keys/privatekey.txt", "D:/keys/publickey.txt");
			 */
			util.generateKeys("passcode", 1024, "C710", "D:\\temp\\keys\\privatekey.txt", "D:\\temp\\keys\\publickey.txt");
		} catch (AdminException e) {
			e.printStackTrace();
			System.out.println("admin exception in  main");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception in  main");
		}
		System.out.println("End main");
	}
}

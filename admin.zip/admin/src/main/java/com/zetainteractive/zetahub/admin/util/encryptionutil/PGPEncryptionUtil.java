package com.zetainteractive.zetahub.admin.util.encryptionutil;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.operator.PBESecretKeyEncryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPDigestCalculatorProviderBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPKeyPair;
import org.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyEncryptorBuilder;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

public class PGPEncryptionUtil implements EncryptionUtil {

	ZetaLogger logger = new ZetaLogger(getClass().getName());

	/**
	 * This method is used to create a key provided the keysize and the
	 * passphrase. With these parameters the method creates a secret key and the
	 * public key using DSA algorithm
	 * @param passphrase
	 * @param keySize
	 * @param custcode
	 * @param secretKeyFilePath
	 * @param publicKeyFilePath
	 * @returns Map of public and private keys
	 * @throws AdminException
	 * 
	 */
	@Override
	public Map<String, String> generateKeys(String passphrase, int keySize, String custcode, String secretKeyFilePath,
			String publicKeyFilePath) throws AdminException {
		Map<String, String> keys = new HashMap<>();
		logger.info("Begin pgp generateKeys");
		FileOutputStream secretKeyOutputStream = null;
		FileOutputStream publicKeyOutputStream = null;
		try {
			String identity = custcode;
			logger.info("Add BouncyCastleProvider privider");
			Security.addProvider(new BouncyCastleProvider());

			logger.info("Get keypairgenerator instance");
			KeyPairGenerator dsaKpg = KeyPairGenerator.getInstance("DSA", "BC");

			logger.info("initialize dsaKpg");
			dsaKpg.initialize(keySize);
			
			// It takes a while as the key generator has to generate some DSA
			// params  before it generates the key.
			logger.info("Generate KeyPair");
			KeyPair dsaKp = dsaKpg.generateKeyPair();

			logger.info("Get ELGAMAL KeyPairGenerator instance");
			KeyPairGenerator elgKpg = KeyPairGenerator.getInstance("ELGAMAL", "BC");
			BigInteger g = new BigInteger(
					"153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc",
					16);
			BigInteger p = new BigInteger(
					"9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b",
					16);

			ElGamalParameterSpec elParams = new ElGamalParameterSpec(p, g);

			elgKpg.initialize(elParams);
			// This is quicker because we are using pre-generated parameters.
			KeyPair elgKp = elgKpg.generateKeyPair();
			logger.info("Generated elgkp:");

			logger.info("private key file path:" + secretKeyFilePath);
			logger.info("public key file path:" + publicKeyFilePath);
			logger.info("Instantiate secretKeyOutputStream");
			secretKeyOutputStream = new FileOutputStream(secretKeyFilePath);
			logger.info("Instantiate publicKeyOutputStream");
			publicKeyOutputStream = new FileOutputStream(publicKeyFilePath);
			logger.info("exportKeyPair");
			exportKeyPair(secretKeyOutputStream, publicKeyOutputStream, dsaKp, elgKp, identity,
					passphrase.toCharArray(), true);
			logger.info("Get publicKey");
			String publicKey = readFile(publicKeyFilePath);
			logger.info("Get privateKey");
			String privateKey = readFile(secretKeyFilePath);
			keys.put("publicKey", publicKey);
			keys.put("privateKey", privateKey);
		}catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidAlgorithmParameterException e) {
			logger.error("InvalidAlgorithmParameterException");
			e.printStackTrace();
			throw new AdminException("EL1300", e);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new AdminException("EL1301", e);
		} catch (AdminException e) {
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdminException("F00002", e);
		} finally{
			try {
				if(secretKeyOutputStream!=null)
					secretKeyOutputStream.close();
				if(publicKeyOutputStream!=null)
					publicKeyOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
				logger.error("Exception while closing output streams");
				throw new AdminException("EL1301",e);
			}
			
		}
		logger.info("!!!!!!!!End pgp generateKeys!!!!!!!!!!!!");
		return keys;
	}

	/**
	 * This method is used to generate the key pair (Public and private)
	 * 
	 * @param secretOut
	 *            this is the outputsream for secret key
	 * @param publicOut
	 *            this is the output stream for public key
	 * @param dsaKp
	 * @param elgKp
	 * @param identity
	 *            generally is the userid
	 * @param passPhrase
	 *            is the password with which we generate a unique key
	 * @param armor
	 *            this is to specify if we need an ascii format data
	 * @throws AdminException
	 */
	private void exportKeyPair(OutputStream secretOut, OutputStream publicOut, KeyPair dsaKp, KeyPair elgKp,
			String identity, char[] passPhrase, boolean armor) throws AdminException {
		logger.debug("Begin:exportKeyPair");
		try {
			if (armor) {
				secretOut = new ArmoredOutputStream(secretOut);
				logger.debug("instantiated ArmoredOutputStream");
			}

			logger.debug("Generating PGPKeyPair");
			PGPKeyPair        dsaKeyPair = new JcaPGPKeyPair(PGPPublicKey.DSA, dsaKp, new Date());
		    PGPKeyPair        elgKeyPair = new JcaPGPKeyPair(PGPPublicKey.ELGAMAL_ENCRYPT, elgKp, new Date());
		    logger.info("Generated PGPKeyPair");
		    PGPDigestCalculator sha1Calc = new JcaPGPDigestCalculatorProviderBuilder().build().get(HashAlgorithmTags.SHA1);
		    JcaPGPContentSignerBuilder builder = new JcaPGPContentSignerBuilder(dsaKeyPair.getPublicKey().getAlgorithm(), HashAlgorithmTags.SHA1);
		    PBESecretKeyEncryptor secretKeyEncBuilder = new JcePBESecretKeyEncryptorBuilder(PGPEncryptedData.AES_256, sha1Calc).setProvider("BC").build(passPhrase);
		    logger.info("Instantiating PGPKeyRingGenerator");
		    PGPKeyRingGenerator    keyRingGen = new PGPKeyRingGenerator(PGPSignature.POSITIVE_CERTIFICATION, dsaKeyPair,
		             identity, sha1Calc, null, null, builder, secretKeyEncBuilder);
		    logger.debug("adding SubKey");
		    keyRingGen.addSubKey(elgKeyPair);
		    
		    keyRingGen.generateSecretKeyRing().encode(secretOut);
		    
		    if (armor)
		    {
		        publicOut = new ArmoredOutputStream(publicOut);
		    }
		    
		    keyRingGen.generatePublicKeyRing().encode(publicOut);
		    	
		} catch (PGPException e) {
			logger.error("PGPException: " + e.getMessage(), e);
			throw new AdminException("EL1300", e);
		} catch (IOException e) {
			logger.error("IOException : " + e.getMessage(), e);
			throw new AdminException("EL1301", e);
		} catch (Exception e) {
			logger.error("Exception while generating keys:" + e.getMessage(), e);
			throw new AdminException("F00002", e);
		} finally{
			 try {
				 secretOut.close();
				 publicOut.close();
			} catch (IOException e) {
				logger.error("Exception while closing output streams :" + e.getMessage(), e);
				throw new AdminException("EL1301",e);
			}
		}
	}

	/**
	 * Reads the data from the file and returns the string
	 * @param filename
	 * @return file string
	 * @throws AdminException
	 * 
	 */
	private String readFile(String filename) throws AdminException {
		logger.info("Begin read file" + filename);
		String fileString = "";
		try (FileReader fReader = new FileReader(filename); BufferedReader bReader = new BufferedReader(fReader)) {
			String line;
			while ((line = bReader.readLine()) != null) {
				fileString = fileString + line;
				fileString = fileString + "\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new AdminException("EL1310", e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdminException("EL1311", e);
		}
		logger.info("End read file" + filename);
		return fileString;
	}
	/**
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception{
		PGPEncryptionUtil util = new PGPEncryptionUtil();
		//util.generateKeys("passcode",768,"userid",ZetaUtil.getHelper().getConfig().getConfigValueString("ADMIN_ENCRYPTION_PRIVATE_KEY_FILE", null), ZetaUtil.getHelper().getConfig().getConfigValueString("ADMIN_ENCRYPTION_PUBLIC_KEY_FILE", null));
		util.generateKeys("passcode",768,"userid","D:/temp/keys/privatekey.txt", "D:/temp/keys/publickey.txt");
		System.out.println("End");
	}
}

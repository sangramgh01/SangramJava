package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
@Component
public class DbSourceValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports 
	 * Description : The Method "supports" is used for
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return DbSourceBO.class.equals(clazz);

	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 29, 2016, 5:02:02 PM
	 * 
	 * @param target
	 * @param errors
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		DbSourceBO dbSource = (DbSourceBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dbSourceName",
				messageSource.getMessage("ACF004", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hostname",
				messageSource.getMessage("ACF005", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "port",
				messageSource.getMessage("ACF0024", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username",
				messageSource.getMessage("ACF0025", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password",
				messageSource.getMessage("ACF0026", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dbvendor",
				messageSource.getMessage("ACF0029", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "schemaName",
				messageSource.getMessage("ACF0032", new Object[] {}, LocaleContextHolder.getLocale()));
		}

}


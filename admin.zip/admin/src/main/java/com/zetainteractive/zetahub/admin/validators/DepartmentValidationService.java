package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;

/**
 * Validates the request inputs and places corresponding exceptions
 */
@Component
public class DepartmentValidationService {
	
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	MessageSource messageSource;
	
	/**
	 * @param departmentID
	 * @param bindingResult
	 */
	public void checkDepartmentId(Long departmentID,BindingResult bindingResult){
		if(departmentID!=null && departmentID>0){
			Boolean exists=departmentService.isDepartmentExists(departmentID,bindingResult);
			if(!exists && bindingResult.hasErrors()==Boolean.FALSE)
				bindingResult.reject(messageSource.getMessage("ADM006", new Object[]{departmentID},LocaleContextHolder.getLocale()),"Invalid DepartmentID Specified.");
		}
		else
			bindingResult.reject(messageSource.getMessage("ADM005", new Object[]{departmentID},LocaleContextHolder.getLocale()),"Invalid DepartmentID Specified.");
	}
	
	/**
	 * @param key
	 * @param bindingResult
	 */
	public void validateDepartmentPropertyKey(String key,BindingResult bindingResult){
		if(key == null || key.trim().length() == 0){
			bindingResult.reject(messageSource.getMessage("ADM015", new Object[]{key},LocaleContextHolder.getLocale()),"Please enter valid property key.");
			return;
		}
		if(!key.equalsIgnoreCase(Constants.DEPARTMENT_PARAMETERS_KEY) && 
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_ADDRESSLIST_KEY) && 
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_UNSUBRULES_KEY) && 
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_NOTIFICATIONS_KEY) &&
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_GOOGLEANALYTICS_KEY) &&
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_ADOBEANALYTICS_KEY) &&
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_MOBILE_KEY) &&
		   !key.equalsIgnoreCase(Constants.DEPARTMENT_OTHERWEBANALYTICS_KEY))
			bindingResult.reject(messageSource.getMessage("ADM015", new Object[]{key},LocaleContextHolder.getLocale()),"Please enter valid property key.");
	}
	
	/**
	 * @param departmentName
	 * @param approvalNeeded
	 * @param domainKeysNeeded
	 * @param bindingResult
	 * @throws AdminException 
	 */
	public void checkDepartmentProperties(String departmentName,BindingResult bindingResult) throws AdminException{
		Boolean exists=departmentService.departmentNameExists(departmentName,bindingResult);
		if(!bindingResult.hasErrors() && exists)
			bindingResult.reject(messageSource.getMessage("ADM016",new Object[]{departmentName},LocaleContextHolder.getLocale()),"Unable to create department.");
	}
}

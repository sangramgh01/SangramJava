package com.zetainteractive.zetahub.admin.validators;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;

/**
 * Validate DepartmentBO
 * @author Lakshmi.Medarametla
 */
@Component
public class DepartmentValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return DepartmentBO.class.equals(clazz);
	}

	/* (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object target, Errors errors) {
		
	}

}

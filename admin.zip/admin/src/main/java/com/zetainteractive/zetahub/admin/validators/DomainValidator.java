package com.zetainteractive.zetahub.admin.validators;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.DomainBO;
@Component
public class DomainValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports 
	 * Description : The Method "supports" is used for
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return DomainBO.class.equals(clazz);

	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 29, 2016, 5:02:02 PM
	 * 
	 * @param target
	 * @param errors
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		DomainBO domain = (DomainBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "code",
				messageSource.getMessage("ACF007", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pattern",
				messageSource.getMessage("ACF0030", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description",
				messageSource.getMessage("ACF0031", new Object[] {}, LocaleContextHolder.getLocale()));

		if (domain.getCode() != null && domain.getCode().length() > 4) {
			messageSource.getMessage("ACF008", new Object[] {}, LocaleContextHolder.getLocale());
		}
		// Acepting characters and numbers
		/*if (!NumberUtils.isNumber(domain.getCode())) {
			errors.rejectValue("code",
					messageSource.getMessage("ACF0014", new Object[] {}, LocaleContextHolder.getLocale()));
		}*/
	}

}




package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
@Component
public class EncryptionKeyValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports 
	 * Description : The Method "supports" is used for
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return EncryptionKeyBO.class.equals(clazz);

	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 29, 2016, 5:02:02 PM
	 * 
	 * @param target
	 * @param errors
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		EncryptionKeyBO encryptionKey = (EncryptionKeyBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "encryptionKeyName",
				messageSource.getMessage("ACF009", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "encryptionType",
				messageSource.getMessage("ACF009", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passphrase",
				messageSource.getMessage("ACF009", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "registrationtype",
				messageSource.getMessage("ACF009", new Object[] {}, LocaleContextHolder.getLocale()));

		if (!(encryptionKey.getEncryptionType().equalsIgnoreCase(Constants.PGP)
				|| encryptionKey.getEncryptionType().equalsIgnoreCase(Constants.GPG))) {
			errors.rejectValue("encryptionType",
					messageSource.getMessage("WD0016", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		if (!(encryptionKey.getRegistrationtype() == Constants.GENARATE
				|| encryptionKey.getRegistrationtype() == Constants.UPLOAD)) {
			errors.rejectValue("registrationtype",
					messageSource.getMessage("WD0017", new Object[] {}, LocaleContextHolder.getLocale()));

		}
	}

}

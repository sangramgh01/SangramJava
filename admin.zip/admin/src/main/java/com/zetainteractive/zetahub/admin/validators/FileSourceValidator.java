package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.admin.constants.Constants;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
@Component
public class FileSourceValidator  implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports 
	 * Description : The Method "supports" is used for
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return FileSourceBO.class.equals(clazz);

	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 29, 2016, 5:02:02 PM
	 * 
	 * @param target
	 * @param errors
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		FileSourceBO fileSource = (FileSourceBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fileSourceName",
				messageSource.getMessage("ACF006", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hostname",
				messageSource.getMessage("ACF005", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "protocol",
				messageSource.getMessage("ACF0027", new Object[] {}, LocaleContextHolder.getLocale()));
		if(!Constants.HTTP_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())&&
		   !Constants.HTTPS_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())){
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "port",
					messageSource.getMessage("ACF0024", new Object[] {}, LocaleContextHolder.getLocale()));
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username",
					messageSource.getMessage("ACF0025", new Object[] {}, LocaleContextHolder.getLocale()));
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password",
					messageSource.getMessage("ACF0026", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		if(!Constants.HTTP_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())&&
		   !Constants.HTTPS_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())&&
		   !Constants.FTP_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())&&
		   !Constants.SFTP_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())&&
		   !Constants.SCP_PROTOCOL.equalsIgnoreCase(fileSource.getProtocol())){
			errors.rejectValue("protocol",
					messageSource.getMessage("ACF0028", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		
	}

}



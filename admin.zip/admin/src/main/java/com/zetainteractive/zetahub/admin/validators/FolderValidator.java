/**
 * FolderValidator.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.commons.domain.FolderBO;

/**
 * 
 * @Author : Srinivasa.Katta
 * @Created On : Jul 29, 2016 2:52:05 PM
 * @Version : 1.7
 * @Description : "FolderValidator" is used for folder validations
 * 
 **/
@Component
public class FolderValidator implements Validator {

	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * Method Name : supports Description : The Method "supports" is used for
	 * Date : Jul 29, 2016, 2:54:28 PM
	 * 
	 * @param clazz
	 * @return
	 * @param :
	 * @return :
	 * @throws :
	 */

	@Override
	public boolean supports(Class<?> clazz) {
		return FolderBO.class.equals(clazz);
	}

	/**
	 * 
	 * Method Name : validate Description : The Method "validate" is used for
	 * Date : Jul 29, 2016, 2:54:28 PM
	 * 
	 * @param target
	 * @param errors
	 * @return :
	 * @throws :
	 */

	@Override
	public void validate(Object target, Errors errors) {
		FolderBO folderBO = (FolderBO) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "foldername",
				messageSource.getMessage("ADM024", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type",
				messageSource.getMessage("ADM025", new Object[] {}, LocaleContextHolder.getLocale()));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "departmentid",
				messageSource.getMessage("ADM005", new Object[] {}, LocaleContextHolder.getLocale()));
		if (folderBO.getType() != 'A' && folderBO.getType() != 'R') {
			errors.rejectValue("type",
					messageSource.getMessage("ADM026", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		if (folderBO.getFoldername().equalsIgnoreCase("TRASH")) {
			errors.rejectValue("type",
					messageSource.getMessage("ADM027", new Object[] {}, LocaleContextHolder.getLocale()));
		}
		if(folderBO.getFolderid()==null){
			folderBO.setFolderid(0L);
		}
		if(folderBO.getFolderid()<0){
			errors.rejectValue("folderid",
					messageSource.getMessage("ADM112", new Object[]{folderBO.getFolderid()}, LocaleContextHolder.getLocale()));
		}
	}

}

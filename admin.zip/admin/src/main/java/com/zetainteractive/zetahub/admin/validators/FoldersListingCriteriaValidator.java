package com.zetainteractive.zetahub.admin.validators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria;

/**
 * Validate list criteria
 * @author Lakshmi.Medarametla
 */
@Component
public class FoldersListingCriteriaValidator implements Validator{

	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	MessageSource messageSource;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return FoldersListingCriteria.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		FoldersListingCriteria listingCriteria=(FoldersListingCriteria)target;
		
		if(listingCriteria.getType() == null)
			listingCriteria.setType('A');
		if (listingCriteria.getType() != 'A' && listingCriteria.getType() != 'R')
			errors.rejectValue("type",messageSource.getMessage("ADM033",new Object[]{listingCriteria.getType()},LocaleContextHolder.getLocale()),"Invalid folder type specified.");
		
		Boolean exists=departmentService.isDepartmentExists(listingCriteria.getDepartmentId(),errors);
		if(!exists && errors.hasErrors()==Boolean.FALSE)
			errors.reject(messageSource.getMessage("ADM006", new Object[]{listingCriteria.getDepartmentId()},LocaleContextHolder.getLocale()),"Invalid DepartmentID Specified.");
		
	}

}

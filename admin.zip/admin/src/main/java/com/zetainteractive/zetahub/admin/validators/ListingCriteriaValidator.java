package com.zetainteractive.zetahub.admin.validators;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;

/**
 * Validate list criteria
 * @author Lakshmi.Medarametla
 */
@Component
public class ListingCriteriaValidator implements Validator{

	@Autowired
	MessageSource messageSource;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return ListingCriteria.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ListingCriteria listingCriteria=(ListingCriteria)target;
		List<String> columnNames=listingCriteria.getColumnNames();
		
		if(listingCriteria.getSortUsing()==null)
			listingCriteria.setSortUsing(columnNames.get(0));
		if(!columnNames.contains(listingCriteria.getSortUsing().toLowerCase()))
			errors.rejectValue("sortUsing",messageSource.getMessage("ADM001",new Object[]{listingCriteria.getSortUsing()},LocaleContextHolder.getLocale()),"Invalid column name specified.");
		else
			listingCriteria.setSortUsing(listingCriteria.getSortUsing().toLowerCase());

		List<String> sortByAscendingValues = Arrays.asList("asc","ascending");
		List<String> sortByDescendingValues = Arrays.asList("desc","descending");
		if(listingCriteria.getSortBy()==null)
			listingCriteria.setSortBy("asc");
		if(sortByAscendingValues.contains(listingCriteria.getSortBy().toLowerCase()))
			listingCriteria.setSortBy("asc");
		else if(sortByDescendingValues.contains(listingCriteria.getSortBy().toLowerCase()))
			listingCriteria.setSortBy("desc");
		else
			errors.rejectValue("sortBy",messageSource.getMessage("ADM002",new Object[]{listingCriteria.getSortBy()},LocaleContextHolder.getLocale()),"Invalid sort order specified.");

		if(listingCriteria.getNameLike()==null)
			listingCriteria.setNameLike("");
		/*My SQL Wild Card Characters in Like Operator*/
		listingCriteria.setNameLike(listingCriteria.getNameLike().replaceAll("_","\\\\_"));
		listingCriteria.setNameLike(listingCriteria.getNameLike().replaceAll("%","\\\\%"));

		if(listingCriteria.getPageNumber()==null)
				listingCriteria.setPageNumber(1L);
		else if(listingCriteria.getPageNumber()<=0)
				errors.rejectValue("pageNumber",messageSource.getMessage("ADM003", new Object[]{listingCriteria.getPageNumber()},LocaleContextHolder.getLocale()),"Invalid page number specified.");

		if(listingCriteria.getPageSize()==null)
				listingCriteria.setPageSize(Long.MAX_VALUE);
		else if(listingCriteria.getPageSize()<=0)
				errors.rejectValue("pageSize",messageSource.getMessage("ADM004", new Object[]{listingCriteria.getPageSize()},LocaleContextHolder.getLocale()),"Invalid page size specified.");
	}

}

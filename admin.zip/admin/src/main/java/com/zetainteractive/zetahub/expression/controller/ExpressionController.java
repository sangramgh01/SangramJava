package com.zetainteractive.zetahub.expression.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zetainteractive.expressions.Expressions;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ExpressionBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.expression.exception.ExpressionException;
import com.zetainteractive.zetahub.expression.service.ExpressionService;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @author Venkata.Tummala
 *
 */
@RestController
@RequestMapping("/expression")
public class ExpressionController {
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	MessageSource messageSource;
	@Autowired
	ExpressionService expressionService;
	
	private static final String DEFAULT_MESSAGE="Invalid Data";
	
	private static final String EXPRESSION="expression";
	/**
	 * @param expressionsBO
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/saveExpression",method=RequestMethod.POST)
	public ResponseEntity<?> saveExpression(@RequestBody ExpressionBO expressionsBO,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.EXPRESSION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("EXPRESSIONID", expressionsBO.getExpressionID()==null?0:expressionsBO.getExpressionID());}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ExpressionBO expressionBO=expressionService.saveExpression(expressionsBO,bindingResult);
		ResponseObject resp=new ResponseObject();
		if (bindingResult.hasErrors()) {
			resp.addErrors(bindingResult, DEFAULT_MESSAGE);
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}else
			return new ResponseEntity<>(expressionBO,HttpStatus.OK);
	}
	
	/*
	 * method for fetching all expressions bases on a search criteria
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/getAllExpressions", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllExpressions(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.EXPRESSION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("EXPRESSIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<HashMap<String, Object>>(expressionService.getAllExpressions(searchCriteria),HttpStatus.OK);
		} catch (ExpressionException e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			resp.addError("Failed to get all the expressions", messageSource.getMessage(e.getErrorCode(), new Object[] { e.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
			}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/validateExpression", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> validateExpression(@RequestParam("expression") String expression,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.EXPRESSION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("EXPRESSIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:ExpressionController class ::validateExpression() ::"+expression);
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Expressions exp =null;
		try {
			exp = new Expressions();
            boolean isValid = exp.isValidExpression(expression);
            if(!isValid){
            	ResponseObject resp = new ResponseObject();
    			resp.addError("expression","Invalid expression </br>"+exp.getErrorMessage());
    			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            else{
            	if(expression.startsWith("number_format")){
            		expressionService.validateNumberFormat(expression);
            	}
            	return new ResponseEntity<JSONObject>(new ObjectMapper().readValue("{\"response\":"+isValid+"}", JSONObject.class),HttpStatus.OK);
            }
		}  catch (com.zetainteractive.expressions.SyntaxError e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			resp.addError("expression",exp.getErrorMessage());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if(expression.startsWith("number_format") && e instanceof ExpressionException){
				resp.addError("expression","Invalid number format");
			}else
			resp.addError("expression","Exception in Expression validation");
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getExpressionByName"+ "/{expressionName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getExpressionByName(@PathVariable String expressionName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.EXPRESSION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("EXPRESSIONID", expressionName);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:ExpressionController class ::getExpressionByName() ::"+expressionName);
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ExpressionBO expressionBO =null;
		try {
			expressionBO = expressionService.getExpressionByName(expressionName);
			
		}catch (ExpressionException e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			resp.addError("Failed to get expression", messageSource.getMessage(e.getErrorCode(), new Object[] { e.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<ExpressionBO>(expressionBO,HttpStatus.OK);
	}
	
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteExpression"+ "/{expressionId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> deleteExpression(@PathVariable Long expressionId,@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.EXPRESSION.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("EXPRESSIONID", expressionId);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:ExpressionController class ::deleteExpression() ::"+expressionId);
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Boolean isDelete =false;
		try {
			isDelete = expressionService.deleteExpression(expressionId);
		}catch(HttpClientErrorException e){
			JSONObject obj = new ObjectMapper().readValue(((HttpClientErrorException)e).getResponseBodyAsString(), JSONObject.class);
			return new ResponseEntity<JSONObject>(obj,HttpStatus.BAD_REQUEST);
		}
		catch (ExpressionException e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			resp.addError("Failed to get expression", messageSource.getMessage(e.getErrorCode(), new Object[] { e.getObject()[0] },
						LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<>(isDelete,HttpStatus.OK);
	}
	/**
	 * 
	 * 
	 * Method Name 	: getListOfExpressionsByNames
	 * Description 	: The Method "getListOfExpressionsByNames" is used for getting list of expressions based on list of Names 
	 * Date    		: 8 Jan 2018, 14:34:29
	 * @param names
	 * @param headers
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/getListOfExpressionsByNames")
	public ResponseEntity<?> getListOfExpressionsByNames(@RequestBody Set<String> names,@RequestHeader HttpHeaders headers){
		logger.debug("Begin :: "+getClass().getName()+" :: getListOfExpressionsByNames(@RequestBody List<String> Names) ");
		if (!AuthorizationUtil.authorize(headers, EXPRESSION, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ","Unauthorized");
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<>(expressionService.getListOfExpressionsByNames(names),HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			ResponseObject resp = new ResponseObject();
			resp.addError("Failed to get expression",e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	
	}
	
}

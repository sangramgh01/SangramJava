package com.zetainteractive.zetahub.expression.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zetainteractive.zetahub.commons.domain.ExpressionBO;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface ExpressionDao extends Serializable
{
	public ExpressionBO saveExpression(ExpressionBO expressionBO) throws Exception;
	public HashMap<String,Object> getAllExpressions(Map<String,String> searchCriteria) throws Exception;
	public ExpressionBO getExpressionByName(String expressionName) throws Exception;
	public Boolean deleteExpression(Long expressionId) throws Exception;
	/**
	 * 
	 * 
	 * Method Name 	: getListOfExpressionsByNames
	 * Description 	: The Method "getListOfExpressionsByNames" is used for 
	 * Date    		: 8 Jan 2018, 14:37:23
	 * @param names
	 * @return
	 * @param  		:
	 * @return 		: Set<ExpressionBO>
	 * @throws 		:
	 */
	public List<ExpressionBO> getListOfExpressionsByNames(Set<String> names);
	public boolean validateNumberFormat(String format) throws Exception;

}
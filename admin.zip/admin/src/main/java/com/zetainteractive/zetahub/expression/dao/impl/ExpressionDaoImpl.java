/**
 * DataTransformsDaoImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/
package com.zetainteractive.zetahub.expression.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.ExpressionBO;
import com.zetainteractive.zetahub.expression.dao.ExpressionDao;
/**
 * ExpressionDao
 * @author Venkata.Tummala
 *
 */
@Repository
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class ExpressionDaoImpl implements ExpressionDao {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/** The logger. */
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate template;
	
	@Autowired
	@Qualifier("whJdbc")
	private JdbcTemplate whJdbcTemplate;
	
	@Autowired
	MessageSource messageSource;

	@Override
	public ExpressionBO saveExpression(ExpressionBO expressionBO) throws Exception {
		logger.debug("Begin : saveExpression()");
		ObjectMapper mapper = new ObjectMapper();
		String inputParams =  mapper.writeValueAsString(expressionBO.getInputParams());
		String returnvalue =  mapper.writeValueAsString(expressionBO.getReturnvalue());
		if (expressionBO.getExpressionID() == null || expressionBO.getExpressionID() ==0) {
			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(
							"insert into ADM_EXPRESSION(departmentid,name,expressiontype,returnvalue,status,inputparams,expressiondsl,description,createdby,createdate,updatedate) values(?,?,?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp())",
							Statement.RETURN_GENERATED_KEYS);
					ps.setLong(1, expressionBO.getDepartmentID());
					ps.setString(2, expressionBO.getName());
					ps.setString(3, expressionBO.getExpressionType().toString());
					ps.setString(4, returnvalue);
					ps.setString(5,expressionBO.getStatus().toString());
					ps.setString(6,inputParams);
					ps.setString(7, expressionBO.getExpressionDSL());
					ps.setString(8, expressionBO.getDescription());
					ps.setString(9, expressionBO.getCreatedBy());
					return ps;
				}
			}, keyHolder);
			expressionBO.setExpressionID(keyHolder.getKey().longValue());
		} else {
			StringBuilder queryBuilder = new StringBuilder();
			List<Object> params = new ArrayList<>();
			queryBuilder.append("update ADM_EXPRESSION set ");
			if (expressionBO.getName() != null) {
				params.add(expressionBO.getName());
				queryBuilder.append("name=?,");
			}
			if (expressionBO.getStatus() != null) {
				params.add(expressionBO.getStatus().toString());
				queryBuilder.append("status=?,");
			}
			if (expressionBO.getDepartmentID() != null) {
				params.add(expressionBO.getDepartmentID());
				queryBuilder.append("departmentid=?,");
			}
			if (expressionBO.getExpressionType()!= null) {
				params.add(expressionBO.getExpressionType().toString());
				queryBuilder.append("expressiontype=?,");
			}
			if (expressionBO.getReturnvalue()!= null) {
				params.add(returnvalue);
				queryBuilder.append("returnvalue=?,");
			}
			if (expressionBO.getInputParams()!= null) {
				params.add(inputParams);
				queryBuilder.append("inputparams=?,");
			}
			if (expressionBO.getExpressionDSL()!= null) {
				params.add(expressionBO.getExpressionDSL());
				queryBuilder.append("expressiondsl=?,");
			}
			if (expressionBO.getDescription() != null) {
				params.add(expressionBO.getDescription());
				queryBuilder.append("description=?,");
			}
			if (expressionBO.getUpdateDate() != null) {
				params.add(expressionBO.getUpdateDate());
				queryBuilder.append("updatedate=?,");
			}

			if (expressionBO.getUpdatedBy() != null) {
				params.add(expressionBO.getUpdatedBy());
				queryBuilder.append("updatedby=?,");
			}
			String finalQuery = queryBuilder.toString().substring(0, queryBuilder.toString().length()-1) + " where expressionid = ?";
			params.add(expressionBO.getExpressionID());
			template.update(finalQuery,params.toArray());
		}
		logger.debug("End : saveExpression()");
		return expressionBO;

	}
	private Object[] prepareSearchCriteria(Map<String, String> map) throws Exception {
		Integer pageno = null;
		Integer pagesize = null;
		String search = "";
		String sortby = "expressionid";
		String sortorder = "ASC";
		Object[] output = new Object[5];
		if (map != null && !map.isEmpty()) {
			if (map.get("sortby") != null && (map.get("sortby").equalsIgnoreCase("createdate") || map.get("sortby").equalsIgnoreCase("name") || map.get("sortby").equalsIgnoreCase("createdby"))) {
				sortby = map.get("sortby").toString();
			}else{
				sortby = "createdate";
			}
			if (map.get("sortorder") != null && (map.get("sortorder").equalsIgnoreCase("ASC") || map.get("sortorder").equalsIgnoreCase("DESC"))) {
				sortorder = map.get("sortorder");
			}else{
				sortorder = "DESC";
			}
			if (map.get("pageno") != null) {
				pageno = new Integer(map.get("pageno").toString());
			}
			if (map.get("pagesize") != null) {
				pagesize = new Integer(map.get("pagesize").toString());
			}
			String createdFromDate = "";
			String createdToDate = "";
			String updatedFromdate = "";
			String updatedTodate = "";
			if (map != null && !map.isEmpty()) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					String key = entry.getKey().trim();
					String value = entry.getValue().trim();
					if (key.equalsIgnoreCase("createdFromDate")) {
						createdFromDate = (String)value.split(" ")[0];
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						createdFromDate = sdf.format(CommonUtil.toUTC(sdf.parse(createdFromDate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("createdToDate")) {
						createdToDate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						createdToDate = sdf.format(CommonUtil.toUTC(sdf.parse(createdToDate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("updatedFromdate")) {
						updatedFromdate = (String) value.split(" ")[0];
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						updatedFromdate = sdf.format(CommonUtil.toUTC(sdf.parse(updatedFromdate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("updatedTodate")) {
						updatedTodate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						updatedTodate = sdf.format(CommonUtil.toUTC(sdf.parse(updatedTodate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (!(key.equalsIgnoreCase("sortby") || key.equalsIgnoreCase("sortorder")
							|| key.equalsIgnoreCase("pageno") || key.equalsIgnoreCase("pagesize")
							|| key.equalsIgnoreCase("createdFromDate") || key.equalsIgnoreCase("createdToDate")
							|| key.equalsIgnoreCase("updatedFromdate") || key.equalsIgnoreCase("updatedTodate"))) {
						if (key.equals("id") && sortby.equals("filedefinitionid")) {
							key = "filedefinitionid";
						} else if (key.equals("namelike")) {
							key = "name";
						}
						String operator = key.equalsIgnoreCase("name") ? " like " : " = ";
						if (key.equalsIgnoreCase("name")) {
							search += " and " + key + operator + "'%" + value + "%'";
						} else {
							search += " and " + key + operator + "'" + value + "'";
						}
					}
				}
			}
			if (!"".equalsIgnoreCase(createdFromDate.trim()) && !"".equalsIgnoreCase(createdToDate.trim())) {
				search += " and "  + "CREATEDATE  BETWEEN DATE_FORMAT('" + createdFromDate.trim()
						+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + createdToDate.trim() + "','%Y-%m-%d %H:%i:%s')";
			}
			if (!"".equalsIgnoreCase(updatedFromdate.trim()) && !"".equalsIgnoreCase(updatedTodate.trim())) {
				search += " and "  + "UPDATEDATE  BETWEEN DATE_FORMAT('" + updatedFromdate.trim()
						+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + updatedTodate.trim() + "','%Y-%m-%d %H:%i:%s')";
			}
			if (search != null && !"".equalsIgnoreCase(search)) {
				search = search.replaceFirst("and", " where ");
			}
		}
		output[0] = pageno;
		output[1] = pagesize;
		output[2] = search;
		output[3] = sortby;
		output[4] = sortorder;
		return output;

	}
	
	public HashMap<String,Object> getAllExpressions(Map<String,String> searchCriteria) throws Exception{
		try {
			Object[] searchConditions = prepareSearchCriteria(searchCriteria);
			Integer pageno = (Integer) searchConditions[0];
			Integer pagesize = (Integer) searchConditions[1];
			String sorting=searchConditions[3] + " " + searchConditions[4];
			
			String query = "select count(1) from ADM_EXPRESSION "+((searchConditions[2] != null) ? searchConditions[2] : "")+" order by "+ sorting;
			int totalRecords = template.queryForObject(query,Integer.class);
			int count = 0;
			int length = totalRecords;
			if (pageno != null && pagesize != null) {
				count = ((pageno - 1) * pagesize);
				length = count + pagesize;
				if (totalRecords < length) {
					length = totalRecords;
				}
			}
			if(pageno == null)pageno=0;
			if(pagesize == null)pagesize = totalRecords;
			query = "select expressionid,departmentid,name,expressiontype,returnvalue,status,inputparams,expressiondsl,description,createdby,updatedby,createdate,updatedate"
					+ " from ADM_EXPRESSION "+((searchConditions[2] != null) ? searchConditions[2] : "")+" order by "+sorting+" limit ?,?";
			List<ExpressionBO> expressionBOs = template.query(query,new Object[]{count,pagesize},new ExpressionMapper());
			if (expressionBOs != null && !expressionBOs.isEmpty()) {
				try {
					StringBuilder sb = new StringBuilder();
					for (ExpressionBO resultBo : expressionBOs) {
						sb.append(resultBo.getExpressionID() + ",");
					}
				} catch (Exception e) {
					HashMap<String, Object> reult = new HashMap<String, Object>();
					reult.put("result", expressionBOs);
					reult.put("totalRecords", totalRecords);
					return reult;
				}
			}
			HashMap<String, Object> reult = new HashMap<String, Object>();
			reult.put("result", expressionBOs);
			reult.put("totalRecords", totalRecords);
			return reult;
		} catch (Exception e) {
			logger.error("ExpressionException:: ", e);
			throw e;
		}
	}
	
	public ExpressionBO getExpressionByName(String expressionName) throws Exception{
		try {
			logger.debug("Begin : getExpressionByName(String expressionName)");
			String query = "SELECT * FROM ADM_EXPRESSION WHERE name=?";
			Object[] params = { expressionName };
			try {
				logger.debug("params : "+params+"	query : "+query);
				return template.queryForObject(query, params, new ExpressionMapper());
			} catch (EmptyResultDataAccessException ex) {
				return null;
			}
		} catch (Exception e) {
			logger.error("ExpressionException:: ", e);
			throw e;
		}
	}
	@Override
	public Boolean deleteExpression(Long expressionId) {
		try {
			logger.debug("Begin : deleteExpression(Long expressionId)");
			String query = "DELETE FROM ADM_EXPRESSION WHERE expressionid=?";
			Object params = expressionId;
			try {
				logger.debug("params : " + params + "	query : " + query);
				template.update(query, params);
			} catch (EmptyResultDataAccessException ex) {
				logger.error("EmptyResult fetched in deleteExpression(expressionId)", ex);
				return false;
			}
			logger.debug("End : deleteExpression(Long expressionId)");
			return true;
		} catch (Exception e) {
			logger.error("ExpressionException:: ", e);
			throw e;
		}
	}
	@Override
	public List<ExpressionBO> getListOfExpressionsByNames(Set<String> names){
		logger.debug("Begin ::"+getClass().getName()+" getListOfExpressionsByNames(List<String> names)");
		List<ExpressionBO> expressionBOs=null;
		try {
			if (!names.isEmpty()){
				StringBuilder queryParams=new StringBuilder();
				for (String name : names){
					queryParams.append("'").append(name).append("',");
				}
				expressionBOs=template.query("SELECT * FROM ADM_EXPRESSION WHERE name IN ("+queryParams.toString().substring(0, queryParams.toString().length()-1)+")", new ExpressionMapper());
			}
		} catch (Exception e) {
			throw e;
		}
		logger.debug("End ::"+getClass().getName()+" getListOfExpressionsByNames(List<String> names)");
		return expressionBOs;
	}
	
	@Override
	public boolean validateNumberFormat(String format) throws Exception{
		logger.debug("Begin ::"+getClass().getName()+" validateNumberFormat(String format)");
		whJdbcTemplate.queryForObject("SELECT TO_CHAR(000,'"+format+"') from dual",String.class);
		logger.debug("End ::"+getClass().getName()+" validateNumberFormat(String format)");
		return true;
	}
}

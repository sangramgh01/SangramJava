package com.zetainteractive.zetahub.expression.dao.impl;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.ExpressionBO;

public class ExpressionMapper  implements RowMapper<ExpressionBO>{

	@Override
	public ExpressionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ExpressionBO expressionBO = new ExpressionBO();
		expressionBO.setExpressionID(rs.getLong("expressionid"));
		expressionBO.setDepartmentID(rs.getLong("departmentid"));
		expressionBO.setName(rs.getString("name"));
		expressionBO.setExpressionType(rs.getString("expressiontype").charAt(0));
		expressionBO.setStatus(rs.getString("status").charAt(0));
		expressionBO.setExpressionDSL(rs.getString("expressiondsl"));
		try {
			if(rs.getString("returnvalue") != null)
				expressionBO.setReturnvalue(new ObjectMapper().readValue(rs.getString("returnvalue"), new TypeReference<Map<String,String>>(){}));
			if(rs.getString("inputParams") != null)
				expressionBO.setInputParams(new ObjectMapper().readValue(rs.getString("inputParams"), new TypeReference<List<Object>>(){}));
		} catch (IOException e) {
		}
		expressionBO.setDescription(rs.getString("description"));
		expressionBO.setCreatedBy(rs.getString("createdby"));
		expressionBO.setUpdatedBy(rs.getString("updatedby"));
		try {
			expressionBO.setCreateDate(CommonUtil.toLocalTime(rs.getTimestamp("createdate").getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			expressionBO.setUpdateDate(CommonUtil.toLocalTime(rs.getTimestamp("updatedate").getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
		} catch (Exception e) {
		}
		
		return expressionBO;
		
	}
}

/**
 * AudienceException.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.expression.exception;

import org.apache.log4j.Level;

/**
 * 
 * @author Venkata.Tummala
 *
 */

public class ExpressionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String dbMessage;
	Object[] object;
	Level level = Level.ERROR;
	boolean flag = false;

	/**
	 * @return Returns the errorMessage.
	 */

	public String getErrorMessage() {
		return getMessage();
	}

	/**
	 * No argument constructor.
	 */
	public ExpressionException() {
		super();
	}

	/**
	 * @param errorCode
	 *            error code
	 */
	public ExpressionException(String errorCode) {
		super(errorCode);
	}

	/**
	 * Constructor takes Error code and actual ex as arguments.
	 * 
	 * @param code
	 *            Error code
	 * @param ex
	 *            Actual Exception occured.
	 */
	public ExpressionException(String code, Throwable ex) {
		super(code, ex);
	}

	public String getErrorCode(){
		return super.getMessage();
	}
	
	/**
	 * @param code
	 * @param object
	 */
	public ExpressionException(String code, Object[] object) {
		super(code);
		this.object = object;
	}

	/**
	 * @param code
	 * @param ex
	 * @param object
	 * @param flag
	 */
	public ExpressionException(String code, Throwable ex, Object[] object, boolean flag) {
		super(code, ex);
		this.object = object;
		this.flag = flag;
	}

	/**
	 * @param code
	 * @param object
	 * @param level
	 * @param ex
	 */
	public ExpressionException(String code, Object[] object, Level level, Throwable ex) {
		super(code, ex);
		this.object = object;
		this.level = level;
	}

	public ExpressionException(String code, String locale, Object obj) {
		super(code);
	}

	/**
	 * @return Returns the dbMessage.
	 */
	public String getDbMessage() {
		return dbMessage;
	}

	/**
	 * @param dbMessage
	 *            The dbMessage to set.
	 */
	public void setDbMessage(String dbMessage) {
		this.dbMessage = dbMessage;
	}

	/**
	 * @return Returns the object.
	 */
	public Object[] getObject() {
		return object;
	}

	/**
	 * @param object
	 *            the object to set
	 */
	public void setObject(Object[] object) {
		this.object = object;
	}

	/**
	 * @return Returns the exception.
	 */
	public Throwable getException() {
		return super.getCause();
	}

	/**
	 * @return Returns the level.
	 */
	public Level getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            The level to set.
	 */
	public void setLevel(Level level) {
		this.level = level;
	}
}

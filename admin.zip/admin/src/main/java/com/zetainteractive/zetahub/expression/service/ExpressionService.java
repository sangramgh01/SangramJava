package com.zetainteractive.zetahub.expression.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.commons.domain.ExpressionBO;
import com.zetainteractive.zetahub.commons.domain.TrackClicksBO;
import com.zetainteractive.zetahub.expression.exception.ExpressionException;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface ExpressionService {
	
	public ExpressionBO saveExpression(ExpressionBO expressionsBO,BindingResult bindingResult);
	public HashMap<String, Object> getAllExpressions(Map<String, String> searchCriteria) throws ExpressionException;
	public ExpressionBO getExpressionByName(String expressionName) throws ExpressionException;
	public Boolean deleteExpression(Long expressionId) throws ExpressionException,Exception;
	/**
	 * 
	 * 
	 * Method Name 	: getListOfExpressionsByNames
	 * Description 	: The Method "getListOfExpressionsByNames" is used for getting list of expressions based on list of Names
	 * Date    		: 8 Jan 2018, 14:36:30
	 * @param names
	 * @return
	 * @param  		:
	 * @return 		: Set<ExpressionBO>
	 * @throws 		:
	 */
	public List<ExpressionBO> getListOfExpressionsByNames(Set<String> names);
	public boolean validateNumberFormat(String expressionDSL) throws ExpressionException;
}

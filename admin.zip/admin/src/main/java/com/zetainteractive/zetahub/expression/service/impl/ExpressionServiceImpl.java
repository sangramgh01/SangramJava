package com.zetainteractive.zetahub.expression.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.util.AdminDependencyCalls;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.ExpressionBO;
import com.zetainteractive.zetahub.expression.dao.ExpressionDao;
import com.zetainteractive.zetahub.expression.exception.ExpressionException;
import com.zetainteractive.zetahub.expression.service.ExpressionService;
import com.zetainteractive.zetahub.expression.validator.ExpressionValidator;
/**
 * 
 * @author Venkata.Tummala
 *
 */
@Component
public class ExpressionServiceImpl implements ExpressionService{

	ZetaLogger logger = new ZetaLogger(getClass().getName());
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();
	@Autowired
	AdminDependencyCalls admindependencycalls;
	@Autowired
	ExpressionValidator expressionValidator;
	@Autowired
	ExpressionDao expressionDao;
	@Autowired
	MessageSource messageSource;
	@Autowired
	DepartmentService departmentService;
	private String unExpectedErrorCode = "F00002";
	private String unExpectedErrorMessage = "An unexpected error has occurred.";
	
	@Override
	public ExpressionBO saveExpression(ExpressionBO expressionsBO,BindingResult bindingResult) {
		logger.debug("Start : saveExpression()");
		try {
			expressionValidator.validate(expressionsBO, bindingResult);
			if(expressionsBO.getExpressionDSL().startsWith("number_format")){
				try{
					validateNumberFormat(expressionsBO.getExpressionDSL());
				}catch(Exception e){
					logger.error("Error while saving Expression :: ", e);
					bindingResult.reject("Invalid number format","Invalid Data");
				}
			}
			if (!bindingResult.hasErrors()){
				if(expressionsBO.getExpressionID() == null ||  expressionsBO.getExpressionID() == 0){
					ExpressionBO expressions = expressionDao.getExpressionByName(expressionsBO.getName());
					if(expressions != null){
						throw new ExpressionException("EX0001");
					}
				}
				AuditEvent event = new AuditEvent();
		        event.setActor("ExpressionServiceImpl");
		        event.setAction("save or update Expression");
		        event.addField("save or update Expression :: ",expressionsBO.getName());
		        auditManager.audit(event);
				expressionsBO = expressionDao.saveExpression(expressionsBO);
			}
		} catch (Exception e) {
			AuditEvent event = new AuditEvent();
	        event.setActor("ExpressionServiceImpl");
	        event.setAction("save or update Expression exception ");
	        event.addField("save or update Expression exception :: ",expressionsBO.getName());
	        auditManager.audit(event);
			logger.error("Error while saving Expression :: ", e);
			if(e instanceof ExpressionException){
					ExpressionException ex = (ExpressionException) e;
					bindingResult.reject(messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()),"Invalid Data");
			}else{
				bindingResult.reject(messageSource.getMessage(unExpectedErrorCode, new Object[] {}, LocaleContextHolder.getLocale()),unExpectedErrorMessage);
			}
		}
		logger.debug("End : saveExpression()");
		return expressionsBO;
	}
	
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public HashMap<String, Object> getAllExpressions(Map<String, String> searchCriteria) throws ExpressionException{
		try{
			return expressionDao.getAllExpressions(searchCriteria);
		}catch (Exception e) {
			throw new ExpressionException("F00002",e);
		}
	}
	
	
	
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public ExpressionBO getExpressionByName(String expressionName) throws ExpressionException{
		try{
			return expressionDao.getExpressionByName(expressionName);
		}catch (Exception e) {
			throw new ExpressionException("F00002",e);
		}
	}

	@Override
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public Boolean deleteExpression(Long expressionId) throws ExpressionException,Exception{
		logger.debug("Start : deleteExpression()");
		Boolean isDelete = true;
		try {
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<Object> entity = new HttpEntity<>(headers);
			ResponseEntity<List> result = new RestRequestHandler().exchange(
					getEndPoint() + "/Conversation/criteriaExist/derivedfields/" + expressionId, HttpMethod.GET, entity,
					List.class);
			if (result.getBody().isEmpty()) {
				return expressionDao.deleteExpression(expressionId);
			} else {
				throw new ExpressionException("EX0014",new Object[]{result.getBody()});
			}
		}
		catch (ExpressionException e) {
			logger.debug("Exceptin in  : deleteExpression()");
			throw e;
		} catch (Exception e) {
			logger.debug("Exceptin in  : deleteExpression()");
			throw e;
		}
	}
	
	private String  getEndPoint() throws Exception{
		//return "http://localhost:8110";
		return ZetaUtil.getHelper().getEndpoint("conversation").toString();
	}
	
	@Override
	public List<ExpressionBO> getListOfExpressionsByNames(Set<String> names){
		return expressionDao.getListOfExpressionsByNames(names);
	}
	
	@Retryable(value = {CannotGetJdbcConnectionException.class},maxAttempts = 4,backoff = @Backoff( delay = 2000))
	public boolean validateNumberFormat(String expressionDSL) throws ExpressionException{
		try{
			String ConditionStr = expressionDSL.substring(expressionDSL.indexOf("(")+1,expressionDSL.length()-1);
			ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("','"), Matcher.quoteReplacement("'#splitString'"));
			ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("',$"), Matcher.quoteReplacement("'#splitString$"));
			ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("},'"), Matcher.quoteReplacement("}#splitString'"));
			ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("},$"), Matcher.quoteReplacement("}#splitString$"));
			ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("',"), Matcher.quoteReplacement("#splitString"));
			String[] paramsStringArray = ConditionStr.split("#splitString");
			return expressionDao.validateNumberFormat(paramsStringArray[1].replaceAll(Matcher.quoteReplacement("'"), ""));
		}catch (Exception e) {
			throw new ExpressionException("F00002",e);
		}
	}
	
}

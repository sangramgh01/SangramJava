package com.zetainteractive.zetahub.expression.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.client.RestClientException;
import com.zetainteractive.zetahub.admin.util.AdminDependencyCalls;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.Conversation;
import com.zetainteractive.zetahub.commons.domain.ExpressionBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.Node;
import com.zetainteractive.zetahub.commons.domain.TimeZoneData;
import com.zetainteractive.zetahub.commons.domain.TrackClicksBO;
import com.zetainteractive.zetahub.commons.enums.ExpressionReturnTypes;
import com.zetainteractive.zetahub.expression.dao.ExpressionDao;
import com.zetainteractive.zetahub.expression.exception.ExpressionException;


/**
 * 
 * @author Venkata.Tummala
 *
 */
@Component
public class ExpressionValidator implements Validator{

	@Autowired
	AdminDependencyCalls adminDependencyCalls;
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	ExpressionDao expressionDao;
	
	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object target, Errors errors) {
		ExpressionBO expressionBO = (ExpressionBO) target;
		if(expressionBO.getName() == null || "".equalsIgnoreCase(expressionBO.getName().trim())){
			errors.rejectValue("name", messageSource.getMessage("FL0010",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if(expressionBO.getName()!= null && (expressionBO.getName().length() < 1 || expressionBO.getName().length() >= 100)){
			errors.rejectValue("name", messageSource.getMessage("F00054",new Object[] { "name" }, LocaleContextHolder.getLocale()));
		}
		if (expressionBO.getDepartmentID() == null) {
			errors.rejectValue("departmentID", messageSource.getMessage("FL0010",new Object[] { "departmentID" }, LocaleContextHolder.getLocale()));
		}
		if (expressionBO.getExpressionType() != null && expressionBO.getExpressionType()=='S'){
			errors.rejectValue("expressionType", messageSource.getMessage("EX0006",new Object[] { "expressionType" }, LocaleContextHolder.getLocale()));
		}
		else if (expressionBO.getExpressionType() == null ||  expressionBO.getExpressionType()==' '  || !(expressionBO.getExpressionType() == 'C')) {
			errors.rejectValue("expressionType", messageSource.getMessage("EX0003",new Object[] { "expressionType" }, LocaleContextHolder.getLocale()));
		}
		if (expressionBO.getReturnvalue() == null) {
			errors.rejectValue("returnvalue", messageSource.getMessage("EX0004",new Object[] { "returnvalue" }, LocaleContextHolder.getLocale()));
		}else{
			Map<String,String> returnvalue = expressionBO.getReturnvalue();
			String returnType = returnvalue.get("type");
			if(returnType == null || "".equalsIgnoreCase(returnType.trim())){
				errors.rejectValue("returnvalue", messageSource.getMessage("EX0004",new Object[] { "returnvalue" }, LocaleContextHolder.getLocale()));
			}else{
				boolean isValid = false;
				for (Object s : ExpressionReturnTypes.values())
			    {
					if (returnType.toUpperCase().trim().equals(s.toString()))
			        {
						isValid = true;
						break;
			        }
			    }
				if(!isValid){
					errors.rejectValue("returnvalue", messageSource.getMessage("EX0004",new Object[] { "returnvalue" }, LocaleContextHolder.getLocale()));
				}else{
					returnvalue.put("type", ExpressionReturnTypes.valueOf(returnType.toUpperCase()).getReturnType());
					expressionBO.setReturnvalue(returnvalue);
				}
			}
		}
		if (expressionBO.getStatus() == null  ||  expressionBO.getStatus()==' ' || !(expressionBO.getStatus() == 'A' || expressionBO.getStatus() == 'I' || expressionBO.getStatus() == 'D')) {
			errors.rejectValue("status", messageSource.getMessage("EX0002",new Object[] { "status" }, LocaleContextHolder.getLocale()));
		}
		if(expressionBO.getInputParams()!=null && !expressionBO.getInputParams().isEmpty()){
			List<Object> inputParams = expressionBO.getInputParams();
			boolean isConversationexists = false;
			boolean isTouchPointexists = false;
			boolean isLinkexists = false;
			Set<String> paramsSet = new HashSet<String>();
			for (Object input : inputParams) {
				LinkedHashMap map = (LinkedHashMap) input;
				if(map.get("paramName")==null || "".equalsIgnoreCase(map.get("paramName").toString().trim())){
					errors.rejectValue("inputParams", messageSource.getMessage("FL0010",new Object[] { "paramName" }, LocaleContextHolder.getLocale()));
				}else{
					if(paramsSet.contains(map.get("paramName").toString().trim())){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0012",new Object[] { "paramName" }, LocaleContextHolder.getLocale()));
					}else{
						paramsSet.add(map.get("paramName").toString().trim());
					}
				}
				if(map.get("paramType")==null || "".equalsIgnoreCase(map.get("paramType").toString().trim())){
					errors.rejectValue("inputParams", messageSource.getMessage("FL0076",new Object[] { "paramType" }, LocaleContextHolder.getLocale()));
				}
				if(map.get("paramType")!=null && !"".equalsIgnoreCase(map.get("paramType").toString().trim())){
					if("Conversation".equalsIgnoreCase(map.get("paramType").toString()) && !isConversationexists){
						isConversationexists = true;
					}else if ("Conversation".equalsIgnoreCase(map.get("paramType").toString())){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0009",new Object[] { "Conversation" }, LocaleContextHolder.getLocale()));
					}
					if("TouchPoint".equalsIgnoreCase(map.get("paramType").toString()) && !isTouchPointexists){
						isTouchPointexists = true;
					}else if ("TouchPoint".equalsIgnoreCase(map.get("paramType").toString())){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0009",new Object[] { "TouchPoint" }, LocaleContextHolder.getLocale()));
					}
					if("Link".equalsIgnoreCase(map.get("paramType").toString()) && !isLinkexists){
						isLinkexists = true;
					}else if ("Link".equalsIgnoreCase(map.get("paramType").toString())){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0009",new Object[] { "Link" }, LocaleContextHolder.getLocale()));
					}
					if("TouchPoint".equalsIgnoreCase(map.get("paramType").toString()) && !isConversationexists){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0010",new Object[] { "Conversation" }, LocaleContextHolder.getLocale()));
					}
					if("Link".equalsIgnoreCase(map.get("paramType").toString()) && (!isConversationexists || !isTouchPointexists)){
						errors.rejectValue("inputParams", messageSource.getMessage("EX0011",new Object[] { "Conversation" }, LocaleContextHolder.getLocale()));
					}
				}
			}
		}
		try {
			validateDSL(expressionBO,errors);
		} catch (ExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RestClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void validateDSL(ExpressionBO expressionBO, Errors errors) throws RestClientException, Exception {
		String expressionDSL = expressionBO.getExpressionDSL();
		ArrayList<Object> userParamList = (ArrayList<Object>)expressionBO.getInputParams();
		Map<String,String> criteria = new HashMap<String, String>();
		criteria.put("expressiontype", "S");
		HashMap<String, Object> systemExpressions = expressionDao.getAllExpressions(criteria);
		ArrayList<Object> sysExpList = (ArrayList<Object>) systemExpressions.get("result");
		Iterator<Object> sysExpIterator = sysExpList.iterator();
		boolean tillValid = true;
		boolean convParam = false;
		boolean touchPointParam = false;
		boolean linkParam = false;
		TimeZoneData timeZoneData = null;
		boolean isConversation = false;
		while(sysExpIterator.hasNext()){
			ExpressionBO expObj = (ExpressionBO)sysExpIterator.next(); 
			ArrayList<Object> sysParamList = (ArrayList<Object>)expObj.getInputParams();
			if(expressionDSL != null && expressionDSL.startsWith(expObj.getName())){
				if(!(expressionBO.getReturnvalue().get("type").equalsIgnoreCase(expObj.getReturnvalue().get("type")))){
					errors.rejectValue("returnvalue", messageSource.getMessage("EX0013",new Object[] {expObj.getName()}, LocaleContextHolder.getLocale()));
				}
				String ConditionStr = expressionDSL.substring(expObj.getName().length());
				if(ConditionStr.startsWith("(") && ConditionStr.endsWith(")") ){
				
					ConditionStr=ConditionStr.substring(1,ConditionStr.length()-1);
					ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("','"), Matcher.quoteReplacement("'#splitString'"));
					ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("',$"), Matcher.quoteReplacement("'#splitString$"));
					ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("},'"), Matcher.quoteReplacement("}#splitString'"));
					ConditionStr = ConditionStr.replaceAll(Matcher.quoteReplacement("},$"), Matcher.quoteReplacement("}#splitString$"));
					String[] paramsStringArray = ConditionStr.split("#splitString");
					if(expressionDSL.equalsIgnoreCase("now()") && expObj.getInputParams()==null){
						// If expressionDSL  is now() no need to check 
					}
					else if(paramsStringArray.length==expObj.getInputParams().size()){
						for (int i = 0; i < paramsStringArray.length; i++) {
							if(!(paramsStringArray[i].startsWith("'") && paramsStringArray[i].endsWith("'"))){
								if(!(paramsStringArray[i].startsWith("${") && paramsStringArray[i].endsWith("}"))){
									errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL000",new Object[] {}, LocaleContextHolder.getLocale()));
									tillValid = false;
									break;
								}
							}else{
								paramsStringArray[i] = paramsStringArray[i] .substring(1, paramsStringArray[i].length()-1);
							}
						}
						if(tillValid){
							Conversation conversation = null;
							List<Node> touchPoints = null;
							String tracklinkUrlString = "";
							for (int i = 0; i < paramsStringArray.length; i++) {
								if(tillValid){
									LinkedHashMap<String, String> parameterObject = (LinkedHashMap<String, String>)	sysParamList.get(i);
									String sysParameterType = parameterObject.get("paramType");
									boolean nameFound = false;
									RestRequestHandler restHandler = new RestRequestHandler();
									if(paramsStringArray[i].startsWith("${") && paramsStringArray[i].endsWith("}")){
										for (int j = 0; j < userParamList.size(); j++) {
											LinkedHashMap<String, String> customParameterObject = (LinkedHashMap<String, String>)userParamList.get(j);
											if(customParameterObject.get("paramName").equals(paramsStringArray[i].substring(2,paramsStringArray[i].length()-1)) && customParameterObject.get("paramType").equals(sysParameterType)){
												nameFound = true;
												if(customParameterObject.get("paramType").equals("Conversation")){
													convParam = true;
												}else if(customParameterObject.get("paramType").equals("Touchpoint")){
													if(!convParam){
														errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL003",new Object[] {}, LocaleContextHolder.getLocale()));
														tillValid =false;
														break;
													}else{
														touchPointParam = true;
													}
												}else if(customParameterObject.get("paramType").equals("Link")){
													if(!touchPointParam){
														errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL003",new Object[] {}, LocaleContextHolder.getLocale()));
														tillValid =false;
														break;
													}else{
														linkParam = true;
													}
													
												}
												break;
											}
										}
										if(!nameFound){
											errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL002",new Object[] { paramsStringArray[i] }, LocaleContextHolder.getLocale()));
											tillValid =false;
											break;
										}
									}else{
										if(sysParameterType.equals("Conversation")){
											if(touchPointParam || linkParam){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL003",new Object[] {}, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}else{
												try{
													/*ResponseEntity<Conversation> response = restTemplate.exchange(
														"http://localhost:7091"+"/Conversation/getConversationByName/"+paramsStringArray[i] , HttpMethod.GET, null,
									                        new ParameterizedTypeReference<Conversation>() {
									                        });*/
													/*HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
													Map<String,String> conversationData = new HashMap<>();
													conversationData.put("conversationName", paramsStringArray[i]+"");
													HttpEntity entity = new HttpEntity<>(conversationData,headers);
													ResponseEntity<Conversation> response = restHandler.exchange(
								            			ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/getConversationByName" , HttpMethod.POST, entity,
								                        Conversation.class);
													conversation = response.getBody();*/
													conversation=adminDependencyCalls.getConversationByName(paramsStringArray[i]);
													tracklinkUrlString = tracklinkUrlString+conversation.getConversationID()+",";
													isConversation = true;
												}catch (Exception e) {
													errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "Conversation "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
													tillValid =false;
													break;
												}
											}
											
										}else if(sysParameterType.equals("Touchpoint")){
											if(convParam || linkParam){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL003",new Object[] {}, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}else{
												try{
													int isTouchpointsValidCount = 0;
													/*ResponseEntity<List<Node>> response = restTemplate.exchange(
														"http://localhost:7091"+"/Conversation/listAllTouchPoints/"+conversation.getConversationID() , HttpMethod.GET, null,
									                        new ParameterizedTypeReference<List<Node>>() {
									                        });*/
													/*HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
													HttpEntity entity = new HttpEntity<>(headers);
													ResponseEntity<List<Node>> response = restHandler.exchange(
								            			ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/listAllTouchPoints/"+conversation.getConversationID() , HttpMethod.GET, entity,
								                        new ParameterizedTypeReference<List<Node>>() {
								                        });
													touchPoints = response.getBody();*/
													touchPoints=adminDependencyCalls.listAllTouchPoints(conversation.getConversationID());
													Iterator<Node> touchPointIterator = touchPoints.iterator();
													String[] touchPointArray = paramsStringArray[i].split(",");
													while(touchPointIterator.hasNext()){
														Node node = touchPointIterator.next();
														for (int j = 0; j < touchPointArray.length; j++) {
															if(touchPointArray[j].equals(node.getNodeName())){
																isTouchpointsValidCount++;
																tracklinkUrlString = tracklinkUrlString+node.getNodeID()+",";
															}
														}
														
													}
													if(isTouchpointsValidCount!=touchPointArray.length){
														errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "TouchPoints "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
														tillValid =false;
														break;
													}
												}catch (RestClientException e) {
													errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "TouchPoints "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
													tillValid =false;
													break;
												}
											}
											
											
										}else if(sysParameterType.equals("Link")){
											if(touchPointParam || convParam){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL003",new Object[] {}, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}else{
												try{
													boolean istrackClickValid = false;
													List<TrackClicksBO> trackClicks = null;
													/*HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
													HttpEntity entity = new HttpEntity<>(headers);
													ResponseEntity<List<TrackClicksBO>> response = restHandler.exchange(
									            		ZetaUtil.getHelper().getEndpoint("conversation")+"/getAllTrackClicks/"+tracklinkUrlString , HttpMethod.GET, entity,
									                        new ParameterizedTypeReference<List<TrackClicksBO>>() {
									                        });*/
													//tracklinkUrlString.substring(0,tracklinkUrlString.length()-1)
													/*ResponseEntity<List<TrackClicksBO>> response = restTemplate.exchange(
														"http://localhost:7093"+"/getAllTrackClicks/"+tracklinkUrlString.substring(0,tracklinkUrlString.length()-1) , HttpMethod.POST, null,
									                        new ParameterizedTypeReference<List<TrackClicksBO>>() {
									                        });*/
												
//													trackClicks = response.getBody();
													trackClicks =adminDependencyCalls.getAllTrackClicks(tracklinkUrlString);
													Iterator<TrackClicksBO> trackClicksIterator = trackClicks.iterator();
													while(trackClicksIterator.hasNext()){
														TrackClicksBO tcb = trackClicksIterator.next();
														if((tcb.getUrl().equals(paramsStringArray[i].split(",")[0]) && tcb.getClickSequence().equals(paramsStringArray[i].split(",")[1]))||(paramsStringArray[i].split(",")[0]).equals("All links") ){
															istrackClickValid = true;
															break;
														}
													}
													
													if(!istrackClickValid){
														errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "Links "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
														tillValid =false;
														break;
													}
												}catch (RestClientException e) {
													errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "Links "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
													tillValid =false;
													break;
												}
											}
											
											
											
										}else if(sysParameterType.equals("Aggregate")){
											boolean isaggregateValid = false;
											String[] aggregateArray = { "COUNT","MAX","MIN","AVG","SUM"};
											//ArrayList datePart = (ArrayList) Arrays.asList(daysArray);
											for (int j = 0; j < aggregateArray.length; j++) {
												if(paramsStringArray[i].equals(aggregateArray[j])){
													isaggregateValid = true;
												}
											}
											if(!isaggregateValid){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "Aggregate "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}
										}else if(sysParameterType.equals("DateFormat")){
											boolean isDateFormatValid = false;
											String[] dateFormatArray = {"mm/dd","mm/dd/yy","MM/dd/yy","MM/dd/yyyy","dd/MM/yy","dd-Mon","dd-Mon-yy","Mon-yy","Month-yy","Month dd,yyyy","mm/dd/yy hh12:mi am","mm/dd/yy hh:mi","mm/dd/yyyy","yyyyMMdd","Month","Day","yyyy","Mon","dd","yy","dd/MM/yyyy","dd-MM-yyyy","MM-dd-yyyy","yyyy-mm-dd","yyyy-dd-mm"};
											for (int j = 0; j < dateFormatArray.length; j++) {
												if(paramsStringArray[i].equals(dateFormatArray[j])){
													isDateFormatValid = true;
												}
											}
											if(!isDateFormatValid){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "DateFormat "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}
										}else if(sysParameterType.equals("TimeZone")){
											if(timeZoneData==null){
												try{
													HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
													HttpEntity entity = new HttpEntity<>(headers);
													ResponseEntity<TimeZoneData> response = restHandler.exchange(
										            		ZetaUtil.getHelper().getEndpoint("admin")+"/datatransforms/getTimeZones" , HttpMethod.GET, entity,
										            		TimeZoneData.class);
													/*ResponseEntity<TimeZoneData> response = restTemplate.exchange(
															"http://localhost:7092"+"/datatransforms/getTimeZones" , HttpMethod.GET, null,
										                        new ParameterizedTypeReference<TimeZoneData>() {
										                        });*/
													timeZoneData = response.getBody();
													}catch(Exception e){
														throw new Exception("Unexpected error");
													}
											}
											String[] timeZones = timeZoneData.getRegionIds();
											boolean istimeZoneValid = false;
											for (int j = 0; j < timeZones.length; j++) {
												if(paramsStringArray[i].equals(timeZones[j])){
													istimeZoneValid = true;
												}
											}
											if(!istimeZoneValid){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "TimeZone "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}
 											
										}else if(sysParameterType.equals("DatePart")){
											boolean isDatePartValid = false;
											String[] daysArray = { "day","month","week","year","hour","minute"};
											//ArrayList datePart = (ArrayList) Arrays.asList(daysArray);
											for (int j = 0; j < daysArray.length; j++) {
												if(paramsStringArray[i].equals(daysArray[j])){
													isDatePartValid = true;
												}
											}
											if(!isDatePartValid){
												errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL004",new Object[] { "DatePart "+paramsStringArray[i] }, LocaleContextHolder.getLocale()));
												tillValid =false;
												break;
											}
										}else if(sysParameterType.equals("String")){
											
										}else if(sysParameterType.equals("BigInt")){
											
										}else if(sysParameterType.equals("DateTime")){
											if(isConversation){
												if(paramsStringArray[i]!=null && !"".equalsIgnoreCase(paramsStringArray[i].trim()) && paramsStringArray[i].contains(".")){
													HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
													HttpEntity entity = new HttpEntity<>(headers);
													ResponseEntity<List<Node>> response = restHandler.exchange(
								            			ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/listAllTouchPoints/"+conversation.getConversationID() , HttpMethod.GET, entity,
								                        new ParameterizedTypeReference<List<Node>>() {
								                        });
													touchPoints = response.getBody();
													if(touchPoints!=null && !touchPoints.isEmpty()){
														Long audienceID = touchPoints.get(0).getAudienceID();
														ResponseEntity<AudienceBO> response1 = restHandler.exchange(
											            		ZetaUtil.getHelper().getEndpoint("admin")+"/audience/findAudienceById/"+audienceID , HttpMethod.GET, entity,
											            		AudienceBO.class);
														AudienceBO audience = response1.getBody();
														Map<String,List<String>> logicalTablesMap = new HashMap<String,List<String>>();
														Map<String,List<String>> physicalTableMap = new HashMap<String,List<String>>();
														if(audience!=null){
															List<LogicalTableBO> logicalTables = audience.getLogicalTables();
															if(logicalTables!=null && !logicalTables.isEmpty()){
																for (LogicalTableBO logicalTableBO : logicalTables) {
																	String logicalTable = logicalTableBO.getLogicalTableName();
																	String physicalTable = logicalTableBO.getPhysicalTableName();
																	List<LogicalColumnBO> logicalColumns = logicalTableBO.getLogicalColumns();
																	List<String> logicalcolumns = new ArrayList<String>();
																	List<String> physicalcolumns = new ArrayList<String>();
																	if(logicalColumns!=null && !logicalColumns.isEmpty()){
																		for(LogicalColumnBO logicalColumnBO : logicalColumns) {
																			if(logicalColumnBO.getColumnDataType()==9){
																				logicalcolumns.add(logicalColumnBO.getLogicalColumnName());
																				physicalcolumns.add(logicalColumnBO.getPhysicalColumnName());
																			}
																		}
																	}
																	logicalTablesMap.put(logicalTable, logicalcolumns);
																	physicalTableMap.put(physicalTable, physicalcolumns);
																}
															}
															String[] columnData = paramsStringArray[i].split("\\.");
															String tableName = columnData[0].trim();
															if(logicalTablesMap.containsKey(tableName) || physicalTableMap.containsKey(tableName)){
																if(logicalTablesMap.containsKey(tableName)){
																	List<String> logicalColumns = logicalTablesMap.get(tableName);
																	if(!logicalColumns.contains(columnData[1].trim())){
																		errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL006",new Object[] {columnData[1],columnData[0]}, LocaleContextHolder.getLocale()));
																	}
																}
																if(physicalTableMap.containsKey(tableName)){
																	List<String> physicalColumns = physicalTableMap.get(tableName);
																	if(!physicalColumns.contains(columnData[1].trim())){
																		errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL007",new Object[] {columnData[1],columnData[0]}, LocaleContextHolder.getLocale()));
																	}
																}
															}else{
																errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL005",new Object[] {columnData[0],columnData[1]}, LocaleContextHolder.getLocale()));
															}
														}
														
													}
												}
											}
										}
									}
								}
								
								
							}
						}
						
					}else{
						errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL000",new Object[] { }, LocaleContextHolder.getLocale()));
						break;
					}
					
					
				}else{
					//errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL000",new Object[] { "'"+expObj.getName()+"{' and it should end with '}'" }, LocaleContextHolder.getLocale()));
					errors.rejectValue("expressionDSL", messageSource.getMessage("EXDSL000",new Object[] { }, LocaleContextHolder.getLocale()));
					break;
				}
				
				
				
				
			}
			
			
			
		}
		
	}

}

package com.zetainteractive.zetahub.file.constants;

import java.util.regex.Pattern;

/**
 * 
 * @author Venkata.Tummala
 * To define all the constants used for list and file service
 */
public class Constants {
	public static String DBTYPE_MYSQL = "MYSQL";
	public static String MYSQL_URL = "jdbc:mysql://${IPADDRESS}:${PORT}/${SID}?autoReconnect=true&useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"; 
	public static String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
	
	public static String DBTYPE_ORACLE = "ORACLE";
	public static String ORACLE_URL = "jdbc:oracle:thin:@${IPADDRESS}:${PORT}:${SID}";
	public static String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	
	public static String DBTYPE_MSSQL = "MSSQL";
	public static String MSSQL_URL = "jdbc:jtds:sqlserver://${IPADDRESS}:${PORT}/${SID}";
	public static String MSSQL_DRIVER = "net.sourceforge.jtds.jdbc.Driver";
	
	public static String DBTYPE_TERADATA = "TERADATA";
	public static String TERADATA_URL = "jdbc:teradata://${SID}/";
	public static String TERADATA_DRIVER = "com.ncr.teradata.TeraDriver";
	
	public static String DBTYPE_NETEZZA = "NETEZZA";
	public static String NETEZZA_URL = "jdbc:netezza://${IPADDRESS}:${PORT}/${SID}";
	public static String NETEZZA_DRIVER = "org.netezza.Driver";
	
	public static String DBTYPE_POSTGRES = "POSTGRES";
	public static String POSTGRES_URL = "jdbc:postgresql://${IPADDRESS}:${PORT}/${SID}" ;
	public static String POSTGRES_DRIVER = "org.postgresql.Driver";
	
	public static String DBTYPE_VERTICA = "VERTICA";
	public static String VERTICA_URL = "jdbc:vertica://${IPADDRESS}:${PORT}/${SID}" ;
	public static String VERTICA_DRIVER = "com.vertica.jdbc.Driver";
	
	public static String IP_ADDRESS = "IPADDRESS";
	public static String PORT = "PORT";
	public static String SID = "SID";
	public static String COMMA =",";
	
	public static int MAXPAGE_LIMIT = 5000;
	public static int ROW_NUM = 10;
	public static final Pattern DatePatternWithZero = Pattern
			.compile("(((19|20)[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])++[\\s]++((([0-1]{1}[0-9]{1})|([2]{1}[0-3]{1}))[:][0-5]{1}[0-9]{1}[:][0-5]{1}[0-9]{1}[.][0]{1}))");
	
	public static final Pattern EMAIL_PATTERN = 
			Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	public static String INTERNAL_DB ="InternalDB";
	public static Character FILE_TYPE_BASE = 'B';
	public static Character FILE_TYPE_DIMENSION = 'D';
	public static Character FILE_TYPE_UNSUB = 'U';
	public static Character FILE_TYPE_RESUB = 'R';
	public static Character FILE_TYPE_ADHOC = 'A';
	public static Character YES = 'Y';
	public static Character NO = 'N';
	public static Character FILE_ACTION_STORE = 'S';
	public static Character FILE_ACTION_IMPORT = 'I';
	public static Character FILE_SOURCE_REMOTE_SERVER = 'R';
	public static Character FILE_SOURCE_REMOTE_DB = 'B';
	public static Character FILE_SOURCE_LOCAL_SERVER = 'L';
	public static Character FILE_SOURCE_DESKTOP = 'D';
	public static Character FILE_TYPE_ERRORED = 'E';
	public static Character FILE_TYPE_SKIPPED = 'U';
	

}

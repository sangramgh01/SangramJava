package com.zetainteractive.zetahub.file.controller;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.fileutils.exception.FileSystemUtilException;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceColumnTypeService;
import com.zetainteractive.zetahub.admin.audience.service.AudienceMetadataService;
import com.zetainteractive.zetahub.admin.audience.service.AudienceService;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.file.validator.FileActivityValidator;
import com.zetainteractive.zetahub.admin.file.validator.FileValidator;
import com.zetainteractive.zetahub.admin.service.ConfigurationService;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ActivitySearchCriteria;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentBO;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.file.service.FileService;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @author Venkata.Tummala
 *
 */
@RestController
@RequestMapping("/file")
public class FileController {

	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	FileService fileService;
	@Autowired
	ConfigurationService configurationsService;
	@Autowired
	private AudienceService audienceService;
	@Autowired
	DepartmentService departmentService;

	@Autowired
	FileValidator fileValidator;
	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;
	@Autowired
	private AudienceColumnTypeService audienceColumnTypeService;
	@Autowired
	FileActivityValidator fileActivityValidator;

	@Autowired
	AudienceMetadataService audienceMetadataService;

	@Autowired
	MessageSource messageSource;
	
	public static final String FILE = "admin";
	

	/**
	 * 
	 * @param dbSourceName
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(value = "/fetchTablesFromRemoteDB/{dbSourceName}", method = RequestMethod.GET)
	public ResponseEntity<?> fetchTablesFromRemoteDB(@PathVariable String dbSourceName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:fetchTablesFromRemoteDB()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<String>>(fileService.getTablesInfoFromRemoteDB(dbSourceName), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:fetchTablesFromRemoteDB", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch tables from the given DataBase", messageSource.getMessage(errorcode,
					new Object[] { dbSourceName }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param dbSourceName
	 * @param tableName
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(value = "/prepareSelectQueryOnTable/{dbSourceName}/{tableName}", method = RequestMethod.GET)
	public ResponseEntity<?> prepareSelectQueryOnTable(@PathVariable String dbSourceName,
			@PathVariable String tableName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:prepareSelectQueryOnTable()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			Map<String,String> res = new HashMap<>();
			res.put("query", fileService.prepareQueryOnSelectedTableOfRemoteDB(dbSourceName, tableName));
			return new ResponseEntity<Map<String,String>>(res, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:prepareSelectQueryOnTable", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to prepare select query on the given Database and table", messageSource
					.getMessage(errorcode, new Object[] { dbSourceName,tableName }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param requestData
	 * @return
	 * @throws Exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/executeSelectQueryOnTable", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> executeSelectQueryOnTable(@RequestBody Map<String, String> requestData,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:executeSelectQueryOnTable()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		String dbSourceName = "";
		String query = "";
		try {
			dbSourceName = requestData.get("dbSourceName");
			query = requestData.get("query");
			return new ResponseEntity<List<String[]>>(
					fileService.executeQueryOnSelectedTableOfRemoteDB(dbSourceName, query), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:executeSelectQueryOnTable", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to execute select query on the given Database", messageSource.getMessage(errorcode,
					new Object[] { dbSourceName, query }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param dbSourceName
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	@HystrixCommand
	@RequestMapping(value = "/getTableMetaData/{dbSourceName}/{tableName}", method = RequestMethod.GET)
	public ResponseEntity<?> getTableMetaData(@PathVariable String dbSourceName, @PathVariable String tableName,@RequestHeader HttpHeaders headers)
			throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:getTableMetaData()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<String[]>>(fileService.getTableMetaData(dbSourceName, tableName),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getTableMetaData", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch table metadata on the given Database and table", messageSource
					.getMessage(errorcode, new Object[] { dbSourceName, tableName }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="300000")})
	@RequestMapping(value = "/testFileSourceAndLoadFiles", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> testFileSourceAndLoadFiles(@RequestBody JSONObject obj,@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:testFileSourceAndLoadFiles()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if(!(Boolean)obj.get("isFiles"))
				return new ResponseEntity<Object>(fileService.testFileSourceAndLoadFiles((String)obj.get("fileSourceName"), (String)obj.get("filePath"), (Boolean)obj.get("isFiles")),
					HttpStatus.OK);
			else
				return new ResponseEntity<Object>(fileService.testFileSourceAndLoadFiles((String)obj.get("fileSourceName"), (String)obj.get("filePath"), (Boolean)obj.get("isFiles")),
						HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:testFileSourceAndLoadFiles", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			if (e instanceof FileSystemUtilException) {
				FileSystemUtilException ex = (FileSystemUtilException) e;
				errorcode = ((FileSystemUtilException) ex).getErrorCode();
			}
			resp.addError("Failed to test file source and load files", messageSource
					.getMessage(errorcode, new Object[] { (String)obj.get("fileSourceName") }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="300000")})
	@RequestMapping(value = "/testFileSourceAndLoadFilesWithDelimiter", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> testFileSourceAndLoadFilesWithDelimiter(@RequestBody JSONObject obj,@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:testFileSourceAndLoadFiles()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			int headerrow = 0,datarow = 0;
			if(obj.get("headerrow") instanceof Integer){
				headerrow = (Integer)obj.get("headerrow");
			}else if(obj.get("headerrow") instanceof String){
				headerrow = Integer.parseInt((String)obj.get("headerrow"));
			}
			if(obj.get("datarow") instanceof Integer){
				datarow = (Integer)obj.get("datarow");
			}else if(obj.get("datarow") instanceof String){
				datarow = Integer.parseInt((String)obj.get("datarow"));
			}
			if(!(Boolean)obj.get("isFiles"))
				return new ResponseEntity<Object>(fileService.testFileSourceAndLoadFiles((String)obj.get("fileSourceName"), (String)obj.get("filePath"), (Boolean)obj.get("isFiles"), headerrow,datarow,(String)obj.get("delimit"),(String)obj.get("textqualifier")),
					HttpStatus.OK);
			else
				return new ResponseEntity<Object>(fileService.testFileSourceAndLoadFiles((String)obj.get("fileSourceName"), (String)obj.get("filePath"), (Boolean)obj.get("isFiles"), headerrow,datarow,(String)obj.get("delimit"),(String)obj.get("textqualifier")),
						HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:testFileSourceAndLoadFiles", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			if (e instanceof FileSystemUtilException) {
				FileSystemUtilException ex = (FileSystemUtilException) e;
				errorcode = ((FileSystemUtilException) ex).getErrorCode();
			}
			resp.addError("Failed to test file source and load files", messageSource
					.getMessage(errorcode, new Object[] { (String)obj.get("fileSourceName") }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	@HystrixCommand
	@RequestMapping(value = "/getAllAudiences", method = RequestMethod.GET)
	public ResponseEntity<?> getAllAudiences(@RequestHeader HttpHeaders headers) throws AudienceException {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("Inside:getAllAudiences()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<List<AudienceBO>>(audienceService.listAudience(), HttpStatus.OK);
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */

	@HystrixCommand
	@RequestMapping(value = "/getAllFileSources", method = RequestMethod.GET)
	public ResponseEntity<?> getAllFileSources(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:getAllFileSources()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			ListingCriteria listingCriteria = new ListingCriteria();
			listingCriteria.setSortBy("ASC");
			return new ResponseEntity<List<FileSourceBO>>(configurationsService.listFileSources(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAudienceBaseColumns", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof AdminException) {
				AdminException ex = (AdminException) e;
				errorcode = ((AdminException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch all File sources",
					messageSource.getMessage(errorcode, new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	@HystrixCommand
	@RequestMapping(value = "/getAllDBSources", method = RequestMethod.GET)
	public ResponseEntity<?> getAllDBSources(@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:getAllDBSources()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ListingCriteria listingCriteria = new ListingCriteria();
		listingCriteria.setSortBy("ASC");
		try {
			return new ResponseEntity<List<DbSourceBO>>(configurationsService.listDBSources(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAudienceBaseColumns", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof AdminException) {
				AdminException ex = (AdminException) e;
				errorcode = ((AdminException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch all DB sources",
					messageSource.getMessage(errorcode, new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	@HystrixCommand
	@RequestMapping(value = "/getAllAddressTypes", method = RequestMethod.GET)
	public ResponseEntity<?> getAllAddressTypes(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Inside:getAllAddressTypes()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map<String, List<Object[]>>>(fileService.fetchAllAddresstypes(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAudienceBaseColumns", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof AdminException) {
				AdminException ex = (AdminException) e;
				errorcode = ((AdminException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch all Address types",
					messageSource.getMessage(errorcode, new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/*
	 * method for inserting data into file definition and file schedule
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="200000")})
	@RequestMapping(value = "/saveFileDefinition", method = RequestMethod.POST)
/*	public ResponseEntity<?> saveFileDefinition(@RequestParam("fileDefinitionBO") FileDefinitionBO fileDefinitionBO,@RequestParam("file") MultipartFile file,
			BindingResult bindingResult) {*/
	public ResponseEntity<?> saveFileDefinition(@RequestParam("fileDefinitionBO") String strFileDefJSON,@RequestParam(value = "file", required = false) MultipartFile file,@RequestHeader HttpHeaders headers) {
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			ObjectMapper om = new ObjectMapper();
			om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			FileDefinitionBO fileDefinitionBO = om.readValue(strFileDefJSON, FileDefinitionBO.class);
			if(fileDefinitionBO != null)
				try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", fileDefinitionBO.getFileDefinitionID()== null?0:fileDefinitionBO.getFileDefinitionID());}},"{", "}"));} catch (Exception e) {}
			else
				try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
			if(fileDefinitionBO != null && fileDefinitionBO.getFileSource() != null && fileDefinitionBO.getFileSource().getSourceType() != null){
				if(fileDefinitionBO.getFileSource().getSourceType().charValue() == 'D' && file == null){
					ResponseObject resp = new ResponseObject();
					resp.addError("", "Please Upload File");
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			BindingResult bindingResult = new BindException(fileDefinitionBO, "fileDefinitionBO");
			fileValidator.validate(fileDefinitionBO, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			List<CustomColumnDefinitionBO> columnBOs = new ArrayList<CustomColumnDefinitionBO>();
			if(fileDefinitionBO.getFileType()!=null && (fileDefinitionBO.getFileType()=='B' || fileDefinitionBO.getFileType()=='A')){
				columnBOs = fileService.fetchAudienceBaseColumns(fileDefinitionBO.getAudienceID());
			}else if (fileDefinitionBO.getFileType()!=null && fileDefinitionBO.getFileType()=='D'){
				columnBOs = fileService.fetchStagingTableColumns(fileDefinitionBO.getTableName());
			}
			fileValidator.validateLogicalColumns(columnBOs, fileDefinitionBO, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<FileDefinitionBO>(fileService.saveOrUpdateFileDefinition(fileDefinitionBO,file),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Failed to process file definition: " + e.getMessage(), e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/getAudienceBaseColumns/{audienceID}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAudienceBaseColumns(@PathVariable("audienceID") long audienceID,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<CustomColumnDefinitionBO>>(fileService.fetchAudienceBaseColumns(audienceID),HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAudienceBaseColumns", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			if (e instanceof AudienceException) {
				AudienceException ex = (AudienceException) e;
				errorcode = ((AudienceException) ex).getErrorCode();
			}
			resp.addError("Failed to fetch audience base columns",messageSource.getMessage(errorcode, new Object[] { audienceID }, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}

	/*
	 * method for file uploading with parameters headerStart,dataStart and
	 * delimiter
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="300000")})
	@RequestMapping(method = RequestMethod.POST, value = "/fileUpload")
	public ResponseEntity<?> fileUpload(@RequestParam("file") MultipartFile file,
			@RequestParam("headerStart") int headerStart, @RequestParam("dataStart") int dataStart,
			@RequestParam("delimiter") String delimiter,
			@RequestParam("textQualifier") String textQualifier,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (file != null && file.isEmpty()) {
				throw new FileException("FL0056");
			}
			if (headerStart >= dataStart) {
				throw new FileException("FL0057");
			}
			if(delimiter==null || !(",".equalsIgnoreCase(delimiter.trim()) ||
					"|".equalsIgnoreCase(delimiter.trim()) || "tab".equalsIgnoreCase(delimiter.trim()) || ";".equalsIgnoreCase(delimiter.trim()))){
				throw new FileException("FL0058");
			}
			if(textQualifier!=null && !("None".equalsIgnoreCase(textQualifier.trim()) || "\"".equalsIgnoreCase(textQualifier.trim()) ||  "\'".equalsIgnoreCase(textQualifier.trim()))){
				throw new FileException("FL0061");
			}
			return new ResponseEntity<Object>(
					fileService.fileUpload(file.getInputStream(), headerStart, dataStart, delimiter,textQualifier), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:fileUpload", e);
			String errorcode = "F00002";
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ex.getErrorCode();
			}
			resp.addError("Failed to upload the file",messageSource.getMessage(errorcode, new Object[] {}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * method for fetching all file definitions bases on a search criteria
	 */
	@HystrixCommand
	 @RequestMapping(method = RequestMethod.POST, value = "/getAllFileDefinitionsForTrigger", produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<?> getAllFileDefinitionsForTrigger(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
				ResponseObject resp = new ResponseObject();
				resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
				resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<HashMap<String, Object>>(fileService.getAllFileDefinitions(searchCriteria,true),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileDefinitionsForTrigger", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("Failed to get all the file definitions", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	 }
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/getAllFileDefinitions", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllFileDefinitions(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<HashMap<String, Object>>(fileService.getAllFileDefinitions(searchCriteria,false),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileDefinitions", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("Failed to get all the file definitions", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getFileDefinitionByID/{filedefId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getFileDefinitionByID(@PathVariable Long filedefId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", filedefId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<FileDefinitionBO>(fileService.getAllFileDefinitions(filedefId),
					HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("Failed to get the file definition by ID", messageSource.getMessage(ex.getErrorCode(), new Object[] {"definition",filedefId},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * method for inserting into File Activity
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveFileActivity", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveFileActivity(@RequestBody FileActivityBO fileActivityBO,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			fileActivityValidator.validate(fileActivityBO, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<Long>(fileService.saveFileActivity(fileActivityBO), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:saveFileActivity", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/*
	 * method for seleting entries from File Activity Criteria
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/getAllFileActivities")
	public ResponseEntity<?> getAllFileActivities(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(fileService.getAllFileActivities(searchCriteria),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileActivities", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="120000")})
	@RequestMapping(method = RequestMethod.POST, value = "/getallfileactivitiesbycriteria")
	public ResponseEntity<?> getAllFileActivitiesByCriteria(@RequestBody ActivitySearchCriteria searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(fileService.getAllFileActivities(searchCriteria),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileActivities", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/*
	 * method for seleting entry from File Activity by id
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getFileActivity/{id}")
	public ResponseEntity<?> getFileActivity(@PathVariable long id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<FileActivityBO>(fileService.getAllFileActivities(id), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getFileActivity", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getfileactivities/{id}")
	public ResponseEntity<?> getFileActivities(@PathVariable long id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<LinkedHashMap<Long, List<FileActivityBO>>>(
					fileService.getAllFileActivity(id), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getFileActivities", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getAllFileActivityByFileDefId/{id}")
	public ResponseEntity<?> getAllFileActivityByFileDefId(@PathVariable long id,@RequestHeader HttpHeaders headers) throws FileException{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", id);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<FileActivityBO>(fileService.getAllFileActivityByFileDefId(id), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileActivityByFileDefId", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * method for deleting entry from File Definition by id
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/deleteFileDefinition/{id}")
	public ResponseEntity<?> deleteFileDefinition(@PathVariable long id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", id);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try {
			fileService.deleteFileDefinition(id);
			resp.setMessage("File Definition deleted successfully.");
		    resp.setHttpStatusCode(HttpStatus.OK.value());
		    return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:deleteFileDefinition", e);
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("Failed to delete File defintion", messageSource.getMessage(ex.getErrorCode(), new Object[] {"definition",id},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * method for deleting entry from File Activity by id
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/deleteFileActivity/{id}")
	public ResponseEntity<?> deleteFileActivity(@PathVariable long id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		try {
			fileService.deleteFileActivity(id);
			resp.setMessage("File Activity deleted successfully.");
		    resp.setHttpStatusCode(HttpStatus.OK.value());
		    return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:deleteFileActivity", e);
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("Failed to delete File activity", messageSource.getMessage(ex.getErrorCode(), new Object[] {"activity",id},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Find all column type model.
	 *
	 * @return the list
	 * @throws AudienceException
	 *             the audience exception
	 */
	@HystrixCommand
	@RequestMapping("/getAllColumnTypes")
	public ResponseEntity<?> getAllColumnTypes(@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<List<ColumnTypeModelBO>>(audienceColumnTypeService.findAllColumnTypeModel(),HttpStatus.OK);
	}

	
	@HystrixCommand
	@RequestMapping("/getAllFileActivitiesByFileId/{filedefinitionid}")
	public ResponseEntity<?> getAllFileActivitiesByFileDefIDId(@PathVariable Long filedefinitionid,@RequestHeader HttpHeaders headers) throws Exception {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", filedefinitionid);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<String[]>>(fileService.getAllFileActivitiesByFileDefId(filedefinitionid),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileActivitiesByFileDefIDId", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	@HystrixCommand
	@RequestMapping(value = "/getAllFileDefinitionsByLogicalColumn/{logicalColumnName}/{logicalTableName}", method = RequestMethod.GET)
	public ResponseEntity<?> getAllFileDefinitionsByLogicalColumn(
			@PathVariable("logicalColumnName") String logicalColumnName,@PathVariable("logicalTableName") String logicalTableName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Long>(fileService.getAllFileDefinitionsLogicalColumnNames(logicalColumnName,logicalTableName),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileDefinitionsByLogicalColumn", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	@HystrixCommand
	@RequestMapping(value = "/getAllStagingTables", method = RequestMethod.GET)
	public ResponseEntity<?> getAllStagingTables(@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<PhysicalTableBO>>(audienceMetadataService.listStatingTables(),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllStagingTables", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("",
						messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * 
	 * @param listingCriteria
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getAllEncryptionKeys",method=RequestMethod.GET)
	public ResponseEntity<?> getAllEncryptionKeys(@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<EncryptionKeyBO>>(configurationsService.listEncryptionKeys(),HttpStatus.OK);
		} catch (AdminException e) {
			logger.error("Exception:getAllEncryptionKeys", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof AdminException) {
				AdminException ex = (AdminException) e;
				resp.addError("",
						messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	
	/**
	 * @param listingCriteria
	 * @param result
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getAllDepartments",method=RequestMethod.POST)
	public ResponseEntity<?> getAllDepartments(@RequestBody ListingCriteria listingCriteria,BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		ResponseObject resp = new ResponseObject();
		Map<Long,String> departments = new HashMap<Long,String>();
		try {
			List<DepartmentBO> departmentsList=departmentService.listDepartments(listingCriteria,bindingResult);
			if (bindingResult.hasErrors()) {
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}else{
				if(departmentsList!=null && !departmentsList.isEmpty()){
					for (DepartmentBO departmentBO : departmentsList) {
						departments.put(departmentBO.getDepartmentID(), departmentBO.getDepartmentName());
					}
				}
				return new ResponseEntity<>(departments, HttpStatus.OK);
			}
		} catch (AdminException ex) {
			logger.error("Error occurred while fetching departments", ex);
			resp.addError("Error occurred while fetching departments",
					messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * @param json
	 * @param bindingResult
	 * @return
	 */
	@HystrixCommand
	@RequestMapping(path="/getDepartmentNotifications/{departmentID}",method=RequestMethod.GET)
	public ResponseEntity<?> getDepartmentNotifications(@PathVariable Long departmentID,@RequestHeader HttpHeaders headers){
		/*try{
			Map<String,String> res = new HashMap<>();
			res.put("notifications", fileService.getDepartmentNotifications(departmentID));
			return new ResponseEntity<Map<String,String>>(res, HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof AdminException) {
				AdminException ex = (AdminException) e;
				resp.addError("",
						messageSource.getMessage(ex.getErrorCode(), new Object[] {}, LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}*/
		return null;
	}
	
	/*
	 * method for fetching all file definitions bases on a search criteria
	 */
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/getAllFileDefinitionsNames", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllFileDefinitionsNames(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Begin ::"+getClass().getName()+"getAllFileDefinitionsNames()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map<Long, String>>(fileService.getAllFileDefinitionsByID(searchCriteria),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllFileDefinitionsNames", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.GET, value = "/getAllTablesAndFiles/{sourceType}/{audienceID}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllTablesAndFiles(@PathVariable char sourceType,@PathVariable Long audienceID,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Begin ::"+getClass().getName()+"getAllTablesAndFiles()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<Object>>(fileService.getAllTablesAndFiles(sourceType, audienceID),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getAllTablesAndFiles", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(method = RequestMethod.POST, value = "/updateschedule", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateSchedule(@RequestBody FileScheduleBO bo,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Begin ::"+getClass().getName()+"updateSchedule()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+fileService.updateSchedule(bo)+"}", JSONObject.class),HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:updateSchedule", e);
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(ex.getErrorCode(), new Object[] { ex.getErrorMessage() },
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<?> processValidations(HttpMessageNotReadableException exception) {
		Object obj = exception.getCause();
		if (obj instanceof InvalidFormatException) {
			InvalidFormatException ie = (InvalidFormatException) obj;
			Reference me = ie.getPath().get(0);
			ResponseObject ro = new ResponseObject();
			ro.addError("invalid Form data", me.getFieldName() + " contains invalid data " + ie.getValue(),
					me.getFieldName());
			return new ResponseEntity<ResponseObject>(ro, HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (obj instanceof JsonMappingException) {
			JsonMappingException ie = (JsonMappingException) obj;
			Reference ref2 = ie.getPath().get(1);
			ResponseObject ro = new ResponseObject();
			ro.addError("invalid Form data", ref2.getFieldName() + " is invalid", ref2.getFieldName());
			return new ResponseEntity<ResponseObject>(ro, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return new ResponseEntity<String>("invalid Form Data", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/updateFileDefinitionStatus",method=RequestMethod.POST)
	public ResponseEntity<?> updateFileDefinitionStatus(@RequestBody Map<String, String> requestData,@RequestHeader HttpHeaders headers){
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		Long fileDefintionId;
		Character fileDefinitionStatus;
		ObjectMapper objectMapper=new ObjectMapper();
		FileSummaryBO fileSummaryBO;
		try {
			fileDefintionId = Long.parseLong(requestData.get("fileDefinitionId"));
			try {
				Map<String,Object> contextValues=new HashMap<>();
				contextValues.put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());
				contextValues.put("UID", ZetaUtil.getHelper().getUser().getUserID());
				contextValues.put("FILEDEFINITIONID",fileDefintionId);
				logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(),contextValues,"{","}"));
			}catch(Exception e){
				logger.error("Erorr while setting context string ::"+e.getMessage());
			}
			fileDefinitionStatus = requestData.get("fileDefinitionStatus").charAt(0);
			fileSummaryBO = objectMapper.readValue(requestData.get("fileSummaryBO"),FileSummaryBO.class);
			return new ResponseEntity<>(fileService.updateFileDefinitionStatus(fileDefintionId, fileDefinitionStatus,fileSummaryBO), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:updateFileDefinitionStatus", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to update file definition status", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/updateFileActivitystatus/{fileactivityid}/{status}",method=RequestMethod.GET)
	public ResponseEntity<?> updateFileActivitystatus(@PathVariable Character status,@PathVariable String fileactivityid,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("updateFileActivitystatus()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+fileService.updateFileActivitystatus(status, fileactivityid)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:updateFileActivitystatus", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to update FileActivity status", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/fileactivitybyfiledefinitionid/{filedifinitionid}",method=RequestMethod.GET)
	public ResponseEntity<?> existFileactivityByFiledefinitionId(@PathVariable Long filedifinitionid){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", filedifinitionid);}},"{", "}"));} catch (Exception e) {}
		logger.info("updateFileActivitystatus()");
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+fileService.existFileactivityByFiledefinitionId(filedifinitionid)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:fileactivitybyfiledefinitionid", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to update FileActivity status", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="300000")})
	@RequestMapping(path="/getverticadbtablecolumns/{tableName}",method=RequestMethod.GET)
	public ResponseEntity<?> getVerticaDbTableColumns(@PathVariable String tableName){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.debug("getVerticaDbTableColumns()");
		try {
			return new ResponseEntity<Object>(fileService.getTableColumns(tableName), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:getVerticaDbTableColumns", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to get Vertica DbTableColumns", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@HystrixCommand
	@RequestMapping(path="/updatefiledefinitionactivitystatus/{fileactivityid}/{status}/{filedefinitionId}",method=RequestMethod.GET)
	public ResponseEntity<?> updateFileDefinitionActivitystatus(@PathVariable Character status,@PathVariable String fileactivityid,@PathVariable long filedefinitionId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", filedefinitionId);}},"{", "}"));} catch (Exception e) {}
		logger.info("updateFileDefinitionActivitystatus()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+fileService.updateFileActivitystatus(status, fileactivityid,filedefinitionId)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:updatefiledefinitionactivitystatus", e);
			ResponseObject resp = new ResponseObject();
			String errorcode = "F00002";
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				errorcode = ((FileException) ex).getErrorCode();
			}
			resp.addError("Failed to update FileActivity status", messageSource.getMessage(errorcode,new Object[]{}, LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@SuppressWarnings("unused")
	@HystrixCommand
	@RequestMapping(path="/createzipfile",method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> createZipFile(@RequestBody FileActivityBO activityBO,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Begin :" + getClass().getName() + " :createzipfile()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		FileInputStream fis = null;
		try {
			File zipFile = new File(fileService.zipIt(activityBO.getIgnorefilePath()+File.separator+"Activity_"+activityBO.getFileActivityID()+"_"+new Date().getTime()+".zip", activityBO.getIgnorefilePath()));
			logger.info("FileController createZipFile :: zipFile AbsolutePAth ::"+zipFile.getAbsolutePath());
			if(zipFile == null){
				ResponseObject resp = new ResponseObject();
				resp.addError("", "file not found");
				return new ResponseEntity<Object>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<Object>(new HashMap<String,String>(){{put("response", zipFile.getAbsolutePath());}},HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception:createZipFile", e);
			ResponseObject resp = new ResponseObject();
			resp.addError("", "file downloading exception occurred");
			return new ResponseEntity<Object>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	
	@SuppressWarnings("unused")
	@HystrixCommand
	@RequestMapping(path="/downloadfileactivitylog",method=RequestMethod.POST, produces="application/zip")
	public ResponseEntity<?> downloadFileActivityLogFiles(@RequestParam("zipFilePath") String zipFilePath,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.DATA_IMPORT.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("FILEDEFINITIONID", 0);}},"{", "}"));} catch (Exception e) {}
		logger.info("Begin :" + getClass().getName() + " :downloadFileActivityLogFiles()");
		if (!AuthorizationUtil.authorize(headers, FILE, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {FILE},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		FileInputStream fis = null;
		File zipFile = null;
		try {
			zipFile = new File(zipFilePath);
			if(zipFile == null){
				ResponseObject resp = new ResponseObject();
				resp.addError("", "file not found");
				return new ResponseEntity<Object>(resp, HttpStatus.BAD_REQUEST);
			}
			return ResponseEntity
	                .ok()
	                .contentLength(zipFile.length())
	                .header("Cache-Control", "max-age=0")
	                .header("Content-disposition", "attachment;filename="+zipFile.getName())
	                .contentType(
	                        MediaType.parseMediaType("application/zip;charset=UTF-8"))
	                .body(new InputStreamResource(new FileInputStream(zipFile)));
		} catch (Exception e) {
			logger.error("Exception:downloadFileActivityLogFiles", e);
			ResponseObject resp = new ResponseObject();
			resp.addError("", "file downloading exception occurred");
			return new ResponseEntity<Object>(resp, HttpStatus.BAD_REQUEST);
		}finally {
			if(zipFile != null){
				zipFile.delete();
			}
		}
	}
}

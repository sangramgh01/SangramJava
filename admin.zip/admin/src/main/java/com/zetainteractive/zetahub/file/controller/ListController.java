/**
 * 
 */
package com.zetainteractive.zetahub.file.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.file.validator.FileValidator;
import com.zetainteractive.zetahub.admin.file.validator.ListAndFileValidator;
import com.zetainteractive.zetahub.admin.file.validator.ListValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.file.service.FileService;
import com.zetainteractive.zetahub.file.service.ListService;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * @author Paparao.Pandiri
 *
 */
@RestController
@RequestMapping("/list")
public class ListController {

	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	ListService listService;

	@Autowired
	ListValidator listValidator;
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	FileValidator fileValidator;
	
	@Autowired
	ListAndFileValidator listAndFileValidator;
	@Autowired
	FileService fileService;
	
	public static final String LIST = "list";

	
	/*
	 * method for selecting entries from AdhocList
	 */
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="300000")})
	@RequestMapping(value = "/getAllLists", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllLists(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map<String,Object>>(listService.getAllLists(searchCriteria), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	/*
	 * method for inserting entries in AdhocList
	 */
	@HystrixCommand
	@RequestMapping(value = "/saveList", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveList(@Valid @RequestBody ListDefinitionBO listDefinitionBO,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", listDefinitionBO.getListID()==null?0:listDefinitionBO.getListID());}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			listValidator.validate(listDefinitionBO, bindingResult);
			List<CustomColumnDefinitionBO> columnBOs = new ArrayList<CustomColumnDefinitionBO>();
			if(listDefinitionBO.getListType()!=null &&  listDefinitionBO.getAudienceID()!=null && (listDefinitionBO.getListType()=='G' || listDefinitionBO.getListType()=='T' || listDefinitionBO.getListType()=='S')){
				columnBOs = fileService.fetchAudienceBaseColumns(listDefinitionBO.getAudienceID());
			}
			fileValidator.validateLogicalColumns(columnBOs, listDefinitionBO, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<ListDefinitionBO>(listService.saveList(listDefinitionBO), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			if (e instanceof AudienceException) {
				AudienceException ex = (AudienceException) e;
				resp.addError("", messageSource.getMessage(((AudienceException) ex).getErrorCode(), new Object[] {listDefinitionBO.getAudienceID()},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="200000")})
	@RequestMapping(value = "/saveListAndFile", method = RequestMethod.POST)
	public ResponseEntity<?> saveFileAndListDefinition(@RequestParam("fileDefinitionBO") String strFileDefJSON,
			@RequestParam("listDefinitionBO") String strListDefJSON, @RequestParam(value = "file", required = false) MultipartFile file,@RequestHeader HttpHeaders headers) {
		//FileDefinitionBO fileDefinitionBO = listAndFile.getFileDefbo();
		//ListDefinitionBO listDefinitionBO = listAndFile.getListbo();
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_CREATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		Long audienceID = null;
		try {
			ObjectMapper om = new ObjectMapper();
			om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			FileDefinitionBO fileDefinitionBO = om.readValue(strFileDefJSON, FileDefinitionBO.class);
			try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String, Object>(3) {{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());if(fileDefinitionBO != null){put("LISTID",fileDefinitionBO.getFileDefinitionID()==null? 0:fileDefinitionBO.getFileDefinitionID());}else put("LISTID", 0);}}, "{", "}"));} catch (Exception e) {}
			logger.info("ListController :: saveFileAndListDefinition");
			ListDefinitionBO listDefinitionBO = om.readValue(strListDefJSON, ListDefinitionBO.class);
			if(fileDefinitionBO != null && fileDefinitionBO.getFileSource() != null && fileDefinitionBO.getFileSource().getSourceType() != null){
				if(fileDefinitionBO.getFileSource().getSourceType().charValue() == 'D' && file == null){
					ResponseObject resp = new ResponseObject();
					resp.addError("", "Please Upload File");
					return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			BindingResult bindingResult = new BindException(listDefinitionBO, "listDefinitionBO");
			listAndFileValidator.validate(listDefinitionBO, bindingResult);
			
			List<CustomColumnDefinitionBO> columnBOs = new ArrayList<CustomColumnDefinitionBO>();
			if(listDefinitionBO.getListType()!=null &&  listDefinitionBO.getAudienceID()!=null && (listDefinitionBO.getListType()=='G' || listDefinitionBO.getListType()=='T' || listDefinitionBO.getListType()=='S')){
				columnBOs = fileService.fetchAudienceBaseColumns(listDefinitionBO.getAudienceID());
			}
			listAndFileValidator.validateLogicalColumns(columnBOs, listDefinitionBO, bindingResult);
			if (bindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			BindingResult fileDefinitionBindingResult = new BindException(fileDefinitionBO, "fileDefinitionBO");
			listAndFileValidator.validateFileDefination(fileDefinitionBO, fileDefinitionBindingResult);
			if(fileDefinitionBO.getFileType()!=null && (fileDefinitionBO.getFileType()=='B' || fileDefinitionBO.getFileType()=='A')){
				columnBOs = fileService.fetchAudienceBaseColumns(fileDefinitionBO.getAudienceID());
			}else if (fileDefinitionBO.getFileType()!=null && fileDefinitionBO.getFileType()=='D'){
				columnBOs = fileService.fetchStagingTableColumns(fileDefinitionBO.getTableName());
			}
			listAndFileValidator.validateLogicalColumns(columnBOs, fileDefinitionBO, bindingResult);
			if (bindingResult.hasErrors() || fileDefinitionBindingResult.hasErrors()) {
				ResponseObject resp = new ResponseObject();
				resp.addErrors(bindingResult, "Invalid Data");
				resp.addErrors(fileDefinitionBindingResult, "Invalid Data");
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			audienceID = listDefinitionBO.getAudienceID();
			return new ResponseEntity<ListDefinitionBO>(listService.saveFileAndListDefinition(listDefinitionBO,fileDefinitionBO,file), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				if(((FileException) ex).getErrorCode().equals("FL0059")){
					resp.addError("", messageSource.getMessage("F00040", new Object[] {},LocaleContextHolder.getLocale()));
				}else{
					resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
				}
			}
			if (e instanceof AudienceException) {
				AudienceException ex = (AudienceException) e;
				resp.addError("", messageSource.getMessage(((AudienceException) ex).getErrorCode(), new Object[] {audienceID},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/*
	 * method for deleting entries in AdhocList by id
	 */
	@HystrixCommand
	@RequestMapping(value = "/deleteList/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> deleteList(@PathVariable("id") String id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", id);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map>(new ObjectMapper().readValue("{\"resultval\":"+listService.deleteAdhocList(id)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/restoretrash/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> restoreTrash(@PathVariable("id") String id,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+listService.restoreTrash(id)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/deletelistbyfolderid/{folderid}", method = RequestMethod.GET)
	public ResponseEntity<?> deleteListByFolderId(@PathVariable("folderid") String folderid,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_DELETE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(new ObjectMapper().readValue("{\"response\":"+listService.deleteListByFolderId(folderid)+"}", JSONObject.class), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/updateFolerOrCategory/{column}/{value}/{listId}/{deptID}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateFolerOrCategory(@PathVariable String column, @PathVariable String value,@PathVariable String listId,@PathVariable String deptID,@RequestHeader HttpHeaders headers)throws Exception{
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", listId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_UPDATE)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map>(new HashMap(){{put("resultval", listService.updateList(column, value, listId,deptID));}}, HttpStatus.OK);
		} catch(HttpClientErrorException e){
			JSONObject obj = new ObjectMapper().readValue(((HttpClientErrorException)e).getResponseBodyAsString(), JSONObject.class);
			return new ResponseEntity<JSONObject>(obj,HttpStatus.BAD_REQUEST);
		}catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {((FileException) ex).getErrorMessage()},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * method for selecting details of Column Defination by table type and
	 * audienceid
	 */
	@HystrixCommand
	@RequestMapping(value = "/getListByListTypeAudienceId/{type}/{audienceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getListByListTypeAudienceId(@PathVariable("type") char type,
			@PathVariable("audienceId") long audienceId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<ListDefinitionBO>>(
					listService.getListByListTypeAudienceId(type, audienceId), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/getTrashFolderList/{deptId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTrashFolderList(@PathVariable Long deptId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{{", "}}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<List<ListDefinitionBO>>(listService.getListByFolderId(deptId), HttpStatus.OK);
		} catch (FileException e){
			ResponseObject resp = new ResponseObject();
			FileException ex = (FileException) e;
			resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			resp.addError("", messageSource.getMessage("F00002", new Object[]{},LocaleContextHolder.getLocale()));
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@HystrixCommand
	@RequestMapping(value = "/findListByListName/{listName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findListByListName(@PathVariable String listName,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<ListDefinitionBO>(listService.findListByListName(listName), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/findlistbylistnamedeptid/{listName}/{deptId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findListByListNameDeptId(@PathVariable String listName,@PathVariable long deptId,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<ListDefinitionBO>(listService.findListByListName(listName,deptId), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand
	@RequestMapping(value = "/getemailslistbyid/{listId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getEmailsFromVericaDB(@PathVariable long listId,@RequestHeader HttpHeaders headers){
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", listId);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(listService.getEmailsFromVericaDB(listId), HttpStatus.OK);
		} catch (Exception e) {
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", e.getMessage());
			}else if(e instanceof AudienceException){
				AudienceException ex = (AudienceException) e;
				resp.addError("", ((AudienceException) e).getErrorMessage());
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand(commandProperties={
			@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="120000")
	})
	@RequestMapping(value = "/getalllistsids/{ids}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllListsByIds(@PathVariable String ids,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Object>(listService.getAllListsByIds(ids), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<?> processValidations(HttpRequestMethodNotSupportedException exception) {
		Object obj = exception.getCause();
		if (obj instanceof InvalidFormatException) {
			InvalidFormatException ie = (InvalidFormatException) obj;
			Reference me = ie.getPath().get(0);
			ResponseObject ro = new ResponseObject();
			ro.addError("invalid Form data", me.getFieldName() + " contains wrong data "+ie.getValue(), me.getFieldName());
			return new ResponseEntity<ResponseObject>(ro, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return new ResponseEntity<String>("invalid Form Data", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@HystrixCommand(commandProperties={@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="800000")})
	@RequestMapping(value = "/getAllListsForAPI", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllListsForAPI(@RequestBody Map<String, String> searchCriteria,@RequestHeader HttpHeaders headers) {
		try {logger.setContextString(new TagReplacement().replace(LoggerConstants.LIST.toString(), new HashMap<String,Object>(3){{put("CUSTCODE", ZetaUtil.getHelper().getCustomerID());put("UID", ZetaUtil.getHelper().getUser().getUserID());put("LISTID", 0);}},"{", "}"));} catch (Exception e) {}
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<Map<String,Object>>(listService.getAllListsForAPI(searchCriteria), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			ResponseObject resp = new ResponseObject();
			if (e instanceof FileException) {
				FileException ex = (FileException) e;
				resp.addError("", messageSource.getMessage(((FileException) ex).getErrorCode(), new Object[] {},
						LocaleContextHolder.getLocale()));
			}
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: getAllListsForAPI
	 * Description 	: The Method "getAllListsForAPI" is used for getting list type by using filedefinitionid. 
	 * Date    		: 14 Dec 2017, 16:13:33
	 * @param fileDefinitionId
	 * @param headers
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(value = "/getListTypeByFileDefId/{fileDefinitionId}", method = RequestMethod.GET)
	public ResponseEntity<?> getAllListsForAPI(@PathVariable Long fileDefinitionId,@RequestHeader HttpHeaders headers) {
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			return new ResponseEntity<String>(listService.getListTypeByFileDefId(fileDefinitionId), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			ResponseObject resp = new ResponseObject();
			resp.addError("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	/**
	 * 
	 * 
	 * Method Name 	: getListsByNames
	 * Description 	: The Method "getListsByNames" is used for get multiple lists at a time based on names
	 * Date    		: 15 Dec 2017, 17:38:59
	 * @param names
	 * @param headers
	 * @return
	 * @param  		:
	 * @return 		: ResponseEntity<?>
	 * @throws 		:
	 */
	@HystrixCommand
	@RequestMapping(value = "/getListsByNames", method = RequestMethod.POST)
	public ResponseEntity<?> getListsByNames(@RequestBody Set<String> names,@RequestHeader HttpHeaders headers) {
		if (!AuthorizationUtil.authorize(headers, LIST, com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
			ResponseObject resp = new ResponseObject();
			resp.addError("Unauthorized request ",messageSource.getMessage("E00007",new Object[] {LIST},LocaleContextHolder.getLocale()));
			resp.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
			return new ResponseEntity<>(resp, HttpStatus.UNAUTHORIZED);
		}
		try {
			if (names!= null && !names.isEmpty())
				return new ResponseEntity<>(listService.getListsByNames(names), HttpStatus.OK);
			else{
				ResponseObject resp = new ResponseObject();
				resp.addError("error","Provide valid list names.");
				return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
			}
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			ResponseObject resp = new ResponseObject();
			resp.addError("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

}

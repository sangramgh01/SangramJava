package com.zetainteractive.zetahub.file.dao;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.commons.domain.ActivityCollection;
import com.zetainteractive.zetahub.commons.domain.ActivitySearchCriteria;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface FileDao {
	public FileDefinitionBO saveFileDefinition(com.zetainteractive.zetahub.commons.domain.FileDefinitionBO fileDefintionBO) throws FileException;
	public FileDefinitionBO updateFileDefinition(com.zetainteractive.zetahub.commons.domain.FileDefinitionBO fileDefintionBO) throws FileException;
	public List<com.zetainteractive.zetahub.commons.domain.FileActivityBO> getAllFileActivities() throws FileException;
	public FileActivityBO getAllFileActivities(long fileactivityid) throws FileException;
	public boolean isFileDefinationExistWithName(String name,long departmentid) throws FileException;
	public long saveFileActivity(FileActivityBO fileActivityBO) throws FileException;
	public HashMap<String,Object> getAllFileDefinitions(Map<String,String> searchCriteria, boolean flag) throws FileException;
	public void deleteFileDefinition(long fileDefId) throws FileException;
	public void deleteFileActivity(long fileactivityid) throws FileException;
	public List<String[]> getAllFileActivitiesByFileDefId(long filedefinitionid) throws FileException;
	public Map<Long, List<FileActivityBO>> getAllFileActivities(Map<String, String> searchCriteria) throws FileException;
	public ActivityCollection getAllFileActivities(ActivitySearchCriteria searchCriteria) throws FileException;
	public long getAllFileDefinitionsLogicalColumnNames(String logicalTableName,String logicalColumnName)throws FileException;
	public boolean existTableName(String tableName,long filedefinitionId) throws FileException;
	public FileDefinitionBO getAllFileDefinitions(Long filedefId) throws FileException;
	public List<Object> getAllTablesAndFiles(char sourceType, Long audienceID) throws FileException;
	public int updateSchedule(FileScheduleBO fileScheduleBO) throws FileException;
	public LinkedHashMap<Long, List<FileActivityBO>> getAllFileActivity(long fileactivityid) throws FileException;
	public FileActivityBO getAllFileActivityByFileDefId(long filedefinitionId) throws FileException;
	public boolean updateFileActivitystatus(Character status,String fileactivityid) throws FileException;
	public boolean updateFileDefifinationStatus(Character status,long filedefinitionId) throws FileException;
	/**
	 * Verifying filEncryptionKey is used in Files or not
	 * 
	 * @param encryptionKey
	 * @return
	 * @throws AdminException
	 */
	public boolean isFilEncryptionExist(String encryptionKey) throws AdminException;
	/**
	 * Verifying keyName is used in FileSources or not
	 * @param sourceName
	 * @param type
	 * @return
	 * @throws AdminException
	 */
	public boolean veryfingFileSourceandDBSourceinFiles(String sourceName,char type) throws AdminException;
	public Long existFileactivityByFiledefinitionId(long filedefintionid) throws FileException;
	public Map<String, Long> getDomainWiseCount(String countQuery) throws FileException;
	public long checkAudienceExistInFileDefinitions(Long audienceId)throws FileException;
}

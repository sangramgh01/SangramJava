package com.zetainteractive.zetahub.file.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface ListDao {

	public ListDefinitionBO saveList(ListDefinitionBO listDefinitionBO) throws FileException;
	public int updateList(String column, String value,String listId) throws FileException;
	public int updateList(long folderID,String listId) throws FileException;
	public ListDefinitionBO getList(Long listID) throws FileException;
	public List<ListDefinitionBO> getAllListsOnCriteria(String searchCriteria) throws FileException;
	public boolean isListExists(String listName) throws FileException;
	public boolean deleteListOnId(String id) throws FileException;
	public boolean deleteList(String name) throws FileException;
	public  Map<String,Object> getAllLists(Map<String, String> searchCriteria,Long folderid) throws FileException;
	public  Map<String,Object> getAllListsForAPI(Map<String, String> searchCriteria) throws FileException;
	public int deleteAdhocList(String listid) throws FileException;
	public List<ListDefinitionBO> getListByListTypeAudienceId(char listType, long audienceId) throws FileException;
	public boolean existListName(String listName,long departmentid) throws FileException;
	public ListDefinitionBO findListByListName(String listName) throws FileException;
	public ListDefinitionBO findListByListName(String listName,long deptId) throws FileException, Exception;
	public List<ListDefinitionBO> getListByFolderId(Long folderId) throws FileException;
	public int restoreTrash(String listId) throws FileException;
	public int deleteListByFolderId(String folderid) throws FileException;
	public int updateListStatus(Long fileDefinitionId, Character status) throws FileException;
	public String getTableNameById(long listId) throws FileException;
	public Object getAllListsByIds(String ids) throws Exception;
	/**
	 * 
	 * 
	 * Method Name 	: getListTypeByFileDefId
	 * Description 	: The Method "getListTypeByFileDefId" is used for getting list type by using filedefinitionid.
	 * Date    		: 14 Dec 2017, 16:10:06
	 * @param fileDefinitionId
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getListTypeByFileDefId(long fileDefinitionId);
	
	/**
	 * 
	 * 
	 * Method Name 	: getListsByNames
	 * Description 	: The Method "getListsByNames" is used for 
	 * Date    		: 15 Dec 2017, 17:41:28
	 * @param names
	 * @return
	 * @param  		:
	 * @return 		: List<ListDefinitionBO>
	 * @throws 		:
	 */
	public List<ListDefinitionBO> getListsByNames(Set<String> names);
}

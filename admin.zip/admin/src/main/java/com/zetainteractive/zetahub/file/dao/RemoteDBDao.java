package com.zetainteractive.zetahub.file.dao;

import java.util.List;

import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface RemoteDBDao {
	public List<String> fetchTablesFromRemoteDB(DbSourceBO dbSourceBO) throws  FileException, Exception;
	public String prepareQuery(DbSourceBO dbSourceBO,String tableName) throws   FileException, Exception;
	public List<String[]> executeQuery(DbSourceBO dbSourceBO,String query,int rowNum)  throws  FileException, Exception;
	public List<String[]> getTableMetaData(DbSourceBO dbSourceBO,String tableName) throws FileException, Exception ;
}

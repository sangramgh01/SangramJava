package com.zetainteractive.zetahub.file.dao.impl;
/**
 * 
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.util.AdminDependencyCalls;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.ActivityCollection;
import com.zetainteractive.zetahub.commons.domain.ActivitySearchCriteria;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileActionMappingBO;
import com.zetainteractive.zetahub.commons.domain.FileActivitiesBO;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileFormatSpecBO;
import com.zetainteractive.zetahub.commons.domain.FileProcessingOptionsBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceSpecBO;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.commons.domain.Notifications;
import com.zetainteractive.zetahub.de.commons.domain.AlertBO;
import com.zetainteractive.zetahub.de.commons.domain.JobType;
import com.zetainteractive.zetahub.de.util.AlertingUtil;
import com.zetainteractive.zetahub.file.constants.Constants;
import com.zetainteractive.zetahub.file.dao.FileDao;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * @author Paparao.Pandiri
 *
 */
@Repository
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class FileDaoImpl implements FileDao {
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate template;
	
	@Autowired
	@Qualifier("whJdbc")
	JdbcTemplate wareHouseTemplate;
	
	@Autowired
	AdminDependencyCalls adminDependencyCalls;
	
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Override
	public void deleteFileDefinition(long fileDefId) throws FileException {
		try {
			logger.debug("Inside deleteFileDefinition()  "+getClass().getName());
			int result1 = template.update("delete from LFD_FILEDEFINITION where filedefinitionid = ?",fileDefId );
			int result2 = template.update("delete from LFD_FILESCHEDULE where filedefinitionid = ?",fileDefId );
			if(!(result1==1 & result2==1)){
				logger.error("NO file exist with given ID"+fileDefId);
				throw new FileException("FL0062");
			}
		} catch (Exception e) {
			if(e instanceof FileException){
				throw new FileException(((FileException) e).getErrorCode(),e);
			}else{
				throw new FileException("F00002",e);
			}
		}

	}

	@Override
	public FileDefinitionBO saveFileDefinition(FileDefinitionBO fileDefintionBO) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"saveFileDefinition()" );
			ObjectMapper mapper = new ObjectMapper();
			String fileformatspec = mapper.writeValueAsString(fileDefintionBO.getFileFormatSpec());
			String filemapping = mapper.writeValueAsString(fileDefintionBO.getFileMapping());
			String fileSource = mapper.writeValueAsString(fileDefintionBO.getFileSource());
			String unsubResubProperties = mapper.writeValueAsString(fileDefintionBO.getUnsubResubProperties());
			String fileProcessingOptions = mapper.writeValueAsString(fileDefintionBO.getFileProcessingOptions());
			String notifications = mapper.writeValueAsString(fileDefintionBO.getNotifications());
			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(
							"insert into LFD_FILEDEFINITION(name,departmentid,fileType,audienceid,status,scheduleactivemode,fileformatspec,fileSource,fileaction,filemapping,isfiletrigger,notifications,useencryption,encryptionkey,sendworkflow,workflowid,tableName,tableDisposition,unsubresubproperties,retrycount,maxfiles,channeltype,timezone,fileprocessingoptions,createdate,updatedate,createdby,updatedby) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp(),?,?)",
							Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, fileDefintionBO.getName());
					ps.setLong(2, fileDefintionBO.getDepartmentID());
					ps.setString(3, fileDefintionBO.getFileType() + "");
					ps.setLong(4, fileDefintionBO.getAudienceID());
					ps.setString(5, fileDefintionBO.getStatus() + "");
					ps.setString(6, fileDefintionBO.getScheduleactivemode() + "");
					ps.setString(7, fileformatspec);
					ps.setString(8, fileSource);
					ps.setString(9, fileDefintionBO.getFileAction().toString());
					ps.setString(10, filemapping);
					ps.setString(11, fileDefintionBO.getIsFileTrigger() + "");
					ps.setString(12, notifications);
					ps.setString(13, fileDefintionBO.getUseEncryption() + "");
					ps.setString(14, fileDefintionBO.getEncryptionKey());
					ps.setString(15, fileDefintionBO.getSendWorkFlow() + "");
					if (fileDefintionBO.getSendWorkFlow() == 'Y' && fileDefintionBO.getWorkFlowID() != null) {
						ps.setInt(16, fileDefintionBO.getWorkFlowID().intValue());
					} else {
						ps.setInt(16, 0);
					}

					ps.setString(17, fileDefintionBO.getTableName());
					ps.setString(18, fileDefintionBO.getTableDisposition());
					ps.setString(19, unsubResubProperties);
					if (fileDefintionBO.getRetryCount() != null) {
						ps.setLong(20, fileDefintionBO.getRetryCount());
					} else {
						ps.setLong(20, 0);
					}
					if (fileDefintionBO.getMaxFiles() != null) {
						ps.setInt(21, fileDefintionBO.getMaxFiles());
					} else {
						ps.setInt(21, 1);
					}
					ps.setString(22, fileDefintionBO.getChannelType() == null ? null
							: fileDefintionBO.getChannelType().toString());
					ps.setString(23, fileDefintionBO.getTimeZone());
					ps.setString(24, fileProcessingOptions);
					ps.setString(25, fileDefintionBO.getCreatedBy());
					ps.setString(26, fileDefintionBO.getUpdatedBy());
					return ps;
				}
			}, keyHolder);
			fileDefintionBO.setFileDefinitionID(keyHolder.getKey().longValue());
			logger.debug("savefiledefination id:: :: "+keyHolder.getKey().longValue()+"    "+fileDefintionBO.getWorkFlowID());
			FileScheduleBO fileScheduleBO = fileDefintionBO.getFileScheduleBO();
			if (fileScheduleBO != null && fileScheduleBO.getFrequency() != null) {
				keyHolder = new GeneratedKeyHolder();
				if(fileScheduleBO.getFrequency()!=null && fileScheduleBO.getFrequency() == 'N' && (fileScheduleBO.getFrequencyUnit() == null || fileScheduleBO.getFrequencyUnit() <= 0 ))
					throw new FileException("FL0014",new Object[] {"Execute every/Frequency unit","By Minutes"});
				template.update(new PreparedStatementCreator() {
					@Override
					public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
						PreparedStatement ps = con.prepareStatement(
								"insert into LFD_FILESCHEDULE(updatedate,filedefinitionid,frequency,timezone,schedulestartdate,scheduleenddate,schedulenextdue,frequencyunit,includedays,monthlyschdfreq,monthlyweekfreq,monthlydayfreq,dayofeverymonth,createdate,createdby,updatedby) values(utc_timestamp(),?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp(),?,?)",
								Statement.RETURN_GENERATED_KEYS);
						ps.setLong(1, fileDefintionBO.getFileDefinitionID());
						ps.setString(2,
								fileScheduleBO.getFrequency() != null ? fileScheduleBO.getFrequency() + "" : null);
						ps.setString(3, fileScheduleBO.getTimeZone());
						
						ps.setString(4,sd.format(fileScheduleBO.getScheduleStartDate()));
						ps.setString(5,sd.format(fileScheduleBO.getScheduleEndDate()));
						ps.setString(6, sd.format(fileScheduleBO.getSchedulenextdue()));
						
						ps.setLong(7,
								(fileScheduleBO.getFrequencyUnit() != null) ? fileScheduleBO.getFrequencyUnit() : 0);
						
						ps.setLong(8, (fileScheduleBO.getIncludeDays() != null) ? fileScheduleBO.getIncludeDays() : 0);
						ps.setString(9, (fileScheduleBO.getMonthlySchdFreq() != null)
								? fileScheduleBO.getMonthlySchdFreq() + "" : null);
						ps.setString(10, (fileScheduleBO.getMonthlyWeekFreq() != null)
								? fileScheduleBO.getMonthlyWeekFreq() + "" : null);
						ps.setString(11, (fileScheduleBO.getMonthlyDayFreq() != null)
								? fileScheduleBO.getMonthlyDayFreq() + "" : null);
						ps.setLong(12, (fileScheduleBO.getDayOfEveryMonth() != null)
								? fileScheduleBO.getDayOfEveryMonth() : 0);
						ps.setString(13, fileDefintionBO.getCreatedBy());
						ps.setString(14, fileDefintionBO.getUpdatedBy());
						return ps;
					}
				}, keyHolder);
				fileScheduleBO.setFileScheudleID(keyHolder.getKey().longValue());
			}
			logger.debug("End::"+getClass().getName()+"saveFileDefinition()" );
			return fileDefintionBO;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "saving");
		}
	}

	@Override
	public boolean existTableName(String tableName,long filedefinitionId) throws FileException {
		try {
			logger.debug("Inside existTableName()  "+getClass().getName());
			if(tableName == null || tableName.equals(""))
				return false;
			String table = template.queryForObject(
					"select tablename from LFD_FILEDEFINITION where tableName=? and fileaction='I' and filetype!='D' and filedefinitionId <> ?",
					new Object[] { tableName,filedefinitionId }, String.class);
			return (table.equalsIgnoreCase(tableName) == true) ? true : false;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean isScheduleExists(Long fileDefinitionID) throws FileException {
		try {
			Long ID = template.queryForObject("select filedefinitionid from LFD_FILESCHEDULE where filedefinitionid=?",
					new Object[] { fileDefinitionID }, Long.class);
			return (ID != null) ? true : false;
		} catch (EmptyResultDataAccessException ex) {
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public FileDefinitionBO updateFileDefinition(FileDefinitionBO fileDefintionBO) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"updateFileDefinition()  ");
			ObjectMapper mapper = new ObjectMapper();
			String fileformatspec = null;
			String filemapping = null;
			String fileSource = null;
			String unsubResubProperties = null;
			String fileProcessingOptions = null;
			String notifications = null;
			String fileSummary = null;
			if (fileDefintionBO.getFileFormatSpec() != null) {
				fileformatspec = mapper.writeValueAsString(fileDefintionBO.getFileFormatSpec());
			}
			if (fileDefintionBO.getFileMapping() != null) {
				filemapping = mapper.writeValueAsString(fileDefintionBO.getFileMapping());
			}
			if (fileDefintionBO.getFileSource() != null) {
				fileSource = mapper.writeValueAsString(fileDefintionBO.getFileSource());
			}
			if (fileDefintionBO.getUnsubResubProperties() != null) {
				unsubResubProperties = mapper.writeValueAsString(fileDefintionBO.getUnsubResubProperties());
			}
			if(fileDefintionBO.getFileProcessingOptions() != null){
				fileProcessingOptions = mapper.writeValueAsString(fileDefintionBO.getFileProcessingOptions());
			}
			if(fileDefintionBO.getNotifications() != null){
				notifications = mapper.writeValueAsString(fileDefintionBO.getNotifications());
			}
			if(fileDefintionBO.getFileSummaryBO() != null){
				fileSummary = mapper.writeValueAsString(fileDefintionBO.getFileSummaryBO());
			}

			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("update LFD_FILEDEFINITION set ");
			List<Object> params = new ArrayList<>();
			if (fileDefintionBO.getName() != null) {
				params.add(fileDefintionBO.getName());
				queryBuilder.append("name=?,");
			}
			if (fileDefintionBO.getDepartmentID() != null) {
				params.add(fileDefintionBO.getDepartmentID());
				queryBuilder.append("departmentid=?,");
			}

			if (fileDefintionBO.getFileType() != null) {
				params.add(fileDefintionBO.getFileType().toString());
				queryBuilder.append("fileType=?,");
			}

			if (fileDefintionBO.getAudienceID() != null) {
				params.add(fileDefintionBO.getAudienceID());
				queryBuilder.append("audienceid=?,");
			}

			if (fileDefintionBO.getStatus() != null) {
				params.add(fileDefintionBO.getStatus().toString());
				queryBuilder.append("status=?,");
			}

			if (fileDefintionBO.getScheduleactivemode() != null) {
				params.add(fileDefintionBO.getScheduleactivemode().toString());
				queryBuilder.append("scheduleactivemode=?,");
			}
			if (fileDefintionBO.getRetryCount() != null) {
				params.add(fileDefintionBO.getRetryCount());
				queryBuilder.append("retrycount=?,");
			}

			if (fileDefintionBO.getIsFileTrigger() != null) {
				params.add(fileDefintionBO.getIsFileTrigger().toString());
				queryBuilder.append("isfiletrigger=?,");
			}

			if(fileDefintionBO.getNotifications() != null){
				params.add(notifications);
				queryBuilder.append("notifications=?,");
			}
			
			if(fileDefintionBO.getFileAction() != null){
				params.add(fileDefintionBO.getFileAction().toString());
				queryBuilder.append("fileaction=?,");
			}
			if(fileDefintionBO.getTableDisposition() != null){
				params.add(fileDefintionBO.getTableDisposition());
				queryBuilder.append("tabledisposition=?,");
			}
			
			if(fileDefintionBO.getTableName() != null){
				params.add(fileDefintionBO.getTableName());
				queryBuilder.append("tablename=?,");
			}

			if (fileDefintionBO.getFileSource() != null) {
				params.add(fileSource);
				queryBuilder.append("filesource=?,");
			}
			if (fileDefintionBO.getFileMapping() != null) {
				params.add(filemapping);
				queryBuilder.append("filemapping=?,");
			}
			if (fileDefintionBO.getFileFormatSpec() != null) {
				params.add(fileformatspec);
				queryBuilder.append("fileformatspec=?,");
			}

			if (fileDefintionBO.getUnsubResubProperties() != null) {
				params.add(unsubResubProperties);
				queryBuilder.append("unsubResubProperties=?,");
			}
			if(fileDefintionBO.getFileProcessingOptions()!=null){
				params.add(fileProcessingOptions);
				queryBuilder.append("fileprocessingoptions=?,");
			}

			if (fileDefintionBO.getUseEncryption() != null) {
				params.add(fileDefintionBO.getUseEncryption().toString());
				queryBuilder.append("useencryption=?,");
			}

			if (fileDefintionBO.getEncryptionKey() != null) {
				params.add(fileDefintionBO.getEncryptionKey());
				queryBuilder.append("encryptionkey=?,");
			}else{
				if(fileDefintionBO.getUseEncryption() != null && fileDefintionBO.getUseEncryption() == 'N')
					queryBuilder.append("encryptionkey=NULL,");
			}
			if (fileDefintionBO.getSendWorkFlow() != null) {
				params.add(fileDefintionBO.getSendWorkFlow().toString());
				queryBuilder.append("sendworkflow=?,");
			}
			if (fileDefintionBO.getWorkFlowID() != null) {
				params.add(fileDefintionBO.getWorkFlowID());
				queryBuilder.append("workflowid=?,");
			}
			if (fileDefintionBO.getMaxFiles() != null) {
				params.add(fileDefintionBO.getMaxFiles());
				queryBuilder.append("maxfiles=?,");
			}
			if (fileDefintionBO.getTimeZone() != null) {
				params.add(fileDefintionBO.getTimeZone());
				queryBuilder.append("timezone=?,");
			}
			queryBuilder.append("updatedate=utc_timestamp(),");

			if (fileDefintionBO.getUpdatedBy() != null) {
				params.add(fileDefintionBO.getUpdatedBy());
				queryBuilder.append("updatedby=?,");
			}
			
			if(fileDefintionBO.getFileSummaryBO() != null){
				params.add(fileSummary);
				queryBuilder.append("filesummary=?,");
			}
			
			params.add(fileDefintionBO.getFileDefinitionID());
			template.update(
					queryBuilder.toString().substring(0, queryBuilder.toString().length() - 1)
							+ " where filedefinitionid = ?",params.toArray());			
			FileScheduleBO fileScheduleBO = fileDefintionBO.getFileScheduleBO();
			queryBuilder = new StringBuilder();
			boolean isScheduleExists = isScheduleExists(fileDefintionBO.getFileDefinitionID());
			if (isScheduleExists) {
				List<Object> args=new ArrayList<>();
				queryBuilder.append("update LFD_FILESCHEDULE set ");
				if (fileScheduleBO != null) {
					if (fileScheduleBO.getFrequency() != null) {
						args.add(fileScheduleBO.getFrequency().toString());
						queryBuilder.append("frequency=?,");
					}

					if (fileScheduleBO.getTimeZone() != null) {
						args.add(fileScheduleBO.getTimeZone());
						queryBuilder.append("timezone=?,");
					}

					if (fileScheduleBO.getScheduleStartDate() != null) {
						queryBuilder.append("schedulestartdate=").append("'")
								.append(new java.sql.Timestamp(fileScheduleBO.getScheduleStartDate().getTime()))
								.append("'").append(",");
					}

					if (fileScheduleBO.getScheduleEndDate() != null) {
						queryBuilder.append("scheduleenddate='").append(new java.sql.Timestamp(fileScheduleBO.getScheduleEndDate().getTime())).append("',");
					}

					if (fileScheduleBO.getSchedulenextdue() != null) {
						queryBuilder.append("schedulenextdue='").append(new java.sql.Timestamp(fileScheduleBO.getSchedulenextdue().getTime())).append("',");
					}

					if (fileScheduleBO.getFrequencyUnit() != null) {
						args.add(fileScheduleBO.getFrequencyUnit());
						queryBuilder.append("frequencyunit=?,");
					}

					if (fileScheduleBO.getIncludeDays() != null) {
						args.add(fileScheduleBO.getIncludeDays());
						queryBuilder.append("includedays=?,");
					}

					if (fileScheduleBO.getMonthlySchdFreq() != null) {
						args.add(fileScheduleBO.getMonthlySchdFreq().toString());
						queryBuilder.append("monthlyschdfreq=?,");
					}

					if (fileScheduleBO.getMonthlyWeekFreq() != null) {
						args.add(fileScheduleBO.getMonthlyWeekFreq().toString());
						queryBuilder.append("monthlyweekfreq=?,");
					}

					if (fileScheduleBO.getMonthlyDayFreq() != null) {
						args.add(fileScheduleBO.getMonthlyDayFreq().toString());
						queryBuilder.append("monthlydayfreq=?,");
					}

					if (fileScheduleBO.getDayOfEveryMonth() != null) {
						args.add(fileScheduleBO.getDayOfEveryMonth());
						queryBuilder.append("dayofeverymonth=?,");
					}
					queryBuilder.append("updatedate=").append("utc_timestamp()").append(",");

					if (fileScheduleBO.getUpdatedBy() != null) {
						args.add(fileScheduleBO.getUpdatedBy());
						queryBuilder.append("updatedby=?,");
					}
					if (fileScheduleBO.getCreatedBy() != null) {
						args.add(fileScheduleBO.getCreatedBy());
						queryBuilder.append("createdby=?,");
					}
					args.add(fileScheduleBO.getFileScheudleID());

					template.update(queryBuilder.toString().substring(0, queryBuilder.toString().length() - 1)
							+ " where filescheduleid = ?",args.toArray());
				}

			} else {
				if (fileScheduleBO != null && fileScheduleBO.getFrequency() != null) {
					KeyHolder keyHolder = new GeneratedKeyHolder();
					Timestamp scheduleStartDate = fileScheduleBO.getScheduleStartDate() == null?null:new Timestamp(fileScheduleBO.getScheduleStartDate().getTime());
					Timestamp scheduleEndDate = fileScheduleBO.getScheduleEndDate() == null?null:new Timestamp(fileScheduleBO.getScheduleEndDate().getTime());
					Timestamp scheduleNextDue = fileScheduleBO.getSchedulenextdue() == null?null:new Timestamp(fileScheduleBO.getSchedulenextdue().getTime());
					if(fileScheduleBO.getFrequency()!=null && fileScheduleBO.getFrequency() == 'N' && (fileScheduleBO.getFrequencyUnit() == null || fileScheduleBO.getFrequencyUnit() <= 0 ))
						throw new FileException("FL0014",new Object[] {"Execute every/Frequency unit","By Minutes"});
					template.update(new PreparedStatementCreator() {
						@Override
						public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
							PreparedStatement ps = con.prepareStatement(
									"insert into LFD_FILESCHEDULE(filedefinitionid,frequency,timezone,schedulestartdate,scheduleenddate,schedulenextdue,frequencyunit,includedays,monthlyschdfreq,monthlyweekfreq,monthlydayfreq,dayofeverymonth,createdate,updatedate,createdby,updatedby) values(?,?,?,'"+scheduleStartDate+"','"+scheduleEndDate+"','"+scheduleNextDue+"',?,?,?,?,?,?,utc_timestamp(),utc_timestamp(),?,?)",
									Statement.RETURN_GENERATED_KEYS);
							ps.setLong(1, fileDefintionBO.getFileDefinitionID());
							ps.setString(2,
									fileScheduleBO.getFrequency() != null ? fileScheduleBO.getFrequency() + "" : null);
							ps.setString(3, fileScheduleBO.getTimeZone());
							ps.setLong(4, (fileScheduleBO.getFrequencyUnit() != null)
									? fileScheduleBO.getFrequencyUnit() : 0);
							ps.setLong(5,
									(fileScheduleBO.getIncludeDays() != null) ? fileScheduleBO.getIncludeDays() : 0);
							ps.setString(6, (fileScheduleBO.getMonthlySchdFreq() != null)
									? fileScheduleBO.getMonthlySchdFreq() + "" : null);
							ps.setString(7, (fileScheduleBO.getMonthlyWeekFreq() != null)
									? fileScheduleBO.getMonthlyWeekFreq() + "" : null);
							ps.setString(8, (fileScheduleBO.getMonthlyDayFreq() != null)
									? fileScheduleBO.getMonthlyDayFreq() + "" : null);
							ps.setLong(9, (fileScheduleBO.getDayOfEveryMonth() != null)
									? fileScheduleBO.getDayOfEveryMonth() : 0);
							ps.setString(10, fileDefintionBO.getCreatedBy());
							ps.setString(11,
									(fileDefintionBO.getUpdatedBy() != null) ? fileDefintionBO.getUpdatedBy() : null);
							return ps;
						}
					}, keyHolder);
					fileScheduleBO.setFileScheudleID(keyHolder.getKey().longValue());
				}
			}
			logger.debug("End::"+getClass().getName()+"updateFileDefinition()" );
			return fileDefintionBO;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "updating");
		}
	}

	public boolean isFileDefinationExistWithName(String name,long departmentid) throws FileException {
		String fileDefName = null;
		try {
			logger.debug("Inside isFileDefinationExistWithName()  "+getClass().getName());
			fileDefName = template.queryForObject("select name from LFD_FILEDEFINITION where name = ? and departmentid=?", String.class,
					new Object[]{name,departmentid});
			if (fileDefName != null) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	private Object[] prepareSearchCriteria(Map<String, String> map, String tableAlias) throws Exception {
		Integer pageno = null;
		Integer pagesize = null;
		String search = "";
		String sortby = (tableAlias == "fd.") ? "filedefinitionid" : "fileactivityid";
		String sortorder = "ASC";
		Object[] output = new Object[5];
		if (map != null && !map.isEmpty()) {
			if (map.get("sortby") != null && (map.get("sortby").equalsIgnoreCase("createdon") || map.get("sortby").equalsIgnoreCase("name") || map.get("sortby").equalsIgnoreCase("createdby") || map.get("sortby").equalsIgnoreCase("createdate"))) {
				sortby = map.get("sortby").toString();
			}
			if (map.get("sortorder") != null && (map.get("sortorder").equalsIgnoreCase("asc") || map.get("sortorder").equalsIgnoreCase("desc"))) {
				sortorder = map.get("sortorder");
			}
			if (map.get("pageno") != null) {
				pageno = new Integer(map.get("pageno").toString());
			}
			if (map.get("pagesize") != null) {
				pagesize = new Integer(map.get("pagesize").toString());
			}
			String createdFromDate = "";
			String createdToDate = "";
			String updatedFromdate = "";
			String updatedTodate = "";
			if (map != null && !map.isEmpty()) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					String key = entry.getKey().trim();
					String value = entry.getValue().trim();
					if (key.equalsIgnoreCase("createdFromDate")) {
						if(value.isEmpty())
							throw new FileException("FL0078");
						createdFromDate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						createdFromDate = sdf.format(CommonUtil.toUTC(sdf.parse(createdFromDate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("createdToDate")) {
						if(value.isEmpty())
							throw new FileException("FL0079");
						createdToDate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						createdToDate = sdf.format(CommonUtil.toUTC(sdf.parse(createdToDate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("updatedFromdate")) {
						if(value.isEmpty())
							throw new FileException("FL0078");
						updatedFromdate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						updatedFromdate = sdf.format(CommonUtil.toUTC(sdf.parse(updatedFromdate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (key.equalsIgnoreCase("updatedTodate")) {
						if(value.isEmpty())
							throw new FileException("FL0079");
						updatedTodate = (String) value;
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						updatedTodate = sdf.format(CommonUtil.toUTC(sdf.parse(updatedTodate).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
					}
					if (!(key.equalsIgnoreCase("sortby") || key.equalsIgnoreCase("sortorder")
							|| key.equalsIgnoreCase("pageno") || key.equalsIgnoreCase("pagesize")
							|| key.equalsIgnoreCase("createdFromDate") || key.equalsIgnoreCase("createdToDate")
							|| key.equalsIgnoreCase("updatedFromdate") || key.equalsIgnoreCase("updatedTodate"))) {
						if (key.equals("id") && sortby.equals("filedefinitionid")) {
							key = "filedefinitionid";
						} else if (key.equals("namelike")) {
							key = "name";
						}
						String operator = key.equalsIgnoreCase("name") ? " like " : " = ";
						if (key.equalsIgnoreCase("name")) {
							search +=  tableAlias + key + operator + "'%" + value + "%'";
						} else {
							if(key.equals("id"))
								key = "filedefinitionid";
							search += tableAlias + key + operator + "'" + value + "'";
						}
						search += " and ";
					}
				}
			} 
			if (!"".equalsIgnoreCase(createdFromDate.trim()) && !"".equalsIgnoreCase(createdToDate.trim())) {
				search += tableAlias + "CREATEDATE  BETWEEN DATE_FORMAT('" + createdFromDate.trim()
						+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + createdToDate.trim() + "','%Y-%m-%d %H:%i:%s') and ";
			}
			if (!"".equalsIgnoreCase(updatedFromdate.trim()) && !"".equalsIgnoreCase(updatedTodate.trim())) {
				search +=  tableAlias + "UPDATEDATE  BETWEEN DATE_FORMAT('" + updatedFromdate.trim()
						+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + updatedTodate.trim() + "','%Y-%m-%d %H:%i:%s')  and ";
			}
			if (search != null && !"".equalsIgnoreCase(search)) {
				if (tableAlias == "fd.")
					search += " fd.filetype!='A'";
			} else {
				if (tableAlias == "fd.")
					search = " fd.filetype!='A' ";
			}
		}else {
			if (tableAlias == "fd.")
				search = " fd.filetype!='A' ";
		}
		output[0] = pageno;
		output[1] = pagesize;
		output[2] = search;
		output[3] = sortby;
		output[4] = sortorder;
		return output;

	}
	@Override
	public boolean isFilEncryptionExist(String encryptionKey) throws AdminException{
		logger.debug("Begin:" + getClass().getName() + ":isFilEncryptionExist(encryptionKey)");
		boolean isFilEncryptionExist  = false;
		try{
			String countQuery = "select count(1) from LFD_FILEDEFINITION where useencryption='Y' and encryptionkey =?";
			isFilEncryptionExist =  template.queryForObject(countQuery, Integer.class,encryptionKey)>0;
		}catch (Exception e) {
			logger.error("is File:: ", e);
			throw new AdminException("E00005");
		}
		logger.debug("Ends:" + getClass().getName() + ":isFilEncryptionExist(encryptionKey)");
		return isFilEncryptionExist;
	}
	
	@Override
	public boolean veryfingFileSourceandDBSourceinFiles(String sourceName,char type) throws AdminException{
		logger.debug("Begin:" + getClass().getName() + ":veryfingFileSourceandDBSourceinFiles(sourceName,type)");
		boolean isFound=false;
		try{
			ObjectMapper objectMapper=new ObjectMapper();
			List<String> filesources = template.queryForList("select filesource from LFD_FILEDEFINITION", String.class);
			if (filesources != null & filesources.size() > 0){
				for (String fileSource : filesources){
					fileSource=fileSource.replace("\\","\\\\");
						FileSourceSpecBO fileSourceSpecBO=objectMapper.readValue(fileSource, FileSourceSpecBO.class);
						if(fileSourceSpecBO.getSourceType()==type && fileSourceSpecBO.getSourceName() != null && fileSourceSpecBO.getSourceName().equals(sourceName)){
							isFound=true;
							break;
						}
					}
				}
			logger.debug("Ends:" + getClass().getName() + ":veryfingFileSourceandDBSourceinFiles(sourceName,type)");
			return isFound;
			
		}catch (Exception e) {
			logger.error("veryfingFileSourceandDBSourceinFiles:"+e.getMessage(), e);
			throw new AdminException("E00005");
		}

	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public HashMap<String, Object> getAllFileDefinitions(Map<String, String> searchCriteria, boolean isExists) throws FileException {
		logger.debug("Inside::"+getClass().getName()+"getAllFileDefinitions(searchCriteria,isExists)" );
		String departmentID = searchCriteria.get("departmentID");
		String countQuery = null;
		String selectQuery = null;
		
		if(departmentID == null){
			throw new FileException("FL0069");
		}
		try {
			searchCriteria.remove("departmentID");
			Object[] searchConditions = prepareSearchCriteria(searchCriteria, "fd.");
			
			
			Integer pageno = (Integer) searchConditions[0];
			Integer pagesize = (Integer) searchConditions[1];
		
			String sortBy=(String) searchConditions[3];
			
			String sortOrder=(String) searchConditions[4];
			String sorting= "fd."+sortBy+" "+sortOrder;
			if(isExists){
				countQuery = "select count(1) from LFD_FILEDEFINITION fd LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid where fd.tablename !='' and departmentid = ? and "+((searchConditions[2] != null) ? searchConditions[2] : "")+" order by "+sorting;
			}else{
				countQuery = "select count(1) from LFD_FILEDEFINITION fd LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid where departmentid = ? and "+((searchConditions[2] != null) ? searchConditions[2] : "")+" order by "+sorting;
			}
			int totalRecords = template.queryForObject(countQuery,new Object[]{departmentID}, Integer.class);
			int count = 0;
			int length = totalRecords;
			if (pageno != null && pagesize != null) {
				count = ((pageno - 1) * pagesize);
				length = count + pagesize;
				if (totalRecords < length) {
					length = totalRecords;
				}
			}
			if(pageno == null)pageno=0;
			if(pagesize == null) pagesize = totalRecords;
			if(isExists){
				selectQuery =  "select fd.filedefinitionid,fd.filesummary,fd.departmentid,fd.name,fd.filetype,fd.audienceid,fd.status,fd.scheduleactivemode,fd.fileformatspec,fd.filesource,fd.filemapping,fd.isfiletrigger,fd.notifications,fd.useencryption,fd.encryptionkey,fd.sendworkflow,fd.workflowid,fd.tablename,fd.tabledisposition,fd.unsubresubproperties,fd.retrycount,fd.fileaction,fd.createdate,fd.maxfiles,fd.updatedate,fd.createdby,fd.updatedby,fd.channeltype,fd.timezone tz,fd.fileprocessingoptions,"
								+ "fs.filescheduleid,fs.frequency,fs.timezone,fs.schedulestartdate,fs.scheduleenddate,fs.schedulenextdue,fs.frequencyunit,fs.includedays,fs.monthlyschdfreq,fs.monthlyweekfreq,fs.monthlydayfreq,fs.dayofeverymonth,fs.createdate,fs.updatedate,fs.createdby,fs.updatedby from LFD_FILEDEFINITION fd LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid  where fd.tablename !='' and fd.departmentid = ? and "
								+ ((searchConditions[2] != null) ? searchConditions[2] : "") + "order by "+sorting+" limit  ?,?";
			}else{
				selectQuery =  "select fd.filedefinitionid,fd.filesummary,fd.departmentid,fd.name,fd.filetype,fd.audienceid,fd.status,fd.scheduleactivemode,fd.fileformatspec,fd.filesource,fd.filemapping,fd.isfiletrigger,fd.notifications,fd.useencryption,fd.encryptionkey,fd.sendworkflow,fd.workflowid,fd.tablename,fd.tabledisposition,fd.unsubresubproperties,fd.retrycount,fd.fileaction,fd.createdate,fd.maxfiles,fd.updatedate,fd.createdby,fd.updatedby,fd.channeltype,fd.timezone tz,fd.fileprocessingoptions,"
								+ "fs.filescheduleid,fs.frequency,fs.timezone,fs.schedulestartdate,fs.scheduleenddate,fs.schedulenextdue,fs.frequencyunit,fs.includedays,fs.monthlyschdfreq,fs.monthlyweekfreq,fs.monthlydayfreq,fs.dayofeverymonth,fs.createdate,fs.updatedate,fs.createdby,fs.updatedby from LFD_FILEDEFINITION fd LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid  where fd.departmentid = ? and "
								+ ((searchConditions[2] != null) ? searchConditions[2] : "") + "order by "+sorting+" limit ?,?";
			}
			List<FileDefinitionBO> fileDefinitionBOs = template.query(selectQuery,new Object[]{departmentID,count,pagesize}, new RowMapper<FileDefinitionBO>() {
						@Override
						public FileDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
							FileDefinitionBO fileDefinitionBO = new FileDefinitionBO();
							fileDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
							fileDefinitionBO.setDepartmentID(rs.getLong("departmentid"));
							fileDefinitionBO.setAudienceID(rs.getLong("audienceid"));
							fileDefinitionBO.setFileType(rs.getString("filetype").charAt(0));
							fileDefinitionBO.setName(rs.getString("name"));
							fileDefinitionBO.setFileType(rs.getString("filetype").charAt(0));
							fileDefinitionBO.setScheduleactivemode(rs.getString("scheduleactivemode").charAt(0));
							fileDefinitionBO.setStatus(rs.getString("status").charAt(0));
							fileDefinitionBO.setRetryCount(rs.getInt("retrycount"));
							fileDefinitionBO.setIsFileTrigger(rs.getString("isfiletrigger").charAt(0));
							try {
								ObjectMapper objectMapper=new ObjectMapper();
								fileDefinitionBO.setFileSummaryBO(rs.getString("filesummary") != null ? objectMapper.readValue(rs.getString("filesummary"), FileSummaryBO.class) : null);
								fileDefinitionBO.setFileFormatSpec(objectMapper.readValue(rs.getString("fileformatspec"), FileFormatSpecBO.class));
								fileDefinitionBO.setFileSource(objectMapper.readValue(rs.getString("filesource"),
										FileSourceSpecBO.class));
								fileDefinitionBO.setFileMapping(objectMapper
										.readValue(rs.getString("filemapping"), FileActionMappingBO.class));
								fileDefinitionBO.setUnsubResubProperties(objectMapper
										.readValue(rs.getString("unsubresubproperties"), HashMap.class));
								fileDefinitionBO.setFileProcessingOptions(objectMapper
										.readValue(rs.getString("fileprocessingoptions"), FileProcessingOptionsBO.class));
								if(rs.getString("notifications") != null){
									fileDefinitionBO.setNotifications(objectMapper.readValue(rs.getString("notifications"), Notifications.class));
								}
							} catch (IOException e) {
								logger.error("Exception:FileDaoImpl internall bos:: ", e);
							}catch ( Exception ex) {
								logger.error("Exception:FileDaoImpl internall bos:: "+ex.getClass().getName(), ex);
							}
							fileDefinitionBO.setUseEncryption(rs.getString("useencryption").charAt(0));
							fileDefinitionBO.setEncryptionKey(rs.getString("encryptionkey"));
							fileDefinitionBO.setSendWorkFlow(rs.getString("sendworkflow").charAt(0));
							fileDefinitionBO.setTableName(rs.getString("tablename"));
							fileDefinitionBO.setTableDisposition(rs.getString("tabledisposition"));
							fileDefinitionBO.setWorkFlowID(rs.getLong("workflowid"));
							fileDefinitionBO.setFileAction(rs.getString("fileaction").charAt(0));
							fileDefinitionBO.setMaxFiles(rs.getInt("maxfiles"));
							fileDefinitionBO.setTimeZone(rs.getString("tz"));
							try {
								if(ZetaUtil.getHelper().getUser().getTimeZone() !=null && rs.getTimestamp("createdate")!=null)
									fileDefinitionBO.setCreateDate(convLocalTZ(rs.getString("createdate")));
								if(ZetaUtil.getHelper().getUser().getTimeZone()!=null && rs.getTimestamp("updatedate")!=null)
									fileDefinitionBO.setUpdateDate(convLocalTZ(rs.getString("updatedate")));
							} catch (Exception e) {
							}
							fileDefinitionBO.setCreatedBy(rs.getString("createdby"));
							fileDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
							fileDefinitionBO.setChannelType(
									rs.getString("channeltype") != null ? rs.getString("channeltype").charAt(0) : null);
							FileScheduleBO fileScheduleBO = new FileScheduleBO();
							fileScheduleBO.setFileScheudleID(rs.getLong("filescheduleid"));
							fileScheduleBO.setFileDefintionID(rs.getLong("filedefinitionid"));
							fileScheduleBO.setFrequency(
									rs.getString("frequency") != null ? rs.getString("frequency").charAt(0) : null);
							fileScheduleBO.setTimeZone(rs.getString("timezone"));
							try {
								if(rs.getString("schedulestartdate") != null && fileScheduleBO.getTimeZone() !=null){
									fileScheduleBO.setScheduleStartDate(convLocalTZ(rs.getString("schedulestartdate"),fileScheduleBO.getTimeZone()));
									fileScheduleBO.setSchedulenextdue(convLocalTZ(rs.getString("schedulenextdue"),fileScheduleBO.getTimeZone()));
									fileScheduleBO.setScheduleEndDate(convLocalTZ(rs.getString("scheduleenddate"),fileScheduleBO.getTimeZone()));
									fileScheduleBO.setCreateDate(convLocalTZ(rs.getString("createdate")));
									fileScheduleBO.setUpdateDate(convLocalTZ(rs.getString("updatedate")));
								}
							} catch (Exception e) {
								logger.error("Exception:FileDaoImpl utc to local time conversion:: ", e);
							}
							fileScheduleBO.setFrequencyUnit(rs.getInt("frequencyunit"));
							fileScheduleBO.setIncludeDays(rs.getInt("includedays"));
							fileScheduleBO.setMonthlySchdFreq((rs.getString("monthlyschdfreq") != null)
									? rs.getString("monthlyschdfreq").charAt(0) : '\0');
							fileScheduleBO.setMonthlyWeekFreq((rs.getString("monthlyweekfreq") != null)
									? rs.getString("monthlyweekfreq").charAt(0) : '\0');
							fileScheduleBO.setMonthlyDayFreq((rs.getString("monthlydayfreq") != null)
									? rs.getString("monthlydayfreq").charAt(0) : '\0');
							fileScheduleBO.setDayOfEveryMonth(rs.getInt("dayofeverymonth"));
							fileScheduleBO.setCreatedBy(rs.getString("createdby"));
							fileScheduleBO.setUpdatedBy(rs.getString("updatedby"));
							fileDefinitionBO.setFileScheduleBO(fileScheduleBO);
							return fileDefinitionBO;
						}
					});
			LinkedHashMap<Long, Long> activityStatus = null;
			if (fileDefinitionBOs != null && !fileDefinitionBOs.isEmpty()) {
				try {
					StringBuilder sb = new StringBuilder();
					for (Object object : fileDefinitionBOs) {
						FileDefinitionBO resultBo = (FileDefinitionBO) object;
						sb.append(resultBo.getFileDefinitionID() + ",");
					}
					List<Object> activites = template
							.query("select filedefinitionid,fileactivityid from LFD_FILEACTIVITY where filedefinitionid IN("
									+ sb.toString().substring(0, sb.toString().length() - 1) + ")", new RowMapper() {
										@Override
										public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
											return new Long[] { rs.getLong("filedefinitionid"),
													rs.getLong("fileactivityid") };
										}
									});
					activityStatus = new LinkedHashMap<>();
					for (Object object : fileDefinitionBOs) {
						FileDefinitionBO resultBo = (FileDefinitionBO) object;
						boolean flag = false;
						for (Object longsArray : activites) {
							Long[] longs = (Long[]) longsArray;
							if (longs[0] != null && (longs[0].longValue() == resultBo.getFileDefinitionID().longValue())) {
								activityStatus.put(resultBo.getFileDefinitionID(), longs[1]);
								flag = true;
								break;
							}
						}
						if (!flag) {
							activityStatus.put(resultBo.getFileDefinitionID(), 0L);
						}
					}


				} catch (Exception e) {
					logger.error("Exception:FileDaoImpl For getting fileactivity:: ", e);
					HashMap<String, Object> reult = new HashMap<String, Object>();
					reult.put("result", fileDefinitionBOs);
					reult.put("activies", activityStatus);
					reult.put("totalRecords", totalRecords);
					return reult;
				}
			}
			HashMap<String, Object> reult = new HashMap<String, Object>();
			reult.put("result", fileDefinitionBOs);
			reult.put("activies", activityStatus);
			reult.put("totalRecords", totalRecords);
			logger.debug("End::"+getClass().getName()+"getAllFileDefinitions(searchCriteria,isExists)" );
			return reult;
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}

	@Override
	public FileDefinitionBO getAllFileDefinitions(Long filedefId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileDefinitions()" );
				return (FileDefinitionBO)template.queryForObject(
						"select fd.filedefinitionid,fd.departmentid,fd.name,fd.filetype,fd.audienceid,fd.status,fd.scheduleactivemode,fd.fileformatspec,fd.filesource,fd.filemapping,fd.isfiletrigger,fd.notifications,fd.useencryption,fd.encryptionkey,fd.sendworkflow,fd.workflowid,fd.tablename,fd.tabledisposition,fd.unsubresubproperties,fd.retrycount,fd.fileaction,fd.createdate,fd.maxfiles,fd.updatedate,fd.createdby,fd.updatedby,fd.channeltype,fd.timezone tz,fd.fileprocessingoptions,"
								+ "fd.filesummary,fs.filescheduleid,fs.frequency,fs.timezone,fs.schedulestartdate,fs.scheduleenddate,fs.schedulenextdue,fs.frequencyunit,fs.includedays,fs.monthlyschdfreq,fs.monthlyweekfreq,fs.monthlydayfreq,fs.dayofeverymonth,fs.createdate,fs.updatedate,fs.createdby,fs.updatedby from LFD_FILEDEFINITION fd LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid  where fd.filedefinitionid = ? order by fd.filedefinitionid",
						new RowMapper<Object>() {
							@SuppressWarnings("unchecked")
							@Override
							public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
								ObjectMapper objectMapper=new ObjectMapper();
								FileDefinitionBO fileDefinitionBO = new FileDefinitionBO();
								fileDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
								fileDefinitionBO.setDepartmentID(rs.getLong("departmentid"));
								fileDefinitionBO.setAudienceID(rs.getLong("audienceid"));
								fileDefinitionBO.setFileType(rs.getString("filetype").charAt(0));
								fileDefinitionBO.setName(rs.getString("name"));
								fileDefinitionBO.setFileType(rs.getString("filetype").charAt(0));
								fileDefinitionBO.setScheduleactivemode(rs.getString("scheduleactivemode").charAt(0));
								fileDefinitionBO.setStatus(rs.getString("status").charAt(0));
								fileDefinitionBO.setRetryCount(rs.getInt("retrycount"));
								fileDefinitionBO.setIsFileTrigger(rs.getString("isfiletrigger").charAt(0));
								try {
									fileDefinitionBO.setFileSummaryBO(rs.getString("filesummary") != null ? objectMapper.readValue(rs.getString("filesummary"), FileSummaryBO.class) : null);
									fileDefinitionBO.setFileFormatSpec(objectMapper
											.readValue(rs.getString("fileformatspec"), FileFormatSpecBO.class));
									fileDefinitionBO.setFileSource(objectMapper.readValue(rs.getString("filesource"),
											FileSourceSpecBO.class));
									fileDefinitionBO.setFileMapping(objectMapper
											.readValue(rs.getString("filemapping"), FileActionMappingBO.class));
									fileDefinitionBO.setUnsubResubProperties(objectMapper
											.readValue(rs.getString("unsubresubproperties"), HashMap.class));
									fileDefinitionBO.setFileProcessingOptions(objectMapper
											.readValue(rs.getString("fileprocessingoptions"), FileProcessingOptionsBO.class));
									if(rs.getString("notifications") != null){
										fileDefinitionBO.setNotifications(objectMapper.readValue(rs.getString("notifications"), Notifications.class));
									}
									if(ZetaUtil.getHelper().getUser().getTimeZone() !=null && rs.getTimestamp("createdate")!=null)
										fileDefinitionBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
									if(ZetaUtil.getHelper().getUser().getTimeZone() !=null && rs.getTimestamp("updatedate")!=null)
										fileDefinitionBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								} catch (Exception e) {
								}
								fileDefinitionBO.setUseEncryption(rs.getString("useencryption").charAt(0));
								fileDefinitionBO.setEncryptionKey(rs.getString("encryptionkey"));
								fileDefinitionBO.setSendWorkFlow(rs.getString("sendworkflow").charAt(0));
								fileDefinitionBO.setTableName(rs.getString("tablename"));
								fileDefinitionBO.setTableDisposition(rs.getString("tabledisposition"));
								fileDefinitionBO.setWorkFlowID(rs.getLong("workflowid"));
								fileDefinitionBO.setFileAction(rs.getString("fileaction").charAt(0));
								fileDefinitionBO.setMaxFiles(rs.getInt("maxfiles"));
								fileDefinitionBO.setTimeZone(rs.getString("tz"));
								fileDefinitionBO.setCreatedBy(rs.getString("createdby"));
								fileDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
								fileDefinitionBO.setChannelType(
										rs.getString("channeltype") != null ? rs.getString("channeltype").charAt(0) : null);
								FileScheduleBO fileScheduleBO = new FileScheduleBO();
								fileScheduleBO.setFileScheudleID(rs.getLong("filescheduleid"));
								fileScheduleBO.setFileDefintionID(rs.getLong("filedefinitionid"));
								fileScheduleBO.setFrequency(
										rs.getString("frequency") != null ? rs.getString("frequency").charAt(0) : null);
								fileScheduleBO.setTimeZone(rs.getString("timezone"));
								try {
									if(rs.getString("schedulestartdate") != null && fileScheduleBO.getTimeZone() !=null){
										fileScheduleBO.setScheduleStartDate(convLocalTZ(rs.getString("schedulestartdate"),fileScheduleBO.getTimeZone()));
										fileScheduleBO.setSchedulenextdue(convLocalTZ(rs.getString("schedulenextdue"),fileScheduleBO.getTimeZone()));
										fileScheduleBO.setScheduleEndDate(convLocalTZ(rs.getString("scheduleenddate"),fileScheduleBO.getTimeZone()));
										fileScheduleBO.setCreateDate(convLocalTZ(rs.getString("createdate")));
										fileScheduleBO.setUpdateDate(convLocalTZ(rs.getString("updatedate")));
									}
								} catch (Exception e) {logger.error("Exception:FileDaoImpl utc to local time conversion:: ", e);}
								fileScheduleBO.setFrequencyUnit(rs.getInt("frequencyunit"));
								fileScheduleBO.setIncludeDays(rs.getInt("includedays"));
								fileScheduleBO.setMonthlySchdFreq((rs.getString("monthlyschdfreq") != null)
										? rs.getString("monthlyschdfreq").charAt(0) : '\0');
								fileScheduleBO.setMonthlyWeekFreq((rs.getString("monthlyweekfreq") != null)
										? rs.getString("monthlyweekfreq").charAt(0) : '\0');
								fileScheduleBO.setMonthlyDayFreq((rs.getString("monthlydayfreq") != null)
										? rs.getString("monthlydayfreq").charAt(0) : '\0');
								fileScheduleBO.setDayOfEveryMonth(rs.getInt("dayofeverymonth"));
								fileScheduleBO.setCreatedBy(rs.getString("createdby"));
								fileScheduleBO.setUpdatedBy(rs.getString("updatedby"));
								fileDefinitionBO.setFileScheduleBO(fileScheduleBO);
								return fileDefinitionBO;
							}
						}, new Object[] { filedefId });
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
				throw new FileException("FL0062",e);
		}
	}
	
	@Override
	public Map<Long, List<FileActivityBO>> getAllFileActivities(Map<String, String> map) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivities()" );
			Integer pageno = 1;
			Integer pagesize = null;
			if (map.get("pageno") != null) {
				pageno = new Integer(map.get("pageno").toString());
				map.remove("pageno");
			}
			if (map.get("pagesize") != null) {
				pagesize = new Integer(map.get("pagesize").toString());
				map.remove("pagesize");
			}
			StringBuilder search = new StringBuilder();
			if (map != null && !map.isEmpty()) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					String key = entry.getKey().trim();
					if(!(key.equals("startedFromDate") || key.equals("startedToDate") ||
							key.equals("completedFromDate") || key.equals("completedToDate"))){
						String value = entry.getValue().trim();
						if(search.toString().length() == 0 )
							search.append(" where ");
						else 
							search.append(" and ");
						search.append(key).append("='").append(value).append("' ");
					}else{
						if(key.contains("startedFromDate")){
							if(search.toString().length() == 0 )
								search.append(" where ");
							else 
								search.append(" and ");
							search.append("startedon BETWEEN DATE_FORMAT('" + (String) map.get("startedFromDate")
									+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + (String) map.get("startedToDate")
									+ "','%Y-%m-%d %H:%i:%s') ");
						}else if(key.contains("completedFromDate")){
							if(search.toString().length() == 0 )
								search.append(" where ");
							else 
								search.append(" and ");
							search.append("completedon BETWEEN DATE_FORMAT('" + (String) map.get("completedFromDate")
							+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + (String) map.get("completedToDate")
							+ "','%Y-%m-%d %H:%i:%s') ");
						}
					}
				}
			}
			int totalRecords = template.queryForObject("select count(1) from LFD_FILEACTIVITY " +((search.length() == 0) ?  "":search.toString())+ " order by fileactivityid ASC", Integer.class);
			int count = 0;
			int length = totalRecords;
			if (pageno != null && pagesize != null) {
				count = ((pageno - 1) * pagesize);
				length = count + pagesize;
				if (totalRecords < length) {
					length = totalRecords;
				}
			}
			if(pagesize == null)
				{
					pagesize = totalRecords;
				}
				
			Object[] params={count,pagesize};
			List<FileActivityBO> result = template.query(
					"select fileactivityid,filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby from LFD_FILEACTIVITY " +((search.length() == 0) ?  "":search.toString())+ " order by  fileactivityid ASC limit ?, ?",params,
					new FileActivityRowMapper() {});
			LinkedHashMap<Long, List<FileActivityBO>> activitiesByBatch = new LinkedHashMap<>();
			for (FileActivityBO object : result) {
				if (activitiesByBatch.get(object.getBatchId()) == null) {
					activitiesByBatch.put(object.getBatchId(), new ArrayList<FileActivityBO>() {
						{
							add(object);
						}
					});
				} else {
					activitiesByBatch.get(object.getBatchId()).add(object);
				}

			}
			logger.debug("End::"+getClass().getName()+"getAllFileActivities()" );
			return activitiesByBatch;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	@Override
	public ActivityCollection getAllFileActivities(ActivitySearchCriteria searchCriteria) throws FileException{
		try {
			List<Object> params= new ArrayList<>();
			params.add(searchCriteria.getDepartmentID());
			StringBuilder whereCondition = new StringBuilder();
			if (searchCriteria.getFileDefinitionID() != 0) {
				whereCondition.append("fa.filedefinitionid like ?");
				params.add("%"+searchCriteria.getFileDefinitionID()+"%");
			} else if (searchCriteria.getFiledefName() != null) {
				whereCondition.append("fd.name like ?");
				params.add("%"+searchCriteria.getFiledefName()+"%");
			} else if (searchCriteria.getFileactivityID() != 0) {
				whereCondition.append("fa.fileactivityid = ?");
//				params.add("%"+searchCriteria.getFileactivityID()+"%");
				params.add(searchCriteria.getFileactivityID());
			} else if (searchCriteria.getFileName() != null) {
				whereCondition.append("fa.filename like ?");
				params.add("%"+searchCriteria.getFileName()+"%");
			} else if (searchCriteria.getStatus() != '\0') {
				whereCondition.append("fa.status = ?");
				params.add(searchCriteria.getStatus()+"");
			} else if (searchCriteria.getStartedOnFrom() != null && searchCriteria.getStartedOnEnd() != null) {
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//				whereCondition.append("fa.startedon BETWEEN DATE_FORMAT('" + sdf.format(CommonUtil.toUTC(sdf.parse(searchCriteria.getStartedOnFrom()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())))
//									+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + sdf.format(CommonUtil.toUTC(sdf.parse(searchCriteria.getStartedOnEnd()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())))
//									+ "','%Y-%m-%d %H:%i:%s') ");
				whereCondition.append("fa.startedon BETWEEN '" +searchCriteria.getStartedOnFrom()+ "' and '"+ searchCriteria.getStartedOnEnd()+"'");
			} else if (searchCriteria.getCompletedOnFrom() != null && searchCriteria.getCompletedOnEnd() != null) {
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//				whereCondition.append("fa.startedon BETWEEN DATE_FORMAT('" + sdf.format(CommonUtil.toUTC(sdf.parse(searchCriteria.getCompletedOnFrom()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())))
//									+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + sdf.format(CommonUtil.toUTC(sdf.parse(searchCriteria.getCompletedOnEnd()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())))
//									+ "','%Y-%m-%d %H:%i:%s') ");
				whereCondition.append("fa.startedon BETWEEN '" +searchCriteria.getCompletedOnFrom()+ "' and '"+ searchCriteria.getCompletedOnEnd()+"'");
			} else if (searchCriteria.getBatchID() != 0) {
				whereCondition.append("fa.batchid = ?");
//				params.add("%"+searchCriteria.getBatchID()+"%");
				params.add(searchCriteria.getBatchID());
			}
			int totalRecords = template
					.queryForObject("select count(1) from (LFD_FILEACTIVITY fa LEFT JOIN LFD_FILEDEFINITION fd ON fa.filedefinitionid=fd.filedefinitionid) LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid where fd.departmentid= ? "+(whereCondition.toString().isEmpty()?"":"AND "+whereCondition.toString())+" order by "+searchCriteria.getSortBy()+" "+searchCriteria.getOrderBy(),params.toArray(),Integer.class);
			int count = 0;
			int length = totalRecords;
			int pageno = 0;
			int pageSize = 0;
			if (searchCriteria.getPageno() != 0)
				pageno = searchCriteria.getPageno();
			if (searchCriteria.getPageSize() != 0)
				pageSize = searchCriteria.getPageSize();
			if (pageno != 0 && pageSize != 0) {
				count = ((pageno - 1) * pageSize);
				length = count + pageSize;
				if (totalRecords < length) {
					length = totalRecords;
				}
			}
			if (pageSize == 0) {
				pageSize = totalRecords;
			}
			params.add(count);
			params.add(pageSize);
			List<FileActivitiesBO> result = template.query(
					"select fa.*,fd.name,fs.schedulenextdue from (LFD_FILEACTIVITY fa LEFT JOIN LFD_FILEDEFINITION fd ON fa.filedefinitionid=fd.filedefinitionid) LEFT JOIN LFD_FILESCHEDULE fs ON fd.filedefinitionid = fs.filedefinitionid where fd.departmentid= ? "+(whereCondition.toString().isEmpty()?"":"AND "+whereCondition.toString())+" order by "+searchCriteria.getSortBy()+" "+searchCriteria.getOrderBy()+" limit ?, ?",params.toArray(),
					new FileActivitiesRowMapper() {});
			return new ActivityCollection(result,totalRecords);
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FileActivityBO> getAllFileActivities() throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivities()" );
			return template.query(
					"select fileactivityid,filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby from LFD_FILEACTIVITY order by fileactivityid asc",new FileActivityRowMapper());
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}

	@Override
	public FileActivityBO getAllFileActivities(long fileactivityid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivities()" );
			FileActivityBO fb = new FileActivityBO();
			List<FileActivityBO> fileActivities = template.query(
					"select fileactivityid,filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby from LFD_FILEACTIVITY where fileactivityid= ? order by batchid asc",
					new FileActivityRowMapper(), new Object[] { fileactivityid });

			if(!fileActivities.isEmpty())
				fb = fileActivities.get(0);
			logger.debug("End::"+getClass().getName()+"getAllFileActivities()" );
			return fb;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
		
	@Override
	public boolean updateFileActivitystatus(Character status,String fileactivityid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"updateFileActivitystatus()" );
			FileActivityBO fb = new FileActivityBO();
			return template.update(
					"update LFD_FILEACTIVITY set status = ? where fileactivityid IN(?)",new Object[]{status.toString(),fileactivityid}) == 1?true:false;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	@Override
	public FileActivityBO getAllFileActivityByFileDefId(long filedefinitionId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivityByFileDefId()" );
			FileActivityBO fb = new FileActivityBO();
			List<FileActivityBO> fileActivities = template.query(
					"select fileactivityid,filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby from LFD_FILEACTIVITY where filedefinitionid= ?",
					new FileActivityRowMapper(), new Object[] { filedefinitionId });

			if(!fileActivities.isEmpty())
				fb = fileActivities.get(0);
			logger.debug("End::"+getClass().getName()+"getAllFileActivityByFileDefId()" );
			return fb;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	
	@Override
	public LinkedHashMap<Long, List<FileActivityBO>> getAllFileActivity(long fileactivityid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivity()" );
			List<FileActivityBO> fileActivities = template.query(
					"select fileactivityid,filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby from LFD_FILEACTIVITY where filedefinitionid= ? order by batchid asc",
					new FileActivityRowMapper(), new Object[] { fileactivityid });

			LinkedHashMap<Long, List<FileActivityBO>> activitiesByBatch = new LinkedHashMap<>();
			for (FileActivityBO object : fileActivities) {
				if (activitiesByBatch.get(object.getBatchId()) == null) {
					activitiesByBatch.put(object.getBatchId(), new ArrayList<FileActivityBO>() {
						{
							add(object);
						}
					});
				} else {
					activitiesByBatch.get(object.getBatchId()).add(object);
				}

			}
			logger.debug("End::"+getClass().getName()+"getAllFileActivity()" );
			return activitiesByBatch;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}

	}

	@Override
	public void deleteFileActivity(long fileactivityid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"deleteFileActivity()" );
			int count = template.update("delete from LFD_FILEACTIVITY where fileactivityid=?",new Object[] { fileactivityid });
			if(count!=1){
				logger.error("No file is exist with id"+fileactivityid);
				throw new FileException("");
			}
			logger.debug("End::"+getClass().getName()+"deleteFileActivity()" );
		} catch (Exception e) {
			if(e instanceof FileException){
				throw new FileException(((FileException) e).getErrorCode(),e);
			}else{
				throw new FileException("F00002",e);
			}
		}
	}

	@Override
	public long saveFileActivity(FileActivityBO fileActivityBO) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"saveFileActivity()" );
			if (fileActivityBO.getFileActivityID() == null) {
				KeyHolder keyHolder = new GeneratedKeyHolder();
				template.update(new PreparedStatementCreator() {
					@Override
					public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
						String	query = "insert into LFD_FILEACTIVITY(filedefinitionid,filename,status,message,startedon,completedon,filesummary,batchid,ignorefilepath,databaselogpath,activitysource,sourceinfo,createdate,updatedate,createdby,updatedby) values(?,?,?,?,utc_timestamp(),utc_timestamp(),?,?,?,?,?,?,utc_timestamp(),utc_timestamp(),?,?)";
						PreparedStatement ps = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
						ps.setLong(1, fileActivityBO.getFileDefinitionID());
						ps.setString(2, fileActivityBO.getFileName());
						ps.setString(3, fileActivityBO.getStatus() + "");
						ps.setString(4, fileActivityBO.getMessage());
						if(fileActivityBO.getFileSummaryBO() != null){
							try {
								ps.setString(5, new ObjectMapper().writeValueAsString(fileActivityBO.getFileSummaryBO()));
							} catch (JsonProcessingException e) {ps.setString(5,null);}
						}else{
							ps.setString(5,null);
						}
						ps.setLong(6, fileActivityBO.getBatchId());
						ps.setString(7, fileActivityBO.getIgnorefilePath());
						ps.setString(8, fileActivityBO.getDatabaseLogPath());
						if(fileActivityBO.getActivitySource()==null)
							ps.setString(9, null);
						else
							ps.setString(9, (fileActivityBO.getActivitySource() + "").substring(0,1));
						ps.setString(10, fileActivityBO.getSourceInfo());
						ps.setString(11, fileActivityBO.getCreatedBy());
						ps.setString(12, fileActivityBO.getUpdatedBy());
						return ps;
					}
				}, keyHolder);
				
				if(fileActivityBO.getStatus()==Constants.FILE_TYPE_ERRORED || fileActivityBO.getStatus() == Constants.FILE_TYPE_SKIPPED){
				  logger.debug("Activity Status ::"+fileActivityBO.getStatus());
					try{
						fileActivityBO.setFileActivityID(keyHolder.getKey().longValue());
						sendAlert(fileActivityBO);
					}catch(Exception e){
						logger.error("Error sending alert :: "+e.getMessage());
					}
				}
				logger.debug("End::"+getClass().getName()+"saveFileActivity()" );
				
				return keyHolder.getKey().longValue();
			} else {
				StringBuilder queryBuilder = new StringBuilder();
				List<Object> params= new ArrayList<Object>();
				queryBuilder.append("update LFD_FILEACTIVITY set ");
				if (fileActivityBO.getFileName() != null) {
					//If file name contains single quote query splitting as two parts due to that file name replacing with escape character.   
					queryBuilder.append("filename=?,");
					params.add(fileActivityBO.getFileName().replaceAll("'","\\\\'"));
				}
				if (fileActivityBO.getStatus() != null) {
					queryBuilder.append("status=?,");
					params.add(fileActivityBO.getStatus().toString());
				}
				if (fileActivityBO.getMessage() != null) {
					queryBuilder.append("message= ?,");
					params.add(fileActivityBO.getMessage());
				}
				/*if (fileActivityBO.getStartedOn() != null) {
					Timestamp startedDate = CommonUtil.toUTC(fileActivityBO.getStartedOn().getTime(), TimeZone.getTimeZone(userBO.getTimeZone()));
					queryBuilder.append("startedon=").append("'").append(startedDate).append("'")
							.append(",");
				}*/
				if (fileActivityBO.getCompletedOn() != null) {
					queryBuilder.append("completedon=").append("utc_timestamp()").append(",");
				}
				if (fileActivityBO.getFileSummaryBO() != null) {
					queryBuilder.append("filesummary=?,");
					params.add(new ObjectMapper().writeValueAsString(fileActivityBO.getFileSummaryBO()));
				}
				if (fileActivityBO.getBatchId() != null) {
					queryBuilder.append("batchid=?,");
					params.add(fileActivityBO.getBatchId());
				}
				if (fileActivityBO.getIgnorefilePath() != null) {
					queryBuilder.append("ignorefilepath= ?,");
					params.add(fileActivityBO.getIgnorefilePath());
				}
				if (fileActivityBO.getDatabaseLogPath() != null) {
					queryBuilder.append("databaselogpath=?,");
					params.add(fileActivityBO.getDatabaseLogPath());
				}
				if (fileActivityBO.getActivitySource() != null) {
					queryBuilder.append("activitysource=?,");
					params.add(fileActivityBO.getActivitySource().toString());
				}
				if (fileActivityBO.getSourceInfo() != null) {
					queryBuilder.append("sourceinfo=?,");
					params.add(fileActivityBO.getSourceInfo());
				}
				queryBuilder.append("updatedate=").append("utc_timestamp()").append(",");
				if (fileActivityBO.getUpdatedBy() != null) {
					queryBuilder.append("updatedby= ?,");
					params.add(fileActivityBO.getUpdatedBy());
				}
				if (fileActivityBO.getCreatedBy() != null) {
					queryBuilder.append("createdby=?");
					params.add(fileActivityBO.getCreatedBy());
				}
                params.add(fileActivityBO.getFileActivityID());
				template.update(queryBuilder.toString() + " where fileactivityid = ?",
						params.toArray());
				
				if(fileActivityBO.getStatus()==Constants.FILE_TYPE_ERRORED || fileActivityBO.getStatus() == Constants.FILE_TYPE_SKIPPED){
					logger.debug("Activity Status ::"+fileActivityBO.getStatus());
					try{
						sendAlert(fileActivityBO);
					}catch(Exception e){
						logger.error("Error sending alert :: "+e.getMessage());
					}
				}
			}
			
			logger.debug("End::"+getClass().getName()+"saveFileActivity()" );
			return fileActivityBO.getFileActivityID();
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "updating",e);
		}
	}

	/**
	 * @param fileActivityBO
	 * @throws Exception
	 */
	private void sendAlert(FileActivityBO fileActivityBO) throws Exception {
		logger.debug("Sending JIRA Alert for FileDefId :: " + fileActivityBO.getFileDefinitionID() + " File Activity ID :: "+fileActivityBO.getFileActivityID());
		try {
			AlertBO alertBO = new AlertBO();
			alertBO.setFileDefinitionID(fileActivityBO.getFileDefinitionID());
			alertBO.setCauseType(fileActivityBO.getStatus().toString());
			alertBO.setCause(fileActivityBO.getMessage());
			alertBO.setCustCode(ZetaUtil.getHelper().getCustomerID());	
			alertBO.setFileActivityId(fileActivityBO.getFileActivityID());
			alertBO.setJobType(JobType.DATAIMPORT.toString());
			AlertingUtil alertingUtil = new AlertingUtil();
			alertingUtil.sendAlert(alertBO);
			logger.debug("Sent JIRA Alert for FileDefId :: " + fileActivityBO.getFileDefinitionID() + " File Activity ID :: "+fileActivityBO.getFileActivityID());
		} catch (Exception e) {
			logger.error("Error occurred while sending JIRA alert :: " + e.getMessage());
		}
	}

	public List<List<ColumnDefinitionBO>> getColumnDefinitions(List<String> tableNames) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getColumnDefinitions()" );
			List<List<ColumnDefinitionBO>> bosList = null;
			StringBuilder builder = new StringBuilder();
			for (String tableName : tableNames) {
				builder.append("'").append(tableName).append("',");
			}
			
			List<String> filemappings = template
					.queryForList(
							"select filemapping from LFD_FILEDEFINITION where tablename IN("
									+ builder.toString().substring(0, builder.toString().length() - 1) + ")",
							String.class);
			if (filemappings != null & filemappings.size() > 0) {
				ObjectMapper mapper = new ObjectMapper();
				bosList = new ArrayList<List<ColumnDefinitionBO>>();
				for (String filemapping : filemappings) {
					FileActionMappingBO fileActionMappingBO = mapper.readValue(filemapping, FileActionMappingBO.class);
					List<ColumnDefinitionBO> bos = fileActionMappingBO.getColumnDefinitionList();
					bosList.add(bos);
				}
			}
			logger.debug("End::"+getClass().getName()+"getColumnDefinitions()" );
			return bosList;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "updating");
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String[]> getAllFileActivitiesByFileDefId(long filedefinitionid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileActivitiesByFileDefId()" );
			return template.query("select fileactivityid,filename from LFD_FILEACTIVITY where filedefinitionid = ?",
					new Object[] { filedefinitionid }, new RowMapper() {
						List<String[]> list = new ArrayList<String[]>();

						@Override
						public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
							String[] array = new String[2];
							array[0] = rs.getLong("fileactivityid") + "";
							array[1] = rs.getString("filename");
							list.add(array);
							return list;
						}
					});
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}

	@Override
	public long getAllFileDefinitionsLogicalColumnNames(String logicalTableName,String logicalColumnName) throws FileException {
		long count = 0;
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllFileDefinitionsLogicalColumnNames()" );
			if (logicalTableName != null && logicalColumnName != null) {
				List<String> fileMappings = template.queryForList("select fileMapping from LFD_FILEDEFINITION",
						String.class);
				
				for (String fileDef : fileMappings) {
					try {
						List<ColumnDefinitionBO> bos = (new ObjectMapper()
								.readValue(fileDef, FileActionMappingBO.class))
								.getColumnDefinitionList();
						for (ColumnDefinitionBO columnDefinitionBO : bos) {
							if (logicalTableName.equals(columnDefinitionBO.getLogicalTableName())
									&& logicalColumnName.equals(columnDefinitionBO.getLogicalColumnName())) {
								count++;
							}
						}
					} catch (Exception e) {
						logger.error("Exception:FileDaoImpl :: getAllFileDefinitionsLogicalColumnNames() : " + fileDef,
								e);
					}
				}
			}
			logger.debug("End::"+getClass().getName()+"getAllFileDefinitionsLogicalColumnNames()" );
			return count;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getAllTablesAndFiles(char sourceType, Long audienceID) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getAllTablesAndFiles()" );
			String query = "";
			List<Object> response = null;
			if (sourceType == 'T') {
				query = "select filedefinitionid,tablename from LFD_FILEDEFINITION where audienceid = ? and tablename is not null and  (status='C' or (status='W' and filedefinitionid IN (SELECT distinct filedefinitionid FROM LFD_FILEACTIVITY fa where fa.status='C')))";
				response = template.query(query, new RowMapper() {
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						return new Object[] { rs.getLong("filedefinitionid"), rs.getString("tablename") };
					}
				}, new Object[] { audienceID });

			} else {
				query = "select filedefinitionid,name from LFD_FILEDEFINITION where audienceid = ? and (status='C' or (status='W' and filedefinitionid IN (SELECT distinct filedefinitionid FROM LFD_FILEACTIVITY fa where fa.status='C')))";
				response = template.query(query, new RowMapper() {
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						return new Object[] { rs.getLong("filedefinitionid"), rs.getString("name") };
					}
				}, new Object[] { audienceID });
			}
			logger.debug("End::"+getClass().getName()+"getAllTablesAndFiles()" );
			return response;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}

	}
	
	@Override
	public int updateSchedule(FileScheduleBO fileScheduleBO) throws FileException{
	try{
		logger.debug("Inside::"+getClass().getName()+"updateSchedule()" );
		StringBuilder queryBuilder = new StringBuilder();
		List<Object> params=new ArrayList<>();
			queryBuilder.append("update LFD_FILESCHEDULE set ");
				if (fileScheduleBO.getFrequency() != null) {
					params.add(fileScheduleBO.getFrequency().toString());
					queryBuilder.append("frequency=?,");
				}

				if (fileScheduleBO.getTimeZone() != null) {
					params.add(fileScheduleBO.getTimeZone());
					queryBuilder.append("timezone=?,");
				}

				if (fileScheduleBO.getScheduleStartDate() != null) {
					params.add(new java.sql.Timestamp(fileScheduleBO.getScheduleStartDate().getTime()));
					queryBuilder.append("schedulestartdate=?,");
				}

				if (fileScheduleBO.getScheduleEndDate() != null) {
					params.add(fileScheduleBO.getScheduleEndDate());
					queryBuilder.append("scheduleenddate=?,");
				}

				if (fileScheduleBO.getSchedulenextdue() != null) {
					params.add(fileScheduleBO.getScheduleEndDate());
					queryBuilder.append("schedulenextdue=?,");
				}

				if (fileScheduleBO.getFrequencyUnit() != null) {
					params.add(fileScheduleBO.getFrequencyUnit());
					queryBuilder.append("frequencyunit=?,");
				}

				if (fileScheduleBO.getIncludeDays() != null) {
					params.add(fileScheduleBO.getIncludeDays());
					queryBuilder.append("includedays=?,");
				}

				if (fileScheduleBO.getMonthlySchdFreq() != null) {
					params.add(fileScheduleBO.getMonthlySchdFreq().toString());
					queryBuilder.append("monthlyschdfreq=?,");
					
				}

				if (fileScheduleBO.getMonthlyWeekFreq() != null) {
					params.add(fileScheduleBO.getMonthlyWeekFreq().toString());
					queryBuilder.append("monthlyweekfreq=?,");
				}

				if (fileScheduleBO.getMonthlyDayFreq() != null) {
					params.add(fileScheduleBO.getMonthlyDayFreq().toString());
					queryBuilder.append("monthlydayfreq=?,");
				}

				if (fileScheduleBO.getDayOfEveryMonth() != null) {
					params.add(fileScheduleBO.getDayOfEveryMonth());
					queryBuilder.append("dayofeverymonth=?,");
				}
				if (fileScheduleBO.getUpdateDate() != null) {
					params.add(fileScheduleBO.getUpdateDate());
					queryBuilder.append("updatedate=?,");
				}
				if (fileScheduleBO.getUpdatedBy() != null) {
					params.add(fileScheduleBO.getUpdatedBy());
					queryBuilder.append("updatedby=?,");
				}
				params.add(fileScheduleBO.getFileScheudleID());
				logger.debug("End::"+getClass().getName()+"updateSchedule()" );
				return template.update(queryBuilder.toString().substring(0, queryBuilder.toString().length() - 1)
						+ " where filescheduleid = ?",params.toArray());
		
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "updating FileSchedule",e);
		}
	}
	
	public class FileActivityRowMapper implements RowMapper<FileActivityBO>{

		@SuppressWarnings("unchecked")
		@Override
		public FileActivityBO mapRow(ResultSet rs, int rowNum) throws SQLException {
			FileActivityBO fileActivityBO = new FileActivityBO();
			fileActivityBO.setFileActivityID(rs.getLong("fileactivityid"));
			fileActivityBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
			fileActivityBO.setFileName(rs.getString("filename"));
			fileActivityBO.setStatus(rs.getString("status").charAt(0));
			fileActivityBO.setMessage(rs.getString("message"));
			try {
				fileActivityBO.setStartedOn(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("startedon").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				fileActivityBO.setCompletedOn(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("completedon").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
			}
			try {
				fileActivityBO.setFileSummaryBO(rs.getString("filesummary") != null ? new ObjectMapper().readValue(rs.getString("filesummary"), FileSummaryBO.class) : null);
			} catch (IOException e) {
			}
//			fileActivityBO.setBatchId(rs.getInt("batchid"));
			fileActivityBO.setBatchId(rs.getLong("batchid"));
			fileActivityBO.setIgnorefilePath(rs.getString("ignorefilepath"));
			fileActivityBO.setDatabaseLogPath(rs.getString("databaselogpath"));
			if(rs.getString("activitysource")!=null)
			fileActivityBO.setActivitySource(rs.getString("activitysource").charAt(0));
			fileActivityBO.setSourceInfo(rs.getString("sourceinfo"));
			fileActivityBO.setCreatedBy(rs.getString("createdby"));
			fileActivityBO.setUpdatedBy(rs.getString("updatedby"));
			try {
				fileActivityBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				fileActivityBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
			}
			
			return fileActivityBO;
		}
	}
	
	
	
	public class FileActivitiesRowMapper implements RowMapper<FileActivitiesBO>{

		@SuppressWarnings("unchecked")
		@Override
		public FileActivitiesBO mapRow(ResultSet rs, int rowNum) throws SQLException {
			FileActivitiesBO fileActBo = new FileActivitiesBO();
			fileActBo.setFileActivityID(rs.getLong("fileactivityid"));
			fileActBo.setFileDefinitionID(rs.getLong("filedefinitionid"));
			fileActBo.setFileName(rs.getString("filename"));
			fileActBo.setStatus(rs.getString("status").charAt(0));
			fileActBo.setMessage(rs.getString("message"));
			try {
				fileActBo.setStartedOn(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("startedon").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				fileActBo.setCompletedOn(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("completedon").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
			}
			try {
				fileActBo.setFileSummaryBO(rs.getString("filesummary") != null ? new ObjectMapper().readValue(rs.getString("filesummary"), FileSummaryBO.class) : null);
			} catch (IOException e) {
			}
			fileActBo.setBatchId(rs.getLong("batchid"));
			fileActBo.setIgnorefilePath(rs.getString("ignorefilepath"));
			fileActBo.setDatabaseLogPath(rs.getString("databaselogpath"));
			if(rs.getString("activitysource")!=null)
				fileActBo.setActivitySource(rs.getString("activitysource").charAt(0));
			fileActBo.setSourceInfo(rs.getString("sourceinfo"));
			fileActBo.setCreatedBy(rs.getString("createdby"));
			fileActBo.setUpdatedBy(rs.getString("updatedby"));
			try {
				fileActBo.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				fileActBo.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				if(rs.getString("schedulenextdue") != null)
					fileActBo.setSchedulenextdue(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("schedulenextdue").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				
			} catch (Exception e) {
			}
			fileActBo.setFileDefinitionName(rs.getString("name"));
			return fileActBo;
		}
	}
	
	@Override
	public Long existFileactivityByFiledefinitionId(long filedefintionid) throws FileException{
		try {
			logger.debug("Inside::"+getClass().getName()+"existFileactivityByFiledefinitionId()" );
			return template.queryForObject("select count(1) from LFD_FILEACTIVITY where filedefinitionid = ?",Long.class,new Object[] { filedefintionid });
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
		
	}

	@Override
	public boolean updateFileDefifinationStatus(Character status, long filedefinitionId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"updateFileDefifinationStatus()" );
			FileActivityBO fb = new FileActivityBO();
			Object[] params ={status.toString(),filedefinitionId};
			return template.update(
					"update LFD_FILEDEFINITION set status = ? where filedefinitionid=?",params) == 1?true:false;
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting");	
		}
	}
	
	private Timestamp convLocalTZ(String time) throws Exception{
		return CommonUtil.toLocalTime(sd.parse(time).getTime(), TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone()));
	}
	private Timestamp convLocalTZ(String time,String timeZone) throws Exception{
		return CommonUtil.toLocalTime(sd.parse(time).getTime(), TimeZone.getTimeZone(timeZone));
	}
	
	@Override
	public Map<String,Long> getDomainWiseCount(String countQuery) throws FileException{
		logger.debug("Begin: getDomainWiseCount(String query)");
		HashMap<String, Long> listSummaryDomainCount = new HashMap<>();	
		try{
			wareHouseTemplate.query(countQuery,new RowCallbackHandler(){
				public void processRow(ResultSet countResultSet) throws SQLException {
					 String domainName = countResultSet.getString("EMAIL_DOMAIN_NAME");
					 long domainCount = countResultSet.getLong("EMAIL_DOMAIN_COUNT");
					 if(domainName == null)
						 domainName="";
					 listSummaryDomainCount.put(domainName, domainCount);
				}
			});
		}catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "Failed while getting domain wise counts.");	
		}
		logger.debug("Begin: getDomainWiseCount(String query)");
		return listSummaryDomainCount;
	}

	@Override
	public long checkAudienceExistInFileDefinitions(Long audienceId) throws FileException {
		try {
			logger.debug("checkAudienceExistInFileDefinitions()" );
			return template.queryForObject("select count(1) from LFD_FILEDEFINITION where audienceid = ?",Long.class,new Object[] { audienceId });
		} catch (Exception e) {
			logger.error("Exception:checkAudienceExistInFileDefinitions :: ", e);
			throw new FileException("checkAudienceExistInFileDefinitions",e);
		}
		
	}
}

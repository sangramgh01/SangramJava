package com.zetainteractive.zetahub.file.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.file.dao.ListDao;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * @author Paparao.Pandiri
 *
 */
@Repository
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS) 
public class ListDaoImpl implements ListDao {

	
	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Autowired
	@Qualifier("clientJdbcTemplate")
	JdbcTemplate template;

	@Override
	public ListDefinitionBO saveList(ListDefinitionBO listDefinitionBO) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"saveList()");
			ObjectMapper mapper = new ObjectMapper();
			String columnsList = mapper.writeValueAsString(listDefinitionBO.getColumnDefinitionList());
			if (listDefinitionBO.getListID() == null) {
				KeyHolder keyHolder = new GeneratedKeyHolder();
				template.update(new PreparedStatementCreator() {
					@Override
					public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
						PreparedStatement ps = con.prepareStatement(
								"insert into LFD_ADHOCLIST(name,status,listtype,audienceid,sourcetype,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,filedefinitionid,channeltype,updatedby) values(?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp(),utc_timestamp(),?,?,?,?)",
								Statement.RETURN_GENERATED_KEYS);
						ps.setString(1, listDefinitionBO.getName());
						ps.setString(2, listDefinitionBO.getStatus() + "");
						ps.setString(3, listDefinitionBO.getListType() + "");
						ps.setLong(4, (listDefinitionBO.getAudienceID()!= null)?listDefinitionBO.getAudienceID():0);
						ps.setString(5, listDefinitionBO.getSourceType() + "");
						ps.setString(6, listDefinitionBO.getTableName());
						ps.setLong(7, (listDefinitionBO.getFolderID()!=null)?listDefinitionBO.getFolderID():0);
						ps.setLong(8, (listDefinitionBO.getPreviousFolderID() != null )? listDefinitionBO.getPreviousFolderID() : 0);
						ps.setLong(9, listDefinitionBO.getCategoryID());
						ps.setLong(10,(listDefinitionBO.getDeptID() != null)? listDefinitionBO.getDeptID():0);
						ps.setString(11, columnsList);
						ps.setString(12, listDefinitionBO.getFilter());
						ps.setString(13, listDefinitionBO.getCreatedBy());
						ps.setLong(14, (listDefinitionBO.getFileDefinitionID()!= null)?listDefinitionBO.getFileDefinitionID():0);
						ps.setString(15, (listDefinitionBO.getChannelType() != null)?listDefinitionBO.getChannelType()+"":null);
						ps.setString(16, listDefinitionBO.getUpdatedBy());
						return ps;
					}
				}, keyHolder);
				listDefinitionBO.setListID(keyHolder.getKey().longValue());
			} else {
				StringBuilder queryBuilder = new StringBuilder();
				queryBuilder.append("update LFD_ADHOCLIST set ");
				List<Object> params=new ArrayList();
				if (listDefinitionBO.getName() != null) {
					params.add(listDefinitionBO.getName());
					queryBuilder.append("name=?,");
				}
				if (listDefinitionBO.getStatus() != null) {
					params.add(listDefinitionBO.getStatus().toString());
					queryBuilder.append("status=?,");
				}
				if (listDefinitionBO.getListType() != null) {
					params.add(listDefinitionBO.getListType().toString());
					queryBuilder.append("listtype=?,");
				}
				if (listDefinitionBO.getSourceType() != null) {
					params.add(listDefinitionBO.getSourceType().toString());
					queryBuilder.append("sourcetype=?,");
				}
				if (listDefinitionBO.getTableName() != null) {
					params.add(listDefinitionBO.getTableName());
					queryBuilder.append("tablename=?,");
				}
				if (listDefinitionBO.getFolderID() != null) {
					params.add(listDefinitionBO.getFolderID());
					queryBuilder.append("folderid=?,");
				}
				if (listDefinitionBO.getPreviousFolderID() != null) {
					params.add(listDefinitionBO.getPreviousFolderID());
					queryBuilder.append("previousfolderid=?,");
				}
				if (listDefinitionBO.getCategoryID() != null) {
					params.add(listDefinitionBO.getCategoryID());
					queryBuilder.append("categoryid=?,");
				}
				if (listDefinitionBO.getDeptID() != null) {
					params.add(listDefinitionBO.getDeptID());
					queryBuilder.append("departmentid=?,");
				}
				
				if(listDefinitionBO.getColumnDefinitionList() != null){
					params.add(columnsList);
					queryBuilder.append("columnmapping=?,");
				}
				
				if(listDefinitionBO.getChannelType() != null){
					params.add(listDefinitionBO.getChannelType().toString());
					queryBuilder.append("channeltype=?,");
				}
				
				if(listDefinitionBO.getFilter() != null){
					params.add(listDefinitionBO.getFilter());
					queryBuilder.append("filter=?,");
				}
				
				queryBuilder.append("updatedate=").append("utc_timestamp()")
						.append(",");

				if (listDefinitionBO.getUpdatedBy() != null) {
					params.add(listDefinitionBO.getUpdatedBy());
					queryBuilder.append("updatedby=?,");
				}
				
				if (listDefinitionBO.getCreatedBy() != null) {
					params.add(listDefinitionBO.getCreatedBy());
					queryBuilder.append("createdby=?,");
				}
				params.add(listDefinitionBO.getListID());
				template.update(queryBuilder.toString().substring(0, queryBuilder.toString().length()-1) + " where listid = ?",params.toArray());
			}
			logger.debug("End::"+getClass().getName()+"saveList()");
			return listDefinitionBO;
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "inserting",e);
		}
	}
	@Override
	public int updateList(String column, String value,String listId) throws FileException {
		try {
			logger.debug("Inside::" + getClass().getName() + "updateList()");
			Object[] params = { value };
			return template.update("update LFD_ADHOCLIST set "+column+"=? where listid IN("+listId+")", params);
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "updating",e);
		}
		
	}
	
	@Override
	public int restoreTrash(String listId) throws FileException {
		try {
			return template.update("update LFD_ADHOCLIST set folderid=previousfolderid,previousfolderid=0 where listid IN(?)",listId);
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "updating");
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int updateList(long folderID,String listId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"updateList(folderid,listId)");
			List<Long[]> folderIds = template.query("select listid,folderid from LFD_ADHOCLIST where listid IN(?)",new Object[]{listId}, new RowMapper() {
								@Override
								public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
									return new Long[] { rs.getLong("listid"),
											rs.getLong("folderid") };
								}
			});
			if(folderIds!= null &&folderIds.size() == 1){
				Object[] params={folderID,folderIds.get(0)[1],folderIds.get(0)[0]};
				return template.update("update LFD_ADHOCLIST set folderid=?,previousfolderid=? where listid =?",params);
			}else{
				for (Long[] longs : folderIds) {
					Object[] params={folderID,longs[1],longs[0]};
					template.update("update LFD_ADHOCLIST set folderid=?,previousfolderid=? where listid =?",params);
				}
				return 1;
			}
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "updating");
		}
	}
	
	
	@Override
	public boolean existListName(String listName,long departmentid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"existListName()");
			String table = template.queryForObject("select name from LFD_ADHOCLIST where name=? and departmentid=?",new Object[]{listName,departmentid}, String.class);
			return (table.equals(listName) == true) ? true : false;
		} catch (Exception e) {
			//logger.error("Exception:FileDaoImpl :: ", e);
			return false;
		}
	}
	
	@Override
	public ListDefinitionBO findListByListName(String listName) throws FileException {
		ListDefinitionBO listDefinitionBO = null;
		try {
			logger.debug("Inside::"+getClass().getName()+"findListByListName()");
			listDefinitionBO = template.queryForObject("select * from LFD_ADHOCLIST where name=?",new Object[]{listName}, new ListBORowMapper());
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("", "",e);
		}
		logger.debug("End::"+getClass().getName()+"findListByListName()");
		return listDefinitionBO;
	}
	
	@Override

	public ListDefinitionBO getList(Long listID) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getList()");
			return (ListDefinitionBO) template.queryForObject(
					"select listid,name,status,listtype,audienceid,channeltype,sourcetype,filedefinitionid,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,updatedby from LFD_ADHOCLIST where listid = ?",new ListBORowMapper(),new Object[]{listID});
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	@Override
	public List<ListDefinitionBO> getListByFolderId(Long folderId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getListByFolderId()");
			return template.query(
					"select listid,name,status,listtype,audienceid,channeltype,sourcetype,filedefinitionid,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,updatedby from LFD_ADHOCLIST where folderid = ?",new ListBORowMapper(),new Object[]{folderId});
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	
	private Object[] prepareSearchCriteria(Map<String, String> map) throws Exception {
		logger.debug("Inside::prepareSearchCriteria()");
		Integer pageno = 1;
		Integer pagesize = null;
		String search = "";
		String sortorder = "DESC";
		Object[] output = new Object[4];
		String[] status = null;
		String[] datesearch = null;
		if (map != null && !map.isEmpty()) {
			if (map.get("sortorder") != null) {
				sortorder = map.get("sortorder");
			}
			if (map.get("pageno") != null) {
				pageno = new Integer(map.get("pageno").toString());
			}
			if (map.get("pagesize") != null) {
				pagesize = new Integer(map.get("pagesize").toString());
			}
			if(map.get("status") != null){
				status = map.get("status").split(",");
				map.remove("status");
			}
			if(map.get("datesearch") != null){
				datesearch = map.get("datesearch").split(",");
				map.remove("datesearch");
			}
			if (map != null && !map.isEmpty()) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					String key = entry.getKey().trim();
					String value = entry.getValue().trim();
					if (key.equalsIgnoreCase("createdate") || key.equalsIgnoreCase("updatedate")
							|| key.equalsIgnoreCase("startedon") || key.equalsIgnoreCase("completedon")) {
						search += " and " + key + " BETWEEN DATE_FORMAT('" + (String) value
								+ "','%Y-%m-%d %H:%i:%s') and DATE_FORMAT('" + (String) value
								+ "','%Y-%m-%d %H:%i:%s')";
					} else if (!(key.equalsIgnoreCase("sortby") || key.equalsIgnoreCase("sortorder")
							|| key.equalsIgnoreCase("pageno") || key.equalsIgnoreCase("pagesize"))) {
						String operator = key.equalsIgnoreCase("name") ? " like " : " = ";
						if (key.equalsIgnoreCase("name")) {
							search += " and " + key + operator + "'%" + value + "%'";
						} else {
							search += " and "  + key + operator + "'" + value + "'";
						}
					}
				}
			}
			if (search != null && !"".equalsIgnoreCase(search)) {
				search = search.replaceFirst("and", " and ");
			}
			if(status != null){
				StringBuilder sb = new StringBuilder();
				for(String singleStatus : status){
					sb.append("'").append(singleStatus).append("',");
				}
				search = search + " and status IN("+sb.toString().substring(0, sb.toString().length()-1)+")";
			}
			if(datesearch != null && datesearch.length >= 1){
				search = search + " AND";
				search = search + " (";
				for(String dsearch : datesearch){
					if(dsearch.equals("T")){
						search = search + " cast(createdate as DATE) = CURDATE() OR";
					}else if(dsearch.equals("Y")){
						search = search + " cast(createdate as DATE) = (CURDATE() - INTERVAL 1 DAY) OR";
					}else if(dsearch.equals("TW")){
						search = search + " cast(createdate as DATE) > (CURDATE() - INTERVAL 7 DAY) OR";
					}else if(dsearch.equals("LW")){
						search = search + " cast(createdate as DATE) >= (CURDATE() - INTERVAL 14 DAY) AND cast(createdate as DATE) < (CURDATE() - INTERVAL 7 DAY) OR";
					}else if(dsearch.equals("TM")){
						search = search + " cast(createdate as DATE) > (CURDATE() - INTERVAL 30 DAY) OR";
					}
				}
				search = search.substring(0, search.length()-2);
				search = search + " )";
			}
		}
		output[0] = pageno;
		output[1] = pagesize;
		output[2] = search;
		output[3] = sortorder;
		logger.debug("End::prepareSearchCriteria()");
		return output;

	}
	
	@SuppressWarnings({ "unchecked", "serial" })
	@Override
	public Map<String,Object> getAllLists(Map<String, String> searchCriteria,Long foderID) throws FileException {
		logger.debug("Inside::"+getClass().getName()+"getAllLists()");
		String departmentID = searchCriteria.get("departmentID");
		if(departmentID == null){
			throw new FileException("FL0069");
		} 
		try {
			Object[] searchConditions = prepareSearchCriteria(searchCriteria);
			Integer pageno = (Integer) searchConditions[0];
			String sortby = "listid";
			if(searchCriteria.get("sortby") != null && (searchCriteria.get("sortby").equalsIgnoreCase("name") || searchCriteria.get("sortby").equalsIgnoreCase("createdate") || searchCriteria.get("sortby").equalsIgnoreCase("createdby"))){
				sortby = searchCriteria.get("sortby");
			}
			if(searchCriteria.get("sortOrder") != null && (searchCriteria.get("sortorder").equalsIgnoreCase("DESC") || searchCriteria.get("sortorder").equalsIgnoreCase("ASC"))){
				sortby = searchCriteria.get("sortby");
			}
				int totalRecords = template.queryForObject("select count(listid) from LFD_ADHOCLIST where departmentid = ? and folderid <> ? " + ((searchConditions[2] != null) ? searchConditions[2] : "") + " order by " +sortby +" "+ searchConditions[3], new Object[]{departmentID,foderID}, Integer.class);
			
			int count = 0;
			int length = totalRecords;
			Integer pagesize = null;
			if(pageno == null)pageno=0;
			if(searchConditions[1] != null){
				pagesize = (Integer) searchConditions[1];
			}else{
				pagesize = totalRecords;
			}
			if (pageno != null && pagesize != null) {
				count = ((pageno - 1) * pagesize);
				length = count + pagesize;
				if (totalRecords < length) {
					length = totalRecords;
				}
			}
			
			List<ListDefinitionBO> result =  template.query(
					"select listid,name,status,listtype,audienceid,channeltype,sourcetype,filedefinitionid,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,updatedby from LFD_ADHOCLIST where departmentid = "+departmentID+" and folderid <> "+foderID+" "+searchConditions[2] + " order by "+sortby+" "+ searchConditions[3] + " limit " + count + "," + pagesize,
					new RowMapper<ListDefinitionBO>() {
						@Override
						public ListDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
							ListDefinitionBO listDefinitionBO = new ListDefinitionBO();
							listDefinitionBO.setListID(rs.getLong("listid"));
							listDefinitionBO.setName(rs.getString("name"));
							listDefinitionBO.setStatus(rs.getString("status").charAt(0));
							listDefinitionBO.setListType(rs.getString("listtype").charAt(0));
							listDefinitionBO.setAudienceID(rs.getLong("audienceid"));
							listDefinitionBO.setChannelType(
									rs.getString("channeltype") != null ? rs.getString("channeltype").charAt(0) : '\0');
							listDefinitionBO.setSourceType(
									rs.getString("sourcetype") != null ? rs.getString("sourcetype").charAt(0) : '\0');
							listDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
							listDefinitionBO.setTableName(rs.getString("tablename"));
							listDefinitionBO.setFolderID(rs.getLong("folderid"));
							listDefinitionBO.setPreviousFolderID(rs.getLong("previousfolderid"));
							listDefinitionBO.setCategoryID(rs.getLong("categoryid"));
							listDefinitionBO.setDeptID(rs.getLong("departmentid"));
							try {
								listDefinitionBO.setColumnDefinitionList(
										new ObjectMapper().readValue(rs.getString("columnmapping"), List.class));
							} catch (Exception e) {
							}
							listDefinitionBO.setFilter(rs.getString("filter"));
							listDefinitionBO.setCreatedBy(rs.getString("createdby"));
							listDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
							try {
								listDefinitionBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								listDefinitionBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							} catch (Exception e) {
							}
							return listDefinitionBO;
						}
					});
			logger.debug("End::"+getClass().getName()+"getAllLists()");
			return new HashMap<String,Object>(){{put("totalRecords", totalRecords);put("result", result);}};
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}


	@Override
	public List<ListDefinitionBO> getAllListsOnCriteria(String searchCriteria) throws FileException {
		return null;
	}

	@Override
	public boolean isListExists(String name) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"isListExists()");
			String listName = null;
			listName = template.queryForObject("select name from LFD_ADHOCLIST where name = ?", String.class, name);
			if (listName != null) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			//logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}

	}

	@Override
	public boolean deleteListOnId(String id) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"deleteListOnId()");
			return (template.update("delete from LFD_ADHOCLIST where listid=?", new Object[] { id }) == 1) ? true
					: false;
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "deleting",e);
		}
	}
	@Override
	public int deleteAdhocList(String listid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"deleteAdhocList()");
			return template.update("delete from LFD_ADHOCLIST where listid IN(?)",listid);
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "deleting",e);
		}
	}
	
	@Override
	public int deleteListByFolderId(String folderid) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"deleteListByFolderId()");
			return template.update("delete from LFD_ADHOCLIST where folderid IN(?)",folderid);
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "deleting");
		}
	}

	@Override
	public boolean deleteList(String name) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"deleteList()");
			return (template.update("delete from LFD_ADHOCLIST where name=?", new Object[] { name }) == 1) ? true
					: false;
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "deleting",e);
		}
	}

	@Override
	public List<ListDefinitionBO> getListByListTypeAudienceId(char listType, long audienceId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getListByListTypeAudienceId()");
			return template.query(
					"select listid,name,status,listtype,audienceid,channeltype,sourcetype,filedefinitionid,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,updatedby from LFD_ADHOCLIST where listtype = ? and audienceid = ? ",new Object[]{listType,audienceId},
					new RowMapper<ListDefinitionBO>() {
						@SuppressWarnings("unchecked")
						@Override
						public ListDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
							ListDefinitionBO listDefinitionBO = new ListDefinitionBO();
							listDefinitionBO.setListID(rs.getLong("listid"));
							listDefinitionBO.setName(rs.getString("name"));
							listDefinitionBO.setStatus(rs.getString("status").charAt(0));
							listDefinitionBO.setListType(rs.getString("listtype").charAt(0));
							listDefinitionBO.setAudienceID(rs.getLong("audienceid"));
							listDefinitionBO.setChannelType((rs.getString("channeltype") != null)?rs.getString("channeltype").charAt(0):'\0');
							listDefinitionBO.setSourceType(rs.getString("sourcetype").charAt(0));
							listDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
							listDefinitionBO.setTableName(rs.getString("tablename"));
							listDefinitionBO.setFolderID(rs.getLong("folderid"));
							listDefinitionBO.setPreviousFolderID(rs.getLong("previousfolderid"));
							listDefinitionBO.setCategoryID(rs.getLong("categoryid"));
							listDefinitionBO.setDeptID(rs.getLong("departmentid"));
							try {
								listDefinitionBO.setColumnDefinitionList(
										new ObjectMapper().readValue(rs.getString("columnmapping"), List.class));
							} catch (Exception e) {
							}
							listDefinitionBO.setFilter(rs.getString("filter"));
							try {
								listDefinitionBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								listDefinitionBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							} catch (Exception e) {
							}
							listDefinitionBO.setCreatedBy(rs.getString("createdby"));
							listDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
							return listDefinitionBO;
						}
					});
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	
	public class ListBORowMapper implements RowMapper<ListDefinitionBO>{

		@SuppressWarnings("unchecked")
		@Override
		public ListDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
			ListDefinitionBO listDefinitionBO = new ListDefinitionBO();
			listDefinitionBO.setListID(rs.getLong("listid"));
			listDefinitionBO.setName(rs.getString("name"));
			listDefinitionBO.setStatus(rs.getString("status").charAt(0));
			listDefinitionBO.setListType(rs.getString("listtype").charAt(0));
			listDefinitionBO.setAudienceID(rs.getLong("audienceid"));
			listDefinitionBO.setChannelType(
					rs.getString("channeltype") != null ? rs.getString("channeltype").charAt(0) : '\0');
			listDefinitionBO.setSourceType(
					rs.getString("sourcetype") != null ? rs.getString("sourcetype").charAt(0) : '\0');
			listDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
			listDefinitionBO.setTableName(rs.getString("tablename"));
			listDefinitionBO.setFolderID(rs.getLong("folderid"));
			listDefinitionBO.setPreviousFolderID(rs.getLong("previousfolderid"));
			listDefinitionBO.setCategoryID(rs.getLong("categoryid"));
			listDefinitionBO.setDeptID(rs.getLong("departmentid"));
			try {
				listDefinitionBO.setColumnDefinitionList(
						new ObjectMapper().readValue(rs.getString("columnmapping"), List.class));
			} catch (Exception e) {
			}
			listDefinitionBO.setFilter(rs.getString("filter"));
			try {
				listDefinitionBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
				listDefinitionBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
			} catch (Exception e) {
			}
			listDefinitionBO.setCreatedBy(rs.getString("createdby"));
			listDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
			return listDefinitionBO;
		}
		
	}

	@Override
	public int updateListStatus(Long fileDefinitionId,Character status) throws FileException{
		try {
			logger.debug("Inside::"+getClass().getName()+"updateListStatus()");
			String updateListStatus="update LFD_ADHOCLIST set status=?,updatedate = UTC_TIMESTAMP where filedefinitionid=?";
			return template.update(updateListStatus,String.valueOf(status),fileDefinitionId);
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "updating",e);
		}
	}
	
	@Override
	public String getTableNameById(long listId) throws FileException {
		try {
			logger.debug("Inside::"+getClass().getName()+"getTableNameById()");
			return template.queryForObject("select tablename from LFD_ADHOCLIST where listid=?",new Object[]{listId}, String.class);
		} catch (Exception e) {
			return null;
		}
	}
	@Override
	public Object getAllListsByIds(String ids) throws Exception{
		logger.debug("Inside::"+getClass().getName()+"getAllListsByIds()");
		return template.query("select * from LFD_ADHOCLIST where listid IN(?)",new Object[]{ids},new ListBORowMapper());
	}
	@Override
	public Map<String, Object> getAllListsForAPI(Map<String, String> searchCriteria) throws FileException {
		logger.debug("Inside::"+getClass().getName()+"getAllListsAPI()");
		String countQuery="select count(listid) from LFD_ADHOCLIST ";
		String baseQuery="select listid,name,status,listtype,audienceid,channeltype,sourcetype,filedefinitionid,tablename,folderid,previousfolderid,categoryid,departmentid,columnmapping,filter,createdate,updatedate,createdby,updatedby from LFD_ADHOCLIST ";
		try {
	            StringBuilder whereClauseBuilder = new StringBuilder();
				List<Object> params=new ArrayList<>();
				if (searchCriteria.get("status") != null) {
					String[] status = searchCriteria.get("status").split(",");
					StringBuilder sb = new StringBuilder();
					for (String singleStatus : status) {
						sb.append(singleStatus+",");
					}
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
					params.add(sb.toString().substring(0, sb.toString().length() - 1));
	
					whereClauseBuilder
							.append("status IN(?)" + " ");
				}
				if (searchCriteria.get("listId") != null) {
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
		               params.add(searchCriteria.get("listId"));
					whereClauseBuilder.append(" listid=?");
				}
				if (searchCriteria.get("departmentID") != null) {
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
					whereClauseBuilder.append(" departmentid IN("+searchCriteria.get("departmentID")+")");
				}
				if(searchCriteria.get("name") !=null ){
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
					 params.add(searchCriteria.get("name"));
					whereClauseBuilder.append(" name=?");
				}
				if (searchCriteria.get("audienceId") != null) {
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
					params.add(searchCriteria.get("audienceId"));
					whereClauseBuilder.append(" audienceid=?");
				}
				if (searchCriteria.get("listtype") != null) {
					if (whereClauseBuilder.length() > 0)
						whereClauseBuilder.append(" and ");
					else
						whereClauseBuilder.append(" where ");
					params.add(searchCriteria.get("listtype"));
					whereClauseBuilder.append(" listtype=?");
				}
				int totalRecords = template.queryForObject(
						countQuery+whereClauseBuilder.toString()+" order by listid",params.toArray(), Integer.class);
			   
			   List<ListDefinitionBO> result =  template.query(
                       baseQuery+whereClauseBuilder.toString()+" order by listid",params.toArray(), 
					new RowMapper<ListDefinitionBO>() {
						@Override
						public ListDefinitionBO mapRow(ResultSet rs, int rowNum) throws SQLException {
							ListDefinitionBO listDefinitionBO = new ListDefinitionBO();
							listDefinitionBO.setListID(rs.getLong("listid"));
							listDefinitionBO.setName(rs.getString("name"));
							listDefinitionBO.setStatus(rs.getString("status").charAt(0));
							listDefinitionBO.setListType(rs.getString("listtype").charAt(0));
							listDefinitionBO.setAudienceID(rs.getLong("audienceid"));
							listDefinitionBO.setChannelType(
									rs.getString("channeltype") != null ? rs.getString("channeltype").charAt(0) : '\0');
							listDefinitionBO.setSourceType(
									rs.getString("sourcetype") != null ? rs.getString("sourcetype").charAt(0) : '\0');
							listDefinitionBO.setFileDefinitionID(rs.getLong("filedefinitionid"));
							listDefinitionBO.setTableName(rs.getString("tablename"));
							listDefinitionBO.setFolderID(rs.getLong("folderid"));
							listDefinitionBO.setPreviousFolderID(rs.getLong("previousfolderid"));
							listDefinitionBO.setCategoryID(rs.getLong("categoryid"));
							listDefinitionBO.setDeptID(rs.getLong("departmentid"));
							try {
								listDefinitionBO.setColumnDefinitionList(
										new ObjectMapper().readValue(rs.getString("columnmapping"), List.class));
							} catch (Exception e) {
							}
							listDefinitionBO.setFilter(rs.getString("filter"));
							listDefinitionBO.setCreatedBy(rs.getString("createdby"));
							listDefinitionBO.setUpdatedBy(rs.getString("updatedby"));
							try {
								listDefinitionBO.setCreateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("createdate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
								listDefinitionBO.setUpdateDate(CommonUtil.toLocalTime(CommonUtil.toUTC(rs.getTimestamp("updatedate").getTime(),TimeZone.getDefault()).getTime(),TimeZone.getTimeZone(ZetaUtil.getHelper().getUser().getTimeZone())));
							} catch (Exception e) {
							}
							return listDefinitionBO;
						}
					});
			logger.debug("End::"+getClass().getName()+"getAllListsForAPI()");
			return new HashMap<String,Object>(){{put("totalRecords", totalRecords);put("result", result);}};
		} catch (Exception e) {
			logger.error("Exception:ListDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
	}
	@Override
	public ListDefinitionBO findListByListName(String listName,long deptId)  throws Exception{
		ListDefinitionBO listDefinitionBO = null;
		try {
			logger.debug("Inside::"+getClass().getName()+"findListByListName()");
			listDefinitionBO = template.queryForObject("select * from LFD_ADHOCLIST where name=? and departmentid=?",new Object[]{listName,deptId}, new ListBORowMapper());
		} catch (Exception e) {
			logger.error("Exception:FileDaoImpl :: ", e);
			throw new FileException("F00002", "selecting",e);
		}
		logger.debug("End::"+getClass().getName()+"findListByListName()");
		return listDefinitionBO;
	}
	
	@Override
	public String getListTypeByFileDefId(long fileDefinitionId){
		return template.queryForObject("SELECT listtype FROM LFD_ADHOCLIST where filedefinitionid=?",new Object[]{fileDefinitionId}, String.class);
	}
	@Override
	public List<ListDefinitionBO> getListsByNames(Set<String> names){
		StringBuilder params=new StringBuilder();
		for (String name : names)
			params.append("'").append(name).append("',");
		
		
		return template.query("SELECT * FROM LFD_ADHOCLIST where name in ("+params.toString().substring(0, params.toString().length()-1)+")",new ListBORowMapper());
	}
}

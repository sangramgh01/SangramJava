package com.zetainteractive.zetahub.file.dao.impl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.google.api.client.util.Base64;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.file.constants.Constants;
import com.zetainteractive.zetahub.file.dao.RemoteDBDao;
import com.zetainteractive.zetahub.file.exception.FileException;
/**
 * 
 * @author Venkata.Tummala
 *
 */
@Component
public class RemoteDBDaoImpl implements RemoteDBDao {

	ZetaLogger logger = new ZetaLogger(getClass().getName());
	@Autowired
	MessageSource messageSource;
	private Connection getConnection(String vendor,String host,long port,String db_Name,String user,String passwd) 
			throws FileException
	    {
			logger.info("Begin: getConnection(): vendor "+vendor+ " host : "+host + " port : "+port+ " db_Name : "+db_Name+ " user : "+user);			
		    Connection con = null;
		    String url = null;
	        String driver=null;
	        String schemaName = null;
		    try {
		        if(vendor.equalsIgnoreCase(Constants.DBTYPE_MYSQL)) {
		        	url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-url",
		        			"jdbc:mysql://${IPADDRESS}:${PORT}/${SID}?autoReconnect=true&useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-driver","com.mysql.cj.jdbc.Driver");
				} else if(vendor.equalsIgnoreCase(Constants.DBTYPE_ORACLE)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-url",
							"jdbc:oracle:thin:@${IPADDRESS}:${PORT}:${SID}");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-driver","oracle.jdbc.driver.OracleDriver");
				} else if(vendor.equalsIgnoreCase(Constants.DBTYPE_MSSQL)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-url","jdbc:jtds:sqlserver://${IPADDRESS}:${PORT}/${SID}");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-driver","net.sourceforge.jtds.jdbc.Driver");
				} else if(vendor.equalsIgnoreCase(Constants.DBTYPE_TERADATA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-url","jdbc:teradata://${SID}/");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-driver","com.ncr.teradata.TeraDriver");
				}else if(vendor.equalsIgnoreCase(Constants.DBTYPE_NETEZZA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-url","jdbc:netezza://${IPADDRESS}:${PORT}/${SID}");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-driver","org.netezza.Driver");
				}else if(vendor.equalsIgnoreCase(Constants.DBTYPE_POSTGRES)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-url","jdbc:postgresql://${IPADDRESS}:${PORT}/${SID}");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-driver",
		        			"org.postgresql.Driver");
				}else if(vendor.equalsIgnoreCase(Constants.DBTYPE_VERTICA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-url","jdbc:vertica://${IPADDRESS}:${PORT}/${SID}");
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-driver","com.vertica.jdbc.Driver");
				    if(db_Name != null && db_Name.contains(".")){
				    	schemaName = db_Name.split(Pattern.quote("."))[1];
				    	db_Name = db_Name.split(Pattern.quote("."))[0];
				    }
				}
		        url = CommonUtil.replaceValuesInStringTemplate(url,host,port,db_Name);
				if(vendor.equalsIgnoreCase(Constants.DBTYPE_VERTICA) && schemaName != null){      	                                                                      
					url=url+"?searchpath="+schemaName;
				} 
				Class.forName(driver).newInstance();  
				byte[] decodedPassword = Base64.decode(passwd.getBytes());
				logger.error("DB URL"+url );
				con = DriverManager.getConnection(url,user,new String(decodedPassword));
		    }catch(Exception e) {
		    	logger.error("DB URL"+url );
		    	logger.error("Exception: getConnection()",e);
		    	throw new FileException("F00002",null,Level.FATAL,e);
		    }finally{
		    	logger.info("End: getConnection()");
			}
		  return con;
	    }
	
	public List<String> fetchTablesFromRemoteDB(DbSourceBO dbSourceBO) throws  FileException, Exception {
		logger.info("Begin: fetchTablesFromRemoteDB()");		
		List<String> tablesList = new ArrayList<String>();
		ResultSet rs = null;
		Connection con = null;
		try{
			con = getConnection(dbSourceBO.getDbvendor(),dbSourceBO.getHostname(),dbSourceBO.getPort(),dbSourceBO.getSchemaName(),dbSourceBO.getUsername(),dbSourceBO.getPassword()); 
			java.sql.DatabaseMetaData dbm = con.getMetaData();
			//for verica db only
			if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_VERTICA)) {
			    if(dbSourceBO.getSchemaName() != null && dbSourceBO.getSchemaName().contains(".")){
			    	dbSourceBO.setSchemaName(dbSourceBO.getSchemaName().split(Pattern.quote("."))[0]);
			    }
			}
			rs = dbm.getTables(dbSourceBO.getSchemaName(), null, "%", new String[]{"TABLE"});
			while (rs.next()) {
				String tableName = rs.getString(3);
				if (tableName != null && !tablesList.contains(tableName)) {
					tablesList.add(tableName);
				}
			}
		}catch(SQLException e) {
			logger.error("SQLException: fetchTablesFromRemoteDB()"+ e);	
		    if ((dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_ORACLE) && e.getErrorCode() == 17410)||(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_MYSQL) && e.getErrorCode() == 0)) {
		    	throw new FileException("E00003",e);
		    }
		    throw new FileException("F00002",e);
        }
		catch(Exception e){
			logger.error("Exception: fetchTablesFromRemoteDB()"+ e);	
			 throw new FileException("F00002",e);		
		}finally{
			 if (rs != null) {
			        try {
			            rs.close();
			        } catch (SQLException e) { 
			        	/* ignored */}
			    }
			 if (con != null) {
			        try {
			            con.close();
			        } catch (SQLException e) { /* ignored */}
			    }
			logger.info("End: fetchTablesFromRemoteDB()");	
		}
		return tablesList;
	}
	
	public String prepareQuery(DbSourceBO dbSourceBO,String tableName) throws FileException, Exception {
		logger.info("Begin: prepareQuery()");	
		Connection con = null;
		ResultSet rs = null;
		 ResultSetMetaData rsmd = null;
	    Statement stmt = null;
	    String query = "select " ;
		try{
		con = getConnection(dbSourceBO.getDbvendor(),dbSourceBO.getHostname(),dbSourceBO.getPort(),dbSourceBO.getSchemaName(),dbSourceBO.getUsername(),dbSourceBO.getPassword()); 
		String tempQuery = "select * from " + tableName + " WHERE 1 = 2";  
		stmt = con.createStatement();
		rs = stmt.executeQuery(tempQuery);
		rsmd = rs.getMetaData();
        for(int i = 1;i <=rsmd.getColumnCount();i++){   
        	String appendValue = (i==rsmd.getColumnCount())?"":",";
        	query+= rsmd.getColumnName(i)+appendValue;  
        }    
       query+=" from " + tableName;
		}catch(SQLException e){
			logger.error("SQLException: fetchTablesFromRemoteDB()",e);	
			if (e.getErrorCode() == 17410 || e.getErrorCode() == 0)  {
                throw new FileException("E00003",e);
            }
            else if(e.getErrorCode() == 1146){
                throw new FileException("FL0006",e);
            }else{
            	 throw new FileException("F00002",e);
            }
		}catch(Exception e){
			logger.error("Exception: fetchTablesFromRemoteDB()",e);	
			throw new FileException("F00002",e);
		}finally {
		    if (rs != null) {
		        try {
		            rs.close();
		        } catch (SQLException e) { 
		        	/* ignored */}
		    }
		    if (stmt != null) {
		        try {
		            stmt.close();
		        } catch (SQLException e) { 
		        	/* ignored */}
		    }
		    if (con != null) {
		        try {
		            con.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		logger.info("End: prepareQuery()");	
		return query;
	}
	
	
	public List<String[]> executeQuery(DbSourceBO dbSourceBO,String query,int rowNum) throws FileException,Exception {
		logger.info("Begin: executeQuery()");
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		List<String[]> output = new ArrayList<String[]>();
		try{
			con = getConnection(dbSourceBO.getDbvendor(),dbSourceBO.getHostname(),dbSourceBO.getPort(),dbSourceBO.getSchemaName(),dbSourceBO.getUsername(),dbSourceBO.getPassword()); 
			query = query.replaceAll(";+$", "");
			if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_MYSQL)) {
				 if(query.matches("(?i).*limit.*")){
					 int limitPos = query.lastIndexOf("limit");
						int commaPos = query.lastIndexOf(",");
						String limit = commaPos > limitPos ? query.substring(commaPos+1,query.length()).trim():query.substring(limitPos+5,query.length()).trim();
						if(Long.parseLong(limit)>Constants.MAXPAGE_LIMIT){
							query = commaPos > limitPos ?  query.substring(0,commaPos+1)+ " "+Constants.MAXPAGE_LIMIT: query.substring(0,limitPos+5)+" " +Constants.MAXPAGE_LIMIT;
						}
						stmt = con.prepareStatement(query);
				 }else
				 {	
					 query+=" limit ?";
					 stmt = con.prepareStatement(query);
					 stmt.setInt(1, rowNum);
				 }
			 }else if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_ORACLE)){
				 query = "select * from (select p.*, rownum rnum	from (?) p	where rownum <= ? ) where rnum > 0";
				 stmt = con.prepareStatement(query);
				 stmt.setString(1, query);
				 stmt.setInt(2, rowNum);
			 }else{
				 stmt = con.prepareStatement(query);
			 }
			rs = stmt.executeQuery();
			int  columnCount = rs.getMetaData().getColumnCount();
			if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_ORACLE))
				columnCount-=1;
			String initArr[] = new String[columnCount];
		 	for(int i=1;i<=columnCount;i++)
			{
				initArr[i-1] = rs.getMetaData().getColumnLabel(i);
			}
		 	output.add(initArr);
				while(rs.next())
				{
					String arr[] = new String[columnCount];
					for(int i=1;i<=columnCount;i++)
					{	
						int j = i-1;		
						arr[j] = rs.getString(i);
						if(arr[j]==null)
						{
						    arr[j] = "-";
						}else{
							if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_ORACLE)){
								String columntype = rs.getMetaData().getColumnTypeName(i);
								if(columntype.equalsIgnoreCase("TimeStamp")||columntype.equalsIgnoreCase("Date"))
								{
									DateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
									arr[j] = dateFormatter.format(rs.getDate(i));
								}
							}else if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_MYSQL) || (dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_MSSQL))){
								Matcher matcher = Constants.DatePatternWithZero.matcher(arr[j].toString());
								if(matcher.matches()){
									if(arr[j].toString().endsWith(".0")){
										String dateStr = arr[j].toString();
										int index = dateStr.indexOf(".0");
										dateStr = dateStr.substring(0, index);
										arr[j] = dateStr;
									}
								}
							}
						}
					}
					output.add(arr);
				}
		}catch(SQLException e){
			if (e.getErrorCode() == 17410 || e.getErrorCode() == 0)  {
                throw new FileException("E00003",null,Level.ERROR,e);
            }
			else if(e.getErrorCode() == 1060 || e.getErrorCode() == 918 || e.getErrorCode() == 8156){
                throw new FileException("WT0006",null,Level.ERROR,e);
            }else{
                throw new FileException("WL0026",null,Level.FATAL,e);
            }
		}catch(Exception e){
			logger.info("Exception: executeQuery()"+e);
			throw new FileException("F00002",null,Level.FATAL,e);
		}finally {
		    if (rs != null) {
		        try {
		            rs.close();
		        } catch (SQLException e) { 
		        	/* ignored */}
		    }
		    if (stmt != null) {
		        try {
		            stmt.close();
		        } catch (SQLException e) { 
		        	/* ignored */}
		    }
		    if (con != null) {
		        try {
		            con.close();
		        } catch (SQLException e) { /* ignored */}
		    }
			logger.info("End: executeQuery()");
		}
		return output;
	}
	
	public List<String[]> getTableMetaData(DbSourceBO dbSourceBO,String tableName) throws FileException, Exception {
		logger.info("Begin:: "+getClass().getName()+"getTableMetaData");
		Connection con = null;
		ResultSet rs = null;
	    DatabaseMetaData dbm = null;
	    List<String[]> output = new ArrayList<String[]>();
	    ResultSet rsPrimaryKeys = null;
	    ResultSet rsIndexKeys = null;
	    HashMap<String,String> indexMap = new HashMap<String,String>();
	    
		try{
		con = getConnection(dbSourceBO.getDbvendor(),dbSourceBO.getHostname(),dbSourceBO.getPort(),dbSourceBO.getSchemaName(),dbSourceBO.getUsername(),dbSourceBO.getPassword());
		dbm = con.getMetaData();
		
		//for verica db only
		if(dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.DBTYPE_VERTICA)) {
		    if(dbSourceBO.getSchemaName() != null && dbSourceBO.getSchemaName().contains(".")){
		    	//dbSourceBO.setSchemaName(dbSourceBO.getSchemaName().split(Pattern.quote("."))[0]);
		    	rs = dbm.getColumns( null, dbSourceBO.getSchemaName().split(Pattern.quote("."))[1], tableName,  "%");
		    }else{
		    	rs = dbm.getColumns(dbSourceBO.getSchemaName(), null, tableName, "%");
		    }
		}else{
			rs = dbm.getColumns(dbSourceBO.getSchemaName(), null, tableName, "%");
		}
       rsIndexKeys = dbm.getIndexInfo(dbSourceBO.getSchemaName(), null, tableName, false, false);
        while (rsIndexKeys.next()) {
        	if(rsIndexKeys.getBoolean("NON_UNIQUE")){
        		indexMap.put(rsIndexKeys.getString("COLUMN_NAME"), "NON-UNIQUE");
        	} else {
				indexMap.put(rsIndexKeys.getString("COLUMN_NAME"), "UNIQUE");
			}
        	}
        rsPrimaryKeys = dbm.getPrimaryKeys(dbSourceBO.getSchemaName(), null, tableName);
        while (rsPrimaryKeys.next()) {
        	indexMap.put(rsPrimaryKeys.getString("COLUMN_NAME"), "UNIQUE");
		}
        while (rs.next()) {
        	String[] stringArray = new String[6];
        	if(!output.contains(rs.getString("COLUMN_NAME"))){
			stringArray[0]= rs.getString("COLUMN_NAME");
        	}
			stringArray[1]= rs.getString("TYPE_NAME");
			stringArray[2]=rs.getString("COLUMN_SIZE");
			stringArray[3]=rs.getString("COLUMN_DEF"); 
			stringArray[4] = (rs.getInt("NULLABLE") == DatabaseMetaData.columnNullable)?"YES":"NO";
			if (indexMap.containsKey(rs.getString("COLUMN_NAME"))) {
				stringArray[5] = indexMap.get(rs.getString("COLUMN_NAME"));
			} else{
				stringArray[5] = "NO-INDEX";
			}
			output.add(stringArray);
		}
		}catch(SQLException e){
			if (e.getErrorCode() == 17410 || e.getErrorCode() == 0)  {
                throw new FileException("E00003",null,Level.ERROR,e);
            }
            else if(e.getErrorCode() == 1146){
                String obj[] = {tableName};
                throw new FileException("EL1146",obj,Level.ERROR,e);
            }else{
                throw new FileException("F00002",null,Level.FATAL,e);
            }
		}catch(Exception e){
			throw new FileException("F00002",null,Level.FATAL,e);
		}finally{
			if(rs!=null && !rs.isClosed()){
				rs.close();
			}
			if (rsPrimaryKeys != null) {
				try {
					rsPrimaryKeys.close();
				} catch (SQLException e) {
					/* ignored */}

			}
			if (rsIndexKeys != null) {
				try {
					rsIndexKeys.close();
				} catch (SQLException e) {
					/* ignored */}

			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					/* ignored */}

			}
		}
		return output;
	}
	
	public static void main(String args[]) throws FileException, Exception{
		
		RemoteDBDaoImpl r = new RemoteDBDaoImpl();
		DbSourceBO dbSourceBO = new DbSourceBO();
		try{
		dbSourceBO.setSchemaName("content");
		dbSourceBO.setHostname("10.219.28.14");
		dbSourceBO.setPort((short)4306);
		dbSourceBO.setUsername("root");
		dbSourceBO.setPassword("TXlzcWwkMTIz");
		dbSourceBO.setDbvendor("MySQL");
		dbSourceBO.setService("content");
		List<String[]> stringArray = r.getTableMetaData(dbSourceBO, "CNT_RSSFEED");
		ListIterator<String[]> itr =  stringArray.listIterator();
		while(itr.hasNext()){
			String[] str = (String[]) itr.next();
			for ( int i=0;i<str.length;i++){
				//System.out.println("column data"+str[i]);
			}
		}
			}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
}

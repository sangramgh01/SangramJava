/**
 * AudienceException.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/

package com.zetainteractive.zetahub.file.exception;

import org.apache.log4j.Level;

/**
 * 
 * @author Venkata.Tummala
 *
 */

public class FileException extends Exception {

	/** The error code. */
	String errorCode;

	/** The error message. */
	String errorMessage;
	
	/** The db message. */
	String dbMessage;

	/** The exception. */
	Throwable exception;
	
	/** The object. */
	Object[] object;
	
	/** The level. */
	Level level = Level.ERROR;
	
	/** The flag. */
	boolean flag = false;

	/**
	 * @return Returns the errorMessage.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            The errorMessage to set.
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * No argument constructor.
	 */
	public FileException() {

	}

	/**
	 * @param errorCode
	 *            error code
	 */
	public FileException(String errorCode) {
		super(errorCode);
		this.errorCode = errorCode;
	}
	
	
	/**
	 * @param errorCode
	 *            error code
	 */
	public FileException(String errorCode,String errorMessage) {
		super(errorCode);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	/**
	 * Constructor takes Error code and actual ex as arguments.
	 * 
	 * @param code
	 *            Error code
	 * @param ex
	 *            Actual Exception occured.
	 */
	public FileException(String code, Throwable ex) {
		super(code, ex);
		this.errorCode = code;
		this.exception = ex;
	}

	public FileException(String code, Throwable ex, Object[] object, boolean flag) {
		super(code, ex);
		this.errorCode = code;
		this.exception = ex;
		this.object = object;
		this.flag = flag;
	}

	public FileException(String code, Object[] object, Level level, Throwable ex) {
		super(code, ex);
		this.errorCode = code;
		this.exception = ex;
		this.object = object;
		this.level = level;
	}
	
	/**
     * @param code
     * @param object
     */
    public FileException(String code,Object[] object){
    	super(code);
        this.errorCode = code;
        this.object = object; 
    }

	public FileException(String code, String locale, Object obj) {
		super(code);
		this.errorCode = code;
	}

	/**
	 * Returns the error code associated with the exception.
	 * 
	 * @return
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * @return Returns the dbMessage.
	 */
	public String getDbMessage() {
		return dbMessage;
	}

	/**
	 * @param dbMessage
	 *            The dbMessage to set.
	 */
	public void setDbMessage(String dbMessage) {
		this.dbMessage = dbMessage;
	}

	/**
	 * @return Returns the object.
	 */
	public Object[] getObject() {
		return object;
	}

	/**
	 * @return Returns the exception.
	 */
	public Throwable getException() {
		return exception;
	}

	/**
	 * @return Returns the level.
	 */
	public Level getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            The level to set.
	 */
	public void setLevel(Level level) {
		this.level = level;
	}

}

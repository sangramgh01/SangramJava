package com.zetainteractive.zetahub.file.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.zetainteractive.fileutils.exception.FileSystemUtilException;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.commons.domain.ActivityCollection;
import com.zetainteractive.zetahub.commons.domain.ActivitySearchCriteria;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.file.exception.FileException;

/**
 * 
 * @author Venkata.Tummala
 *
 */
public interface FileService {

	public List<String> getTablesInfoFromRemoteDB(String dbSourceName) throws FileException,Exception;
	public String prepareQueryOnSelectedTableOfRemoteDB(String dbSourceName,String tableName) throws FileException,Exception ;
	public List<String[]> executeQueryOnSelectedTableOfRemoteDB(String dbSourceName,String query) throws Exception;
	public Object testFileSourceAndLoadFiles(String fileSourceName,String currentPath,boolean isFiles) throws FileSystemUtilException,FileException, Exception ;
	public Object testFileSourceAndLoadFiles(String fileSourceName,String currentPath,boolean isFiles,int headerrow,int datarow,String delimit,String textqualifier) throws FileSystemUtilException,FileException, Exception ;
	public FileDefinitionBO saveOrUpdateFileDefinition(FileDefinitionBO fileDefinitionBO,MultipartFile file) throws Exception ;
	public HashMap<String,Object> getAllFileDefinitions(Map<String,String> searchCriteria, boolean flag) throws Exception ;
	public void deleteFileDefinition(long filescheduleid) throws FileException;
	public long saveFileActivity(FileActivityBO fileActivityBO) throws Exception;
	public FileActivityBO getAllFileActivities(long fileactivityid) throws Exception;
	public void deleteFileActivity(long fileactivityid) throws FileException;
	public List<String[]> getTableMetaData(String dbSourceName,String tableName) throws FileException, Exception ;
	public List<String[]> getAllFileActivitiesByFileDefId(long filedefinitionid) throws Exception;
	public List<LogicalColumnBO> fetchAudienceBaseColumnsByFilter(Long audienceID) throws  FileException, Exception;
	public Object fileUpload(InputStream file, int headerStart, int dataStart, String delimiter,String textQualifier)
			throws FileException,Exception;
	public Map<String,List<Object[]>> fetchAllAddresstypes() throws  FileException, Exception;
	public Map<Long, List<FileActivityBO>> getAllFileActivities(Map<String, String> searchCriteria) throws FileException;
	public ActivityCollection getAllFileActivities(ActivitySearchCriteria searchCriteria) throws FileException;
	public long getAllFileDefinitionsLogicalColumnNames(String logicalTableName,String logicalColumnName)throws FileException;
	public List<CustomColumnDefinitionBO> fetchStagingTableColumns(String tableName) throws FileException, Exception ;
	public List<CustomColumnDefinitionBO> fetchAudienceBaseColumns(Long audienceID) throws AudienceException,FileException,Exception;
//	public String getDepartmentNotifications(Long departmentID) throws AdminException, Exception;
	public Map<Long, String> getAllFileDefinitionsByID(Map<String, String> searchCriteria) throws FileException,Exception;
	public FileDefinitionBO getAllFileDefinitions(Long filedefId) throws FileException;
	public List<Object> getAllTablesAndFiles(char sourceType, Long audienceID) throws FileException ;
	public int updateSchedule(FileScheduleBO fileScheduleBO) throws FileException;
	public FileDefinitionBO updateFileDefinitionStatus(Long fileDefinitionId,Character fileDefinitionStatus,FileSummaryBO fileSummaryBO) throws FileException;
	public LinkedHashMap<Long, List<FileActivityBO>> getAllFileActivity(long fileactivityid) throws Exception;
	public String zipIt(String outputFileName,String sourceFolder) throws Exception;
	public FileActivityBO getAllFileActivityByFileDefId(long filedefinitionId) throws FileException;
	public boolean updateFileActivitystatus(Character status,String fileactivityid) throws FileException;
	public boolean updateFileActivitystatus(Character status,String fileactivityid,long filedefinitionId) throws FileException;
	public Long existFileactivityByFiledefinitionId(long filedefintionid) throws FileException;
	public List<CustomColumnDefinitionBO> getTableColumns(String tableName)throws Exception;
	public long checkAudienceExistInFileDefinitions(Long audienceId)throws FileException;
}

package com.zetainteractive.zetahub.file.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.file.exception.FileException;

public interface ListService {
	
	
	public  Map<String,Object> getAllLists(Map<String, String> searchCriteria) throws Exception ;
	
	public  Map<String,Object> getAllListsForAPI(Map<String, String> searchCriteria) throws Exception ;
	
	public ListDefinitionBO saveList(ListDefinitionBO listDefinitionBO) throws Exception ;

	public int deleteAdhocList(String listid) throws Exception;

	public List<ListDefinitionBO> getListByListTypeAudienceId(char listType,long audienceId)throws Exception;
	public int updateList(String column, String value,String listId,String deptID) throws FileException, Exception;

	public ListDefinitionBO saveFileAndListDefinition(ListDefinitionBO listDefinitionBO,FileDefinitionBO fileDefinitionBO,MultipartFile file) throws Exception;

	public ListDefinitionBO findListByListName(String listName) throws Exception;
	public ListDefinitionBO findListByListName(String listName,long deptid) throws Exception;
	public List<ListDefinitionBO> getListByFolderId(Long departmentId) throws Exception;
	public int restoreTrash(String listId) throws FileException;
	public int deleteListByFolderId(String folderid) throws FileException;

	public int updateListStatus(Long fileDefinitionId, Character status) throws FileException;
	public List<String> getEmailsFromVericaDB(long listId) throws Exception;
	public Object getAllListsByIds(String ids) throws Exception ;
	
	/**
	 * 
	 * 
	 * Method Name 	: getListTypeByFileDefId
	 * Description 	: The Method "getListTypeByFileDefId" is used for getting list type by using filedefinitionid.
	 * Date    		: 14 Dec 2017, 15:59:47
	 * @param fileDefinitionId
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getListTypeByFileDefId(long fileDefinitionId);
	
	/**
	 * 
	 * 
	 * Method Name 	: getListsByNames
	 * Description 	: The Method "getListsByNames" is used for 
	 * Date    		: 15 Dec 2017, 17:41:28
	 * @param names
	 * @return
	 * @param  		:
	 * @return 		: List<ListDefinitionBO>
	 * @throws 		:
	 */
	public List<ListDefinitionBO> getListsByNames(Set<String> names);
}

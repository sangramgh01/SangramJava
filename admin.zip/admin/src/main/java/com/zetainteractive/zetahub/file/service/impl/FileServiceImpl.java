package com.zetainteractive.zetahub.file.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.google.api.client.util.Base64;
import com.zetainteractive.fileutils.bo.FileUtilContext;
import com.zetainteractive.fileutils.exception.FileSystemUtilException;
import com.zetainteractive.fileutils.plugin.FileSystemUtilsPlugin;
import com.zetainteractive.fileutils.plugin.impl.FileSystemUtilPluginFactory;
import com.zetainteractive.fileutils.util.FileSystemTypeConstants;
import com.zetainteractive.zetahub.admin.audience.dao.AudienceWarehouseMetaDataDAO;
import com.zetainteractive.zetahub.admin.audience.exception.AudienceException;
import com.zetainteractive.zetahub.admin.audience.service.AudienceMetadataService;
import com.zetainteractive.zetahub.admin.audience.service.AudienceService;
import com.zetainteractive.zetahub.admin.file.validator.FileValidator;
import com.zetainteractive.zetahub.admin.notifications.service.WorkflowNotificationHandler;
import com.zetainteractive.zetahub.admin.service.ConfigurationService;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.validators.ListingCriteriaValidator;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.ActivityCollection;
import com.zetainteractive.zetahub.commons.domain.ActivitySearchCriteria;
import com.zetainteractive.zetahub.commons.domain.AddressTypeBO;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.CustomColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceSpecBO;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.commons.domain.ListingCriteria;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.file.constants.Constants;
import com.zetainteractive.zetahub.file.dao.FileDao;
import com.zetainteractive.zetahub.file.dao.RemoteDBDao;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.file.service.FileService;
import com.zetainteractive.zetahub.file.service.ListService;

/**
 * 
 * @author Venkata.Tummala
 *
 */
@Service
public class FileServiceImpl implements FileService {
	
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();
	@Autowired
	RemoteDBDao remoteDBDao;
	@Autowired
	FileDao fileDao;
	@Autowired
	ConfigurationService configurationService;
	@Autowired
	FileValidator fileValidator;
	@Autowired
	private AudienceService audienceService;
	@Autowired
	ListingCriteriaValidator listingCriteriaValidator;
	@Autowired
	AudienceMetadataService audienceMetadataService;
	@Autowired
	DepartmentService departmentService;
	@Autowired
	ListService listService;
	
	@Autowired
	AudienceWarehouseMetaDataDAO whDao;
	
	@Autowired
	WorkflowNotificationHandler workflowNotificationHandler;

	ZetaLogger logger = new ZetaLogger(getClass().getName());

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<String> getTablesInfoFromRemoteDB(String dbSourceName) throws FileException, Exception {
		logger.debug("Inside:fetchTablesFromRemoteDB()::DBSOURCE" + dbSourceName);
		List<String> finalTablesList = new ArrayList<String>();
		/*
		 * if(Constants.INTERNAL_DB.equalsIgnoreCase(dbSourceBO.getDbvendor())){
		 * //get DB type from config server }
		 */
		DbSourceBO dbSourceBO = validateDataBase(dbSourceName);
		List<String> tablesList = remoteDBDao.fetchTablesFromRemoteDB(dbSourceBO);
		if (dbSourceBO.getDbvendor().equalsIgnoreCase(Constants.INTERNAL_DB)) {
			for (int index = 0; index < tablesList.size(); index++) {
				String tableName = (String) tablesList.get(index);
				if (!(tableName.startsWith("LFD_") && tableName.startsWith("ADM_") && tableName.startsWith("AUD_"))) {
					finalTablesList.add(tableName);
				}
			}
		} else {
			finalTablesList.addAll(tablesList);
		}
		return finalTablesList;
	}

	private DbSourceBO validateDataBase(String dbSourceName) throws FileException, Exception {
		DbSourceBO dbSourceBO = configurationService.getDBSource(dbSourceName);
		if (dbSourceBO == null) {
			throw new FileException("FL0001");
		}
		return dbSourceBO;
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public String prepareQueryOnSelectedTableOfRemoteDB(String dbSourceName, String tableName)
			throws FileException, Exception {
		logger.debug("Inside:prepareQueryOnSelectedTableOfRemoteDB()");
		if (tableName == null || "".equalsIgnoreCase(tableName.trim()))
			throw new FileException("FL0004");
		return remoteDBDao.prepareQuery(validateDataBase(dbSourceName), tableName);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<String[]> executeQueryOnSelectedTableOfRemoteDB(String dbSourceName, String query)
			throws FileException, Exception {
		logger.debug("Inside:executeQueryOnSelectedTableOfRemoteDB()");
		if (dbSourceName == null || "".equalsIgnoreCase(dbSourceName)) {
			throw new FileException("FL0004");
		}
		if (query == null || "".equalsIgnoreCase(query)) {
			throw new FileException("FL0008");
		}
		DbSourceBO dbSourceBO = configurationService.getDBSource(dbSourceName);
		return remoteDBDao.executeQuery(dbSourceBO, query, Constants.ROW_NUM);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<String[]> getTableMetaData(String dbSourceName, String tableName) throws FileException, Exception {
		logger.debug("Inside:getTableMetaData()");
		DbSourceBO dbSourceBO = configurationService.getDBSource(dbSourceName);
		return remoteDBDao.getTableMetaData(dbSourceBO, tableName);
	}

	public Object testFileSourceAndLoadFiles(String fileSourceName, String currentPath, boolean isFiles)
			throws FileSystemUtilException, FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"testFileSourceAndLoadFiles()");
		FileSystemUtilsPlugin fileUtils = null;
		FileSourceBO fileSourceBO = configurationService.getFileSource(fileSourceName);
		if (fileSourceBO == null) {
			throw new FileException("FL0002");
		}
		if (fileSourceBO.getProtocol().equalsIgnoreCase("HTTP")
				|| fileSourceBO.getProtocol().equalsIgnoreCase("HTTPS")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.HTTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("FTP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.FTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("SFTP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SFTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("SCP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SCP);
			currentPath = getSpecialCharEscapeMap(escape(currentPath, " "));
		}
		byte[] decodedPassword = Base64.decode(fileSourceBO.getPassword().getBytes());
		FileUtilContext fileUtilContext = new FileUtilContext(fileSourceBO.getHostname(), fileSourceBO.getUsername(),
				new String(decodedPassword), fileSourceBO.getPort(), 15000);
		fileUtilContext.setRemoteFilePath(currentPath);

		fileUtils.setContext(fileUtilContext);
		try {
			if (!isFiles) {
				/*String[] list = fileUtils.listFiles();
				List<String> result = new ArrayList<String>();
				for (String f : list) {
					if (f.endsWith(".txt") || f.endsWith(".csv") || f.endsWith("/"))
						result.add(f);
				}
				return result;*/
				 return fileUtils.listFiles();
			} else {
			
				if (fileSourceBO.getProtocol().equalsIgnoreCase("HTTP")
						|| fileSourceBO.getProtocol().equalsIgnoreCase("HTTPS")) {
					fileUtilContext.setLocalFilePath(currentPath);
					fileUtilContext.setUrlString(currentPath);
					fileUtils.setContext(fileUtilContext);
					String result = fileUtils.getSampleData(1024, "UTF-8");
					return fileUpload(IOUtils.toInputStream(result, "UTF-8"), 0, 1, ",", "NONE",true);
				} else {
					fileUtilContext.setLocalFilePath(currentPath);
					fileUtilContext.setUrlString(currentPath);
					fileUtils.setContext(fileUtilContext);
					String result = fileUtils.getSampleData(1024, "UTF-8");
					return fileUpload(IOUtils.toInputStream(result, "UTF-8"), 0, 1, ",", "NONE",true);
				}
			}
		} catch (Exception e) {
			if(e.getMessage() != null && e.getMessage().equals("FL0070")){
				throw new FileException("FL0070");
			}else if(e.getMessage() != null && e.getMessage().equals("FL0071")){
				throw new FileException("FL0071");
			}
			throw new FileException("FL0067");
		}
	}

	public Object testFileSourceAndLoadFiles(String fileSourceName, String currentPath, boolean isFiles, int headerrow,
			int datarow, String delimit, String textqualifier)
					throws FileSystemUtilException, FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"testFileSourceAndLoadFiles(fileSourcname,currentpath,isFiles,headerrow,datarow,delimit,textqualifier)");
		FileSystemUtilsPlugin fileUtils = null;
		FileSourceBO fileSourceBO = configurationService.getFileSource(fileSourceName);
		if (fileSourceBO == null) {
			throw new FileException("FL0002");
		}
		if (fileSourceBO.getProtocol().equalsIgnoreCase("HTTP")
				|| fileSourceBO.getProtocol().equalsIgnoreCase("HTTPS")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.HTTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("FTP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.FTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("SFTP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SFTP);
		} else if (fileSourceBO.getProtocol().equalsIgnoreCase("SCP")) {
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SCP);
			currentPath = getSpecialCharEscapeMap(escape(currentPath, " "));
		}
		byte[] decodedPassword = Base64.decode(fileSourceBO.getPassword().getBytes());
		FileUtilContext fileUtilContext = new FileUtilContext(fileSourceBO.getHostname(), fileSourceBO.getUsername(),
				new String(decodedPassword), fileSourceBO.getPort(), 15000);
		fileUtilContext.setRemoteFilePath(currentPath);

		fileUtils.setContext(fileUtilContext);
		try {
			if (!isFiles){
				return fileUtils.listFiles();
			}else {
				if (fileSourceBO.getProtocol().equalsIgnoreCase("HTTP")
						|| fileSourceBO.getProtocol().equalsIgnoreCase("HTTPS")) {
					fileUtilContext.setLocalFilePath(currentPath);
					fileUtilContext.setUrlString(currentPath);
					fileUtils.setContext(fileUtilContext);
					String result = fileUtils.getSampleData(1024, "UTF-8");
					return fileUpload(IOUtils.toInputStream(result, "UTF-8"), headerrow, datarow, delimit,
							textqualifier,true);
				} else {
					fileUtilContext.setLocalFilePath(currentPath);
					fileUtilContext.setUrlString(currentPath);
					fileUtils.setContext(fileUtilContext);
					String result = fileUtils.getSampleData(1024, "UTF-8");
					return fileUpload(IOUtils.toInputStream(result, "UTF-8"), headerrow, datarow, delimit,
							textqualifier,true);
				}
			}
		} catch (Exception e) {
			if(e.getMessage() != null && e.getMessage().equals("FL0070")){
				throw new FileException("FL0070");
			}else if(e.getMessage() != null && e.getMessage().equals("FL0071")){
				throw new FileException("FL0071");
			}
			throw new FileException("FL0067");
		}
	}

	private void updateFileSchedule(FileScheduleBO fileScheduleBO) {
		logger.debug("Inside::"+getClass().getName()+"updateFileSchedule()");
		if (fileScheduleBO != null && fileScheduleBO.getFrequency() != null) {
			if (fileScheduleBO.getFrequency() == 'I' || fileScheduleBO.getFrequency() == 'O') {
				Date startDate = CommonUtil.toUTC(fileScheduleBO.getScheduleStartDate().getTime(),
						TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
				fileScheduleBO.setScheduleStartDate(startDate);
				fileScheduleBO.setScheduleEndDate(startDate);
				fileScheduleBO.setSchedulenextdue(startDate);
			}
			if (fileScheduleBO.getFrequency() == 'D' || fileScheduleBO.getFrequency() == 'W' || fileScheduleBO.getFrequency() == 'M'
					|| fileScheduleBO.getFrequency() == 'N') {
				Date beforeEndDate = fileScheduleBO.getScheduleEndDate();
				beforeEndDate.setHours(23);
				beforeEndDate.setMinutes(59);
				beforeEndDate.setSeconds(59);
				Date endDate = CommonUtil.toUTC(beforeEndDate.getTime(),
						TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
				Date startDate = CommonUtil.toUTC(fileScheduleBO.getScheduleStartDate().getTime(),
						TimeZone.getTimeZone(fileScheduleBO.getTimeZone()));
				fileScheduleBO.setScheduleStartDate(startDate);
				fileScheduleBO.setSchedulenextdue(startDate);
				fileScheduleBO.setScheduleEndDate(endDate);
			}
		}
		logger.debug("End::"+getClass().getName()+"updateFileSchedule()");
	}

	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public FileDefinitionBO saveOrUpdateFileDefinition(FileDefinitionBO fileDefinitionBO, MultipartFile file)
			throws Exception {
		logger.debug("Inside::"+getClass().getName()+"saveOrUpdateFileDefinition()");
		// rest call to get Table Name
		if (fileDefinitionBO.getFileDefinitionID() == null || (fileDefinitionBO.getFileDefinitionID() != null
				&& fileDefinitionBO.getFileDefinitionID().longValue() == 0)) {
			if(fileDefinitionBO.getFileType()!=null && fileDefinitionBO.getFileType() == 'B' && fileDefinitionBO.getTableName() != null){
				if(!fileDefinitionBO.getTableName().trim().isEmpty()){
					Boolean isExists = false;
					List<AudienceBO> audienceBOs=audienceService.listAudience();
					if(audienceBOs!=null && !audienceBOs.isEmpty()){
						audienceOuterLoop: for (AudienceBO audienceBO : audienceBOs) {
							List<LogicalTableBO> logicalTableList = audienceBO.getLogicalTables();
							for (LogicalTableBO logicalTableBO : logicalTableList) {
								String physicalTableName = logicalTableBO.getPhysicalTableName();
									if(physicalTableName!=null&&fileDefinitionBO.getTableName()!=null){
										if (physicalTableName.equalsIgnoreCase(fileDefinitionBO.getTableName())) {
											isExists = true;
											break audienceOuterLoop;
										}
									}
							}
						}
						if(isExists){
							throw new FileException("FL0072");
						}
					}
				}
			}
			if (!fileDao.isFileDefinationExistWithName(fileDefinitionBO.getName(),fileDefinitionBO.getDepartmentID())) {
				if (((fileDefinitionBO.getFileType() == Constants.FILE_TYPE_BASE
						|| fileDefinitionBO.getFileType() == Constants.FILE_TYPE_UNSUB
						|| fileDefinitionBO.getFileType() == Constants.FILE_TYPE_RESUB)
						&& !fileDao.existTableName(fileDefinitionBO.getTableName(),0))
						|| fileDefinitionBO.getFileType() == Constants.FILE_TYPE_DIMENSION
						|| fileDefinitionBO.getFileType() == Constants.FILE_TYPE_ADHOC) {
					updateFileSchedule(fileDefinitionBO.getFileScheduleBO());
					AuditEvent event = new AuditEvent();
		            event.setActor("FileServiceImpl");
		            event.setAction("save or update filedefinition");
		            event.addField("Save or update filedefinition name :: ",fileDefinitionBO.getName());
		            auditManager.audit(event);
					fileDefinitionBO = fileDao.saveFileDefinition(fileDefinitionBO);
					if (fileDefinitionBO.getFileSource().getSourceType() == 'L'
							|| fileDefinitionBO.getFileSource().getSourceType() == 'D') {
						String filePath = ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-folder", null);
						if (filePath != null) {
							String custCode = ZetaUtil.getHelper().getCustomerID().toLowerCase();
							String fullFilePath = filePath + File.separator + custCode;
							if (fileDefinitionBO.getFileType() == 'A') {
								fullFilePath += File.separator + "adhocimport";
							} else {
								fullFilePath += File.separator + "batchimport";
							}
							if (fileDefinitionBO.getFileType() == 'B') {
								fullFilePath += File.separator + "base";
							} else if (fileDefinitionBO.getFileType() == 'D') {
								fullFilePath += File.separator + "dim";
							} else if (fileDefinitionBO.getFileType() == 'U') {
								fullFilePath += File.separator + "unsub";
							} else if (fileDefinitionBO.getFileType() == 'R') {
								fullFilePath += File.separator + "resub";
							}
							fullFilePath += File.separator + fileDefinitionBO.getFileDefinitionID();
							File f = new File(fullFilePath);
							if (!f.exists()) {
								f.mkdirs();
							}
							AuditEvent event1 = new AuditEvent();
				            event1.setActor("FileServiceImpl");
				            event1.setAction("save or update filedefinition");
				            event1.addField("Save or update filedefinition name :: ",fileDefinitionBO.getName());
				            auditManager.audit(event1);
							saveuploadedFile(fileDefinitionBO, file, fullFilePath);
							FileDefinitionBO updateBo = new FileDefinitionBO();
							FileSourceSpecBO fileSource = fileDefinitionBO.getFileSource();
							fileSource.setFilePath(fullFilePath);
							updateBo.setFileSource(fileSource);
							updateBo.setFileDefinitionID(fileDefinitionBO.getFileDefinitionID());
//							updateBo.setCreatedBy("admin");
//							updateBo.setWorkFlowID(fileDefinitionBO.getWorkFlowID());
//							updateBo.setSendWorkFlow(fileDefinitionBO.getSendWorkFlow());
							fileDefinitionBO = fileDao.updateFileDefinition(updateBo);
						} else {
							throw new FileException("FL0065");
						}
					}

					return fileDefinitionBO;
				} else {
					throw new FileException("F00039");
				}
			} else {
				throw new FileException("FL0059");
			}
		} else {
			if(fileDao.existTableName(fileDefinitionBO.getTableName(),fileDefinitionBO.getFileDefinitionID())){
				throw new FileException("F00039");
			}
			updateFileSchedule(fileDefinitionBO.getFileScheduleBO());
			try {
				if (fileDefinitionBO.getFileSource() != null && (fileDefinitionBO.getFileSource().getSourceType() == 'D' || fileDefinitionBO.getFileSource().getSourceType() == 'L')) {
					String filePath = ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-folder", null);
					if (filePath != null) {
						String custCode = ZetaUtil.getHelper().getCustomerID().toLowerCase();
						String fullFilePath = filePath + File.separator + custCode;
						if (fileDefinitionBO.getFileType() == 'A') {
							fullFilePath += File.separator + "adhocimport";
						} else {
							fullFilePath += File.separator + "batchimport";
						}
						if (fileDefinitionBO.getFileType() == 'B') {
							fullFilePath += File.separator + "base";
						} else if (fileDefinitionBO.getFileType() == 'D') {
							fullFilePath += File.separator + "dim";
						} else if (fileDefinitionBO.getFileType() == 'U') {
							fullFilePath += File.separator + "unsub";
						} else if (fileDefinitionBO.getFileType() == 'R') {
							fullFilePath += File.separator + "resub";
						}
						fullFilePath += File.separator + fileDefinitionBO.getFileDefinitionID();
						File f = new File(fullFilePath);
						if (!f.exists()) {
							f.mkdirs();
						}
						if(fileDefinitionBO.getFileSource().getSourceType() == 'D'){
							File[] files = f.listFiles();
							for (File file2 : files) {
								logger.info("Inside:saveOrUpdateFileDefinition() in fileupload already existed files ::"+file2.getName());
								if(file2.isFile())file2.delete();
							}		
							saveuploadedFile(fileDefinitionBO, file, fullFilePath);
						}
						fileDefinitionBO.getFileSource().setFilePath(fullFilePath);
					}
					else {
						throw new FileException("FL0065");
					}
				}
			} catch (FileException e) {logger.error("FileStrore Exception In editmode", e);}
			AuditEvent event = new AuditEvent();
			event.setActor("FileServiceImpl");
			event.setAction("update filedefinition");
			event.addField("update filedefinition by id :: ",fileDefinitionBO.getFileDefinitionID());
            auditManager.audit(event);
			return fileDao.updateFileDefinition(fileDefinitionBO);
		}
	}

	private String saveuploadedFile(FileDefinitionBO fileDefinitionBO, MultipartFile file, String fullFilePath) {
		logger.debug("Inside::"+getClass().getName()+"saveuploadedFile()");
		if (fileDefinitionBO.getFileSource() != null && fileDefinitionBO.getFileSource().getSourceType() == 'D') {
			BufferedReader br = null;
			InputStreamReader stream = null;
			FileOutputStream outputStream = null;
			OutputStreamWriter outputStreamWriter = null;
			PrintWriter printWriter = null;
			try {
				String line = null;
				stream = new InputStreamReader(file.getInputStream());
				br = new BufferedReader(stream);
				String fileName = file.getOriginalFilename();
				String fileExtension[] = fileName.split("\\.");
				String fileExtension1 = fileExtension[fileExtension.length - 1];
				Calendar date1 = Calendar.getInstance();
				String name = fileExtension[0] + "_" + date1.getTimeInMillis() + "." + fileExtension1;
				fullFilePath += File.separator + name;
				outputStream = new FileOutputStream(fullFilePath);
				outputStreamWriter = new OutputStreamWriter(outputStream, Charset.forName("UTF-8"));
				printWriter = new PrintWriter(outputStream);
				while ((line = br.readLine()) != null) {
					printWriter.println(line);
				}
			} catch (IOException e) {
				logger.error("IOException", e);
			} finally {
				try {
					if (br != null)
						br.close();
					if (stream != null)
						stream.close();
					if (printWriter != null)
						printWriter.close();
					if(outputStreamWriter != null){
						outputStreamWriter.close();
					}
					if (outputStream != null)
						outputStream.close();
				} catch (IOException e) {
					logger.error("IOException", e);
				}
			}
		}
		logger.debug("End::"+getClass().getName()+"saveuploadedFile()");
		return fullFilePath;
		
	}

	@SuppressWarnings("unchecked")
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Map<Long, String> getAllFileDefinitionsByID(Map<String, String> searchCriteria)
			throws FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"getAllFileDefinitionsByID()");
		Map<Long, String> fileMap = new HashMap<Long, String>();
		Map<String, Object> output = fileDao.getAllFileDefinitions(searchCriteria,false);
		Long totalRecords = new Long(output.get("totalRecords").toString());
		if (totalRecords >= 0) {
			List<Object> fileDefinitionBOs = (List<Object>) output.get("result");
			for (Object object : fileDefinitionBOs) {
				FileDefinitionBO fileDefinition = (FileDefinitionBO) object;
				fileMap.put(fileDefinition.getFileDefinitionID(), fileDefinition.getName());
			}
		}
		logger.debug("End::"+getClass().getName()+"getAllFileDefinitionsByID()");
		return fileMap;
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public HashMap<String, Object> getAllFileDefinitions(Map<String, String> searchCriteria, boolean flag) throws Exception {
		return fileDao.getAllFileDefinitions(searchCriteria,flag);

	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<FileActivityBO> getAllFileActivities() throws Exception {
		return fileDao.getAllFileActivities();
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public FileActivityBO getAllFileActivities(long fileactivityid) throws Exception {
		return fileDao.getAllFileActivities(fileactivityid);
	}
	
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public LinkedHashMap<Long, List<FileActivityBO>> getAllFileActivity(long fileactivityid) throws Exception {
		return fileDao.getAllFileActivity(fileactivityid);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public long saveFileActivity(FileActivityBO fileActivityBO) throws Exception {
		return fileDao.saveFileActivity(fileActivityBO);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public void deleteFileDefinition(long filescheduleid) throws FileException {
		fileDao.deleteFileDefinition(filescheduleid);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public void deleteFileActivity(long fileactivityid) throws FileException {
		fileDao.deleteFileActivity(fileactivityid);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<String[]> getAllFileActivitiesByFileDefId(long filedefinitionid) throws Exception {
		return fileDao.getAllFileActivitiesByFileDefId(filedefinitionid);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ActivityCollection getAllFileActivities(ActivitySearchCriteria searchCriteria) throws FileException {
		return fileDao.getAllFileActivities(searchCriteria);
	}
	
	
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Map<Long, List<FileActivityBO>> getAllFileActivities(Map<String, String> searchCriteria) throws FileException {
		return fileDao.getAllFileActivities(searchCriteria);
	}

	public List<LogicalColumnBO> fetchAudienceBaseColumnsByFilter(Long audienceID) throws FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"fetchAudienceBaseColumnsByFilter()");
		AudienceBO audienceBO = audienceService.findAudienceById(audienceID);
		if (audienceBO == null) {
			throw new FileException("FL0003");
		}
		Character audienceType = audienceBO.getAudienceType() == 0 ? 'C' : 'S';
		List<LogicalColumnBO> logicalColumns = audienceService.getBaseLogicalColumnsByAudienceId(audienceID);
		List<LogicalColumnBO> finalSetOfLogicalColumns = new ArrayList<LogicalColumnBO>();
		if (audienceType != null && (audienceType == 'S' || audienceType == 'C')) {
			Iterator<LogicalColumnBO> logicalColumnsItr = (Iterator<LogicalColumnBO>) logicalColumns.iterator();
			while (logicalColumnsItr.hasNext()) {
				LogicalColumnBO logicalColumnBO = (LogicalColumnBO) logicalColumnsItr.next();
				if (audienceType == 'S' && ("EMAIL Address".equalsIgnoreCase(logicalColumnBO.getLogicalColumnName())
						|| "SMS Number".equalsIgnoreCase(logicalColumnBO.getLogicalColumnName()))) {
					finalSetOfLogicalColumns.add(logicalColumnBO);
				} else if (audienceType == 'C') {
					if (!(logicalColumnBO.getPhysicalColumnName().toUpperCase().equals("AUDIENCE_MEMBER_ID")
							|| logicalColumnBO.getPhysicalColumnName().toUpperCase().equals("AUDIENCE_TYPE_ID")
							|| logicalColumnBO.getPhysicalColumnName().toUpperCase().equals("MODIFIED_DT")
							|| logicalColumnBO.getPhysicalColumnName().toUpperCase().equals("CREATION_DT"))) {
						finalSetOfLogicalColumns.add(logicalColumnBO);
					}
				}
			}
		} else {
			throw new FileException("file.audience.type.invalid");
		}
		logger.debug("End::"+getClass().getName()+"fetchAudienceBaseColumnsByFilter()");
		return finalSetOfLogicalColumns;
	}

	public List<CustomColumnDefinitionBO> fetchStagingTableColumns(String tableName) throws FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"fetchStagingTableColumns()");
		PhysicalTableBO physicalTableBO = audienceMetadataService.findPhysicalTableByName(tableName);
		if (physicalTableBO == null) {
			throw new FileException("FL0041");
		}
		List<CustomColumnDefinitionBO> logicalColumns = new ArrayList<CustomColumnDefinitionBO>();
		List<PhysicalColumnBO> physicalColumns = physicalTableBO.getPhysicalColumns();
		if (physicalColumns != null && !physicalColumns.isEmpty()) {
			for (PhysicalColumnBO physicalColumnBO : physicalColumns) {
				if (physicalColumnBO.getPhysicalColumnName() != null
						&& !("BATCH_ID".equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase())
								|| "SRC_FILE_ID"
										.equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase())
						|| "AUDIENCE_MEMBER_ID".equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase())
						|| "AUDIENCE_TYPE_ID".equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase())
						|| "MODIFIED_DT".equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase())
						|| "CREATION_DT".equalsIgnoreCase(physicalColumnBO.getPhysicalColumnName().toUpperCase()))) {
					CustomColumnDefinitionBO customColumnDefinitionBO = new CustomColumnDefinitionBO();
					customColumnDefinitionBO.setLogicalColumnName(physicalColumnBO.getPhysicalColumnName());
					customColumnDefinitionBO.setColumnDataType(physicalColumnBO.getColumnDataType());
					customColumnDefinitionBO.setIsNullable(physicalColumnBO.getIsNullable());
					logicalColumns.add(customColumnDefinitionBO);
				}
			}
		}
		logger.debug("End::"+getClass().getName()+"fetchStagingTableColumns()");
		return logicalColumns;
	}
	
	@Override
	public Object fileUpload(java.io.InputStream file, int headerStart, int dataStart,
			String delimiter, String textQualifier) throws FileException, Exception {
		return fileUpload(file, headerStart, dataStart, delimiter, textQualifier,true);
	}

	
	private Object fileUpload(java.io.InputStream file, int headerStart, int dataStart,
			String delimiter, String textQualifier,boolean flag) throws FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"fileUpload(file,datastart,delimiter,textqualifier,flag)");
		BufferedReader br = null;
		InputStreamReader stream = null;
		List<DataMapping> result = null;
		try {
			stream = new InputStreamReader(file);
			br = new BufferedReader(stream);
			String line = null;
			result = new ArrayList<DataMapping>();
			List<List<String>> aL = new ArrayList<List<String>>();
			int length = 0;
			boolean oneTime = true;
			int lineNo = 0;
			if ("|".equalsIgnoreCase(delimiter.trim())) {
				delimiter = "\\|";
			} else if ("tab".equalsIgnoreCase(delimiter.trim())) {
				delimiter = "\t";
			}
			while ((line = br.readLine()) != null) {
				lineNo++;
				if(line.isEmpty())continue;
				if (textQualifier != null && !textQualifier.equalsIgnoreCase("None")) {
					line = replacer(line, textQualifier.charAt(0), delimiter.charAt(0));
					if ("\"".equalsIgnoreCase(textQualifier.trim()))
						line = line.replaceAll("\"", "");
					else if ("\'".equalsIgnoreCase(textQualifier.trim()))
						line = line.replaceAll("\'", "");
				}
				if(flag && aL.size() >= 10) break;
				if (lineNo >= dataStart) {
					aL.add(new ArrayList<String>(Arrays.asList(line.split(delimiter))));
				}
				if (oneTime) {
					if (headerStart != 0 && (headerStart == lineNo)) {
						length = line.split(delimiter).length;
						List<String> list = Arrays.asList(line.split(delimiter));
						for (String object : list) {
							result.add(new DataMapping(object, new ArrayList<String>()));
						}
						oneTime = false;
					} else if (lineNo == dataStart) {
						length = line.split(delimiter).length;
						oneTime = false;
					}
				}
				
			}
			if (headerStart == 0) {
				for (int i = 0; i < length; i++) {
					result.add(new DataMapping("column_" + i, new ArrayList<String>()));
				}
			}
			for (int i = 0; i < aL.size(); i++) {
				int rowCount = 0;
				for (DataMapping dataMapping : result) {
					List<String> strA = aL.get(i);
					try {
						List<String> s = dataMapping.getValues();
						s.add(strA.get(rowCount));
					} catch (Exception e) {
					}
					rowCount++;
				}
			}
		} finally {
			try {
				if (br != null)
					br.close();
				if (stream != null)
					stream.close();
			} catch (IOException e) {
			}
		}
		logger.debug("End::"+getClass().getName()+"fileUpload(file,datastart,delimiter,textqualifier,flag)");
		return result;
	}

	public Map<String, List<Object[]>> fetchAllAddresstypes() throws FileException, Exception {
		logger.debug("Inside::"+getClass().getName()+"fetchAllAddresstypes()");
		Map<String, List<Object[]>> addressTypeMap = new HashMap<String, List<Object[]>>();
		ListingCriteria listingCriteria = new ListingCriteria();
		listingCriteria.setSortBy("ASC");
		listingCriteria.setColumnNames(
				com.zetainteractive.zetahub.admin.constants.Constants.ADM_CONFIGURATION_ADDRESSTYPES_COLUMNS);
		listingCriteria.setSortUsing(listingCriteria.getColumnNames().get(0));
		listingCriteria.setPageNumber(1L);
		listingCriteria.setPageSize(Long.MAX_VALUE);
		listingCriteria.setNameLike("");
		List<AddressTypeBO> addressTypes = configurationService.listAddressTypes();
		if (addressTypes != null) {
			for (AddressTypeBO addressTypeBO : addressTypes) {
				for (String channelType : addressTypeBO.getChannelType()) {
					if (addressTypeMap.get(channelType) != null) {
						List<Object[]> channelCatgories = addressTypeMap.get(channelType);
						channelCatgories.add(new Object[]{addressTypeBO.getKeyName(), addressTypeBO.getName()});
					} else {
						List<Object[]> channelCatgories = new ArrayList<Object[]>();
						JSONObject obj = new JSONObject();
						obj.put(addressTypeBO.getKeyName(), addressTypeBO.getName());
						channelCatgories.add(new Object[]{addressTypeBO.getKeyName(), addressTypeBO.getName()});
						addressTypeMap.put(channelType, channelCatgories);
					}
				}
			}
		} else {
			throw new FileException("FL0007");
		}
		logger.debug("Inside::"+getClass().getName()+"fetchAllAddresstypes()");
		return addressTypeMap;
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public long getAllFileDefinitionsLogicalColumnNames(String logicalTableName,String logicalColumnName) throws FileException {
		return fileDao.getAllFileDefinitionsLogicalColumnNames(logicalTableName,logicalColumnName);
	}

	public List<CustomColumnDefinitionBO> fetchAudienceBaseColumns(Long audienceID)
			throws AudienceException, FileException, Exception {
		logger.info("Begin ::"+getClass().getName()+"fetchAudienceBaseColumns");
		List<LogicalColumnBO> logicalColumnBOs = fetchAudienceBaseColumnsByFilter(audienceID);
		List<LogicalTableBO> LogicalTableBOs = audienceService.findAudienceById(audienceID).getLogicalTables();
		List<CustomColumnDefinitionBO> result = new ArrayList<>();
		for (LogicalColumnBO logicalColumnBO : logicalColumnBOs) {
			for (LogicalTableBO logicalTableBO : LogicalTableBOs) {
				if (logicalTableBO.getTableType() == 0) {
					PhysicalTableBO physicalTableBO = audienceMetadataService
							.findPhysicalTableId(logicalTableBO.getPhysicalTableId());
					List<PhysicalColumnBO> bos = physicalTableBO.getPhysicalColumns();
					for (PhysicalColumnBO physicalColumnBO : bos) {
						if (physicalColumnBO.getPhysicalColumnName().equals(logicalColumnBO.getPhysicalColumnName())) {
							CustomColumnDefinitionBO bo = new CustomColumnDefinitionBO();
							bo.setIsNullable(physicalColumnBO.getIsNullable());
							bo.setDefaultValue(physicalColumnBO.getColumnDefaultValue());
							bo.setLength(physicalColumnBO.getColumnDataLength());
							bo.setLogicalColumnName(logicalColumnBO.getLogicalColumnName());
							bo.setPhysicalColumnName(logicalColumnBO.getPhysicalColumnName());
							bo.setIsProfilable(logicalColumnBO.getIsProfilable());
							bo.setColumnDataType(logicalColumnBO.getColumnDataType());
							bo.setIsKeyColumn(logicalColumnBO.getIsKeyColumn());
							result.add(bo);
						}
					}
				}
			}
		}
		logger.info("End ::"+getClass().getName()+"fetchAudienceBaseColumns");
		return result;
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public FileDefinitionBO getAllFileDefinitions(Long filedefId) throws FileException {
		return fileDao.getAllFileDefinitions(filedefId);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<Object> getAllTablesAndFiles(char sourceType, Long audienceID) throws FileException {
		return fileDao.getAllTablesAndFiles(sourceType, audienceID);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int updateSchedule(FileScheduleBO fileScheduleBO) throws FileException {
		return fileDao.updateSchedule(fileScheduleBO);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false, rollbackFor=Exception.class)
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public FileDefinitionBO updateFileDefinitionStatus(Long fileDefinitionId, Character fileDefinitionStatus,FileSummaryBO fileSummaryBO) throws FileException {
		logger.debug("Inside::"+getClass().getName()+"updateFileDefinitionStatus()");
		Character finalStatus=fileDefinitionStatus;
		FileDefinitionBO fileDefintionBO=getAllFileDefinitions(fileDefinitionId);
		if(finalStatus!='I' && fileDefintionBO!=null && fileDefintionBO.getFileScheduleBO()!=null && fileDefintionBO.getFileScheduleBO().getSchedulenextdue()!=null){
			FileScheduleBO schedule=fileDefintionBO.getFileScheduleBO();
			//Converting to utc and then again converting to local time zone for comparision.
			schedule.setSchedulenextdue(CommonUtil.toUTC(schedule.getSchedulenextdue().getTime(),TimeZone.getTimeZone(schedule.getTimeZone())));
			schedule.setScheduleEndDate(CommonUtil.toUTC(schedule.getScheduleEndDate().getTime(),TimeZone.getTimeZone(schedule.getTimeZone())));
			if(schedule!=null && schedule.getFrequency()!=null && (schedule.getFrequency()=='D' || schedule.getFrequency()=='W' || schedule.getFrequency()=='M' || schedule.getFrequency()=='N') && schedule.getScheduleEndDate().compareTo(schedule.getSchedulenextdue()) >= 0 )
				finalStatus='W';
			fileSummaryBO.setEndDate(new Date());
			logger.debug("Schedulenextdue :: "+schedule.getSchedulenextdue());
		}
		fileSummaryBO.setStatus(fileDefinitionStatus);
		//Update file definition with updated status.
		if(fileDefintionBO.getFileType()!=null && fileDefintionBO.getFileType().equals('A')){
			listService.updateListStatus(fileDefinitionId,fileDefinitionStatus);
			if(fileDefinitionStatus=='C')
				fileSummaryBO.setDomainWiseCount(getDomainWiseCount(fileDefintionBO));
		}
		FileDefinitionBO updatedFileDefinitionBO = new FileDefinitionBO();
		updatedFileDefinitionBO.setFileDefinitionID(fileDefinitionId);
		updatedFileDefinitionBO.setStatus(finalStatus);
		updatedFileDefinitionBO.setFileSummaryBO(fileSummaryBO);
		return fileDao.updateFileDefinition(updatedFileDefinitionBO);
	}
	
	private Map<String,Long> getDomainWiseCount(FileDefinitionBO fileDefintionBO) throws FileException{
		List<String> individualQueries=new ArrayList<>();
		String tableName="ADHOC_"+fileDefintionBO.getFileDefinitionID();
		for(ColumnDefinitionBO columnDefinition : fileDefintionBO.getFileMapping().getColumnDefinitionList()){
			if (columnDefinition.getColumnType().toLowerCase().contains("EMAIL".toLowerCase())){
				String colName;
				Boolean isCustomColumn=(columnDefinition.getIsCustomColumn()==null||columnDefinition.getIsCustomColumn()=='N')?false:true;
				if(columnDefinition.getPhysicalColumnName()==null){
					colName = columnDefinition.getColumnName().replaceAll("[^a-zA-Z0-9]+","_");
				}else{
					if(isCustomColumn){
						colName = columnDefinition.getPhysicalColumnName().replaceAll("[^a-zA-Z0-9]+","_");
					}else{
						colName =columnDefinition.getPhysicalColumnName();
					}
					
				}
				individualQueries.add("select SUBSTRING("+colName+", STRPOS("+colName+", '@') + 1) as EMAIL_DOMAIN_NAME from "+tableName);
			}
		}
		if(!individualQueries.isEmpty()){
			StringBuilder finalQuery=new StringBuilder();
			finalQuery.insert(0,"select EMAIL_DOMAIN_NAME,count(EMAIL_DOMAIN_NAME) AS EMAIL_DOMAIN_COUNT from (");
			finalQuery.append(StringUtils.join(individualQueries, " UNION ALL "));
			finalQuery.append(") AS combined_result group by EMAIL_DOMAIN_NAME");
			return fileDao.getDomainWiseCount(finalQuery.toString());
		}else
			return new HashMap<>();
	}

	private String escape(String input, String stringToEscape) {
		int k = 0;
		int l = 0;
		String escapedOutput = null;
		StringBuffer tempBuffer = new StringBuffer();
		while (k != -1) {
			k = input.indexOf(stringToEscape, k);
			if (k != -1) {
				tempBuffer.append(input.substring(l, k));
				tempBuffer.append("\\" + stringToEscape);
				k += stringToEscape.length();
				l = k;
			} else {
				tempBuffer.append(input.substring(l));
			}
		}
		escapedOutput = tempBuffer.toString();
		tempBuffer.delete(0, tempBuffer.length());
		return escapedOutput;
	}

	private String getSpecialCharEscapeMap(String remoteFilePath) {
		HashMap<String, String> regExMap = new HashMap<String, String>();
		regExMap.put("!", "\\!");
		regExMap.put("@", "\\@");
		regExMap.put("$", "\\$");
		regExMap.put("^", "\\^");
		regExMap.put("&", "\\&");
		regExMap.put("{", "\\{");
		regExMap.put("}", "\\}");
		regExMap.put("(", "\\(");
		regExMap.put(")", "\\)");
		regExMap.put("[", "\\[");
		regExMap.put("]", "\\]");
		regExMap.put(";", "\\;");
		regExMap.put("'", "\\'");
		regExMap.put(",", "\\,");
		Iterator itr = regExMap.keySet().iterator();
		while (itr.hasNext()) {
			String key = (String) itr.next();
			String value = (String) regExMap.get(key);
			remoteFilePath = remoteFilePath.replace(key, value);
		}
		return remoteFilePath;
	}
	private String replacer(String str,char  textQualifier,char delimiter){
		try {
			String copy = "";
			boolean inQuotes = false;
			for(int i=0; i<str.length(); ++i)
			{
				if (str.charAt(i)==textQualifier)
					inQuotes = !inQuotes;
					if (str.charAt(i)==delimiter && inQuotes)
						copy += "";
				else
					copy += str.charAt(i);
			}
			return copy;
		} catch (Exception e) {
		}
		return str;
	 }
	
	@Override
	public String zipIt(String outputFileName,String sourceFolder) throws Exception{
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		try {
			List<String> fileList = new ArrayList<String>();
			generateFileList(new File(sourceFolder),fileList,sourceFolder);
			fos = new FileOutputStream(outputFileName);
			zos = new ZipOutputStream(fos);
			byte[] buffer = new byte[1024];
			for (String file : fileList) {
				ZipEntry ze = new ZipEntry(file);
				zos.putNextEntry(ze);
				FileInputStream in = new FileInputStream(sourceFolder + File.separator + file);
				int len;
				while ((len = in.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				in.close();
			}
			zos.closeEntry();
		} catch (IOException ex) {
			throw new FileException("FL0062");
		}finally {
			try {
				if(zos!= null)
					zos.close();
				if(fos!= null)
					fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return outputFileName;
	}
	private List<String> generateFileList(File node,List<String> fileList,String sourceFolder) {
		if (node.isFile()) {
			fileList.add(node.getAbsoluteFile().toString().substring(sourceFolder.length() + 1,
					node.getAbsoluteFile().toString().length()));
		}
		if (node.isDirectory()) {
			String[] subNote = node.list();
			for (String filename : subNote) {
				generateFileList(new File(node, filename),fileList,sourceFolder);
			}
		}
		return fileList;
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public FileActivityBO getAllFileActivityByFileDefId(long filedefinitionId) throws FileException{
		return fileDao.getAllFileActivityByFileDefId(filedefinitionId);
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public boolean updateFileActivitystatus(Character status,String fileactivityid) throws FileException{
		FileActivityBO fileActivityBO = fileDao.getAllFileActivities(Long.parseLong(fileactivityid));
		if(fileActivityBO.getFileDefinitionID() != null && fileActivityBO.getFileDefinitionID() > 0){
			invokeCancelNotifications(status, fileActivityBO.getFileDefinitionID());
		}
		return fileDao.updateFileActivitystatus(status, fileactivityid);
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public boolean updateFileActivitystatus(Character status,String fileactivityid,long filedefinitionId) throws FileException{
		invokeCancelNotifications(status, filedefinitionId);
		fileDao.updateFileDefifinationStatus('W', filedefinitionId);
		return fileDao.updateFileActivitystatus(status, fileactivityid);
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Long existFileactivityByFiledefinitionId(long filedefintionid) throws FileException{
		return fileDao.existFileactivityByFiledefinitionId(filedefintionid);
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<CustomColumnDefinitionBO> getTableColumns(String tableName)throws Exception{
		return whDao.getTableColumns(tableName);
	}
	
	class DataMapping{
		private String key;
		private List<String> values;
		DataMapping(String key,List<String> values){
			this.key = key;
			this.values = values;
		}
		public String getKey(){
			return key;
		}
		public List<String> getValues(){
			return values;
		}
	}

	@Override
	public long checkAudienceExistInFileDefinitions(Long audienceId) throws FileException {
		return fileDao.checkAudienceExistInFileDefinitions(audienceId);
	}
	
	/**
	 * 
	 * @param status
	 * @param filedefinitionId
	 * @throws FileException
	 */
	public void invokeCancelNotifications(Character status,long filedefinitionId) throws FileException{
		if('S' == status){
			FileDefinitionBO fileDefinitionBO = fileDao.getAllFileDefinitions(filedefinitionId);
			workflowNotificationHandler.sendCancelNotification(fileDefinitionBO, "Cancelled");
		}
		
	}
	
}

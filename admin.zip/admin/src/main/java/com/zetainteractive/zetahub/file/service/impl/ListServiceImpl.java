/**
 * 
 */
package com.zetainteractive.zetahub.file.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.audit4j.core.AuditManager;
import org.audit4j.core.dto.AuditEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.zetainteractive.zetahub.admin.audience.dao.AudienceWarehouseMetaDataDAO;
import com.zetainteractive.zetahub.admin.exception.AdminException;
import com.zetainteractive.zetahub.admin.service.DepartmentService;
import com.zetainteractive.zetahub.admin.util.AdminDependencyCalls;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.bootstarter.rest.RestRequestHandler;
import com.zetainteractive.zetahub.commons.domain.CategoryBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FolderBO;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.file.dao.FileDao;
import com.zetainteractive.zetahub.file.dao.ListDao;
import com.zetainteractive.zetahub.file.exception.FileException;
import com.zetainteractive.zetahub.file.service.FileService;
import com.zetainteractive.zetahub.file.service.ListService;

/**
 * @author Paparao.Pandiri
 *
 */
@Service
public class ListServiceImpl implements ListService {
	
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	
	AuditManager auditManager = (AuditManager) AuditManager.getInstance();

	@Autowired
	ListDao listDao;

	@Autowired
	FileDao fileDao;
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	FileService fileService;
	
	@Autowired
	AudienceWarehouseMetaDataDAO whDao;
	
	@Autowired
	AdminDependencyCalls adminDependencyCalls;

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Map<String, Object> getAllLists(Map<String, String> searchCriteria) throws Exception {
		logger.info("Begin :: "+getClass().getName()+" getAllLists()");
		if(searchCriteria.get("departmentID") == null){
			throw new FileException("FL0066");
		} 
		FolderBO folderBO = departmentService.findFolder("TRASH", 'A', Long.valueOf(searchCriteria.get("departmentID")));
		long folderID = folderBO!=null?folderBO.getFolderid():-1;
		return listDao.getAllLists(searchCriteria,folderID);
			
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ListDefinitionBO saveList(ListDefinitionBO listDefinitionBO) throws Exception {
		logger.info("Begin :: "+getClass().getName()+" saveList()");
		if ((listDefinitionBO.getListID()!=null && listDefinitionBO.getListID()!=0) || !listDao.existListName(listDefinitionBO.getName(),listDefinitionBO.getDeptID())) {
			if (listDefinitionBO.getSourceType() != null && listDefinitionBO.getSourceType() == 'T'
					&& !fileDao.existTableName(listDefinitionBO.getTableName(),0)) {
				throw new FileException("F00048");
			}
			if (listDefinitionBO.getSourceType() != null && listDefinitionBO.getSourceType() == 'F'
					&& listDefinitionBO.getFileDefinitionID() != null) {
				Map<String, String> searchCriteria = new HashMap<String, String>();
				searchCriteria.put("filedefinitionid", listDefinitionBO.getFileDefinitionID().toString());
				searchCriteria.put("departmentID", listDefinitionBO.getDeptID()+"");
				HashMap<String, Object> result = fileDao.getAllFileDefinitions(searchCriteria,false);
				Long totalRecords = new Long(result.get("totalRecords").toString());
				if (totalRecords == 0) {
					throw new FileException("F00050");
				}
			}
			List<AdminException> errorsList = new ArrayList<>();
			if(listDefinitionBO.getFolderID()!=0){
				FolderBO folder = departmentService.getFolder(listDefinitionBO.getFolderID());
				if (!errorsList.isEmpty() || folder == null) {
					throw new FileException("F00049");
				}
			}
			if(listDefinitionBO.getCategoryID()!=0){
				CategoryBO category = departmentService.getCategory(listDefinitionBO.getCategoryID());
				if (!errorsList.isEmpty() || category == null) {
					throw new FileException("F00051");
				}
			}
			if (departmentService.getDepartment(listDefinitionBO.getDeptID()) == null) {
				throw new FileException("F00053");
			}

			if (listDefinitionBO.getStatus() == null)
				listDefinitionBO.setStatus('C');
			AuditEvent event = new AuditEvent();
            event.setActor("ListServiceImpl");
            event.setAction("save or update AdhocList");
            event.addField("Save or update AdhocList name :: ",listDefinitionBO.getName());
            auditManager.audit(event);
			return listDao.saveList(listDefinitionBO);
		} else {
			AuditEvent event = new AuditEvent();
            event.setActor("ListServiceImpl");
            event.setAction("save or update AdhocList");
            event.addField("Save or update AdhocList exception created :: ",listDefinitionBO.getName());
            auditManager.audit(event);
			throw new FileException("F00040");
		}
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int deleteAdhocList(String listid) throws Exception {
		logger.info("Begin ::"+getClass().getName()+"deleteAdhocList()");
		AuditEvent event = new AuditEvent();
        event.setActor("ListServiceImpl");
        event.setAction("delete AdhocList");
        event.addField("delete AdhocList by id :: ",listid);
        auditManager.audit(event);
        logger.info("End ::"+getClass().getName()+"deleteAdhocList()");
		return listDao.deleteAdhocList(listid);
	}

	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<ListDefinitionBO> getListByListTypeAudienceId(char listType, long audienceId) throws Exception {
		return listDao.getListByListTypeAudienceId(listType, audienceId);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int updateList(String column, String value, String listIdsStr,String deptID) throws FileException, Exception {
		if (value.equals("trash")) {
			AuditEvent event = new AuditEvent();
	        event.setActor("ListServiceImpl");
	        event.setAction("Move to Trash AdhocList");
	        event.addField("Move to Trash AdhocList by id :: ",listIdsStr);
	        auditManager.audit(event);
	        if(listIdsStr != null){
	        	for (String listId : listIdsStr.split(",")) {
	        		String[] listNames = column.split(",");
	        		String listName = null;
	        		for (String list : listNames) {
	        			if(list.startsWith(listId)){
	        				listName = list;
	        			}
					}
        			listName = listName.substring(listId.length(),listName.length());
        			
    				ResponseEntity<List<String>> response = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/criteriaExist/list/"+listId,
							HttpMethod.GET, new HttpEntity(ZetaUtil.getHelper().getHeaders()), new ParameterizedTypeReference<List<String>>() {}); 
    				if(response.getStatusCode() == HttpStatus.BAD_REQUEST){
    					throw new FileException("FL0074");
    				}
    				List<String> res = response.getBody();
	        		if(res.size() > 0){
	        			throw new FileException("FL0073",listName);
	        		}
	        		Boolean canDelete=adminDependencyCalls.canDeleteList(listName); 
	        		if(!canDelete)
	        			throw new FileException("FL0075",listName);
				}
	        }
			FolderBO folderBO = departmentService.findFolder("TRASH", 'A', Long.valueOf(deptID));
			return listDao.updateList(folderBO.getFolderid(), listIdsStr);
		} else if(value.equals("updatefolderid")){
			String[] listIds = listIdsStr.toString().split(",");
			AuditEvent event = new AuditEvent();
	        event.setActor("ListServiceImpl");
	        event.setAction("Update AdhocList folders");
			for (String id : listIds) {
				event.addField("Update AdhocList folders by id :: ",id);
				ListDefinitionBO bo = listDao.getList(Long.valueOf(id));
				listDao.updateList("folderid", bo.getPreviousFolderID().toString(),id);
			}
			auditManager.audit(event);
			return 1;
		} else {
			String[] listIds = listIdsStr.toString().split(",");
			AuditEvent event = new AuditEvent();
	        event.setActor("ListServiceImpl");
	        event.setAction("update AdhocList");
	        event.addField("update AdhocList by id :: ",listIdsStr);
	        for (String id : listIds) {
				event.addField("Update AdhocList folders by id :: ",id);
				ListDefinitionBO bo = listDao.getList(Long.valueOf(id));
				if (!column.equalsIgnoreCase("categoryid"))
					listDao.updateList("previousfolderid", bo.getFolderID().toString(),id);
				listDao.updateList(column, value, id);
			}
	        auditManager.audit(event);
			return 1;
		}
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ListDefinitionBO saveFileAndListDefinition(ListDefinitionBO listDefinitionBO,
			FileDefinitionBO fileDefinitionBO,MultipartFile file) throws Exception {
		logger.info("Begin ::"+getClass().getName()+"saveFileAndListDefinition");
		FileDefinitionBO bo = fileService.saveOrUpdateFileDefinition(fileDefinitionBO,file);
		listDefinitionBO.setFileDefinitionID(bo.getFileDefinitionID());
		listDefinitionBO.setTableName("ADHOC_"+bo.getFileDefinitionID());
		AuditEvent event = new AuditEvent();
        event.setActor("ListServiceImpl");
        event.setAction("save filedefinition as AdhocList");
        event.addField("save filedefinition as AdhocList :: ",listDefinitionBO.getName());
        auditManager.audit(event);
		return saveList(listDefinitionBO);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ListDefinitionBO findListByListName(String listName) throws Exception {
		return listDao.findListByListName(listName);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public ListDefinitionBO findListByListName(String listName,long deptid) throws Exception{
		return listDao.findListByListName(listName,deptid);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<ListDefinitionBO> getListByFolderId(Long departmentId) throws Exception{
		FolderBO folderBO = departmentService.findFolder("TRASH", 'A', departmentId);
		if(folderBO==null)
			throw new FileException("FL0077");
		return listDao.getListByFolderId(folderBO.getFolderid());
	}
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int restoreTrash(String listId) throws FileException{
		logger.info("Begin ::"+getClass().getName()+"restoreTrash()");
		AuditEvent event = new AuditEvent();
        event.setActor("ListServiceImpl");
        event.setAction("Restore Trash for  AdhocList");
        event.addField("Restore Trash for  AdhocList by id :: ",listId);
        auditManager.audit(event);
		return listDao.restoreTrash(listId);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int deleteListByFolderId(String folderid) throws FileException{
		return listDao.deleteListByFolderId(folderid);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public int updateListStatus(Long fileDefinitionId,Character status) throws FileException{
		AuditEvent event = new AuditEvent();
        event.setActor("ListServiceImpl");
        event.setAction("update AdhocList status");
        event.addField("update AdhocList status by filedefinition id :: ",fileDefinitionId);
        auditManager.audit(event);
		return listDao.updateListStatus(fileDefinitionId,status);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<String> getEmailsFromVericaDB(long listId) throws Exception{
		String tableName = listDao.getTableNameById(listId);
		if(tableName == null){
			throw new FileException("","TableName doesn't exist");
		}
		return whDao.getEmailDataByTableName(tableName);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Object getAllListsByIds(String ids) throws Exception {
		return listDao.getAllListsByIds(ids);
	}

	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public Map<String, Object> getAllListsForAPI(Map<String, String> searchCriteria) throws Exception {
		logger.info("Begin :: "+getClass().getName()+" getAllListsAPI()");
		return listDao.getAllListsForAPI(searchCriteria);
	}
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public String getListTypeByFileDefId(long fileDefinitionId){
		return listDao.getListTypeByFileDefId(fileDefinitionId);
	}
	
	
	@Override
	@Retryable(
            value = {CannotGetJdbcConnectionException.class  }, 
            maxAttempts = 4,
            backoff = @Backoff( delay = 2000))
	public List<ListDefinitionBO> getListsByNames(Set<String> names){
		return listDao.getListsByNames(names);
	}
}

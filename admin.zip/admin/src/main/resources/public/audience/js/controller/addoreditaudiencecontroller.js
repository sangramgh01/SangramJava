//var s;
zhapp.controller('addoreditaudiencecontroller', ['$rootScope', '$scope', '$q','$filter',  'audiencesService','$timeout','$interval',
    function($rootScope, $scope, $q,$filter,  audiencesService, $timeout,$interval) {
		//s=$scope;
	$scope.ad = {};
        $scope.ad.isConfigure = false; 
        $scope.ad.audienceId = 0;
        $scope.ad.physicalTables = {};
        $scope.ad.selectedRecipientTable = "";
        $scope.ad.selectedDimensionTables = [];
        $scope.selectedDimensionTable = "";
        $scope.ad.physicalColumns = {};
        $scope.ad.recipientphysicalColumns = [];
        $scope.ad.dimensionPhysicalColumns = [];
        $scope.ad.recipientKeyColumns;
        $scope.ad.audienceDetailsBO = {};
        $scope.ad.audienceDetailsBO.logicalTables = [];
        $scope.ad.audienceDetailsBO.audienceName = sessionStorage.audienceName;
        $scope.ad.initialRecipientTable = {};
        $scope.ad.isDimensionSelected = [];
        $scope.ad.usedPhysicalTables = [];
        $scope.ad.currentStep = 0;
        $scope.ad.activeDept = null;
        $scope.ad.isbrowserIE = false;
        $scope.ad.isSaveAudience = false;
        $scope.ad.recipientKeyColumnsArray = [];
        $scope.ad.existingDimensionTables = [];
        $scope.ad.selectList=[];
        $scope.zetacontext = "";
        $scope.userRegionTimezone = "";
        $scope.audiencetemplate = {};
        $scope.showNextStep = false;
        $scope.deleteDimensionindex = "";
        $scope.deleteDimensionTable = "";
        $scope.isBackButton = false;
       
       // $scope.recipientTable=undefined;
        $scope.Timer ;
        initialzeController();
        
    	$scope.ad.loadCommonDialogs=function(){
    		loadCommonDialogs();
    	};

        function initialzeController() {
          //Comment getContext()
        	 $scope.Timer = $interval(function () {
        		 audiencesService.audienceHealthCheck();
             }, 900000);  // 15 Min

        	$q.when(true).then(function() {
                var promises = [];
                $scope.ad.audienceId = sessionStorage.AudienceIdToEdit;
                $scope.ad.findAllColumnTypes();
                if ($scope.ad.audienceId === 0 || $scope.ad.audienceId === undefined || $scope.ad.audienceId === "0") {
                	$scope.prepareAudienceProps()
                	$scope.ad.audienceRightPane="audience/templates/createAudience.html"; 
                }
                if ($scope.ad.audienceId > 0) {
                    $scope.ad.disableLeftPane = false;
                    $scope.ad.audienceRightPane="audience/templates/audienceSummary.html"; 
                    $scope.loadAudienceSummary();
                } else {
                    $scope.ad.isConfigure = true;
                    $scope.ad.disableLeftPane = true;
                    $scope.configureAddAudience();
                }
            });
        };
        
        $scope.ad.summery = false;
        $scope.ad.configure = false;
    	$scope.loadAudienceSummary = function() {
	    	$scope.ad.audienceRightPane="audience/templates/audienceSummary.html"; 
	        $scope.ad.disableLeftPane = false;
	        var promise = $scope.getAudienceDetails($scope.ad.audienceId);
	         promise.then(function(result){
	            	  /* if($scope.ad.isSaveAudience && $scope.deptAccess)
	                       $scope.validateDeptAccess(audiencesService.audienceId);*/
	         });
	        		
//	        $scope.ad.summery = !$scope.ad.summery;
	        /*if($scope.ad.summery){
            	$scope.ad.configure = false;
            }*/
    	};
        

        $scope.prepareAudienceProps = function() {
        	$scope.ad.audienceDetailsBO.audienceId = 0;
            $scope.ad.audienceId = 0;
            $scope.ad.audienceDetailsBO.name = sessionStorage.audiencename;
            $scope.ad.audienceDetailsBO.audienceType = 0;
            $scope.compareVO = $scope.ad.audienceDetailsBO;
      };
      
        
        function getContext() {
            var defer = $q.defer();
            commonService.getContext().success(function(result) {
                $scope.zetacontext = result.zetacontext;
                $scope.userRegionTimezone = result.userRegionTimezone;
                $rootScope.DEPT_NAME = $scope.zetacontext.activeDeptName;
                $rootScope.DEPTID = $scope.zetacontext.activeDepartment;
                $scope.ad.activeDept = $scope.zetacontext.activeDeptName;
                $scope.ad.audienceDetailsBO.deptId = $rootScope.DEPTID;
                defer.resolve();
            });
            return defer.promise;
        };
        
        /**
         * Configure audience
         */
        $scope.configureAddAudience = function() {
            var promises = [];
            promises.push($scope.fetchPhysicaltables());
            $q.all(promises).then(function() {
                $scope.ad.selectedRecipientTable = "";
            });
        };

        $scope.fetchPhysicaltables = function() {
            var defer = $q.defer();
            var physicalTables = [];
            audiencesService.fetchPhysicaltables($scope.ad.audienceId,$scope.ad.isRecipientSelected).success(function(result) {
            	var resultsort=[];
            	resultsort = sortByKey(result,'physicalTableName');
            	function sortByKey(res, TableName) {
            	    return res.sort(function(a, b) {
            	        var x = a[TableName]; var y = b[TableName];
            	        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
            	    });
            	}
            	angular.forEach(resultsort, function(physicaltables) {
                    if (physicaltables.logicalTableName === null || physicaltables.logicalTableName === undefined || physicaltables.logicalTableName === "") {
                        physicaltables.logicalTableName = physicaltables.physicalTableName;
                        physicaltables.isUsed = false;
                    }
                    physicalTables.push(physicaltables);
                });
                $scope.ad.physicalTables =  physicalTables;
                if ($scope.showNextStep) {
                    $scope.ad.physicalTables = $scope.ad.physicalTables.filter(function(el) {
                        return el.physicalTableId !== $scope.ad.selectedRecipientTable.physicalTableId;
                    });
                }
                console.dir($scope.ad.usedPhysicalTables);
                if ($scope.ad.usedPhysicalTables !== null && $scope.ad.usedPhysicalTables !== undefined && $scope.ad.usedPhysicalTables !== "") {
                    angular.forEach($scope.ad.usedPhysicalTables, function(usedTables) {
                        if (usedTables !== null && usedTables !== undefined && usedTables !== "") {
                            $scope.ad.physicalTables = $scope.ad.physicalTables.filter(function(el) {
                                if(el.physicalTableId == usedTables.physicalTableId)
                                	el.isSelected = true;
                                else
                                	el.isSelected = false;
                                return el;
                            });
                        }
                    });
                }
                defer.resolve();
            });
            return defer.promise;
        };
        
        $scope.fetchPhysicalColumnsForRecipient = function(recipientTable) {
            angular.forEach($scope.ad.physicalTables, function(physicalTableObj) {
            	if(recipientTable && (physicalTableObj.physicalTableId === recipientTable.physicalTableId)){
            		var logicalColumns = physicalTableObj.physicalColumns;
            		angular.forEach(logicalColumns, function(logicalColumn) {
            			logicalColumn.logicalColumnName = logicalColumn.physicalColumnName;
            		});
            		recipientTable.logicalColumns = logicalColumns;
                    $scope.ad.selectList= logicalColumns;
                    $scope.ad.customCheck();
            	}
            });
        };
        $scope.ad.saveAudienceRecipient = function() {
        	var isnullableselected = false;
        	var isKeyAttrSelected = false;
            var isNotnullColumnsNotSelected = false;
            var isTableDisplayNameEmpty = false;
            var isColumnDisplayNameEmpty = false;
            var ismandatoryColumnsExists=$scope.checkMandatoryColumns();
            var ismandatoryColumnsDataTypeValid=$scope.checkMandatoryColumnsDataType();
            if (ismandatoryColumnsExists!=true){
            	showErrorMessage("AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT and MODIFIED_DT columns are mandatory for Audience creation.");
            	return;
            }
            if (ismandatoryColumnsDataTypeValid!=true){
            	showErrorMessage("AUDIENCE_MEMBER_ID and AUDIENCE_TYPE_ID data type should be BIGINT,CREATION_DT and MODIFIED_DT data type should be TIMESTAMP or DATE. ");
            	return;
            }
            if ($scope.ad.selectedRecipientTable !== null && $scope.ad.selectedRecipientTable !== undefined && $scope.ad.selectedRecipientTable !== "") {
                $scope.ad.audienceDetailsBO.audienceId = $scope.ad.audienceId;
                $scope.ad.audienceDetailsBO.departmentId = zhapp.loginUser.departmentID;
                $scope.ad.audienceDetailsBO.audienceStatus = "A";
                $scope.ad.audienceDetailsBO.isDefault = 0;
                $scope.ad.audienceDetailsBO.recipientTableName = $scope.ad.selectedRecipientTable.logicalTableName;
                $scope.ad.audienceDetailsBO.logicalTables = [];
                var logicalTables = angular.copy($scope.ad.selectedRecipientTable);
                var logicalColumns = [];
                logicalTables.physicalTableId = $scope.ad.selectedRecipientTable.physicalTableId;
                if ($scope.ad.selectedRecipientTable.logicalTableName !== "" && $scope.ad.selectedRecipientTable.logicalTableName !== null) {
                	logicalTables.logicalTableName = $scope.ad.selectedRecipientTable.logicalTableName;
                } else {
                    isTableDisplayNameEmpty = true;
                }
                logicalTables.tableType = 0;
                angular.forEach($scope.ad.selectedRecipientTable.logicalColumns, function(recipientcolumn) {
                    if (recipientcolumn.selected) {
                        if (recipientcolumn.logicalColumnName === undefined || recipientcolumn.logicalColumnName === "" || recipientcolumn.logicalColumnName === null) {
                            isColumnDisplayNameEmpty = true;
                        }
                        if (recipientcolumn.keyAttribute) {
                            isKeyAttrSelected = true;
                            recipientcolumn.keyAttribute = true;
                            recipientcolumn.isKeyColumn = "Y";
                            if (recipientcolumn.isNullable == "Y"){
                            	isnullableselected=true;
                            }
                        } else {
                        	recipientcolumn.keyAttribute = false;
                        	recipientcolumn.isKeyColumn = "N";
                        }
                        if (recipientcolumn.profileable) {
                        	recipientcolumn.profileable = true;
                        	recipientcolumn.isProfilable = "Y";
                        } else {
                        	recipientcolumn.profileable = false;
                        	recipientcolumn.isProfilable = "N";
                        }
                        logicalColumns.push(recipientcolumn);
                    }else if(recipientcolumn.nullable === "N" && !recipientcolumn.selected && recipientcolumn.physicalColumnName.toLowerCase()!=="audience_member_id" && recipientcolumn.physicalColumnName.toLowerCase() !=="audience_type_id" && recipientcolumn.physicalColumnName.toLowerCase() !=="creation_dt" && recipientcolumn.physicalColumnName.toLowerCase() !=="modified_dt"){
                    	  isNotnullColumnsNotSelected = true;
                    }
                });
                if (logicalColumns.length > 0 && isKeyAttrSelected && !isTableDisplayNameEmpty && !isColumnDisplayNameEmpty && !isNotnullColumnsNotSelected && !isnullableselected) {
                	logicalColumns = $filter('orderBy')(logicalColumns, 'physicalColumnName');
                    logicalTables.logicalColumns = logicalColumns;
                    $scope.ad.audienceDetailsBO.logicalTables.push(logicalTables);
                    if (angular.equals(logicalTables, $scope.ad.baseTable)) {
                        if (!$scope.ad.isSaveAudience) {
                            $scope.ad.onNextClick('D');
                        }
                        if ($scope.ad.isSaveAudience) {
                            showErrorMessage("There are no changes to save.");
                        }
                        $scope.ad.isSaveAudience = false;
                    } else {
                        var defer = $q.defer();
                        if($scope.ad.audienceDetailsBO.audienceId === undefined || $scope.ad.audienceDetailsBO.audienceId === 0){
                        		audiencesService.saveAudience($scope.ad.audienceDetailsBO).error(function(result){
                        			showErrorMessage(getErrorMessage(result)); 
             		  		 	}).success(function(result) {
             		  		 	    audiencesService.audienceId = result.audienceId;
	                        		$scope.ad.moveToDimensionConfiguration(result);
	                        		$scope.ad.initialRecipientTable = angular.copy($scope.ad.selectedRecipientTable);
									var prom = $scope.validateDeptAccess(result.audienceId);
	                                prom.then(function(result){
	                                	defer.resolve();
	                                });
             		  		 	});
                        }else{
                        	angular.forEach($scope.ad.selectedDimensionTables,function(dimensionTable){
                        		dimensionTable.logicalColumns = dimensionTable.logicalColumns.filter(function(el) {
                                    return el.selected;
                                });
                        		$scope.ad.audienceDetailsBO.logicalTables.push(dimensionTable);
                        	})
                        	audiencesService.updateAudience($scope.ad.audienceDetailsBO).error(function(result){
                				 showErrorMessage(getErrorMessage(result)); 
               			 		}).success(function(result) {
                        		$scope.ad.moveToDimensionConfiguration($scope.ad.audienceDetailsBO);
                        		if($scope.ad.audienceDetailsBO.logicalTables.length >1){
                        			$scope.savedTable=true;
                        			$scope.existingAudience=angular.copy($scope.ad.audienceDetailsBO);
                        		}
                                defer.resolve();
                            });
                        }
                        return defer.promise;
                    }
                } else if (isTableDisplayNameEmpty) {
                    showErrorMessage("Recipient table display name can not be empty.");
                    return;
                } else if (isColumnDisplayNameEmpty) {
                    showErrorMessage("Recipient column display name can not be empty.");
                    return;
                }else if(isNotnullColumnsNotSelected){
                	showErrorMessage("All not null columns are not mapped in recipient table.");
                	 return false;
                }
                else if(isnullableselected){
                	showErrorMessage("Nullable columns cannot be selected as key attribute.");
               	 return false;
               }
                else {
                    showErrorMessage("Please select atleast one recipient column as key attribute");
                    return;
                }
            } else {
                showErrorMessage("please select recipient table before saving");
            }
            $scope.compareVO = $scope.ad.audienceDetailsBO;
        };
        
        $scope.isColumnSaved = function(selectedDimensionTable,updatedcolumn){
        	var issavedcolumn = false;
        	if ($scope.savedTable==true){	
        		angular.forEach($scope.existingAudience.logicalTables,function(dimensiontable){
        		if(dimensiontable.tableType!=0 && (dimensiontable.physicalTableName===selectedDimensionTable.physicalTableName )){
        			angular.forEach(dimensiontable.logicalColumns,function(logicalcolumn){
        				if(updatedcolumn.physicalColumnName===logicalcolumn.physicalColumnName){
        					issavedcolumn= true;
        				}
        			});
        		}
        	});
        	}
        	return issavedcolumn;
        };
        $scope.checkMandatoryColumns=function(){
        	var isModifiedDateExists=false; 
        	var isCreateDateExists=false;
        	var isAudienceTypeIdExists=false;
        	var isAudienceMemberIdExists=false;
        	
        	angular.forEach($scope.ad.selectedRecipientTable.logicalColumns, function(recipientcolumn) {
        		if(recipientcolumn.physicalColumnName=="AUDIENCE_MEMBER_ID" && recipientcolumn.selected==true ){
        			isAudienceMemberIdExists=true;
        		}
        		if(recipientcolumn.physicalColumnName=="AUDIENCE_TYPE_ID" && recipientcolumn.selected==true){
        			isAudienceTypeIdExists=true;
        		}
        		if(recipientcolumn.physicalColumnName=="CREATION_DT" && recipientcolumn.selected==true){
        			isCreateDateExists=true;
        		}
        		if(recipientcolumn.physicalColumnName=="MODIFIED_DT"&& recipientcolumn.selected==true){
        			isModifiedDateExists=true;
        		}
        	});
        	if (isModifiedDateExists!=true ||isCreateDateExists !=true ||isAudienceTypeIdExists!=true ||isAudienceMemberIdExists!=true){
        		return false;
        	}else{
        		return true;
        	}
        }
        $scope.checkMandatoryColumnsDataType=function(){
        	var isModifiedDateDataTypeValid=false;
        	var isCreateDateDataTypeValid=false;
        	var isAudienceTypeIdDataTypeValid=false;
        	var isAudienceMemberIdDataTypeValid=false;
        	angular.forEach($scope.ad.selectedRecipientTable.logicalColumns, function(recipientcolumn){
        		if(recipientcolumn.physicalColumnName=="AUDIENCE_MEMBER_ID" && recipientcolumn.selected==true){
        			if($scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="BIGINT"){
        				isAudienceMemberIdDataTypeValid=true;
        			}
        		}
        		if(recipientcolumn.physicalColumnName=="AUDIENCE_TYPE_ID"&& recipientcolumn.selected==true){
        			if($scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="BIGINT"){
        				isAudienceTypeIdDataTypeValid=true;
        			}
        		}
        		if(recipientcolumn.physicalColumnName=="CREATION_DT"&& recipientcolumn.selected==true){
        			if($scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="TIMESTAMP" || $scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="DATE" ){
        				isCreateDateDataTypeValid=true;
        			}
        		}
        		if(recipientcolumn.physicalColumnName=="MODIFIED_DT" && recipientcolumn.selected==true){
        			if($scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="TIMESTAMP" || $scope.ad.getColumnTypeValue(recipientcolumn.columnDataType)=="DATE"){
        				isModifiedDateDataTypeValid=true;
        			}
        		}
        	});
        	if (isModifiedDateDataTypeValid!=true || isCreateDateDataTypeValid !=true || isAudienceTypeIdDataTypeValid!=true || isAudienceMemberIdDataTypeValid!=true ){
        		return false;
        	}else{
        		return true;
        	}
        }
        $scope.ad.moveToDimensionConfiguration = function(result){
        	$scope.ad.isRecipientSelected =  true;
            $scope.ad.audienceDetailsBO.audienceId = result.audienceId;
            $scope.ad.audienceId = result.audienceId;
            sessionStorage.AudienceIdToEdit = $scope.ad.audienceId;
            if (result.logicalTables[0].tableType === 0) {
                $scope.ad.initialRecipientTable = angular.copy(result.logicalTables[0]);
                /*var physicalTableName = $scope.ad.selectedRecipientTable.physicalTableName;
                $scope.ad.selectedRecipientTable = result.logicalTables[0];
                $scope.ad.selectedRecipientTable.physicalTableName = physicalTableName;
                $scope.fetchPhysicalColumnsForRecipient($scope.ad.selectedRecipientTable);*/
               // $scope.ad.initialRecipientTable = angular.copy(result.logicalTables[0]);
            }
            if (!$scope.ad.isSaveAudience) {
                $scope.ad.onNextClick('D');
            }
            $scope.ad.isSaveAudience = false;
            $scope.compareVO = $scope.ad.audienceDetailsBO;
        }
        
        $scope.deptAccess = false;
        $scope.ad.saveAudience = function() {
        	$scope.ad.audienceDetailsBO.departmentId = zhapp.loginUser.departmentID;
            $scope.ad.isSaveAudience = true;
            $scope.deptAccess = true;
            if ($scope.showNextStep) {
               $scope.ad.saveAudienceDimension();
            } else {
                $scope.ad.saveAudienceRecipient();
            }
        };

        $scope.ad.resetTables = function() {
            if ($scope.ad.audienceId === 0) {
                $scope.configureAddAudience();
            } else {
                var promises = [];
                promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                $q.all(promises).then(function() {});
            }
        };


        $scope.updateSelection = function(physicalColumn) {
            angular.forEach($scope.ad.recipientphysicalColumns, function(physicalColumns) {
                if (physicalColumns.physicalColumnName === physicalColumn.physicalColumnName && !physicalColumns.selected) {
                	
                	if(physicalColumn.logicalColumnId>0){
                		var defer = $q.defer();
	                    audiencesService.checkingLogicalColumnUsage(physicalColumn.logicalColumnId).success(function(result) {
	                    	physicalColumns.keyAttribute = false;
	                        physicalColumns.dimensionAttribute = false;
	                        physicalColumns.logicalColumnName = physicalColumns.physicalColumnName;
	                        physicalColumns.profileable = false;
	                       
	                        defer.resolve();
	                    }).error(function(result){
							  
							  physicalColumns.selected=true;
							  showErrorMessage(result.error);
						});;
	                    return defer.promise;
                	}else{
                		physicalColumns.keyAttribute = false;
                        physicalColumns.dimensionAttribute = false;
                        physicalColumns.logicalColumnName = physicalColumns.physicalColumnName;
                        physicalColumns.profileable = false;
                	}
                }
            });
        };

        $scope.updateDimensionSelection = function(selectedDimensionTable, updatedColumn) {
        	var checkboxstatus= false;
        	if(!updatedColumn.selected){
        		checkboxstatus= true;
        	}
        	var issavedcolumn = $scope.isColumnSaved(selectedDimensionTable,updatedColumn);
        	if(issavedcolumn){
        		updatedColumn.selected=checkboxstatus;
        		showErrorMessage("Cannot delete / modify the table, this is already in use.");
        		return;
        	}
            var index = selectedDimensionTable.physicalTableName + selectedDimensionTable.physicalTableId;
            angular.forEach(selectedDimensionTable.logicalColumns, function(logicalColumn) {
                if (logicalColumn.physicalColumnName === updatedColumn.physicalColumnName && !logicalColumn.selected) {
                	if(updatedColumn.isExistForDimension){
                		var defer = $q.defer();
                        audiencesService.checkingLogicalColumnUsage(updatedColumn.logicalColumnName).success(function(result) {
                        	 logicalColumn.keyAttribute = false;
                             logicalColumn.dimensionAttribute = false;
                             logicalColumn.logicalColumnName = logicalColumn.physicalColumnName;
                             logicalColumn.profileable = false;
                             var removedElem = $scope.ad.recipientKeyColumns.filter(function(el) {
                                 return el.logicalColumnName === updatedColumn.mappedLogicalColumnName;
                             });
                             if(removedElem[0]!==undefined){
                             	$scope.ad.recipientKeyColumnsArray[index].push(removedElem[0]);
                             }
                             logicalColumn.mappedLogicalColumnName = "";
                        }).error(function(result){
    						  logicalColumn.selected=true;
    						  logicalColumn.dimensionAttribute = true;
    						  logicalColumn.mappedLogicalColumnName =updatedColumn.mappedLogicalColumnName;
    						  showErrorMessage(result.error);
    					});
                        return defer.promise;
                	}else{
                		logicalColumn.keyAttribute = false;
                        logicalColumn.dimensionAttribute = false;
                        //logicalColumn.logicalColumnName = logicalColumn.physicalColumnName;
                        logicalColumn.profileable = false;
                        var removedElem = $scope.ad.recipientKeyColumns.filter(function(el) {
                            return el.logicalColumnName === updatedColumn.mappedLogicalColumnName;
                        });
                        if(removedElem[0]!==undefined){
                        	$scope.ad.recipientKeyColumnsArray[index].push(removedElem[0]);
                        }
                        logicalColumn.mappedLogicalColumnName = "";
                	}
                }else{
                	if (logicalColumn.dimensionAttribute && logicalColumn.mappedLogicalColumnName==="") {
                        logicalColumn.dimensionAttribute = false;
                	}
                }
            });
        };

        $scope.getRecipitentKeyColumns = function(physicalTableId, audienceId) {
       	 var defer = $q.defer();
            audiencesService.getLogicalColumnsByAudienceIdAndPhyTableId(physicalTableId, audienceId).success(function(result) {
                $scope.ad.recipientKeyColumns = result;
                angular.forEach($scope.ad.recipientKeyColumns, function(column) {
                	column.selected = true;
                });
                defer.resolve();
            });
            return defer.promise;
       };

        $scope.populateRecipientKeyColumns = function(selectedDimensionTable, column) {
            var index = selectedDimensionTable.physicalTableName + selectedDimensionTable.physicalTableId;
            if ($scope.ad.recipientKeyColumnsArray[index] === "" && column.dimensionAttribute) {
            	column.dimensionAttribute = false;
                showErrorMessage("There are no recipient mappings available");
                return;
            }
            if ($scope.ad.recipientKeyColumnsArray[index] === undefined && column.dimensionAttribute) {
                $scope.ad.recipientKeyColumnsArray[index] = $scope.ad.recipientKeyColumns;
            }
           if (!column.dimensionAttribute && column.mappedLogicalColumnName !== undefined && column.mappedLogicalColumnName !== "") {
                var removedElem = $scope.ad.recipientKeyColumns.filter(function(el) {
                    return el.logicalColumnName === column.mappedLogicalColumnName;
                });
                $scope.ad.recipientKeyColumnsArray[index].push(removedElem[0]);
                $scope.ad.recipientKeyColumnsArray[index] = $filter('orderBy')($scope.ad.recipientKeyColumnsArray[index], 'logicalColumnName');
                column.mappedLogicalColumnName = "";
            }
            angular.forEach($scope.ad.recipientKeyColumnsArray[index], function(recipientKeyColumns) {
             	if(column.columnDataType === 0 && recipientKeyColumns.columnDataType === column.columnDataType ){
            		recipientKeyColumns.disable =false;
            	}else{
            		if(column.columnDataType === 1 && recipientKeyColumns.columnDataType === column.columnDataType){
            			recipientKeyColumns.disable =false;
            		} else if(column.columnDataType === 5 && recipientKeyColumns.columnDataType === column.columnDataType){
            			recipientKeyColumns.disable = false;
            		}else{
            			recipientKeyColumns.disable = true;
            		}
            	}
            });
            angular.forEach(selectedDimensionTable.logicalColumns, function(logicalColumn) {
                if (logicalColumn.physicalColumnName === column.physicalColumnName && !logicalColumn.selected) {
                	logicalColumn.dimensionAttribute = false;
                    
                }else if (logicalColumn.physicalColumnName === column.physicalColumnName && logicalColumn.selected) {
                	logicalColumn.dimensionAttribute = true;
                } else{
                	if (logicalColumn.dimensionAttribute && (logicalColumn.mappedLogicalColumnName===undefined || logicalColumn.mappedLogicalColumnName==="")) {
                		logicalColumn.dimensionAttribute = false;
                	}
                }
            });
            
        };

        $scope.populateRemainingKeyColumns = function(selectedDimensionTable, column) {
            var index = selectedDimensionTable.physicalTableName + selectedDimensionTable.physicalTableId;
            var currentKey = $scope.ad.recipientKeyColumns.filter(function(el) {
                return el.logicalColumnName === column.mappedLogicalColumnName;
            });
            if (currentKey !== undefined && $scope.ad.recipientKeyColumnsArray[index] !== undefined) {
                $scope.ad.recipientKeyColumnsArray[index] = $scope.ad.recipientKeyColumnsArray[index].filter(function(el) {
                    return el.logicalColumnName !== currentKey[0].logicalColumnName;
                });
            } else {
                $scope.ad.recipientKeyColumnsArray[index] = [];
            }
            for(key in $scope.ad.recipientphysicalColumns) {
                if($scope.ad.recipientphysicalColumns[key].logicalColumnName === column.mappedLogicalColumnName) {
                    $scope.ad.recipientphysicalColumns[key].isKeyAttrSelected = true;
                }
            }
        };

        $scope.compareVO = {}; 
        
        $scope.ad.resetDimensionList = [];
        
        $scope.getAudienceDetails = function(audienceId) {
        	var d = $q.defer();
            $scope.ad.recipientKeyColumnsArray = [];
            $scope.ad.recipientKeyColumnsShow = [];
            $scope.ad.selectedDimensionTables = [];
            $scope.ad.dimensionPhysicalColumns = [];
            $scope.ad.isDimensionSelected = [];
	    	 audiencesService.getAudienceSummary(audienceId).success(function(result) {
	             $scope.ad.audienceId = result.audienceId;
	             $scope.ad.audienceDetailsBO = {};
	             $scope.ad.audienceDetailsBO = result;
	             
	             $scope.ad.baseTable = {};
	             angular.forEach($scope.ad.audienceDetailsBO.logicalTables, function(recipientTable) {
	            	 if (recipientTable.tableType==0) {
	            		 var logicalTables = angular.copy(recipientTable);
	                     var logicalColumns = [];
	                     logicalTables.physicalTableId = $scope.ad.selectedRecipientTable.physicalTableId;
	                     if ($scope.ad.selectedRecipientTable.logicalTableName !== "" && $scope.ad.selectedRecipientTable.logicalTableName !== null) {
	                     	logicalTables.logicalTableName = $scope.ad.selectedRecipientTable.logicalTableName;
	                     } else {
	                         isTableDisplayNameEmpty = true;
	                     }
	                     logicalTables.tableType = 0;
	                     angular.forEach($scope.ad.selectedRecipientTable.logicalColumns, function(recipientcolumn) {
	                         if (recipientcolumn.selected) {
	                             if (recipientcolumn.logicalColumnName === undefined || recipientcolumn.logicalColumnName === "" || recipientcolumn.logicalColumnName === null) {
	                                 isColumnDisplayNameEmpty = true;
	                             }
	                             if (recipientcolumn.keyAttribute) {
	                                 isKeyAttrSelected = true;
	                                 recipientcolumn.keyAttribute = true;
	                                 recipientcolumn.isKeyColumn = "Y";
	                                 if (recipientcolumn.isNullable == "Y"){
	                                 	isnullableselected=true;
	                                 }
	                             } else {
	                             	recipientcolumn.keyAttribute = false;
	                             	recipientcolumn.isKeyColumn = "N";
	                             }
	                             if (recipientcolumn.profileable) {
	                             	recipientcolumn.profileable = true;
	                             	recipientcolumn.isProfilable = "Y";
	                             } else {
	                             	recipientcolumn.profileable = false;
	                             	recipientcolumn.isProfilable = "N";
	                             }
	                             logicalColumns.push(recipientcolumn);
	                         }else if(recipientcolumn.nullable === "N" && !recipientcolumn.selected && recipientcolumn.physicalColumnName.toLowerCase()!=="audience_member_id" && recipientcolumn.physicalColumnName.toLowerCase() !=="audience_type_id" && recipientcolumn.physicalColumnName.toLowerCase() !=="creation_dt" && recipientcolumn.physicalColumnName.toLowerCase() !=="modified_dt"){
	                         	  isNotnullColumnsNotSelected = true;
	                         }
	                     });
	                     if (logicalColumns.length > 0) {
	                     	logicalColumns = $filter('orderBy')(logicalColumns, 'physicalColumnName');
	                         logicalTables.logicalColumns = logicalColumns;
	                         $scope.ad.baseTable=logicalTables;
	                     }
                     }
	              });
	             
	             $scope.ad.audienceDetailsBO.logicalTables =  $filter('orderBy')($scope.ad.audienceDetailsBO.logicalTables, 'logicalTableName');
	         	 angular.forEach($scope.ad.audienceDetailsBO.logicalTables, function(recipientTable) {
	         		 	var promises = [];
	         		 	promises.push($scope.ad.fetchPhysicalTableById(recipientTable));
	         		 	$q.all(promises).then(function() {
	                        if ($scope.showNextStep === true && $scope.ad.audienceDetailsBO.logicalTables.length > 1) {
	                        	$scope.ad.selectedDimensionTables =  $filter('orderBy')($scope.ad.selectedDimensionTables, 'logicalTableName');
	                        }
	                    });
	              });
	         	if ($scope.showNextStep === true && $scope.ad.audienceDetailsBO.logicalTables.length == 1) {
                	$scope.ad.selectedDimensionTables.push(null);
                    $scope.ad.isDimensionSelected.push(false);
                }
	             $scope.compareVO = $scope.ad.audienceDetailsBO;
	             d.resolve();
	         }).error(function(result) {
	             showErrorMessage(result.error);
	             d.reject();
	         });
	    	 return d.promise;
        };
        
        
        $scope.ad.fetchPhysicalTableById = function(recipientTable){
        	var d = $q.defer();
        	 audiencesService.findPhysicalTableById(recipientTable.physicalTableId).success(function(physicalTable) {
     			 recipientTable.physicalTableName = physicalTable.physicalTableName;
     			 var recipientColumns =  $scope.ad.prepareRecipientColumns(physicalTable,recipientTable);
     			 recipientColumns = $filter('orderBy')(recipientColumns, 'physicalColumnName');
     			 if (recipientTable.tableType === 0) {
     				 if(recipientTable.logicalColumns.length === recipientColumns.length){
         				 $scope.ad.isSelectAllRColumns = true;
         			 }else{
         				 $scope.ad.isSelectAllRColumns = false;
         			 }
     				 recipientTable.logicalColumns = recipientColumns;
                      $scope.ad.selectedRecipientTable = recipientTable;
                      $scope.getRecipitentKeyColumns($scope.ad.selectedRecipientTable.physicalTableId, $scope.ad.audienceId);
                      $scope.ad.initialRecipientTable = angular.copy(recipientTable);
                      $scope.ad.currentStep = 1;
                  } else if (recipientTable.tableType === 1) {
                 	 recipientTable.logicalColumns = recipientColumns;
                 	 recipientTable.isExistInAudience = true;
                      $scope.ad.selectedDimensionTables.push(recipientTable);
                      $scope.ad.resetDimensionList[recipientTable.physicalTableId] = angular.copy(recipientTable);
                      var promises = [];
                      promises.push($scope.updateRecipientKeyColumns(recipientTable));
                      $q.all(promises).then(function() {
                     	  $scope.ad.isDimensionSelected.push(true);
                     	 d.resolve();
                      });
                  }
              }).error(function(result) {
                  showErrorMessage(result.error);
                  d.reject();
              });
        	 return d.promise;
        }

        $scope.ad.prepareRecipientColumns = function(physicalTable,recipientTable){
        	var recipientColumns = [];
        	 angular.forEach(physicalTable.physicalColumns, function(physcicalColumn) {
				 var obj = {};
				 obj.physicalColumnName = physcicalColumn.physicalColumnName;
				 obj.logicalColumnName = physcicalColumn.physicalColumnName;
				 obj.keyAttribute = false;
				 obj.profileable = false;
				 obj.dimensionAttribute = false;
				 obj.columnDataType = physcicalColumn.columnDataType;
				 obj.selected = false;
				 obj.mappedLogicalColumnName = "";
				 obj.isNullable = physcicalColumn.isNullable;
				 angular.forEach(recipientTable.logicalColumns, function(logicalColumn) {
					 if(logicalColumn.physicalColumnName === physcicalColumn.physicalColumnName && logicalColumn.columnDataType === physcicalColumn.columnDataType){
						 obj.columnDataType = logicalColumn.columnDataType;
						 obj.selected = true;
						 obj.isKeyColumn = logicalColumn.isKeyColumn;
						 obj.logicalColumnName =logicalColumn.logicalColumnName;
						 obj.isProfilable=logicalColumn.isProfilable;
                    	 if(logicalColumn.isKeyColumn === "Y"){
                    		 obj.keyAttribute = true;
                    	 }else{
                    		 obj.keyAttribute = false;
                    	 }
                    	 if(logicalColumn.isProfilable === "Y"){
                    		 obj.profileable = true;
                    	 }else{
                    		 obj.profileable = false;
                    	 }
                    	 angular.forEach(recipientTable.dimensionColumnMappings, function(columnMap) {
                    		 if(columnMap.dimensionColumnName === logicalColumn.logicalColumnName){
                    			 obj.dimensionAttribute = true;
                    			 obj.mappedLogicalColumnName = columnMap.baseLogicalColumnName;
                    		 }else{
                    			 obj.dimensionAttribute = false;
                    		 }
                    	 });
					 }
                 });
				 recipientColumns.push(obj);
			 });
        	 return recipientColumns;
        }
        
        $scope.ad.findAllColumnTypes = function() {
        	var defer = $q.defer();
        	 audiencesService.findAllColumnTypes().success(function(result) {
               	 $scope.ad.columnTypesList = result;
               	 defer.resolve();
              }).error(function(result) {
                   showErrorMessage(result.error);
              });
        	 return defer.promise;
        };
        
        $scope.ad.editAudienceDetails = function() {
        	$scope.ad.audienceDetailsBO.audienceNameEdit = $scope.ad.audienceDetailsBO.audienceName;
            $('.edit-audience').dialog('open');
        };

        $scope.editAudience = function() {
            var defer = $q.defer();
          
            audiencesService.isAudienceExistWithNameAndID($scope.ad.audienceDetailsBO.audienceNameEdit, $scope.ad.audienceId).success(function(result) {
                if (result) {
                	  $scope.ad.audienceDetailsBO.audienceName=$scope.ad.audienceDetailsBO.audienceNameEdit;
                      audiencesService.updateAudienceDetails($scope.ad.audienceDetailsBO).success(function(result) {
                        $(".edit-audience").dialog("close");
                      /*  $scope.ad.audienceDetailsBO.audienceName = $scope.ad.audienceDetailsBO.audienceNameEdit;*/
                        defer.resolve();
                    }).error(function(result) {
                    	showConfigurationErrorMessage(result);
                    });
                } else {
                    showErrorMessage("An audience with the name " + $scope.ad.audienceDetailsBO.audienceNameEdit + " already exists. please modify the name.");
                    return;
                }
            });
            return defer.promise;
        };
    

        $scope.stopEventPropagation = function($event) {
            $event.stopPropagation();
        };

        $scope.closeEditAudiencePopup = function() {
            $(".edit-audience").dialog("close");
        };

        
        $scope.ad.getNullableType = function(type) {
            var audiencetype;
            if (type==="Y" || type==="y")
                audiencetype = "Yes";
            else
                audiencetype = "No";
            return audiencetype;
        };

        $scope.ad.deleteAudienceDimensionPopup = function(index, selectedDimensionTable) {
            $scope.deleteDimensionindex = index;
            if (selectedDimensionTable != undefined) {
                $scope.deleteDimensionTable = selectedDimensionTable;
            }
         showCommonConfirmMessage("Are you sure you want to delete this dimension table ?","Alert","Yes","No",450,function(flag)
          /* $(".delete-dialog").dialog("open");*/
         {
         if(flag)
        	 {
        	 $scope.ad.deleteAudienceDimension();
         
        	 }
        
         else
        	 {
        	 
        	     $scope.ad.closeDeleteDimension(); /*= function() {
                 $scope.deleteDimensionindex = "";
                 $scope.deleteDimensionTable = "";
                 $(".delete-dialog").dialog("close");
             }*/
        	 }
         });
        }
        $scope.ad.deleteAudienceDimension= function(){
         var index = $scope.deleteDimensionindex;
         if ($scope.deleteDimensionTable !== undefined) {
             var selectedDimensionTable = $scope.deleteDimensionTable;
             if (selectedDimensionTable.isExistInAudience !== undefined && selectedDimensionTable.isExistInAudience === true) {
             	var logicalColumnNames = [];
             	angular.forEach(selectedDimensionTable.logicalColumns,function(logicalColumn){
             		logicalColumnNames.push(logicalColumn.logicalColumnName);
             	});
             	var defered = $q.defer();
             	audiencesService.checkingDimentionTableUsage($scope.ad.audienceId,selectedDimensionTable.logicalTableName,logicalColumnNames).success(function(result) {
             		var defer = $q.defer();
             		var resultService = result;
                 	if(resultService == true )
                 		{ showErrorMessage("Cannot delete / modify the table, this is already in use.");
                          return false;
                        }
                     audiencesService.deleteAudienceDimension($scope.ad.audienceId,selectedDimensionTable.physicalTableId).success(function(result) {
                         var promises = [];
                         /*$scope.ad.audienceId = result.audienceDetailsBO.audienceId;
                         $scope.ad.audienceDetailsBO = {};
                         $scope.ad.audienceDetailsBO = result.audienceDetailsBO;*/
                         promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                         promises.push($scope.fetchPhysicaltables());
                         $q.all(promises).then(function() {
                             if ($scope.ad.selectedDimensionTables.length === 0) {
                                 $scope.ad.selectedDimensionTables.push(undefined);
                             }
                         });
                         defer.resolve();
                     }).error(function(result) {
                         showErrorMessage(result.error);
                     });
                     $(".delete-dialog").dialog("close");
                     return defer.promise;
                    
                     defered.resolve();
                 }).error(function(result){
                 	$(".delete-dialog").dialog("close");
						 showErrorMessage(result.error);
					});
             	return defered.promise;
             } else {
                 var index1 = selectedDimensionTable.physicalTableName + selectedDimensionTable.physicalTableId;
                 $(".delete-dialog").dialog("close");
//                 	 $scope.$evalAsync(function(){
    				 $scope.ad.selectedDimensionTables.splice(index, 1);
                     $scope.ad.recipientKeyColumnsArray[index1] = $scope.ad.recipientKeyColumns;
                     $scope.ad.isDimensionSelected.splice(index, 1);
//    				});
                 if ($scope.ad.selectedDimensionTables.length === 0) {
                	 var promises = [];
                     promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                     promises.push($scope.fetchPhysicaltables());
                     $q.all(promises).then(function() {
                     $scope.ad.selectedDimensionTables.push(undefined);
                     });
                 }
             }
         } else {
             $(".delete-dialog").dialog("close");
             $scope.ad.selectedDimensionTables.splice(index, 1);
         }
     };
        $scope.ad.closeDeleteDimension = function() {
            $scope.deleteDimensionindex = "";
            $scope.deleteDimensionTable = "";
            $(".delete-dialog").dialog("close");
        }


         $scope.ad.isSelectAllRColumns = false;
         $scope.ad.customSelectall=function(){
            angular.forEach($scope.ad.selectedRecipientTable.logicalColumns ,function(v,k){
                v.selected=$scope.ad.isSelectAllRColumns;
            });
            if($scope.ad.isSelectAllRColumns==false){
                angular.forEach($scope.ad.selectedRecipientTable.logicalColumns ,function(v,k){
                        v.keyAttribute=false;
                        v.profileable=false;
            });
            }
        };

        $scope.ad.customCheck=function(obj){
            var selectqsChkdList = 0;
            angular.forEach($scope.ad.selectList ,function(v,k){                
                if(v.selected){
                    selectqsChkdList++;
                }
            });            
            $scope.ad.isSelectAllRColumns = ((selectqsChkdList == $scope.ad.selectList.length)? true:false);
        }
        
        
        $scope.ad.onNextClick = function(type) {
            if (type == "R") {
                $scope.showNextStep = false;
                $scope.isBackButton = true;
                $('.lwizard-steps li:nth-child(1)').addClass("active");
                $('.lwizard-steps li:nth-child(2)').removeClass("active");
                var promises = [];
                promises.push($scope.fetchPhysicaltables());
                promises.push($scope.getAudienceDetails($scope.ad.audienceId));
            }
            if (type == "D") {
                $scope.showNextStep = true;
                $scope.ad.isRecipientSelected = true;
                if($scope.ad.usedPhysicalTables && $scope.ad.usedPhysicalTables.length>0) {
	                angular.forEach($scope.ad.usedPhysicalTables, function(usedTables, $index) {
	                    if(usedTables && usedTables.logicalTableId == '0') {
	                    	$scope.ad.usedPhysicalTables.splice($index, 1);
	                    }
	                });
                }
                if ($scope.ad.audienceId > 0 && $scope.isBackButton) {
                    $scope.isBackButton = false;
                }
                $('.lwizard-steps li:nth-child(1)').removeClass("active");
                $('.lwizard-steps li:nth-child(2)').addClass("active");
                var promises = [];
                promises.push($scope.fetchPhysicaltables());
                promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                $q.all(promises).then(function() {
                    $scope.getRecipitentKeyColumns($scope.ad.selectedRecipientTable.physicalTableId, $scope.ad.audienceId);
                });
            }
        };
        
        $scope.updateRecipientKeyColumns = function(recipientTable){
        	var defer = $q.defer();
        	 var index = recipientTable.physicalTableName + recipientTable.physicalTableId;
        	 angular.forEach(recipientTable.logicalColumns, function(dimensioncolumn) {
                 if (dimensioncolumn.mappedLogicalColumnName !== undefined && dimensioncolumn.mappedLogicalColumnName !== "" && dimensioncolumn.mappedLogicalColumnName !== null && $scope.ad.recipientKeyColumns !== undefined) {
                     var currentKey = $scope.ad.recipientKeyColumns.filter(function(el) {
                         return el.logicalColumnName === dimensioncolumn.mappedLogicalColumnName;
                     });
                     if ($scope.ad.recipientKeyColumnsArray[index] === undefined || $scope.ad.recipientKeyColumnsArray[index] === "" || $scope.ad.recipientKeyColumnsArray[index] === null) {
                         $scope.ad.recipientKeyColumnsArray[index] = $scope.ad.recipientKeyColumns;
                     }
                     if ($scope.ad.recipientKeyColumnsArray[index] !== undefined) {
                         $scope.ad.recipientKeyColumnsArray[index] = $scope.ad.recipientKeyColumnsArray[index].filter(function(el) {
                             return el.logicalColumnName !== currentKey[0].logicalColumnName;
                         });
                     }
                 }
             });
             defer.resolve();
             return defer.promise;
        }
      
        $scope.changeDimensionTableSelection = function(recipientTable) {
        	if(recipientTable){
        		var defer = $q.defer();
	            var index = recipientTable.physicalTableName + recipientTable.physicalTableId;
	            var logicalColumns = [];
	            angular.forEach(recipientTable.physicalColumns, function(dimensioncolumn) {
	            	$scope.ad.recipientKeyColumnsArray[index] = $scope.ad.recipientKeyColumns;
	                if (dimensioncolumn.logicalColumnName === null || dimensioncolumn.logicalColumnName === undefined || dimensioncolumn.logicalColumnName === "") {
	                    dimensioncolumn.logicalColumnName = dimensioncolumn.physicalColumnName;
	                }
	                dimensioncolumn.mappedLogicalColumnName = "";
	                dimensioncolumn.selected = false;
	                logicalColumns.push(dimensioncolumn);
	            });
	            if ($scope.ad.selectedDimensionTables !== null && $scope.ad.selectedDimensionTables !== undefined) {
	                $scope.ad.selectedDimensionTables.splice($scope.ad.selectedDimensionTables.length - 1, 1);
	                $scope.ad.selectedDimensionTables.push(recipientTable);
	            }
	            recipientTable.logicalColumns = logicalColumns;
	            $scope.ad.resetDimensionList[recipientTable.physicalTableId] = angular.copy(recipientTable);
	            defer.resolve();
	        
	            return defer.promise;
        	}
        };
    
        $scope.dispalychange=function(lgname,index){
	    	angular.forEach($scope.ad.selectedDimensionTables, function(obj1,dindex) {
	        	if(dindex != index && obj1.logicalTableName == lgname){
	        	showErrorMessage("Logical table name already given.");
	        	$scope.ad.selectedDimensionTables[index].logicalTableName = undefined;
	        	}
	        });
        }
        
        
        $scope.ad.saveAudienceDimension = function() {
            var isValidDimension = true;
            var isTableDisplayNameEmpty = false;
            $scope.ad.audienceDetailsBO.audienceId = $scope.ad.audienceId;
            $scope.ad.audienceDetailsBO.departmentId = zhapp.loginUser.departmentID;
            $scope.ad.audienceDetailsBO.audienceStatus = "A";
            $scope.ad.audienceDetailsBO.isDefault = 0;
            $scope.ad.audienceDetailsBO.logicalTables = [];
            var newLogicalColumns = [];
            angular.forEach($scope.ad.selectedRecipientTable.logicalColumns,function(logicalColumn){
            	if(logicalColumn.selected){
				newLogicalColumns.push(logicalColumn);
            }
            });
            
            $scope.ad.selectedRecipientTable.logicalColumns = newLogicalColumns;
            $scope.ad.audienceDetailsBO.logicalTables.push($scope.ad.selectedRecipientTable);
            angular.forEach($scope.ad.selectedDimensionTables, function(selectedDimensionTable) {
                if (selectedDimensionTable !== null && selectedDimensionTable !== undefined && selectedDimensionTable !== "") {
                    var isDimensionAttrSelected = false;
                    var isMappedRicipientEmpty = false;
                    var logicalTables = {};
                    var logicalColumns = [];
                    logicalTables.physicalTableId = selectedDimensionTable.physicalTableId;
                    logicalTables.physicalTableName = selectedDimensionTable.physicalTableName;
                    if (selectedDimensionTable.logicalTableName !== "" && selectedDimensionTable.logicalTableName !== null) {
                        logicalTables.logicalTableName = selectedDimensionTable.logicalTableName;
                        isTableDisplayNameEmpty = false;
                    } else {
                        isTableDisplayNameEmpty = true;
                    }
                    logicalTables.tableType = 1;
                    logicalTables.dimensionColumnMapping = [];
                    var dimentionMappingColumns = [];
                    angular.forEach(selectedDimensionTable.logicalColumns, function(dimensioncolumn) {
                    	if(dimensioncolumn.selected){
                    		var mappingColumns = {};
                            if (dimensioncolumn.logicalColumnName === undefined || dimensioncolumn.logicalColumnName === "" || dimensioncolumn.logicalColumnName === null) {
                                isValidDimension = false;
                                showErrorMessage("Column display name can not be empty for the table: " + logicalTables.physicalTableName);
                                return;
                            } 
                            dimensioncolumn.selected = true;
                            if (dimensioncolumn.dimensionAttribute) {
                                isDimensionAttrSelected = true;
                                if (dimensioncolumn.mappedLogicalColumnName !== undefined && dimensioncolumn.mappedLogicalColumnName !== "") {
                                    isMappedRicipientEmpty = true;
                                }
                            } 
                            if (dimensioncolumn.profileable) {
                            	dimensioncolumn.profileable = true;
                            	dimensioncolumn.isProfilable = "Y";
                            } else {
                            	dimensioncolumn.profileable = false;
                                dimensioncolumn.isProfilable = "N";
                            }
                            //Dimention Mapping
                            if(dimensioncolumn.mappedLogicalColumnName !== undefined && dimensioncolumn.mappedLogicalColumnName !== ""){
                            	mappingColumns.baseLogicalColumnName = dimensioncolumn.mappedLogicalColumnName;
                                mappingColumns.dimensionColumnName = dimensioncolumn.logicalColumnName;
                                dimentionMappingColumns.push(mappingColumns);
                            }
                            logicalColumns.push(dimensioncolumn);
                    	}
                    });
                    if (isTableDisplayNameEmpty) {
                        isValidDimension = false;
                        showErrorMessage("Display name can not be empty for the table: " + logicalTables.physicalTableName);
                        return;
                    }
                    if(dimentionMappingColumns.length > 0){
                    	logicalTables.dimensionColumnMappings = dimentionMappingColumns;
                    }
                    if (logicalColumns.length > 0 && isDimensionAttrSelected) {
                        logicalTables.logicalColumns = logicalColumns;
                        $scope.ad.audienceDetailsBO.logicalTables.push(logicalTables);
                    } else {
                        isValidDimension = false;
                        showErrorMessage("Please select atleast one dimension column as dimension attribute for the table: " + logicalTables.physicalTableName);
                        return;
                    }
                    if (!isMappedRicipientEmpty) {
                        isValidDimension = false;
                        showErrorMessage("Please select the recipient columns to map for the table: " + logicalTables.physicalTableName);
                        return;
                    }
                } else {
                    isValidDimension = false;
                    showErrorMessage("Please select dimension table before saving");
                    return;
                }
            });
            if (isValidDimension) {
                var defer = $q.defer();
                $scope.ad.isSaveAudience = true;
                $scope.deptAccess = true;
                audiencesService.updateAudience($scope.ad.audienceDetailsBO).error(function(result){
                	 showErrorMessage(getErrorMessage(result)); 
                }).success(function(result) {
                    $scope.ad.audienceDetailsBO = {};
                    $scope.ad.audienceDetailsBO = result;
                    sessionStorage.AudienceIdToEdit = $scope.ad.audienceId;
                    $scope.compareVO = $scope.ad.audienceDetailsBO;
                   // navigateToPage('editaudiences.htm');
                    $scope.loadAudienceSummary();
                    defer.resolve();
                   
                });
                return defer.promise;
            }
        };
        
        
        $scope.addNewDimensionTable = function() {
            var promises = [];
            $scope.ad.usedPhysicalTables = [];
            var isPreviousDimensionEmpty = false;
            angular.forEach($scope.ad.selectedDimensionTables, function(dimensionTable) {
                if (dimensionTable === null || dimensionTable === undefined || dimensionTable === "") {
                    isPreviousDimensionEmpty = true;
                }
                dimensionTable.isUsed = true;
                $scope.ad.usedPhysicalTables.push(dimensionTable);
            });
            if (!isPreviousDimensionEmpty) {
                if ($scope.ad.isDimensionSelected.length > 1) {
                    $scope.ad.isDimensionSelected[$scope.ad.isDimensionSelected.length - 1] = true;
                } else {
                    $scope.ad.isDimensionSelected[0] = true;
                }
             
                console.dir($scope.ad.usedPhysicalTables);
                if ($scope.ad.usedPhysicalTables !== null && $scope.ad.usedPhysicalTables !== undefined && $scope.ad.usedPhysicalTables !== "") {
                    angular.forEach($scope.ad.usedPhysicalTables, function(usedTables) {
                        if (usedTables !== null && usedTables !== undefined && usedTables !== "") {
                            $scope.ad.physicalTables = $scope.ad.physicalTables.filter(function(el) {
                                if(el.physicalTableId == usedTables.physicalTableId)
                                	el.isUsed = true;
                                return el;
                            });
                        }
                    });
                }
                
                $q.all(promises).then(function() {
                    $scope.ad.selectedDimensionTables.push(null);
                    $scope.ad.isDimensionSelected.push(false);
                });
            } else {
                showErrorMessage("Please fill this dimension table to add dimension");
                return;
            }
        };
        
        $scope.showDimensionTables = function(){
        	angular.forEach($scope.ad.usedPhysicalTables, function(usedTables) {
                if (usedTables !== null && usedTables !== undefined && usedTables !== "") {
                    $scope.ad.physicalTables = $scope.ad.physicalTables.filter(function(el) {
                        return el.physicalTableId !== usedTables.physicalTableId;
                    });
                }
            });
        }
        

        $scope.ad.closeDeleteDimension = function() {
            $scope.deleteDimensionindex = "";
            $scope.deleteDimensionTable = "";
            $(".delete-dialog").dialog("close");
        }

       
       
        /*$scope.ad.editAudienceTables = function() {
            if ($scope.ad.audienceId > 0) {
                $scope.showNextStep = false;
                $scope.ad.isConfigure = true;
                $scope.ad.audienceRightPane="audience/templates/createAudience.html"; 
                $scope.ad.isRecipientSelected = true;
                if ($scope.ad.selectedRecipientTable !== undefined && $scope.ad.selectedRecipientTable !== "" && !$.isEmptyObject($scope.ad.selectedRecipientTable)) {
                    var promises = [];
                    promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                    $q.all(promises).then(function() {});
                } else {
                    showErrorMessage("Recipient Table is not configured initially");
                    return;
                }
                $('.lwizard-steps li:nth-child(1)').addClass("active");
                $('.lwizard-steps li:nth-child(2)').removeClass("active");
            }
//            $scope.ad.configure = !$scope.ad.configure;
            if($scope.ad.configure){
            	$scope.ad.summery = false;
            }
        };*/
        
        $scope.ad.editAudienceTables = function() {
        	 if ($scope.ad.audienceId > 0) {
        	var newObject="";
            var deferLogicalColumns = $q.defer();
            httpInProgress = true;
            $scope.ad.isSaveAudience = false;
    		audiencesService.fetchingAndCheckingLogicalColumnsUsage($scope.ad.audienceId.toString()).success(function(result) {
    			var audienceresult = result;
    			if(audienceresult["usedAudienceinFileDef"]!=true && audienceresult["usedAudienceinConv"]!=true && audienceresult["usedAudienceinContent"]!=true && audienceresult["usedAudienceinWebpage"]!=true){
                    $scope.showNextStep = false;
                    $scope.ad.isConfigure = true;
                    $scope.ad.audienceRightPane="audience/templates/createAudience.html"; 
                    $scope.ad.isRecipientSelected = true;
                    if ($scope.ad.selectedRecipientTable !== undefined && $scope.ad.selectedRecipientTable !== "" && !$.isEmptyObject($scope.ad.selectedRecipientTable)) {
                        var promises = [];
                        promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                        $q.all(promises).then(function() {});
                    } else {
                        showErrorMessage("Recipient Table is not configured initially");
                        return;
                    }
                    $('.lwizard-steps li:nth-child(1)').addClass("active");
                    $('.lwizard-steps li:nth-child(2)').removeClass("active");
                    if($scope.ad.configure){
                    	$scope.ad.summery = false;
                    }
    			}else{
    				if(audienceresult["usedAudienceinConv"]==true){
    					newObject=newObject+"Conversation(s)"
    				}
    				if(audienceresult["usedAudienceinFileDef"]==true){
    					newObject=newObject+","+"File/List Import"
    				}
    				if(audienceresult["usedAudienceinContent"]==true){
    					newObject=newObject+","+"Content"
    				}
    				if(audienceresult["usedAudienceinWebpage"]==true){
    					newObject=newObject+","+"WebPages"
    				}
    					newObject.indexOf( ',' ) == 0 ? newObject = newObject.replace( ',', '' ) : newObject;
    					var msg = "Audience edit can impact the associated "+newObject.toString()+" "+"workflow.<br>Are you sure to continue?";
                        showCommonConfirmMessage(msg, "Alert", "Yes", "No", 450, function(isOk){
                			if(!isOk)
                				return;
                			 $scope.showNextStep = false;
                             $scope.ad.isConfigure = true;
                             $scope.ad.audienceRightPane="audience/templates/createAudience.html"; 
                             $scope.ad.isRecipientSelected = true;
                             if ($scope.ad.selectedRecipientTable !== undefined && $scope.ad.selectedRecipientTable !== "" && !$.isEmptyObject($scope.ad.selectedRecipientTable)) {
                                 var promises = [];
                                 promises.push($scope.getAudienceDetails($scope.ad.audienceId));
                                 $q.all(promises).then(function() {});
                             } else {
                                 showErrorMessage("Recipient Table is not configured initially");
                                 return;
                             }
                             $('.lwizard-steps li:nth-child(1)').addClass("active");
                             $('.lwizard-steps li:nth-child(2)').removeClass("active");
                             if($scope.ad.configure){
                             	$scope.ad.summery = false;
                             }
            			 });
    			}
    			deferLogicalColumns.resolve();
    		}).error(function(result) {
    			showConfigurationErrorMessage(result);
            });
    		return deferLogicalColumns.promise;
        	 }
        };
        
        $scope.ad.getColumnTypeValue = function(columnType){
        	var columnValue;
        	angular.forEach($scope.ad.columnTypesList, function(cType) {
                if (cType.columnDataType == columnType) {
                     columnValue = cType.columnValue;
                }
            });
        	return columnValue
        };
        
        $scope.ad.resetDimensionTables = function(index,selectedDimensionTable) {
            if (selectedDimensionTable !=null && selectedDimensionTable !== undefined) {
            	selectedDimensionTable.logcalTableName = $scope.ad.resetDimensionList[selectedDimensionTable.physicalTableId].logicalTableName;
            	selectedDimensionTable.logicalColumns = angular.copy($scope.ad.resetDimensionList[selectedDimensionTable.physicalTableId].logicalColumns);
        		//$scope.ad.dimensionPhysicalColumns[selectedDimensionTable.physicalTableName+selectedDimensionTable.physicalTableId] = angular.copy($scope.ad.resetDimensionList[selectedDimensionTable.physicalTableId].logicalColumns);
            }
        }

        $scope.returnToAdminAudience=function(audienceType){
        	//Cancel the Timer.
            if (angular.isDefined($scope.Timer)) {
                $interval.cancel($scope.Timer);
            }
        	
            var audiencetype;
        	if(isModified()){ 
        		showCommonConfirmMessage("You have changed the Audience. Do you want to save ?","Confirm", "YES", "NO", 450,function(flag){
        			if(flag){      				
        				$scope.ad.saveAudience();
        			
        				if(audienceType==0)
        	        	{
        	        		$scope.adminModule.loadPartialScripts('customAudience');
        	        	}
        	        	else
        	        		{
        	        			$scope.adminModule.loadPartialScripts('systemAudience');
        	        		}
        			}else{
        				if(audienceType==0)
        	        	{
        	        		$scope.adminModule.loadPartialScripts('customAudience');
        	        	}
        	        	else
        	        		{
        	        			$scope.adminModule.loadPartialScripts('systemAudience');
        	        		}
        				
        			}
    			});
        	}
        	else
        		{
        		if(audienceType==0)
	        	{
	        		$scope.adminModule.loadPartialScripts('customAudience');
	        	}
	        	else
	        		{
	        			$scope.adminModule.loadPartialScripts('systemAudience');
	        		}
			}
        };
        function isModified(){
           var isModified = false;
           	var finalRecipient = angular.copy($scope.ad.selectedRecipientTable);
        	if(!angular.equals($scope.ad.initialRecipientTable,finalRecipient)){
        		isModified = true;
        	}else{
        		var selectedDimensionlist=angular.copy($scope.ad.selectedDimensionTables);
    			angular.forEach(selectedDimensionlist,function(dimension)
    			{
    				if(dimension!=null)
    				{
    				if(!angular.equals(dimension,$scope.ad.resetDimensionList[dimension.physicalTableId]))
    					isModified = true;
    				}
    					else
    				{
    						isModified = false;
    				}
    			});
    			
        	}
        	return isModified;
        };
        
        $scope.validateDeptAccess = function(audID){
        	  var d = $q.defer();
        	  showCommonConfirmMessage("Would you like to  make this audience visible in all departments ? <br> Note: You may change the audience visibility in the future by editing your department settings.","Alert","Yes","No",450,function(isOk){
    			if(!isOk)return;
    			audiencesService.accessAudienceToAllDepartments(audID).success(function(result){
    				d.resolve();
    			}).error(function(result) {
                	showConfigurationErrorMessage(result);
                	d.reject();
                });
			 });
          return d.promise;
        }
    }
        
]);


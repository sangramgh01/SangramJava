zhapp.controller('audienceshomecontroller', ['$rootScope', '$scope', '$q', '$filter', 'audiencesService','adminListingService',
    function($rootScope, $scope, $q, $filter,audiencesService,adminListingService) {

        $scope.ad = {};
        $scope.ad.Properties = {};
        $scope.ad.Properties.audienceName = "";
        $scope.ad.Properties.audienceType;
        $scope.ad.Properties.audienceId;
        $scope.ad.audienceSearchCriteria = {};
        sessionStorage.audienceName="";
        $scope.ad.currentPageNumber=1;
        $scope.ad.searchText = "";
        $scope.ad.searchType = "ALL";
        $scope.ad.headerdisplay = true;
        $scope.ad.infoMessage = "There are no audiences";
        $scope.ad.audienceDetailsList = [];
        sessionStorage.AudienceIdToEdit = 0;
        $scope.ad.audienceSearchCriteria.sortUsing='audiencename';
                $scope.ad.audienceSearchCriteria.sortBy='ascending';
        $('.anc-box').hide();
        $scope.ad.audiencesSortorderArray = [{
            key: "ASC",
            value: "Ascending"
        }, {
            key: "DESC",
            value: "Descending"
        }];
        
       $scope.$on('listingCriteriaChanged', function () {
            if(adminListingService.sortby==='name')
                $scope.ad.audienceSearchCriteria.sortUsing="audiencename";
            else if(adminListingService.sortby==='createdon')
                $scope.ad.audienceSearchCriteria.sortUsing='createdate';
            else if(adminListingService.sortby==='createdby')
                $scope.ad.audienceSearchCriteria.sortUsing='createdby';
            $scope.ad.audienceSearchCriteria.sortBy=adminListingService.sortorder;
            listAudiences();
        });

        
        	$scope.ad.prepareSearchCriteria = function(audienceType) {
            $scope.ad.audienceSearchCriteria.pageSize = 7;
        	$scope.ad.audienceSearchCriteria.nameEquals= "";
        	$scope.ad.audienceSearchCriteria.nameLike= "";
        	$scope.ad.audienceSearchCriteria.audienceType = audienceType;
        	$scope.ad.audienceSearchCriteria.pageNumber = 1;
        	$scope.ad.audienceSearchCriteria.sortUsing= "";
        	$scope.ad.audienceSearchCriteria.sortBy = "ASC";
        	$scope.ad.audienceSearchCriteria.departmentId = zhapp.loginUser.departmentID;
        	
        	$scope.ad.audienceSearchCriteria.columnNames=["audiencename","departmentid","audiencetype"];
        	
        	$scope.ad.audienceSearchCriteria.sortUsing = "audiencename";
        };

        $scope.ad.orderByAction = function(sortOrder) {
            $scope.ad.audienceSearchCriteria.sortOrder = sortOrder;
            $scope.ad.audienceSearchCriteria.pageNumber = 1;
            listAudiences();
        };

        $scope.ad.audiencesSortbyArray = [{
                key: "Name",
                value: "name"
            }, {
                key: "Created On",
                value: "createddate"
            }
        ];

        $scope.ad.sortByAction = function(sortby) {
            $scope.ad.audienceSearchCriteria.sortBy = sortby;
            if (sortby == 'createddate') {
                $scope.ad.audienceSearchCriteria.sortOrder = 'DESC';
            } else {
                $scope.ad.audienceSearchCriteria.sortOrder = "ASC";
            }
            $scope.ad.audienceSearchCriteria.pageNumber = 1;
            listAudiences();
        };

        $scope.audienceshomedateCreated = [{
            key: "Select All",
            value: "Select All"
        }, {
            key: "today",
            value: "Today"
        }, {
            key: "yesterday",
            value: "Yesterday"
        }, {
            key: "thisweek",
            value: "This Week"
        }, {
            key: "lastweek",
            value: "Last Week"
        }, {
            key: "thismonth",
            value: "This Month"
        }];

        $scope.updateAudiencesHomeSelDates = function(dateObj, value) {
            if (dateObj.value == "Select All") {
                angular.forEach($scope.audienceshomedateCreated, function(object) {
                    object.checked = dateObj.checked;
                    $scope.ad.audienceSearchCriteria.dateSelection = null;
                });
            } else {
                //unselect all first.
                $scope.audienceshomedateCreated[0].checked = false;
                var selectedStatus = $.grep($scope.audienceshomedateCreated, function(object) {
                    return object.checked;
                });
                if (selectedStatus.length == ($scope.audienceshomedateCreated.length - 1)) {
                    $scope.audienceshomedateCreated[0].checked = true;
                    $scope.ad.audienceSearchCriteria.dateSelection = null;
                } else {
                    $scope.audienceshomedateCreated[0].checked = false;
                    var listHomedateSelStr = ($filter('uniqueFilter')($scope.audienceshomedateCreated, "key")).toString();
                    $scope.ad.audienceSearchCriteria.dateSelection = listHomedateSelStr;
                }
            }
            $scope.ad.loadPageDetails(1);
        };

        $scope.ad.loadPageDetails = function(pageNumber) {
        	 $scope.ad.audienceSearchCriteria.pageNumber = pageNumber;
        	 $scope.ad.currentPageNumber=pageNumber;
            listAudiences();
        };

        $scope.ad.audiencesTypeArray = [{
            key: "Select All",
            value: "ALL"
        }, {
            key: "System",
            value: "System"
        }, {
            key: "Custom",
            value: "Custom"
        }];

        $scope.ad.getAudienceType = function(type) {
            var audiencetype;
            if (type == 0)
                audiencetype = "Custom";
            else
                audiencetype = "System";
            return audiencetype;
        };

        $scope.ad.searchByType = function() {
            if ($scope.ad.searchType) {
                $scope.ad.audienceSearchCriteria.audienceType = null;
                if ($scope.ad.searchType == 'ALL') {
                    $scope.ad.audienceSearchCriteria.audienceType =null;
                }else {
                    $scope.ad.audienceSearchCriteria.audienceType = $scope.ad.searchType;
                }
            }
            $scope.ad.loadPageDetails(1);
        };
        $scope.$on('systemAudience', function(e) {
        	$scope.ad.audienceDetailsList = [];
        	$scope.ad.searchText = "";
        	$scope.ad.prepareSearchCriteria("System");
        	$scope.ad.audienceSearchCriteria.sortUsing = "audiencename";
        	listAudiences();
       });
        $scope.$on('customAudience', function(e) {
        	$scope.ad.audienceDetailsList = [];
        	$scope.ad.searchText = "";
        	$scope.ad.prepareSearchCriteria("Custom");
        	$scope.ad.audienceSearchCriteria.sortUsing = "audiencename";
        	listAudiences();
       });
        
        audienceTotalCount=function(){
            var deferred = $q.defer();
            audiencesService.audienceTotalCount($scope.ad.audienceSearchCriteria).success(function(result){
                 $scope.ad.totalRecords=result;
                deferred.resolve();
            }).error(function(){
                deferred.reject('Failed to get audience count.');
            });
            return deferred.promise;
        };
        function listAudiences() {
            /*var criteria = {};
            criteria = $scope.ad.audienceSearchCriteria;*/
            audiencesService.listAudiences(angular.toJson($scope.ad.audienceSearchCriteria)).success(function(result) {
                $scope.ad.audienceDetailsList = result;
                if($scope.ad.audienceDetailsList.length <= 0){
                    showErrorMessage("No Audience found.");
//                     return;    
                }
                $scope.ad.morecheckedId = -1;
                if ($scope.ad.audienceDetailsList.length > 0)
                   /* $scope.ad.totalRecords = 1;*/
                 audienceTotalCount();
                else
                    $scope.ad.totalRecords = 0;
                
                setRgtHeaderWidth();
                $(window).resize(function(){setRgtHeaderWidth();});
            });
        };
       

        function getContext() {
            var defer = $q.defer();
            commonService.getContext().success(function(result) {
                $scope.zetacontext = result.zetacontext;
                $scope.userRegionTimezone = result.userRegionTimezone;
                $rootScope.DEPT_NAME = $scope.zetacontext.activeDeptName;
                $rootScope.DEPTID = $scope.zetacontext.activeDepartment;
                $scope.ad.activeDept = $scope.zetacontext.activeDeptName;
                defer.resolve();
            });
            return defer.promise;
        };

        //initialzeController();

        function initialzeController() {
            //onLoadSetTimer();
        	
            sessionStorage.removeItem('AudienceIdToEdit');
            $q.when(true).then(function() {
                var promises = [];
                
               /* $q.when(listAudiences()).then(function() {
                setRgtHeaderWidth();
                $(window).resize(function(){setRgtHeaderWidth();});
                });*/
                
            });
        }

        function setRgtHeaderWidth() {
        	$scope.ad.headerdisplay = false;
            if (screen.width >= 1900)
                $(".l-rightpanel").css("width", "1535px");
            if (navigator.appName == 'Microsoft Internet Explorer')
                $("#headerAudiences").width($("#admin_audience_lst_basetable_tables_chzn").width() - 9);
            else
                $("#headerAudiences").width($("#admin_audience_lst_basetable_tables_chzn").width());
        };

        $scope.ad.searchByName = function(event) {
            if ((event.type == "click" || event.keyCode == 13) && $scope.ad.searchText.length == 0) {
                showErrorMessage("Enter the string to be searched.");
                return;
            }
            if (event.type == "click" || event.keyCode == 13 ||
                ((event.keyCode == 8 || event.keyCode == 46) &&
                    $scope.ad.searchText.length == 0)) {
                if ($scope.ad.searchText != $scope.ad.audienceSearchCriteria.nameLike) {
                    $scope.ad.audienceSearchCriteria.nameLike = $scope.ad.searchText;
                    $scope.ad.loadPageDetails(1);
                }
            }
        };

        $scope.addAudiences = function() {
       	 	
            if (!$scope.ad.Properties.audienceName || $scope.ad.Properties.audienceName.length == 0) {
                showErrorMessage("Audience Name can not be empty.");
                return;
            }
            $scope.ad.Properties.audienceId = 0;
            audiencesService.isAudiencesNameExists($scope.ad.Properties.audienceName, $scope.ad.Properties.audienceId).success(function(result) {
            	 $scope.ad.valid = true;
                 $scope.ad.Properties.audienceType = 0;
                 $scope.ad.Properties.audienceId = 0;
                 sessionStorage.audienceName = $scope.ad.Properties.audienceName;
                 sessionStorage.audienceType = 0;
            	if (result===false) {
            		hideDisableBack();
            		$scope.adminModule.loadPartialScripts('editaudiencearea');
            		/*window.location.href='audience/templates/addOrEditAudience.html';*/
                } else {
                    showErrorMessage("An audience with the name " + $scope.ad.Properties.audienceName + " already exists. please modify the name.");
                    return;
                }
            });
        }

        $scope.editAudience = function(id) {
            sessionStorage.AudienceIdToEdit = id;
            $scope.adminModule.loadPartialScripts('editaudiencearea');
           // window.location.href='audience/templates/addOrEditAudience.html';
        };

        $scope.ad.clearSearch = function() {
            if ($scope.ad.searchText && $scope.ad.searchText.length > 0) {
                $scope.ad.searchText = "";
                $scope.ad.audienceSearchCriteria.nameLike = undefined;
                $scope.ad.loadPageDetails(1);
            }
        };

        $scope.ad.selectAllAudiences = function() {
            angular.forEach($scope.ad.audienceDetailsList, function(listdetail) {
                listdetail.checked = true;
            });

        };

        $scope.ad.clearAudienceSelection = function() {
            angular.forEach($scope.ad.audienceDetailsList, function(listDetails) {
                listDetails.checked = false;
            });
        };

        function getSelectedAudienceIds() {
            var selectedAudienceIds = [];
            angular.forEach($scope.ad.audienceDetailsList, function(listDetails) {
            	if(listDetails.checked == true) {
     	           selectedAudienceIds.push(listDetails.audienceId);
                }
            });
            return selectedAudienceIds;
        };

        $scope.ad.deleteList = function(flag) {
        	var usedAudiences=[];
        	var newObject="";
        	if (flag) {
        		var selectedIds = getSelectedAudienceIds();
        		//console.dir(selectedIds);
        		if(selectedIds.length >1){
        			showErrorMessage("Cannot delete multiple audience." ); 
        			return
        		}
        		else{
        		var deferLogicalColumns = $q.defer();
        		audiencesService.fetchingAndCheckingLogicalColumnsUsage(selectedIds.toString()).success(function(result) {
        			var audienceresult = result;
        			if(audienceresult["usedAudienceinFileDef"]!=true && audienceresult["usedAudienceinConv"]!=true && audienceresult["usedAudienceinContent"]!=true && audienceresult["usedAudienceinWebpage"]!=true){
        			/*if(audience!=null && audience!=undefined && audience==0){*/
        				audiencesService.deleteMultipleAudiences(selectedIds.toString()).success(function(result) {
                           // showInfoMessage("Audiences deleted successfully"); //ZHPE-12829 bug changes
                            $('#common-confirmBtn').addClass('cancel-btn');
                            showCommonConfirmMessage("Audiences deleted successfully", "Info", "Ok",'', 450,$scope.defaultAudinceList);                          
                         }).error(function(result) {
                        	 showConfigurationErrorMessage(result);
                         });
        				
        			}else{
        				
        				if(audienceresult["usedAudienceinConv"]==true){
        					newObject=newObject+"Conversation(s)"
        				}
        				if(audienceresult["usedAudienceinFileDef"]==true){
        					newObject=newObject+","+"File/List Import"
        				}
        				if(audienceresult["usedAudienceinContent"]==true){
        					newObject=newObject+","+"Content"
        				}
        				if(audienceresult["usedAudienceinWebpage"]==true){
        					newObject=newObject+","+"WebPages"
        				}
        				/*usedAudiences.push(audience);
            			var audienceNames ="";
    			          angular.forEach($scope.ad.audienceDetailsList, function(audience) {
    	                        if ($.inArray(audience.audienceId, usedAudiences) > -1) {
    	                            if(audienceNames.length>0){
    	                            	audienceNames=audienceNames+",";
    	                            }
    	                            audienceNames=audienceNames+audience.name;
    	                        }
    	                    });*/
        					newObject.indexOf( ',' ) == 0 ? newObject = newObject.replace( ',', '' ) : newObject;
    	            		showErrorMessage("Audience cannot be deleted, as this is is associated with."+newObject+"" );   		               		
    	            		
        			}
        				
        			deferLogicalColumns.resolve();
        		}).error(function(result) {
        			showConfigurationErrorMessage(result);
                });
        		return deferLogicalColumns.promise;
            	/*angular.forEach(selectedIds, function(audienceId) {
            		 var deferLogicalColumns = $q.defer();
            		audiencesService.fetchingAllLogicalColumnsOfAudiences(audienceId).success(function(result) {
            			var logicalcolumns = result.logicalColumns;
            			if(logicalcolumns!=null && logicalcolumns.length>0){
            				var logicalColumnIdList = _.pluck(logicalcolumns, 'logicalcolumnid');
            				audiencesService.checkingDimentionTableUsage(logicalColumnIdList).success(function(result) {
            					var audienceIds=[];
            					audienceIds.push(audienceId);
                				audiencesService.deleteMultipleAudiences(audienceIds.toString()).success(function(result) {
                                   showInfoMessage("Audiences deleted successfully");
                                   
                                }).error(function(result) {

                                });
                			}).error(function(result) {
                				if(result.error){
                					usedAudiences.push(audienceId);
                				}
                                //showErrorMessage(result.error);
                            });
            			}
            			deferLogicalColumns.resolve();
            			
                    
                    }).error(function(result) {

                    });
            		return deferLogicalColumns.promise;
                });*/
            	/*var audienceNames ="";
            	if(usedAudiences.length>0){
            		angular.forEach($scope.ad.audienceDetailsList, function(audience) {
                        if ($.inArray(audience.audienceId, usedAudiences) > -1) {
                            if(audienceNames.length>0){
                            	audienceNames=audienceNames+",";
                            }
                        }
                    });
            		showErrorMessage("You can not delete"+audienceNames+"they can be used in the system." );
            	}
            	 $scope.ad.loadPageDetails(1);*/
        	}
        	}else {
                return false;
            }
        	
            /*if (flag) {
                var selectedIds = getSelectedAudienceIds();
                audiencesService.deleteMultipleAudiences(selectedIds.toString()).success(function(result) {
                    showInfoMessage("Audience deleted successfully");
                    $scope.ad.loadPageDetails(1);
                }).error(function(result) {

                });
            } else {
                return false;
            }*/
        };

        $scope.defaultAudinceList = function(flag){
        	$('#common-confirmBtn').removeClass('cancel-btn');
        	if(flag)
        		  $scope.ad.loadPageDetails(1);
        }
        
        $scope.ad.deleteAudiencePopUp = function() {
            var isSystemAudience = false;
            if ($scope.ad.audienceDetailsList.length == 0) {
                return false;
            }
            var selectedIds = getSelectedAudienceIds();
            if (selectedIds.length > 0) {
                angular.forEach($scope.ad.audienceDetailsList, function(audience) {
                    if ($.inArray(audience.audienceId, selectedIds) > -1) {
                        if (audience.audienceType != 0)
                            isSystemAudience = true;
                    }
                });
                if (!isSystemAudience) {
                    var msg = "Delete Audience.";
                    showCommonConfirmMessage(msg, "Alert", "Yes", "No", 450, $scope.ad.deleteList);
                } else {
                    showErrorMessage("You can't delete system audience");
                }
            } else {
                showInfoMessage("You must select an item from the audience before deleting it.");
            };
        };

        $scope.ad.clearProperties = function() {
            $scope.ad.Properties = {};
            $('.anc-box').show();
            $('.addsettings').hide();
            if($scope.aud.showDialog)
    			showDisableBack();
    		else
    			hideDisableBack();
            
        };

        $scope.ad.closeAddPopup = function() {
            $('.anc-box').hide();
            hideDisableBack();
        };

        $scope.stopClickPropagation = function($event) {
            $event.stopPropagation();
        };

        $scope.ad.toolTip = function(id, name) {
            return name + ", id : " + id;
        };
        $scope.ad.getAudienceRecipientTableName = function(recipientTableName) {
            var reciptableName = "---";
            if (recipientTableName != null) {
                reciptableName = recipientTableName
            }
            return reciptableName;
        };
        
        /**
         * Method to syncDataSource
         */
        $scope.syncDataSource=function(){
        	 var msg = "This action will populate any new audience tables." +
        	 		"<br\> Are you sure to initiate the DataSource sync service?";
             showCommonConfirmMessage(msg, "Alert", "Yes", "No", 450, syncAudienceDataSource);
        };
       
        var syncAudienceDataSource = function(flag){
        	if(!flag) return false;
        	if(flag){
        		audiencesService.syncDataSource(zhapp.loginUser.departmentID).success(function(result) {
            		showInfoMessage("Sync Datasource request initiated. It usually takes few minutes to complete.");
            	}).error(function(result) {
            		if(result.errors[0] != null) {
             		   showInfoMessage(result.errors[0].message);
             		}else{
             			showInfoMessage("Unknown exception occured. Please check the logs for more details.");
             		}
                 });
        	}
        }
        
        /**
         * METHOD TO syncProfileColumns
         */
        
        $scope.ad.syncProfileColumns = function(audienceid){
        	var appendStr = "";
            if(audienceid == 0) {
                appendStr = " all";   
            }
        	var msg = "This action will populate data to \"Is Profileable\"" + appendStr + " audience columns." +
	 				  "<br\> Are you sure to initiate the Profile column sync service?";
        	showCommonConfirmMessage(msg,"Alert","Yes","No",480,$scope.ad.syncAudienceProfileColumns,audienceid);
        }
        
        $scope.ad.syncAudienceProfileColumns = function(flag, audienceid){
        	if(!flag) return false;
        	if(flag) {
        		audiencesService.syncProfileColumns(audienceid).success(function(result) {
            		if(audienceid == 0) showInfoMessage("Sync Profile columns request initiated. It usually takes few minutes to complete.");
            	}).error(function(result) {
            		if(result.errors[0] != null) {
              		   showInfoMessage(result.errors[0].message);
              		}else{
              			showInfoMessage("Unknown exception occured. Please check the logs for more details.");
              		}
                  });
        	}
        }
       /* $scope.systemAudience =  function(e) {
        	$scope.ad.audienceDetailsList = [];
        	$scope.ad.searchText = "";
        	$scope.ad.prepareSearchCriteria("System");
        	$scope.ad.audienceSearchCriteria.sortUsing = "audiencename";
        	listAudiences();
       };
       $scope.systemAudience();*/

        $scope.stopClickPropagation = function($event) {
            $event.stopPropagation();
        };
        setAudienceRgtHeaderWidth();
        
        function initializeaudience(){
        	if(adminListingService.loadAudiance=="System")
        		$scope.$broadcast('systemAudience');
        	else
        	 $scope.$broadcast('customAudience');
        }
        initializeaudience();
    }
]);

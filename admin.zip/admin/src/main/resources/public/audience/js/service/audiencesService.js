zhapp.factory('audiencesService', ['$http', '$rootScope',
    function($http, $rootScope) {
        return {
            listAudiences: function(audienceCriteriaObj) {
                return $http({
                    method: 'POST',
                    url: 'audience/findAudiencesByCriteria',
                    headers: {
                        'Content-type': 'application/json'
                    },
                    data:audienceCriteriaObj
                });
            },
            audienceTotalCount: function(audienceCriteriaObj) {
                return $http({
                    method: 'POST',
                    url: 'audience/findAudiencesTotalCount',
                    headers: {
                        'Content-type': 'application/json'
                    },
                    data:audienceCriteriaObj
                });
            },
            searchList: function(audienceSearchCriteriaObj) {
                return $http({
                    method: 'GET',
                    url: 'searchList.htm',
                    data: audienceSearchCriteriaObj
                });
            },
            deleteMultipleAudiences: function(ids) {
                return $http({
                    method: 'DELETE',
                    url: '/audience/deleteMultipleAudiences/'+ids
                });
            },
            fetchPhysicaltables: function(audienceId,isRecipientSelected) {
            if(isRecipientSelected)   
            	return $http({
                    method: 'GET',
                    url: '/physicalTables/findPhysicalTablesForDimensionsInAudiences'
                });
            else
            	return $http({
                    method: 'GET',
                    url: '/physicalTables/findPhysicalTablesNotMappedInAudiences'
                });
            },
            fetchPhysicalColumns: function(physicaltableId, audienceId) {
                return $http({
                    method: 'GET',
                    url: 'fetchPhysicalColumns.htm',
                    data: {
                        "physicaltableId": physicaltableId,
                        "audienceId": audienceId
                    }
                });
            },
            isAudiencesNameExists: function(audiencename, audienceId) {
                return $http({
                    method: 'GET',
                    url: '/audience/isAudienceExist/'+audiencename
                });
            },
            isAudienceExistWithNameAndID: function(audiencename, audienceId) {
                return $http({
                    method: 'GET',
                    url: '/audience/isAudienceExistWithNameAndID/'+audiencename+"/"+audienceId
                });
            },
            saveAudienceInSession: function(audienceObject) {
                return $http({
                    method: 'GET',
                    url: 'saveAudienceInSession.htm',
                    data: audienceObject
                });
            },
            getAudienceInSession: function() {
                return $http({
                    method: 'GET',
                    url: 'getAudienceInSession.htm'
         
                });
            },
            saveAudience: function(audienceBO) {
                return $http({
                    method: 'POST',
                    url: '/audience/saveAudience',
                    data:audienceBO
                    
                });
            },
            updateAudience: function(audienceBO) {
                return $http({
                    method: 'POST',
                    url: '/audience/updateAudience',
                    data:audienceBO
                });
            },
            getAudienceSummary: function(audienceId) {
                return $http({
                    method: 'GET',
                    url: '/audience/findAudienceById/'+audienceId
                });
            },
            getRecipientKeyColumns: function(physicaltableId, audienceId) {
                return $http({
                    method: 'GET',
                    url: 'getRecipientKeyColumns.htm',
                    data: {
                        "physicaltableid": physicaltableId,
                        "audienceId": audienceId
                    }
                });
            },
            updateAudienceDetails: function(audienceBO) {
                return $http({
                    method: 'POST',
                    url: '/audience/updateAudience',
                    data:audienceBO
                });
            },
            deleteAudienceDimension: function(audienceId, physicalTableId) {
                return $http({
                    method: 'DELETE',
                    url: '/audience/deleteDimensionTables/'+audienceId+"/"+physicalTableId
                });
            },
            syncDataSource: function(departmentId) {
                return $http({
                    method: 'GET',
                    url: '/systemAudienceDataSync/sync/'+departmentId
                });
            },
            syncProfileColumns: function(audienceId, logicalTableId) {
                return $http({
                    method: 'GET',
                    url: 'syncProfileColumns/'+audienceId
                });
            },
            checkingLogicalColumnUsage: function(logicalcolumnid) {
            	return $http({
                    method: 'GET',
                    url: 'checkingLogicalColumnUsage.htm',
                    data: {
                        "logicalcolumnid": logicalcolumnid
                    }
                });
            },
            checkingDimentionTableUsage: function(audienceId,logicalTableName,logicalColumnNames) {
            	return $http({
                    method: 'GET',
                    url: '/audience/checkingDimentionTableUsage/'+audienceId+"/"+logicalTableName+"/"+logicalColumnNames
                });
            },
            fetchingAndCheckingLogicalColumnsUsage: function(audienceIds) {
            	return $http({
                    method: 'GET',
                    url: '/audience/fetchingAndCheckingLogicalColumnsUsage/'+audienceIds
                });
            },
            getLogicalColumnsByAudienceIdAndPhyTableId: function(physicalTableId, audienceId) {
                return $http({
                    method: 'GET',
                    url: '/audience/getLogicalColumnsByAudienceIdAndPhyTableId/'+audienceId+"/"+physicalTableId
                });
            },
            findPhysicalTableById : function(physicalTableId) {
                return $http({
                    method: 'GET',
                    url: '/physicalTables/findPhysicalTableById/'+physicalTableId
                 
                });
            },
            findAllColumnTypes : function() {
                return $http({
                    method: 'GET',
                    url: '/audienceColumnType/findAllColumnTypes/'
                });
            },
            audienceHealthCheck : function(){
    			return $http({
    				method : 'GET',
    				url    : '/health'
    			});
    		},	
    		accessAudienceToAllDepartments : function(audienceId){
    			return $http({
    				method : 'POST',
    				url    : '/accessAudienceToAllDepartments/'+audienceId
    			});
    		}	
        }
    }
]);

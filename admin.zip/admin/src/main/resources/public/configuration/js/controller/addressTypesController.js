zhapp.controller("addressTypesController",['$scope','$q','addressTypesService','addressTypesValidationService','$timeout','uiGridConstants',function($scope,$q,addressTypesService,addressTypesValidationService,$timeout,uiGridConstants) {
	$scope.addressType={};
	$scope.channels = [];
	$scope.addressType.addressTypeList=[];
	$scope.addressType.editCreateAddressTypeObj={};
	
	$scope.init=function(){		 
		$scope.channels = [ {
			'key' : 'E',
			'value' : 'Email',
			'checked':false	
		}, {
			'key' : 'Z',
			'value' : 'SMS',
			'checked':false	
		}];
	};
	
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    enableVerticalScrollbar: 0,
		    enableHorizontalScrollbar: 0,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    columnDefs: [
		      { field:'name', name: 'AddressType Name',headerCellClass: $scope.highlightFilteredHeader,
		    	  			cellTemplate:'<div><a ng-show=(row.entity.enable==="Y")>&nbsp;<img src="images/green-circle-small.png" title="Active"></a>&nbsp;<a title="{{row.entity.name}}">{{row.entity.name}}</a></div>'},
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort:{direction:'desc', priority:0}},
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      {name: 'Actions',cellClass:'actioncell',
			    	cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a></div>',
			    		width: '60',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
	};
	
	$scope.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	 };
	  
	$scope.toggleFiltering = function(){
		    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	$scope.addressType.listAddressTypes=function(){
		addressTypesService.listAddressTypes().success(function(result){
			$scope.addressType.addressTypeList=result;
			$scope.$evalAsync(function(){
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			console.dir(result);
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.addressType.saveAddressTypeDialog=function(){  
		 if ($('#admin_configurations_div_addaddresstype').css('display') === 'none'){
			$scope.init();
			$scope.addressType.initEditCreateAddressTypeObj();
			$("#admin_configurations_div_addaddresstype").show();
			showDisableBack();
		 }
	};
	
	$scope.addressType.saveAddressType= function(isEdit){
		var list = [];
		angular.forEach($scope.channels,function(obj){
			if(obj.checked===true){
				list.push(obj.key);
			}
		}); 
		$scope.addressType.editCreateAddressTypeObj.channelType = list;
		var isValid = addressTypesValidationService.validateAddressType($scope.addressType.editCreateAddressTypeObj);
		if(!isValid)
			return;
		addressTypesService.createAddressType($scope.addressType.editCreateAddressTypeObj).success(function() {
			if(isEdit){
				showInfoMessage("Address type updated successfully");
				$('.dialog-popup17').dialog('close');
			}
			else{
				showInfoMessage("Address type created successfully");
				$("#admin_configurations_div_addaddresstype").hide();
				hideDisableBack();
			}
			$scope.addressType.listAddressTypes();
			$scope.addressType.initEditCreateAddressTypeObj();
			}).error(function(errormessage){
				showConfigurationErrorMessage(errormessage);
			});
	};
	
	$scope.addressType.closeAddressTypeDialog=function(){
		$("#admin_configurations_div_addaddresstype").hide();
		hideDisableBack();
	};
	
	$scope.openEditDialog=function(addressType){
		$scope.init();
		$scope.addressType.editCreateAddressTypeObj.name=addressType.name;
		$scope.addressType.editCreateAddressTypeObj = angular.copy(addressType);
		angular.forEach($scope.channels,function(node){
			angular.forEach($scope.addressType.editCreateAddressTypeObj.channelType,function(channelType){
				if(node.key===channelType){
					node.checked = true;
				}
			});
		});
		$scope.addressSelection = true;
		angular.forEach($scope.channels,function(node){
			if(!node.checked){
				$scope.addressSelection = false;
			}
		});
		$(".dialog-popup17").dialog('option', 'title',"Edit Address Type");
		$(".dialog-popup17").dialog( "open" );
		
	};
	
	$scope.addressType.initEditCreateAddressTypeObj=function(){
		$scope.addressType.editCreateAddressTypeObj={};
		$scope.addressType.editCreateAddressTypeObj.name='';
		$scope.addressType.editCreateAddressTypeObj.enable='Y';
		$scope.addressType.editCreateAddressTypeObj.channelType='';
		$scope.addressType.editCreateAddressTypeObj.createdBy=zhapp.loginUser.userName;
	};
	
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))	event.preventDefault();
	};
	
	$scope.addressType.isDefault = function(addressType){
		if(addressType.name && (addressType.name.toUpperCase()==='HOME'|| 
		   addressType.name.toUpperCase()==='WORK'|| 
		   addressType.name.toUpperCase()==='MOBILE'||
		   addressType.name.toUpperCase()==='DEFAULT'))
			return true;
		return false;
	}
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("ADDRESSTYPE");
	});
}]);
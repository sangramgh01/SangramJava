zhapp.controller("dbsourceController",['$scope','$q','adminListingService','dbsourceService','dbsourceValidationService','$timeout','uiGridConstants',function($scope,$q,adminListingService,dbsourceService,dbsourceValidationService,$timeout,uiGridConstants) {
	$scope.dbsource={};
	$scope.dbsource.dbsourceList=[];
	$scope.dbsource.editCreatedbsourceObj={};
	
	$scope.gridOptions = {
		    paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    enableVerticalScrollbar: 0,
		    enableHorizontalScrollbar: 0,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    columnDefs: [
		      { field:'dbSourceName', name: 'Source Name',headerCellClass: $scope.highlightFilteredHeader },
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort:{direction:'desc', priority:0}},
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      {name: 'Actions',cellClass:'actioncell',
			    	cellTemplate: '<div><a id="admin_databasesource_lnk_editdbsource" name="admin_databasesource_lnk_editdbsource" href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>'+
			    		'<a id="admin_databasesource_lnk_deletedbsource" name="admin_databasesource_lnk_deletedbsource" href="javascript:void(0)" ng-click="grid.appScope.deleteDBSourceDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',width: '60',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
		  };
	$scope.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };	
	  $scope.toggleFiltering = function(){
		    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
		};
	$scope.dbsource.listDBsources=function(){
		dbsourceService.listDBsources().success(function(result){
			$scope.dbsource.dbsourceList=result;
			$scope.$evalAsync(function(){
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	$scope.dbsource.saveDBsourceDialog=function(){  
		 if ($("#admin_div_adddbsource").css('display') === 'none'){
			$scope.dbsource.initializeDBSourceObj();
			$("#admin_div_adddbsource").show();			
			showDisableBack();
		 }
	};
	$scope.dbsource.saveDBsource=function(isEdit){
		if($scope.dbsource.editCreatedbsourceObj.password == "" || $scope.dbsource.editCreatedbsourceObj.password == undefined){
		$scope.password = btoa($scope.decPassword);
		$scope.dbsource.editCreatedbsourceObj.password = $scope.password;  
		}
		var isValid = dbsourceValidationService.validateDBsource($scope.dbsource.editCreatedbsourceObj);
		if(!isValid)
			return;
		
		//Encrypt the password using Base64
		var enc;
		if(isEdit){
			enc = btoa($scope.decPassword);
		}
		else{
			enc = btoa($scope.dbsource.editCreatedbsourceObj.password);
		}
		$scope.dbsource.editCreatedbsourceObj.password = enc;
		
		//Save or update DB source
		dbsourceService.createDBSource($scope.dbsource.editCreatedbsourceObj).success(function(){
			if(isEdit){
				showInfoMessage("DB source updated successfully");
				$('.dialog-popup17').dialog('close');
			}
			else{
				showInfoMessage("DB source created successfully");
				$("#admin_div_adddbsource").hide();
				hideDisableBack();
			}
			$scope.dbsource.listDBsources();
			$scope.dbsource.initializeDBSourceObj();
		}).error(function(result){
			showConfigurationErrorMessage(result);
			$scope.dbsource.editCreatedbsourceObj.password='';
		});
	};
	
	$scope.dbsource.closeDBsourceDialog=function(){
		$("#admin_div_adddbsource").hide();
		hideDisableBack();
	};
	$scope.openEditDialog=function(dbsource){
		//Decrypt the password
		$scope.decPassword = atob(dbsource.password);
		$scope.dbsource.editCreatedbsourceObj = angular.copy(dbsource);
		$(".dialog-popup17").dialog('option', 'title',"Edit DB Source");
		$(".dialog-popup17").dialog( "open" );
	};
	$scope.deleteDBSourceDialog=function(dbsource){		
		$scope.dbsource.editCreatedbsourceObj =dbsource;
		showCommonConfirmMessage("Delete database source?","Confirm","Yes","No",350,$scope.dbsource.deleteDBsource);
	};
	$scope.dbsource.deleteDBsource=function(flag){
		if(flag){
			var key_name=$scope.dbsource.editCreatedbsourceObj.keyName;
			var last_key_value=key_name.substring(key_name.lastIndexOf('_')+1,key_name.length);
			dbsourceService.deleteDBsource(last_key_value).success(function(result){
				if(result){
					showInfoMessage("DB source deleted successfully");
			$scope.dbsource.listDBsources();
			}else{
				showInfoMessage("Cannot delete the DBsource "+$scope.dbsource.editCreatedbsourceObj.dbSourceName+ ". Dependencies exist for this DBsource");
			}	
		}).error(function(error){
			showConfigurationErrorMessage(error);
		});
		}
	};
	$scope.dbsource.initializeDBSourceObj=function(){
		$scope.dbsource.editCreatedbsourceObj={};
		$scope.dbsource.editCreatedbsourceObj.dbvendor='';	
		//call refactorDBSourceObj()
		$scope.refactorDBSourceObj();		
		$scope.dbsource.editCreatedbsourceObj.createdBy=zhapp.loginUser.userName;
	};
	
	//refactared DBDataSourceObj()
	$scope.refactorDBSourceObj=function(){	
		/**dbSourceName dosen't have to change**/
		//$scope.dbsource.editCreatedbsourceObj.dbSourceName='';
		/**dbSourceName dosen't have to change**/
		$scope.dbsource.editCreatedbsourceObj.hostname='';
		$scope.dbsource.editCreatedbsourceObj.port='';
		$scope.dbsource.editCreatedbsourceObj.username='';
		$scope.dbsource.editCreatedbsourceObj.password='';
		$scope.dbsource.editCreatedbsourceObj.schemaName='';
		$scope.dbsource.editCreatedbsourceObj.dbChracterSet='';	
		$scope.dbsource.editCreatedbsourceObj.service='';
		$scope.decPassword='';
	};
	
	
	$scope.dbsource.onChangeDBSourceObj=function(){
		if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "MySQL") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="MySQL";
		}
		else if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "Oracle") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="Oracle";
		}
		else if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "MsSQL") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="MsSQL";
		}
		else if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "Netezza") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="Netezza";
		}
		else if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "Vertica") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="Vertica";
		}
		else if ($scope.dbsource.editCreatedbsourceObj.dbvendor === "Postgres") {
			$scope.dbsource.editCreatedbsourceObj.dbvendor="Postgres";
		}
		else {
			$scope.dbsource.editCreatedbsourceObj.dbvendor='';
		}
		//call refactorDBSourceObj()
		$scope.refactorDBSourceObj();		
		
		$scope.dbsource.editCreatedbsourceObj.createdBy=zhapp.loginUser.userName;
	};
	
	
	
	$scope.dbsource.initializeDBSourceObj();
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))
			event.preventDefault();
	};
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("DBSOURCE");
	});
}]);
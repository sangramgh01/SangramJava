zhapp.controller("domainController",['$scope','$q','adminListingService','domainService','domainValidationService','$timeout','uiGridConstants',function($scope,$q,adminListingService,domainService,domainValidationService,$timeout,uiGridConstants) {
	$scope.domain={};
	$scope.restrictedDomain={};
	$scope.domain.domainList=[];
	
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
		    columnDefs: [
		      { field:'code', name: 'Domain Code',headerCellClass: $scope.filteredHeader ,width:100},
		      { field:'pattern', name: 'Pattern'},
		      { field:'description', name: 'Description' },
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',cellFilter:'date',sort:{direction:'desc', priority:0} },
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      {field: 'Actions',cellClass:'actioncell',
		    	cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>'+
		    		'<a href="javascript:void(0)" ng-click="grid.appScope.deleteDomainDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',
		    		width: '60',enableSorting: false,enableFiltering: false,
		    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
                        
		    ]
	};
	
	$scope.toggleFiltering = function(){
	    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
	    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	  
	$scope.filteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	$scope.domain.listDomains=function(){
		domainService.listDomains().success(function(result){
			$scope.domain.domainList = result;
			$scope.$evalAsync(function(){
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	setDeptRgtHeaderWidth();
	$scope.domain.saveDomainDialog=function(){  
		 if ($("#adminDomainsAdd").css('display') === 'none'){
			$scope.domain.domainObj={};
			$scope.domain.domainObj.pattern='';
			$scope.domain.domainObj.code='';
			$scope.domain.domainObj.description='';
			$scope.domain.domainObj.status='A';
			showDisableBack();
			$("#adminDomainsAdd").show();			
		 }
	};
	$scope.domain.addDomain=function(isEdit){
		var canSave = domainValidationService.validateDomain($scope.domain.domainObj);
		if(!canSave) 
			return;
		domainService.saveDomain($scope.domain.domainObj).success(function(){
			if(isEdit){
					showInfoMessage("Domain updated successfully");
					$('.dialog-popup17').dialog('close');
					hideDisableBack();
				}
			else {
					showInfoMessage("Domain created successfully");
					$("#adminDomainsAdd").hide();
					hideDisableBack();
				}
				$scope.domain.listDomains();
			}).error(function(error){
				showConfigurationErrorMessage(error);
			});
	};
	$scope.domain.closeAddDomainDialog=function(){
		$("#adminDomainsAdd").hide();
		hideDisableBack();
	};
	$scope.openEditDialog=function(domain){
		$scope.domain.domainObj = angular.copy(domain);
		$(".dialog-popup17").dialog('option', 'title',"Edit Domain");
		$(".dialog-popup17").dialog( "open" );
	};
	$scope.deleteDomainDialog=function(domain){		
		$scope.domain.domainObj=domain;
		showCommonConfirmMessage("Delete domain?","Confirm","Yes","No",350,$scope.domain.deleteDomain);
	};
	$scope.domain.deleteDomain=function(flag){
		if(flag){					
		domainService.deleteDomain($scope.domain.domainObj.code).success(function(result){
			if(result){
                showInfoMessage("Domain deleted successfully");
                $scope.domain.listDomains();    
            }else{
                showInfoMessage("Cannot delete the domain "+$scope.domain.domainObj.code+". Dependencies exist for this domain");
            }
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
		}
	};
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))	event.preventDefault();
	};
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("DOMAIN");
	});
}]);
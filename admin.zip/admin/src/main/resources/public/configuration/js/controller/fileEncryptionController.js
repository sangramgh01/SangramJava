zhapp.controller("fileEncryptionController",['$scope','$q','adminListingService','fileEncryptionService','fileEncryptionValidationService','uiGridConstants','$timeout',function($scope,$q,adminListingService,fileEncryptionService,fileEncryptionValidationService,uiGridConstants,$timeout) {
	$scope.fileEncryption={};
	$scope.fileEncryption.fileEncryptionList=[];
	$scope.fileEncryption.keyObj = {};
	$scope.keySizes = [768,1024,2048];
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
		    columnDefs: [
		      { field:'encryptionKeyName', name: 'Encryption Key Name',headerCellClass: $scope.highlightFilteredHeader },
		      { field:'encryptionType', name: 'Key Type',headerCellClass: $scope.highlightFilteredHeader },
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort: { direction: 'desc', priority: 0 }},
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      { name: 'Actions',cellClass:'actioncell3',
			    	cellTemplate: '<a id="admin_fileencryption_lnk_downloadencryptionkeys" name="admin_fileencryption_lnk_downloadencryptionkeys" href="javascript:void(0)"><img src="images/download.png" title="Download keys" ng-click="grid.appScope.downloadKeys($parent.$parent.row.entity)"></a>'+
			    		'<a id="admin_fileencryption_lnk_editencryption" name="admin_fileencryption_lnk_editencryption" href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.editEncryptionDialog($parent.$parent.row.entity)"></a>'+
			    		'<a id="admin_fileencryption_lnk_deleteencryption" name="admin_fileencryption_lnk_deleteencryption" href="javascript:void(0)" ng-click="grid.appScope.deleteEncryptionDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a>',
			    		width: '60',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
		  };
	$scope.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	  
	$scope.toggleFiltering = function(){
		    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	$scope.fileEncryption.listfileEncryptions=function(){
		fileEncryptionService.listfileEncryptions().success(function(result){
			$scope.fileEncryption.fileEncryptionList=result;
			$scope.$evalAsync(function(){
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	$scope.fileEncryption.saveFileEncryptionDialog=function(){  
		 if ($("#admin_div_addfileencryption").css('display') === 'none'){
			$scope.fileEncryption.keyObj = newKeyObj();
			$scope.fileEncryption.clearTexts();
			$("#admin_div_addfileencryption").show();
			showDisableBack();
		 }
	};
	$scope.fileEncryption.closeFileEncryptionDialog=function(){
		$("#admin_div_addfileencryption").hide();
		hideDisableBack();
	};
	$scope.editEncryptionDialog = function(encryptionKey){
		$scope.fileEncryption.keyObj = angular.copy(encryptionKey);
		$scope.fileEncryption.clearTexts();
		$(".dialog-popup17").dialog('option', 'title',"Edit Encryption Key");
		$(".dialog-popup17").dialog( "open" );
	}
	$scope.deleteEncryptionDialog = function(encryptionKey){
		$scope.fileEncryption.keyObj = encryptionKey ;
		showCommonConfirmMessage("Delete file encryption key?","Confirm","Yes","No",350,$scope.fileEncryption.deleteFileEncryption);
	}
	$scope.fileEncryption.deleteFileEncryption = function(flag){
		if(flag){
			fileEncryptionService.deleteFileEncryption($scope.fileEncryption.keyObj.encryptionKeyName).success(function(result){
				if(result){
					showInfoMessage("File encryption key deleted successfully");
					$scope.fileEncryption.listfileEncryptions();
				}else{
					showInfoMessage("Cannot delete the FileEncryption "+$scope.fileEncryption.keyObj.encryptionKeyName+ ". Dependencies exist for this FileEncryption");
				}
			
			}).error(function(result){
				showConfigurationErrorMessage(result);
			});
		}
	}
	$scope.downloadKeys = function(EncryptionKey){
		var rule = zhapp.loginUser.userInfo.rules.split(",");
		var flag = false;
		angular.forEach(rule, function(obj){
			if(obj.toLowerCase() == 'admin'){
				flag = true;
			}
		});
		if(flag)
		fileEncryptionService.downloadKeys(EncryptionKey.encryptionKeyName);
		else
		showErrorMessage("Unauthorized request. You don't have access to download File Encryption Key ");	
	}
	
	function newKeyObj(){
		var keyObj = {};
		keyObj.encryptionKeyName="";
		keyObj.encryptionType='PGP'; 
		keyObj.passphrase=""; 
		keyObj.publickey=""; 
		keyObj.privatekey=""; 
		keyObj.registrationtype='G'; 
		keyObj.keysize = "768"; 
		return keyObj;
	}
	$scope.fileEncryption.saveEncryptionKey = function(isEdit){
		var isValid = fileEncryptionValidationService.validateFileEncryption($scope.fileEncryption.keyObj);
		if(!isValid)
			return;
		if($scope.fileEncryption.keyObj.registrationtype==='U'){
			var uploadForm = new FormData();
			var privId;
			var pubId;
			if(!isEdit){
				privId = "encPrivateFile";
				pubId =  "encPublicFile";
			}
			else{
				privId = "encEditPrivateFile";
				pubId =  "encEditPublicFile";
			}
			if(!$("#" + privId)[0].files[0]){
				showErrorMessage("Upload private key");
				return false;
			}
			if(!$("#" + pubId)[0].files[0]){
				showErrorMessage("Upload public key");
				return false;
			}
			uploadForm.append("privateKeyfile", $("#"+privId)[0].files[0]);
			uploadForm.append("publicKeyfile", $("#"+pubId)[0].files[0]);
			uploadForm.append("keyName", $scope.fileEncryption.keyObj.keyName);
			uploadForm.append("encryptionKeyName", $scope.fileEncryption.keyObj.encryptionKeyName);
			uploadForm.append("encryptionType", $scope.fileEncryption.keyObj.encryptionType);
			uploadForm.append("passphrase", $scope.fileEncryption.keyObj.passphrase);
			uploadForm.append("registrationtype", $scope.fileEncryption.keyObj.registrationtype);
			uploadForm.append("keysize", $scope.fileEncryption.keyObj.keysize);
			fileEncryptionService.saveFileEncryptionForUpload(uploadForm).success(function(){
				$scope.displayMessages(isEdit);
			}).error(function(result){
				  var messages="";
				  angular.forEach(result.errors,function(data){
						messages=messages+data.message+"<br>"
						
					});
			  	  showErrorMessage(messages);
				  return false;
			  });
		}else{
			if(!isEdit)
				$scope.fileEncryption.keyObj.keyName = $scope.fileEncryption.keyObj.encryptionKeyName;
			fileEncryptionService.saveFileEncryptionForGenereate($scope.fileEncryption.keyObj).success(function(){
				$scope.displayMessages(isEdit);
			}).error(function(result){
					var messages="";
					  angular.forEach(result.errors,function(data){
							messages=messages+data.message+"<br>"
							
						});
				  	  showErrorMessage(messages);
					  return false;
				});
		}
		
	};
	
	$scope.browseClick = function(type) {
		$("#enc" + type + "File").change(function() {
			var file = $(this).val().replace(/C:\\fakepath\\/ig, '');
						
			$("#" + type + "File").val(file);
			$("#enc" + type + "File").unbind('change');
		});
		$("#enc" + type + "File").trigger('click');
	};
	
	$scope.displayMessages = function(isEdit){
		if(isEdit){
			showInfoMessage("File encryption key updated successfully");
			$(".dialog-popup17").dialog( "close" );
			}
		else{
			showInfoMessage("File encryption key created successfully");
			$("#admin_div_addfileencryption").hide();
			hideDisableBack();
		}
		$scope.fileEncryption.listfileEncryptions();
		$scope.fileEncryption.keyObj = newKeyObj();
		};
	
	$scope.fileEncryption.clearTexts = function(){
		$("#encPrivateFile").val(undefined);
		$("#PrivateFile").val('');
		$("#encPublicFile").val(undefined);
		$("#PublicFile").val('');
		$("#encEditPrivateFile").val(undefined);
		$("#EditPrivateFile").val('');
		$("#encEditPublicFile").val(undefined);
		$("#EditPublicFile").val('');
	};
	$scope.fileEncryption.keyObj = newKeyObj();
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("FILEENCRYPTION");
	});
}]);
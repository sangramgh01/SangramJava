zhapp.controller("filesourceController",['$scope','$q','adminListingService','filesourceService','filesourceValidationService','$timeout','uiGridConstants',function($scope,$q,adminListingService,filesourceService,filesourceValidationService,$timeout,uiGridConstants) {
	$scope.filesource={};
	$scope.filesource.filesourceList=[];
	$scope.filesource.editCreatefilesourceObj={};
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    enableVerticalScrollbar: 0,
		    enableHorizontalScrollbar: 0,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    columnDefs: [
		      { field:'fileSourceName', name: 'Source Name',headerCellClass: $scope.highlightFilteredHeader },
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort: { direction: 'desc', priority: 0 } },
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      {name: 'Actions',cellClass:'actioncell',
			    	cellTemplate: '<div><a href="javascript:void(0) id="admin_filesource_lnk_editfilesource" name="admin_filesource_lnk_editfilesource"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>'+
			    		'<a href="javascript:void(0) id="admin_filesource_lnk_deletefilesource" name="admin_filesource_lnk_deletefilesource" ng-click="grid.appScope.deleteDomainDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',
			    		width: '60',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
		  };
	$scope.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	  $scope.toggleFiltering = function(){
		    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
		};
	$scope.filesource.listFilesources=function(){
		filesourceService.listFilesources().success(function(result){
			$scope.filesource.filesourceList=result;
			$scope.$evalAsync(function(){
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	$scope.filesource.saveFilesourceDialog=function(){  
		 if ($("#admin_div_addfilesource").css('display') === 'none'){
			$scope.filesource.initializeFileSourceObj();
			$("#admin_div_addfilesource").show();
			showDisableBack();
		 }
	};
	
	$scope.filesource.saveFilesource=function(isEdit){
		$scope.filesource.editCreatefilesourceObj.password = $scope.decPassword;
		var isValid = filesourceValidationService.validateFilesource($scope.filesource.editCreatefilesourceObj);
		if(!isValid)
			return;
		
		//Encrypt the password using Base64
		var enc;
		if(isEdit){
			enc = btoa($scope.decPassword);
		}
		else{
			enc = btoa($scope.filesource.editCreatefilesourceObj.password);
		}
		$scope.filesource.editCreatefilesourceObj.password = enc;
		
			
		//Save or update file source
		filesourceService.createFileSource($scope.filesource.editCreatefilesourceObj).success(function(){
			if(isEdit){
				showInfoMessage("File source updated successfully");
				$('.dialog-popup17').dialog('close');
			}
			else{
				showInfoMessage("File source created successfully");
				$("#admin_div_addfilesource").hide();
				hideDisableBack();
			}
			//After successful creation or update list the sources
			$scope.filesource.listFilesources();
			$scope.filesource.initializeFileSourceObj();
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.filesource.closeFilesourceDialog=function(){
		$("#admin_div_addfilesource").hide();
		hideDisableBack();
	};
	$scope.openEditDialog=function(filesource){
		//Decrypt the password
		$scope.decPassword = atob(filesource.password);
		
		$scope.filesource.editCreatefilesourceObj = angular.copy(filesource);
		$(".dialog-popup17").dialog('option', 'title',"Edit File Source");
		$(".dialog-popup17").dialog( "open" );
	};
	$scope.deleteDomainDialog=function(filesource){		
		$scope.filesource.editCreatefilesourceObj =filesource;
		showCommonConfirmMessage("Delete file source?","Confirm","Yes","No",350,$scope.filesource.deleteFilesource);
	};
	$scope.filesource.deleteFilesource=function(flag){
		if(flag){	
		var key_name=$scope.filesource.editCreatefilesourceObj.keyName;
		var last_key_value=key_name.substring(key_name.lastIndexOf('_')+1,key_name.length);
		filesourceService.deleteFilesource(last_key_value).success(function(result){
			if(result){
				showInfoMessage("File source deleted successfully");
				$scope.filesource.listFilesources();
				}else{
			showInfoMessage("Cannot delete the Filesource "+$scope.filesource.editCreatefilesourceObj.fileSourceName+ ". Dependencies exist for this Filesource");
				}
		}).error(function(error){
			showConfigurationErrorMessage(error);
		});
		}
	};
	$scope.filesource.initializeFileSourceObj=function(){
		$scope.filesource.editCreatefilesourceObj={};
		$scope.filesource.editCreatefilesourceObj.fileSourceName='';
		$scope.filesource.editCreatefilesourceObj.hostname='';
		$scope.filesource.editCreatefilesourceObj.port='';
		$scope.filesource.editCreatefilesourceObj.protocol='';
		$scope.filesource.editCreatefilesourceObj.username='';
		$scope.filesource.editCreatefilesourceObj.password='';
		$scope.decPassword='';
	};
	$scope.filesource.onChangeProtocol =function(){
		if($scope.filesource.editCreatefilesourceObj.protocol === "http"){
			$scope.filesource.editCreatefilesourceObj.hostname = "http://";
			$scope.filesource.editCreatefilesourceObj.port = "";
		}else if($scope.filesource.editCreatefilesourceObj.protocol === "https"){
			$scope.filesource.editCreatefilesourceObj.hostname = "https://";
			$scope.filesource.editCreatefilesourceObj.port = "";
		}else if($scope.filesource.editCreatefilesourceObj.protocol === "ftp"){
			$scope.filesource.editCreatefilesourceObj.hostname ="";
			$scope.filesource.editCreatefilesourceObj.port =21;
		}else if($scope.filesource.editCreatefilesourceObj.protocol === "sftp"|| 
				$scope.filesource.editCreatefilesourceObj.protocol === "scp"){
			$scope.filesource.editCreatefilesourceObj.hostname ="";
			$scope.filesource.editCreatefilesourceObj.port =22;
		}
		$scope.filesource.editCreatefilesourceObj.username='';
		$scope.filesource.editCreatefilesourceObj.password='';
		$scope.decPassword='';
		
	};
	$scope.filesource.initializeFileSourceObj();
	
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))	event.preventDefault();
	};
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("FILESOURCE");
	});
	$scope.filesource.isEditable = function(){
		  var isEditable = true;
		  if($scope.filesource.editCreatefilesourceObj && ($scope.filesource.editCreatefilesourceObj.protocol === 'https'||
				  $scope.filesource.editCreatefilesourceObj.protocol === 'http')){
			  isEditable = false;
		  }
		  return isEditable;
	  };
}]);
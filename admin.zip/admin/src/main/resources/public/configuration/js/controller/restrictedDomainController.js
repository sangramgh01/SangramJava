zhapp.controller("restrictedDomainController",['$scope','$q','adminListingService','domainService','domainValidationService',function($scope,$q,adminListingService,domainService,domainValidationService) {
	
	$(function () {
		$( ".dialog-popup4").dialog({ autoOpen: false, draggable: false,modal:true, resizable: false, autoReposition: true,closeOnEscape: false,width: 850 });
		$( ".duplicate-domain-popup").dialog({ autoOpen: false, draggable: false,modal:true, resizable: false, autoReposition: true,closeOnEscape: false });
		$(window).resize(function(){ $(".dialog-popup4,.duplicate-domain-popup").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup4,.duplicate-domain-popup" ).dialog( "close" );	return false;});
		$( ".cancel-btn" ).click(function() {$( ".duplicate-domain-popup" ).dialog( "close" );	return false;});
		
	}); 
	$scope.restrictedDomain.duplicateDomains=[];
	$scope.restrictedDomain.getRestrictedDomainWithDepartmentList = function(){
		domainService.getRestrictedDomainWithDepartmentList().success(function(result){
			$scope.restrictedDomain.restrictedDomainsList = result;
			$scope.restrictedDomain.restrictedDomainsList[0].domains = convertToList($scope.restrictedDomain.restrictedDomainsList[0].domains);
			$( ".dialog-popup4" ).dialog( "open" );
			$("#browseExcelTempFile").val('');
			$("#domainexcel").val('');		
			$("#disabletextselect").disableSelection();
			$scope.restrictedDomain.uploadDisabled = true;
		});
	};
	
	
	$scope.restrictedDomain.updateRSDomains = function(){
		if($scope.restrictedDomain.validateRSDomains()){
			$scope.restrictedDomain.restrictedDomainsList[0].domains=convertToMap($scope.restrictedDomain.restrictedDomainsList[0].domains);
			$scope.restrictedDomain.restrictedDomainsList[0].updatedBy=zhapp.loginUser.userName;
			if ($scope.restrictedDomain.restrictedDomainsList[0].createdBy == null)
				$scope.restrictedDomain.restrictedDomainsList[0].createdBy=zhapp.loginUser.userName;
			domainService.updateRestrictedDomains($scope.restrictedDomain.restrictedDomainsList[0]).success(function(){
				showInfoMessage("Restricted Domains Updated Successfully.");
				domainService.getRestrictedDomainWithDepartmentList().success(function(result){
					$scope.restrictedDomain.restrictedDomainsList = result;
					$scope.restrictedDomain.restrictedDomainsList[0].domains = convertToList($scope.restrictedDomain.restrictedDomainsList[0].domains);
				}).error(function(result){
					showErrorMessage(result.error[0].message); //Assign By
				});
			}).error(function(info){
				showErrorMessage(info.error[0].message);//Assign By
			});
		}
		
	};
	 
	$scope.restrictedDomain.validateRSDomains =function(){
		var valid = true;
		var groups = _.groupBy($scope.restrictedDomain.restrictedDomainsList[0].domains,
						function(item) {
							return [ item.domain ]
									.sort();
						});
		 
		angular.forEach(groups, function(group) {
			if (group.length > 1 && valid) {
				showErrorMessage("Restricted domain : "+group[0].domain +" already exists");
				valid = false;
			}
		});
		
		return valid;
	};
	
	$scope.restrictedDomain.confirmdeleteRSDomains = function(){
		if(validateRSDomains()){
			showErrorMessage("Please select at least one item.");
			return;
		}
		$scope.restrictedDomain.updatedDomainList = [];
		
		var str = "Are you sure you want to delete the selected item(s)?";
		showCommonConfirmMessage(str,"Confirm","Yes","No",350,$scope.restrictedDomain.deleteRSDomains);
		
	};
	
	$scope.restrictedDomain.deleteRSDomains = function(flag){
		if(flag){
			var restrictedDomainBO = angular.copy($scope.restrictedDomain.restrictedDomainsList[0]);
			
			var rds = convertToMap(restrictedDomainBO.domains);
			angular.forEach(rds, function(value, key) {
				if(value){
					delete rds[key];
				}
			});
			restrictedDomainBO.domains = rds;
			domainService.updateRestrictedDomains(restrictedDomainBO).success(function(){
				domainService.getRestrictedDomainWithDepartmentList().success(function(result){
					$scope.restrictedDomain.restrictedDomainsList = result;
					$scope.restrictedDomain.restrictedDomainsList[0].domains = convertToList($scope.restrictedDomain.restrictedDomainsList[0].domains);
				});
			});
		}
	};
	
	$scope.restrictedDomain.saveActiveRestrictedDomainforDept = function(){
		if(validateRSDomains()){
			showErrorMessage("Please select at least one item from Restricted Domains.");
			return;
		}
		
		if(validateRSDepartments()){
			showErrorMessage("Please select at least one item from Departments.");
			return;
		}
		if($scope.restrictedDomain.validateRSDomains()){
			var temp = angular.copy($scope.restrictedDomain.restrictedDomainsList[0]);
			temp.domains = convertToMap(temp.domains);
			var tempList = angular.copy($scope.restrictedDomain.restrictedDomainsList);
			tempList[0] = temp;
			
			tempList[0].updatedBy=zhapp.loginUser.userName;
			if (tempList[0].createdBy == null)
				tempList[0].createdBy=zhapp.loginUser.userName;
			
			domainService.saveActiveRestrictedDomainforDept(tempList).success(function(result){
				if(result){
					$scope.restrictedDomain.restrictedDomainsList[0].domains = $scope.restrictedDomain.restrictedDomainsList[0].domains;
					showInfoMessage("Restricted Domains have been successfully Applied for Selected Department(s)");
				}
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
		}
	};
	$scope.restrictedDomain.downloadRSDomains = function(){
		domainService.downloadRSDomains();
	};
	
	$scope.restrictedDomain.viewSampleTemplate = function(){
		domainService.viewSampleTemplate();
	};
	
	$scope.restrictedDomain.browseExcelFile = function(){
		    $("#browseExcelTempFile").change(function () {
		    	var file=$(this).val().replace(/C:\\fakepath\\/ig,'');
		        if(file.length > 0){
		        	$scope.restrictedDomain.uploadDisabled = false;
		        	$scope.$apply();
		        	$("#domainexcel").val(file);   
		        }      
		    });
		    $("#browseExcelTempFile").trigger('click');
	};
	
	$scope.restrictedDomain.uploadExcelFile = function(){
		if($("#domainexcel").val().length>0){
				var fileExtension = ['xls', 'xlsx'];
				
				if($.inArray($("#browseExcelTempFile")[0].files[0].name.split('.').pop().toLowerCase(), fileExtension) === -1){
					$("#browseExcelTempFile").val('');
					$("#domainexcel").val('');
					showErrorMessage("Please select only excel files to upload.");
					$scope.restrictedDomain.uploadDisabled = true;
					return;
				}
				//Assign by
				var desktopForm = new FormData();
				desktopForm.append("file", $("#browseExcelTempFile")[0].files[0]);
				 domainService.saveRestrictedDomains(desktopForm).success(function (result){
					 	if(result == "" || result == undefined || result.length == 0){
					 		showErrorMessage("No Domains Found In The Selected File.Please Select Another One");
					 		$("#domainexcel").val('');
							$("#browseExcelTempFile").val('');
							$scope.restrictedDomain.uploadDisabled = true;
					 		return;
					 	}
						$scope.restrictedDomain.restrictedDomainsList[0] = result[0];
						$scope.restrictedDomain.restrictedDomainsList[0].domains = convertToList($scope.restrictedDomain.restrictedDomainsList[0].domains);
						$scope.restrictedDomain.duplicateDomains = result[1];
						
						showCommonConfirmMessage("File Uploaded Successfully","Info","OK",null,350,function(flag){
							if(flag){	  
								if($scope.restrictedDomain.duplicateDomains.length !== 0){
									$("#resetscroll3").slimScroll({ scrollTo: '0' });
									$( ".duplicate-domain-popup" ).dialog( "open" );
								}
								$("#domainexcel").val('');
								$("#browseExcelTempFile").val('');
								$scope.restrictedDomain.uploadDisabled = true;
							}		
						});					
							
		});
				//Assign by
		}
		else{
			showErrorMessage("Please browse the file.");
		}
	};
	
	 $scope.restrictedDomain.allSelected = false;
	  
	 $scope.restrictedDomain.cbChecked = function(){
	    $scope.restrictedDomain.allSelected = true;
	    angular.forEach($scope.restrictedDomain.restrictedDomainsList[1], function(v, k) {
	      if(!v.restrictedDomainsExists){
	        $scope.restrictedDomain.allSelected = false;
	      }
	    });
	  }
	  
	  $scope.restrictedDomain.toggleAll = function() {
	    var bool = true;
	    if ($scope.restrictedDomain.allSelected) {
	      bool = false;
	    }
	    angular.forEach($scope.restrictedDomain.restrictedDomainsList[1], function(v, k) {
	      v.restrictedDomainsExists = !bool;
	      $scope.restrictedDomain.allSelected = !bool;
	    });
	  }
	function convertToList(map){
		var rds = [];
		angular.forEach(map, function(value, key) {
			var rd ={};
			rd.domain = key;
			rd.value=value;
			rds.push(rd)
		});
		return rds;
	}
	function convertToMap(list){
		var hash = new Object();
		angular.forEach(list,function(rd){
			hash[rd.domain] = rd.value;
		});
		return hash;
	}
	function validateRSDomains(){
		var flag = true;
		angular.forEach($scope.restrictedDomain.restrictedDomainsList[0].domains, function(rd) {
			if(rd.value){
				flag = false;
			}
		});
		return flag;
	};
	
	function validateRSDepartments(){
		var flag = true;
		angular.forEach($scope.restrictedDomain.restrictedDomainsList[1], function(rdepartment) {
			if(rdepartment.restrictedDomainsExists){
				flag = false;
			}
		});
		return flag;
	};
}]);
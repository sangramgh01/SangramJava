zhapp.controller("throttlingController",['$scope','$q','throttlingService','throttlingValidationService','$timeout','uiGridConstants',function($scope,$q,throttlingService,throttlingValidationService,$timeout,uiGridConstants) {
	$scope.meterQueue={};
	$scope.meterQueue.meterQueueList=[];
	
	$scope.meterQueue.meterQueueObj={};
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    enableVerticalScrollbar: 0,
		    enableHorizontalScrollbar: 0,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    columnDefs: [
		      { field:'meterQueueName', name: 'Throttle Name',headerCellClass: $scope.highlightFilteredHeader, cellTemplate:'<div><a ng-show=(row.entity.status=="A")> &nbsp; <img src="images/green-circle-small.png" title="Active" )"></a>&nbsp; <a title="{{row.entity.meterQueueName}}">{{row.entity.meterQueueName}}</a></div>'},
		      { field:'isdefault',name: 'is Default' },
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort:{direction:'desc', priority:0} },
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      {name: 'Actions',cellClass:'actioncell',
		    	  cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openMeterQueueEditDialog($parent.$parent.row.entity)"></a>'+
		    		'<a href="javascript:void(0)" ng-click="grid.appScope.deleteMeterQueueDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',
			    	width: '60',enableSorting: false,enableFiltering: false,
			    	headerCellTemplate: '<div style="padding:2px;"><span>Action</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
	};

	
	$scope.meterQueue.listMeterQueues=function(){
		throttlingService.listMeterQueues().success(function(result){
			$scope.meterQueue.meterQueueList=result;
			angular.forEach($scope.meterQueue.meterQueueList,function(obj){
				if(obj.isDefault === 'Y'){
					obj.isdefault = 'Yes';
				}else{
					obj.isdefault = 'No';
				}
			});
			$scope.gridOptions.data = [];
			$timeout(function(){$scope.gridOptions.data = result;});
		}).error(function(result){
			console.dir(result);
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.meterQueue.saveMeterQueueDialog=function(){
		
		$("#admin_configurations_throttling_txt_meterQueueName").val("");
		var temp = newMeterQueueObj();
        $scope.$evalAsync(function(){
        	$scope.meterQueue.meterQueueObj.saveFlag = $scope.meterQueue.meterQueueObj.saveFlag;
	           $scope.meterQueue.meterQueueObj =  temp;
	           initialzeConfigDialogs('THROTTLING');
	           $("#admin_configurations_div_addthrottling").dialog('option', 'title','Add Throttle');
	   			$( "#admin_configurations_div_addthrottling").dialog('open');
     });
		
		
	};
	
	function newMeterQueueObj(){
		var mqObj = {};
		
		mqObj.meterQueueName='';
		mqObj.meterRate='S';
		mqObj.maxRate='';
		mqObj.maxRate00 = '';
		mqObj.maxRate01 = '';
		mqObj.maxRate02 = '';
		mqObj.maxRate03 = '';
		mqObj.maxRate04 = '';
		
		mqObj.maxRate05 = '';
		mqObj.maxRate06 = '';
		mqObj.maxRate07 = '';
		mqObj.maxRate08 = '';
		mqObj.maxRate09 = '';
		
		mqObj.maxRate10 = '';
		mqObj.maxRate11 = '';
		mqObj.maxRate12 = '';
		mqObj.maxRate13 = '';
		mqObj.maxRate14 = '';
		
		mqObj.maxRate15 = '';
		mqObj.maxRate16 = '';
		mqObj.maxRate17 = '';
		mqObj.maxRate18 = '';
		mqObj.maxRate19 = '';
		
		mqObj.maxRate20 = '';
		mqObj.maxRate21 = '';
		mqObj.maxRate22 = '';
		mqObj.maxRate23 = '';
		mqObj.status='A';
		mqObj.saveFlag = 'Y';
		mqObj.isDefault='Y';
		throttlingService.existingDefaultMeterQueueForClient().success(function(result){
			if(result.response) {
				mqObj.isDefault='N';
			
			}else{
				mqObj.isDefault='Y';
				}
		});
		if($scope.meterQueue.meterQueueObj.meterQueueId === undefined) {
			mqObj.meterQueueId = 0;
		}
		mqObj.customerId = 1;
		
		mqObj.createdBy=zhapp.loginUser.userName;
		mqObj.updatedBy=zhapp.loginUser.userName;
		return mqObj;
	}
	
	$scope.meterQueue.defaultExists=function(){
		$scope.meterQueue.meterQueueObj.isDefaultOverride = false;
		// check if user selects isDefault to 'Y' (check if any throttle is already selected as 'Y' and prompt for override
		var defer=$q.defer();
		if($scope.meterQueue.meterQueueObj.isDefault === 'Y') {
			throttlingService.existingDefaultMeterQueueForClient().success(function(result){
				if(typeof  result.response !== "undefined") {
					var msg = "Default already configured to '"+result.response+"' <br> override ?";
					  showCommonConfirmMessage(msg,"Confirm","Yes","No","450",function(isOk,defer){
						  if(isOk){
							  $scope.meterQueue.meterQueueObj.isDefaultOverride = true;
						  }else{
							  $scope.meterQueue.meterQueueObj.isDefaultOverride = false;
							  return false;
						  }
						  defer.resolve();
					  },defer);
				}else{
					 defer.resolve();
				}
			}).error(function(resp){ 
				defer.reject(resp);
			});
		}else{
			defer.resolve();
		}
		return defer.promise;
	};
	
	$scope.meterQueue.addMeterQueue=function(saveFlag){
		var canSave = throttlingValidationService.validateMeterQueue($scope.meterQueue.meterQueueObj);
		if(!canSave) return;
		var isDefaultOverride = false;
		
		var promises = [];
		promises.push($scope.meterQueue.defaultExists()); 
		 
		
		// Save the meter queue if the meter queue name does not already exists or if the operation is Edit
		 $q.all(promises).then(function(){
			 var isDefaultOverride = $scope.meterQueue.meterQueueObj.isDefaultOverride;
			throttlingService.isMeterQueueExistsWithNameAndId($scope.meterQueue.meterQueueObj.meterQueueId,$scope.meterQueue.meterQueueObj.meterQueueName).success(function(result){
			if(result.isMeterQueue){
				  showErrorMessage("Throttling with the name "+$scope.meterQueue.meterQueueObj.meterQueueName+" already exists, Specify another name.");
					return false;  
			  }else{
				  if($scope.meterQueue.meterQueueObj.meterQueueId > 0 && $scope.meterQueue.meterQueueObj.status === 'A') {
						  throttlingService.meterQueueAssociatedCampaigns($scope.meterQueue.meterQueueObj.meterQueueId).success(function(result){
							   if(result.response === "") {
								     $scope.meterQueue.meterQueueObj.createdBy = zhapp.loginUser.userName;
									  $scope.meterQueue.meterQueueObj.updatedBy = zhapp.loginUser.userName;
									  throttlingService.saveMeterQueue($scope.meterQueue.meterQueueObj,isDefaultOverride).success(function(){
										  if(saveFlag) {
												showInfoMessage("Throttling saved successfully");
											}else{
												showInfoMessage("Throttling updated successfully");
											}
										$( "#admin_configurations_div_addthrottling" ).dialog( "destroy" );
										$scope.meterQueue.meterQueueObj = {};
										$scope.meterQueue.listMeterQueues();
									}).error(function(resp){
										showConfigurationErrorMessage(resp);
									});
							   } else{
								   var msg = "Changes will impact associated conversation(s):<br> "+result.response+" <br> override ?";
								   showCommonConfirmMessage(msg,"Confirm","Yes","No","450",function(isOk){
										if(isOk){
												$scope.meterQueue.meterQueueObj.updatedBy = zhapp.loginUser.userName;
												throttlingService.saveMeterQueue($scope.meterQueue.meterQueueObj,isDefaultOverride).success(function(){
													if(saveFlag) {
														showInfoMessage("Throttling saved successfully");
													}else{
														showInfoMessage("Throttling updated successfully");
													}
													$( "#admin_configurations_div_addthrottling" ).dialog( "destroy" );
													$scope.meterQueue.meterQueueObj = {};
													$scope.meterQueue.listMeterQueues();
												}).error(function(resp){
													showConfigurationErrorMessage(resp);
												});
											
										}
									});
							   }	
						}).error(function(error){
							showConfigurationErrorMessage(error);
						});
				  }
				  /*else if($scope.meterQueue.meterQueueObj.meterQueueId > 0 && $scope.meterQueue.meterQueueObj.status === 'I') {
					  throttlingService.meterQueueAssociatedCampaigns($scope.meterQueue.meterQueueObj.meterQueueId).success(function(result){
						   if(result.response !== "") {
							   var msg = "Throttling already associated to conversation(s) <br> "+result.response+" so cannot be inactive.: ";
							   showErrorMessage(msg);
						   } 
						   else
							   {
							   		$scope.meterQueue.meterQueueObj.createdBy = "ADMIN";
									$scope.meterQueue.meterQueueObj.updatedBy = "ADMIN";
									throttlingService.saveMeterQueue($scope.meterQueue.meterQueueObj,isDefaultOverride).success(function(){
									$( "#admin_configurations_div_addthrottling" ).dialog( "close" );
							   
							   }}
					  });
				  }*/
				  else if($scope.meterQueue.meterQueueObj.meterQueueId > 0 && $scope.meterQueue.meterQueueObj.status === 'I') {
					  throttlingService.meterQueueAssociatedCampaigns($scope.meterQueue.meterQueueObj.meterQueueId).success(function(result){
						   if(result.response !== "") {
							   var msg = "Throttling already associated to conversation(s) <br> "+result.response+" so cannot be inactive.: ";
							   showErrorMessage(msg);
						   } else{
						   	 $scope.meterQueue.meterQueueObj.createdBy = zhapp.loginUser.userName;
						$scope.meterQueue.meterQueueObj.updatedBy = zhapp.loginUser.userName;
						throttlingService.saveMeterQueue($scope.meterQueue.meterQueueObj,isDefaultOverride).success(function(){
							if(saveFlag) {
								showInfoMessage("Throttling saved successfully");
							}else{
								showInfoMessage("Throttling updated successfully");
							}
							 $( "#admin_configurations_div_addthrottling" ).dialog( "destroy" );
							 $scope.meterQueue.meterQueueObj = {};
							$scope.meterQueue.listMeterQueues();
						}).error(function(resp){
							showConfigurationErrorMessage(resp);
						});
						   }
					  }).error(function(error){
						  showConfigurationErrorMessage(error);
					  });
					  }
				  
				  
				  
				  else if($scope.meterQueue.meterQueueObj.meterQueueId === 0) {
					    $scope.meterQueue.meterQueueObj.createdBy = zhapp.loginUser.userName;
						$scope.meterQueue.meterQueueObj.updatedBy = zhapp.loginUser.userName;
						throttlingService.saveMeterQueue($scope.meterQueue.meterQueueObj,isDefaultOverride).success(function(){
							if(saveFlag) {
								showInfoMessage("Throttling saved successfully");
							}else{
								showInfoMessage("Throttling updated successfully");
							}
							$( "#admin_configurations_div_addthrottling" ).dialog( "destroy" );
							$scope.meterQueue.meterQueueObj = {};
							$scope.meterQueue.listMeterQueues();
						}).error(function(resp){
							showConfigurationErrorMessage(resp);
						});
				  }
				  
				  
			  }
		});
		 });
	};
	
		$scope.openMeterQueueEditDialog=function(meterQueue){
			
		$scope.meterQueue.meterQueueId=meterQueue.meterQueueId;
		$scope.meterQueue.meterQueueObj = angular.copy(meterQueue);
		/*angular.forEach($scope.meterQueue.meterQueueObj,function(obj){
			if(obj.isDefault == 'Yes'){
				obj.isDefault = 'Y';
			}else{
				obj.isDefault = 'N';
			}
		});*/
		if(meterQueue.maxRate00 == meterQueue.maxRate01 && meterQueue.maxRate00 == meterQueue.maxRate02 && meterQueue.maxRate00 == meterQueue.maxRate03
				&& meterQueue.maxRate00 === meterQueue.maxRate04 && meterQueue.maxRate00 === meterQueue.maxRate05 && meterQueue.maxRate00 === meterQueue.maxRate06
				&& meterQueue.maxRate00 === meterQueue.maxRate07 && meterQueue.maxRate00 === meterQueue.maxRate08 && meterQueue.maxRate00 === meterQueue.maxRate09
				&& meterQueue.maxRate00 === meterQueue.maxRate10 && meterQueue.maxRate00 === meterQueue.maxRate11 && meterQueue.maxRate00 === meterQueue.maxRate12
				&& meterQueue.maxRate00 === meterQueue.maxRate13 && meterQueue.maxRate00 === meterQueue.maxRate14 && meterQueue.maxRate00 === meterQueue.maxRate15
				&& meterQueue.maxRate00 === meterQueue.maxRate16 && meterQueue.maxRate00 === meterQueue.maxRate17 && meterQueue.maxRate00 === meterQueue.maxRate18
				&& meterQueue.maxRate00 === meterQueue.maxRate19 && meterQueue.maxRate00 === meterQueue.maxRate20 && meterQueue.maxRate00 === meterQueue.maxRate21
				&& meterQueue.maxRate00 === meterQueue.maxRate22 && meterQueue.maxRate00 === meterQueue.maxRate23){
			
			$scope.meterQueue.meterQueueObj.meterRate = 'S';
			if(meterQueue.maxRate00 === 0){
				$scope.meterQueue.meterQueueObj.maxRate ="";
			}else{
				$scope.meterQueue.meterQueueObj.maxRate = meterQueue.maxRate00;
			}
		}else{
			$scope.meterQueue.meterQueueId=meterQueue.meterQueueId;
			$scope.meterQueue.meterQueueObj.meterRate = 'C';
			$scope.meterQueue.meterQueueObj.maxRate = '';
		}
		$scope.meterQueue.meterQueueObj.saveFlag = 'N';
		
		
		if(meterQueue.maxRate00 === 0){
			$scope.meterQueue.meterQueueObj.maxRate00 = '';
		}
		if(meterQueue.maxRate01 === 0){
			$scope.meterQueue.meterQueueObj.maxRate01 = '';
		}
		if(meterQueue.maxRate02 === 0){
			$scope.meterQueue.meterQueueObj.maxRate02 = '';
		}
		if(meterQueue.maxRate03 === 0){
			$scope.meterQueue.meterQueueObj.maxRate03 = '';
		}
		if(meterQueue.maxRate04 === 0){
			$scope.meterQueue.meterQueueObj.maxRate04 = '';
		}
		if(meterQueue.maxRate05 === 0){
			$scope.meterQueue.meterQueueObj.maxRate05 = '';
		}
		if(meterQueue.maxRate06 === 0){
			$scope.meterQueue.meterQueueObj.maxRate06 = '';
		}
		if(meterQueue.maxRate07 === 0){
			$scope.meterQueue.meterQueueObj.maxRate07 = '';
		}
		if(meterQueue.maxRate08 === 0){
			$scope.meterQueue.meterQueueObj.maxRate08 = '';
		}
		if(meterQueue.maxRate09 === 0){
			$scope.meterQueue.meterQueueObj.maxRate09 = '';
		}
		if(meterQueue.maxRate10 === 0){
			$scope.meterQueue.meterQueueObj.maxRate10 = '';
		}
		if(meterQueue.maxRate11 === 0){
			$scope.meterQueue.meterQueueObj.maxRate11 = '';
		}
		if(meterQueue.maxRate12 === 0){
			$scope.meterQueue.meterQueueObj.maxRate12 = '';
		}
		if(meterQueue.maxRate13 === 0){
			$scope.meterQueue.meterQueueObj.maxRate13 = '';
		}
		if(meterQueue.maxRate14 === 0){
			$scope.meterQueue.meterQueueObj.maxRate14 = '';
		}
		if(meterQueue.maxRate15 === 0){
			$scope.meterQueue.meterQueueObj.maxRate15 = '';
		}
		if(meterQueue.maxRate16 === 0){
			$scope.meterQueue.meterQueueObj.maxRate16 = '';
		}
		if(meterQueue.maxRate17 === 0){
			$scope.meterQueue.meterQueueObj.maxRate17 = '';
		}
		if(meterQueue.maxRate18 === 0){
			$scope.meterQueue.meterQueueObj.maxRate18 = '';
		}
		if(meterQueue.maxRate19 === 0){
			$scope.meterQueue.meterQueueObj.maxRate19 = '';
		}
		if(meterQueue.maxRate20 === 0){
			$scope.meterQueue.meterQueueObj.maxRate20 = '';
		}
		if(meterQueue.maxRate21 === 0){
			$scope.meterQueue.meterQueueObj.maxRate21 = '';
		}
		if(meterQueue.maxRate22 === 0){
			$scope.meterQueue.meterQueueObj.maxRate22 = '';
		}
		if(meterQueue.maxRate23 === 0){
			$scope.meterQueue.meterQueueObj.maxRate23 = '';
		}
		//$("#admin_configurations_div_addthrottling").dialog( "destroy" );
		initialzeConfigDialogs('THROTTLING');
		$("#admin_configurations_div_addthrottling").dialog('option', 'title','Edit Throttle');
		$("#admin_configurations_div_addthrottling").dialog( "open" );
	};
	
	$scope.deleteMeterQueueDialog=function(meterQueue){		
		$scope.meterQueue.meterQueueObj=meterQueue;
		showCommonConfirmMessage("Delete throttle rate?","Confirm","Yes","No",350,$scope.meterQueue.deleteMeterQueue);
	};
	// This function is used to delete the throttle record if it is not associated to any campaigns
	$scope.meterQueue.deleteMeterQueue=function(flag){
		if(flag){	
			throttlingService.meterQueueAssociatedCampaigns($scope.meterQueue.meterQueueObj.meterQueueId).success(function(result){
				   if(result.response === "") {
					   throttlingService.deleteMeterQueue($scope.meterQueue.meterQueueObj.meterQueueId).success(function(){
						   showInfoMessage("Throttle deleted successfully");
					        $scope.meterQueue.listMeterQueues();
					   }).error(function(error){
						   showConfigurationErrorMessage(error);
					   });
				   } else{
					   var msg = "Throttle cannnot be deleted. <br> Associated to: "+result.response;
					   showErrorMessage(msg);
				   }	
			}).error(function(error){
				 showConfigurationErrorMessage(error);
			});
		}
	};
	
	$scope.toggleFiltering = function(){
	    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
	    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	}; 
	
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("THROTTLING");
	});
}]);
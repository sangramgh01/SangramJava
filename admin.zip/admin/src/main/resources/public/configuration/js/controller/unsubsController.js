zhapp.controller("unsubsController",['$scope','$q','adminListingService','unsubsService','unsubsValidationService','uiGridConstants','$timeout',function($scope,$q,adminListingService,unsubsService,unsubsValidationService,uiGridConstants,$timeout) {
	$scope.unsubsKeyword={};
	$scope.keywordObj = {};
	$scope.unsubsKeyword.unsubsKeywordList=[];
	$scope.unsubProps={};
	$scope.unsubProps.unsubsTypes=[{key:"ABS", value:"Abuse"},
	                               {key:"HRD", value:"Hard Bounce"},
	                               {key:"IGN", value:"Ignore Unsub"},
	                               {key:"SFT", value:"Soft Bounce"},
	                               {key:"USB", value:"Unsub"}]
    
	$scope.unsubProps.unsubsCategories=[{key:"BODY", value:"Body"},
	                                    {key:"FROMADD", value:"From Address"},
	                                    {key:"MIME", value:"Mime"},
	                                    {key:"SUBJECT", value:"Subject"},
	                                    {key:"TOADD", value:"To Address"}]
		
	$scope.unsubsKeyword.keywordObj = {};
	$scope.unsubsKeyword.isEdit = false;
	$scope.systemUnsubGridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
		    columnDefs: [
		      { field:'unsubKeyword', name: 'Keyword',headerCellClass: $scope.highlightFilteredHeader , cellTemplate:'<div><a ng-show=(row.entity.status=="A")> &nbsp;<img src="images/green-circle-small.png" title="Active" )"></a>&nbsp;<a title="{{row.entity.unsubKeyword}}">{{row.entity.unsubKeyword}}</a> </div>'},
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On',sort:{direction:'desc', priority:0} },
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      { name: 'Actions',cellClass:'actioncell3',
			    	cellTemplate: '<a href="javascript:void(0)" ng-show=(row.entity.status==="A") ng-click="grid.appScope.deactiveKeywordDialog($parent.$parent.row.entity)">Deactivate</a><a href="javascript:void(0)" ng-show=(row.entity.status==="I") ng-click="grid.appScope.deactiveKeywordDialog($parent.$parent.row.entity)">Activate</a>',
			    		width: '80',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Action</span>&nbsp;<span><a href="javascript:void(0)"><img ng-click="grid.appScope.systemUnsubtoggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
		  };
	
	
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
		    columnDefs: [
		      { field:'unsubKeyword', name: 'Keyword',headerCellClass: $scope.highlightFilteredHeader , cellTemplate:'<div><a ng-show=(row.entity.status=="A")>&nbsp;<img src="images/green-circle-small.png" title="Active" )"></a>&nbsp;<a title="{{row.entity.unsubKeyword}}">&nbsp;{{row.entity.unsubKeyword}}</a></div>'},
		      { field:'createdBy',name: 'Created By' },
		      { field:'createDate',name: 'Created On' },
		      { field:'updateDate',name: 'Last Modified' },
		      { field:'updatedBy',name: 'Modified By' },
		      { name: 'Actions',cellClass:'actioncell3',
			    	cellTemplate: '<a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.editKeywordDialog($parent.$parent.row.entity)"></a>'+
			    		'<a href="javascript:void(0)" ng-click="grid.appScope.deleteKeywordDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a>',
			    		width: '70',enableSorting: false,enableFiltering: false,
			    		headerCellTemplate: '<div style="padding:2px;"><span>Action</span>&nbsp;<span><a href="javascript:void(0)"><img ng-click="grid.appScope.customUnsubtoggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
		    ]
		  };
	$scope.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	  
	
	  
	$scope.systemUnsubtoggleFiltering = function(){
		    $scope.systemUnsubGridOptions.enableFiltering = !$scope.systemUnsubGridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	$scope.customUnsubtoggleFiltering = function(){
		    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
		    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	$scope.unsubsKeyword.listSystemUnsubKeywords=function(unsubType){
		unsubsService.listUnsubKeywords(unsubType).success(function(result){
			$scope.unsubsKeyword.unsubsKeywordList=result;
			//$scope..data = result;
			//$scope.systemUnsubGridOptions.data = [];
			//$timeout(function(){$scope.systemUnsubGridOptions.data = result;});
			$scope.systemUnsubGridOptions.data = result;
			$scope.gridData=$scope.systemUnsubGridOptions.data;
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.unsubsKeyword.listCustomUnsubKeywords=function(unsubType){
		unsubsService.listUnsubKeywords(unsubType).success(function(result){
			$scope.unsubsKeyword.unsubsKeywordList=result;
			//$scope.gridOptions.data = result;
			//$scope.gridOptions.data = [];
			//$timeout(function(){$scope.gridOptions.data = result;});
			$scope.$evalAsync(function() {
				$scope.gridOptions.data = result;
				$scope.gridData=$scope.gridOptions.data;
	          });
			
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.unsubsKeyword.openAddUnsubs = function(title){
		$scope.unsubsKeyword.keywordObj =  newKeywordObj();
		$scope.unsubsKeyword.buttonName = "Save";
		$scope.unsubsKeyword.isEdit = false;
		//$(".regkey-pop").dialog('option', 'title',title);
		//$(".regkey-pop").dialog( "open" );
		
		 showDisableBack();
		 $("#adminunsubcustom").show();    
	};
	
	$scope.editKeywordDialog = function(Unsubs){
		$scope.unsubsKeyword.keywordObj =  angular.copy(Unsubs) ;
		$scope.unsubsKeyword.buttonName = "Update";
		$scope.unsubsKeyword.isEdit = true;
		$(".regkey-pop").dialog('option', 'title',"Edit Keyword");
		$(".regkey-pop").dialog( "open" );
	}
	
	function newKeywordObj(){
		var keyObj = {};
		keyObj.unsubKeywordId = 0;
		keyObj.unsubKeyword="";
		keyObj.status='A'; 
		keyObj.createdBy=zhapp.loginUser.userName;
		keyObj.updatedBy=zhapp.loginUser.userName;
		return keyObj;
	}
	
   $scope.unsubsKeyword.saveUnsubKeyword = function(unsubType){
		
		var isValid = unsubsValidationService.validateUnsubsKeyword($scope.unsubsKeyword.keywordObj);
		if(!isValid)
			return;
		
		/*unsubsService.isKeywordExistsWithNameAndId($scope.unsubsKeyword.keywordObj.unsubKeywordId,$scope.unsubsKeyword.keywordObj.unsubKeyword).success(function(result){
			if(result.isUnsubs){
				  showErrorMessage("Keyword with the name "+$scope.unsubsKeyword.keywordObj.unsubKeyword+" already exists, Specify another keyword.");
				  return false;  
			  }else{*/
				  unsubsService.saveUnsubsKeyword($scope.unsubsKeyword.keywordObj,unsubType).success(function(){
						if(!$scope.unsubsKeyword.isEdit){
							showInfoMessage("Keyword saved successfully");
							$("#adminunsubcustom").hide();
							hideDisableBack();
						}else{
							showInfoMessage("Keyword updated successfully");
							$(".regkey-pop").dialog('close');
						}
						$(".regkey-pop").dialog( "close" );
						if(unsubType === 'System') {
							$scope.unsubsKeyword.listSystemUnsubKeywords(unsubType);
						}else{
							
							$scope.unsubsKeyword.listCustomUnsubKeywords(unsubType);
						}
						
						
					}).error(function(result){
						showConfigurationErrorMessage(result);
					});
			  //}
			
		//});
		
	}
	
   $scope.deleteKeywordDialog = function(Unsubs){
	   $scope.unsubsKeyword.keywordObj = Unsubs ;
	   showCommonConfirmMessage("Delete keyword ?","Confirm","Yes","No",350,$scope.unsubsKeyword.deleteKeyword);
	}
   
   $scope.unsubsKeyword.deleteKeyword = function(flag){
		if(flag){
			unsubsService.deleteKeyword($scope.unsubsKeyword.keywordObj.unsubKeywordId).success(function(){
				showInfoMessage("Keyword deleted successfully");
				$scope.unsubsKeyword.listCustomUnsubKeywords('Custom');
			}).error(function(result){
				showConfigurationErrorMessage(result);
			});
		}
	}
   
   $scope.deactiveKeywordDialog = function(Unsubs){
	   $scope.unsubsKeyword.keywordObj = Unsubs ;
	   if(Unsubs.status === 'A'){
		   showCommonConfirmMessage("Deactivate keyword ?","Confirm","Yes","No",350,$scope.unsubsKeyword.deactiveKeyword);
	   }else{
		   showCommonConfirmMessage("Activate keyword ?","Confirm","Yes","No",350,$scope.unsubsKeyword.deactiveKeyword);
	   }
	   
	}
   
   $scope.unsubsKeyword.deactiveKeyword = function(flag){
		  if(flag){
			  $scope.keywordObj  = $scope.unsubsKeyword.keywordObj;
			  if($scope.unsubsKeyword.keywordObj.status === 'A') {
				  $scope.keywordObj.status = 'I';
			  }else{
				  $scope.keywordObj.status = 'A';
			  }
			 unsubsService.saveUnsubsKeyword($scope.keywordObj,'System').success(function(result){
				 if($scope.unsubsKeyword.keywordObj.status === 'I') {
					 showInfoMessage("Keyword deactivated successfully");
				  }else{
					  showInfoMessage("Keyword activated successfully");
				  }
				 $(".regkey-pop").dialog( "close" );
				$scope.unsubsKeyword.listSystemUnsubKeywords('System');
			}).error(function(result){
				 if($scope.unsubsKeyword.keywordObj.status === 'I') {
					  $scope.unsubsKeyword.keywordObj.status = 'A';
				  }else{
					  $scope.unsubsKeyword.keywordObj.status = 'I';
				  }
				$scope.unsubsKeyword.listSystemUnsubKeywords('System');
				showConfigurationErrorMessage(result);
			});
		  }
		}


	
	$timeout(function(){
		initialzeConfigDialogs("UNSUBS");
	});
}]);
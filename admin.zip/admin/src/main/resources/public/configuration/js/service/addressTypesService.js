zhapp.factory('addressTypesService', ['$http', function($http) {
    return {
        listAddressTypes: function() {
            return $http({
                method: 'GET',
                url: 'listAddressTypes'
            });
        },
        getTotalAddressTypesCount: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'getTotalAddressTypesCount',
                data: listingCriteria
            });
        },
        deleteAddressType: function(addressTypeName){
        	return $http({
        		method: 'DELETE',
        		url: 'deleteAddressType/'+addressTypeName
        	});
        },
        createAddressType: function(createAddressTypeObject){
        	return $http({
        		method: 'POST',
        		url: 'saveAddressType',
        		data: createAddressTypeObject
        	});
        },
        isAddressTypeExists: function(isEdit,addressTypeBO){
        	return $http({
        		method: 'POST',
        		url:'isAddressTypeExist/'+isEdit,
        		data:addressTypeBO
        	});
        }
    }
}]);
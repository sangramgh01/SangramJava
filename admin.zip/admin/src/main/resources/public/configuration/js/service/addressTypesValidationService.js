zhapp.factory('addressTypesValidationService', [ function() {
	var obj = {};
	
	//Validate the AddressTypeBO
	obj.validateAddressType = function(addressType) {
		if (!addressType.name
				|| addressType.name.length === 0) {
			showErrorMessage("Enter Address type name");
			return false;
		}
		else if(addressType.channelType.length===0){
			showErrorMessage("Please select atleast one channel type.");
			return false;
		}
			
		return true;
	}
	return obj;

}]);
zhapp.factory('dbsourceService', ['$http', function($http) {
    return {
        listDBsources: function() {
            return $http({
                method: 'GET',
                url: 'listDBSources'
            });
        },
        getTotalDBsourcesCount: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'getTotalDBsourcesCount',
                data: listingCriteria
            });
        },
        deleteDBsource: function(keyName){
        	return $http({
        		method: 'DELETE',
        		url: 'deleteDBSource/'+keyName
        	});
        },
        createDBSource: function(createDBsourceObject){
        	return $http({
        		method: 'POST',
        		url: 'createDBSource',
        		data: createDBsourceObject
        	});
        }
    }
}]);
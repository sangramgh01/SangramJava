
function ValidateIPaddress(ipaddress)   
	{  
	 if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress))  
	  {  
	    return (false) ; 
	  }  
	return (true)  ;
	};



zhapp.factory('dbsourceValidationService', [ function() {
	var obj = {};
	obj.validateDBsource = function(dbsource) {
		if (!dbsource.dbSourceName
				|| dbsource.dbSourceName.length === 0) {
			showErrorMessage("Enter source name");
			return false;
		}
		if (!dbsource.dbvendor) {
			showErrorMessage("Select  DBType");
			return false;
		}
		
		if (!dbsource.hostname || dbsource.hostname.length === 0 ) {
			showErrorMessage("Enter  Host Value");
			return false;
		}
		
		/*if ( ValidateIPaddress(dbsource.hostname) ) {
			showErrorMessage(" Host value is Invalid Format ");
			return false;
		}*/
		if ( !dbsource.port || dbsource.port.length === 0 ) {
			showErrorMessage("Enter Port number");
			return false;
		}
	     if (!dbsource.username || dbsource.username.length === 0) {
			showErrorMessage("Enter username");
			return false;
		}
		if (!dbsource.password || dbsource.password.length === 0) {
			showErrorMessage("Enter password");
			return false;
		}
		return true;
	}
	return obj;



}]);
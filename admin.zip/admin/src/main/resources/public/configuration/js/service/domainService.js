zhapp.factory('domainService', ['$http', function($http) {
    return {
    	listDomains: function() {
            return $http({
                method: 'GET',
                url: 'listDomains'
            });
        },
        saveDomain: function(domain) {
            return $http({
                method: 'POST',
                url: 'saveDomain',
                data: domain
            });
        },deleteDomain: function(code) {
            return $http({
                method: 'POST',
                url: 'deleteDomain',
                data: code
            });
        },getRestrictedDomainWithDepartmentList: function() {
            return $http({
                method: 'GET',
                url: 'getRestrictedDomainWithDepartmentList'
            });
        },
        viewSampleTemplate: function() {
            window.location.assign(zhapp.admin_host + '/configuration/templates/Restricted_Domains_Sample_File_Format.xls');
        },
        downloadRSDomains: function() {
        	window.location.assign(zhapp.admin_host + '/downloadRSDomains');
        },
        saveRestrictedDomains: function(fileData) {
            return $http({
                method: 'POST',
                url: 'saveRestrictedDomains',
                data:fileData,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            });
        },
        saveActiveRestrictedDomainforDept: function(restrictedDomainDeptList) {
        	return $http({
                method: 'POST',
                url: 'saveActiveRestrictedDomainforDept',
                data:restrictedDomainDeptList
            });
        },updateRestrictedDomains: function(restrictedDomainBO) {
        	return $http({
                method: 'POST',
                url: 'updateRestrictedDomains',
                data:restrictedDomainBO
            });
        }
        
    }
}]);
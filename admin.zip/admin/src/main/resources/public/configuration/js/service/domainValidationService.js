zhapp.factory('domainValidationService', [function() {
	var obj={};
	obj.validateDomain = function(domain){
		
		if(! domain.code||domain.code.length===0)
		{			
			showErrorMessage("Enter domain code.");
			return false;
		}
		if(! domain.pattern||domain.pattern.length===0)
		{			
			showErrorMessage("Enter domain pattern.");
			return false;
		}
		if(! domain.description||domain.description.length===0)
		{			
			showErrorMessage("Enter domain description.");
			return false;
		}
		if(domain.pattern.indexOf("@")!==-1)
		{			
			showCommonConfirmMessage("Domain pattern should not contain @.","Confirm","Ok","Cancel",300);
			return false;
		}
		return true;
	}
	return obj;

}]);
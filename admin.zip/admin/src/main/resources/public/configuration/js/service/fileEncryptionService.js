zhapp.factory('fileEncryptionService', ['$http', function($http) {
    return {
    	listfileEncryptions: function() {
            return $http({
                method: 'GET',
                url: 'listfileEncryptions'
            });
        },
        deleteFileEncryption: function(keyName){
        	return $http({
                method: 'DELETE',
                url: 'deleteEncryptionKey/'+keyName
            });
        },
        downloadKeys: function(keyName){
        	
            window.location.assign(zhapp.admin_host + '/downloadEncryptionKeys/'+keyName);
        },
        saveFileEncryptionForUpload: function(uploadForm){
        	return $http({
                method: 'POST',
                url: 'saveFileEncryptionForUpload',
                data:uploadForm,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            });
        },
        saveFileEncryptionForGenereate: function(keyBO){
        	return $http({
                method: 'POST',
                url: 'saveFileEncryptionForGenereate',
                data:keyBO
            });
        }
    }
}]);
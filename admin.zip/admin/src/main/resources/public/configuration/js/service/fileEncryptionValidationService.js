zhapp.factory('fileEncryptionValidationService', [ function() {
	var obj = {};
	obj.validateFileEncryption = function(keyObj) {
			if(! keyObj.encryptionKeyName ||keyObj.encryptionKeyName.length===0)
			{			
				showErrorMessage("Enter encryption key name.");
				return false;
			}
			if(! keyObj.encryptionType ||keyObj.encryptionType.length===0)
			{			
				showErrorMessage("Select encryption key type.");
				return false;
			}
			if(! keyObj.passphrase ||keyObj.passphrase.length===0)
			{			
				showErrorMessage("Enter encryption key passphrase.");
				return false;
			}
			if(! keyObj.registrationtype ||keyObj.registrationtype.length===0)
			{			
				showErrorMessage("Select encryption key registration type.");
				return false;
			}
			if(keyObj.registrationtype==='G' && (! keyObj.keysize || keyObj.keysize===0))
			{			
				showErrorMessage("Select key size.");
				return false;
			}
			return true;
		}
	
	return obj;

}]);
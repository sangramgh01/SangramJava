zhapp.factory('filesourceService', ['$http', function($http) {
    return {
        listFilesources: function() {
            return $http({
                method: 'GET',
                url: 'listFileSources'
            });
        },
        getTotalFilesourcesCount: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'getTotalFilesourcesCount',
                data: listingCriteria
            });
        },
        deleteFilesource: function(keyName){
        	return $http({
        		method: 'DELETE',
        		url: 'deleteFileSource/'+keyName
        	});
        },
        createFileSource: function(createFilesourceObject){
        	return $http({
        		method: 'POST',
        		url: 'createFileSource',
        		data: createFilesourceObject
        	});
        }
    }
}]);
zhapp.factory('filesourceValidationService', [ function() {
	var obj = {};
	obj.validateFilesource = function(filesource) {
		if (!filesource.fileSourceName
				|| filesource.fileSourceName.length === 0) {
			showErrorMessage("Enter source name");
			return false;
		}
		if (!filesource.hostname) {
			showErrorMessage("Enter the host name");
			return false;
		}
		if (!filesource.protocol) {
			showErrorMessage("select the protocol");
			return false;
		}
		if (filesource.protocol!=="http"&&filesource.protocol!=="https"&&!filesource.port) {
			showErrorMessage("Enter the port number");
			return false;
		}
		if (filesource.protocol!=="http"&&filesource.protocol!=="https"&&(!filesource.username || filesource.username.length === 0)) {
			showErrorMessage("Enter username");
			return false;
		}
		if (filesource.protocol!=="http"&&filesource.protocol!=="https"&&(!filesource.password || filesource.username.password === 0)) {
			showErrorMessage("Enter password");
			return false;
		}
		return true;
	}
	
	return obj;


}]);
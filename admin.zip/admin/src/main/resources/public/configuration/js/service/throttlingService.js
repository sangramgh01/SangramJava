zhapp.factory('throttlingService', ['$http', function($http) {
    return {
        listMeterQueues: function() {
            return $http({
                method: 'GET',
                url: '/listMeterQueues'
            });
        },
        saveMeterQueue: function(meterQueueObj, isDefaultOverride) {
            return $http({
                method: 'POST',
                url: '/saveMeterQueue/'+isDefaultOverride,
                data: meterQueueObj
            });
        },
        deleteMeterQueue: function(meterQueueId) {
            return $http({
                method: 'DELETE',
                url: '/deleteMeterQueue/'+meterQueueId
            });
        },
        existingDefaultMeterQueueForClient: function() {
            return $http({
                method: 'GET',
                url: '/existingDefaultMeterQueueForClient'
            });
        },
        meterQueueAssociatedCampaigns: function(meterQueueId) {
            return $http({
                method: 'GET',
                url: '/meterQueueAssociatedCampaigns/'+meterQueueId
            });
        },
        isMeterQueueExists: function(meterQueueName) {
            return $http({
                method: 'GET',
                url: '/isMeterQueueExists/'+meterQueueName
            });
        },
        isMeterQueueExistsWithNameAndId: function(meterQueueId,meterQueueName) {
            return $http({
                method: 'GET',
                url: '/isMeterQueueExistsWithNameAndId/'+meterQueueId+"/"+meterQueueName
            });
        }
    }
}]);
zhapp.factory('throttlingValidationService', [ function() {
	var obj = {};
	obj.validateMeterQueue = function(meterQueueObj) {

		if (!meterQueueObj.meterQueueName || meterQueueObj.meterQueueName.length === 0) {
			showErrorMessage("Enter meter queue name.");
			return false;
		}
		
		
		if(meterQueueObj.meterRate === 'S'){
			if(meterQueueObj.meterQueueId===undefined)
			{
			meterQueueObj.meterQueueId=0;
			}
			if(meterQueueObj.maxRate && isNaN(meterQueueObj.maxRate)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			meterQueueObj.maxRate00=meterQueueObj.maxRate;
			meterQueueObj.maxRate01=meterQueueObj.maxRate;
			meterQueueObj.maxRate02=meterQueueObj.maxRate;
			meterQueueObj.maxRate03=meterQueueObj.maxRate;
			meterQueueObj.maxRate04=meterQueueObj.maxRate;
			meterQueueObj.maxRate05=meterQueueObj.maxRate;
			meterQueueObj.maxRate06=meterQueueObj.maxRate;
			meterQueueObj.maxRate07=meterQueueObj.maxRate;
			meterQueueObj.maxRate08=meterQueueObj.maxRate;
			meterQueueObj.maxRate09=meterQueueObj.maxRate;
			meterQueueObj.maxRate10=meterQueueObj.maxRate;
			meterQueueObj.maxRate11=meterQueueObj.maxRate;
			meterQueueObj.maxRate12=meterQueueObj.maxRate;
			meterQueueObj.maxRate13=meterQueueObj.maxRate;
			meterQueueObj.maxRate14=meterQueueObj.maxRate;
			meterQueueObj.maxRate15=meterQueueObj.maxRate;
			meterQueueObj.maxRate16=meterQueueObj.maxRate;
			meterQueueObj.maxRate17=meterQueueObj.maxRate;
			meterQueueObj.maxRate18=meterQueueObj.maxRate;
			meterQueueObj.maxRate19=meterQueueObj.maxRate;
			meterQueueObj.maxRate20=meterQueueObj.maxRate;
			meterQueueObj.maxRate21=meterQueueObj.maxRate;
			meterQueueObj.maxRate22=meterQueueObj.maxRate;
			meterQueueObj.maxRate23=meterQueueObj.maxRate;
		}else if(meterQueueObj.meterRate === 'C'){
			if(meterQueueObj.meterQueueId===undefined)
				{
				meterQueueObj.meterQueueId=0;
				}
			
			if(meterQueueObj.maxRate00 && isNaN(meterQueueObj.maxRate00)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate01 && isNaN(meterQueueObj.maxRate01)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate02 && isNaN(meterQueueObj.maxRate02)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate03 && isNaN(meterQueueObj.maxRate03)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate04 && isNaN(meterQueueObj.maxRate04)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate05 && isNaN(meterQueueObj.maxRate05)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate06 && isNaN(meterQueueObj.maxRate06)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate07 && isNaN(meterQueueObj.maxRate07)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate08 && isNaN(meterQueueObj.maxRate08)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate09 && isNaN(meterQueueObj.maxRate09)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate10 && isNaN(meterQueueObj.maxRate10)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate11 && isNaN(meterQueueObj.maxRate11)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate12 && isNaN(meterQueueObj.maxRate12)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate13 && isNaN(meterQueueObj.maxRate13)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate14 && isNaN(meterQueueObj.maxRate14)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate15 && isNaN(meterQueueObj.maxRate15)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate16 && isNaN(meterQueueObj.maxRate16)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate17 && isNaN(meterQueueObj.maxRate17)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate18 && isNaN(meterQueueObj.maxRate18)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate19 && isNaN(meterQueueObj.maxRate19)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate20 && isNaN(meterQueueObj.maxRate20)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate21 && isNaN(meterQueueObj.maxRate21)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate22 && isNaN(meterQueueObj.maxRate22)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
			if(meterQueueObj.maxRate23 && isNaN(meterQueueObj.maxRate23)){
				showErrorMessage("Please Enter Meter Rate as Numeric values Only");
				return false;
			}
		}
		
		return true;
	}

	return obj;

} ]);
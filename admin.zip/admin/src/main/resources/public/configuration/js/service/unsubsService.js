zhapp.factory('unsubsService', ['$http', function($http) {
    return {
    	listUnsubKeywords: function(unsubType) {
            return $http({
                method: 'GET',
                url: 'listUnsubs/All/'+unsubType
            });
        },
        saveUnsubsKeyword: function(keywordBO,unsubType) {
        	return $http({
                method: 'POST',
                url: 'saveUnsubs/'+unsubType,
                data:keywordBO
            });
        },
        deleteKeyword: function(keywordId) {
        	return $http({
                method: 'DELETE',
                url: 'deleteUnsubs/'+keywordId+'/Custom'
            });
        },
        isKeywordExistsWithNameAndId: function(keywordId,keywordName) {
        	return $http({
                method: 'GET',
                url: 'isUnsubsExists/'+keywordName+'/'+keywordId+'/Custom'
            });
        }
    }
}]);
zhapp.factory('unsubsValidationService', [ function() {
	var obj = {};
	obj.validateUnsubsKeyword = function(keywordObj) {
		if ( !keywordObj.unsubKeyword || keywordObj.unsubKeyword.length === 0 ) {
			showErrorMessage("Enter keyword name.");
			return false;
		}else if ( !keywordObj.type || keywordObj.type.length === 0 ) {
			showErrorMessage("Select keyword type.");
			return false;
		}else if ( !keywordObj.category || keywordObj.category.length === 0 ) {
			showErrorMessage("Select keyword category.");
			return false;
		}
		return true;
	}
	return obj;

} ]);
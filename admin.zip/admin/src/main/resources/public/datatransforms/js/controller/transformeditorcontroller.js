zhapp.controller("TransformController",['$rootScope','$scope','$q','dataTransformsService',function($rootScope,$scope,$q,dataTransformsService) {
	
	$scope.name='';
	$scope.useTransaction='';
	$scope.transform={};
	$scope.transformController={};
	$scope.transformController.name='';
	$scope.transformController.transform='';
	$scope.transformController.usetransaction='';
	$scope.transformController.transform='';
	$scope.transformController.createdby=zhapp.loginUser.userName;
	$scope.transformController.updatedby=zhapp.loginUser.userName;
	$scope.transformController.createddate='';
	$scope.transformController.updateddate='';
	$scope.hubListCriteria={};
	$scope.searchTransformList={};
	$scope.searchTransformList.pageno=1;
	$scope.searchTransformList.pagesize=7;
	$scope.searchTransformList.sortby = 'name';	
	$scope.searchTransformList.sortorder='DESC';
	$scope.searchTransformList.totalsize;
	$scope.searchTransformList.namelike;
	$scope.searchTransformList.id;
	$scope.searchTransformList.createdFromDate;
	$scope.searchTransformList.createdToDate;
	$scope.searchTransformList.updatedTodate;
	$scope.searchTransformList.updatedFromdate;
	$scope.searchTransformList.maxFiles;
	$scope.searchTransformList.ignorebadfiles;
	$scope.searchForTransform='I';
	$scope.transform.searchtext='';
	$scope.transform.infoMessage="There are no transforms";
	$scope.pageTransformList=[];
	$scope.totalRecords=-1;
	$scope.listOfTransform=null;
	$scope.fullDate = new Date();
	
	
	  
	  $scope.$on('rootScope:broadcast', function (event, data) {
		console.log(data); // 'Broadcast!'
	  });
	  
	  
	
	$scope.searchFor= [{'key':'I','value':'Id'},
	                   {'key':'NE','value':'Name'},
	                   {'key':'CD','value':'Created Date'}, 
	                   {'key':'MD','value':'Modified Date'}]; 
	
$scope.init=function(){	
	
	$(".anc-box").hide();
	$(".edit-box").hide();
	$(".edittransform-popup").hide();
	
	$("#headertransformeditor").show();
	$("#listofTransforms").show();
	$(".mbox-menu").show();
	$("#Filetransform").show();
	$scope.searchTransformList={};
	$scope.transform.searchtext='';
	$scope.transform.createFromDate='';
	$scope.transform.createToDate=getChangedDateForUIUtil($scope.fullDate);//'';
	$scope.transform.modifiedFromDate='';
	$scope.transform.modifiedToDate= getChangedDateForUIUtil($scope.fullDate);//'';
	$scope.searchTransformList.pageno=1;
	$scope.searchTransformList.pagesize=7;
	$scope.loadPageDetails(1);
	if($scope.transformController.createdby==undefined||$scope.transformController.createdby=='')
	{
		$scope.transformController.createdby = "DataTransformsUser";
	}
	var fullDate = new Date();
	
	}; 
	var user= zhapp.loginUser.userName;
	console.log('LOGGGED IN USER-->'+user);
	//pageNation
	$scope.loadPageDetails=function(pageno){
		$scope.searchTransformList.pageno=pageno;
		listListDetails();
	}
	  
	function listListDetails(){
			
		$scope.hubListCriteria.pageno=$scope.searchTransformList.pageno;	
		$scope.hubListCriteria.pagesize=$scope.searchTransformList.pagesize;
		
		$scope.hubListCriteria.sortby=$scope.searchTransformList.sortby;
		$scope.hubListCriteria.sortorder=$scope.searchTransformList.sortorder;
		
		$scope.newTransformList=new Array();
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			
			$scope.newTransformList=result;
			if($scope.newTransformList.length>0)
			{
				$scope.totalRecords=$scope.newTransformList[0].totalsize;
			}
			else
			{
				$scope.totalRecords=0;
			}
			
			//$scope.loadScheduleEvents();
		
	}).error(function(result){
		
		showConfigurationErrorMessage(result);
	});
		
	}
	 
$scope.init();	


$scope.$on('transformeditor', function(e) {
	
	$scope.searchTransformList.sortorder="DESC";
	
        $scope.init();
   });	
   
$scope.getBuids=function() {
	
			setRgtHeaderWidth();
			$(window).resize(function(){setRgtHeaderWidth();});
			  	
};

$scope.$on('listingCriteriaChanged', function () {
    if($scope.adminModule.sortorder == 'descending'){
        $scope.searchTransformList.sortorder = 'DESC';
        
    }else{
        $scope.searchTransformList.sortorder = 'ASC';
    }
    if($scope.adminModule.sortby == 'createdon'){
        $scope.searchTransformList.sortby='createdate';
    }else{
        $scope.searchTransformList.sortby=$scope.adminModule.sortby;
    }
    listListDetails();
});

function setRgtHeaderWidth() {
	        if (screen.width >= 1900)
		       $(".l-rightpanel").css("width", "1535px");
	       if (navigator.appName == 'Microsoft Internet Explorer')
		       $("#headertransformeditor").width();  
	       else{
	    	   $("#headertransformeditor").width();
	       }
	    	   
};

$(window).resize(function(){ setRgtHeaderWidth();});
//DateFormat

$scope.dateToNormalString=function(d){
    var hh = d.getHours(); 
    var min = d.getMinutes(); 
    var suffix = "AM"; 
    var hours = hh;
    if (min.toString().length == 1) 
        min = "0" + min;         
    if (hours >= 12) {
     hours = hh - 12;
        suffix = "PM";
    }
    if (hours == 0) {
     hours = 12;
    }
    var Datetime = (d.getMonth()+1)+"/"+d.getDate()+"/"+d.getFullYear()+" "+hours+":"+min+":"+d.getSeconds()+" "+suffix;         
    return Datetime;
   };
   
   $scope.searchRefresh=function(){
	   $scope.transform.searchtext='';
	   $scope.transform.createFromDate='';
		$scope.transform.createToDate='';
		$scope.transform.modifiedFromDate='';
		$scope.transform.modifiedToDate='';
		
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result){
			showConfigurationErrorMessage(result);
			$scope.loading=false;
			$scope.newTransformList=[];
		});
   }
		 
//For Search Text Field Validations 
$scope.searchTransform=function(){
	$scope.transform.searchtext='';
	$scope.loadPageDetails(1);
}

//For Date picker in Creation Date
$scope.loadScheduleEvents=function(){
		$( ".datepicker" ).datepicker({autoclose:true,format: 'yyyy-mm-dd',todayHighlight:true});       
		$('.timepicker').timepicker({
	        showSeconds: false,
	        showMeridian: false,
	        defaultTime: false,
	        disableFocus: false,
	        minuteStep: 1
	    });
	    $('.cal-icon').click(function(){
			$(this).prev("input").trigger('focus');
		});
		   
	    
	};


//For Search
	
$scope.transform.search=function(event){
			if($scope.searchForTransform=='I'){
						searchByIdPages(event);	
				}else if($scope.searchForTransform=='NE'){
					searchByNamePages(event);
				}else if($scope.searchForTransform=='CD'){
					searchByCreationDate(event);
				}else if($scope.searchForTransform=='MD'){
					searchByModificationDate(event);
				}
			
			}

function searchByNamePages(event){
	 if((event.type=="click" || event.keyCode==13) && $scope.transform.searchtext.length==0){
			showErrorMessage("Enter the string to be searched.");	
			return;
		}else if(event.type=="click" || event.keyCode==13)		
		{
			
			
			$scope.hubListCriteria.sortby=$scope.searchTransformList.sortby;
			$scope.hubListCriteria.sortorder=$scope.searchTransformList.sortorder;
			
		$scope.hubListCriteria.namelike=$scope.searchTransformList.namelike;
        $scope.searchTransformList.namelike=$scope.transform.searchtext;
      
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result){
			showConfigurationErrorMessage(result);
			$scope.loading=false;
			$scope.newTransformList=[];
		});
		
	}
	 if(((event.keyCode==8 || event.keyCode==46)&& $scope.transform.searchtext.length==0)){

			$scope.init();
		}
}

function searchByIdPages(event){
		
	 if((event.type=="click" || event.keyCode==13) && $scope.transform.searchtext.length==0){
		showErrorMessage("Enter the string to be searched.");	
		return;
	}else if(event.type=="click" || event.keyCode==13)						
		{
		if(isNaN($scope.transform.searchtext)){
			showErrorMessage("Please enter numeric values only");
			$scope.transform.searchtext="";
			return false;
		}
		
		if($scope.transform.searchtext==0){
			showErrorMessage("Enter id value more than 0.");	
			$scope.transform.searchtext='';
			return false;
		}
		
		$scope.hubListCriteria.sortby=$scope.searchTransformList.sortby;
		$scope.hubListCriteria.sortorder=$scope.searchTransformList.sortorder;
							$scope.hubListCriteria.namelike=$scope.searchTransformList.namelike;
							$scope.searchTransformList.id=$scope.transform.searchtext;
        dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result){
				showConfigurationErrorMessage(result);
			$scope.loading=false;
			$scope.newTransformList=[];
		});
		
	}
	 if(((event.keyCode==8 || event.keyCode==46)&& $scope.transform.searchtext.length==0)){
		$scope.init();
	}
}

function searchByCreationDate(event){
	//Begin for OneView-<<9455>>
	
    //Desc :: <<An alert is showing with message like "UNDEFINED".Removed from here that alert message issue fixed>>
	
	//End for OneView-<<9455>>

	 if((event.type=="click" || event.keyCode==13) && $scope.transform.createFromDate.length==0 || $scope.transform.createToDate.length==0){
		 if(($scope.transform.createFromDate.length==undefined  || $scope.transform.createFromDate.length==0 || $scope.transform.createFromDate.length=="" )&& ($scope.transform.createToDate.length==undefined || $scope.transform.createToDate.length==0 || $scope.transform.createToDate.length=="")){
             showErrorMessage("Please select fromDate and toDate.");     
             return;
       }
       else if($scope.transform.createFromDate.length==undefined  ||  $scope.transform.createFromDate.length==0 ||$scope.transform.createFromDate.length==""){
             showErrorMessage("Please select fromDate.");    
             return;
       }
       else if($scope.transform.createToDate.length==undefined || $scope.transform.createToDate.length==0 || $scope.transform.createToDate.length==""){
             showErrorMessage("Please select toDate.");      
             return;
       }
		}else if(event.type=="click" || event.keyCode==13)
		{
		year = $scope.transform.createFromDate.split('-')[0];
	    month = $scope.transform.createFromDate.split('-')[1] - 1;
	    day = $scope.transform.createFromDate.split('-')[2];
	    var endson=new Date(year, month, day, 00, 00);
	    
		$scope.searchTransformList.createdFromDate= dateToNormalStringUtil(endson);
	    
	    year1 = $scope.transform.createToDate.split('-')[0];
	    month1 = $scope.transform.createToDate.split('-')[1] - 1;
	    day1 = $scope.transform.createToDate.split('-')[2];
	    var endson1=new Date(year1, month1, day1, 23, 59);
	    
	    $scope.searchTransformList.createdToDate= dateToNormalStringUtil(endson1);
	  //Begin for OneView-<<9488>>
		
	    //Desc :: <<Search for created date is accepting dates in descending order in transform and workflow home page>>
	    if(endson > endson1){
    		showErrorMessage("Please select fromdate which is less than or equalto todate.");
    		return;
    	}
	  //End for OneView-<<9488>>
	    $scope.hubListCriteria.sortby=$scope.searchTransformList.sortby;
		$scope.hubListCriteria.sortorder=$scope.searchTransformList.sortorder;
							$scope.hubListCriteria.createdFromDate=$scope.searchTransformList.createdFromDate;
							$scope.hubListCriteria.createdToDate=$scope.searchTransformList.createdToDate;
							$scope.searchTransformList.pageno=1;	
        dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result){
			showConfigurationErrorMessage(result);
			$scope.loading=false;
			$scope.newTransformList=[];
		});
		
	}
	 if(((event.keyCode==8 || event.keyCode==46)&& $scope.transform.createFromDate.length==0 || $scope.transform.createToDate.length==0 )){
			$scope.init();
		}
	
}
function searchByModificationDate(event){
	if((event.type=="click" || event.keyCode==13) && $scope.transform.modifiedFromDate.length==0 || $scope.transform.modifiedToDate.length==0){
		if(($scope.transform.modifiedFromDate.length==undefined  || $scope.transform.modifiedFromDate.length==0 || $scope.transform.modifiedFromDate.length=="" )&& ($scope.transform.modifiedToDate.length==undefined || $scope.transform.modifiedToDate.length==0 || $scope.transform.modifiedToDate.length=="")){
            showErrorMessage("Please select fromDate and toDate.");     
            return;
      }
      else if($scope.transform.modifiedFromDate.length==undefined  ||  $scope.transform.modifiedFromDate.length==0 ||$scope.transform.modifiedFromDate.length==""){
            showErrorMessage("Please select fromDate.");    
            return;
      }
      else if($scope.transform.modifiedToDate.length==undefined || $scope.transform.modifiedToDate.length==0 || $scope.transform.modifiedToDate.length==""){
            showErrorMessage("Please select toDate.");      
            return;
      }
	}else if(event.type=="click" || event.keyCode==13)
	{
		year = $scope.transform.modifiedFromDate.split('-')[0];
	    month = $scope.transform.modifiedFromDate.split('-')[1] - 1;
	    day = $scope.transform.modifiedFromDate.split('-')[2];
	    var endson=new Date(year, month, day, 00, 00);
	    
		$scope.searchTransformList.updatedFromdate= dateToNormalStringUtil(endson);
	    
	    year1 = $scope.transform.modifiedToDate.split('-')[0];
	    month1 = $scope.transform.modifiedToDate.split('-')[1] - 1;
	    day1 = $scope.transform.modifiedToDate.split('-')[2];
	    var endson1=new Date(year1, month1, day1, 23, 59);
	    
	    $scope.searchTransformList.updatedTodate= dateToNormalStringUtil(endson1);
         //Begin for OneView-<<9488>>
		
	    //Desc :: <<Search for modified date is accepting dates in descending order in transform and workflow home page>>
	    if(endson > endson1){
    		showErrorMessage("Please select fromdate which is less than or equalto todate");
    		return;
    	}
		  //End for OneView-<<9488>>
	    $scope.hubListCriteria.sortby=$scope.searchTransformList.sortby;
		$scope.hubListCriteria.sortorder=$scope.searchTransformList.sortorder;
		
							$scope.hubListCriteria.updatedFromdate=$scope.searchTransformList.updatedFromdate;
							$scope.hubListCriteria.updatedTodate=$scope.searchTransformList.updatedFromdate;
							$scope.searchTransformList.pageno=1;	
        dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result){
				showConfigurationErrorMessage(result);
			$scope.loading=false;
			$scope.newTransformList=[];
		});
		
	}
	 if(((event.keyCode==8 || event.keyCode==46)&& $scope.transform.modifiedFromDate.length==0 || $scope.transform.modifiedToDate.length==0 )){
			$scope.init();
		}
	
}



function isSearchActive(){
	if($scope.transform.searchtext!=null){
		return true;
	}
};




$scope.useTransaction=false;
$scope.addTransform=function(){
	$scope.tranformName=null;
	$scope.transformTextarea=null;
	$scope.useTransaction=false;
	$(".anc-box").show();	
}


$scope.closeaddTransformpopup=function(){
	
	$(".anc-box").hide();	
}
$scope.closeeditTransformpopup=function(){
	
	$(".edittransform-popup").dialog('close');	
}

$scope.editTransformpopup=function(){
	$(".edittransform-popup.ui-dialog-content").dialog("destroy");
	$( ".edittransform-popup" ).dialog( "open" );	
}


$scope.saveTranform=function(){
	
	$scope.transformController.id=0;
	if($scope.useTransaction==true){
		$scope.transformController.usetransaction='Y';
	}else{
		$scope.transformController.usetransaction='N';
	}
	if($scope.tranformName==''|| $scope.tranformName==null){
		showErrorMessage("Name cannot be empty.");
		return false;
	}
	if($scope.tranformName.length>255){
		showErrorMessage("Name length cannot be more than 255 characters");
		return false;
	}
	if($scope.transformTextarea=='' || $scope.transformTextarea==null){
		showErrorMessage("Transform cannot be empty.");
		return false;
	}
	$scope.transformController.name=$scope.tranformName.trim();
	$scope.transformController.transform=$scope.transformTextarea.trim();
	if($scope.transformController.updatedby==undefined||$scope.transformController.updatedby=='')
		{
			$scope.transformController.updatedby=zhapp.loginUser.userName;
		}
	dataTransformsService.saveTransform($scope.transformController).success(function(result){
		if(result.message == 'Success'){
			hideDisableBack();
			  $scope.init();
		}else{
			showConfigurationErrorMessage(result);
		}
	}).error(function(result){
		showConfigurationErrorMessage(result);
	});
}

$scope.useTransactionchecked="N";
$scope.editTransformid=0;
$scope.editTransformcreatedBy="";
$scope.editTransformcreatedDate=null;
//$scope.editTransformupdatedDate=null;
$scope.editSaveTransformPopUp=function(transFormPagesList){
	$(".edittransform-popup").show();
	$(".edittransform-popup.ui-dialog-content").dialog("destroy");
	$scope.editTranformName=transFormPagesList.name;
	$scope.editTransformTextarea=transFormPagesList.transform;
	if(transFormPagesList.usetransaction=='Y'){
		$("#useTransformTransaction").addClass("checked");
		$scope.useTransactionchecked="Y";
		$scope.useTransaction=true;
	}else{
		$("#useTransformTransaction").removeClass("checked");
		$scope.useTransaction=false;
		$scope.useTransactionchecked="N";
	}
	$scope.editTransformid=transFormPagesList.id;
	$scope.editTransformcreatedBy=transFormPagesList.createdby;
	$scope.editTransformcreatedDate=transFormPagesList.createddate;
		
		var opt = {
        autoOpen: false,
        modal: true,
        width: 550,
        //height:650,
        title: 'Edit Transform'
	};
	var theDialog = $(".edittransform-popup").dialog(opt);
	theDialog.dialog("open");
	
}

$scope.editSaveTransform=function(){
	
	
	if($scope.useTransaction==true){
		$scope.transformController.usetransaction='Y';
	}else{
		$scope.transformController.usetransaction='N';
	}
	if($scope.editTranformName==''|| $scope.editTranformName==null){
		showErrorMessage("Name cannot be empty.");
		return false;
	}
	if($scope.editTranformName.length>255){
		showErrorMessage("Name length cannot be more than 255 characters");
		return false;
	}
	
	if($scope.editTransformTextarea=='' || $scope.editTransformTextarea==null){
		showErrorMessage("Transform cannot be empty.");
		return false;
	}
	$scope.transformController.id=$scope.editTransformid;
	$scope.transformController.createdby=$scope.editTransformcreatedBy;
	//$scope.transformController.createddate=$scope.editTransformcreatedDate;
	
	$scope.transformController.name=$scope.editTranformName.trim();
	$scope.transformController.transform=$scope.editTransformTextarea.trim();
	
		dataTransformsService.editSaveTransform($scope.transformController).success(function(result){	
			if(result.message == 'Success'){
				$scope.closeeditTransformpopup();
				dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
				     $scope.newTransformList=result;
				     if($scope.newTransformList.length>0)
				      $scope.totalRecords=$scope.newTransformList[0].totalsize;
				     else
				      $scope.totalRecords=0;
				}).error(function(result)
				{	showConfigurationErrorMessage(result);
					$scope.newTransformList=[];
				});
			}else{
				showConfigurationErrorMessage(result);
			}
	}).error(function(result){
		showConfigurationErrorMessage(result);
	});

}


$scope.$on('sortByTransformeditor',function(e){

	if($rootScope.adminModule.sortby == 'name'){
	    $scope.sortByValue=$rootScope.adminModule.sortby;
	  
	
	if($rootScope.adminModule.sortorder=='true'){
		$scope.searchTransformList.sortorder="DESC";
		$scope.searchTransformList.sortby ="name";
		
		
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result)
			{
				showConfigurationErrorMessage(result);
				$scope.newTransformList=[];
			});
		
	}else{
		$scope.searchTransformList.sortby ="name";
		$scope.searchTransformList.sortorder="ASC";
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result)
			{	showConfigurationErrorMessage(result);
				$scope.newTransformList=[];
			});
		
		
	}
	}else if($rootScope.adminModule.sortby == 'createdate'){
		 $scope.sortByValue=$rootScope.adminModule.sortby;
		 
		if($rootScope.adminModule.sortorder=='true'){
			$scope.searchTransformList.sortorder="DESC";
			$scope.searchTransformList.sortby ="createdate";
		dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result)
			{
				showConfigurationErrorMessage(result);
				$scope.newTransformList=[];
			});
		
		}else{
			$scope.searchTransformList.sortby ="createdate";
			$scope.searchTransformList.sortorder="ASC";
			dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
			     $scope.newTransformList=result;
			     if($scope.newTransformList.length>0)
			      $scope.totalRecords=$scope.newTransformList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			}).error(function(result)
			{
				showConfigurationErrorMessage(result);
				$scope.newTransformList=[];
			});
			
			
		}
			
		}else if($rootScope.adminModule.sortby == 'lastupdateonstr'){
			 $scope.sortByValue=$rootScope.adminModule.sortby;
			 
				if($rootScope.adminModule.sortorder=='true'){
					$scope.searchTransformList.sortorder="DESC";
					$scope.searchTransformList.sortby ="lastupdateon";
				dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
						 $scope.newTransformList=result;
						 if($scope.newTransformList.length>0)
						  $scope.totalRecords=$scope.newTransformList[0].totalsize;
						 else
						  $scope.totalRecords=0;
					}).error(function(result)
						{
							showConfigurationErrorMessage(result);
							$scope.newTransformList=[];
						});	
					
				}else{
					$scope.searchTransformList.sortby ="lastupdateon";
					$scope.searchTransformList.sortorder="ASC";
					dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
							 $scope.newTransformList=result;
							 if($scope.newTransformList.length>0)
							  $scope.totalRecords=$scope.newTransformList[0].totalsize;
							 else
							  $scope.totalRecords=0;
						}).error(function(result)
						{	showConfigurationErrorMessage(result);
							$scope.newTransformList=[];
						});
					
					
				}
					
				}
		else if($rootScope.adminModule.sortby == 'id' || $rootScope.adminModule.sortby == 'transformid'){
			 $scope.sortByValue=$rootScope.adminModule.sortby;
			 
				if($rootScope.adminModule.sortorder=='true'){
					$scope.searchTransformList.sortorder="DESC";
					$scope.searchTransformList.sortby ="transformid";
					dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
						$scope.newTransformList=result;
						if($scope.newTransformList.length>0)
							$scope.totalRecords=$scope.newTransformList[0].totalsize;
						else
							$scope.totalRecords=0;
					
				}).error(function(result)
					{
					showConfigurationErrorMessage(result);
						$scope.newTransformList=[];
					});
					
				}else{
					$scope.searchTransformList.sortby ="transformid";
					$scope.searchTransformList.sortorder="ASC";
					dataTransformsService.getTransformsForSearchCriteria($scope.searchTransformList).success(function(result){
							 $scope.newTransformList=result;
							 if($scope.newTransformList.length>0)
							  $scope.totalRecords=$scope.newTransformList[0].totalsize;
							 else
							  $scope.totalRecords=0;
						}).error(function(result)
							{   showConfigurationErrorMessage(result);
								$scope.newTransformList=[];
							});
					
					
				}
					
				}
	
});



//Common functions...Nag
////Don't add class .anc-box
	//Close Flyouts
	$('.closebtn').click(function() {
		$('.movinglist, .ans-box,.antc-box, .ancb, .addnewsegment,.addsettings, .aef-box, .cnf-box').hide();
		hideDisableBack();
		
	});
	
	$('.addcampgn').click(function(){
		showDisableBack();
	});
	function closeConfirmMess(message){
	$("#confirm-dialog").dialog("close");
}

function hideDisableBack(){
	$('.l-rightpanel').css({'margin-top': '0px'});
	$('.disableBack').hide();	
	$('.rgt-headerfix').css({position: 'fixed'});
	$('.rgt-headerfix').css("height", "auto");
	$('.rgt-headerfix').css('padding-top',"12px");
	if($('body').scrollLeft() != 0 || $('html').scrollLeft()  > 0 ){
		//$('.rgt-headerfix').css('margin-left',mrgleft);
	} 
}
function showDisableBack(){
	$('.disableBack').show();
	$('.l-rightpanel').css({'margin-top': '-90px'});
	$('.rgt-headerfix').css({position: 'inherit'});
	$('.rgt-headerfix').css('padding-top',"0px");
	$('.rgt-headerfix').css("height", "0px");
	if($('body').scrollLeft() != 0 || $('html').scrollLeft()  > 0 ){
		$('.rgt-headerfix').css('margin-left','0px');
	}	
}
function isIE() {
	if (window.jQuery) {
        return jQuery.browser.msie || false;
    } else {
        // adapted from jQuery's source:
        return navigator.userAgent.toLowerCase().indexOf('msie') >= 0;
    }
}
function getChangedDateForUIUtil(d){
			var fullDate;
			if(d)
			   fullDate=new Date(d);
			else 
			   fullDate=new Date(document.getElementById('curprofiletime').innerHTML.replace('|', ''));
			var twoDigitMonth = ((fullDate.getMonth()+1) > 9)? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
			//var currentDate = twoDigitMonth + "/" + fullDate.getDate() + "/" + fullDate.getFullYear();
			var date=fullDate.getDate();	
			if(date > 9){
				date=date;
			}else{
				date="0"+date;
			}
			var currentDate = fullDate.getFullYear() + "-" +twoDigitMonth + "-" + date;
			return currentDate;
		};
		function dateToNormalStringUtil(d){
			var hh = d.getHours(); 
			var min = d.getMinutes(); 
			var suffix = "AM"; 
			var hours = hh;
			if (min.toString().length == 1) 
				min = "0" + min;        	
					
			var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
			return Datetime;
		};

}]);
zhapp.controller('WorkflowActivityController', ['$rootScope','$scope','$q','dataTransformsService','$filter','$timeout',function($rootScope,$scope,$q,dataTransformsService,$filter,$timeout) {
	$scope.workflowActivityList=[];
	$scope.workflowActivity={};
	$scope.workflowActivity.infoMessage="There are no WorkflowActivity";
	$scope.searchForWorkflowAct='ID';
	$scope.workflowActivity.hubListCriteria={};

	$scope.initCriteria=function(){
		$scope.workflowActivity.hubListCriteria={};
		$scope.workflowActivity.hubListCriteria.pageno=1;
		$scope.workflowActivity.hubListCriteria.pagesize=7;
		$scope.workflowActivity.hubListCriteria.sortorder="DESC";
		$scope.workflowActivity.hubListCriteria.sortby="createdate";
		$scope.workflowActivity.hubListCriteria.departmentId = zhapp.loginUser.departmentID;
		
	}
	
	$scope.init=function(){		 
		$("#headerWorkflowActivity").show();
		$("#listofWorkflowActivity").show();
		$(".mbox-menu").show();
		$(".workflowactivetable").hide();
		$scope.searchFor= [{'key':'Activity ID','value':'Activity Id'},
		                   {'key':'Workflow Name','value':'Workflow Name'},
		                   {'key':'ID','value':'Workflow Id'},
		                   {'key':'Created On','value':'Created Date'},
		                   {'key':'Status','value':'Status'},
		                   {'key':'Started On','value':'Started On'},
                           {'key':'Completed On','value':'Completed On'},
		                   ];
		$scope.statusArray = [ {
		    'key' : 'W',
		    'value' : 'Waiting'
		   }, {
		    'key' : 'E',
		    'value' : 'Errored'
		   }, {
		    'key' : 'F',
		    'value' : 'Failed'
		   }, {
		    'key' : 'I',
		    'value' : 'In Progress'
		   },{
		    'key' : 'R',
		    'value' : 'Restarted'
		   },{
		    'key' : 'S',
		    'value' : 'Stopped'
		   },{
		    'key' : 'B',
		    'value' : 'Blocked'
		   },{
		    'key' : 'C',
		    'value' : 'Completed'
		   },{
    	   'key' :  'U',
    	   'value'  : 'Waiting to retry'	
		   },{
			'key' : 'X',
			'value' : 'Completed'
		   }  ];
		$scope.workflowActivity.searchtext='';
		$scope.initCriteria();
		$scope.loadPageDetails(1);
        var fullDate = new Date();
        //var twoDigitMonth = ((fullDate.getMonth() + 1) > 9) ? (fullDate.getMonth() + 1) : '0' + (fullDate.getMonth() + 1);
        var currentDate =getChangedDateForUIUtil(fullDate);
		$scope.workflowActivity.toDate=currentDate;
		$scope.workflowActivity.fromDate="";
		$scope.loadScheduleEvents();
	};
	
	$scope.$on('workflowactivity', function() {
		$scope.adminModule.sortby = 'createdon';
		$scope.adminModule.sortorder='descending';
        $scope.init();
   });
	
	$scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.workflowActivity.hubListCriteria.sortorder = 'DESC';
		}else{
			$scope.workflowActivity.hubListCriteria.sortorder = 'ASC';
		}
		if($scope.adminModule.sortby == 'createdon'){
			$scope.workflowActivity.hubListCriteria.sortby='createdate';
		}else{
			$scope.workflowActivity.hubListCriteria.sortby=$scope.adminModule.sortby;
		}
		listWorkflowActivityDetails($scope.workflowActivity.hubListCriteria);
    });
	
	$scope.loadPageDetails=function(pageno){
		$scope.workflowActivity.hubListCriteria.pageno=pageno;
		listWorkflowActivityDetails($scope.workflowActivity.hubListCriteria);
	}
	
	function listWorkflowActivityDetails(hubListCriteria){
		$scope.loadScheduleEvents();
		hubListCriteria.departmentId = zhapp.loginUser.departmentID;
		dataTransformsService.getWorkflowActivityForSearchCriteria(hubListCriteria).success(function(result){
			$scope.workflowActivityList=result;
			if($scope.workflowActivityList.length>0)
			{
				$scope.totalRecords=$scope.workflowActivityList[0].totalsize;
			}
			else
			{
				$scope.totalRecords=0;
			}
			
	   }).error(function(result)
	   {
		   showConfigurationErrorMessage(result);
		   $scope.workflowActivityList=[];
	   });
	}
	
	//For Date picker in Creation Date
	$scope.loadScheduleEvents=function(){
			$( ".datepicker" ).datepicker({autoclose:true,format: 'yyyy-mm-dd',todayHighlight:true});       
			$('.timepicker').timepicker({
		        showSeconds: false,
		        showMeridian: false,
		        defaultTime: false,
		        disableFocus: false,
		        minuteStep: 1
		    });
		    $('.cal-icon').click(function(){
				$(this).prev("input").trigger('focus');
			});    
	};
	
	
	$scope.workflowActivity.searchByValue = function(serachValue, event) {
		$scope.adminModule.sortby="createdon";
		$scope.adminModule.sortorder="descending";
		if ((event.type == "click" || event.keyCode == 13)
				&& $scope.workflowActivity.searchtext.length == 0 && ($scope.workflowActivity.fromDate.length==0 || $scope.workflowActivity.toDate.length==0)) {
			if ($scope.searchForWorkflowAct == "Started On") {
				if(($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == "")&&($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == "")){
					showErrorMessage("Please select the FromDate and To Date");
			    	return;
				}else if($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == ""){
					showErrorMessage("Please select the FromDate.");
			    	return;
				}else if($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == ""){
					showErrorMessage("Please select the ToDate.");
			    	return;
				}
			}
			if ($scope.searchForWorkflowAct == "Completed On") {
				if(($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == "")&&($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == "")){
					showErrorMessage("Please select the FromDate and To Date");
			    	return;
				}else if($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == ""){
					showErrorMessage("Please select the FromDate.");
			    	return;
				}else if($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == ""){
					showErrorMessage("Please select the ToDate.");
			    	return;
				}
			}
			if ($scope.searchForWorkflowAct == "Created On") {
				if(($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == "")&&($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == "")){
					showErrorMessage("Please select the FromDate and To Date");
			    	return;
				}else if($scope.workflowActivity.fromDate == undefined || $scope.workflowActivity.fromDate == ""){
					showErrorMessage("Please select the FromDate.");
			    	return;
				}else if($scope.workflowActivity.toDate== undefined || $scope.workflowActivity.toDate == ""){
					showErrorMessage("Please select the ToDate.");
			    	return;
				}
			}
			if ($scope.searchForWorkflowAct == "ID" || $scope.searchForWorkflowAct == "Activity ID" ) {
				if($scope.workflowActivity.searchtext == undefined || $scope.workflowActivity.searchtext== ""){
					showErrorMessage("Enter ID to be searched.");
			    	return;
				}
			}
			if ($scope.searchForWorkflowAct == "Status" || $scope.searchForWorkflowAct == "Workflow Name" ) {
				if($scope.workflowActivity.searchtext == undefined || $scope.workflowActivity.searchtext== ""){
					showErrorMessage("Enter text to be searched.");
			    	return;
				}
			}
			return;
		} else if (event.type == "click"
				|| event.keyCode == 13) {
			$scope.workflowActivity.hubListCriteria = {};
			$scope.workflowActivity.hubListCriteria.pageno = 1;
			$scope.workflowActivity.hubListCriteria.pagesize = 7;
			$scope.workflowActivity.searchtext = serachValue;
			if ($scope.searchForWorkflowAct == "ID" || $scope.searchForWorkflowAct == "Activity ID") {
				if ($scope.workflowActivity.searchtext == 0) {
					showErrorMessage("Enter "+$scope.searchForWorkflowAct+" value more than 0.");
					$scope.workflowActivity.searchtext = '';
					return false;
				}
				if (isNaN($scope.workflowActivity.searchtext)) {
					showErrorMessage("Please enter numeric values only.");
					$scope.workflowActivity.searchtext = '';
					return;
				} else {
					if($scope.searchForWorkflowAct == "ID"){
						$scope.workflowActivity.hubListCriteria.workflowId = $scope.workflowActivity.searchtext;
						//$scope.workflowActivity.hubListCriteria.sortby="workflowId";
					}else if($scope.searchForWorkflowAct == "Activity ID"){
						$scope.workflowActivity.hubListCriteria.id = $scope.workflowActivity.searchtext;
						//$scope.workflowActivity.hubListCriteria.sortby="id";
					}
				}
			} else if ($scope.searchForWorkflowAct == "Workflow Name") {
				$scope.workflowActivity.hubListCriteria.namelike = $scope.workflowActivity.searchtext;
				//$scope.workflowActivity.hubListCriteria.sortby="name";
			} else if ($scope.searchForWorkflowAct == "Started On") {
				$scope.workflowActivity.hubListCriteria.startedFromDate = getFromDateForUIForSearch($scope.workflowActivity.fromDate,"from");
				$scope.workflowActivity.hubListCriteria.startedToDate = getToDateForUIForSearch($scope.workflowActivity.toDate,"to");
				if(getFromDateForUIForSearch($scope.workflowActivity.fromDate) > getToDateForUIForSearch($scope.workflowActivity.toDate)){
			    	showErrorMessage("Please select FromDate lessthan or equal to ToDate.");
			    	return;
			    }
				//$scope.workflowActivity.hubListCriteria.sortby="startedOn";
			} else if ($scope.searchForWorkflowAct == "Completed On") {
				$scope.workflowActivity.hubListCriteria.completedFromDate = getFromDateForUIForSearch($scope.workflowActivity.fromDate,"from");
				$scope.workflowActivity.hubListCriteria.completedToDate = getToDateForUIForSearch($scope.workflowActivity.toDate,"to");
				if(getFromDateForUIForSearch($scope.workflowActivity.fromDate) > getToDateForUIForSearch($scope.workflowActivity.toDate)){
			    	showErrorMessage("Please select FromDate lessthan or equal to ToDate.");
			    	return;
			    }
				//$scope.workflowActivity.hubListCriteria.sortby="completedOn";
			}else if ($scope.searchForWorkflowAct == "Created On") {
				$scope.workflowActivity.hubListCriteria.createdFromDate = getFromDateForUIForSearch($scope.workflowActivity.fromDate,"from");
				$scope.workflowActivity.hubListCriteria.craetedToDate = getToDateForUIForSearch($scope.workflowActivity.toDate,"to");
				if(getFromDateForUIForSearch($scope.workflowActivity.fromDate) > getToDateForUIForSearch($scope.workflowActivity.toDate)){
			    	showErrorMessage("Please select FromDate lessthan or equal to ToDate.");
			    	return;
			    }
				//$scope.workflowActivity.hubListCriteria.sortby="completedOn";
			}else if($scope.searchForWorkflowAct == "Status"){
				var status = $scope.statusArray.filter(function(sta){
					return (sta.value==$scope.workflowActivity.searchtext);
				})
				if(status[0]==undefined){
					showErrorMessage("Please enter valid status.");
					return false;
				}else $scope.workflowActivity.hubListCriteria.status=status[0].key;
				//$scope.workflowActivity.hubListCriteria.sortby="status";
			}
			if($scope.adminModule.sortorder=="descending"){
				$scope.workflowActivity.hubListCriteria.sortorder="DESC";
			}else{
				$scope.workflowActivity.hubListCriteria.sortorder="ASC";
			}
			if($scope.adminModule.sortby == "createdon"){
				$scope.workflowActivity.hubListCriteria.sortby = "createdate";
			}else{
				$scope.workflowActivity.hubListCriteria.sortby=$scope.adminModule.sortby;
			}
			
			listWorkflowActivityDetails($scope.workflowActivity.hubListCriteria);
		}
		if (((event.keyCode == 8 || event.keyCode == 46) && $scope.workflowActivity.searchtext.length == 0)) {
			$scope.init();
		}
	}
	
	
	
	$scope.workflowActivity.getFromDateForUI = function(fromDate,validate){
		var year = fromDate.split('/')[2];
		var month = fromDate.split('/')[0] - 1;
		var  day = fromDate.split('/')[1];
		if(validate) return $scope.dateToNormalString(new Date(year, month, day, 00, 00));
		else return new Date(year, month, day, 00, 00);
	}
	
	$scope.workflowActivity.getToDateForUI = function(toDate,validate){
		var year1 = toDate.split('/')[2];
		var month1 = toDate.split('/')[0] - 1;
		var day1 = toDate.split('/')[1];
	    if(validate) return $scope.dateToNormalString(new Date(year1, month1, day1, 23, 59));
		else  return new Date(year1, month1, day1, 23, 59);
	}
	
	$scope.dateToNormalString=function(d){
	    var hh = d.getHours(); 
	    var min = d.getMinutes(); 
	    var suffix = "AM"; 
	    var hours = hh;
	    if (min.toString().length == 1) 
	        min = "0" + min;         
	    if (hours >= 12) {
	     hours = hh - 12;
	        suffix = "PM";
	    }
	    if (hours == 0) {
	     hours = 12;
	    }
	    var Datetime = (d.getMonth()+1)+"/"+d.getDate()+"/"+d.getFullYear()+" "+hours+":"+min+":"+d.getSeconds()+" "+suffix;         
	    return Datetime;
	};
	
	
	$scope.$on('sortByworkflowactivity',function(e){
		$scope.loadScheduleEvents();
		if($scope.adminModule.sortorder=="false")$scope.workflowActivity.hubListCriteria.sortorder="ASC";
		else $scope.workflowActivity.hubListCriteria.sortorder="DESC";
		 $scope.sortByValue=$scope.adminModule.sortby;
		 if($scope.adminModule.sortby)
			 $scope.workflowActivity.hubListCriteria.sortby=$scope.adminModule.sortby;
		 
		 $scope.workflowActivity.hubListCriteria.departmentId = zhapp.loginUser.departmentID;
		 dataTransformsService.getWorkflowActivityForSearchCriteria($scope.workflowActivity.hubListCriteria).success(function(result){
			$scope.workflowActivityList=result;
			if($scope.workflowActivityList.length>0)
			{
				$scope.totalRecords=$scope.workflowActivityList[0].totalsize;
			}
			else
			{
				$scope.totalRecords=0;
			}
			
	   }).error(function(result)
	   {	showConfigurationErrorMessage(result);
		   $scope.workflowActivityList=[];
	   });
		
	});
	
	
	$scope.initializeActivityPopup = function(){
		var opt = {
				autoOpen: false,
	            resizable: false,
	            draggable: false,
	            modal: true,
	            autoReposition: true,
	            closeOnEscape: false,
		        width: 750,
		        title: 'Steps'
			};
		var temp = $(".workflowactivitytransform-popup.ui-dialog-content").length;
		if(temp > 0){
			var clength = $(".workflowactivitytransform-popup").length;
			while( clength > 1){
				$($(".workflowactivitytransform-popup")[clength-1]).dialog('destroy').remove();
				clength--;
			}
		}
		$(".workflowactivitytransform-popup").dialog(opt);
	
	}
	
	$scope.viewTransformpopup=function(){
		$('.workflowactivetable').show();
		$('.buttons').show();
	    $(".workflowactivitytransform-popup").dialog("open");
		//$( ".workflowactivitytransform-popup" ).dialog( "open" );	
	}

	$scope.cancelViewTransform=function(){
    	$( ".workflowactivitytransform-popup" ).dialog( "close" );
}
	$scope.changeStatusText = function(activity)
		{
			if(activity.status=="W")activity.status="Waiting";
					else if(activity.status=="B")activity.status="Blocked";
					else if(activity.status=="E")activity.status="Errored";
					else if(activity.status=="F")activity.status="Failed";
					else if(activity.status=="I")activity.status="In Progress";
					else if(activity.status=="C")activity.status="Completed";
					else if(activity.status=="R")activity.status="Restarted";
					else if(activity.status=="S")activity.status="Stopped";
					else if(activity.status=="U")activity.status="Waiting to retry";
					else if(activity.status=="X")activity.status="Expired";
		}
	//activityTransform
	
	$scope.activityTransform=function(workflowid,activityId){
	    dataTransformsService.getWorkFlowById(workflowid, activityId).success(function(result) {
	        
			var array = result.mappingstep;
			$scope.workflowactivityTransformsList = [];
			
			angular.forEach(result.listTransformActivities,function(workAct){
					workAct.type ='T';
					workAct.typeText ='Transform';
					$scope.workflowactivityTransformsList.push(workAct);
					
				});
			for (var j = 0; j < array.length; j++) {
				$scope.searchTransformList ={};
				$scope.searchTransformList.id = array[j].stepId;
				if(array[j].type=='W')
				{
					
					dataTransformsService.getWorkflowActivity(array[j].stepId).success(function(WorkflowActivityList){
					WorkflowActivityList[0].type ='W';
					WorkflowActivityList[0].typeText ='Workflow';
					
					WorkflowActivityList[0].name = WorkflowActivityList[0].hubListworkflowEditor.name;
					
					//$scope.changeStatusText(WorkflowActivityList[0]);
					
					$scope.workFlow.workflowactivityTransformsList.push(WorkflowActivityList[0]);
					}).error(function(WorkflowActivityList)
					{
						showConfigurationErrorMessage(result);
						//error
						//No Activities for the workflow
					});
				}
			}
			
	    });
	    $scope.viewTransformpopup();
	}
	
	
	//Reset search based onchange
	$scope.resetSearch = function()
	{
		$scope.workflowActivity.searchtext = '';
		$scope.workflowActivity.hubListCriteria.workflowId = '';
		$scope.workflowActivity.hubListCriteria.id = '';
		$scope.workflowActivity.hubListCriteria.namelike = '';
		$scope.workflowActivity.fromDate = '';
		$scope.workflowActivity.toDate = '';
		$scope.workflowActivity.hubListCriteria.status = '';
		$scope.init();
        /*var fullDate = new Date();
        var twoDigitMonth = ((fullDate.getMonth() + 1) > 9) ? (fullDate.getMonth() + 1) : '0' + (fullDate.getMonth() + 1);
        var currentDate =getChangedDateForUIUtil(fullDate);
		$scope.workflowActivity.toDate=currentDate;
		$scope.workflowActivity.fromDate="";
		 $scope.la.searchCriteria.sortby=$scope.searchBy;*/
	}
	
	$scope.openErrorPopUp=function(msg)
	{		
		showErrorMessage1(msg)
	};	
	function showErrorMessage1(message){
		$("#errormessage")[0].innerHTML=message;
		$("#error-dialog").dialog('option', 'title', 'Errored');
		$("#error-dialog").dialog('open');
	}

	function getSelectedWFActivities() {
		return $filter('uniqueFilter')($scope.workflowActivityList, "id");
	};
	function getChangedDateForUIUtil(d){
			var fullDate;
			if(d)
			   fullDate=new Date(d);
			else 
			   fullDate=new Date(document.getElementById('curprofiletime').innerHTML.replace('|', ''));
			var twoDigitMonth = ((fullDate.getMonth()+1) > 9)? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
			//var currentDate = twoDigitMonth + "/" + fullDate.getDate() + "/" + fullDate.getFullYear();
			var date=fullDate.getDate();	
			if(date > 9){
				date=date;
			}else{
				date="0"+date;
			}
			var currentDate = fullDate.getFullYear() + "-" +twoDigitMonth + "-" + date;
			return currentDate;
		};
		function dateToNormalStringUtil(d){
				var hh = d.getHours(); 
				var min = d.getMinutes(); 
				var suffix = "AM"; 
				var hours = hh;
				if (min.toString().length == 1) 
					min = "0" + min;        	
						
				var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
				return Datetime;
			};
			function getFromDateForUIForSearch(fromDate, validate) {
		var year = fromDate.split('-')[0];
		var month = fromDate.split('-')[1] - 1;
		var day = fromDate.split('-')[2];
		if (validate) 
			return dateToNormalStringUtil(new Date(year, month, day, 00, 00));
		else 
			return new Date(year, month, day, 00, 00);
	}

	function getToDateForUIForSearch(toDate, validate) {
		var year1 = toDate.split('-')[0];
		var month1 = toDate.split('-')[1] - 1;
		var day1 = toDate.split('-')[2];
		if (validate) 
			return dateToNormalStringUtil(new Date(year1, month1, day1, 23, 59));
		else 
			return new Date(year1, month1, day1, 23, 59);
	}
	$scope.workflowActivity.selectAllWFActivities = function() {
		angular.forEach($scope.workflowActivityList, function(activity) {
	        activity.checked = true;
	    });
	}; 

	$scope.workflowActivity.clearWFActivitySelection = function() {
		/*
		var lists = $filter('uniqueFilter')($scope.workflowActivityList, "");
        angular.forEach(lists, function(listDetails) {
            listDetails.checked = false;  
        });
		*/
		angular.forEach($scope.workflowActivityList, function(activity) {
	        activity.checked = false;
	    });
	};

	$scope.workflowActivity.restartWFActivity = function() {
		if(!$scope.workflowActivityList)
			return;
		var checkedActivites=$filter('filter')($scope.workflowActivityList,{checked:true,status:'E'},true);
		if(checkedActivites.length===0)
		{
			showErrorMessage("Please select one errored or failed activity to restart.");
			return;
		}
		if(checkedActivites.length>1)
		{
			showErrorMessage("Only one activity in Errored state can be restarted.");
			return;
		}
		var activity=checkedActivites[0];
		activity.updatedby = zhapp.loginUser.userName;
		dataTransformsService.restartWFActivity(activity).success(function(){
				$scope.workflowActivity.hubListCriteria.workflowId ='';
				$scope.loadPageDetails(1);
				$scope.triggerWorkFlowActivity();
				showInfoMessage("Activity ( "+ activity.hubListworkflowEditor.name +" ) successfully restarted.");
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};

	$scope.workflowActivity.cancelWFActivity = function() {
		if(!$scope.workflowActivityList)
			return;
		var checkedActivites=$filter('filter')($scope.workflowActivityList,function(value){
			return value.checked&&(value.status==='E'||value.status==='F');
		});
		if(checkedActivites.length===0)
			{
			showErrorMessage("Please select one errored or failed activity to cancel.");
			return;
			}
			
		if(checkedActivites.length>1)
			{
			showErrorMessage("Only one activity in Errored/Failed state can be cancelled.");
			return;
			}
			
		var activity=checkedActivites[0];
		activity.updatedby = zhapp.loginUser.userName;
		dataTransformsService.cancelWFActivity(activity).success(function(){
			$scope.loadPageDetails(1);
			$scope.triggerWorkFlowActivity();
			showInfoMessage("Activity ( "+ activity.hubListworkflowEditor.name +" ) successfully cancelled.");
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	$scope.triggerWorkFlowActivity=function(){
		var customerId=zhapp.loginUser.customerID;
		dataTransformsService.triggerWorkFlowActivity(customerId).error(function(){
			showErrorMessage("Couldn't trigger workflow processor.");
		});
	};

	$scope.workflowActivity.refreshWFActivity = function() {
		listWorkflowActivityDetails($scope.workflowActivity.hubListCriteria);
	};
	//Nag
	$scope.init();
}]);
zhapp.controller("WorkflowController",['$rootScope','$scope','$q','dataTransformsService',function($rootScope,$scope,$q,dataTransformsService) {
$scope.fullDate = new Date();
$scope.workFlow={};
$scope.editWorkflow={};
$scope.workFlow.schedule='S';
$scope.workFlow.steprights=[];
$scope.workFlow.triggersteps=[];
$scope.workFlow.selectedSourceSteps=[];
$scope.workFlow.selectedSourceTransformSteps=[];
$scope.workFlow.selectedSourceWorkflowSteps=[];
$scope.workFlow.editschedule='S';
$scope.workFlow.selectedSteps={};
$scope.workFlow.selectedTransformSteps={};
$scope.workFlow.selectedWorkflowSteps={};
$scope.workFlow.radioFrequency = 'O';
$scope.workFlow.listWorkflowEditor={};
$scope.workFlow.listWorkflowEditor.frequency='O';
$scope.workFlow.listWorkflowEditor.schedulesetting='N';
$scope.workFlow.listWorkflowEditor.enablemode='N';
$scope.workFlow.listWorkflowEditor.runmode='N';
$scope.workFlow.listWorkflowEditor.scheduleStartDate='';
$scope.workFlow.listWorkflowEditor.scheduleStartDate='';
$scope.workFlow.listWorkflowEditor.scheduleEndDate='';
$scope.workFlow.listWorkflowEditor.schedulenextdue='';
$scope.workFlow.listWorkflowEditor.includedays=0;
$scope.workFlow.listWorkflowEditor.frquencyunit=0;
$scope.workFlow.listWorkflowEditor.monthlyschdfreq='D';
$scope.workFlow.listWorkflowEditor.dayofeverymonth=0;
$scope.workFlow.listWorkflowEditor.monthlyWeekFreq='F';
$scope.workFlow.listWorkflowEditor.monthlyDayFreq='M';
$scope.workFlow.listWorkflowEditor.timezone='';
$scope.workFlow.listWorkflowEditor.status='W';
$scope.workFlow.mappingstep=[];
$scope.workFlow.listWorkflowEditor.listWorkflowTriggers=[];
$scope.workFlow.listWorkflowEditor.id=0;
$scope.workFlow.hubListCriteria={};
$scope.workFlow.selectWorkFlowItem='I';  
$scope.workFlow.infoMessage='There are no workflows';
$scope.editWorkflow={};
$scope.editWorkflowForCancel=[];
$scope.editWorkflow.listWorkflowTriggers=[];
$scope.workFlow.hubListCriteria.pageno=1;
$scope.workFlow.hubListCriteria.pagesize=7;
$scope.workFlow.hubListCriteria.sortorder="DESC";
$scope.workFlow.sortby='createdate';
$scope.workFlow.orderby='ASC';
$scope.workFlow.erroredMessage="";
$scope.workFlow.createdby = zhapp.loginUser.userName;
$scope.workFlow.updatedby = zhapp.loginUser.userName;
$scope.isWorkflowEditing = 'F';  //To detect for edit workflow
$scope.useWorkflow='';
$scope.workFlow.loggedInUser = zhapp.loginUser.userName;
var tooltiptimeout;

//$scope.workFlow.configure='N';
$scope.$on('workfloweditorschedule', function(e) {
	$scope.loadScheduleEvents();
	if(tooltiptimeout)
	{
		clearTimeout(tooltiptimeout);
	}
	
	});	
	   
$scope.loadScheduleEvents=function(){ 
		   $( ".datepicker" ).datepicker({autoclose:true,showOnFocus:true,format: 'yyyy-mm-dd',todayHighlight:true});       
		   $('.timepicker').timepicker({
		          showSeconds: false,
		          showMeridian: false,
		          defaultTime: false,
		          disableFocus: false,
		          minuteStep: 1
		      });
		    $('.cal-icon').click(function(){
				$(this).prev("input").trigger('focus');
		   }); 
			$('.time-icon').click(function(){
				$(this).prev("input").trigger('focus');
		   });
		  $(".scheduleTimeField").datepicker({autoclose:true,format: 'yyyy-mm-dd',todayHighlight:true});
		   };

$scope.totalRecords=-1;

$scope.weekDays=  	[{'key':'S','value':'Sun'},
                          	 {'key':'M','value':'Mon'},
                          	 {'key':'T','value':'Tue'},
                          	 {'key':'W','value':'Wed'},
                          	 {'key':'H','value':'Thu'},
                          	 {'key':'F','value':'Fri'},
                          	 {'key':'U','value':'Sat'}];   

$scope.workFlow.monthlyWeeks=[{'key':'F','value':'First'},
                             {'key':'S','value':'Second'},
                             {'key':'T','value':'Third'},
                             {'key':'O','value':'Fourth'},
                             {'key':'L','value':'Last'}];
$scope.workFlow.weekDays=  	[{'key':'S','value':'Sun'},
                          	 {'key':'M','value':'Mon'},
                          	 {'key':'T','value':'Tue'},
                          	 {'key':'W','value':'Wed'},
                          	 {'key':'H','value':'Thu'},
                          	 {'key':'F','value':'Fri'},
                          	 {'key':'U','value':'Sat'}];  
 
$scope.workFlowStatusList = [ {
    'key' : 'W',
    'value' : 'Waiting'
   }, {
    'key' : 'B',
    'value' : 'Blocked'
   }, {
    'key' : 'E',
    'value' : 'Errored'
   }, {
    'key' : 'F',
    'value' : 'Failed'
   }, {
    'key' : 'I',
    'value' : 'In Progress'
   },{
    'key' : 'C',
    'value' : 'Completed'
   },{
	 'key' : 'X',
	  'value' : 'Completed'
   }  ];

$scope.statusArray = [ {
    'key' : 'W',
    'value' : 'Waiting'
   }, {
    'key' : 'B',
    'value' : 'Preparing'
   }, {
    'key' : 'E',
    'value' : 'Errored'
   }, {
    'key' : 'F',
    'value' : 'Failed'
   }, {
    'key' : 'I',
    'value' : 'In Progress'
   },{
    'key' : 'C',
    'value' : 'Completed'
   },{
	 'key' : 'X',
	  'value' : 'Completed'
   }  ];
$scope.workFlow.sortBy = [ {
	'key' : 'workflowactivityid',
	'value' : 'Activity ID'
}, {
	'key' : 'status',
	'value' : 'Status'
}, {
	'key' : 'startedOn',
	'value' : 'Started on'
}, {
	'key' : 'completedOn',
	'value' : 'Completed on'
}];

$scope.workFlow.orderBy = [ {
	'key' : 'ASC',
	'value' : 'Ascending'
}, {
	'key' : 'DESC',
	'value' : 'Descending'
} ];
	$scope.preInit = function(){
		$("#headerworkflow").show();
		$("#listOfWorkflow").show();
		$("#addWorkFlowDiv").hide();
		$("#editWorkFlowDiv").hide();
		$(".activitytransform-popup").hide();
		$(".pad20").hide();
		$(".workflowactivity-popup").hide();
		$(".trigger-popup").hide();
		$(".dtw-managesteps").hide();
		$(".workflowactivityError-popup").hide();
		$("#addWorkflow").hide();
		$scope.getBuids();
		$scope.initWorkflow();
		$scope.workFlow.resetOnChange();
		$scope.workFlow.hubListCriteria.pageno=1;
		$scope.workFlow.hubListCriteria.pagesize=7;
		$scope.workFlow.hubListCriteria.sortorder="DESC";
		$scope.workFlow.hubListCriteria.sortby="createdate";
		$scope.timeZoneData=null;
		$scope.workFlow.everyWeekDays=[];
		
		  $scope.workFlow.frequencies= [{'key':'O','value':'Once Later','id':'admin_workflow_Schedule_oncelater'},
		                           {'key':'N','value':'By Minutes','id':'admin_workflow_Schedule_byminutes'},
		                           {'key':'D','value':'Daily','id':'admin_workflow_Schedule_daily'},
		                           {'key':'W','value':'Weekly','id':'admin_workflow_Schedule_weekly'},
		                           {'key':'M','value':'Monthly','id':'admin_workflow_Schedule_monthly'}];
		  $scope.weekDays=  	[{'key':'S','value':'Sun'},
	                          	 {'key':'M','value':'Mon'},
	                          	 {'key':'T','value':'Tue'},
	                          	 {'key':'W','value':'Wed'},
	                          	 {'key':'H','value':'Thu'},
	                          	 {'key':'F','value':'Fri'},
	                          	 {'key':'U','value':'Sat'}];   
		  
		  $scope.homeselect=[{'key':'I','value':'Id'},
		                              {'key':'N','value':'Name'},
		                              {'key':'C','value':'Created Date'},
		                              {'key':'M','value':'Modified Date'}];
		   
		 // loadScheduleEvents();  
		  //$scope.workFlow.hubListCriteria={};
		  $scope.workFlow.searchtext='';
		  $scope.workFlow.searchtextfromdatec='';
		  $scope.workFlow.searchtexttodatec='';
		  $scope.workFlow.searchtextfromdatem='';
		  $scope.workFlow.searchtexttodatem='';
		  $scope.workFlow.hubListCriteria.pageno=1;
			$scope.workFlow.hubListCriteria.pagesize=7;
			if(	$scope.workFlow.hubListCriteria.hasOwnProperty("id")){
			    $scope.workFlow.hubListCriteria.id='';
				$scope.workFlow.hubListCriteria.namelike='';
				$scope.workFlow.hubListCriteria.createdFromDate='';
				$scope.workFlow.hubListCriteria.createdToDate='';
				$scope.workFlow.hubListCriteria.updatedFromdate='';
				$scope.workFlow.hubListCriteria.updatedTodate='';
			}
			$scope.loadScheduleEvents();
	}
	$scope.init=function(){	
		$scope.preInit();
		$scope.loadPageDetails(1);
	};
	$scope.urlRedictInit = function(){
		$scope.preInit();
		var hubListCriteria = {};
		var queryParams = JSON.parse(sessionStorage.getItem('queryParams'));
		hubListCriteria.departmentId = queryParams.departmentId;
		hubListCriteria.id = queryParams.value;
		dataTransformsService.getWorkflowsForSearchCriteria(hubListCriteria).success(function(result){
			if(result.length>0){
				$scope.workFlow.editWorkflow(result[0]);
			}
			sessionStorage.removeItem('queryParams');
		}).error(function(result){
			sessionStorage.removeItem('queryParams');
			showConfigurationErrorMessage(result);
			$scope.workFlow.workflowUIList =[];
		});
	}
	
	$scope.serchRefresh=function(){
		$scope.workFlow.searchtext='';
		$scope.workFlow.hubListCriteria.id='';
		$scope.workFlow.hubListCriteria.namelike='';
		$scope.workFlow.hubListCriteria.id='';
		$scope.workFlow.hubListCriteria.createdFromDate='';
		$scope.workFlow.hubListCriteria.createdToDate='';
		$scope.workFlow.hubListCriteria.updatedFromdate='';
		$scope.workFlow.hubListCriteria.updatedTodate='';
		$scope.loadPageDetails(1);
	}

	$scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.workFlow.hubListCriteria.sortorder = 'DESC';
		}else{
			$scope.workFlow.hubListCriteria.sortorder = 'ASC';
		}
		if($scope.adminModule.sortby == 'createdon'){
			$scope.workFlow.hubListCriteria.sortby='createdate';
		}else{
			$scope.workFlow.hubListCriteria.sortby=$scope.adminModule.sortby;
		}
		listListDetails($scope.workFlow.hubListCriteria);
    });
	
		//PageNation  
		  $scope.loadPageDetails=function(pageno){
			    $scope.workFlow.hubListCriteria.pageno=pageno;
			    listListDetails($scope.workFlow.hubListCriteria);
			   }
			   
			   function listListDetails(hubListCriteria){
			    
			    $scope.workFlow.hubListCriteria.pageno=hubListCriteria.pageno; 
			    $scope.workFlow.hubListCriteria.pagesize=hubListCriteria.pagesize;
			    $scope.workFlow.workflowUIList=new Array();
			    $scope.workFlow.hubListCriteria.departmentId = zhapp.loginUser.departmentID;;
			    dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
			     $scope.workFlow.workflowUIList=result;
			     if($scope.workFlow.workflowUIList.length>0)
			      $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
			     else
			      $scope.totalRecords=0;
			      

				
			   }).error(function(result){
				    showConfigurationErrorMessage(result);
					$scope.workFlow.workflowUIList =[];
			   });
			   }
	
$scope.$on('workfloweditor', function() {
	$scope.adminModule.sortby = 'createdon';
	$scope.adminModule.sortorder='descending';
	$scope.workFlow.hubListCriteria.sortorder="DESC";
	$scope.adminModule.templateSrc = 'datatransforms/templates/workfloweditor.html';
	$scope.adminworkarea='workfloweditorarea';
	$scope.adminModule.adminworkarea='workfloweditor';
    $scope.init();
   });

   
$scope.getBuids=function() {
	
			setRgtHeaderWidth();
			$(window).resize(function(){setRgtHeaderWidth();});
			  	
};
function setRgtHeaderWidth() {
	        if (screen.width >= 1900)
		       $(".l-rightpanel").css("width", "1535px");
	       if (navigator.appName == 'Microsoft Internet Explorer')
		        $("#headerworkflow").width();
	            
	       else
	    	   {
		        $("#headerworkflow").width();
	    	   }
}

$(window).resize(function(){ setRgtHeaderWidth();});

$scope.addWorkflow=function(){
	$scope.isWorkflowEditing = 'F';
	
	
	$scope.timeZoneData=null;
	$scope.workFlow.timezone = '';
	$scope.workFlow.schedule='S';
	var nowDate = new Date();
	$scope.workFlow.startTime = nowDate.getHours()+':'+nowDate.getMinutes();
	$scope.workFlow.startDate=getChangedDateForUIUtil($scope.fullDate);    	
    $scope.workFlow.endDate=getChangedDateForUIUtil($scope.fullDate);
	$scope.initWorkflow();
	$scope.workFlow.resetOnChange();
	$scope.workFlow.listWorkflowEditor={};
	$scope.workFlow.listWorkflowEditor.frequency='O';
	$scope.workFlow.listWorkflowEditor.schedulesetting='N';
	$scope.workFlow.listWorkflowEditor.enablemode='N';
	$scope.workFlow.listWorkflowEditor.runmode='N'
	$scope.workFlow.listWorkflowEditor.scheduleStartDate='';
	$scope.workFlow.listWorkflowEditor.scheduleStartDate='';
	$scope.workFlow.listWorkflowEditor.scheduleEndDate='';
	$scope.workFlow.listWorkflowEditor.schedulenextdue='';
	$scope.workFlow.listWorkflowEditor.includedays=0;
	$scope.workFlow.listWorkflowEditor.frquencyunit=0;
	$scope.workFlow.listWorkflowEditor.monthlyschdfreq='D';
	$scope.workFlow.listWorkflowEditor.dayofeverymonth=0;
	$scope.workFlow.listWorkflowEditor.monthlyWeekFreq='F';
	$scope.workFlow.listWorkflowEditor.monthlyDayFreq='M';
	$scope.workFlow.listWorkflowEditor.timezone='';
	$scope.workFlow.listWorkflowEditor.status='W';
	$scope.workFlow.mappingstep=[];
	$scope.workFlow.listWorkflowEditor.listWorkflowTriggers=[];
	$scope.workFlow.listWorkflowEditor.id=0;
	if($scope.workFlow.configure==undefined || $scope.workFlow.configure==false){
	$scope.workFlow.configure=false;
	}
	if($scope.workFlow.enable==undefined || $scope.workFlow.enable==false){
		$scope.workFlow.enable= false;
	}  
	 $("#headerworkflow").hide();
	 $("#listOfWorkflow").hide();
	 
	 
	 $scope.workflowarea = "addworkflow";
	 $scope.DummyVariable='';
	 $scope.addworkflowTemplateUrl="datatransforms/templates/addworkflow.html";
	 $("#addWorkflow").show();
	 $("#addWorkFlowDiv").show();
	 if($scope.workFlow.schedule==undefined)
	{
	  $scope.workFlow.schedule = 'S';
	}
	$scope.workFlow.scheduleSettingsChange().then(function(messages) {
		$scope.workFlow.timezone = messages;
	});
	if(tooltiptimeout)
	{
		clearTimeout(tooltiptimeout);
	}
}

$scope.workFlow.editWorkflow=function(listworkflow){
	 $("#headerworkflow").hide();
	 $("#listOfWorkflow").hide();
	 $("#addWorkFlowDiv").show();
	 
	 $scope.workflowarea = "addworkflow";
	 $scope.isWorkflowEditing = 'T';
	 $scope.useWorkflow = false;
	 
	 $scope.DummyVariable='Du';
	 
	 var id=listworkflow.id;
	 var createddate = listworkflow.createddate;
	// dataTransformsService.getWorkFlowById(id,0).success(function(result){
		 $scope.workFlow.listWorkflowEditor=listworkflow.listWorkflowEditor;
		 $scope.editWorkflow= listworkflow;
		 $scope.workFlow.schedule = $scope.editWorkflow.schedule;
		 $scope.workFlow.workflowname=$scope.editWorkflow.listWorkflowEditor.name;
		  
		//Nag
		 $scope.workFlow.id = $scope.editWorkflow.id;
		 $scope.workFlow.executeeverymin = $scope.editWorkflow.listWorkflowEditor.frquencyunit;
		
		 $scope.workFlow.listWorkflowEditor.id=$scope.editWorkflow.id;
		 $scope.workFlow.listWorkflowEditor.createdBy=listworkflow.createdby;
		 $scope.workFlow.listWorkflowEditor.updatedBy=listworkflow.updatedby;
		  
		 $scope.workFlow.listWorkflowEditor.createddate=$scope.editWorkflow.createddate;
		 
		if($scope.editWorkflow.listWorkflowEditor.scheduleStartDate==undefined)
		{
			$scope.workFlow.startDate = getChangedDateForUIUtil($scope.fullDate);
		}
		else
		{
			$scope.workFlow.startDate = getChangedDateForUIUtil($scope.editWorkflow.listWorkflowEditor.scheduleStartDate);
		}
		
		 //$scope.workFlow.addedSteps = $scope.editWorkflow.mappingstep;
		 if($scope.editWorkflow.mappingstep.length>0)
		 {
		  for(var j=0;j<$scope.editWorkflow.mappingstep.length;j++){
						var transform = {};//$scope.editWorkflow.mappingstep[j];
						
						transform.stepId = $scope.editWorkflow.mappingstep[j].stepId;
						transform.id = $scope.editWorkflow.mappingstep[j].stepId;
						transform.name = $scope.editWorkflow.mappingstep[j].name;
						if($scope.editWorkflow.mappingstep[j].type==='W')
						{
							transform.typeText = 'Workflow';
							transform.type = 'W';
							transform.imageurl='images/Workflow.png';
							$scope.useWorkflow = true;
							$scope.workFlow.manageStepsWorkflowDisplay();
							
						}
						else if($scope.editWorkflow.mappingstep[j].type==='T')
						{
							
							transform.typeText = 'Transform';
							transform.type = 'T';
							transform.imageurl='images/Transforms.png';
							
						}
						
						
						transform.index = j;
						
						$scope.workFlow.steprights.push(transform);
						//$scope.workFlow.addedSteps.push(transform);
					 
				 }
		  $scope.workFlow.mappingstep = [];
		  if($scope.workFlow.steprights)
			{
			    
				if($scope.workFlow.steprights.length>0)
				{
					for(var i=0;i<$scope.workFlow.steprights.length;i++)
					{
						$scope.workFlow.mappingstep.push($scope.workFlow.steprights[i]);
					}
				}
			}
		   
		 }
		 		 
		 $scope.workFlow.radioFrequency=$scope.editWorkflow.listWorkflowEditor.frequency;
		 $scope.workFlow.timezone=$scope.editWorkflow.listWorkflowEditor.timezone;
		 $scope.workFlow.executeeverymin =	$scope.editWorkflow.listWorkflowEditor.frquencyunit;
		 

		 $scope.workFlow.monthlyschdfreq=$scope.editWorkflow.listWorkflowEditor.monthlyschdfreq;
		 
		 if($scope.editWorkflow.schedule==undefined)
		 {
			 $scope.workFlow.schedule=$scope.editWorkflow.listWorkflowEditor.runmode;
		 }
		 else
		 {
			 $scope.workFlow.schedule=$scope.editWorkflow.schedule;
		 }
		 
		 
		 $scope.workFlow.timezone=$scope.editWorkflow.listWorkflowEditor.timezone;
		 
		 
		 
		 if($scope.workFlow.listWorkflowEditor.frequency==='N'){
			 $scope.workFlow.executeeverymin =	$scope.editWorkflow.listWorkflowEditor.frquencyunit;
		}else if($scope.workFlow.listWorkflowEditor.frequency==='M'){
			if($scope.workFlow.listWorkflowEditor.monthlyschdfreq=='D'){
				$scope.workFlow.listWorkflowEditor.dayofeverymonth=$scope.editWorkflow.listWorkflowEditor.dayofeverymonth;
				$scope.workFlow.dayofeverymonth=$scope.editWorkflow.listWorkflowEditor.dayofeverymonth;
				
			}else{
				$scope.workFlow.listWorkflowEditor.monthlyWeekFreq=$scope.editWorkflow.listWorkflowEditor.monthlyWeekFreq;
				$scope.workFlow.listWorkflowEditor.monthlyDayFreq= $scope.editWorkflow.listWorkflowEditor.monthlyDayFreq;
				$scope.workFlow.monthlyWeekFreq=$scope.editWorkflow.listWorkflowEditor.monthlyWeekFreq;
				$scope.workFlow.monthlyDayFreq= $scope.editWorkflow.listWorkflowEditor.monthlyDayFreq;
			}
		}
		 var checktrue=$scope.editWorkflow.listWorkflowEditor.schedulesetting;
		 var enablechecktrue = $scope.editWorkflow.listWorkflowEditor.enablemode; 
		 if(checktrue == 'Y'){
			 $scope.workFlow.listWorkflowEditor.configure=true;			 
		 }else{
			 $scope.workFlow.listWorkflowEditor.configure=false;
			 $scope.workFlow.listWorkflowEditor.schedule='S';
		 }
		 if(enablechecktrue == 'Y'){
			 $scope.workFlow.listWorkflowEditor.enable=true;
		 }else{
			 $scope.workFlow.listWorkflowEditor.enable=false;
		 } 
		 $scope.workFlow.listWorkflowEditor.enablemode = $scope.editWorkflow.listWorkflowEditor.enablemode;
		    var hours=0;
		    var PM=12;
		    var minutes=0;
		 	 
			 if($scope.editWorkflow.listWorkflowEditor.scheduleStartDate!=null){
					$scope.workFlow.listWorkflowEditor.startDate = getChangedDateForUIUtil($scope.editWorkflow.listWorkflowEditor.scheduleStartDate
					.split(' ')[0]);
					
				}
				if($scope.editWorkflow.listWorkflowEditor.scheduleEndDate!=null){
					$scope.workFlow.listWorkflowEditor.endDate = $scope.editWorkflow.listWorkflowEditor.scheduleEndDate
					.split(' ')[0];
					
					$scope.workFlow.endDate = $scope.editWorkflow.listWorkflowEditor.scheduleEndDate
					.split(' ')[0];
					
				}else{
					$scope.workFlow.listWorkflowEditor.endDate = getChangedDateForUIUtil($scope.fullDate);
					$scope.workFlow.endDate = getChangedDateForUIUtil($scope.fullDate);
				}
				if($scope.editWorkflow.listWorkflowEditor.scheduleStartDate!=null){
				if ($scope.editWorkflow.listWorkflowEditor.scheduleStartDate
						.split(' ')[2] == 'AM') {
					hours = $scope.editWorkflow.listWorkflowEditor.scheduleStartDate
							.split(' ')[1]
							.split(':')[0];
					minutes = $scope.editWorkflow.listWorkflowEditor.scheduleStartDate
							.split(' ')[1]
							.split(':')[1]
				} else {
					hours = $scope.editWorkflow.listWorkflowEditor.scheduleStartDate
							.split(' ')[1]
							.split(':')[0];
					minutes = $scope.editWorkflow.listWorkflowEditor.scheduleStartDate
							.split(' ')[1]
							.split(':')[1];
					/*if (hours != 12) {
						hours = parseInt(
								hours, 10)
								+ parseInt(
										PM,
										10);
					}*/
				}
				
				$scope.workFlow.listWorkflowEditor.startTime = hours
						+ ":" + minutes;
				$scope.workFlow.startTime = hours
						+ ":" + minutes;
				}
		 
		 if($scope.editWorkflow.listWorkflowEditor.includedays>0){
			 $scope.getWeekDays();
		 }
		
	// });
	 
	 $scope.addworkflowTemplateUrl="datatransforms/templates/addworkflow.html"; 
	 $("#addWorkflow").show();
	 $("#addWorkFlowDiv").show();
	 if($scope.workFlow.schedule==undefined /*|| $scope.workFlow.schedule != 'S' || $scope.workFlow.schedule != 'T'*/)
	{
	  $scope.workFlow.schedule = 'S';
	}
	 $scope.workFlow.scheduleSettingsChange();
	 $scope.loadScheduleEvents();
	
}


$scope.canceledittrigger=function(){
	$( ".trigger-popup" ).dialog( "close" );
}
//includedays  getting
$scope.getWeekDays=function(){
	$scope.workFlow.everyWeekDays=[];
	var sum=$scope.editWorkflow.listWorkflowEditor.includedays;
	
	while(sum>0){
		var pow=Math.floor(Math.log(sum)/Math.log(2));
		var sum=sum-Math.pow(2,pow);
		switch(pow){
		  case 0: $scope.workFlow.everyWeekDays.push('S');
				  break;
		  case 1: $scope.workFlow.everyWeekDays.push('M');
				  break;
		  case 2: $scope.workFlow.everyWeekDays.push('T');
  		  		  break;
		  case 3: $scope.workFlow.everyWeekDays.push('W');
  		  		  break;
		  case 4: $scope.workFlow.everyWeekDays.push('H');
  		          break;
		  case 5: $scope.workFlow.everyWeekDays.push('F');
  		  		  break;
		  case 6: $scope.workFlow.everyWeekDays.push('U');
  		  		   break;		  		  		  
		};
	}; 
};

$scope.changeTimezone=function(timezone){
	$scope.workFlow.timezone=timezone;
	if(timezone)
	{
		$scope.workFlow.startTime = moment().tz(timezone).format("HH:mm");
	}
	
}

/* addConfigurepopup */
$scope.workFlow.configurepopup=function(){
    var PM=12;
	//if($scope.DummyVariable!='Du' && $scope.saveSucess!='Yes'){
	  if($scope.workFlow.schedule=='S'){
	      $scope.timeZoneData = zhapp.timeZoneData;
	      if($scope.workFlow.timezone==undefined||$scope.workFlow.timezone=='')
			{
				$scope.workFlow.timezone=$scope.timeZoneData[0].regionid;
			}
	  }
	  
}

$scope.workFlow.editTransformpopup=function(){
	var opt = {
        autoOpen: false,
        modal: true,
        width: 750,
        //height:650,
        title: 'Select Steps'
	};
	var theDialog = $(".dtw-managesteps").dialog(opt);
	theDialog.dialog("open");
}

$scope.workFlow.manageStepsWorkflowDisplay=function()
{
	if($scope.useWorkflow==true)
	{
		$(".workflow-table-workflow").show();
	}
	else
	{
		$(".workflow-table-workflow").hide();
	}

}
/* Managesteppopup */

$scope.workFlow.managestepspopup=function(){
	//$scope.useWorkflow=false;
	$('.dtw-managesteps.ui-dialog-content').dialog('destroy');
	$scope.transformexists = 'T';
	$scope.workflowexists = 'T';
	$scope.workFlow.steprights = [];
	if($scope.workFlow.mappingstep)
	{
		if($scope.workFlow.mappingstep.length>0)
		{
			for(var i=0;i<$scope.workFlow.mappingstep.length;i++)
			{
				$scope.workFlow.steprights.push($scope.workFlow.mappingstep[i]);
			}
		}
	}
	dataTransformsService.getWorkFlowList($scope.workFlow.hubListCriteria).success(function(result){
					     
					     if(result.length>0)
						 {
							$scope.workFlow.workflowsteps = result;
							//if($scope.isWorkflowEditing == 'T')
							//{
								//if($scope.workFlow.id!=undefined && $scope.workFlow.id>0)
								//{
									for(var k=0;k<$scope.workFlow.workflowsteps.length;k++)
									{
										if($scope.isWorkflowEditing == 'T'&& $scope.workFlow.workflowsteps[k].id==$scope.workFlow.id)
											{
												$scope.workFlow.workflowsteps.splice(k,1);
											}
									}
									for(var j=0;j<$scope.workFlow.steprights.length;j++)
									{
										for(var i=0;i<$scope.workFlow.workflowsteps.length;i++)
										{
											if($scope.workFlow.steprights[j].type=='W'&&
												$scope.workFlow.steprights[j].id==$scope.workFlow.workflowsteps[i].id)
											{
												$scope.workFlow.workflowsteps.splice(i,1);
											}
										}
									}
									/*
									for(var i=0;i<$scope.workFlow.workflowsteps.length;i++)
									{
										if($scope.workFlow.workflowsteps[i].id==$scope.workFlow.id)
										{
											$scope.workFlow.workflowsteps.splice(i,1);
										}
										else{
											for(var j=0;j<$scope.workFlow.steprights.length;j++)
										{
											if($scope.workFlow.steprights[j].type=='W'&&
												$scope.workFlow.steprights[j].id==$scope.workFlow.workflowsteps[i].id)
											{
												$scope.workFlow.workflowsteps.splice(i,1);
											}
										}
										}
										
										
										
									}*/
								//}
								
							//}
							
						 }
					      
					     else
					      $scope.workFlow.workflowsteps = $scope.workFlow.workflowUIList;
					    
						//$scope.workFlow.addToolTips();
						//$scope.workflowexists = 'T';
						
					   }).error(function(result)
						{
						    showConfigurationErrorMessage(result);
							$scope.workflowexists = 'F';
						})
						;
	//$scope.workFlow.workflowsteps = $scope.workFlow.workflowUIList;
	//$scope.saveManage='N';
	$scope.workFlow.getTransformsForStep().then(function(messages) {
		$scope.transformexists = messages;
		if($scope.transformexists=='F')
		{
			showErrorMessage("No transforms or workflows are present to configure.");
			return false;
		}
	});
	//$scope.workFlow.addToolTips();
}
$scope.workFlow.getTransformsForStep = function(){
	var deferred = $q.defer();
	dataTransformsService.getTransforms().success(function(result){
		var cur;
		$scope.workFlow.steps = result;
		for(var j=0;j<$scope.workFlow.steprights.length;j++)
		{
			
			for(var i=0;i<result.length;i++)
			{
				if($scope.workFlow.steprights[j].type=='T')
				{
					if($scope.workFlow.steprights[j].id==result[i].id)
					{
						result.splice(i,1);
					}
				}
				
				
			}
		}
		$scope.workFlow.transformsteps = result;
		
		$(".clearfix pad20").show();
		$scope.workFlow.editTransformpopup();
		$scope.workFlow.addToolTips();
		$scope.transformexists = 'T';
		deferred.resolve($scope.transformexists);
	}).error(function(result)
	{
		showConfigurationErrorMessage(result);
		$scope.transformexists = 'F';
		deferred.resolve($scope.transformexists);
	});
	return deferred.promise;
}
/* add ManageSteps */

$scope.workFlow.addManageSteps=function(type){
	var cur;
	
	var steprightIndex=0;
	 
	for (var i = 0; i < $scope.workFlow.steprights.length; i++) {
	        $scope.workFlow.steprights[i].index = steprightIndex;
			steprightIndex++;
	       
	}
	
	if(type=='T')
	{
		for (var i = 0; i < $scope.workFlow.selectedSourceTransformSteps.length; i++) {
	        
			var steprightitem = {};
			steprightitem.id = $scope.workFlow.selectedSourceTransformSteps[i].id;
			steprightitem.name = $scope.workFlow.selectedSourceTransformSteps[i].name;
			steprightitem.type = 'T';
			steprightitem.typeText = 'Transform';
			steprightitem.imageurl='images/Transforms.png';
			steprightitem.index=steprightIndex;
			steprightIndex++;
			$scope.workFlow.steprights.push(steprightitem);
			
	        $scope.workFlow.transformsteps.splice($scope.workFlow.transformsteps.indexOf($scope.workFlow.selectedSourceTransformSteps[i]),1);	        
		}
		$scope.workFlow.selectedSourceTransformSteps=[];
	}
	else if(type=='W')
	{
		for (var i = 0; i < $scope.workFlow.selectedSourceWorkflowSteps.length; i++) {
	        //$scope.workFlow.steprightworkflows.push($scope.workFlow.selectedSourceWorkflowSteps[i]);
			var steprightitem = {};
			steprightitem.id = $scope.workFlow.selectedSourceWorkflowSteps[i].id;
			steprightitem.name = $scope.workFlow.selectedSourceWorkflowSteps[i].listWorkflowEditor.name;
			steprightitem.imageurl='images/Workflow.png';
			//steprightitem.imagetitle='Workflow';
			steprightitem.type = 'W';
			steprightitem.typeText = 'Workflow';
			steprightitem.index=steprightIndex;
			steprightIndex++;
			$scope.workFlow.steprights.push(steprightitem);
			
	        $scope.workFlow.workflowsteps.splice($scope.workFlow.workflowsteps.indexOf($scope.workFlow.selectedSourceWorkflowSteps[i]),1);	        
		}
		$scope.workFlow.selectedSourceWorkflowSteps=[];
	}

	
	
	if($scope.workFlow.selectedSourceSteps.length > 0){
		//$scope.workFlow.changeItems($(".transform-table-workflow select")[1].length, 1, 0);
	}
	
	
	if($scope.workFlow.selectedSourceTransformSteps.length > 0){
		//$scope.workFlow.changeItems($(".transform-table-workflow select"),$(".transform-table-workflow select")[1].length, 1, 0);
		//$scope.workFlow.changeItems($(".table-workflow select")[1].length, 1, 0);
	}
/*
	if($scope.workFlow.selectedSourceWorkflowSteps.length > 0){
		$scope.workFlow.changeItems($(".workflow-table-workflow select"),$(".workflow-table-workflow select")[1].length, 1, 0);
	}
	*/
	
	for(var i=0;i<$scope.workFlow.steprights.length;i++)
	{
		$scope.workFlow.steprights[i].index = i;
		
	}
	$scope.workFlow.selectedSourceSteps=[];
	$scope.workFlow.selectedSourceTransformSteps=[];
	$scope.workFlow.selectedSourceWorkflowSteps=[];
	$scope.workFlow.addToolTips();
}


$scope.workFlow.deleteManageSteps=function(type){
	for (var i = 0; i < $scope.workFlow.selectedSteps.length; i++) {
			
			for(var j=0;j<$scope.workFlow.steprights.length;j++)
			{
				
				if($scope.workFlow.steprights[j].index==$scope.workFlow.selectedSteps[i])
				{
					if(type=='T'&&$scope.workFlow.steprights[j].type=='T')
					{
						$scope.workFlow.transformsteps.push($scope.workFlow.steprights[j]);
						$scope.workFlow.steprights.splice(j,1);

					}
					else if(type=='W'&&$scope.workFlow.steprights[j].type=='W')
					{
						$scope.workFlow.steprights[j].listWorkflowEditor ={};
						$scope.workFlow.steprights[j].listWorkflowEditor.name = $scope.workFlow.steprights[j].name;
						$scope.workFlow.workflowsteps.push($scope.workFlow.steprights[j]);
						$scope.workFlow.steprights.splice(j,1);
					}
					/*if($scope.workFlow.steprights[j].type=='T')
					{
						$scope.workFlow.transformsteps.push($scope.workFlow.steprights[j]);
					}
					
					else if($scope.workFlow.steprights[j].type=='W')
					{
						$scope.workFlow.steprights[j].listWorkflowEditor ={};
						$scope.workFlow.steprights[j].listWorkflowEditor.name = $scope.workFlow.steprights[j].name;
						$scope.workFlow.workflowsteps.push($scope.workFlow.steprights[j]);
					}
					$scope.workFlow.steprights.splice(j,1);
					*/
				}
			}
			
	}
	for(var i=0;i<$scope.workFlow.steprights.length;i++)
	{
		$scope.workFlow.steprights[i].index = i;
		
	}
	$scope.workFlow.selectedSteps=[];
	if(type=='T')
	{
		$scope.workFlow.selectedTransformSteps=[];
	}else if(type=='W')
	{
		$scope.workFlow.selectedWorkflowSteps=[];
	}
	$scope.workFlow.addToolTips();
}

/* trigger Steps */
$scope.workFlow.triggersteps=[];

/* save ManageSteps */
$scope.manageList=[];
$scope.workFlow.addedSteps=[];
$scope.workFlow.saveManageSteps=function(){
	$scope.saveManage='Y';
	$scope.manageList=[];
	$scope.workFlow.mappingstep=[];
	for (var i = 0; i < $scope.workFlow.steprights.length; i++) {
		var hubListTransformWorkflow={};
		$scope.manageList[i]=$scope.workFlow.steprights[i];
		hubListTransformWorkflow.id=$scope.workFlow.steprights[i].id;
		hubListTransformWorkflow.name=$scope.workFlow.steprights[i].name;
		hubListTransformWorkflow.listworkflowid=0;
		hubListTransformWorkflow.type = $scope.workFlow.steprights[i].type;
		hubListTransformWorkflow.stepId = $scope.workFlow.steprights[i].id;
		
		hubListTransformWorkflow.typeText = $scope.workFlow.steprights[i].typeText;
		hubListTransformWorkflow.imageurl=$scope.workFlow.steprights[i].imageurl;
		$scope.workFlow.mappingstep.push(hubListTransformWorkflow);
	}
	$scope.workFlow.addedSteps=$scope.manageList;
	//console.log('MAPPING TRANSFORMS--'+$scope.workFlow.mappingstep);
	$( ".dtw-managesteps" ).hide();
	$( ".dtw-managesteps" ).dialog( "close" );
	$( ".dtw-managesteps" ).dialog( "destroy" );

}


//cancelManageSteps

$scope.cancelManageSteps=function(){
    	$( ".dtw-managesteps" ).hide();
		$( ".dtw-managesteps" ).dialog( "close" ); //"destroy"
		$( ".dtw-managesteps" ).dialog( "destroy" );
}

/* saveWorkFlowEditor */

$scope.workFlow.saveWorkFlowEditor=function(){

	if($scope.workFlow.workflowname == null || $scope.workFlow.workflowname =="" || $scope.workFlow.workflowname == "undefined"){
		showErrorMessage(" Please enter workflow name.");
		return false;
	}	
	if($scope.workFlow.workflowname.length>255){
		showErrorMessage("Workflow name length cannot be more than 255 characters");
		return false;
	}
	if($scope.workFlow.startDate == null || $scope.workFlow.startDate =="" || $scope.workFlow.startDate == undefined){
		showErrorMessage(" Please enter startDate.");
		return false;
	}
	if($scope.workFlow.endDate == null || $scope.workFlow.endDate =="" || $scope.workFlow.endDate == undefined){
		showErrorMessage(" Please enter endDate.");
		return false;
	}
	
	$scope.workFlow.listWorkflowEditor.name = $scope.workFlow.workflowname;
	$scope.workFlow.listWorkflowEditor.status = 'W';
	
	for(var i=0;i< $scope.workFlow.workflowUIList.length;i++){
		if($scope.workFlow.workflowUIList[i].listWorkflowEditor != null )
		  if($scope.workFlow.workflowUIList[i].listWorkflowEditor.name.toUpperCase() === $scope.workFlow.workflowname.toUpperCase() 
			 && $scope.workFlow.id!=$scope.workFlow.workflowUIList[i].id){
		      showErrorMessage("This workflow name already exists, please enter another name.");
		      return false;
		  }
	}
	
	if($scope.workFlow.schedule=='S')
	{
		if($scope.saveSheduledConfig()!=true)
		{
			return;
		}
		$scope.saveSucess='Yes';
		$scope.workFlow.configure =true;
		
	}
	else
	{
		$scope.workFlow.listWorkflowEditor.scheduleStartDate = '';
		$scope.workFlow.listWorkflowEditor.scheduleEndDate = '';
		$scope.workFlow.listWorkflowEditor.schedulenextdue ='';
	}
	if($scope.workFlow.listWorkflowEditor.updatedBy==undefined||$scope.workFlow.listWorkflowEditor.updatedBy=='')
		{
			$scope.workFlow.listWorkflowEditor.updatedBy = zhapp.loginUser.userName;
		}
	if($scope.workFlow.listWorkflowEditor.createdBy==undefined||$scope.workFlow.listWorkflowEditor.createdBy=='')
	{
		$scope.workFlow.listWorkflowEditor.createdBy = zhapp.loginUser.userName;
	}
	
	$scope.workFlow.departmentId=zhapp.loginUser.departmentID;
	
	if(/*$scope.workFlow.configure != true && */$scope.workFlow.mappingstep.length<=0){
		showCommonConfirmMessage("You are attempting to save a partially configured workflow. You will not be able to activate the workflow until it is fully configured. Do you wish to continue??","Alert","Yes","No",450,function(flag){
		if(flag){
			$scope.workFlow.listWorkflowEditor.runmode=$scope.workFlow.schedule;
			var workflowSubmit = '';
			if($scope.isWorkflowEditing == 'F')
				{
					workflowSubmit = dataTransformsService.saveWorkFlowEditor($scope.workFlow);
				}
			else
				{
					workflowSubmit = dataTransformsService.updateWorkFlowEditor($scope.workFlow);
				}

					workflowSubmit.success(function(result){
						if(result.message == 'Success'){
							$scope.adminModule.loadPartialScripts('workfloweditorarea');
						}else{
							showConfigurationErrorMessage(result);
						}
					}).error(function(result){
						showConfigurationErrorMessage(result);
					});	
		     }
		  });
	
		}else if($scope.workFlow.configure != true){
			$scope.workFlow.listWorkflowEditor.schedulesetting='N';
			//showCommonConfirmMessage("You are attempting to save a partially configured transform. You will not be able to activate the transform until it is fully configured. Do you wish to continue??","Alert","Yes","No",450,function(flag){
				//if(flag){
					$scope.workFlow.listWorkflowEditor.runmode=$scope.workFlow.schedule;
					$scope.workFlow.listWorkflowEditor.listHubListtranformEditor=[];
					var workflowSubmit = '';
					if($scope.isWorkflowEditing == 'F')
					{
						workflowSubmit = dataTransformsService.saveWorkFlowEditor($scope.workFlow);
					}
					else
					{
						workflowSubmit = dataTransformsService.updateWorkFlowEditor($scope.workFlow);
					}

					workflowSubmit.success(function(result){
						if(result.message == 'Success'){
							$scope.adminModule.loadPartialScripts('workfloweditorarea');
						}else{
							showConfigurationErrorMessage(result);
						}
				       }).error(function(result){
				    	   showConfigurationErrorMessage(result);
				       });	
				     //}
				  //});
			
		}
		else if($scope.workFlow.configure == true  && $scope.workFlow.mappingstep.length<=0){
				showErrorMessage("Atleast one transform or workflow should be configured.");
				return false;
			}
        else if($scope.workFlow.configure == true){
        	if($scope.workFlow.schedule == 'S' && $scope.saveSucess!='Yes'){
        		showErrorMessage("Please schedule the workflow.");
				return false;
        	}if($scope.workFlow.schedule != 'S' && $scope.workFlow.schedule == 'T' && $scope.workFlow.listWorkflowEditor.listWorkflowTriggers<=0){
        		showErrorMessage("Please configure triggers.");
				return false;
        	}else{
        		$scope.workFlow.listWorkflowEditor.schedulesetting='Y';
        		$scope.workFlow.listWorkflowEditor.frequency=$scope.workFlow.radioFrequency; 
        		$scope.workFlow.listWorkflowEditor.runmode=$scope.workFlow.schedule;
    			
				$scope.workFlow.listWorkflowEditor.runmode=$scope.workFlow.schedule;
    			$scope.workFlow.listWorkflowEditor.listHubListtranformEditor=[];
    			var workflowSubmit = '';
					if($scope.isWorkflowEditing == 'F')
					{
						workflowSubmit = dataTransformsService.saveWorkFlowEditor($scope.workFlow);
					}
					else
					{
						workflowSubmit = dataTransformsService.updateWorkFlowEditor($scope.workFlow);
					}

					workflowSubmit.success(function(result){
						if(result.message == 'Success'){
							$scope.adminModule.loadPartialScripts('workfloweditorarea');
						}else{
							showConfigurationErrorMessage(result);
						}	
				}).error(function(result){
					showConfigurationErrorMessage(result);
				});
        	}
        	
        }
	
        else{
			if($scope.workFlow.configure == true){
				
				$scope.workFlow.listWorkflowEditor.schedulesetting='Y';
			}else{
				$scope.workFlow.listWorkflowEditor.schedulesetting='N';
			}
			$scope.workFlow.listWorkflowEditor.frequency=$scope.workFlow.radioFrequency; 
			
			$scope.workFlow.listWorkflowEditor.runmode=$scope.workFlow.schedule;
			$scope.workFlow.listWorkflowEditor.listHubListtranformEditor=[];
				var workflowSubmit = '';
					if($scope.isWorkflowEditing == 'F')
					{
						workflowSubmit = dataTransformsService.saveWorkFlowEditor($scope.workFlow);
					}
					else
					{
						workflowSubmit = dataTransformsService.updateWorkFlowEditor($scope.workFlow);
					}

					workflowSubmit.success(function(result){
						if(result.message == 'Success'){
							if(tooltiptimeout)
							{
								clearTimeout(tooltiptimeout);
							}
							$scope.adminModule.loadPartialScripts('workfloweditorarea');
						}else{
							showConfigurationErrorMessage(result);
						}
				}).error(function(result){
					showConfigurationErrorMessage(result);
				});                         
					      
        }	
	
}


$scope.initWorkflow=function(){
	$scope.workFlow.workflowname='';
	$scope.workFlow.configure=undefined;
	$scope.workFlow.enable= undefined;
	$scope.workFlow.radioFrequency = 'O';
	$scope.workFlow.listWorkflowEditor.status='W';
	$scope.workFlow.steprights=[];
	$scope.workFlow.addedSteps=[];
	$scope.useWorkflow=false;
	$('.workflow-table-workflow').hide();
	if(tooltiptimeout)
	{
		clearTimeout(tooltiptimeout);
	}
}

/* editWorkFlowEditor */

$scope.workFlow.editWorkFlowEditor=function(){
	
	if($scope.workFlow.editworkflowName == null || $scope.workFlow.editworkflowName ==""){
		showErrorMessage("Please enter name.");
	}
}

/* Enable or Disable workflow */

$scope.workFlow.enableSettingsChange=function(enabled)
{
	var defer = $q.defer();
	$scope.workFlow.listWorkflowEditor.enablemode=undefined;
	$scope.workFlow.listWorkflowEditor.enablemode=enabled;
	if(enabled == 'N' && $scope.workFlow.listWorkflowEditor.workFlowId!=undefined){
		var defer = $q.defer();
		   dataTransformsService.getIsUsedInList($scope.workFlow.listWorkflowEditor.workFlowId).success(function(result){
			  var resp=result;
			     if(resp != 0){
			  $scope.workFlow.listWorkflowEditor.enablemode='Y';
			showErrorMessage($scope.workFlow.workflowname +" WorkFlow is associated with Files");
			defer.resolve();
		}else
			$scope.workFlow.listWorkflowEditor.enablemode=enabled;
			      
  }).error(function(error){
		showErrorMessage(getErrorMessage(error));
			defer.reject();
		});
		   return defer.promise;
	}
	return defer.promise;
}

/* schedule */
$scope.workFlow.scheduleSettingsChange=function()
{
	var defer = $q.defer();
	if($scope.workFlow.schedule=='S')
	{
		$(".workFlowScheduleField").show();
		
		$scope.timeZoneData = zhapp.timeZoneData;

		if($scope.isWorkflowEditing == 'F'||$scope.workFlow.timezone==undefined||$scope.workFlow.timezone=='')
		{
			if(zhapp.loginUser.timeZone)
			{
				$scope.workFlow.timezone=zhapp.loginUser.timeZone;
			}
			else
			{
				$scope.workFlow.timezone=$scope.timeZoneData[0].regionid;
			}
			$scope.workFlow.startTime = moment().tz($scope.workFlow.timezone).format("HH:mm");
			
		}
		defer.resolve($scope.workFlow.timezone);
	
			if($scope.workFlow.startTime==undefined)
			{
				$scope.workFlow.startTime='0:00';
			}
			
	}
	else
	{
		$(".workFlowScheduleField").hide();
	}
	return defer.promise;

}
	  $scope.workFlow.resetOnChange=function(){ 
	  		var PM=12;   
			
	    	var currentDate = getChangedDateForUIUtil($scope.fullDate);
	    	
	    	$scope.workFlow.endproperty='N';        	
	    	$scope.workFlow.endafterval=0;
	        $scope.workFlow.executeeverymin=0;
	        $scope.workFlow.everyWeekDays=[];            
	        $scope.workFlow.monthlyschdfreq='D'
	        $scope.workFlow.monthlyWeekFreq='F';
	        $scope.workFlow.monthlyDayFreq='M';
	        $scope.workFlow.dayofeverymonth=0;
	        
	    };
	    
	    $scope.workFlow.dateToNormalString=function(d){
	    	var hh = d.getHours(); 
        	var min = d.getMinutes(); 
        	var suffix = "AM"; 
        	var hours = hh;
        	if (min.toString().length == 1) 
        	    min = "0" + min;        	
        	/*if (hours >= 12) {
        		hours = hh - 12;
        	    suffix = "PM";
        	}
        	if (hours == 0) {
        		hours = 12;
        	}*/
        	//var Datetime = (d.getMonth()+1)+"/"+d.getDate()+"/"+d.getFullYear()+" "+hours+":"+min+":"+d.getSeconds()+" "+suffix;        	
        	var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
            return Datetime;
	    };
	    
	    $scope.workFlow.getChangedDateForUI=function(d){
	    	var fullDate;
	    	if(d)
	    	   fullDate=new Date(d);
	    	else 
	    		fullDate=new Date();
			var twoDigitMonth = ((fullDate.getMonth()+1) > 9)? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
			//var currentDate = twoDigitMonth + "/" + fullDate.getDate() + "/" + fullDate.getFullYear();	
            var currentDate = fullDate.getFullYear() + "-" +twoDigitMonth + "-" + fullDate.getDate();
			return currentDate;
	    };
	    
	    $scope.getChangedDateForUI=function(d){
	    	var fullDate;
	    	if(d)
	    	   fullDate=new Date(d);
	    	else 
	    		fullDate=new Date();
			var twoDigitMonth = ((fullDate.getMonth()+1) > 9)? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
    		//var currentDate = twoDigitMonth + "/" + fullDate.getDate() + "/" + fullDate.getFullYear();	
            var currentDate = fullDate.getFullYear() + "-" +twoDigitMonth + "-" + fullDate.getDate();
			return currentDate;
	    };
	    
	    $scope.stopEventPropagation=function(){
			var evt = window.event;
			if (evt.stopPropagation)    evt.stopPropagation();
			if (evt.cancelBubble!=null) evt.cancelBubble = true;
		};
		$scope.workFlow.resetOnEndPropertyChange=function(){
	    	var currentDate = getChangedDateForUIUtil($scope.fullDate);    			        	    
	        $scope.workFlow.endDate=currentDate;
	        $scope.workFlow.endafterval=0;           
	    };
	    $scope.workFlow.resetOnMonthPropertyChange=function(){
	    	$scope.workFlow.monthlyWeekFreq='F';
	        $scope.workFlow.monthlyDayFreq='M';
	        $scope.workFlow.dayofeverymonth=0;
	    };
	    $scope.addOrRemoveWeekDays=function(weekDay){        	
	    	var index=$scope.workFlow.everyWeekDays.indexOf(weekDay);
	    	if(index === -1)
	    		$scope.workFlow.everyWeekDays.push(weekDay);
	    	else if(index>=0)
	    		$scope.workFlow.everyWeekDays.splice(index,1);          	
	    };
	    
	    ///saveSheduledConfig
	    
	    $scope.saveSheduledConfig=function(){
	    	
	    	if($scope.workFlow.steprights.length<=0||$scope.workFlow.mappingstep.length<=0)
			{
				showErrorMessage("Atleast one transform or workflow should be configured.");
				return false;
			}
			$scope.workFlow.listWorkflowEditor.frequency=$scope.workFlow.radioFrequency;
	    	if($scope.workFlow.radioFrequency==='N' && $scope.workFlow.executeeverymin==='')
	    	{
	    		showErrorMessage("Please provide all required fields in schedule minutes.");
	    		return;
	    	}
	    	else if($scope.workFlow.radioFrequency==='N' && $scope.workFlow.executeeverymin==0)
	    	{
	    		showErrorMessage("Value must be greater than 0.");
	    		return;
	    	}
	    	else if($scope.workFlow.radioFrequency==='W' && $scope.workFlow.everyWeekDays.length==	0)
	    	{        	
	    		showErrorMessage("Please select atleast one week day.");
	    		return;        		
	    	}
	    	else if($scope.workFlow.radioFrequency==='M' && $scope.workFlow.monthlyschdfreq=='D' && $scope.workFlow.dayofeverymonth==='')
	    	{        	
	    		showErrorMessage("Please provide all required fields in schedule months.");
	    		return;        		
	    	}
	    	else if($scope.workFlow.radioFrequency==='M' && $scope.workFlow.monthlyschdfreq==='D' && !($scope.workFlow.dayofeverymonth<=31 && $scope.workFlow.dayofeverymonth>=1))
	    	{        	
	    		showErrorMessage("Day interval must be between 1 to 31.");
	    		return;        		
	    	}
	    	
	    	if($scope.workFlow.radioFrequency==='O')
	    		$scope.workFlow.endproperty='N';
	    	
	    	if($scope.workFlow.endproperty==='A' && $scope.workFlow.endafterval==='')
	    	{        	
	    		showErrorMessage("Please provide all required fields.");
	    		return;        		
	    	}
	    	else if($scope.workFlow.endproperty==='A' && $scope.workFlow.endafterval==0)
	    	{        	
	    		showErrorMessage("Value must be greater than 0.");
	    		return;        		
	    	}
	    	else if($scope.workFlow.endproperty==='A' && $scope.workFlow.endafterval>1000)
	    	{        	
	    		showErrorMessage("Occurrences must be between 1 to 1000.");
	    		return;        		
	    	}
	    	if($scope.workFlow.startTime==undefined)
			{
				$scope.workFlow.startTime='0:00';
			}
	    	var hours=$scope.workFlow.startTime.split(':')[0];
	    	var minutes=$scope.workFlow.startTime.split(':')[1];
	    	var year=$scope.workFlow.startDate.split('-')[0];
	    	var month=$scope.workFlow.startDate.split('-')[1]-1;
	    	var day=$scope.workFlow.startDate.split('-')[2];
	    	var executeon=new Date(year, month, day, hours, minutes);
			if(minutes<=0&&hours<=0)
			{
				showErrorMessage("Please provide valid start time.");
	    		return; 
			}
			
			console.log('EXECUTE ON DATE>>>'+executeon+';'+$scope.workFlow.timezone);
			console.log('MOMENT CURRENT TIME IN TIME ZONE>>>'+moment().tz($scope.workFlow.timezone).format());
			var mo = moment(executeon.toString()).format();
			
			if(mo<moment().tz($scope.workFlow.timezone).format())
			{
				showErrorMessage("Start date time must be greater than or equal to current date time.");
	        	return;
			}
	         
	        if($scope.workFlow.radioFrequency==='O'){
		        $scope.workFlow.listWorkflowEditor.scheduleStartDate = dateToNormalStringUtil(executeon);
		        $scope.workFlow.listWorkflowEditor.schedulenextdue= dateToNormalStringUtil(executeon);
				$scope.workFlow.listWorkflowEditor.frquencyunit = $scope.workFlow.executeeverymin;
	        }else if($scope.workFlow.radioFrequency==='N'|| $scope.workFlow.radioFrequency==='D' || $scope.workFlow.radioFrequency==='W' || $scope.workFlow.radioFrequency==='M'){
	        	year = $scope.workFlow.endDate.split('-')[0];
		        month = $scope.workFlow.endDate.split('-')[1] - 1;
		        day = $scope.workFlow.endDate.split('-')[2];
		        var endson=new Date(year, month, day, 23, 59);
		        if(endson < executeon){
		        	showErrorMessage("Enddate should be greater than or equal to start date.");
		        	return;
		        }
	        	$scope.workFlow.listWorkflowEditor.scheduleStartDate = dateToNormalStringUtil(executeon);
	        	$scope.workFlow.listWorkflowEditor.scheduleEndDate = dateToNormalStringUtil(endson);
		        $scope.workFlow.listWorkflowEditor.schedulenextdue= dateToNormalStringUtil(executeon);
	        }
	        $scope.workFlow.listWorkflowEditor.includedays=0;
	    	angular.forEach($scope.workFlow.everyWeekDays,function(value,key){
	    		if(value=='S')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+1;
	    		else if(value=='M')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+2;
	    		else if(value=='T')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+4;
	    		else if(value=='W')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+8;
	    		else if(value=='H')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+16;
	    		else if(value=='F')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+32;
	    		else if(value=='U')
	    			$scope.workFlow.listWorkflowEditor.includedays=$scope.workFlow.listWorkflowEditor.includedays+64;
	    	});
	    	if($scope.workFlow.radioFrequency==='N'){
				 $scope.workFlow.listWorkflowEditor.frquencyunit =	$scope.workFlow.executeeverymin;
			}else if($scope.workFlow.radioFrequency==='M'){
				 $scope.workFlow.listWorkflowEditor.monthlyschdfreq=$scope.workFlow.monthlyschdfreq
				if($scope.workFlow.monthlyschdfreq=='D'){
					$scope.workFlow.listWorkflowEditor.dayofeverymonth=$scope.workFlow.dayofeverymonth;
				}else{
					$scope.workFlow.listWorkflowEditor.monthlyWeekFreq=$scope.workFlow.monthlyWeekFreq;
					$scope.workFlow.listWorkflowEditor.monthlyDayFreq= $scope.workFlow.monthlyDayFreq;
				}
			}
	    	$scope.workFlow.listWorkflowEditor.frequency=$scope.workFlow.radioFrequency; 
			$scope.workFlow.listWorkflowEditor.timezone=$scope.workFlow.timezone;
	    	if($scope.workFlow.timezone == null || $scope.workFlow.timezone.trim().length == 0){
	    		showErrorMessage("Please select timeZone.");
	    		return; 
	    	}
	    	return true;
	    };
//cancelScheduleConfig
	    
	    $scope.cancelScheduleConfig=function(){
	    	
	    	$( ".workFlowScheduleField" ).dialog( "close" );
	    }
	    
	    
//workFlow.saveloadTypes
	    function isSearchActive(){
	    	 if($scope.workFlow.searchtext!=null){
	    	  return true;
	    	 }
	    };
	    
	    $scope.workFlow.listRefresh=function(){
	  
	    	$scope.init();
	    }	
	    
	    $scope.workFlow.search=function(event){
	
	    	if($scope.workFlow.selectWorkFlowItem=='I'){
						searchByIdPages(event);		
			}else if($scope.workFlow.selectWorkFlowItem=='N'){
				searchByNamePages(event);
			}else if($scope.workFlow.selectWorkFlowItem=='C'){
				searchByCreationDate(event);
			}else if($scope.workFlow.selectWorkFlowItem=='M'){
				searchByModificationDate(event);
			}
		};
		
		function searchByIdPages(event){
		
			
			 if((event.type=="click" || event.keyCode==13) && $scope.workFlow.searchtext.length==0){	
				 		showErrorMessage("Enter the string to be searched.");	
				 		return;
					
			 }else if(event.type=="click" || event.keyCode==13)		
			 	{
				 if(isNaN($scope.workFlow.searchtext)){
						showErrorMessage("Please enter numeric values only.");
							$scope.workFlow.searchtext='';
							return false;
		    		}
				 
				 if($scope.workFlow.searchtext==0){
						showErrorMessage("Enter id value more than 0.");	
						$scope.workFlow.searchtext='';
						return false;
					}
				 
				    $scope.workFlow.hubListCriteria.id=$scope.workFlow.searchtext;
					
					//dataTransformsService.searchByWorkFlowID($scope.workFlow.hubListCriteria).success(function(result){
					dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						//$scope.totalRecords=$scope.workFlow.workflowUIList.length;
						 
					})
					.error(function(result){
						showConfigurationErrorMessage(result);
						$scope.workFlow.workflowUIList =[];
					});
			}
			
			 if(((event.keyCode==8 || event.keyCode==46)&& $scope.workFlow.searchtext.length==0)){
					$scope.init();
				}
			
		}
		
		function searchByNamePages(event){
			
			 if((event.type=="click" || event.keyCode==13) && $scope.workFlow.searchtext.length==0){
					showErrorMessage("Enter the string to be searched.");	
					return;
			 }else if(event.type=="click" || event.keyCode==13)		
			{
					 $scope.workFlow.hubListCriteria
					 $scope.workFlow.hubListCriteria.pageno=1;
					 $scope.workFlow.hubListCriteria.pagesize=7;
				    $scope.workFlow.hubListCriteria.namelike=$scope.workFlow.searchtext;
					
					dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						//$scope.totalRecords=$scope.workFlow.workflowUIList.length;
						 
					}).error(function(result){
					showConfigurationErrorMessage(result);
					$scope.workFlow.workflowUIList =[];
					});
			}
			 if(((event.keyCode==8 || event.keyCode==46)&& $scope.workFlow.searchtext.length==0)){
					$scope.init();
				}
		
		}
		
		function searchByCreationDate(event){
			if((event.type=="click" || event.keyCode==13) && $scope.workFlow.searchtextfromdatec.length==0 || $scope.workFlow.searchtexttodatec.length==0){
				if(($scope.workFlow.searchtextfromdatec.length==undefined  || $scope.workFlow.searchtextfromdatec.length==0 || $scope.workFlow.searchtextfromdatec.length=="" )&& ($scope.workFlow.searchtexttodatec.length==undefined || $scope.workFlow.searchtexttodatec.length==0 || $scope.workFlow.searchtexttodatec.length=="")){
                    showErrorMessage("Please select fromDate and toDate.");     
                    return;
              }
              else if($scope.workFlow.searchtextfromdatec.length==undefined  ||  $scope.workFlow.searchtextfromdatec.length==0 ||$scope.workFlow.searchtextfromdatec.length==""){
                    showErrorMessage("Please select fromDate.");    
                    return;
              }
              else if($scope.workFlow.searchtexttodatec.length==undefined || $scope.workFlow.searchtexttodatec.length==0 || $scope.workFlow.searchtexttodatec.length==""){
                    showErrorMessage("Please select toDate.");      
                    return;
              } 

		 }else if(event.type=="click" || event.keyCode==13)		
			 {
					year = $scope.workFlow.searchtextfromdatec.split('-')[0];
			        month = $scope.workFlow.searchtextfromdatec.split('-')[1] - 1;
			        day = $scope.workFlow.searchtextfromdatec.split('-')[2];
			        var endson=new Date(year, month, day, 00, 00);
			        $scope.workFlow.hubListCriteria.createdFromDate = dateToNormalStringUtil(endson);
			        
			        year1 = $scope.workFlow.searchtexttodatec.split('-')[0];
			        month1 = $scope.workFlow.searchtexttodatec.split('-')[1] - 1;
			        day1 = $scope.workFlow.searchtexttodatec.split('-')[2];
			        var endson1=new Date(year1, month1, day1, 23, 59);
		        	$scope.workFlow.hubListCriteria.createdToDate = dateToNormalStringUtil(endson1);
		        	if(endson > endson1){
		        		showErrorMessage("Please select fromdate which is less than or equalto todate.");
		        		return;
		        	}
		        	$scope.workFlow.hubListCriteria.pageno=1;
					dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						 
					}).error(function(result){
					showConfigurationErrorMessage(result);
					$scope.workFlow.workflowUIList =[];
					});
					
			 }
			 if(((event.keyCode==8 || event.keyCode==46)&& $scope.workFlow.searchtextfromdatec.length==0 && $scope.workFlow.searchtexttodatec.length==0)){
					$scope.init();
				}
		}
		
		function searchByModificationDate(event){
			if((event.type=="click" || event.keyCode==13) && $scope.workFlow.searchtextfromdatem.length==0 || $scope.workFlow.searchtexttodatem.length==0){
				if(($scope.workFlow.searchtextfromdatem.length==undefined  || $scope.workFlow.searchtextfromdatem.length==0 || $scope.workFlow.searchtextfromdatem.length=="" )&& ($scope.workFlow.searchtexttodatem.length==undefined || $scope.workFlow.searchtexttodatem.length==0 || $scope.workFlow.searchtexttodatem.length=="")){
                    showErrorMessage("Please select fromDate and toDate.");     
                    return;
              }
              else if($scope.workFlow.searchtextfromdatem.length==undefined  ||  $scope.workFlow.searchtextfromdatem.length==0 ||$scope.workFlow.searchtextfromdatem.length==""){
                    showErrorMessage("Please select fromDate.");    
                    return;
              }
              else if($scope.workFlow.searchtexttodatem.length==undefined || $scope.workFlow.searchtexttodatem.length==0 || $scope.workFlow.searchtexttodatem.length==""){
                    showErrorMessage("Please select toDate.");      
                    return;
              } 

		 }else if(event.type=="click" || event.keyCode==13)		
			 {
				year = $scope.workFlow.searchtextfromdatem.split('-')[0];
		        month = $scope.workFlow.searchtextfromdatem.split('-')[1] - 1;
		        day = $scope.workFlow.searchtextfromdatem.split('-')[2];
		        var endson=new Date(year, month, day, 00, 00);
		        $scope.workFlow.hubListCriteria.updatedFromdate = dateToNormalStringUtil(endson);
	        	
	        	year1 = $scope.workFlow.searchtexttodatem.split('-')[0];
		        month1 = $scope.workFlow.searchtexttodatem.split('-')[1] - 1;
		        day1 = $scope.workFlow.searchtexttodatem.split('-')[2];
		        var endson1=new Date(year1, month1, day1, 23, 59);
	        	$scope.workFlow.hubListCriteria.updatedTodate = dateToNormalStringUtil(endson1);
	        	
	        	if(endson > endson1){
	        		showErrorMessage("Please select fromdate which is less than or equalto todate.");
	        		return;
	        	}
	        	$scope.workFlow.hubListCriteria.pageno=1;
				dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						 
					}).error(function(result){
					   showConfigurationErrorMessage(result);
					   $scope.workFlow.workflowUIList =[];
					});
				
		}
			 if(((event.keyCode==8 || event.keyCode==46)&& $scope.workFlow.searchtextfromdatem.length==0 && $scope.workFlow.searchtexttodatem.length==0)){
					$scope.init();
				}
		}
		
		$scope.$on('sortByWorkfloweditor',function(e){
			
			if($scope.adminModule.sortby == 'name'){
			    $scope.sortByValue=$scope.adminModule.sortby;
			
			if($scope.adminModule.sortorder=='true'){
				$scope.workFlow.hubListCriteria.sortorder="DESC";
				$scope.workFlow.hubListCriteria.sortby="name";
				   dataTransformsService.getWorkFlowList($scope.workFlow.hubListCriteria).success(function(result){
					     $scope.workFlow.workflowUIList=result;
					     if($scope.workFlow.workflowUIList.length>0)
					      $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
					     else
					      $scope.totalRecords=0;
					    
					   }).error(function(result){
						    showConfigurationErrorMessage(result);
							$scope.workFlow.workflowUIList =[];
					   });
				
			}else{
				$scope.workFlow.hubListCriteria.sortby="name";
				$scope.workFlow.hubListCriteria.sortorder="ASC";
				dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						//$scope.totalRecords=$scope.workFlow.workflowUIList.length;
						 
					}).error(function(result){
						showConfigurationErrorMessage(result);
						$scope.workFlow.workflowUIList =[];
				   });
				
			}
			}else if($scope.adminModule.sortby == 'id'){
			    $scope.sortByValue=$scope.adminModule.sortby;
				
				if($scope.adminModule.sortorder=='true'){
					$scope.workFlow.hubListCriteria.sortorder="DESC";
					$scope.workFlow.hubListCriteria.sortby="workflowid";
					dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
					}).error(function(result){
						showConfigurationErrorMessage(result);
						$scope.workFlow.workflowUIList =[];
				   });
					
				}else{
					$scope.workFlow.hubListCriteria.sortby="workflowid";
					$scope.workFlow.hubListCriteria.sortorder="ASC";
					dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
					}).error(function(result){
						showConfigurationErrorMessage(result);
						$scope.workFlow.workflowUIList =[];
				   });
					
				}
				}else if($scope.adminModule.sortby == 'createdate'){
				    $scope.sortByValue=$scope.adminModule.sortby;
					
					if($scope.adminModule.sortorder=='true'){
						$scope.workFlow.hubListCriteria.sortorder="DESC";
						$scope.workFlow.hubListCriteria.sortby="createdate";
						dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
					}).error(function(result){
						showConfigurationErrorMessage(result);
						$scope.workFlow.workflowUIList =[];
				   });
						
					}else{
						$scope.workFlow.hubListCriteria.sortby="createdate";
						$scope.workFlow.hubListCriteria.sortorder="ASC";
						dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
						$scope.workFlow.workflowUIList=result;
						if($scope.workFlow.workflowUIList.length>0)
						  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
						 else
						  $scope.totalRecords=0;
						}).error(function(result){
						
							$scope.workFlow.workflowUIList =[];
							showConfigurationErrorMessage(result);
						
					   });
						
					}
					}else if($scope.adminModule.sortby == 'lastupdateonstr'){
					    $scope.sortByValue=$scope.adminModule.sortby;
						
						if($scope.adminModule.sortorder=='true'){
							$scope.workFlow.hubListCriteria.sortorder="DESC";
							$scope.workFlow.hubListCriteria.sortby="updatedate";
							dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
								$scope.workFlow.workflowUIList=result;
								if($scope.workFlow.workflowUIList.length>0)
								  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
								 else
								  $scope.totalRecords=0;
							}).error(function(result){
								$scope.workFlow.workflowUIList =[];
								showConfigurationErrorMessage(result);
						   });
							
							
						}else{
							$scope.workFlow.hubListCriteria.sortby="updatedate";
							$scope.workFlow.hubListCriteria.sortorder="ASC";
							dataTransformsService.getWorkflowsForSearchCriteria($scope.workFlow.hubListCriteria).success(function(result){
								$scope.workFlow.workflowUIList=result;
								if($scope.workFlow.workflowUIList.length>0)
								  $scope.totalRecords=$scope.workFlow.workflowUIList[0].totalsize;
								 else
								  $scope.totalRecords=0;
							}).error(function(result){
								showConfigurationErrorMessage(result);
								$scope.workFlow.workflowUIList =[];
						   });
							
						}
						}
			
		});
		
		
		$scope.workFlow.arrowupManageSteps=function(selectedSteps,selectedRights){
						
		  for (var i = 0; i < $scope.workFlow.selectedSteps.length; i++) {
			
			for(var j=0;j<$scope.workFlow.steprights.length;j++)
			{
				
				if($scope.workFlow.steprights[j].index==$scope.workFlow.selectedSteps[i])
				{
					if(j!=0)
					{
						var temp = $scope.workFlow.steprights[j-1];
						$scope.workFlow.steprights[j-1] = $scope.workFlow.steprights[j];
						$scope.workFlow.steprights[j] = temp;
					}
				}
			}
		}
			for(var i=0;i<$scope.workFlow.steprights.length;i++)
			{
				$scope.workFlow.steprights[i].index = i;
			}
			$scope.workFlow.selectedSteps=[];
		  
		}
		

		//arrowDownManagerSteps
		$scope.workFlow.arrowDownManageSteps=function(){
			
			for(var i=$scope.workFlow.steprights.length-1;i >= 0;i--)
			{
				  for(var j=$scope.workFlow.selectedSteps.length-1;j >= 0;j--)
				  {
				   if(i != $scope.workFlow.steprights.length-1)
				   {
						  if($scope.workFlow.selectedSteps[j] == $scope.workFlow.steprights[i].index) 
						   {
							 var temp = $scope.workFlow.steprights[i];
							 $scope.workFlow.steprights[i]= $scope.workFlow.steprights[i+1];
							 $scope.workFlow.steprights[i+1]=temp;
						   }
					}
				  }
				  
				  
			}
			
			
			for(var i=0;i<$scope.workFlow.steprights.length;i++)
			{
				$scope.workFlow.steprights[i].index = i;
			}
			$scope.workFlow.selectedSteps=[];
		}
		
		/*adding tool tip to select options*/		
		$scope.workFlow.addToolTips=function(){
			
			var sourceSelectTransform = [];
			var sourceSelectWorkflow = [];
			var destinationSelectRight = [];
			sourceSelectTransform = $(".transform-table-workflow select")[0];
			sourceSelectWorkflow = $(".workflow-table-workflow select")[0];
			destinationSelectRight = $(".transform-right-table-workflow select")[0];
			if(sourceSelectTransform!=undefined&&sourceSelectTransform.length >0)
			{
				for(var i=0;i<sourceSelectTransform.length;i++)
				{
					sourceSelectTransform[i].title=sourceSelectTransform[i].text;
				}
			}
			if(sourceSelectWorkflow!=undefined&&sourceSelectWorkflow.length >0)
			{
				for(var i=0;i<sourceSelectWorkflow.length;i++)
				{
					sourceSelectWorkflow[i].title=sourceSelectWorkflow[i].text;
				}
			}
			if(destinationSelectRight!=undefined&&destinationSelectRight.length >0)
				{
					for(var i=0;i<destinationSelectRight.length;i++){
						destinationSelectRight[i].title=destinationSelectRight[i].text;
					}
				}
			tooltiptimeout = setTimeout(function(){
					$scope.workFlow.addToolTips();
				},500);
		};  
		/*change of options source to destination or destination to source.*/
		$scope.workFlow.changeItems=function(previousLength, sourceSelect1, destinationSelect1){
			var sourceSelect = $(".transform-table-workflow select")[sourceSelect1];
			var destinationSelect = $(".transform-table-workflow select")[destinationSelect1];
			if(sourceSelect.length > previousLength){					
				for(var i=0;i<sourceSelect.length;i++){
					sourceSelect[i].title=sourceSelect[i].text;
				}
				for(var i=0;i<destinationSelect.length;i++){
					destinationSelect[i].title=destinationSelect[i].text;
				}
				previousLength = sourceSelect.length;
			}else{
				setTimeout(function(){
					$scope.workFlow.changeItems(previousLength, sourceSelect1, destinationSelect1);
				},500);
			}
		}
	

		//Activity POPup
		$scope.workflowActiveCriteria={};
		$scope.workflowActiveCriteria.sortby='id';
		$scope.openWorkFlowActivity=function(workflowid,workflowName){
			$scope.workFlow.orderby = 'DESC';
			$scope.workFlow.sortby = 'workflowactivityid';
			$scope.workFlow.openActivityUIList = new Array();
			$scope.workFlow.workflowId = workflowid;
			$scope.workFlow.wfName = workflowName;
			$scope.workflowActivitySort(workflowid);
		    //$( ".workflowactivity-popup" ).dialog( "open" );
			$scope.openActivitiespopup();
		}
		
		$scope.initializeWorkflowActivityPopup = function(){
			var opt = {
				  autoOpen: false,
	              resizable: false,
	              draggable: false,
	              modal: true,
	              autoReposition: true,
	              closeOnEscape: false,
				  width: 750,
				  title: 'Workflow Activities'
				};
			var temp = $(".workflowactivity-popup.ui-dialog-content").length;
			if(temp > 0){
				var clength = $(".workflowactivity-popup").length;
				while( clength > 1){
					$($(".workflowactivity-popup")[clength-1]).dialog('destroy').remove();
					clength--;
				}
			}
			$(".workflowactivity-popup").dialog(opt);
		}
		
		
		$scope.openActivitiespopup=function(){
			$(".pad20").show();
			$(".workflowactivity-popup").dialog("open");
					
		}
		$scope.cancelActivityPopup=function(){
			$( ".workflowactivity-popup" ).dialog( "close" );
		}
		//Sorting
		
		$scope.workflowActivitySort=function(workflowId){
			$scope.workflowActiveCriteria.sortby=$scope.workFlow.sortby;
			$scope.workflowActiveCriteria.workflowId=workflowId;
			$scope.workflowActiveCriteria.sortorder=$scope.workFlow.orderby;
			$scope.workFlow.openActivityUIList = [];
		    //dataTransformsService.listWorkflowActivity($scope.workflowActiveCriteria).success(function(result){
			dataTransformsService.getWorkflowActivityForSearchCriteria($scope.workflowActiveCriteria).success(function(result){
		    	$scope.workFlow.openActivityUIList=result;
				
		    	angular.forEach($scope.workFlow.openActivityUIList,function(workAct){
					if(workAct.status=="W")workAct.status="Waiting";
					else if(workAct.status=="B")workAct.status="Blocked";
					else if(workAct.status=="E")workAct.status="Errored";
					else if(workAct.status=="F")workAct.status="Failed";
					else if(workAct.status=="I")workAct.status="In Progress";
					else if(workAct.status=="C")workAct.status="Completed";
					else if(workAct.status=="R")workAct.status="Restarted";
					else if(workAct.status=="S")workAct.status="Stopped";
					else if(workAct.status=="U")workAct.status="Waiting to retry";
					else if(workAct.status=="X")workAct.status="Expired";
					workAct.isViewTransforms='F';
				});
				
		   });
			
		}
		
		//Activity popup style
		$scope.activitytableStyle=function(index){
			  if(index==0 || index%2==0){
			   return {backgroundColor: "rgb(255, 255, 255)"};
			  }else{
			   return {backgroundColor: "rgb(243, 243, 243)"};
			  }
		}
		
		$scope.hideActivities=function(workflowid,activityId){
			angular.forEach($scope.workFlow.openActivityUIList,function(workAct){
					workAct.isViewTransforms='F';
				});
		}
		
		$scope.changeStatusText = function(activity)
		{
			if(activity.status=="W")activity.status="Waiting";
					else if(activity.status=="B")activity.status="Blocked";
					else if(activity.status=="E")activity.status="Errored";
					else if(activity.status=="F")activity.status="Failed";
					else if(activity.status=="I")activity.status="In Progress";
					else if(activity.status=="C")activity.status="Completed";
					else if(activity.status=="R")activity.status="Restarted";
					else if(activity.status=="S")activity.status="Stopped";
					else if(activity.status=="U")activity.status="Waiting to retry";
					else if(activity.status=="X")activity.status="Expired";
		}
		
		$scope.activityTransforms=function(workflowid,activityId){
		dataTransformsService.getWorkFlowById(workflowid, activityId).success(function(result) {
	        var array = result.mappingstep;
			$scope.workFlow.workflowactivityTransformsList = [];
			angular.forEach(result.listTransformActivities,function(workAct){
					workAct.type ='T';
					workAct.typeText ='Transform';
					$scope.changeStatusText(workAct);
					$scope.workFlow.workflowactivityTransformsList.push(workAct);
					
				});
			for (var j = 0; j < array.length; j++) {
				$scope.searchTransformList ={};
				$scope.searchTransformList.id = array[j].stepId;
				if(array[j].type=='W')
				{
					
					dataTransformsService.getWorkflowActivity(array[j].stepId).success(function(WorkflowActivityList){
					WorkflowActivityList[0].type ='W';
					WorkflowActivityList[0].typeText ='Workflow';
					
					WorkflowActivityList[0].name = WorkflowActivityList[0].hubListworkflowEditor.name;
					
					$scope.changeStatusText(WorkflowActivityList[0]);
					
					$scope.workFlow.workflowactivityTransformsList.push(WorkflowActivityList[0]);
					}).error(function(WorkflowActivityList)
					{
						//error
						//No Activities for the workflow
					});
				}
			}
			angular.forEach($scope.workFlow.workflowactivityTransformsList,function(workAct){
				if(workAct.status=="W")workAct.status="Waiting";
					else if(workAct.status=="B")workAct.status="Blocked";
					else if(workAct.status=="E")workAct.status="Errored";
					else if(workAct.status=="F")workAct.status="Failed";
					else if(workAct.status=="I")workAct.status="In Progress";
					else if(workAct.status=="C")workAct.status="Completed";
					else if(workAct.status=="R")workAct.status="Restarted";
					else if(workAct.status=="S")workAct.status="Stopped";
					else if(workAct.status=="U")workAct.status="Waiting to retry";
					else if(workAct.status=="X")workAct.status="Expired";
				
			});
			
			var isDisplay='F';
			angular.forEach($scope.workFlow.openActivityUIList,function(workAct){
					
					if(workAct.id==activityId&&isDisplay=='F')
					{
						workAct.isViewTransforms='T';
						isDisplay ='T';
						
					}
					else
					{
						workAct.isViewTransforms='F';
					}
					
				});
			
			
	    });
	    
	}
		
		//activityClosepopup
		$scope.activityClosepopup =function(){
			$(".activitytransform-popup").dialog("close");
		}
		
		$scope.openErrorPopUp = function(msg){
			$scope.workFlow.erroredMessage=msg;
			showErrorMessage1(msg);
		}
		function showErrorMessage1(message){
			$("#errormessage")[0].innerHTML=message;
			$("#error-dialog").dialog('option', 'title', 'Errored');
			$("#error-dialog").dialog('open');
		}

		$scope.loadJSDefaults=function(param){					  
		   if(!param)
			  setChosemin();	
		};
		
		function getChangedDateForUIUtil(d){
			var fullDate;
			if(d)
			   fullDate=new Date(d);
			else 
			   fullDate=new Date(document.getElementById('curprofiletime').innerHTML.replace('|', ''));
			var twoDigitMonth = ((fullDate.getMonth()+1) > 9)? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
			//var currentDate = twoDigitMonth + "/" + fullDate.getDate() + "/" + fullDate.getFullYear();
			var date=fullDate.getDate();	
			if(date > 9){
				date=date;
			}else{
				date="0"+date;
			}
			var currentDate = fullDate.getFullYear() + "-" +twoDigitMonth + "-" + date;
			return currentDate;
		};
		function dateToNormalStringUtil(d){
			var hh = d.getHours(); 
			var min = d.getMinutes(); 
			var suffix = "AM"; 
			var hours = hh;
			if (min.toString().length == 1) 
				min = "0" + min;        	
					
			var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
			return Datetime;
		};
		function setChosemin(){	
	$('.topctline span').click(function() {
		$('.createcampaign').toggle();	
	});
    $('.tabpages').each(function(){
		var $active, $content, $links = $(this).find('a');
		$active = $links.first().addClass('active');
		$content = $($active.attr('href'));
		$links.not(':first').each(function () {
		$($(this).attr('href')).hide();
	});
	
	$(this).on('click', 'a', function(e){
		$active.removeClass('active');
		$content.hide();
		$active = $(this);
		$content = $($(this).attr('href'));
		$active.addClass('active');
		$content.show();
		e.preventDefault();
		});
	});
    $('.topnav,.campscroll,.vscroll,.scroll, .listSummaryEmailDomain').slimScroll({
		color: '#ccc',
		size: '6px',
		wheelStep:1,
		railVisible: true,
		alwaysVisible: false
	});	
    $("input[type='text'], textarea").attr('spellcheck','false');
}
		if(sessionStorage.getItem('queryParams')){
			$scope.urlRedictInit();
		}else{
	    	// init ...
			$scope.init();	
	    }
		
			
		
  }]);
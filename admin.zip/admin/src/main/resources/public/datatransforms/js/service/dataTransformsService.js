zhapp.factory('dataTransformsService', ['$http', '$rootScope', function($http, $rootScope) {
    return {

        saveTransform: function(transformController) {
			return $http({
                method: 'POST',
                url: '/datatransforms/createTransform',
                data: transformController
                
            });
        },

        listTransforms: function(searchTransformList) {
            return $http({
                method: 'GET',
                url: '/datatransforms/getAllTransforms'
                
            });
        },

        editSaveTransform: function(transformController) {
			return $http({
                method: 'PUT',
                url: '/datatransforms/updateTransform',
                data: transformController
                
            });
        },

        //workFlow editor start

        saveWorkFlowEditor: function(hubListWorkFlow) {
            return $http({
                method: 'POST',
                url: '/datatransforms/createWorkflow',
                data: hubListWorkFlow
            });
        },
		
		updateWorkFlowEditor: function(hubListWorkFlow) {
            return $http({
                method: 'PUT',
                url: '/datatransforms/updateWorkflow',
                data: hubListWorkFlow
            });
        }, 
		/*getTimeZones: function() {
            return $http({
                method: 'GET',
                url: '/datatransforms/getTimeZones'
            });
        },*/

        getTransforms: function() {
            return $http({
                method: 'GET',
                url: '/datatransforms/getAllTransforms'
            });
        },
		getTransformsForSearchCriteria: function(hubListCriteria) {
            return $http({
                method: 'POST',
                url: 'datatransforms/getTransformsForSearchCriteria',
                data: hubListCriteria
                
            });
        },
		getWorkflowActivityForSearchCriteria: function(hubListCriteria) {
            return $http({
                method: 'POST',
                url: 'datatransforms/getWorkflowActivityForSearchCriteria',
                data: hubListCriteria
                
            });
        },
        getWorkFlowList: function(hubListCriteria) {
            return $http({
                method: 'GET',
                url: 'datatransforms/getAllWorkflows'
                
            });
        },
		
		getWorkflowsForSearchCriteria: function(hubListCriteria) {
            return $http({
                method: 'POST',
                url: 'datatransforms/getWorkflowsForSearchCriteria',
                data: hubListCriteria
                
            });
        },

        getWorkFlowById: function(workflowId,activityId) {
            return $http({
                method: 'GET',
                url: '/datatransforms/getWorkflowWithActivities/'+workflowId+'/'+activityId
                
            });
        },
		
		getWorkflowActivity: function(workflowId) {
            return $http({
                method: 'GET',
                url: '/datatransforms/getWorkflowActivity/'+workflowId
                
            });
        },

        restartWFActivity: function(activity) {
            return $http({
                method: 'PUT',
                url: '/datatransforms/restartWorkflowActivity',
                data: activity
            });
        },
        getIsUsedInList: function(workflowId) {
            return $http({
                method: 'GET',
                url: '/datatransforms/getIsUsedInList/'+workflowId
                
            });
        },
        cancelWFActivity: function(activity) {
        	return $http({
                method: 'PUT',
                url: '/datatransforms/cancelWorkflowActivity',
                data: activity
            });
        },
		triggerWorkFlowActivity: function(customerId) {
			return $http({
				method : 'GET',
				url : 'datatransforms/triggerWorkFlowActivity/'+customerId
			});
		},
    }
}]);

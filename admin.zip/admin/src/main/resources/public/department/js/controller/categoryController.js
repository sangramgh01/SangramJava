zhapp.controller("categoryController",['$scope','$filter','departmentService',function($scope,$filter,departmentService) {
	$scope.cat={};
	$scope.cat.categoryType="A";
	$scope.cat.selectAll=false;
	$scope.cat.categoriesList=null;
	$scope.cat.addCategoryName=null;
	$scope.cat.listCategories=function(){
		var listingCriteria={};
		listingCriteria.type=$scope.cat.categoryType;
		listingCriteria.departmentId=$scope.dept.DepartmentBO.departmentID;
		departmentService.listCategories(listingCriteria).success(function(result){
			$scope.cat.categoriesList=result;
			if(isNotNullOrUndefined($scope.cat.categoriesList))
				$scope.cat.categoriesList.splice(0,1);
			$scope.cat.addCategoryName=null;
			$scope.cat.addCategoryDescription=null;
			$scope.cat.selectAll=false;
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.cat.addCategory=function(){
		var category={};
		category.categoryid=0;
		category.departmentid=$scope.dept.DepartmentBO.departmentID;
		category.categorycode=$scope.cat.addCategoryName;
		category.type=$scope.cat.categoryType;
		category.description=$scope.cat.addCategoryDescription;
		if(category.categorycode.toLowerCase() === $scope.dept.DepartmentBO.departmentName.toLowerCase()){
			showErrorMessage("Category name can't be same as department name.");
			return;
		}
		if(category.categorycode.toUpperCase() === "TRASH" ){
			showErrorMessage("Category Name for new category can not be set as Trash.");
			return;
		}
		departmentService.saveCategory(category).success(function(result){
		    result.categorycode=$scope.cat.addCategoryName;
			result.description=$scope.cat.addCategoryDescription;
			$scope.cat.addCategoryName="";
			$scope.cat.addCategoryDescription="";
			$scope.cat.categoriesList.push(result);
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.cat.saveCategory=function(category){
		if(category.categorycode.toUpperCase() ==='TRASH'){
			showErrorMessage("Category Name can not be set as Trash.");
			return;
		}
		category.updateDate=zhapp.getCnvDateTime('DTS',null,null);
		departmentService.saveCategory(category).success(function(){
			category.isEdit=false;
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.cat.clearAllCategories=function(){
		$scope.cat.selectAll=false;
		angular.forEach($scope.cat.categoriesList,function(category){
			category.isSelected=false;
		});
	};
	$scope.cat.selectAllCategories=function(){
		$scope.cat.selectAll=true;
		angular.forEach($scope.cat.categoriesList,function(category){
			category.isSelected=true;
		});
	};
	$scope.cat.selectDeselectAll=function(){
		if($scope.cat.selectAll)
			$scope.cat.selectAllCategories();
		else
			$scope.cat.clearAllCategories();
			
	};
	$scope.cat.deleteCategory=function(category){
		showCommonConfirmMessage("Delete category?", "Confirm", "Yes", "No",400,function(flag){
			if(!flag)
				return;
			departmentService.deleteCategory(category.categoryid).success(function(){
				showInfoMessage("Selected category deleted successfully.");
				$scope.cat.categoriesList=_.without($scope.cat.categoriesList,category);
			}).error(function(responseObj){
				showDepartmentErrorMessage(responseObj);
			});
		});
	};
	$scope.cat.deleteCategories=function(){
		var ids=$filter('filter')($scope.cat.categoriesList,{'isSelected':true},true);
		var categoryIds = _.pluck(ids, 'categoryid');
		if(categoryIds.length === 0)
			showErrorMessage("Please select categories to delete.");
		else{
			showCommonConfirmMessage("Delete category?", "Confirm", "Yes", "No",400,function(flag){
				if(!flag)
					return;
				departmentService.deleteCategories(categoryIds).success(function(){
					showInfoMessage("Selected categories deleted successfully.");
					$scope.cat.categoriesList=_.difference($scope.cat.categoriesList,ids);
				}).error(function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
			});
		}
	};
	$scope.cat.listCategories();
}]);
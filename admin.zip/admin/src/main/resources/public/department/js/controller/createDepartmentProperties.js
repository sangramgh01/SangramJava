zhapp.controller("createDepartmentController",['$rootScope','$scope','$q','$filter','$timeout','departmentService',function($rootScope,$scope,$q,$filter,$timeout,departmentService) {
	$scope.ced={};
	$scope.ced.showDialog=false;
	$scope.ced.resetCreateDeptValues=function(){
		$scope.ced.addDeptName='';
		$scope.ced.deptApprovalNeeded=false;
		$scope.ced.deptDomainKeysNeeded=false;
		$scope.ced.instance=zhapp.loginUser.custCode;
		if($scope.ced.showDialog)
			showDisableBack();
		else
			hideDisableBack();
	};
	
	$scope.ced.createDepartment=function(){
		if(isNullOrUndefined($scope.ced.addDeptName) || $scope.ced.addDeptName.trim().length===0)
		{
			showInfoMessage("Please enter department name.");
			return false;
		}
		var obj={};
		obj.departmentName=$scope.ced.addDeptName;
		obj.approvalNeeded=$scope.ced.deptApprovalNeeded;
		obj.domainKeysNeeded=$scope.ced.deptDomainKeysNeeded;
		departmentService.createDepartment(obj).success(function(result) {
			$filter('filter')(result.departmentSettings,{objectKey:'NOTIFICATIONS'},true)[0].objectValue=JSON.parse('{"notifications": [{"notificationTypeName": "Conversation","isEnabled": false,"defaultEmailAddresses": "","notificationStatuses": [  {"isEnabled": false,"name": "Activated","emailAddresses": ""  },  {"isEnabled": false,"name": "Deactivated","emailAddresses": ""  },  {"isEnabled": false,"name": "Waiting","emailAddresses": ""  },  {"isEnabled": false,"name": "Approved","emailAddresses": ""  },  {"isEnabled": false,"name": "Rejected","emailAddresses": ""  },  {"isEnabled": false,"name": "Ready","emailAddresses": ""  },  {"isEnabled": false,"name": "Executing","emailAddresses": ""  },  {"isEnabled": false,"name": "Completed","emailAddresses": ""  },  {"isEnabled": false,"name": "Errored","emailAddresses": ""  },  {"isEnabled": false,"name": "Skipped","emailAddresses": ""  },  {"isEnabled": false,"name": "Stopped","emailAddresses": ""  }]},{"notificationTypeName": "Files","isEnabled": false,"defaultEmailAddresses": "","notificationStatuses": [  {"isEnabled": false,"name": "Executing","emailAddresses": ""  },  {"isEnabled": false,"name": "Cancelled","emailAddresses": ""  },  {"isEnabled": false,"name": "Completed","emailAddresses": ""  },  {"isEnabled": false,"name": "Errored","emailAddresses": ""  }]},{"notificationTypeName": "Lists","isEnabled": false,"defaultEmailAddresses": "","notificationStatuses": [  {"isEnabled": false,"name": "Executing","emailAddresses": ""  }, {"isEnabled": false,"name": "Completed","emailAddresses": ""  },  {"isEnabled": false,"name": "Errored","emailAddresses": ""  }]},{"notificationTypeName": "Workflows","isEnabled": false,"defaultEmailAddresses": "","notificationStatuses": [  {"isEnabled": false,"name": "Waiting","emailAddresses": ""  },  {"isEnabled": false,"name": "Executing","emailAddresses": ""  },  {"isEnabled": false,"name": "Completed","emailAddresses": ""  },  {"isEnabled": false,"name": "Errored","emailAddresses": ""  },  {"isEnabled": false,"name": "Blocked","emailAddresses": ""  },  {"isEnabled": false,"name": "Retry","emailAddresses": ""  },  {"isEnabled": false,"name": "Cancelled","emailAddresses": ""  }]},{"notificationTypeName": "Reports","isEnabled": false,"defaultEmailAddresses": "", "notificationStatuses": [] }, {"notificationTypeName": "Heatmap Report","isEnabled": false,"defaultEmailAddresses": "", "notificationStatuses": [] }] }');			
			localStorage.DepartmentBO=JSON.stringify(result);
			hideDisableBack();
			$scope.adminModule.loadPartialScripts('editdepartmentarea');
		}).error(function(responseObj) {
			showDepartmentErrorMessage(responseObj);
		});
	 };
}]);
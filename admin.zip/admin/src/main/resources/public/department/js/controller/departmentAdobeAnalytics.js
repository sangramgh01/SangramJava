zhapp.controller("departmentAdobeController",['$scope','$filter','departmentService','$timeout',function($scope,$filter,departmentService,$timeout) {
	$scope.adba={};
	$scope.adba.selectedAttributes=null;
	$scope.adba.adobeAnalyticsBO=null;
	$scope.adba.fileSourcesList=null;
	$scope.adba.unlockLayout=null;
	$scope.adba.days=[15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
	$scope.adba.hours=['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
	$scope.adba.minutes=['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59'];
	$scope.adba.FinalizeMessage="Review the sample header preview above";
	$scope.adba.convertAttributeForDisplay=function(attr){
		switch(attr){
			case 'custname': return 'Customer Name';
			case 'deptname': return 'Department Name';
			case 'schddate': return 'Scheduled Date';
			case 'fromaddr': return 'From Address';
			case 'rplyaddr': return 'Reply To Address';
			default: return '';
		}
	};
	$scope.adba.listFileSources=function(){
		departmentService.listFilesources().success(function(result){
			$scope.adba.fileSourcesList = result;
		}).error(function(error){
			showDepartmentErrorMessage(error);
		});
	};
	$scope.adba.closeAdvanceOptionsPopUp=function(){
		$scope.adba.unlockLayout=null;
		$("#adv-opt-popup").dialog("close");
	};
	$scope.adba.toggleAttributes=function(value){
		var index=$scope.adba.selectedAttributes.indexOf(value);
		if(index > -1)
			$scope.adba.selectedAttributes.splice(index,1);
		else
			$scope.adba.selectedAttributes.push(value);
	};
	$scope.adba.openAdvanceOptionsPopUp=function(){
		$scope.adba.showFinalizeMessage=false;
		$scope.adba.selectedAttributes=angular.copy($scope.adba.adobeAnalyticsBO.attributes||[]);
		$("#adv-opt-popup").dialog("open");
	};
	$scope.adba.finalizeLayout=function(){
		$scope.adba.showFinalizeMessage=true;
		$scope.adba.adobeAnalyticsBO.layoutFinalized=true;
		$scope.adba.adobeAnalyticsBO.attributes=angular.copy($scope.adba.selectedAttributes);
	};
	$scope.adba.addAnalyticsDomain=function(index){
		if(!$scope.adba.adobeAnalyticsBO.adobeAnalyticsTracking && index>=0)
			return false;
		if(!$scope.adba.adobeAnalyticsBO.integratedDomains)
			$scope.adba.adobeAnalyticsBO.integratedDomains=[];
		$scope.adba.adobeAnalyticsBO.integratedDomains.splice(index+1,0,"");
	};
	$scope.adba.deleteAnalyticsDomain=function(index){	
		if(!$scope.adba.adobeAnalyticsBO.adobeAnalyticsTracking)
			return false;
		showCommonConfirmMessage("Are you sure you want to delete the selected domain ?","Confirm","Yes","No",450,$scope.adba.deleteRealAnalyticsDomain,index);
	};
	$scope.adba.deleteRealAnalyticsDomain=function(flag,index){
		if(flag)
		{
			$scope.adba.adobeAnalyticsBO.integratedDomains.splice(index,1);		
			$scope.$apply();
			if($scope.adba.adobeAnalyticsBO.integratedDomains.length===0){
				$scope.adba.addAnalyticsDomain(-1);				
			}			
			$scope.$apply();
		}
	};
	$scope.adba.init=function(){
		$scope.adba.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'ADOBEANALYTICS'},true);
		if($scope.adba.departmentSetting && $scope.adba.departmentSetting.length===1)
			$scope.adba.adobeAnalyticsBO=$scope.adba.departmentSetting[0].objectValue;
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.adba.init();
    });
	$scope.adba.init();
	$scope.adba.listFileSources();
	$scope.adba.uploadNow=function(){
		departmentService.uploadNow($scope.dept.DepartmentBO.departmentID).success(function(){
			departmentService.getDepartmentSpecificProperty($scope.dept.DepartmentBO.departmentID,"ADOBEANALYTICS").success(function(result){
				var adobeAnalyticsBO=result.objectValue;
				$scope.adba.adobeAnalyticsBO.runDetails=adobeAnalyticsBO.runDetails;
			}).error(function(error){
				showDepartmentErrorMessage(error);
			});
		}).error(function(error){
			showDepartmentErrorMessage(error);
		});
	};
	$timeout(initializeAdobeAnalyticsDialogs);
}]);
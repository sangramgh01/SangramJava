zhapp.controller("departmentGAController",['$scope','$filter','departmentService',function($scope,$filter,departmentService) {
	$scope.ga={};
	$scope.ga.googleAnalyticsBO=null;
	$scope.ga.selectedAccount=null;
	$scope.ga.selectedIndex=null;
	$scope.ga.createGADomain=function(){		 
		 var obj={};
		 obj.domainName='';
		 obj.utmCampaign="Campaign Name";
		 obj.utmSource="Category Name";
		 obj.utmContent="Profileid";
		 obj.utmTerm='';		 
		 obj.utmMedium='email';
		 if(!$scope.ga.googleAnalyticsBO.gaDomainsList)
			 $scope.ga.googleAnalyticsBO.gaDomainsList=[];
		 $scope.ga.googleAnalyticsBO.gaDomainsList.push(obj);
	 };
	 $scope.ga.deleteGADomain=function(index){
		 if($scope.ga.googleAnalyticsBO.gaDomainsList[index] && $scope.ga.googleAnalyticsBO.gaDomainsList[index].domainName.trim().length > 0){			
			 var obj={'index':index};
			 showCommonConfirmMessage("Are you sure you want to delete the Domain ?","Confirm","Yes","No",350,$scope.ga.deleteGADomains,obj);
		 }else
		 {
			 $scope.ga.googleAnalyticsBO.gaDomainsList.splice(index,1);
			 if($scope.ga.googleAnalyticsBO.gaDomainsList.length===0)
				 $scope.ga.createGADomain();
		 }
	 };
	 $scope.ga.deleteGADomains=function(flag,obj){
		if(flag){
			$scope.ga.googleAnalyticsBO.gaDomainsList.splice(obj.index,1);		
			if($scope.ga.googleAnalyticsBO.gaDomainsList.length===0)	
				$scope.ga.createGADomain();
			$scope.$apply();
		}
	 };
	 $scope.ga.authoriseGA=function(account,index){
		$scope.ga.selectedAccount=account;
		$scope.ga.selectedIndex=index;
		if(!account.accountID||account.accountID.trim().length===0){
			showErrorMessage("Enter Valid Google Analytics Domain Details.");
			return false;
		}
		else{			
			departmentService.getGAAuthURL().success(function(result){
				$scope.ga.ga_window = window.open(result,'ga_window','scrollbars=yes,menubar=no,height=700,width=950,top=0,left=20,resizable=yes,toolbar=no,location=no,status=no');
			}).error(function(responseObj){
				showDepartmentErrorMessage(responseObj);
			});
		}	
	 };
	 $scope.ga.addGAAccount=function(){
		 if((! $scope.ga.googleAnalyticsBO.gaReportsEnabled) && $scope.ga.googleAnalyticsBO.gaAccountList && $scope.ga.googleAnalyticsBO.gaAccountList.length > 0)
			 return false;
		 var obj={};
		 $scope.ga.googleAnalyticsBO.gaAccountList.push(obj);
	 };
	 $scope.ga.saveGAAccountDetails=function(accessToken) {	           
		 if(isNotNullOrUndefined(accessToken) && accessToken.trim().length>0){			
				var googleAnalyticsObj={};
				googleAnalyticsObj.userName = $scope.ga.selectedAccount.userName;
				googleAnalyticsObj.passWord = $scope.ga.selectedAccount.passWord;
				googleAnalyticsObj.profileName = $scope.ga.selectedAccount.accountName;
				googleAnalyticsObj.accountID = $scope.ga.selectedAccount.accountID;
				googleAnalyticsObj.id = $scope.ga.selectedAccount.id;				
				googleAnalyticsObj.gaAuthorized = false;
				googleAnalyticsObj.accessToken = accessToken;
				googleAnalyticsObj.profilesList = $scope.ga.selectedAccount.profilesList;	
				$scope.ga.ga_window.close();
				departmentService.authorizeGA(googleAnalyticsObj).success(function(result){
					showInfoMessage("Account Authorized.");
					$scope.ga.googleAnalyticsBO.gaAccountList[$scope.ga.selectedIndex]=result;
				}).error(function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
		 }	
	};
	$scope.ga.init=function(){
		$scope.ga.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'GOOGLEANALYTICS'},true);
		if($scope.ga.departmentSetting && $scope.ga.departmentSetting.length===1)
			$scope.ga.googleAnalyticsBO=$scope.ga.departmentSetting[0].objectValue;
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.ga.init();
    });
	$scope.ga.init();
}]);
function saveGAAccountDetails(accessToken) {	
	angular.element("#departmentGA").scope().ga.saveGAAccountDetails(accessToken);
 };
zhapp.controller("departmentHomeController",['$scope','$q','adminListingService','departmentService',function($scope,$q,adminListingService,departmentService) {
	$scope.dept={};
	$scope.dept.currentPageNumber=1;
	$scope.dept.deptList=[];
	$scope.dept.listingCriteria={};
	$scope.dept.listingCriteria.sortUsing='departmentname';
	$scope.dept.listingCriteria.sortBy='ascending';
	$scope.dept.listingCriteria.pageNumber=1;
	$scope.dept.listingCriteria.pageSize=7; 
	$scope.dept.listingCriteria.nameLike;
	$scope.dept.createDepartment = "/department/templates/createDepartment.html";
	$scope.dept.noDepartmentsInfoMessage='There are no departments';
	
	$scope.$on('listingCriteriaChanged', function () {
		if(adminListingService.sortby==='name')
				$scope.dept.listingCriteria.sortUsing='departmentname';
		else if(adminListingService.sortby==='createdon')
				$scope.dept.listingCriteria.sortUsing='createdate';
		else if(adminListingService.sortby==='createdby')
				$scope.dept.listingCriteria.sortUsing='createdby';
		$scope.dept.listingCriteria.sortBy=adminListingService.sortorder;
		$scope.dept.listDepartments();
    });
	
	$scope.dept.listDepartments=function(){
		departmentService.listDepartments($scope.dept.listingCriteria).success(function(result){
			$scope.dept.deptList=result;
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	
	$scope.dept.departmentsTotalCount=function(){
		var deferred = $q.defer();
		departmentService.departmentsTotalCount($scope.dept.listingCriteria).success(function(result){
			$scope.dept.totalRecords=result;
			deferred.resolve();
		}).error(function(){
			deferred.reject('Failed to get departments count.');
		});
		return deferred.promise;
	};
	
	$scope.dept.loadPageDetails=function(pageNumber){
		$scope.dept.listingCriteria.pageNumber=pageNumber;
		$scope.dept.currentPageNumber=pageNumber;
		$scope.dept.listDepartments();
	};
	
	$scope.dept.validateSearchDeptName=function(){
		if($scope.dept.listingCriteria.nameLike==undefined || $scope.dept.listingCriteria.nameLike.length == 0){
			showErrorMessage("Enter the string to be searched.");
		}else{
			$scope.dept.searchByName(1);
		}
	}
	
	$scope.dept.searchByName=function(pageNumber){
		$scope.dept.listingCriteria.pageNumber=pageNumber;
		$scope.dept.currentPageNumber=pageNumber;
		var promise=$scope.dept.departmentsTotalCount();
		promise.then($scope.dept.listDepartments,function(responseObj){ showErrorMessage(responseObj) });
	};
	
	$scope.dept.searchByDeptName=function(event){	
		 if (event.type == "click" || event.keyCode == 13 || ((event.keyCode == 8 || event.keyCode == 46) && ($scope.dept.listingCriteria.nameLike == undefined || $scope.dept.listingCriteria.nameLike == ""))) {
				$scope.dept.searchByName(1);
			} 
	}; 
	
	$scope.dept.deleteDeparmentDialog=function(departmentId){
		showCommonConfirmMessage("Delete department?", "Confirm", "Yes", "No",400,function(flag){
			if(!flag)
				return;
			departmentService.deleteDepartment(departmentId).success(function(){
				$scope.dept.searchByName(1);
			}).error(function(responseObj){
				showDepartmentErrorMessage(responseObj);
			});
		});
	};
	
	$scope.dept.editDepartment=function(departmentID){
		var DepartmentBO={};
		DepartmentBO.departmentID=departmentID;
		localStorage.DepartmentBO=JSON.stringify(DepartmentBO);
		//For moving to edit department.
		$scope.adminModule.loadPartialScripts('editdepartmentarea');
	};
	
	var promise=$scope.dept.departmentsTotalCount();
	promise.then($scope.dept.listDepartments,function(responseObj){ showErrorMessage(responseObj) });
	
	setDeptRgtHeaderWidth();
}]);
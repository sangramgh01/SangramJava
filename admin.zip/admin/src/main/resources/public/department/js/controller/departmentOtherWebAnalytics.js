zhapp.controller("departmentOtherWebAnalyticsController",['$scope','$filter','departmentService',function($scope,$filter,departmentService) {
	$scope.owa={};
	$scope.owa.otherWebAnalyticsBO=null;
	$scope.owa.init=function(){
		$scope.owa.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'OTHERWEBANALYTICS'},true);
		if($scope.owa.departmentSetting && $scope.owa.departmentSetting.length===1){
			$scope.owa.otherWebAnalyticsBO=$scope.owa.departmentSetting[0].objectValue;
			if($scope.owa.otherWebAnalyticsBO.domainsList.length == 0)
				$scope.owa.addEmptyDomain($scope.owa.otherWebAnalyticsBO.domainsList,-1);
		}
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.owa.init();
    });
	$scope.owa.addEmptyDomain=function(variable,index){	
		variable.splice(index+1,0,"");
		variable[index+1]='';
	};
	$scope.owa.removeDomain=function(variable,index){
		variable.splice(index,1);	
		if(variable.length===0)
			$scope.owa.addEmptyDomain(variable,-1);
	}
	$scope.owa.init();
}]);
zhapp.controller("departmentAddressController",['$scope','$filter','departmentService',function($scope,$filter,departmentService) {
	$scope.addressListBO=null;
	$scope.activeTab="configure";
	$scope.categories=[];
	//Assign By
	$scope.myCount=0;
	$scope.addEmptyEmailAddress=function(variable,index,typeOfAddress){	
		if(typeOfAddress=="testAddressesList"){
		if($scope.addEmptyEmailAddressCount > 0){
			if(variable.length != $scope.addEmptyEmailAddressCount){
			variable.splice(index+1,0,"");
			variable[index+1]='';
			}
		}
		else{
			
			if(variable.length !== 10)	{
				 variable.splice(index+1,0,"");
				 variable[index+1]='';
			}
		}
		} //closing typeOfAddress Check
		else{
			variable.splice(index+1,0,"");
			variable[index+1]='';
		}
		
	};
	//Assign By
	
	$scope.loadAllCategories=function(){
		if($scope.dept.DepartmentBO.departmentID===0){
			$scope.categories=[];
			return;
		}
		var listingCriteria={};
		listingCriteria.type='A';
		listingCriteria.departmentId=$scope.dept.DepartmentBO.departmentID;
		departmentService.listCategories(listingCriteria).success(function(result){
			$scope.categories=result;
			if(isNullOrUndefined($scope.categories)){
				$scope.categories=[];
				var obj={};
				obj.label=$scope.dept.DepartmentBO.departmentName;
				obj.categorycode='DEFAULTCATEGORY';
				$scope.categories.push(obj);
			}
			angular.forEach($scope.categories,function(value){
				value.label=value.categorycode;
				if(value.categorycode===$scope.dept.DepartmentBO.departmentName)
					value.categorycode='DEFAULTCATEGORY';
			});
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.removeEmailAddress=function(variable,index){
		variable.splice(index,1);	
		if(variable.length===0)
			$scope.addEmptyEmailAddress(variable,-1);
	}
	
	$scope.changeInCategoryDefault=function(){
		for(var i=0;i<$scope.addressListBO.categoryDefaults.length;i++){
			var value=$scope.addressListBO.categoryDefaults[i];
			if(value.catcode!=='DEFAULTCATEGORY' && value.catcode!==$scope.addressListBO.selectedCatcode)
				continue;
			switch (value.addressType) {
				case 'fromadd_dispname':
					$scope.addressListBO.cat_fromadd_dispname = value.value;
					break;
				case 'fromadd_emails':
					$scope.addressListBO.cat_fromadd_emails = value.value;
					break;
				case 'replytoadd_dispname':
					$scope.addressListBO.cat_replytoadd_dispname = value.value;
					break;
				case 'replytoadd_emails':
					$scope.addressListBO.cat_replytoadd_emails = value.value;
					break;
				case 'returnpath':
					$scope.addressListBO.cat_returnpath = value.value;
					break;
				case 'unsubemails':
					$scope.addressListBO.cat_unsubemails = value.value;
					break;
			}
		}
	};
	$scope.updateLists=function(){
		setTimeout(function(){
			 $('#ddfrom').trigger('liszt:updated');		
			 $('#ddreply').trigger('liszt:updated');
			 $('#ddreturn').trigger('liszt:updated');
			 $('#ddunsubscribe').trigger('liszt:updated'); 
		     $('#cdfrom').trigger('liszt:updated');
			 $('#cdreply').trigger('liszt:updated');
			 $('#cdreturn').trigger('liszt:updated');
			 $('#cdunsubscribe').trigger('liszt:updated'); 
		 },10);	
	};
	$scope.loadAllCategories();
	$scope.init=function(){
		$scope.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'ADDRESSLIST'},true);
		$scope.departmentSettingsParameter=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'PARAMETERS'},true);//Assign By
		if($scope.departmentSetting && $scope.departmentSetting.length===1){
			 $scope.addressListBO=$scope.departmentSetting[0].objectValue;
			 //Assign By
			 if($scope.departmentSettingsParameter && $scope.departmentSettingsParameter.length===1){
			 $scope.PARAMETERSData=$scope.departmentSettingsParameter[0].objectValue;
			 $scope.addEmptyEmailAddressCount=$scope.PARAMETERSData.testMaxEmails; 
			 }
			 else showDepartmentErrorMessage("Error While Retrieving The Count Of Maximum Emails in Test List.Please Try Again");
			 //Assign By
		}
		angular.forEach($scope.addressListBO.departmentDefaults,function(value){
			switch (value.addressType) {
				case 'fromadd_dispname':
					$scope.addressListBO.dept_fromadd_dispname = value.value;
					break;
				case 'fromadd_emails':
					$scope.addressListBO.dept_fromadd_emails = value.value;
					break;
				case 'replytoadd_dispname':
					$scope.addressListBO.dept_replytoadd_dispname = value.value;
					break;
				case 'replytoadd_emails':
					$scope.addressListBO.dept_replytoadd_emails = value.value;
					break;
				case 'returnpath':
					$scope.addressListBO.dept_returnpath = value.value;
					break;
				case 'unsubemails':
					$scope.addressListBO.dept_unsubemails = value.value;
					break;
			}
		});
		$scope.addressListBO.selectedCatcode='DEFAULTCATEGORY';
		$scope.changeInCategoryDefault();
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.init();
    });
	$scope.init();
}]);



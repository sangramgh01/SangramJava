zhapp.controller("departmentAudiencesController",['$scope','$filter','departmentService','$timeout',function($scope,$filter,departmentService,$timeout) {
	$scope.depAud={};
	$scope.depAud.audiencesBO=null;
	$scope.depAud.selDefAudiences = []; //taking selected audiences from dropdown
	$scope.audSearch = {};
	departmentService.selectedAudiences = false;
	
	$scope.depAud.init=function(){
		$scope.depAud.departmentSettings=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'AUDIENCES'},true);
		if($scope.depAud.departmentSettings && $scope.depAud.departmentSettings.length===1)
			$scope.depAud.selDefAudiences = $scope.depAud.departmentSettings[0].objectValue;
		    listAllAudiences();
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.depAud.init();
    });
	$scope.depAud.init();
	
	function initializeAudSlimScroll(){
		$('.user-dept-list-container').slimScroll({
 			color: '#a9a9a9',
 			size: '8px',
 			wheelStep:1,
 			railVisible: true,
 			alwaysVisible: false
 		});	
	};
	
	
	function listAllAudiences(){
		departmentService.getAudiences().success(function(result) {
			if($scope.depAud.selDefAudiences){
				angular.forEach(result,function(obj1){
			    	angular.forEach($scope.depAud.selDefAudiences,function(obj2){
						if((obj1.audienceId == obj2.audienceId) && obj2.checked)
							obj1.checked = 'Y';
						if(obj2.isDefault && (obj2.audienceId == obj1.audienceId)){
							$scope.depAud.selAud = obj2.audienceId;
							obj1.isDefault = true;
						}
					});
				});
		    }
			$scope.depAud.audiencesBO = sortAudienceList(result); //taking all audience for display 
			$scope.depAud.selDefAudiences = $filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);
			$scope.depAud.departmentSettings[0].objectValue =  $filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);;
			if(!$scope.depAud.selDefAudiences || !$scope.depAud.departmentSettings[0].departmentID){
				$scope.depAud.deptSelectAll = 'Y';
			    $scope.depAud.selectAllDeptChanged();
		    }
			var selAud = $filter('filter')($scope.depAud.selDefAudiences,{checked:'Y'},true);
			if(selAud.length == result.length){
				$scope.depAud.deptSelectAll = 'Y';
			}
		 	initializeAudSlimScroll();
		});
	}
	
	$scope.depAud.selectDeptChanged = function(){
		var flag = true;
		var count = 0;
		angular.forEach($scope.depAud.audiencesBO,function(obj){
			if(obj.audienceId != $scope.depAud.selAud){
				if(obj.checked != 'Y'){
					flag = false;
				}else if(obj.checked == 'Y'){
					count++;
				}
			}
		});
		$scope.depAud.deptSelectAll = flag ? 'Y' : 'N'; 
		$scope.depAud.departmentSettings[0].objectValue=$filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);
		$scope.depAud.selDefAudiences = $filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);
	};
	
	$scope.depAud.selectAllDeptChanged = function(){
		if($scope.depAud.deptSelectAll == 'Y'){
			angular.forEach($scope.depAud.audiencesBO,function(obj){obj.checked = 'Y'});
			$scope.depAud.selDefAudiences = angular.copy($scope.depAud.audiencesBO);
		}else{
			angular.forEach($scope.depAud.audiencesBO,function(obj){obj.checked = 'N'});
			$scope.depAud.selDefAudiences = [];
			departmentService.selectedAudiences = true;
		}
		if(!$scope.depAud.selAud){
			angular.forEach($scope.depAud.audiencesBO,function(obj){
				if(obj.audienceName == 'Email Address Audience'){
					$scope.depAud.selAud = obj.audienceId;
					obj.isDefault = true;
				}else{
					obj.isDefault = false;
				}
			});
		}
		$scope.depAud.departmentSettings[0].objectValue=$filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);
		$scope.depAud.selDefAudiences = $filter('filter')($scope.depAud.audiencesBO,{checked:'Y'},true);
	};
	
	$scope.depAud.selectDefAudience = function(){
		angular.forEach($scope.depAud.selDefAudiences,function(obj){
			if($scope.depAud.selAud == obj.audienceId){
				obj.isDefault = true;
			}else{
				obj.isDefault = false;
			}
		});
		$scope.depAud.departmentSettings[0].objectValue=$filter('filter')($scope.depAud.selDefAudiences,{checked:'Y'},true);
	}
	
	function sortAudienceList(result){
		var noEmailSms = $.grep(result,function(obj){
			return !(obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var emailSms = $.grep(result,function(obj){
    		return (obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var sorted = noEmailSms.sort(function(a, b){
			if(a.audienceName.toLowerCase() < b.audienceName.toLowerCase()) return -1;
			if(a.audienceName.toLowerCase() > b.audienceName.toLowerCase()) return 1; return 0;
			});
		var finalAudience = [];
		angular.forEach(emailSms,function(obj){
			finalAudience.push(obj);
		});
		angular.forEach(sorted,function(obj){
			finalAudience.push(obj);
		});
		return finalAudience;
	}
	
}]);

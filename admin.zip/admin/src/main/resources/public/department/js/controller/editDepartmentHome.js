zhapp.controller("editDepartmentHomeController", ['$scope', '$q', '$rootScope', 'departmentService', 'departmentValidationService', 'departmentConversionService', 'mainAppService', function ($scope, $q, $rootScope, departmentService, departmentValidationService, departmentConversionService, mainAppService) {
	$rootScope.navTo = true;
	$scope.dept = {};
	$scope.edp = {};
	$scope.dept.DepartmentBO = JSON.parse(localStorage.DepartmentBO);
	$scope.dept.DuplicateDepartmentBO = null;
	$scope.dept.editDepartmentType = null;
	$scope.dept.rightPaneTemplateSrc = null;
	$scope.dept.leftPaneTemplateSrc = null;
	$scope.dept.checkIfCanReturnToHomePage = function () {
		if (angular.equals($scope.dept.DepartmentBO, $scope.dept.DuplicateDepartmentBO))
			$scope.dept.returnToAdminHomePage();
		else
			$(".back-dialog").dialog("open");
	};
	$scope.dept.saveAndReturn = function () {
		$(".back-dialog").dialog("close");
		var canSave = departmentValidationService.validateDepartment($scope.dept.DepartmentBO);
		if (!canSave)
			return;
		var toSaveDepartmentBO = departmentConversionService.covertDepartmentBOForSave($scope.dept.DepartmentBO);
		departmentService.saveDepartment(toSaveDepartmentBO).success(function () {
			$scope.dept.returnToAdminHomePage();
		}).error(function (responseObj) {
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.dept.returnToAdminHomePage = function () {
		//For moving to list departments.
		$rootScope.navTo = false;
		$scope.adminModule.loadPartialScripts('deptarea');
		removeDepartmentDialogsFromDom();
	};
	$scope.dept.navigateToAnotherModuleSel = function (eve) {
		if (angular.equals($scope.dept.DepartmentBO, $scope.dept.DuplicateDepartmentBO)) {
			$rootScope.navTo = false;
			mainAppService.getBack(eve, $rootScope.linkUrl);
		} else {
			$(".back-dialog").dialog("open");
		}
	};

	$scope.dept.saveDepartment = function () {
		var d = $q.defer();
		var audpromise = $scope.getAudiencesList();
		audpromise.then(function () {
			var canSave = departmentValidationService.validateDepartment($scope.dept.DepartmentBO);
			if (!canSave) {
				var ObjValue = $scope.dept.DepartmentBO.departmentSettings[0].objectValue;
				if (!ObjValue.approvalAddressList || ObjValue.approvalAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.approvalAddressList.push("");
				if (!ObjValue.unsubHeaderAddressList || ObjValue.unsubHeaderAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.unsubHeaderAddressList.push("");
				if (!ObjValue.testAddressList || ObjValue.testAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.testAddressList.push("");
				if (!ObjValue.responseAddressList || ObjValue.responseAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.responseAddressList.push("");
				if (!ObjValue.fromAddressList || ObjValue.fromAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.fromAddressList.push("");
				if (!ObjValue.replyToAddressList || ObjValue.replyToAddressList.length === 0)
					$scope.dept.DepartmentBO.departmentSettings[0].objectValue.replyToAddressList.push("");
				return;
			}
			$scope.dept.DepartmentBO.updatedBy = zhapp.loginUser.userName;
			$scope.saveDepartmentInfo($scope.dept.DepartmentBO).then(function(){
				d.resolve();
			}, function() {
				d.reject();
			});
			return d.promise;
		})
	};

	$scope.getAudiencesList = function () {
		var d = $q.defer();
		if ($scope.dept.DepartmentBO.departmentID == 0) {
			departmentService.getAudiences().then(function (result) {
				for (var i = 0; i < $scope.dept.DepartmentBO.departmentSettings.length; i++) {
					var departmentSetting = $scope.dept.DepartmentBO.departmentSettings[i];
					if (departmentSetting && departmentSetting.objectKey === "AUDIENCES" && !departmentService.selectedAudiences) {
						angular.forEach(result.data, function (obj) {
							obj.checked = 'Y';
							if (obj.audienceName == 'Email Address Audience') {
								obj.isDefault = true;
							}
						});
						departmentSetting.objectValue = result.data;
						d.resolve();
					} else {
						d.resolve();
					}
				}
			}, function (error) {
				showErrorMessage('Fetching Audiences got failed.');
				return false;
				d.reject();
			});
			return d.promise;
		} else {
			d.resolve();
			return d.promise;
		}
	}

	$scope.saveDepartmentInfo = function (testGroupStatus) { // Assign By
		var d = $q.defer();
		if (testGroupStatus == "noTestGroup") {
			$scope.dept.DepartmentBO.departmentSettings[3].objectValue.adminTestGroups = $scope.dept.DuplicateDepartmentBO.departmentSettings[3].objectValue.adminTestGroups;
			var toSaveDepartmentBO = departmentConversionService.covertDepartmentBOForSave($scope.dept.DepartmentBO);
		} else {
			var toSaveDepartmentBO = departmentConversionService.covertDepartmentBOForSave($scope.dept.DepartmentBO);
		}
		//Assign By

		var finalObj = angular.copy(toSaveDepartmentBO);
		var notification = $.grep(finalObj.departmentSettings, function (obj) {
			return obj.objectKey === "NOTIFICATIONS";
		})[0];
		if (notification != undefined) {
			angular.forEach(notification.objectValue.notifications, function (obj) {
				if (obj.isEnabled) {
					angular.forEach(obj.notificationStatuses, function (notificatiobArray) {
						if (notificatiobArray.isEnabled) {
							if (notificatiobArray.emailAddresses === "" || notificatiobArray.emailAddresses === null || typeof notificatiobArray.emailAddresses === "undefined") {
								//notificatiobArray.emailAddresses = obj.defaultEmailAddresses;
								notificatiobArray.emailAddresses = "";
							}
						}
					});
				}
			});
		}
		departmentService.saveDepartment(finalObj).success(function (result) {
			localStorage.DepartmentBO = JSON.stringify({
				"departmentID": result
			});
			$scope.dept.getDepartment(result);
			showInfoMessage("Department saved successfully");
			d.resolve();
		}).error(function (responseObj) {
			showDepartmentErrorMessage(responseObj);
			d.reject();
		});
		return d.promise;
	};

	//Starting of check all boxes while enabling Notifications
	$scope.checkAllCheckBoxes = function (enbaleOrDisabled, typeOfNotification) {

		if (enbaleOrDisabled) {

			if ($scope.dept.DepartmentBO.departmentSettings[0].objectKey == "NOTIFICATIONS") { //In local NOTIFIICATION Object is coming at the index of 0 when we are creating a new department.For This I have checked Notification at Position 0.
				angular.forEach($scope.dept.DepartmentBO.departmentSettings[0].objectValue.notifications, function (notificationObject) {
					if (notificationObject.notificationTypeName == typeOfNotification) {
						if (notificationObject.isEnabled != true) {
							notificationObject.isEnabled = true;
						}
						angular.forEach(notificationObject.notificationStatuses, function (notificationStatusesObj) {
							notificationStatusesObj.isEnabled = true;
						});
					}
				});
			} else if ($scope.dept.DepartmentBO.departmentSettings[4].objectKey == "NOTIFICATIONS") {

				angular.forEach($scope.dept.DepartmentBO.departmentSettings[4].objectValue.notifications, function (notificationObject) {
					if (notificationObject.notificationTypeName == typeOfNotification) {
						if (notificationObject.isEnabled != true) {
							notificationObject.isEnabled = true;
						}
						var x = 0;
						while (x < notificationObject.notificationStatuses.length) {
							if (notificationObject.notificationStatuses[x].isEnabled == true) {
								$scope.replaceOriginalContent(typeOfNotification);
								break;
							} else {
								notificationObject.notificationStatuses[x].isEnabled = true;
								x++;
							}
						}
					}
				});

			}
		} else {
			if ($scope.dept.DepartmentBO.departmentSettings[0].objectKey == "NOTIFICATIONS") { //In local NOTIFIICATION Object is coming at the index of 0 when we are creating a new department.For This I have checked Notification at Position 0.
				angular.forEach($scope.dept.DepartmentBO.departmentSettings[0].objectValue.notifications, function (notificationObject) {
					if (notificationObject.notificationTypeName == typeOfNotification) {
						if (notificationObject.isEnabled == true) {
							notificationObject.isEnabled = false;
						}
						angular.forEach(notificationObject.notificationStatuses, function (notificationStatusesObj) {
							notificationStatusesObj.isEnabled = false;
						});
					}
				});
			} else
				$scope.replaceOriginalContent(typeOfNotification);

		}
	}
	//Closing of check all boxes while enabling Notifications

	//Outside function to replace checkBoxes with original Content	
	$scope.replaceOriginalContent = function (typeOfNotification) {

		$scope.replaceNotificationObject = angular.copy($scope.dept.DuplicateDepartmentBO.departmentSettings[4].objectValue.notifications);
		var i = 0;
		for (var i in $scope.replaceNotificationObject) {
			if ($scope.replaceNotificationObject[i].notificationTypeName == typeOfNotification)
				$scope.dept.DepartmentBO.departmentSettings[4].objectValue.notifications[i].notificationStatuses = $scope.replaceNotificationObject[i].notificationStatuses;
		}

	};
	// Closing Of Outside function to replace checkBoxes with original Content	


	$scope.dept.loadCommonDialogs = function () {
		loadCommonDialogs();
	};
	$scope.dept.loadJQueryEvents = function () {
		$('.approvaladdress').slimScroll({
			color: '#a9a9a9',
			height: '350px',
			size: '6px',
			wheelStep: 1,
			railVisible: false,
			alwaysVisible: false
		});
		loadScrollEvents();
	};
	$scope.$watch('dept.editDepartmentType', function (newValue) {
		if (newValue === 'NOTIFICATIONS')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentnotifications.html";
		else if (newValue === 'ADDRESSLIST')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentaddresses.html";
		else if (newValue === 'Folders')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/addeditfolders.html";
		else if (newValue === 'Categories')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/addeditcategories.html";
		else if (newValue === 'PARAMETERS')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentparameters.html";
		else if (newValue === 'UNSUBRULES')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentunsubs.html";
		else if (newValue === 'GOOGLEANALYTICS')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentga.html";
		else if (newValue === 'ADOBEANALYTICS')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentadobeanalytics.html";
		else if (newValue === 'MOBILE')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentmobile.html";
		else if (newValue === 'OTHERWEBANALYTICS')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentotherwebanalytics.html";
		else if (newValue === 'AUDIENCES')
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentaudiences.html";

	});
	$scope.dept.getDepartment = function (departmentID) {
		var defer = $q.defer();
		departmentService.getDepartment(departmentID).success(function (result) {
			$scope.dept.DepartmentBO = departmentConversionService.convertDepartmentBOForUI(result);
			$scope.dept.DuplicateDepartmentBO = angular.copy($scope.dept.DepartmentBO);
			$rootScope.$broadcast('departmentBOChanged');
			defer.resolve();
		}).error(function (responseObj) {
			showDepartmentErrorMessage(responseObj);
			defer.resolve();
		});
		return defer.promise;
	};
	if (isNotNullOrUndefined($scope.dept.DepartmentBO) && $scope.dept.DepartmentBO.departmentID > 0) {
		var promise = $scope.dept.getDepartment($scope.dept.DepartmentBO.departmentID);
		promise.then(function () {
			$scope.dept.editDepartmentType = 'parameters';
			$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentparameters.html";
		});
	} else {
		$scope.dept.DepartmentBO = departmentConversionService.convertDepartmentBOForUI($scope.dept.DepartmentBO);
		$scope.dept.editDepartmentType = 'parameters';
		$scope.dept.rightPaneTemplateSrc = "/department/templates/editdepartmentparameters.html";
	}
	$scope.dept.leftPaneTemplateSrc = "/department/templates/editDepartmentLeftPane.html"
	$scope.dept.loadAccordionEvents = function () {
		loadAccordionEvents();
	}
	$scope.dept.loadFoldersCategoriesWithOutDepartmentID = function () {
		showInfoMessage("Save Department");
	};

	$scope.deptlodingScrollBar = function () {
		var wh = $(window).height() - 90;
		$(".deptleftscroll").css({
			'height': wh
		});
		$('.deptleftscroll').slimScroll({
			color: '#a9a9a9',
			height: '130px',
			size: '5px',
			wheelStep: 1,
			railVisible: true,
			alwaysVisible: false
		});
	}
}]);
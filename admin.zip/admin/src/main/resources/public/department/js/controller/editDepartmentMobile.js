zhapp.controller("editDepartmentMobile",['$scope','$filter','$q','mobileValidationService','departmentService',function($scope,$filter,$q,mobileValidationService,departmentService) {
	$scope.mobile={};
	$scope.mobile.mobileBO=null;
	$scope.mobile.addShortCodeValue = null;
	$scope.mobile.addShortCodeIsDefault = null;
	$scope.mobile.addKeywordName = null;
	$scope.mobile.addKeywordForShortCode = null;
	$scope.mobile.selectedKeywords = null;
	$scope.mobile.addFirstName = null;
	$scope.mobile.addLastName = null;
	$scope.mobile.addMobileNo = null;
	
	$scope.mobile.addShortCode = function(){
		var shortCode={};
		shortCode.shortCode=parseInt($scope.mobile.addShortCodeValue);
		
		if($scope.mobile.addShortCodeIsDefault){
			shortCode.isDefault="Y";
			$scope.mobile.changeDefaultShortCode(shortCode);
		}
		else
			shortCode.isDefault="N";
	    shortCode.createDate=zhapp.getCnvDateTime('DTS',null,null);
		shortCode.updateDate=zhapp.getCnvDateTime('DTS',null,null);
		shortCode.createdBy=zhapp.loginUser.userName;
		shortCode.updatedBy=zhapp.loginUser.userName;
		//shortCode.activateddate=null;
		//shortCode.validtill=null;
		shortCode.keyWords=[];
		shortCode.isEditable = false;
		if(mobileValidationService.validateShortCode($scope.mobile.mobileBO.shortCodes,shortCode,true)){
			$scope.mobile.mobileBO.shortCodes.push(shortCode);
			$scope.mobile.addKeywordForShortCode = shortCode;
			$scope.mobile.loadKeywords();
			$scope.mobile.addShortCodeValue="";
			$scope.mobile.addShortCodeIsDefault = null;
		}
	};
	$scope.mobile.saveShortCode = function(index,shortCode){
		if(mobileValidationService.validateShortCode($scope.mobile.mobileBO.shortCodes,shortCode,false)){
			var shortCodeObj={};
			shortCodeObj.shortCode=shortCode.shortCode;
			shortCodeObj.isDefault=shortCode.isDefault;
			shortCodeObj.createDate=shortCode.createDate;
			shortCodeObj.createdBy=shortCode.createdBy;
			shortCodeObj.updateDate=zhapp.getCnvDateTime('DTS',null,null);
			shortCode.updatedBy=zhapp.loginUser.userName;
			shortCodeObj.keyWords=shortCode.keyWords;
			//shortCode.activateddate=null;
			//shortCode.validtill=null;
			shortCodeObj.isEditable = false;
			$scope.mobile.mobileBO.shortCodes[index]= shortCodeObj;
			$scope.mobile.addKeywordForShortCode = shortCodeObj;
			$scope.mobile.loadKeywords();
		}
	};
	$scope.mobile.editShortCode = function(index){
		$scope.mobile.mobileBO.shortCodes[index].isEditable = true;
	}
	$scope.mobile.deleteShortCode = function(index){
		$scope.mobile.mobileBO.shortCodes.splice(index,1);
		if(index > 0)
			$scope.mobile.addKeywordForShortCode = $scope.mobile.mobileBO.shortCodes[index-1];
		else
			$scope.mobile.addKeywordForShortCode = {};
		
		$scope.mobile.loadKeywords();
	}
	$scope.mobile.addKeyword = function(){
		var keyword={};
		keyword.name=$scope.mobile.addKeywordName;
		keyword.used="N";
		keyword.createDate=zhapp.getCnvDateTime('DTS',null,null);
		keyword.updateDate=zhapp.getCnvDateTime('DTS',null,null);
		keyword.createdBy=zhapp.loginUser.userName;
		keyword.updatedBy=zhapp.loginUser.userName;
		//keyword.activatedDate=null;
		//keyword.validTill=null;
		keyword.isEditable=false;
		var arr=$filter('filter')($scope.mobile.mobileBO.shortCodes,{shortCode : $scope.mobile.addKeywordForShortCode},true);
		if(mobileValidationService.validateKeyword(arr[0],keyword)){
			if(arr && arr.length > 0){
				arr[0].keyWords.push(keyword);
				$scope.mobile.loadKeywords();
			}
			$scope.mobile.addKeywordName = "";
		}
	};
	$scope.mobile.loadKeywords=function(){
		var arr=$filter('filter')($scope.mobile.mobileBO.shortCodes,{shortCode : $scope.mobile.addKeywordForShortCode},true);
		if(arr && arr.length > 0){
			$scope.mobile.selectedKeywords=arr[0].keyWords;
		}
		else
			$scope.mobile.selectedKeywords = {};
	};
	$scope.mobile.saveKeyword = function(index,keyword){
		var keywordObj={};
		keywordObj.name=keyword.name;
		keywordObj.used=keyword.used;
		keywordObj.createDate=keyword.createDate;
		keywordObj.createdBy=keyword.createdBy;
		keywordObj.updateDate=zhapp.getCnvDateTime('DTS',null,null);
		keyword.updatedBy=zhapp.loginUser.userName;
		//keyword.activatedDate=null;
		//keyword.validTill=null;
		keyword.used='N';
		keywordObj.isEditable=false;
		var arr=$filter('filter')($scope.mobile.mobileBO.shortCodes,{shortCode : $scope.mobile.addKeywordForShortCode},true);
		if(arr && arr.length > 0)
			arr[0].keyWords[index]= keywordObj;
	};
	$scope.mobile.editKeyword = function(index){
		var arr=$filter('filter')($scope.mobile.mobileBO.shortCodes,{shortCode : $scope.mobile.addKeywordForShortCode},true);
		if(arr && arr.length > 0)
			arr[0].keyWords[index].isEditable = true;
		
		$scope.mobile.loadKeywords();
	}
	$scope.mobile.deleteKeyword = function(index){
		var arr=$filter('filter')($scope.mobile.mobileBO.shortCodes,{shortCode : $scope.mobile.addKeywordForShortCode},true);
		if(arr && arr.length > 0)
			arr[0].keyWords.splice(index,1);
		
		$scope.mobile.loadKeywords();
		
	}
	$scope.mobile.saveTestGroup = function(index,testGroup){
		if(mobileValidationService.validateTestGroup($scope.mobile.mobileBO,testGroup)){
			testGroup.campaignId = 0;
			if(!(testGroup.createdBy||testGroup.createdBy===""))
				testGroup.createdBy = zhapp.loginUser.userName;
			testGroup.updatedBy = zhapp.loginUser.userName;
			$scope.mobile.mobileBO.adminTestGroups[index].isEditable = false;
			$scope.mobile.mobileBO.adminTestGroups[index].isValidated = true;
		}
	};
	$scope.mobile.editTestGroup = function(index){
		$scope.mobile.mobileBO.adminTestGroups[index].isEditable = true;
		$scope.mobile.mobileBO.adminTestGroups[index].isValidated = false;
	};
	$scope.mobile.deleteTestGroup = function(index){
		$scope.mobile.mobileBO.adminTestGroups[index] = $scope.mobile.initTestGroup();
	};
	$scope.mobile.changeDefaultShortCode = function(shortCode){
		var existingDefaultCodeindex = -1;
		if(shortCode.isDefault){
			//Check for default short code and save the index
			angular.forEach($scope.mobile.mobileBO.shortCodes, function(key,index){
				if(shortCode.shortCode !== key.shortCode && existingDefaultCodeindex<0 && key.isDefault==="Y"){
						   existingDefaultCodeindex = index;
				}
			});
			//If default short code already exists ask for confirmation
			if(existingDefaultCodeindex >= 0){
						var existingDefaultShortCode = $scope.mobile.mobileBO.shortCodes[existingDefaultCodeindex];
						showCommonConfirmMessage(existingDefaultShortCode.shortCode+' is already set as default short code. Do you want to proceed with '
								+ shortCode.shortCode+' as default short code ?',"Confirm","Yes","No",450,function(flag){
							//If Yes, make selected short code as default
							if(flag){
								   $scope.mobile.mobileBO.shortCodes[existingDefaultCodeindex].isDefault="N";
								   shortCode.isDefault="Y";
								   $scope.$apply($scope.mobile.mobileBO.shortCodes[existingDefaultCodeindex].isDefault="N");
								   showInfoMessage("Shortcode modified successfully");
							}else{
									shortCode.isDefault="N";
									$scope.$apply($scope.defaultShortCode="N");
									$scope.$apply(shortCode.isDefault="N");
							}
						});
					}
		}
	};
	
	function listSMSCampaign(){
		var d = $q.defer();
		var criteria = {};
		criteria.campaignType = 'Sms';
		departmentService.getSMSCampaignList(criteria).success(function(result){
			d.resolve(result);
		}).error(function(error){
			d.reject();
		});
		return d.promise;
	};
	
	function validateShrotcodesAndKeywords(mobileBO,deptId){
		var d = $q.defer();
		listSMSCampaign().then(function(result){
			angular.forEach(mobileBO.shortCodes,function(sobj){
				var temp = $.grep(result.result,function(obj){return (deptId == obj.departmentId && obj.campaign.shortcodeID == sobj.shortCode)});
				if(temp.length > 0){
					sobj.isUsedIncampaign = true;
				}
				angular.forEach(sobj.keyWords,function(kobj){
					temp = $.grep(result.result,function(obj){return (deptId == obj.departmentId && obj.campaign.keywordID == kobj.name)});
					if(temp.length > 0){
						kobj.isUsedIncampaign = true;
					}
				});
			});
			d.resolve(mobileBO);
		},function(error){
			d.reject(mobileBO);
		});
		return d.promise;
	};

	$scope.$on('departmentBOChanged', function () {
		$scope.mobile.init();
    });
	$scope.mobile.init=function(){
		$scope.mobile.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'MOBILE'},true);
		if($scope.mobile.departmentSetting && $scope.mobile.departmentSetting.length===1){
			validateShrotcodesAndKeywords($scope.mobile.departmentSetting[0].objectValue,$scope.mobile.departmentSetting[0].departmentID).then(function(result){
				$scope.mobile.mobileBO = result;
			});
		}
	};
	
	$scope.mobile.initTestGroup = function(){
		var testGroup = {};
		testGroup.firstName = "";
		testGroup.lastName = "";
		testGroup.mobileNumber = "";
		testGroup.campaignId = 0;
		testGroup.isEditable = true;
		testGroup.isValidated = false;
		return testGroup;
	};
	
	$scope.mobile.init();
}]);
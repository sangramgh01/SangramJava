zhapp.controller("editDepartmentNotifications",['$scope','$filter','$timeout',function($scope,$filter,$timeout) {
	$scope.ntf={};
	$scope.ntf.notificationObject=null;
	$scope.ntf.init=function(){
		$scope.ntf.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'NOTIFICATIONS'},true);
		if($scope.ntf.departmentSetting[0].objectValue){
				angular.forEach($scope.ntf.departmentSetting[0].objectValue.notifications, function(obj) {
					if (obj.isEnabled) {
						angular.forEach(obj.notificationStatuses, function(notificatiobArray) {
							if (notificatiobArray.isEnabled) {
								if (notificatiobArray.emailAddresses == obj.defaultEmailAddresses) {
									notificatiobArray.emailAddresses = undefined;
								}
							}
						});
					}
				});
			$scope.ntf.notificationObject=$scope.ntf.departmentSetting[0].objectValue;
		}
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.ntf.init();
    });
	$scope.ntf.loadScrollEvents=function(){
		$timeout(loadScrollEvents());
	};
	$scope.ntf.init();
}]);
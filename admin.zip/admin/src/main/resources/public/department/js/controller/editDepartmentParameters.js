zhapp.controller("departmentParametersController",['$scope','$filter','departmentService','$timeout',function($scope,$filter,departmentService,$timeout) {
	$scope.pm={};
	$scope.pm.parametersBO=null;
	$scope.pm.addResponseDomain=function(index){		
		 $scope.pm.parametersBO.listOfResponseDomains.splice(index+1,0,{}); 		 
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].openurl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].shorturl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].longurl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].hostedemailurl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].imageurl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].unsuburl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].webpageurl="";
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].canEdit=true;
		 $scope.pm.parametersBO.listOfResponseDomains[index+1].name="";
	 };
	 $scope.pm.deleteResponseDomain=function(index){
			$scope.pm.parametersBO.listOfResponseDomains.splice(index,1);
			if(index===0)
				$scope.pm.addResponseDomain(-1);
	};
	$scope.pm.validateDomain=function(){
		departmentService.validateDomain(encodeURI($scope.pm.parametersBO.customerDomainURL)).success(function(){
			$scope.pm.parametersBO.isValidCustomerDomain=true;
			showInfoMessage("Entered Customer Domain is valid.");
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.pm.loadTrackURLS=function(){
		 var arr=$filter('filter')($scope.pm.parametersBO.listOfResponseDomains,{name : $scope.pm.parametersBO.defaultRespDomain},true);				
		 $scope.pm.parametersBO.trackOpensURL=arr[0].openurl;
		 $scope.pm.parametersBO.trackClicksShortURL=arr[0].shorturl;
		 $scope.pm.parametersBO.trackClicksLongURL=arr[0].longurl;
		 $scope.pm.parametersBO.defaultHostedEmailURL=arr[0].hostedemailurl;
		 $scope.pm.parametersBO.defaultImageURL=arr[0].imageurl;
		 $scope.pm.parametersBO.defaultUnsubURL=arr[0].unsuburl;
		 $scope.pm.parametersBO.defaultWebpageURL=arr[0].webpageurl;
	};
	$scope.pm.eliminateGreateLesser = function(event) {
	    if (event.shiftKey && (event.keyCode === 188 || event.keyCode === 190)) 
	    		event.preventDefault();
	};
	$scope.pm.openRestrictedPatternDialog=function(){
		$scope.pm.restrictedPatterns="";
		$( ".dialog-popup16" ).dialog( "open" );
	};
	$scope.pm.closeRestrictedPatternDialog=function(){
		$( ".dialog-popup16" ).dialog( "close" );
	};
	$scope.pm.addRestrictedPattern=function(){	
		var name=$scope.pm.restrictedPatterns;
		if(name===''||name.trim().length===0)
			return;
		name=name.trim();
		if(!$scope.pm.parametersBO.restrictedPatterns)
			$scope.pm.parametersBO.restrictedPatterns=[];
		if(!$scope.pm.validateRestrictedPattern())
		{
			showErrorMessage("Enter a Valid email Pattern");
			return;
		}
		if($filter('filter')($scope.pm.parametersBO.restrictedPatterns,name,true).length<=0)
		{
			$scope.pm.parametersBO.restrictedPatterns.push(name);	
			$scope.pm.closeRestrictedPatternDialog();
		}
		else		
			showInfoMessage("The restricted pattern already exists.");		
		
	};
	$scope.pm.deleteRestrictedPattern=function(index){
		$scope.temp=undefined;
		if(index>-1)
			$scope.pm.parametersBO.restrictedPatterns.splice(index,1);	
	}
	$scope.pm.validateRestrictedPattern = function() {
	    var pattern1 = /^[0-9a-zA-Z\-\_.\*]*[@]?[\w\*]?([\.-]?[\w\*]?)*(\.?\w{2,4}\*)?$/;
	    var flag = false;
	    var str = $scope.pm.restrictedPatterns;
	    var search = str.match(pattern1);
	    var arr=["*","*@*","*.*","*_*","*-*"];
	    if (search) {
            if (arr.indexOf(str) === -1)
                flag = true;
            else
                flag = false;
	    }
	    return flag;
	};
	$scope.pm.addnewVmtaSetting=function(){
		var obj={};
		obj.vmtaHeadersX0="";
		obj.vmtaHeadersX1="";
		obj.fieldNotEditable=false;
		$scope.pm.parametersBO.vmtaHeadersUI.push(obj);
	};
   $scope.pm.saveSmtpSetting=function(index,type){
    	if(type==="SMTP"){
    		$scope.pm.parametersBO.smtpHeadersUI[index].fieldNotEditable=true;
    	}else{
    		var prefix = $scope.pm.parametersBO.vmtaHeadersUI[index].vmtaHeadersX0;
		    var suffix = $scope.pm.parametersBO.vmtaHeadersUI[index].vmtaHeadersX1;
		    if((isNullOrUndefined(prefix) || prefix.trim().length === 0) || (isNullOrUndefined(suffix) || suffix.trim().length === 0)){
		    	showErrorMessage("Please enter VMTA name and value.");
    			return false;
		    }
		    $scope.pm.parametersBO.vmtaHeadersUI[index].fieldNotEditable=true;
    	}
    };
    $scope.pm.editSmtpSetting=function(index,type){
        if(type==="SMTP"){
        	$scope.pm.parametersBO.smtpHeadersUI[index].fieldNotEditable=false;
    	}else{
    		$scope.pm.parametersBO.vmtaHeadersUI[index].fieldNotEditable=false;
    	}
    };
    $scope.pm.deleteSmtpSetting=function(index,type){
        if(type==="SMTP"){
        	if(index===0){
    			return ;
    		}
        	$scope.pm.parametersBO.smtpHeadersUI.splice(index,1);
    	}else{
    		$scope.pm.parametersBO.vmtaHeadersUI.splice(index,1);
    		if($scope.pm.parametersBO.vmtaHeadersUI.length===0)
    			$scope.pm.addnewVmtaSetting();
    	}
    };
    $scope.pm.addnewSmtpSetting =function(){
		if($scope.pm.parametersBO.smtpHeadersUI.length>5){
			showErrorMessage("Max limit (6 headers) of SMTP headers has exceeded.");
			return ;
		}
		var obj={};
		obj.smtpHeadersX0="";
		obj.smtpHeadersX1="";
		obj.fieldNotEditable=false;
		$scope.pm.parametersBO.smtpHeadersUI.push(obj);
	};
	$scope.pm.init=function(){
		$scope.pm.departmentSettings=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'PARAMETERS'},true);
		if($scope.pm.departmentSettings && $scope.pm.departmentSettings.length===1)
			$scope.pm.parametersBO=$scope.pm.departmentSettings[0].objectValue;
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.pm.init();
    });
	$scope.pm.init();
	$timeout(initializeRestrictedPatternsDialog);
	$timeout(initializeBackDialog);
}]);

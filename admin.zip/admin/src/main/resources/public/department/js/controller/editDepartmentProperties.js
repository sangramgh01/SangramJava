zhapp.controller("editDepartmentPropsController",['$scope','$q','departmentService','$filter',function($scope,$q,departmentService,$filter) {
	$scope.edp.closeDepartmentProperties=function(){
		$scope.edp.departmentBO.departmentName = $scope.dept.DepartmentBO.departmentName;
		$scope.edp.departmentBO.approvalMandatory = $scope.dept.DepartmentBO.approvalMandatory;
		$scope.edp.departmentBO.domainKeysUsed = $scope.dept.DepartmentBO.domainKeysUsed;
		$(".editDepartmentDialog").dialog("close");
	};
	$scope.edp.openDepartmentPropertiesPopup=function(){
		$scope.edp.instance=zhapp.loginUser.custCode;
		$scope.edp.departmentBO=$scope.dept.DuplicateDepartmentBO;
		$(".editDepartmentDialog").dialog("open");
	};
	$scope.edp.editDepartmentProperties=function(){
		if(isNullOrUndefined($scope.edp.departmentBO.departmentName) || $scope.edp.departmentBO.departmentName.trim().length===0)
		{
			showInfoMessage("Please enter department name.");
			return false;
		}
		departmentService.saveDepartment($scope.edp.departmentBO).success(function(){
			 $scope.dept.DepartmentBO.departmentName=$scope.edp.departmentBO.departmentName;
			 $scope.dept.DepartmentBO.approvalMandatory=$scope.edp.departmentBO.approvalMandatory;
			 $scope.dept.DepartmentBO.domainKeysUsed=$scope.edp.departmentBO.domainKeysUsed;
			 $scope.edp.closeDepartmentProperties();
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	 };
	 initializeEditDepartmentDialog();
}]);
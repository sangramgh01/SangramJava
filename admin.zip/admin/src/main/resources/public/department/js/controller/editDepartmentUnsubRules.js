zhapp.controller("editDepartmentUnsubRules",['$scope','$filter',function($scope,$filter) {
	$scope.unsbr={};
	$scope.unsbr.domainsList=new Set();;
	$scope.unsbr.unsubRulesBO=null;
	$scope.unsbr.totalCount=0;
	$scope.unsbr.curPageNum=0;
	$scope.unsbr.optionsEnableDisabled=[{value:true,label:'Enable'},{value:false,label:'Disable'}];
	$scope.unsbr.loadPageDetails=function(pageno){
		if(pageno<1)
			return;
		$scope.unsbr.UIDomainsList=[];
		for(var i=0;i<9;i++)
		{
			var req=9*(pageno-1)+i;
			if(req<$scope.unsbr.domainsList.length)
				$scope.unsbr.UIDomainsList.push($scope.unsbr.domainsList[req]);
			else
				break;
		}
		$scope.unsbr.curPageNum=pageno;
		jQuery('html,body').animate({scrollTop:0},0);
	};
	$scope.unsbr.init=function(){
		$scope.unsbr.departmentSetting=$filter('filter')($scope.dept.DepartmentBO.departmentSettings,{objectKey:'UNSUBRULES'},true);
		if($scope.unsbr.departmentSetting && $scope.unsbr.departmentSetting.length===1){
			$scope.unsbr.unsubRulesBO=$scope.unsbr.departmentSetting[0].objectValue;
			angular.forEach($scope.unsbr.unsubRulesBO.domainOptoutRules,function(value){
				if(isNotNullOrUndefined(value.domainCode))
					$scope.unsbr.domainsList.add(value.domainCode);
			});
			$scope.unsbr.domainsList=[...$scope.unsbr.domainsList];
			if(isNotNullOrUndefined($scope.unsbr.domainsList)){
				$scope.unsbr.domainsList=$scope.unsbr.domainsList.sort();
			}
			$scope.unsbr.totalCount=$scope.unsbr.domainsList.length;
			$scope.unsbr.loadPageDetails(1);
		}
	};
	$scope.$on('departmentBOChanged', function () {
		$scope.unsbr.init();
    });
	$scope.unsbr.init();
}]);
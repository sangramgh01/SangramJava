zhapp.controller("folderController",['$scope','$filter','$timeout','$q','departmentService',function($scope,$filter,$timeout,$q,departmentService) {
	$scope.fldr={};
	$scope.fldr.folderType="A";
	$scope.fldr.selectAll=false;
	$scope.fldr.foldersList=null;
	$scope.fldr.addFolderName=null;
	$scope.fldr.selectAllTrashItems=false;
	$scope.fldr.trashConversations=null;
	$scope.fldr.trashContents=null;
	$scope.fldr.trashLists=null;
	$scope.fldr.selectedConvList=[];
	$scope.fldr.selectedContentList=[];
	$scope.fldr.selectedRSSContentList=[];
	$scope.fldr.selectedList=[];
	$scope.fldr.listFolders=function(){
		var listingCriteria={};
		listingCriteria.type=$scope.fldr.folderType;
		listingCriteria.departmentId=$scope.dept.DepartmentBO.departmentID;
		departmentService.listFolders(listingCriteria).success(function(result){
			$scope.fldr.foldersList=result;
			if(isNotNullOrUndefined($scope.fldr.foldersList))
				$scope.fldr.foldersList.splice(0,1);
			$scope.fldr.addFolderName=null;
			$scope.fldr.selectAll=false;
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.fldr.addFolder=function(){
		var folder={};
		folder.folderid=0;
		folder.departmentid=$scope.dept.DepartmentBO.departmentID;
		folder.foldername=$scope.fldr.addFolderName;
		folder.type=$scope.fldr.folderType;
		folder.parentfolderid=0;
		if(folder.foldername.toLowerCase() === $scope.dept.DepartmentBO.departmentName.toLowerCase()){
            showErrorMessage("Folder name can't be same as department name.");
            return;
		}
		if(folder.foldername.toUpperCase() === "TRASH" ){
			showErrorMessage("Folder Name for new folder can not be set as Trash.");
			return;
		}
		departmentService.saveFolder(folder).success(function(result){
			$scope.fldr.addFolderName="";
			$scope.fldr.foldersList.push(result);
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.fldr.saveFolder=function(folder){
		if(folder.foldername.toUpperCase()==='TRASH'){
			showErrorMessage("Folder Name can not be set as Trash.");
			return;
		}
		folder.updateDate = zhapp.getCnvDateTime('DTS',null,null);
		departmentService.saveFolder(folder).success(function(){
			folder.isEdit=false;
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	};
	$scope.fldr.clearAllFolders=function(){
		$scope.fldr.selectAll=false;
		angular.forEach($scope.fldr.foldersList,function(folder){
			folder.isSelected=false;
		});
	};
	$scope.fldr.selectDeselectAll=function(){
		if($scope.fldr.selectAll)
			$scope.fldr.selectAllFolders();
		else
			$scope.fldr.clearAllFolders();
			
	};
	$scope.fldr.selectAllFolders=function(){
		$scope.fldr.selectAll=true;
		angular.forEach($scope.fldr.foldersList,function(folder){
			folder.isSelected=true;
		});
	};
	$scope.fldr.deleteFolder=function(folder){
		showCommonConfirmMessage("Delete folder?", "Confirm", "Yes", "No",400,function(flag){
			if(!flag)
				return;
			departmentService.deleteFolder(folder.folderid).success(function(){
				showInfoMessage("Selected folder deleted successfully.");
				$scope.fldr.foldersList=_.without($scope.fldr.foldersList,folder);
			}).error(function(responseObj){
				showDepartmentErrorMessage(responseObj);
			});
		});
	};
	$scope.fldr.deleteFolders=function(){
		var ids=$filter('filter')($scope.fldr.foldersList,{'isSelected':true},true);
		var folderIds = _.pluck(ids, 'folderid');
		if(folderIds.length === 0)
			showErrorMessage("Please select folders to delete.");
		else{
			showCommonConfirmMessage("Delete folder(s)?", "Confirm", "Yes", "No",400,function(flag){
				if(!flag)
					return;
				departmentService.deleteFolders(folderIds).success(function(){
					showInfoMessage("Selected folders deleted successfully.");
					$scope.fldr.foldersList=_.difference($scope.fldr.foldersList,ids);
				}).error(function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
			});
		}
	};
	
	/*Manage Trash*/
	$scope.dept.openTrashItems=function(){
		$scope.trashFolder=$filter('filter')($scope.fldr.foldersList,{'foldername':'TRASH'},true)[0];
		if($scope.trashFolder==null){
			showErrorMessage("No trash folder exists for this department");
			return;
		}
		var promises=[];
		promises.push($scope.fldr.getTrashConversations($scope.dept.DepartmentBO.departmentID));
		promises.push($scope.fldr.getTrashContents($scope.trashFolder.folderid));
		promises.push($scope.fldr.getTrashFolderList($scope.dept.DepartmentBO.departmentID));
		$q.all(promises).then(function(){
			$(".adminTrashDialog").dialog("open");
		},function(responseObj){ 
			showDepartmentErrorMessage(responseObj) 
		});
	};
	$scope.fldr.getTrashConversations=function(deptId){
		var deferred = $q.defer();
		departmentService.getTrashConversations(deptId).success(function(result){
			$scope.fldr.trashConversations = result;
			angular.forEach($scope.fldr.trashConversations,function(conv){
				conv.previousFolderName = $scope.getFolderName(conv.previousFolderID);
			});
			deferred.resolve();
		}).error(function(responseObject){
			deferred.reject(responseObject);
		});
		return deferred.promise;
		
	};
	$scope.fldr.getTrashContents=function(folderId){
		var deferred = $q.defer();
		departmentService.getTrashContents(folderId).success(function(result){
			$scope.fldr.trashContents=result;
			angular.forEach($scope.fldr.trashContents,function(content){
				content.previousFolderName = $scope.getFolderName(content.previousFolderId);
			});
			deferred.resolve();
		}).error(function(responseObject){
			deferred.reject(responseObject);
		});
		return deferred.promise;
	};
	$scope.fldr.getTrashFolderList=function(deptid){
		var deferred = $q.defer();
		departmentService.getTrashFolderList(deptid).success(function(result){
			$scope.fldr.trashLists=result;
			angular.forEach($scope.fldr.trashLists,function(list){
				list.previousFolderName = $scope.getFolderName(list.previousFolderID);
			});
			deferred.resolve();
		}).error(function(responseObject){
			deferred.reject(responseObject);
		});
		return deferred.promise;
	}
	$scope.fldr.closeTrashPopup=function(){
		$(".adminTrashDialog").dialog("close");
	};
	$scope.fldr.deleteTrashItem=function(item){
		showCommonConfirmMessage("Delete?", "Confirm", "Yes", "No",400,function(flag){
			if(!flag)
				return;
			var promise = [];
			//Delete Conversation
			if(item.conversationID){
				var convIDList = [];
				convIDList.push(item.conversationID);
				promise.push($scope.deleteConversations(convIDList));
			}
			//Delete Content
			else if(item.templateId){
				var templateType = null;
				if(item.templateType==='RSS')
					templateType = 'RSS';
				promise.push($scope.deleteContents(item.templateId,templateType));
			}
			//Delete List
			else if(item.listID)
				promise.push($scope.deleteList(item.listID));
			$q.all(promise).then(function(){
				showInfoMessage("Trash item deleted successfully");
				$scope.listTrashItems();
			}),function(responseObj){
				showDepartmentErrorMessage(responseObj);
			}
		});
	};
	$scope.getFolderName = function(folderId){
		for(var i=0; i<$scope.fldr.foldersList.length;i++){
			if($scope.fldr.foldersList[i].folderid===folderId){
				return $scope.fldr.foldersList[i].foldername;
			}
		}
	};
	
	$scope.fldr.selectOrClearAllItems=function(isSelectAll){
		$scope.fldr.selectAllTrashItems=isSelectAll;
		angular.forEach($scope.fldr.trashConversations,function(conversation){
			conversation.isSelected=isSelectAll;
		});
		angular.forEach($scope.fldr.trashContents,function(content){
			content.isSelected=isSelectAll;
		});
		angular.forEach($scope.fldr.trashLists,function(list){
			list.isSelected=isSelectAll;
		});
	};
	
	$scope.fldr.selectDeselectAllTrash=function(){
		if($scope.fldr.selectAllTrashItems)
			$scope.fldr.selectOrClearAllItems(true);
		else
			$scope.fldr.selectOrClearAllItems(false);
	};
	/* delete selected trash items */
	$scope.fldr.deleteSelectedTrashItems=function(){
		$scope.fldr.selectedTrashList();
		if($scope.fldr.isTrashItemSelected()){
			showCommonConfirmMessage("Delete?", "Confirm", "Yes", "No",400,function(flag){
				if(!flag)
					return;
				var promises = [];
				if($scope.fldr.selectedConvList.length>0)
					promises.push($scope.deleteConversations($scope.fldr.selectedConvList));
				if($scope.fldr.selectedContentList.length>0)
					promises.push($scope.deleteContents($scope.fldr.selectedContentList.join(),null));
				if($scope.fldr.selectedRSSContentList.length>0)
					promises.push($scope.deleteContents($scope.fldr.selectedRSSContentList.join(),'RSS'));
				if($scope.fldr.selectedList.length>0)
					promises.push($scope.deleteList($scope.fldr.selectedList.join()));
				$q.all(promises).then(function(){
					showInfoMessage("Deleted the selected trash item(s) successfully");
					$scope.listTrashItems();
				},function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
			});
		}
	}
	$scope.deleteConversations = function(convIDList){
		var deferred = $q.defer();
		departmentService.deleteConversations(convIDList).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	$scope.deleteContents =  function(contentIDList,templateType){
		var deferred = $q.defer();
		departmentService.deleteContents(contentIDList,templateType).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	$scope.deleteList = function(listId){
		var deferred = $q.defer();
		departmentService.deleteLists(listId).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	/* Restore selected trash items */
	$scope.fldr.restoreTrashItems = function(){
		$scope.fldr.selectedTrashList();
		if($scope.fldr.isTrashItemSelected()){
			showCommonConfirmMessage("Restore?", "Confirm", "Yes", "No",400,function(flag){
				if(!flag)
					return;
				var promises=[];
				if($scope.fldr.selectedConvList.length>0)
					promises.push($scope.fldr.restoreConversations($scope.fldr.selectedConvList));
				if($scope.fldr.selectedContentList.length>0)
					promises.push($scope.fldr.restoreContents($scope.fldr.selectedContentList.join(),null));
				if($scope.fldr.selectedRSSContentList.length>0)
					promises.push($scope.fldr.restoreContents($scope.fldr.selectedRSSContentList.join(),'RSS'));
				if($scope.fldr.selectedList.length>0)
					promises.push($scope.fldr.restoreLists($scope.fldr.selectedList.join()));
				$q.all(promises).then(function(){
					showInfoMessage("Restored the selected trash item(s) successfully");
					$scope.listTrashItems();
				},function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
			});
		}
	};
	$scope.fldr.restoreConversations = function(conList){
		var deferred = $q.defer();
		departmentService.restoreConversations(conList).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	$scope.fldr.restoreContents = function(templateIds,templateType){
		var deferred = $q.defer();
		departmentService.restoreContents(templateIds,templateType).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	$scope.fldr.restoreLists = function(trashList){
		var deferred = $q.defer();
		departmentService.restoreLists(trashList).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	
	/* Empty all trash items */
	$scope.fldr.emptyTrashItems = function(){
		if(!$scope.fldr.isTrashEmpty()){
			showCommonConfirmMessage("Are you sure to empty the trash?", "Confirm", "Yes", "No",400,function(flag){
				if(!flag)
					return;
				$scope.fldr.setRssOtherContents();
				var promises=[];
				var convIds = [];
				angular.forEach($scope.fldr.trashConversations,function(conv){
					convIds.push(conv.conversationID);
				});
				if(convIds.length>0)
					promises.push($scope.fldr.emptyTrashConversations(convIds));
				if($scope.fldr.trashRssContents.length>0)
					promises.push($scope.fldr.emptyRssTrashContents());
				if($scope.fldr.trashOtherContents.length>0)
					promises.push($scope.fldr.emptyTrashContents());
				if($scope.fldr.trashLists.length>0)
					promises.push($scope.fldr.emptyTrashLists());
				$q.all(promises).then(function(){
					showInfoMessage("Emptied the trash successfully");
					$scope.fldr.trashConversations=null;
					$scope.fldr.trashContents=null;
					$scope.fldr.trashLists=null;
				},function(responseObj){
					showDepartmentErrorMessage(responseObj);
				});
			});
		}
	};
	//Empty trashed conversations
	$scope.fldr.emptyTrashConversations = function(convIds){
		var deferred = $q.defer();
		departmentService.emptyTrashConversations(convIds).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	//Empty trashed RSS contents
	$scope.fldr.emptyRssTrashContents = function(){
		var deferred = $q.defer();
		departmentService.emptyTrashContents($scope.trashFolder.folderid,'RSS').success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	//Empty trashed contents
	$scope.fldr.emptyTrashContents = function(){
		var deferred = $q.defer();
		departmentService.emptyTrashContents($scope.trashFolder.folderid,null).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	//Empty trashed lists
	$scope.fldr.emptyTrashLists = function(){
		var deferred = $q.defer();
		departmentService.emptyTrashLists($scope.trashFolder.folderid).success(function(){
			deferred.resolve();
		}).error(function(responseObj){
			deferred.reject(responseObj);
		});
		return deferred.promise;
	};
	//Get list of all trashed items
	$scope.listTrashItems = function(){
		$scope.fldr.getTrashConversations($scope.dept.DepartmentBO.departmentID);
		$scope.fldr.getTrashContents($scope.dept.DepartmentBO.departmentID);
		$scope.fldr.getTrashFolderList($scope.dept.DepartmentBO.departmentID);
	};
	//Selected items
	$scope.fldr.selectedTrashList = function(){
		$scope.fldr.initSelectedTrashLists();
		angular.forEach($scope.fldr.trashConversations,function(conversation){
			if(conversation.isSelected){
				$scope.fldr.selectedConvList.push(conversation.conversationID);
			}
		});
		angular.forEach($scope.fldr.trashContents,function(content){
			if(content.isSelected){
				if(content.templateType==='RSS')
					$scope.fldr.selectedRSSContentList.push(content.templateId);
				else
					$scope.fldr.selectedContentList.push(content.templateId);
			}
		});
		angular.forEach($scope.fldr.trashLists,function(list){
			if(list.isSelected){
				$scope.fldr.selectedList.push(list.listID);
			}
		});
	};
	$scope.fldr.initSelectedTrashLists=function(){
		$scope.fldr.selectedConvList = [];
		$scope.fldr.selectedContentList = [];
		$scope.fldr.selectedList = [];
		$scope.fldr.selectedRSSContentList = [];
	};
	//Is at least one item is selected 
	$scope.fldr.isTrashItemSelected = function(){
		if($scope.fldr.selectedConvList.length===0 && $scope.fldr.selectedContentList.length===0 &&
				   $scope.fldr.selectedRSSContentList.length===0 && $scope.fldr.selectedList.length===0){
					showInfoMessage("No item is selected");
					return false;
		}
		return true;
	};
	//Is the trash empty
	$scope.fldr.isTrashEmpty = function(){
		if((!$scope.fldr.trashConversations && !$scope.fldr.trashContents && !$scope.fldr.trashLists) || 
		   ($scope.fldr.trashConversations.length===0&&$scope.fldr.trashContents.length===0&&$scope.fldr.trashLists.length===0)){
			showInfoMessage("The trash is already empty");
			return true;
		}
		return false;
	};
	$scope.fldr.setRssOtherContents = function(){
		$scope.fldr.trashRssContents = [];
		$scope.fldr.trashOtherContents = [];
		angular.forEach($scope.fldr.trashContents,function(content){
			if(content.templateType==='RSS')
				$scope.fldr.trashRssContents.push(content);
			else
				$scope.fldr.trashOtherContents.push(content);
		});
	};
	$timeout(initializeTrashDialogDepartment);
	$scope.fldr.listFolders();
}]);
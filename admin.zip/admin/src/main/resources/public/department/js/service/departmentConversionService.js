zhapp.factory('departmentConversionService', ['$filter',function($filter) {
	var obj={};
	obj.covertDepartmentBOForSave=function(existingDepartmentBO){
		var newDepartmentBO=angular.copy(existingDepartmentBO);
		for(var i=0;i<newDepartmentBO.departmentSettings.length;i++){
			var departmentSetting=newDepartmentBO.departmentSettings[i];
			if(departmentSetting && departmentSetting.objectKey==="NOTIFICATIONS")
					this.convertNotificationsForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="ADDRESSLIST")
					this.convertAddressListForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="PARAMETERS")
					this.convertParametersForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="UNSUBRULES")
					this.convertUnsubrulesForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="GOOGLEANALYTICS")
					this.convertGAForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="ADOBEANALYTICS")
					this.convertAdobeForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="MOBILE")
					this.convertMobileForSave(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="OTHERWEBANALYTICS")
					this.convertOtherWebAnalyticsForSave(departmentSetting.objectValue);
		}	
		return newDepartmentBO;
	};
	obj.convertMobileForSave=function(mobileBO){	
		//Do not save isEditable and isValidated fields
		 _.each(mobileBO.shortCodes,function(obj){
			 obj.isEditable=undefined;
			 _.each(obj.keyWords,function(keyword){
				 keyword.isEditable = undefined; 
			 });
		 });
		 _.each(mobileBO.adminTestGroups,function(obj){
			 obj.isEditable=undefined;
			 obj.isValidated=undefined;
		});
		 
		 //Add all conversation and admin test groups to mobileBO
		 if(mobileBO.conversationTestGroups)
			 mobileBO.testGroups = mobileBO.adminTestGroups.concat(mobileBO.conversationTestGroups);
		 else
			 mobileBO.testGroups = mobileBO.adminTestGroups;
		//Do not save  mobileBO.adminTestGroups and conversationTestGroups fields
		 mobileBO.adminTestGroups = undefined;
		 mobileBO.conversationTestGroups = undefined;
		 
		 //Save valid test group data
		 var newTestGroups = [];
		 angular.forEach(mobileBO.testGroups,function(value,index){
			if(value.firstName.trim().length!==0 && value.lastName.trim().length!==0 && value.mobileNumber)
				newTestGroups.push(mobileBO.testGroups[index])
		});
		 mobileBO.testGroups = newTestGroups;
	};
	obj.convertAdobeForSave=function(adobeAnalyticsBO){
		adobeAnalyticsBO.statusDescription=undefined;
		adobeAnalyticsBO.statusError=undefined;
		angular.forEach(adobeAnalyticsBO.integratedDomains,function(value,key){
			 if(isNullOrUndefined(value) || value.trim().length===0)
			 {
				 adobeAnalyticsBO.integratedDomains.splice(key,1);
			 }else
				 value=value.trim();
		});
		var arr=[];
		angular.forEach(adobeAnalyticsBO.notificationEmails,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		adobeAnalyticsBO.notificationEmails=arr;
	};
	obj.convertGAForSave=function(googleAnalyticsBO){
		angular.forEach(googleAnalyticsBO.gaDomainsList,function(value,key){
			 if(value.domainName.trim().length===0 && value.utmSource==="Category Name" &&
			    value.utmContent==="Profileid" && value.utmTerm.trim().length===0){
				 googleAnalyticsBO.gaDomainsList.splice(key,1);
			 }else if(isNullOrUndefined(value.isActive))
				 value.isActive=true;
		});
		angular.forEach(googleAnalyticsBO.gaAccountList,function(value,key){
			if(!value.gaAuthorized)
				googleAnalyticsBO.gaAccountList.splice(key,1);
		});
	};
	obj.convertUnsubrulesForSave=function(unsubRulesBO){
		angular.forEach(unsubRulesBO.domainOptoutRules,function(value){
			if(value.isEnabled===false || value.threshold===null || 
			   value.threshold.toString().trim().length===0 || Number(value.threshold)<=0){
			   value.isEnabled=false;
			   value.threshold=0;
			}
		});
	};
	obj.convertParametersForSave=function(parametersBO){
		 angular.forEach($filter('filter')(parametersBO.listOfResponseDomains,{canEdit : true}),function(value,key){
			if(value.name.trim().length===0 && value.openurl.trim().length===0 && 
			   value.shorturl.trim().length===0 && value.longurl.trim().length===0 && 
			   value.hostedemailurl.trim().length===0 && value.imageurl.trim().length===0 && 
			   value.unsuburl.trim().length===0 && value.webpageurl.trim().length===0 )
				parametersBO.listOfResponseDomains.splice(key,1);
		 });
		 angular.forEach(parametersBO.listOfResponseDomains,function(obj){
			 obj.canEdit=undefined;
			 if(parametersBO.defaultRespDomain === obj.name){
				 parametersBO.trackOpensURL=obj.openurl;
				 parametersBO.trackClicksShortURL=obj.shorturl;
				 parametersBO.trackClicksLongURL=obj.longurl;
				 parametersBO.defaultHostedEmailURL=obj.hostedemailurl;
				 parametersBO.defaultImageURL=obj.imageurl;
				 parametersBO.defaultUnsubURL=obj.unsuburl;
				 parametersBO.defaultWebpageURL=obj.webpageurl;
			 }
		 });
		 var arr=[];
		 angular.forEach(parametersBO.smtpHeadersUI,function(smtpHeader){
			  var prefix = smtpHeader.smtpHeadersX0;
			  var suffix = smtpHeader.smtpHeadersX1;				  
			  if(isNotNullOrUndefined(prefix) && isNotNullOrUndefined(suffix) && prefix.trim().length > 0 && suffix.trim().length > 0)
						arr.push("X-"+prefix.trim()+":"+suffix.trim());
		 });
		 parametersBO.smtpHeaders=arr;
		 arr=[];
		 angular.forEach(parametersBO.vmtaHeadersUI,function(smtpHeader){
			  var prefix = smtpHeader.vmtaHeadersX0;
			  var suffix = smtpHeader.vmtaHeadersX1;				  
			  if(isNotNullOrUndefined(prefix) && isNotNullOrUndefined(suffix) && prefix.trim().length > 0 && suffix.trim().length > 0)
						arr.push(prefix.trim()+":"+suffix.trim());
		 });
		 if(parametersBO.testKeyWord===null)
			 parametersBO.testKeyWord="";
		 parametersBO.vmtaHeaders=arr;
		 parametersBO.customerDomainURLDup=undefined;
		 parametersBO.isValidCustomerDomain=undefined;
		 parametersBO.vmtaHeadersUI=undefined;
		 parametersBO.smtpHeadersUI=undefined;
	};
	obj.convertNotificationsForSave=function(notificationBO){
		//Remove empty strings
		angular.forEach(notificationBO.notifications, function(obj) {
			if (obj.isEnabled) {
				angular.forEach(obj.notificationStatuses, function(notificatiobArray) {
					if (notificatiobArray.isEnabled && (notificatiobArray.emailAddresses === "" || notificatiobArray.emailAddresses === null || typeof notificatiobArray.emailAddresses === "undefined"))
							notificatiobArray.emailAddresses = "";
				});
			}
		});
	};
	obj.convertAddressListForSave=function(addressListBO){
		var arr=[];
		angular.forEach(addressListBO.fromAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.fromAddressList=arr;
		
		arr=[];
		angular.forEach(addressListBO.unsubHeaderAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.unsubHeaderAddressList=arr;
		
		arr=[];
		angular.forEach(addressListBO.replyToAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.replyToAddressList=arr;
		
		arr=[];
		angular.forEach(addressListBO.testAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.testAddressList=arr;
		
		arr=[];
		angular.forEach(addressListBO.approvalAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.approvalAddressList=arr;

		arr=[];
		angular.forEach(addressListBO.responseAddressList,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		addressListBO.responseAddressList=arr;
		
		/*Department Default*/
		addressListBO.departmentDefaults=[];
		if(isNotNullOrUndefined(addressListBO.dept_fromadd_dispname) && addressListBO.dept_fromadd_dispname.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_fromadd_dispname;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='fromadd_dispname';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_fromadd_dispname=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.dept_fromadd_emails) && addressListBO.dept_fromadd_emails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_fromadd_emails;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='fromadd_emails';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_fromadd_emails=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.dept_replytoadd_dispname) && addressListBO.dept_replytoadd_dispname.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_replytoadd_dispname;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='replytoadd_dispname';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_replytoadd_dispname=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.dept_replytoadd_emails) && addressListBO.dept_replytoadd_emails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_replytoadd_emails;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='replytoadd_emails';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_replytoadd_emails=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.dept_returnpath) && addressListBO.dept_returnpath.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_returnpath;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='returnpath';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_returnpath=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.dept_unsubemails) && addressListBO.dept_unsubemails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.dept_unsubemails;
			obj.catcode='DEFAULTDEPT';
			obj.addressType='unsubemails';
			addressListBO.departmentDefaults.push(obj);
			addressListBO.dept_unsubemails=undefined;
		}
		/*Catcode Defaults*/
		angular.forEach(addressListBO.categoryDefaults,function(value,key){
			if(value.catcode===addressListBO.selectedCatcode)
			   addressListBO.categoryDefaults.splice(key,1);
		});
		if(isNotNullOrUndefined(addressListBO.cat_fromadd_dispname) && addressListBO.cat_fromadd_dispname.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_fromadd_dispname;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='fromadd_dispname';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_fromadd_dispname=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.cat_fromadd_emails) && addressListBO.cat_fromadd_emails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_fromadd_emails;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='fromadd_emails';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_fromadd_emails=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.cat_replytoadd_dispname) && addressListBO.cat_replytoadd_dispname.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_replytoadd_dispname;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='replytoadd_dispname';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_replytoadd_dispname=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.cat_replytoadd_emails) && addressListBO.cat_replytoadd_emails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_replytoadd_emails;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='replytoadd_emails';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_replytoadd_emails=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.cat_returnpath) && addressListBO.cat_returnpath.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_returnpath;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='returnpath';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_returnpath=undefined;
		}
		if(isNotNullOrUndefined(addressListBO.cat_unsubemails) && addressListBO.cat_unsubemails.trim().length > 0){
			var obj={};
			obj.value=addressListBO.cat_unsubemails;
			obj.catcode=addressListBO.selectedCatcode;
			obj.addressType='unsubemails';
			addressListBO.categoryDefaults.push(obj);
			addressListBO.cat_unsubemails=undefined;
		}
		addressListBO.selectedCatcode=undefined;
	};
	obj.convertDepartmentBOForUI=function(departmentBO){
		for(var i=0;i<departmentBO.departmentSettings.length;i++){
			var departmentSetting=departmentBO.departmentSettings[i];
			if(departmentSetting && departmentSetting.objectKey==="ADDRESSLIST")
					this.convertAddressListForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="PARAMETERS")
					this.convertParametersForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="GOOGLEANALYTICS")
					this.convertGAForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="ADOBEANALYTICS")
					this.convertAdobeForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==='MOBILE')
					this.convertMobileForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==='OTHERWEBANALYTICS')
					this.convertOtherWebAnalyticsForUI(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==='AUDIENCES')
				this.convertDeptAudienceForUI(departmentSetting.objectValue);
		}	
		return departmentBO;
	};
	obj.convertMobileForUI=function(mobileBO){
		var testGroup = {};
		testGroup.firstName = "";
		testGroup.lastName = "";
		testGroup.mobileNumber = "";
		testGroup.campaignId = 0;
		testGroup.isEditable = true;
		testGroup.isValidated = false;
		if(!mobileBO.testGroups)
			mobileBO.testGroups=[];
		
		//Discard Test member added in SMS_conversation
		mobileBO.adminTestGroups = [];
		mobileBO.conversationTestGroups = [];
		for(var i=0;i<mobileBO.testGroups.length;i++){
			if(mobileBO.testGroups[i].campaignId===0)
				mobileBO.adminTestGroups.push(mobileBO.testGroups[i]);
			else
				mobileBO.conversationTestGroups.push(mobileBO.testGroups[i]);
		}
		var diff=5-mobileBO.adminTestGroups.length;
		for(var i=1;i<=diff;i++){
			mobileBO.adminTestGroups.push(angular.copy(testGroup));
		}
		angular.forEach(mobileBO.adminTestGroups,function(value){
			if(isNullOrUndefined(value.isEditable)){
				value.isEditable = false;
				value.isValidated = true;
			}
		});
		
	};
	obj.convertAdobeForUI=function(adobeAnalyticsBO){
		if(adobeAnalyticsBO.runNumber > 0){
			var task=null;
			angular.forEach(adobeAnalyticsBO.runDetails,function(runDetail){
				if(isNullOrUndefined(task) || runDetails.runDate > task.runDate)
				   task=runDetail;
			});
			if(isNullOrUndefined(task.errorDescription) || task.errorDescription.trim().length ===0){
				adobeAnalyticsBO.statusDescription="Completed on "+$filter('date')(task.runDate,'yyyy-MM-dd hh:mm a');
			}	
			else{
				adobeAnalyticsBO.statusDescription="Errored on "+$filter('date')(task.runDate,'yyyy-MM-dd hh:mm a');
				adobeAnalyticsBO.statusError=task.errorDescription;
			} 
		}
		if(adobeAnalyticsBO.integratedDomains.length===0)
			adobeAnalyticsBO.integratedDomains.push("");
		if(adobeAnalyticsBO.uploadHours<10)
			adobeAnalyticsBO.uploadHours="0"+adobeAnalyticsBO.uploadHours;
		else
			adobeAnalyticsBO.uploadHours=""+adobeAnalyticsBO.uploadHours;
		if(adobeAnalyticsBO.uploadMinutes<10)
			adobeAnalyticsBO.uploadMinutes="0"+adobeAnalyticsBO.uploadMinutes;
		else
			adobeAnalyticsBO.uploadMinutes=""+adobeAnalyticsBO.uploadMinutes;
	};
	obj.convertGAForUI=function(googleAnalyticsBO){
		var obj={};
		 obj.domainName='';
		 obj.utmCampaign="Campaign Name";
		 obj.utmSource="Category Name";
		 obj.utmContent="Profileid";
		 obj.utmTerm='';		 
		 obj.utmMedium='email';
		 if(!googleAnalyticsBO.gaDomainsList)
			 googleAnalyticsBO.gaDomainsList=[];
		 if(googleAnalyticsBO.gaDomainsList.length===0)
			 googleAnalyticsBO.gaDomainsList.push(obj);
		 if(googleAnalyticsBO.gaAccountList.length===0)
			 googleAnalyticsBO.gaAccountList.push({});
	};
	obj.convertAddressListForUI=function(addressListBO){
		if(addressListBO.fromAddressList.length===0)
			 addressListBO.fromAddressList.push('');
		if(addressListBO.unsubHeaderAddressList.length===0)
			 addressListBO.unsubHeaderAddressList.push('');
		if(addressListBO.replyToAddressList.length===0)
			 addressListBO.replyToAddressList.push('');
		if(addressListBO.testAddressList.length===0)
			 addressListBO.testAddressList.push('');
		if(addressListBO.approvalAddressList.length===0)
			 addressListBO.approvalAddressList.push('');
		if(addressListBO.responseAddressList.length===0)
			 addressListBO.responseAddressList.push('');
		angular.forEach(addressListBO.departmentDefaults,function(value){
			switch (value.addressType) {
				case 'fromadd_dispname':
					addressListBO.dept_fromadd_dispname = value.value;
					break;
				case 'fromadd_emails':
					addressListBO.dept_fromadd_emails = value.value;
					break;
				case 'replytoadd_dispname':
					addressListBO.dept_replytoadd_dispname = value.value;
					break;
				case 'replytoadd_emails':
					addressListBO.dept_replytoadd_emails = value.value;
					break;
				case 'returnpath':
					addressListBO.dept_returnpath = value.value;
					break;
				case 'unsubemails':
					addressListBO.dept_unsubemails = value.value;
					break;
			}
		});
		addressListBO.selectedCatcode="DEFAULTCATEGORY";
		for(var i=0;i<addressListBO.categoryDefaults.length;i++){
			var value=addressListBO.categoryDefaults[i];
			if(value.catcode!==addressListBO.selectedCatcode)
				continue;
			switch (value.addressType) {
				case 'fromadd_dispname':
					addressListBO.cat_fromadd_dispname = value.value;
					break;
				case 'fromadd_emails':
					addressListBO.cat_fromadd_emails = value.value;
					break;
				case 'replytoadd_dispname':
					addressListBO.cat_replytoadd_dispname = value.value;
					break;
				case 'replytoadd_emails':
					addressListBO.cat_replytoadd_emails = value.value;
					break;
				case 'returnpath':
					addressListBO.cat_returnpath = value.value;
					break;
				case 'unsubemails':
					addressListBO.cat_unsubemails = value.value;
					break;
			}
		}
	};
	obj.convertParametersForUI=function(parametersBO){
		angular.forEach(parametersBO.listOfResponseDomains,function(value){
			if(isNullOrUndefined(value.canEdit))
				value.canEdit=false;
		});
		parametersBO.customerDomainURLDup=parametersBO.customerDomainURL;
			if(parametersBO.listOfResponseDomains.length===0){
			parametersBO.listOfResponseDomains.push({
				 'openurl':'',
				 'shorturl':'',
				 'longurl':'',
				 'hostedemailurl':'',
				 'imageurl':'',
				 'unsuburl':'',
				 'webpageurl':'',
				 'canEdit':true,
				 'name':''
			});
		}
		parametersBO.vmtaHeadersUI=[];
		angular.forEach(parametersBO.vmtaHeaders,function(value){
			var obj={};
			obj.vmtaHeadersX0=value.split(":")[0];
			obj.vmtaHeadersX1=value.split(":")[1];
			obj.fieldNotEditable=true;
			parametersBO.vmtaHeadersUI.push(obj);
		});
		if(parametersBO.vmtaHeadersUI.length===0){
			parametersBO.vmtaHeadersUI.push({
				'vmtaHeadersX0':"",
				'vmtaHeadersX1':"",
				'fieldNotEditable':""
			});
		}
		parametersBO.smtpHeadersUI=[];
		angular.forEach(parametersBO.smtpHeaders,function(value){
			var obj={};
			obj.smtpHeadersX0=value.split(":")[0];
			obj.smtpHeadersX0=obj.smtpHeadersX0.replace("X-","");
			obj.smtpHeadersX1=value.substring(value.indexOf(":")+1);
			obj.fieldNotEditable=true;
			parametersBO.smtpHeadersUI.push(obj);
		});
		parametersBO.isValidCustomerDomain=true;
	};
	obj.convertOtherWebAnalyticsForSave=function(otherWebAnalyticsBO){
		if(isNullOrUndefined(otherWebAnalyticsBO.enabled))
			otherWebAnalyticsBO.enabled=false;
		if(isNullOrUndefined(otherWebAnalyticsBO.urlParams))
			otherWebAnalyticsBO.urlParams="";
		if(isNullOrUndefined(otherWebAnalyticsBO.domainsList))
			otherWebAnalyticsBO.domainsList=[];
		else{
			var filteredDomains=[];
			for(var i=0;i<otherWebAnalyticsBO.domainsList.length;i++){
				var domainName=otherWebAnalyticsBO.domainsList[i].trim();
				if(domainName.length>0)
					filteredDomains.push(domainName);
			}
			otherWebAnalyticsBO.domainsList=filteredDomains;
		}
	};
	obj.convertOtherWebAnalyticsForUI=function(){
		
	};
	obj.convertDeptAudienceForUI = function(savedAudBo){
		 angular.forEach(savedAudBo,function(obj){
				obj.checked = 'Y';
		});
	}
	return obj;
}]);
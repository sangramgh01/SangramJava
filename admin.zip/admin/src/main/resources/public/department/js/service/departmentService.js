zhapp.factory('departmentService', ['$http', function($http) {
    return {
        listDepartments: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'getAllDepartments',
                data: listingCriteria
            });
        },
        departmentsTotalCount: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'departmentsTotalCount',
                data: listingCriteria
            });
        },
        deleteDepartment: function(departmentId){
        	return $http({
        		method: 'DELETE',
        		url: 'deleteDepartment/'+departmentId
        	});
        },
        createDepartment: function(createDepartmentObject){
        	return $http({
        		method: 'POST',
        		url: 'createDepartment',
        		data: createDepartmentObject
        	});
        },
        saveDepartment: function(DepartmentBO) {
            return $http({
                method: 'POST',
                url: '/saveDepartment',
                data: DepartmentBO
            });
        },
        getDepartment: function(departmentId){
        	return $http({
        		method: 'GET',
        		url: '/getDepartment/'+departmentId
        	});
        },
        validateDomain: function(url){
        	return $http({
                method: 'POST',
                url: '/validateDomain',
                data: url
            });
        },
        listDomains: function(){
        	return $http({
        		method: 'GET',
        		url: '/listDomains'
        	});
        },
        getGAAuthURL: function(){
        	return $http({
        		method: 'GET',
        		url: '/getGAAuthURL'
        	});
        },
        authorizeGA: function(gaAccountObj){
        	return $http({
                method: 'POST',
                url: '/authorizeGA',
                data: gaAccountObj
            });
        },
        listFilesources: function() {
            return $http({
                method: 'GET',
                url: '/listFileSources'
            });
        },
        listFolders: function(listingCriteria){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/listFolders',
        		data: listingCriteria
        	});
        },
        saveFolder: function(folderBO){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/saveFolder',
        		data: folderBO
        	});
        },
        saveCategory: function(categoryBO){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/saveCategory',
        		data: categoryBO
        	});
        },
        deleteFolder: function(folderID){
        	return $http({
        		method: 'DELETE',
        		url: zhapp.admin_host+'/deleteFolder/'+folderID
        	});
        },
        deleteFolders: function(folderIds){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/deleteFolders',
        		data: folderIds
        	});
        },
        listCategories: function(criteria){
        	return $http({
                method: 'POST',
                url: zhapp.admin_host+'/listCategories',
                data: criteria
            });
        },
        deleteCategory: function(categoryid){
        	return $http({
        		method: 'DELETE',
        		url: zhapp.admin_host+'/deleteCategory/'+categoryid
        	});
        },
        deleteCategories: function(categoryids){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/deleteCategories',
        		data: categoryids
        	});
        },
        getDepartmentSpecificProperty: function(departmentId,propertyKey){
        	return $http({
        		method: 'POST',
        		url: '/getDepartmentSpecificProperty',
        		data: {
        			'departmentId':departmentId,
        			'propertyKey':propertyKey
        		}
        	});
        },
        uploadNow: function(departmentId){
        	return $http({
        		method: 'POST',
        		url: '/uploadNow',
        		data: departmentId
        	});
        },
        getConversationsByFolderId: function(folderId){
        	return $http({
        		method: 'GET',
        		url: '/getConversationsByFolderId/'+folderId
        	});
        },
        getContentsByFolderId: function(folderId){
        	return $http({
        		method: 'GET',
        		url: '/getContentsByFolderId/'+folderId
        	});
        },
        getTrashFolderList:function(deptId){
        	return $http({
        		method: 'GET',
        		url: '/list/getTrashFolderList/'+deptId
        	});
        },
        deleteConversations:function(conversationIds){
        	return $http({
        		method: 'POST',
        		url: '/deleteConversations',
        		data: conversationIds
        	});
        },
       deleteContents:function(selectedTemplateIds,selectedTemplateType){
			return $http({
				method : 'POST',
				url : '/deleteContents',
				params:{selectedTemplateIds: selectedTemplateIds,selectedTemplateType:selectedTemplateType}
			});
		},
        deleteLists:function(listIds){
        	return $http({
        		method: 'GET',
        		url: '/list/deleteList/'+listIds
        	});
        },
        getTrashConversations:function(deptId){
        	return $http({
        		method: 'GET',
        		url: '/getTrashConversations/'+deptId
        	});
        },
        getTrashContents:function(folderId){
        	return $http({
        		method: 'GET',
        		url: '/getTrashContents/'+folderId
        	});
        },
        restoreConversations:function(convList){
        	return $http({
        		method:'POST',
        		url:'/restoreConversations',
        		data:convList
        	});
        },
        restoreContents:function(selectedTemplateIds,selectedTemplateType){
        	return $http({
        		method:'POST',
        		url:'/restoreContents',
        		params:{selectedTemplateIds: selectedTemplateIds,selectedTemplateType:selectedTemplateType}
        	});
        },
        restoreLists:function(trashList){
        	return $http({
        		method:'GET',
        		url:'/list/restoretrash/'+trashList
        	});
        },
        emptyTrashConversations:function(convIds){
        	return $http({
        		method:'POST',
        		url:'/emptyTrashConversations',
        		data:convIds
        	});
        },
        emptyTrashContents:function(folderId,templateType){
        	return $http({
        		method:'POST',
        		url:'/emptyTrashContents',
        		params:{selectedTrashId:folderId,selectedTemplateType:templateType}
        	});
        },
        emptyTrashLists:function(folderId){
        	return $http({
        		method:'GET',
        		url:'/list/deletelistbyfolderid/'+folderId
        	});
        },
        getSMSCampaignList : function(criteria){
			return $http({
				method : 'POST',
				url : zhapp.conversation_host+'/listAllCampaign',
				data : criteria
			});
		},
        getDepartmentSpecificPropertyCSRNotifications: function(departmentId){
        	return $http({
        		method: 'GET',
        		url : zhapp.admin_host+'/getDepartmentSpecificPropertyCSRNotifications',
        		params:{departmentId: departmentId}
        	});
        },
		getAudiences: function() {
            return $http({
                method: 'GET',
            	url   : '/audience/getAudienceMetaDetails'
            });
        },
    }
}]);
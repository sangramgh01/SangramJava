zhapp.factory('departmentValidationService', ['$filter','departmentService',function($filter,departmentService) {
	var obj={};
	obj.validateNotifications=function(notificationBO){
		var retValue=true;
		var atleastSelectOne=false;
		var mainAtleastSelectOne = false;
		angular.forEach(notificationBO,function(notificationobj){
			if(notificationobj.isEnabled==false)
				return;
			//If notifications were empty return an error
				else
				{
					
					for(var i=0;i<notificationobj.notificationStatuses.length;i++){	
						if(notificationobj.notificationStatuses[i].isEnabled==false)
						{
							notificationobj.notificationStatuses[i].emailAddresses="";
							
						}
					}
					
					
					if(isNullOrUndefined(notificationobj.defaultEmailAddresses) || notificationobj.defaultEmailAddresses.length===0){
						showErrorMessage("Please Enter Atleast One Email Id In Notifications.");
						retValue=false;
						return;
					}//Remove empty strings
					
					var atleastSelectOne = false;
					if(notificationobj.notificationTypeName != 'Reports'){
						angular.forEach(notificationobj.notificationStatuses,function(obj){
							if(!atleastSelectOne && obj.isEnabled == true){
								atleastSelectOne = true;
							}
						});						
					}
					if(notificationobj.notificationTypeName == 'Reports'){
						atleastSelectOne = true;
					}
					if(notificationobj.notificationTypeName == 'Heatmap Report'){
						atleastSelectOne = true;
					}

					if(!atleastSelectOne){
						mainAtleastSelectOne = true;
						showErrorMessage("Please Enter Atleast One Status.");
						retValue=false;
						return;
					}
					
					var arr=[];
					angular.forEach(notificationobj.defaultEmailAddresses,function(value){
						if(isNotNullOrUndefined(value) && value.length>0)
							arr.push(value);
					});
					//After removing empty strings, we should have atleast on string
					if(arr.length===0){
						showErrorMessage("Please Enter Atleast One Email Id In Notifications.");
						retValue=false;
						return;
					}
					
					var default_emails=[];
					var notification_emails=[];
					default_emails=notificationobj.defaultEmailAddresses.split(',');
					//notification_emails=notificationobj.notificationStatuses.split(',');
					
						if(default_emails.length>10)
						{
							showErrorMessage("Email length should not grater than 10");
							retValue=false;
							return;
						}
					
						for(var i=0;i<default_emails.length;i++){
						var email=default_emails[i];
						if(email && email.length > 0 && !validateEmail(email)){
							showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
							retValue=false;
							return;
						}
					}
						
						if((new Set(default_emails)).size !== default_emails.length){
							showErrorMessage('Duplicate emails not allowed.');
							retValue=false;
							return;
						}
						var email_Address=[];
						for(var i=0;i<notificationobj.notificationStatuses.length;i++){	
							if(notificationobj.notificationStatuses[i].isEnabled && notificationobj.notificationStatuses[i].emailAddresses)
							{
								
								email_Address=notificationobj.notificationStatuses[i].emailAddresses.split(',');
								if(email_Address.length>10)
								{
									showErrorMessage("Email length should not grater than 10");
									retValue=false;
									return;
								}
								
								for(var j=0;j<email_Address.length;j++){
									var emailAddress=email_Address[j];
									if(emailAddress && emailAddress.length > 0 && !validateEmail(emailAddress)){
										showErrorMessage("An invalid email address '"+emailAddress+"' is specified, verify the email address is valid and retry.");
										retValue=false;
										return;
									}
								}
								
								if((new Set(email_Address)).size !== email_Address.length){
									showErrorMessage('Duplicate emails not allowed.');
									retValue=false;
									return;
								}
							}
							
						}
				}
			
		});
		//Return if send notification is disbled, no need to check anything
		return retValue;
	};
	obj.validateAddressList = function(addressListBO){
		var i;
		var email;
		var arr;
		//Begin :: From Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.fromAddressList.length;i++){
			email=addressListBO.fromAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.fromAddressList=arr;
		for(i=0;i<addressListBO.fromAddressList.length;i++){
			email=addressListBO.fromAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.fromAddressList)).size !== addressListBO.fromAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		//Begin :: Unsub Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.unsubHeaderAddressList.length;i++){
			email=addressListBO.unsubHeaderAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.unsubHeaderAddressList=arr;
		for(i=0;i<addressListBO.unsubHeaderAddressList.length;i++){
			email=addressListBO.unsubHeaderAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.unsubHeaderAddressList)).size !== addressListBO.unsubHeaderAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		//Begin :: Replyto Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.replyToAddressList.length;i++){
			email=addressListBO.replyToAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.replyToAddressList=arr;
		for(i=0;i<addressListBO.replyToAddressList.length;i++){
			email=addressListBO.replyToAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.replyToAddressList)).size !== addressListBO.replyToAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		//Begin :: Test Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.testAddressList.length;i++){
			email=addressListBO.testAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.testAddressList=arr;
		for(i=0;i<addressListBO.testAddressList.length;i++){
			email=addressListBO.testAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.testAddressList)).size !== addressListBO.testAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		//Begin :: Approval Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.approvalAddressList.length;i++){
			email=addressListBO.approvalAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.approvalAddressList=arr;
		for(i=0;i<addressListBO.approvalAddressList.length;i++){
			email=addressListBO.approvalAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.approvalAddressList)).size !== addressListBO.approvalAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		//Begin :: Response Addresses Validation.
		arr=[];
		for(i=0;i<addressListBO.responseAddressList.length;i++){
			email=addressListBO.responseAddressList[i];
			if(email && email.length > 0)
				arr.push(email);
		}
		addressListBO.responseAddressList=arr;
		for(i=0;i<addressListBO.responseAddressList.length;i++){
			email=addressListBO.responseAddressList[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		if((new Set(addressListBO.responseAddressList)).size !== addressListBO.responseAddressList.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		return true;
	};
	obj.validateParameters = function(parametersBO){
		if(parametersBO.canEditCustomerDomainURL && (!parametersBO.customerDomainURL || parametersBO.customerDomainURL.length<=0))
		{
			showErrorMessage("Customer Domain URL Cannot be empty.");
			return false;
		}
		if(!parametersBO.trackOpensURL||parametersBO.trackOpensURL.trim().length===0)
		{	showErrorMessage("Track Open URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.trackOpensURL.indexOf("http://")===0||parametersBO.trackOpensURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Track Open URL must start with http://  or  https://.");
			return false;
		}
		if(!parametersBO.trackClicksShortURL||parametersBO.trackClicksShortURL.trim().length===0)
		{	showErrorMessage("Track Clicks Short URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.trackClicksShortURL.indexOf("http://")===0||parametersBO.trackClicksShortURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Track Clicks Short URL must start with http://  or  https://.");
			return false;
		}
		if(!parametersBO.trackClicksLongURL||parametersBO.trackClicksLongURL.trim().length===0)
		{	showErrorMessage("Track Clicks Long URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.trackClicksLongURL.indexOf("http://")===0||parametersBO.trackClicksLongURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Track Clicks Long URL must start with http://  or  https://.");
			return false;
		}
		if(!parametersBO.defaultHostedEmailURL||parametersBO.defaultHostedEmailURL.trim().length===0)
		{	showErrorMessage("HostedEmail URL Cannot be empty.");
			return false;
		}
		if(!parametersBO.defaultImageURL||parametersBO.defaultImageURL.trim().length===0)
		{	showErrorMessage("Image URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.defaultImageURL.indexOf("http://")===0||parametersBO.defaultImageURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Image URL must start with http://  or  https://.");
			return false;
		}
		if(!parametersBO.defaultUnsubURL||parametersBO.defaultUnsubURL.trim().length===0)
		{	showErrorMessage("Unsub URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.defaultUnsubURL.indexOf("http://")===0||parametersBO.defaultUnsubURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Unsub URL must start with http://  or  https://.");
			return false;
		}
		if(!parametersBO.defaultWebpageURL||parametersBO.defaultWebpageURL.trim().length===0)
		{	showErrorMessage("Webpage URL Cannot be empty.");
			return false;
		}
		if(!(parametersBO.defaultWebpageURL.indexOf("http://")===0||parametersBO.defaultWebpageURL.indexOf("https://")===0))
		{	showErrorMessage("Error! Webpage URL must start with http://  or  https://.");
			return false;
		}
		
		if(parametersBO.unsubAppend){
			if(isNullOrUndefined(parametersBO.unsubHTML) || parametersBO.unsubHTML.trim().length===0)
			{
				showErrorMessage("HTML Message Required.");
				return false;
			}
			else if(isNullOrUndefined(parametersBO.unsubText) || parametersBO.unsubText.trim().length===0)
			{
				showErrorMessage("TEXT Message Required.");
				return false;
			}
		}	
		if(parametersBO.testMaxEmails==='0'||parametersBO.testMaxEmails==='00')
		{
			showErrorMessage("Maximum Test email list should be greater than 0.");
			return false;
		}
		if(!parametersBO.isValidCustomerDomain && parametersBO.canEditCustomerDomainURL)
		{
			showErrorMessage("Validate Customer Domain URL and continue to save.");
			return false;
		}
		if(parametersBO.fCapEnabled)
		{
			if(!parametersBO.fCapThreshold || parametersBO.fCapThreshold.toString().trim().length===0 
			   || parametersBO.fCapThreshold.toString()==='0' 
			   || parametersBO.fCapThreshold.toString().toString()==='00')
			{
				showErrorMessage("Frequency cap value should be greater than zero(0).");
				return false;
			}
		}	
		
		var listOfResponseDomains=angular.copy(parametersBO.listOfResponseDomains);
		angular.forEach($filter('filter')(listOfResponseDomains,{canEdit : true}),function(value,key){
			if(value.name.trim().length===0 && value.openurl.trim().length===0 && 
			   value.shorturl.trim().length===0 && value.longurl.trim().length===0 && 
			   value.hostedemailurl.trim().length===0 && value.imageurl.trim().length===0 &&
			   value.unsuburl.trim().length===0 && value.webpageurl.trim().length===0)
				listOfResponseDomains.splice(key,1);
		});
		var bool=true;
		angular.forEach(listOfResponseDomains,function(value){
			if(!value.name||value.name==='')
			{
				showErrorMessage("Error! Response Domain Name should not be empty.");
				bool=false;
				return false;
			}	
			if($filter('filter')(listOfResponseDomains,{name : value.name},true).length>1)
			{
				showErrorMessage("Error! Response Domain Name should not be same as another Response Domain Name in same department.");
				bool=false;
				return false;
			}
			if(!value.openurl||value.openurl.trim().length===0)
			{
				showErrorMessage("Track Clicks Open URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.openurl.indexOf("http://")===0||value.openurl.indexOf("https://")===0))
			{
				showErrorMessage("Error! Track Clicks Open URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
			if(!value.shorturl||value.shorturl.trim().length===0)
			{
				showErrorMessage("Track Clicks Short URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.shorturl.indexOf("http://")===0||value.shorturl.indexOf("https://")===0))
			{
				showErrorMessage("Error! Track Clicks Short URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
			if(!value.longurl||value.longurl.trim().length===0)
			{
				showErrorMessage("Track Clicks Long URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.longurl.indexOf("http://")===0||value.longurl.indexOf("https://")===0))
			{				
				showErrorMessage("Error! Track Clicks Long URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
			if(!value.hostedemailurl||value.hostedemailurl.trim().length===0)
			{	
				showErrorMessage("HostedEmail URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!value.imageurl||value.imageurl.trim().length===0)
			{	
				showErrorMessage("Image URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.imageurl.indexOf("http://")===0||value.imageurl.indexOf("https://")===0))
			{	
				showErrorMessage("Error! Image URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
			if(!value.unsuburl||value.unsuburl.trim().length===0)
			{	
				showErrorMessage("Unsub URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.unsuburl.indexOf("http://")===0||value.unsuburl.indexOf("https://")===0))
			{	
				showErrorMessage("Error! Unsub URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
			if(!value.webpageurl||value.webpageurl.trim().length===0)
			{	
				showErrorMessage("Webpage URL Cannot be empty.");
				bool=false;
				return false;
			}
			if(!(value.webpageurl.indexOf("http://")===0||value.webpageurl.indexOf("https://")===0))
			{	
				showErrorMessage("Error! Webpage URL must start with http://  or  https://.");
				bool=false;
				return false;
			}
		});
		if(!bool)
			return bool;		
		return true;
	};
	obj.validateMailHeaders=function(parametersBO){
		 var regExp = /[\s]/;			
		 angular.forEach(parametersBO.smtpHeadersUI,function(smtpHeader){
			  var prefix = smtpHeader.smtpHeadersX0;
			  if (isNotNullOrUndefined(prefix) && prefix.match(regExp)){
					 showErrorMessage("Space is not allowed in the SMTP Header.");
					 return false;
			  }
		 });
		 if(isNotNullOrUndefined(parametersBO.baseVmtaName) && parametersBO.baseVmtaName.match(regExp)){
			 showErrorMessage("Space is not allowed in the Base VMTA.");
			 return false;
		 }
		 angular.forEach(parametersBO.vmtaHeadersUI,function(vmtaHeader){
			  var suffix = vmtaHeader.vmtaHeadersX1;
			  if (isNotNullOrUndefined(suffix) && suffix.match(regExp)){
					 showErrorMessage("Space is not allowed in the VMTA value.");
					 return false;
			  }	
		 });
		 
		 var arr=[];
		 angular.forEach(parametersBO.vmtaHeadersUI,function(vmtaHeader){
			  var value = vmtaHeader.vmtaHeadersX1.trim();
			  var header = vmtaHeader.vmtaHeadersX0.trim();
			  if(value.length > 0 && header.length > 0)
				  arr.push(vmtaHeader);
		 });
		 parametersBO.vmtaHeadersUI=arr;
		 
		 var vmtavalue = _.uniq( _.collect(parametersBO.vmtaHeadersUI, function( x ){
			  return  x.vmtaHeadersX1;
		 }));
		 
		  if(vmtavalue.length!== parametersBO.vmtaHeadersUI.length){
			  showErrorMessage("Duplicate VMTA values are not allowed.");
			  return false;
		  }
		  
		  var vmtaheader = _.uniq( _.collect(parametersBO.vmtaHeadersUI, function( x ){
			  return  x.vmtaHeadersX0;
		  }));
		  
		  if(vmtaheader.length!== parametersBO.vmtaHeadersUI.length){
			  showErrorMessage("Duplicate VMTA headers are not allowed.");
			  return false;
		  }
		 return true;
	};
	obj.validateUnsubrules = function(unsubRulesBO){
		if(!unsubRulesBO.emailUnsubDepartment && !unsubRulesBO.emailUnsubGlobal){
			showErrorMessage("Email Unsubscribe Rule is not selected.");
			return false;
		}
		if(!unsubRulesBO.thresholdUnsubDepartment && !unsubRulesBO.thresholdUnsubGlobal){
			showErrorMessage("Error Threshold Subscribe Rule is not selected.");
			return false;
		}
		return true;
	};
	obj.validateGADomain=function(domain){
		if(domain.toLocaleLowerCase().indexOf(('ftp://').toLowerCase())===0||domain.toLocaleLowerCase().indexOf(('sftp://').toLowerCase())===0){
			 showErrorMessage("'"+domain+"' is invalid. Enter a valid Domain.");
			 return false;
		}
		if(domain.length>0 && domain.charAt(0)==='.' ||domain.charAt(domain.length-1)==='.'
		||domain.charAt(0)==='-' ||domain.charAt(domain.length-1)==='-'
		||domain.charAt(0)==='_' ||domain.charAt(domain.length-1)==='_'){
			 showErrorMessage("'"+domain+"' is invalid. Enter a valid Domain.");
			 return false;
		}
		var regExp=/^[0-9]+$/;					
		if (domain.length>0 && domain.charAt(domain.length-1).match(regExp)){
			 showErrorMessage("'"+domain+"' is invalid. Enter a valid Domain.");
			 return false;
		}
		var temp=domain;
		regExp=/([0-9a-zA-Z\-\_]+[.])+[a-zA-Z]{2,4}$/;
		if(domain.indexOf("www.") !== -1)
		{
			domain = domain.substr(domain.indexOf("www.")+4, domain.length);
		}
		if(domain.charAt(0) === '-' || domain.charAt(0) === '_'){
			 showErrorMessage("'"+temp+"' is invalid. Enter a valid Domain.");
		 	 return false;
		}	
		if (!domain.match(regExp)){
			 showErrorMessage("'"+temp+"' is invalid. Enter a valid Domain.");
			 return false;
		}
		return true;
	};
	obj.validateGA = function(googleAnalyticsBO){
		 var bool=true;
		 if(googleAnalyticsBO.gaEnabled)
		 {	
			 for(var i=0;i<googleAnalyticsBO.gaDomainsList.length;i++){
				 var value=googleAnalyticsBO.gaDomainsList[i];
				 if(value.domainName.trim().length===0 && 
				   (value.utmSource!=="Category Name" || value.utmContent!=="Profileid" || value.utmTerm.trim().length===0))
				 {
					 showErrorMessage("Domain names can not be empty.");
					 bool=false;
					 return false;
				 }
				 if(value.domainName.trim().length > 0 && ! this.validateGADomain(value.domainName.trim()))	{
					 bool=false;
					 return false;
				 }		 
			 }
			 if(!bool)
				 return false;
		 }
		 //Check Domain Name uniqueness.
		 var arr=[];
		 angular.forEach(googleAnalyticsBO.gaDomainsList,function(value){
			 if(value.domainName.trim().length===0 && value.utmSource==="Category Name" &&
			    value.utmContent==="Profileid" && value.utmTerm.trim().length===0)
			 {
				 //DO NOTHING
			 }else
				 arr.push(value);
		 });
		 var domainsUnique = _.uniq( _.collect(arr, function( x ){
			  return  x.domainName;
		 }));
		 if(domainsUnique.length!== arr.length){
			  showErrorMessage("Domain name(s) already exist or duplicate domain(s) exist in the list,Provide valid domain(s) and retry.");
			  return false;
		 }
		 return bool;
	};
	obj.validateAdobe=function(adobeAnalyticsBO){
		if(!adobeAnalyticsBO.adobeAnalyticsTracking)
			return true;
		if(!adobeAnalyticsBO.clientID||adobeAnalyticsBO.clientID.trim().length === 0)
		{
			showErrorMessage("Client ID should not be empty.");
			return false;
		}
		if(!adobeAnalyticsBO.reportSuite||adobeAnalyticsBO.reportSuite.trim().length === 0)
		{
			showErrorMessage("Report Suite should not be empty.");
			return false;
		}
		if(!adobeAnalyticsBO.integrationNum||adobeAnalyticsBO.integrationNum.trim().length === 0)
		{
			showErrorMessage("Integration Number should not be empty.");
			return false;
		}
		if(adobeAnalyticsBO.integrationNum.trim().length<4)
		{
			showErrorMessage("Integration Number should be atleast 4 digits.");
			return false;
		}
		if(!adobeAnalyticsBO.metricsFileSourceName || adobeAnalyticsBO.metricsFileSourceName.trim().length === 0)
		{
			showErrorMessage("Adobe Analytics Upload Server Details should not be empty.");
			return false;
		}
		if(!adobeAnalyticsBO.attributesFileSourceName || adobeAnalyticsBO.attributesFileSourceName.trim().length === 0)
		{
			showErrorMessage("Adobe Analytics Upload Server Details should not be empty.");
			return false;
		}
		var bool=false;
		angular.forEach(adobeAnalyticsBO.integratedDomains,function(value){
			if(value && value.trim().length>0)
			{
				bool=true;			
			}
		});
		if(!bool)
		{
			showErrorMessage("Atleast one Domain should be entered.");
			return false;
		}

		if(adobeAnalyticsBO.recipientID==='Profile ID' && (!adobeAnalyticsBO.customerOutboundFileSourceName || adobeAnalyticsBO.customerOutboundFileSourceName.trim().length === 0)){
			showErrorMessage("Adobe Analytics Upload Server Details should not be empty.");
			return false;
		}
		
		//Return if send notification is disbled, no need to check anything
		if(adobeAnalyticsBO.notificationType === 'Disable')
			return true;
		//If notifications were empty return an error
		if(isNullOrUndefined(adobeAnalyticsBO.notificationEmails) || adobeAnalyticsBO.notificationEmails.length===0){
			showErrorMessage("Please Enter Atleast One Email Id In Notifications.");
			return false;
		}//Remove empty strings
		var arr=[];
		angular.forEach(adobeAnalyticsBO.notificationEmails,function(value){
			if(isNotNullOrUndefined(value) && value.length>0)
				arr.push(value);
		});
		//After removing empty strings, we should have atleast on string
		if(arr.length===0){
			showErrorMessage("Please Enter Atleast One Email Id In Notifications.");
			return false;
		}
		//Check whether emails were valid or not.
		for(var i=0;i<arr.length;i++){
			var email=arr[i];
			if(email && email.length > 0 && !validateEmail(email)){
				showErrorMessage("An invalid email address '"+email+"' is specified, verify the email address is valid and retry.");
				return false;
			}
		}
		//Return error message if there are any duplicate values in emails
		if((new Set(arr)).size !== arr.length){
			showErrorMessage('Duplicate emails not allowed.');
			return false;
		}
		return true;
	};
	
	
	obj.validateDepartment = function(departmentBO){
		var notHavingAnyErrors=true;
		var parametersBO;
		var addressListBO;
		for(var i=0;i<departmentBO.departmentSettings.length;i++){
			var departmentSetting=departmentBO.departmentSettings[i];
			if(departmentSetting && departmentSetting.objectKey==="NOTIFICATIONS"){
				    notHavingAnyErrors=this.validateNotifications(departmentSetting.objectValue.notifications);
			}else if(departmentSetting && departmentSetting.objectKey==="ADDRESSLIST"){
					addressListBO=departmentSetting.objectValue;
					notHavingAnyErrors=this.validateAddressList(departmentSetting.objectValue);
			}else if(departmentSetting && departmentSetting.objectKey==="PARAMETERS"){
					parametersBO=departmentSetting.objectValue;
					notHavingAnyErrors=this.validateParameters(departmentSetting.objectValue);
					if(notHavingAnyErrors)
						notHavingAnyErrors=this.validateMailHeaders(departmentSetting.objectValue);
			}
			else if(departmentSetting && departmentSetting.objectKey==="UNSUBRULES")
					notHavingAnyErrors=this.validateUnsubrules(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="GOOGLEANALYTICS")
					notHavingAnyErrors=this.validateGA(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="ADOBEANALYTICS")
					notHavingAnyErrors=this.validateAdobe(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="MOBILE")
					notHavingAnyErrors=this.validateMobile(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="OTHERWEBANALYTICS")
					notHavingAnyErrors=this.validateOtherWebAnalytics(departmentSetting.objectValue);
			else if(departmentSetting && departmentSetting.objectKey==="AUDIENCES")
				notHavingAnyErrors=this.validateAudiences(departmentSetting.objectValue,departmentBO.departmentID);
			
			if(notHavingAnyErrors===false)
				break;
		}
		if(notHavingAnyErrors){
			var textMaxSize=parametersBO.testMaxEmails;
			if(textMaxSize!=null && textMaxSize.trim().length != 0 && textMaxSize!='0' && addressListBO.testAddressList.length > Number(textMaxSize)){
				showErrorMessage("The test emails exceed the maximum allowed email count "+Number(textMaxSize)+". Verify the test emails are less than the allowed email count and retry.");
				notHavingAnyErrors=false;
			}
		}
		return notHavingAnyErrors;
	}
	
	
	obj.validateMobile = function(mobileBO){
		var isValid = true;
		if(!mobileBO.optoutMessage){
			mobileBO.optoutMessage = "STOP";
		}
		else if(mobileBO.optoutMessage.toUpperCase().indexOf('STOP') === -1){
			isValid = false;
			showErrorMessage("Optout message must contain 'STOP'");
		}
		angular.forEach(mobileBO.adminTestGroups,function(value){
			if(value.firstName.trim().length!==0 && value.lastName.trim().length!==0 && value.mobileNumber && !value.isValidated){
				isValid = false;
				showCommonConfirmMessage("Are you sure you want to save to the department without saving the test group data", "Confirm", "Yes", "No",450,function(flag){
					if(flag){
						isValid = true;
						angular.element(document.getElementById("editDepartmentHomeController")).scope().saveDepartmentInfo("noTestGroup");//Assign By
						
					}
				});
			}
		});
		return isValid;
	};
	obj.validateOtherWebAnalytics=function(otherWebAnalyticsBO){
		if(isNotNullOrUndefined(otherWebAnalyticsBO.domainsList) && otherWebAnalyticsBO.domainsList.length>0){
			for(var j=0;j<otherWebAnalyticsBO.domainsList.length;j++){
				var domainName=otherWebAnalyticsBO.domainsList[j].trim();
				if(domainName.length>0 && !validateDomainName(domainName)){
					showErrorMessage("Invalid domain name '"+domainName+"' specified.");
					return false;
				}
			}
		}
		if(!otherWebAnalyticsBO.enabled || isNullOrUndefined(otherWebAnalyticsBO.urlParams))
			return true;
		otherWebAnalyticsBO.urlParams=otherWebAnalyticsBO.urlParams.trim();
		otherWebAnalyticsBO.urlParams=otherWebAnalyticsBO.urlParams.replace(/(\?*$)|(^\?*)/g, "");
		otherWebAnalyticsBO.urlParams=otherWebAnalyticsBO.urlParams.replace(/(\&*$)|(^\&*)/g, "");
		if(otherWebAnalyticsBO.urlParams.length > 0){
			var keyValuePair=otherWebAnalyticsBO.urlParams.split("&");
			for(var i=0;i<keyValuePair.length;i++){
				if(keyValuePair[i].split("=").length!==2){
					showErrorMessage("Invalid query string specified.");
					return false;
				}
			}
		}
		return true;
	};
	obj.validateAudiences = function(selAudienceBo,deptID){
		var defaultAudience = $filter('filter')(selAudienceBo,{isDefault:true},true);
		if(selAudienceBo.length == 0 || defaultAudience.length == 0){
			showErrorMessage("Atleast one audience should be select.");
			return false;
		}
	  return true;
	}
	return obj;
}]);
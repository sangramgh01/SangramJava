zhapp.factory('mobileValidationService', ['$filter',function($filter) {
		var obj={};
		obj.validateShortCode = function(shortCodes,shortCode,isAdd){
			var isShortCodeValid = true;
			if (!shortCode.shortCode) {
				isShortCodeValid = false;
				showErrorMessage("Please enter the code");
			}
			//validation code for short-code don't allow more than 10 digits
			else if(shortCode.shortCode.toString().length > 10)
				{
				isShortCodeValid = false;
				showErrorMessage("Code must be less than 10 digits");
				}
			// Validation for duplicate short code
			else{
				var noOfOccurances = 0;
				angular.forEach(shortCodes,function(value){
					if(parseInt(value.shortCode) === parseInt(shortCode.shortCode)){
						noOfOccurances++;
					}
				});
				
				/*For save operation as the edited short code value binds with mobileBO.shortCodes before save, the arr contains 2 elements if the given
				short code already exists */
				if(!isAdd && noOfOccurances > 1){
					isShortCodeValid = false;
					showErrorMessage("Code already exists. Please enter another code");
				}
				//This condition is for add short code
				else if(isAdd && noOfOccurances > 0){
					isShortCodeValid = false;
					showErrorMessage("Code already exists. Please enter another code");
				}
		}
		return isShortCodeValid;
		}
		
		obj.validateKeyword = function(shortCode,keyword){
		var isKeywordValid = true;
		if(!keyword.name || keyword.name.trim().length === 0){
			isKeywordValid = false;
			showErrorMessage("Please enter the keyword");
		}
		// Validation for duplicate keyword
		else{
			angular.forEach(shortCode.keyWords,function(value){
				if(value.name.toLowerCase() === keyword.name.toLowerCase()){
					isKeywordValid = false;
					showErrorMessage("keyword already exists. Please enter another keyword");
				}
			});
		}
		return isKeywordValid;
	}
	obj.validateTestGroup = function(mobileBO,testGroup){
		var isTestGroupValid = true;
		if(!testGroup.firstName || testGroup.firstName.trim().length === 0){
			isTestGroupValid = false;
			showErrorMessage("Please enter the first name");
		}
		else if(!testGroup.firstName.match( /^[A-Za-z]+$/)){//checking  name allows char's only
			isTestGroupValid = false;
			showErrorMessage("Please enter valid first name.");
		}
		else if(!testGroup.lastName || testGroup.lastName.trim().length === 0){
			isTestGroupValid = false;
			showErrorMessage("Please enter the last name");
		}
		else if(!testGroup.lastName.match( /^[A-Za-z]+$/)){ //checking  name allows char's only
		   isTestGroupValid = false;
		   showErrorMessage("Please enter valid last name.");
		}
		else if(!testGroup.mobileNumber){
			isTestGroupValid = false;
			showErrorMessage("Please enter the mobile number");
		}
		else if(testGroup.mobileNumber.length < 10){
			isTestGroupValid = false;
			showErrorMessage("The mobile number must be of length atleast 10" );
		}
		else{
			var noOfOccurances = 0;
			angular.forEach(mobileBO.adminTestGroups,function(value){
				if(parseInt(value.mobileNumber) === parseInt(testGroup.mobileNumber)){
					noOfOccurances++;
				}
			});
			angular.forEach(mobileBO.conversationTestGroups,function(value){
				if(parseInt(value.mobileNumber) === parseInt(testGroup.mobileNumber)){
					noOfOccurances++;
				}
			});
			if(noOfOccurances>1){
				isTestGroupValid = false;
				showErrorMessage("The mobile number "+ testGroup.mobileNumber +" already exists. " +
						"Please enter another mobile number");
			}
		}
		return isTestGroupValid;
	}
	return obj;
}]);
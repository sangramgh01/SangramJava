zhapp.controller("systemExpressionsController",['$rootScope','$scope','expressionService','adminListingService', function($rootScope,$scope,expSer,adminListingService) {
	$scope.exp = {};
	$scope.exp.detailsList = [];
	$scope.exp.hubSysListCriteria={};
	
	$scope.init=function(){
		$scope.exp.hubSysListCriteria={};
		$scope.exp.hubSysListCriteria.expressiontype = 'S';
		$scope.loadPageDetails(1);
	};
	
	$scope.loadPageDetails=function(pageno){
		$scope.exp.hubSysListCriteria.pageno=pageno;
		$scope.exp.listSystemExpressions($scope.exp.hubSysListCriteria);
	}
	
	$scope.$on('derivedfieldsystem',function(){
		$scope.adminModule.sortby = 'createdon';
		$scope.adminModule.sortorder='descending';
		$scope.init();
	});
	
	$scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.exp.hubSysListCriteria.sortorder = 'DESC';
		}else{
			$scope.exp.hubSysListCriteria.sortorder = 'ASC';
		}
		if($scope.adminModule.sortby == 'createdon'){
			$scope.exp.hubSysListCriteria.sortby='createdate';
		}else{
			$scope.exp.hubSysListCriteria.sortby=$scope.adminModule.sortby;
		}
		$scope.exp.listSystemExpressions($scope.exp.hubSysListCriteria);
    });
	
	$scope.exp.listSystemExpressions = function(hubSysListCriteria){
	expSer.getAllExpressions(hubSysListCriteria).success(function(result){
		if(result.result)
			$scope.exp.detailsList = result.result;
		}).error(function(error){
		showErrorMessage($scope.exp.getErrorMessages(error));
		});
	}
	
}]);
zhapp.controller("customExpressionsController",['$scope','expressionService','$timeout', function($scope,expSer,$timeout) {
	$scope.exp = {};
	$scope.exp.template = "filedefinition/templates/listofcustomexpressions.html";
	$scope.exp.details = {};
	$scope.derField = {};
	$scope.exp.infoMessage="There are no Expressions";
	
	$scope.defaultValuesNewExp = function(){
		$scope.derField.details = {};
		$scope.derField.details.inputParams = [];
//		var empty = {};
//		$scope.derField.details.inputParams.push(empty);
		$scope.searchCriteria = {};		
		$scope.searchCriteria.pageno = 1;		
		$scope.searchCriteria.pagesize = 7;	
		$scope.totalRecords = -1;		
		$scope.currentPageNumber=1;
		$scope.exp.searchBy = "ID";
	}
	
	$scope.exp.paramTypesList = [{key: "DateTime", value: "DateTime"},
	  	                          	{key: "String",value: "String"},
	                                {key: "DatePart",value: "DatePart"},
	                                {key: "BigInt", value: "BigInt"},
	                                {key: "TimeZone",value: "TimeZone"},
	                                {key: "DateFormat", value: "DateFormat"},
	                                {key: "Aggregate",value: "Aggregate"},
	                                {key: "Conversation", value: "Conversation"},
	                                {key: "Touchpoint", value: "Touchpoint"},
	                                {key: "Link", value: "Link"},
	                                {key: "Number", value: "Number"}];
	
	$scope.exp.returnTypes = [{key: "DateTime", value: "DateTime"},
	  	                          	{key: "String",value: "String"},
	                                {key: "Float",value: "Float"},
	                                {key: "Int", value: "Int"},
	                                {key: "Boolean",value: "Boolean"},
	                                {key: "BigInt", value: "BigInt"}];
	
	$scope.exp.searchByValues = [{'key': 'ID','value': 'ID'}, {'key': 'Name','value': 'Name'},{ 'key': 'Created Date','value': 'Created Date'
    }, {		
        'key': 'Modified Date',		
        'value': 'Modified Date'		
    }];
	
	$scope.$on('derivedfieldcustom',function(){
		$scope.adminModule.sortby = 'createdon';
		$scope.adminModule.sortorder='descending';
		$scope.defaultValuesNewExp();
	});
	
	$scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.searchCriteria.sortorder = 'DESC';
		}else{
			$scope.searchCriteria.sortorder = 'ASC';
		}
		if($scope.adminModule.sortby == 'createdon'){
			$scope.searchCriteria.sortby='createdate';
		}else{
			$scope.searchCriteria.sortby=$scope.adminModule.sortby;
		}
		$scope.exp.listcustemExpressions($scope.searchCriteria);
    });
	
	$scope.exp.listcustemExpressions = function(searchCriteria){
		searchCriteria.expressiontype = 'C';
		expSer.getAllExpressions(searchCriteria).success(function(result){
			if(result.result){
				$scope.exp.detailsList = [];
				$scope.exp.detailsList = result.result;
				if(result.result[0])$scope.totalRecords = result.totalRecords;		
				else $scope.totalRecords=-1;
			}
		}).error(function(error){
			showErrorMessage($scope.exp.getErrorMessages(error));
		});
	}
	
	$scope.exp.details.addParameter = function(detailsList){
		var obj = {};
		obj.paramName=undefined;
		obj.paramType = undefined;
		obj.range = undefined;
		obj.purpose = undefined;
		detailsList.push(obj);
	}
	
	$scope.exp.deleteRow = function(index,detailsList){
//		if(detailsList.length==1){
//			return;
//		}
		detailsList.splice(index,1);
	}
	
	$scope.exp.addNewExpression = function(){
		$scope.defaultValuesNewExp();
		$scope.exp.template = "filedefinition/templates/createderivedfield.html";
	}
	
	$scope.derField.addField = function(){
		if($scope.derField.details.inputParams.length > 10){
			return;
		}
		var obj = {};
		$scope.derField.details.inputParams.push(obj);
	}
	
	
	$scope.derField.deleteRow = function(index){
//		if($scope.derField.details.inputParams.length==1){
//			return;
//		}
		$scope.derField.details.inputParams.splice(index,1);
	}
	
	$scope.exp.navigateBack = function(){
    	showCommonConfirmMessage("Do you want to save changes?","Confirm","Yes","No",450,function(value){
			if(value == false){
				$scope.exp.template = "filedefinition/templates/listofcustomexpressions.html";
				var searchCriteria = {};		
				searchCriteria.pageno = 1;		
				searchCriteria.pagesize = 7;
				$scope.currentPageNumber=1;
				$scope.exp.listcustemExpressions(searchCriteria);
				$scope.defaultValuesNewExp();
			}else{
				$scope.exp.saveExpression();
			}
		});
    }
	
	$scope.exp.saveExpression = function(){
		$scope.derField.details.expressionType = 'C';
		$scope.derField.details.departmentID = zhapp.loginUser.departmentID;
		$scope.derField.details.status = 'A';
		$scope.derField.details.createdBy = zhapp.loginUser.userName;
//		$scope.derField.details.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
//		$scope.derField.details.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');	
//		$scope.derField.details.updatedBy = zhapp.loginUser.userName;
		console.log($scope.derField.details);
		expSer.saveExpressions($scope.derField.details).success(function(result){
			$scope.exp.template = "filedefinition/templates/listofcustomexpressions.html";
			var searchCriteria = {};		
			searchCriteria.pageno = 1;		
			searchCriteria.pagesize = 7;
			$scope.currentPageNumber=1;
			$scope.exp.listcustemExpressions(searchCriteria);
		}).error(function(error){
			showErrorMessage($scope.exp.getErrorMessages(error));
		})
	}
	
		$scope.changeSearchBoxData = function(){
			$scope.exp.clearSearch();
		};
	
	$scope.exp.updateExpression = function(details){
		details.updatedBy = zhapp.loginUser.userName;
//		details.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
//		details.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');	
		expSer.saveExpressions(details).success(function(result){
			var searchCriteria = {};		
			searchCriteria.pageno = 1;		
			searchCriteria.pagesize = 7;
			$scope.currentPageNumber=1;
			searchCriteria.expressiontype = 'C';
			expSer.getAllExpressions(searchCriteria).success(function(result){
				if(result.result){
					$scope.exp.detailsList = [];
					$scope.exp.detailsList = result.result;
					if(result.result[0])$scope.totalRecords = result.totalRecords;		
					else $scope.totalRecords=-1;
					$timeout(function() { showInfoMessage("Expression Updated Successfully");}, 500);
				}
			}).error(function(error){
				showErrorMessage($scope.exp.getErrorMessages(error));
			});
		}).error(function(error){
			showErrorMessage($scope.exp.getErrorMessages(error));
		});
	}
	
	$scope.exp.deleteExpression = function(expressionId){
		showCommonConfirmMessage("Delete selected Expression?","Confirm","Yes","No",450,function(flag){
			if(flag){
				expSer.deleteExpression(expressionId).success(function(result){
				if(result){
					var searchCriteria = {};		
					searchCriteria.pageno = 1;		
					searchCriteria.pagesize = 7;
					$scope.currentPageNumber=1;
					searchCriteria.expressiontype = 'C';
					expSer.getAllExpressions(searchCriteria).success(function(result){
						if(result.result){
							$scope.exp.detailsList = [];
							$scope.exp.detailsList = result.result;
							if(result.result[0])$scope.totalRecords = result.totalRecords;		
							else $scope.totalRecords=-1;
							$timeout(function() { showInfoMessage("Expression deleted Successfully");}, 500);
						}
					}).error(function(error){
						showErrorMessage($scope.exp.getErrorMessages(error));
					});
				}
			}).error(function(error){
				showErrorMessage($scope.exp.getErrorMessages(error));
			});}
		});
		
	}
	
	$scope.exp.validateInputParams = function(selectedObj, allInputParams){
		var countConv = 0;
		var countTP = 0;
		var countLink = 0;
		angular.forEach(allInputParams,function(obj){
			if(obj.paramType == 'Conversation'){
				countConv++;
			}
			if(obj.paramType == 'Touchpoint'){
				countTP++;
			}
			if(obj.paramType == 'Link'){
				countLink++;
			}
		});
		if(countConv > 1){
			$timeout(function() { selectedObj.paramType = undefined;}, 1000);
			showErrorMessage("Expression should not have more than one input parameter as type ::Conversation");
			return;
		}
		if(countTP > 1){
			$timeout(function() { selectedObj.paramType = undefined;}, 1000);
			showErrorMessage("Expression should not have more than one input parameter as type ::Touchpoint");
			return;
		}
		if(countLink > 1){
			$timeout(function() { selectedObj.paramType = undefined;}, 1000);
			showErrorMessage("Expression should not have more than one input parameter as type ::Link");
			return;
		}
		if(selectedObj.paramType == 'Touchpoint'){
			var isValidTouchPoint = false;
			angular.forEach(allInputParams,function(obj){
				if(obj.paramType == 'Conversation'){
					isValidTouchPoint = true;
				}
			});
			if(isValidTouchPoint == false){
				$timeout(function() { selectedObj.paramType = undefined;}, 1000);
				showErrorMessage("Expression must have conversation as an input before giving TouchPoint");
				return;
			}
		}
		if(selectedObj.paramType == 'Link'){
			var isValidLink = false;
			angular.forEach(allInputParams,function(obj){
				if(obj.paramType == 'Conversation'){
					isValidLink = true;
				}
			});
			if(isValidLink == false){
				$timeout(function() { selectedObj.paramType = undefined;}, 1000);
				showErrorMessage("Expression must have conversation,TouchPoint as an input before giving Link");
				return;
			}
			isValidLink = false;
			angular.forEach(allInputParams,function(obj){
				if(obj.paramType == 'Touchpoint'){
					isValidLink = true;
				}
			});
			if(isValidLink == false){
				$timeout(function() { selectedObj.paramType = undefined;}, 1000);
				showErrorMessage("Expression must have conversation,TouchPoint as an input before giving Link");
				return;
			}
			
		}
	}
	
	$scope.exp.validateExpression = function(details){
		var req = new FormData();
		req.append("expression", details.expressionDSL);
		expSer.validateExpression(req).success(function(result){
			console.log(result);
			if(result.response == true)
				showInfoMessage("Valid Expression");
			else
				showErrorMessage("Expression is not valid::"+result.message);
		}).error(function(error){
			showErrorMessage($scope.exp.getErrorMessages(error));
		});
	}
	
	$scope.exp.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = error.error;
    	}
    	return msg;
    }
	
	$scope.loadPageDetails = function(pageno){		
		$scope.searchCriteria.pageno = pageno;		
		$scope.currentPageNumber=pageno;
		if($scope.exp.toDate != undefined && $scope.exp.fromDate != undefined ){
			$scope.searchByValue($scope.exp.searchtext,event.type);
		}
		else if($scope.exp.searchtext != undefined || $scope.exp.searchtext != '' || $scope.exp.searchtext.length !=0){
			$scope.searchCriteria.name=$scope.exp.searchtext;
			$scope.exp.listcustemExpressions($scope.searchCriteria);
		}
		else{
			$scope.exp.listcustemExpressions($scope.searchCriteria);
		}
	}
	
	$scope.defaultValuesNewExp();
	$scope.exp.listcustemExpressions($scope.searchCriteria);
	
	$scope.exp.loadCommonDialogs=function(){
		loadCommonDialogs();
	};
	
	$scope.loadScheduleEvents = function() {
        $('.timepicker').timepicker({
            showSeconds: false,
            showMeridian: false,
            defaultTime: false,
            disableFocus: false,
            minuteStep: 1
        });
        $('.cal-icon').click(function() {
            $(this).prev("input").trigger('focus');
        });
        $(".scheduleTimeField").datepicker({
            autoclose: true,
            todayHighlight: true
        });
        $(".scheduleTimeFieldToDate").datepicker({
            autoclose: true,
            todayHighlight: true
        }).datepicker("setDate", new Date());
        
        
	};
	

	$scope.exp.clearSearch = function(){
		$scope.exp.searchtext = '';
		$scope.exp.fromDate = undefined;
		$scope.exp.toDate = undefined;
		var searchCriteria = {};		
		searchCriteria.pageno = 1;		
		searchCriteria.pagesize = 7;
		$scope.currentPageNumber=1;
		$scope.exp.listcustemExpressions(searchCriteria);
	}
	
	$scope.searchByValue = function(serachValue, event) {		
        // alert(event.keyCode);
        if (event.type == "click" || event.keyCode == 13 || event == "click") {		
            var searchCriteria = {};		
            searchCriteria.pageno = 1;		
            searchCriteria.pagesize = 7;		
            $scope.searchtext = serachValue;
            if(serachValue != undefined && event == "click" || event.type == "click"){
            	event.keyCode = 8;
            }
            if($scope.currentPageNumber != undefined){
            	searchCriteria.pageno = $scope.currentPageNumber; 
            }
            if ($scope.exp.searchBy == "ID") {		
                if ($scope.searchtext == 0) {		
                    showErrorMessage("Enter id value more than 0.");		
                    $scope.searchtext = '';		
                    return false;		
                }		
                if (isNaN($scope.searchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    $scope.searchtext = '';		
                    return;		
                } else {		
                    searchCriteria.expressionID = $scope.searchtext;		
                }		
            } else if ($scope.exp.searchBy == "Name") {	
            	if( $scope.searchtext=="'"){
            		$scope.searchtext="\\'";
            	}
                searchCriteria.name = $scope.searchtext;		
            } else if ($scope.exp.searchBy == "Created Date") {
            	if($scope.exp.fromDate == undefined){
            		 showErrorMessage("Please Enter the From Date");
            		 return;
            	}
            	if( $scope.exp.toDate == undefined){
          		   showErrorMessage("Please Enter the To Date");	
          		   return;
                 }
            	
                searchCriteria.createdFromDate = $scope.exp.fromDate+" 00:00:00" ;		
                searchCriteria.createdToDate = $scope.exp.toDate+" 23:59:59" ;			
                if (new Date($scope.exp.fromDate) > new Date($scope.exp.toDate)) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }	
            } else if ($scope.exp.searchBy == "Modified Date") {	
            	if($scope.exp.fromDate == undefined){
           		 showErrorMessage("Please Enter the From Date");
           		 return;
           	}	
            	
            	if( $scope.exp.toDate == undefined){
          		   showErrorMessage("Please Enter the To Date");	
          		   return;
                 }
            	
                searchCriteria.updatedFromdate  = $scope.exp.fromDate+" 00:00:00" ;		
                searchCriteria.updatedTodate = $scope.exp.toDate+" 23:59:59" ;			
                if (new Date($scope.exp.fromDate) > new Date($scope.exp.toDate)) {			
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }
            }
            $scope.exp.listcustemExpressions(searchCriteria);            		
        }   	
        if ((event.keyCode == 8 || event.keyCode == 46) && serachValue.length == 0) {		
            $scope.loadPageDetails(1);
            
        }		
    }
	
	
}]);
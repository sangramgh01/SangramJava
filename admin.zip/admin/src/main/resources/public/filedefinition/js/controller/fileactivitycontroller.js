zhapp.controller("fileActivityController",['$scope','$rootScope','fileDefinitionService','Blob','FileSaver', function(scope,$rootScope,fileDefSer,Blob,FileSaver) {
	scope.la = {};
	function initilizeValues(){
		scope.la.fileImportActivityList = [];
		scope.la.searchBy=[{'key':'ID','value':'ID'},{'key':'File Definition Name','value':'File Definition Name'},{'key':'File ID','value':'File ID'},{'key':'File Name','value':'File Name'},{'key':'Status','value':'Status'},{'key':'Started On','value':'Started On'},{'key':'Completed On','value':'Completed On'},{'key':'Batch ID','value':'Batch ID'}];
		scope.la.statusArray=[{'key':'W','value':'Waiting'},{'key':'E','value':'Errored'},{'key':'I','value':'InProgress'},{'key':'C','value':'Completed'},{'key':'X','value':'Completed'},{'key':'U','value':'Skipped'},{'key':'S','value':'Cancelled'},{'key':'R','value':'Waiting'},{'key':'P','value':'OnHold'},{'key':'F','value':'Errored'}];
		scope.status = [ {'key' : 'R','value' : 'Waiting'}, {'key' : 'E','value' : 'Errored'}, {'key' : 'I','value' : 'In Progress'}, {'key' : 'C','value' : 'Completed'}, {'key' : 'U','value' : 'Skipped'}, {'key' : 'S','value' : 'Cancelled'}, {'key' : 'P','value' : 'On Hold'} ];
		scope.la.search = scope.la.searchBy[0].key;
		defaultSearchValues();
	}
	
	function defaultSearchValues(){
		scope.la.searchCriteria = {}
		scope.la.searchCriteria.departmentID = zhapp.loginUser.departmentID;
		scope.la.searchCriteria.pageno = 1;
		scope.la.searchCriteria.pageSize = 7;
		scope.la.currentPageNumber=1;
	}
	
	scope.$on('fdactivity',function(){
		initilizeValues();
		getAllFileActivities(scope.la.searchCriteria);
	});
	
	scope.la.loadPageDetails = function(pageno){
		scope.la.searchCriteria.pageSize = 7;
		scope.la.searchCriteria.pageno = pageno;		
		scope.la.currentPageNumber=pageno;
		getAllFileActivities(scope.la.searchCriteria);
	}
	
	scope.la.downloadFileActivityLogFiles = function(loadActivity){
		var promise = fileDefSer.createzipfile(loadActivity).success(function(result){
			var req = new FormData();
			req.append("zipFilePath", result.response);
			fileDefSer.downloadFileActivityLogFiles(req).success(function(result1){
				 var data = new Blob([result1], { type: 'application/zip;charset=utf-8' });
				 FileSaver.saveAs(data, result.response.substring(result.response.lastIndexOf("/")+1,result.response.length));
    		}).error(function(error){
    			showErrorMessage(scope.la.getErrorMessages(error));
    		});
		}).error(function(error){
			showErrorMessage(scope.la.getErrorMessages(error));
		});
	}
	
	scope.la.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = error.error;
    	}
    	return msg;
    }
	
	
	scope.la.openErrorPopUp = function(message){
		showErrorMessage(message);
	}
	scope.la.disableDownloadFileActivityLogFiles = function(fileActivity){
			if(fileActivity.status=='W')
					return true;
			else if(fileActivity.status=='B')
					return true;
			else if(fileActivity.status=='I')
					return true;
			else if(fileActivity.status=='U')
					return true;
			else if((fileActivity.ignorefilePath==null || fileActivity.ignorefilePath.length==0) && 
					(fileActivity.databaseLogPath==null || fileActivity.databaseLogPath.length==0))
					return true;
			return false;
	}
	
	function getAllFileActivities(activitySearchCri){
		fileDefSer.getfileActivityByCriteria(activitySearchCri).success(function(result){
			if(result){
				scope.la.fileImportActivityList = result.activityCollection;
				scope.la.totalRecords = result.totalCount;
				scope.la.currentPageNumber=activitySearchCri.pageno;
			}else{
				scope.la.currentPageNumber=1;
			}
			if(scope.la.fileImportActivityList.length == 0){
				scope.la.infoMessage ="No Activity Found";
				//showErrorMessage("No Activity Found");
				return;
			}
		}).error(function(error){
			scope.la.infoMessage = "There are no file import task activites";
			showErrorMessage(scope.la.getErrorMessages(error));
		});
	}
	
	scope.la.selectAllActivities = function(){
		if(scope.la.fileImportActivityList){
			angular.forEach(scope.la.fileImportActivityList,function(obj){obj.checked = true;});
		}
	}
	
	scope.la.clearAllActivities = function(){
		if(scope.la.fileImportActivityList){
			angular.forEach(scope.la.fileImportActivityList,function(obj){obj.checked = false;});
		}
	}
	
	scope.la.retryCancelActivities = function(status){
		if(scope.la.fileImportActivityList == undefined || scope.la.fileImportActivityList.length == 0)
			return;
		var msg = (status=='S')?'cancel':'retry';
		var finalAct = $.grep(scope.la.fileImportActivityList,function(obj){return obj.checked == true && obj.status == 'E';});
		if(finalAct && finalAct.length == 0){
			showErrorMessage("Select atleast one errored activity.");
			return;
		}else if(finalAct && finalAct.length > 1){
			showErrorMessage("Only one errored activity can be "+msg+" at a time");
			return;
		}else{
			if(!finalAct)return;
			fileDefSer.updatefiledefinitionactivitystatus(finalAct[0].fileActivityID,status,finalAct[0].fileDefinitionID).success(function(result){
				getAllFileActivities(scope.la.searchCriteria);
			}).error(function(error){
				showErrorMessage(scope.la.getErrorMessages(error));
			});
		}
	}
	
	scope.la.searchByValue = function(searchtext,event){
		if (event.type == "click" || event =="click" || event.keyCode == 13) {
			if(scope.la.search == "ID"){
				if(scope.la.searchtext == '' || scope.la.searchtext == '0'){
					showErrorMessage("Enter id value more than 0.");		
					scope.la.searchtext = '';		
	                return false;
				}
                if (isNaN(scope.la.searchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    scope.la.searchtext = '';	
                    return false;	
    			}
                scope.la.searchCriteria.fileDefinitionID = scope.la.searchtext;
			}else if(scope.la.search == "File Definition Name"){
				if(scope.la.searchtext == ''){
					showErrorMessage("Enter File Defination Name");		
					scope.la.searchtext = '';		
	                return false;
				}
				scope.la.searchCriteria.filedefName = scope.la.searchtext;
			}else if(scope.la.search == "File ID"){
				if(scope.la.searchtext == '' || scope.la.searchtext == '0'){
					showErrorMessage("Enter id value more than 0.");		
					scope.la.searchtext = '';		
	                return false;
				}
                if (isNaN(scope.la.searchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    scope.la.searchtext = '';	
                    return false;	
    			}
                scope.la.searchCriteria.fileactivityID = scope.la.searchtext;
			}else if(scope.la.search == "File Name"){
				if(scope.la.searchtext == ''){
					showErrorMessage("Enter File Name");		
					scope.la.searchtext = '';		
	                return false;
				}
				scope.la.searchCriteria.fileName = scope.la.searchtext;
			}else if(scope.la.search == "Started On"){
				if(scope.la.fromDate == undefined || scope.la.fromDate.trim().length==0 ){
					scope.la.searchCriteria.startedOnFrom = undefined;
					showErrorMessage("Enter Valid From Date");
					return;
				}else
            		scope.la.searchCriteria.startedOnFrom = scope.la.fromDate+" 00:00:00";
            	if(scope.la.toDate == undefined ||scope.la.toDate.trim().length==0 ){
            		scope.la.searchCriteria.startedOnEnd = undefined;
            		showErrorMessage("Enter Valid To Date");
					return;
				}else
            		scope.la.searchCriteria.startedOnEnd = scope.la.toDate+" 23:59:59";
                if (new Date(scope.la.fromDate) > new Date(scope.la.toDate)) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }
			}else if(scope.la.search == "Completed On"){
				if(scope.la.fromDate == undefined || scope.la.fromDate.trim().length==0 ){
					scope.la.searchCriteria.completedOnFrom = undefined;
					showErrorMessage("Enter Valid From Date");
					return;
				}else
            		scope.la.searchCriteria.completedOnFrom = scope.la.fromDate+" 00:00:00";
            	if(scope.la.toDate == undefined ||scope.la.toDate.trim().length==0 ){
            		scope.la.searchCriteria.completedOnEnd = undefined;
            		showErrorMessage("Enter Valid To Date");
					return;
				}else
            		scope.la.searchCriteria.completedOnEnd = scope.la.toDate+" 23:59:59";
                if (new Date(scope.la.fromDate) > new Date(scope.la.toDate)) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }
			}
			else if(scope.la.search == "Batch ID"){
				if(scope.la.searchtext == '' || scope.la.searchtext == '0'){
					showErrorMessage("Enter id value more than 0.");		
					scope.la.searchtext = '';		
	                return false;
				}
                if (isNaN(scope.la.searchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    scope.la.searchtext = '';	
                    return false;	
    			}
                scope.la.searchCriteria.batchID = scope.la.searchtext;
			}
			scope.la.searchCriteria.pageno = 1;
			scope.la.searchCriteria.pageSize = 7;
			getAllFileActivities(scope.la.searchCriteria);
		}
		if ((event.keyCode == 8 || event.keyCode == 46) && scope.la.searchtext.length == 0) {
			defaultSearchValues();
			scope.la.loadPageDetails(1);
        }
	}
	
	scope.statusSearch = function(status){
		scope.la.searchCriteria.pageSize = 7;
		scope.la.searchCriteria.pageno = 1;
		scope.la.searchCriteria.status = status;
		getAllFileActivities(scope.la.searchCriteria);
	}
	
	
	scope.la.clearSearch = function(){
		scope.la.searchtext = '';
		scope.la.fromDate = '';
		scope.la.toDate = '';
		defaultSearchValues();
		scope.la.loadPageDetails(1);
	}
	
	scope.loadScheduleEvents = function() {		
        $(".scheduleTimeField").datepicker({		
            autoclose: true,		
            todayHighlight: true,		
            //startDate: new Date()		
        });		
    };
    
    scope.$on('listingCriteriaChanged', function () {
    	defaultSearchValues();
    	scope.la.statusArray.statuses = undefined;
		if(scope.adminModule.sortorder == 'descending'){
			scope.la.searchCriteria.orderBy = 'DESC';
		}else{
			scope.la.searchCriteria.orderBy = 'ASC';
		}
		
		if(scope.adminModule.sortby == 'createdon'){
			scope.la.searchCriteria.sortBy = 'fa.createdate';
		}else if(scope.adminModule.sortby == 'name'){
			scope.la.searchCriteria.sortBy = 'fd.name';
		}else if(scope.adminModule.sortby == 'createdby'){
			scope.la.searchCriteria.sortBy = 'fa.createdby';
		}else{
			scope.la.searchCriteria.sortBy = scope.adminModule.sortby;
		}
		getAllFileActivities(scope.la.searchCriteria);
    });
    
    scope.loadScheduleEvents();
	
}]);
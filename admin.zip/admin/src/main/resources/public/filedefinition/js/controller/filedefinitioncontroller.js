zhapp.controller("filedefinitioncontroller",['$scope','$rootScope','fileDefinitionService','$q','$timeout','Blob','FileSaver', function($scope,$rootScope,fileDefinitionService,$q,$timeout,Blob,FileSaver) {
	$scope.editfilemapping = [];
	$scope.fdvo={};
	$scope.fdvo.name = undefined;
	$scope.fdvo.useEncryption = 'Y';
	$scope.fdvo.isFileTrigger = 'Y'; 
	$scope.fdvo.fileFormatSpec ={};
	$scope.fdvo.fileProcessingOptions = {};
	$scope.FileActionMappingVO = {};
	$scope.fdvo.fileScheduleVO = {};
	$scope.fdvo.FileSourceSpecVO = {};
	$scope.ColumnDefinitionVO ={};
	$scope.fdvo.fileFormatSpec.delimiter = undefined;
	$scope.fdvo.fileFormatSpec.textQualifier = undefined;
	$scope.fdvo.fileFormatSpec.headerRowAtLine = undefined;
	$scope.fdvo.fileFormatSpec.dataStartsFromLine = undefined;
	$scope.fdvo.fileFormatSpec.headerInColumn = undefined;
	$scope.fdvo.fileFormatSpec.maxFiles = 1;//undefined;
	$scope.fdvo.fileType = undefined;
	$scope.fdvo.fileProcessingOptions.ignoreBadFiles = 'N';
	$scope.fdvo.fileProcessingOptions.ignoreBadRecords = 'N';
	$scope.fdvo.fileProcessingOptions.preserveOrder = 'N';
	$scope.fdvo.fileProcessingOptions.mergeDuplicates = 'N';
	
	
	$scope.FileActionMappingVO.includeScrubRules = undefined;
	$scope.FileActionMappingVO.enableScrubRules = undefined;
	$scope.FileActionMappingVO.booleanFormat = {};
	$scope.FileActionMappingVO.dateFormat = {};
	$scope.FileActionMappingVO.dateDelimiter = {};
	$scope.FileActionMappingVO.nullValueRepresentation = {};
	$scope.FileActionMappingVO.tableName = undefined;
	$scope.FileActionMappingVO.tableDisposition = undefined;
	/*$scope.FileActionMappingVO.scrubrulesEndingWithText=undefined;*/
	$scope.FileActionMappingVO.columnDefinitionList = [];
	
	$scope.ColumnDefinitionVO.columnName = undefined;
	$scope.ColumnDefinitionVO.columnType = undefined;
	$scope.ColumnDefinitionVO.isCustomColumn = undefined;
	$scope.ColumnDefinitionVO.length = undefined;
	$scope.ColumnDefinitionVO.defaultValue = undefined;
	$scope.ColumnDefinitionVO.isNullable = undefined;
	$scope.ColumnDefinitionVO.columnPositionInFile = undefined;
	$scope.ColumnDefinitionVO.categoryType = undefined;
	$scope.ColumnDefinitionVO.logicalColumnName = undefined;
	$scope.ColumnDefinitionVO.logicalTableName = undefined;
	$scope.notifications = {};
	$scope.notifications.isEnabled = false;
	$scope.notifications.notificationStatuses = [{"isEnabled":false,"name":"Errored"},{"isEnabled":false,"name":"Executing"},
	                                                  {"isEnabled":false,"name":"Completed"},{"isEnabled":false,"name":"Cancelled"}];
	$scope.allnotifications = [{"key":"Errored","name":"Errored"},{"key":"Executing","name":"In - Progress"},
                               {"key":"Completed","name":"Completed"},{"key":"Cancelled","name":"Cancelled"}];
	$scope.fd = {};
	$scope.fdhome = {};
	$scope.fd.emailsCount = 10;
	$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/filedefinitionlist.html";
	$scope.fd.notificationstemp = "filedefinition/templates/listfilenotifications.html";
	$scope.fd.statusArray = [{'key':'W','value':'Waiting'},{'key':'B','value':'Preparing'},{'key':'E','value':'Errored'},{'key':'I','value':'In Progress'},{'key':'C','value':'Completed'},{'key':'U','value':'Waiting to retry'},{'key':'X','value':'Completed'},{'key':'K','value':'In Progress'},{'key' : 'R','value' : 'Waiting'}];
	$scope.fd.activitystatusArray = [ {'key' : 'W','value' : 'Waiting'}, {'key' : 'B','value' : 'Preparing'}, {'key' : 'E','value' : 'Errored'}, {'key' : 'I','value' : 'In Progress'},{'key' : 'C','value' : 'Completed'},{'key' : 'X','value' : 'Completed'},{'key' : 'U','value' : 'Skipped'},{'key' : 'S','value' : 'Cancelled'},{'key' : 'R','value' : 'Waiting'},{'key' : 'P','value' : 'On Hold'},{'key' : 'F','value' : 'Errored'}];
	$scope.fd.isFileUploaded = false;
	
	$scope.getNotificationVal = function(key){
		return $.grep($scope.allnotifications,function(obj){return obj.key == key;})[0].name;
	}
	
	$scope.notificationDetails = function (){
		var deptNotiCriteria = {}
		deptNotiCriteria.departmentId = zhapp.loginUser.departmentID;
		deptNotiCriteria.propertyKey = "NOTIFICATIONS";
		fileDefinitionService.getDepartmentSpecificProperty(deptNotiCriteria).success(function(result){
			if(result && result.objectValue != null && result.objectValue.notifications != null){
				var fileNotifications =  $.grep(result.objectValue.notifications,function(obj){return obj.notificationTypeName == 'Files'})[0];
				if(fileNotifications.isEnabled || $scope.addnewFileFlag){
					$scope.addnewFileFlag=false;
					var actualListNotifications = [];
					angular.forEach(fileNotifications.notificationStatuses,function(obj){
					var selected = $.grep($scope.allnotifications,function(obj1){return obj1.key == obj.name;})[0];
					if(selected){
						actualListNotifications.push(obj);
					}
				});
				fileNotifications.notificationTypeName = undefined;
				fileNotifications.notificationStatuses = actualListNotifications;
				$scope.notifications = fileNotifications;
			}
		  }
    	});
	}
	$scope.notificationdisable = function(val){
		if(val == 'D'){
				$scope.notifications.isEnabled = false;
				$scope.notifications.defaultEmailAddresses = undefined;
				angular.forEach($scope.notifications.notificationStatuses,function(obj){obj.isEnabled = false;obj.emailAddresses = undefined;});
		}else{
			if($scope.savedFiledefinition ==true || $scope.fdobjnotifications){
				$scope.notifications=angular.copy($scope.fdobjnotifications);
				$scope.notifications.isEnabled = true;
				if ($scope.fdobjnotifications.isEnabled===false){
					$scope.addnewFileFlag=false;
					$scope.notificationDetails();
				}
			}else{
				$scope.notifications.isEnabled = true;
				$scope.addnewFileFlag=false;
				$scope.notificationDetails(); // 
			}
		}
	}
	$scope.fd.getAudienceName = function(audienceId){
    	var obj = $.grep($scope.fd.audienceList,function(data){
    		return (data.audienceId == audienceId);
    	});
    	if(obj && obj.length > 0){
    		return obj[0].audienceName;
    	}else{
    		return 'None';
    	}
    }
	
	 $scope.fd.defaultFiledefinitionValues = function(){
		$scope.editfilemapping = [];
	 	$scope.fd.fdMappingVOList = [];
	 	$scope.fd.dbSelectQueryData = undefined;
	 	$scope.fd.dbSelectQuery = undefined;
	 	$scope.fd.createFrom = undefined;
	 	$scope.fd.endingwithtext=undefined;
	 	$scope.fd.changeemail=undefined;
	 	$scope.fd.fdType = "O";
		$scope.fd.includescrubrules = undefined;
		$scope.fd.fileActionType = 'I';
		$scope.fd.getEncryptedKeyList();
		$scope.fd.uploadFileName = undefined;
		$scope.fd.createFromList = [{key:'R',value:'Remote Server'},
		                            {key:'B',value:'Remote DB'},
		                            {key:'L',value:'Local Server'},
		                            {key:'D',value:'Desktop'}];
		
		$scope.fd.fileType = [{key:'B',value:'Base'},
		                      {key:'D',value:'Dimension'},
		                      {key:'R',value:'Resub'},
		                      {key:'U',value:'Unsub'}];
		
		$scope.fd.fileActivites = [];
		
		$scope.fd.tableDispositionList = ['Append','Replace'];
		
		$scope.fd.fileDelimiterList = ['|',',','tab',';'];
		
		$scope.fd.fileTextQualifierList = ['None','\'','\"'];
		
		$scope.fd.nullValue = [{'key': 'NL','value': 'Null'}, {'key': 'ES','value': 'Empty String'}];

	    $scope.fd.booleanFormat = [{'key': 'YESNO','value': 'Yes/No'},
	                               {'key': 'YN','value': 'Y/N'},
	                               {'key': 'TF','value': 'T/F'},
	                               {'key': 'TRFL','value': 'True/False'},
	                               {'key': 'OZ','value': 'One/Zero'}];
	    
	    $scope.fd.dateFormatList = [ {'key':'YMD','value':'YYYY-MM-DD hh:mm:ss'},
		                          {'key':'YMDT','value':'YYYY-MM-DD T hh:mm:ss'},
		                          {'key':'DMY','value':'DD-MM-YYYY hh:mm:ss'},
		                          {'key':'MDY','value':'MM-DD-YYYY hh:mm:ss'},
		                          {'key':'MONDY','value':'MMM-DD-YYYY hh:mm:ss'},
		                          {'key':'DMONY','value':'DD-MMM-YYYY hh:mm:ss'}];
	    
	    $scope.fd.dateDelimiterList = [{'key':' ','value':'Space'},
	                                {'key':'-','value':'-'},
	                                {'key':'/','value':'/'}];
	    
	    $scope.fd.scd = {};
	    $scope.fd.scd.scheduleactivemode = 'N';
	    $scope.fd.frequencies = [{'key': 'I','value': 'Immediately'},
	                             {'key': 'O','value': 'Once Later'},
	                             {'key': 'N','value': 'By Minutes'},
	                             {'key': 'D','value': 'Daily'},
	                             {'key': 'W','value': 'Weekly'},
	                             {'key': 'M','value': 'Monthly'}];

	    $scope.fd.weekDays = [{'key':'S','value':'Sun'},{'key':'M','value':'Mon'},{'key':'T','value':'Tue'},{'key':'W','value':'Wed'},{'key':'H','value':'Thu'},{'key':'F','value':'Fri'},{'key':'U','value':'Sat'}];

	    $scope.fd.monthlyWeeks = [{'key':'F','value':'First'},{'key':'S','value':'Second'},{'key':'T','value':'Third'},{'key':'O','value':'Fourth'},{'key':'L','value':'Last'}];
	    
	    $scope.fd.statusArray = [{'key':'W','value':'Waiting'},{'key':'B','value':'Preparing'},{'key':'E','value':'Errored'},{'key':'I','value':'In Progress'},{'key':'C','value':'Completed'},{'key':'U','value':'Waiting to retry'},{'key':'X','value':'Completed'},{'key':'K','value':'In Progress'}];
	    
		$scope.fd.remote = {};
		$scope.fd.remote.hostList = [];
		
		$scope.fd.db = {};
		$scope.fd.db.sourceList = [];
		$scope.fd.db.tablesList = [];
		$scope.fd.filesInFolder = {};
		$scope.fd.filesInFolder.head = [];
		$scope.fd.filesInFolder.data = [];
		$scope.fd.isEditMode = 'N';	
		$scope.fd.remoteserverlist = undefined;
		$scope.fd.remoteDbList = undefined;
		$scope.fd.scheduleTemplate ="filedefinition/templates/fieldefinitionschedule.html";
		$scope.fd.actionsTemplate = "filedefinition/templates/filedefinitionactions.html";
		$scope.fd.selectedRecord = 0;
		$scope.fd.filePath = undefined;
		$scope.fd.fileNamePattern = undefined;
		$scope.fd.createFromList = $scope.fd.createFromList;
		$scope.fd.scd.timeZoneData = zhapp.timeZoneData;
	 }
	
	 $scope.$on('loadFileDefinition',function(){
		 $scope.fd.searchCriteria = undefined;
		 $scope.fd.initializeFileDefinition();
		 $scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/filedefinitionlist.html";
	 });
	$scope.fd.preInitializeFileDefinition = function(){
		$('.buttons').show();
		$scope.fd.searchtext="";				
		$scope.fd.totalRecords = -1;		
		$scope.fd.currentPageNumber=1;		
		$scope.fd.searchBy = "ID";
		$scope.fd.searchShow = true;		
		$scope.fd.activityShow = true;
		/* email rules un checked bydefault */
		$scope.fd.remrepeatdots = false;
		$scope.fd.remdoublequotes = false;
		$scope.fd.reminvalid = false;
		$scope.fd.remrepeatat = false;
		$scope.fd.removedot = false;
		$scope.fd.changeunderscore = false;
		$scope.fd.removesinglequoteatend = false;
		$scope.fd.removesinglequoteatbegin = false;
		$scope.fd.enclosedoublequotes = false;
		$scope.fd.remwhitespace = false;
		/* sms rules checked bydefault */
		$scope.fd.removeplus = true;
		$scope.fd.removewhitespacesms = true;
		$scope.fd.removeminus = true;
		$scope.fd.department = 'N';
	}
	 
	$scope.fd.initializeFileDefinition= function(){
		$scope.fd.preInitializeFileDefinition();
		var promise = $scope.fd.getAudienceList();
		if($scope.fd.searchCriteria == undefined){
			$scope.fd.searchCriteria = {};		
			$scope.fd.searchCriteria.pageno = 1;		
			$scope.fd.searchCriteria.pagesize = 7;			
			$scope.fd.searchCriteria.sortby="createdate";		
			$scope.fd.searchCriteria.sortorder="DESC";
			$scope.fd.searchCriteria.departmentID = zhapp.loginUser.departmentID;
		}
		var promisefdlist = $scope.fd.listFileDefinitions($scope.fd.searchCriteria);
		promise.then(function(data){
			promisefdlist.then(function(fdList){
				if(fdList.result.length == 0){
					$scope.fd.infoMessage = "No File definitions exists"; 
				}
				angular.forEach(fdList.result,function(key){		
					key.show = true;
				});
				$scope.fd.fileDefinitionList = fdList.result;
				$scope.fd.fileActivites = fdList.activies;		
				if($scope.fd.searchCriteria != undefined){
					$scope.fd.currentPageNumber = $scope.fd.searchCriteria.pageno;
        			$scope.fd.totalRecords = fdList.totalRecords;
				}
				angular.forEach(fdList.activies,function(key,value){		
	    			angular.forEach($scope.fd.fileDefinitionList,function(eachObj){		
	        			if(value == eachObj.fileDefinitionID && key != 0){		
	        				eachObj.isActivity = true;		
	        			}		
	    			});		
				});
			});
		});
		
	}
	
	$scope.fd.openErrorPopUp = function(message){
		showErrorMessage(message);
	}
	$scope.fd.openActivityDialog = function(fileDef){
		fileDefinitionService.openActivityDialog(fileDef.fileDefinitionID).success(function(result){
			if(result){
				var arrayResult = [];
				angular.forEach(result,function(key,value){
					var obj = {};
					//obj.batchId = value;
					obj.activities = key;
					arrayResult.push(obj);
				});
				$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/fileactivityhome.html";
				$scope.fileDef = fileDef;
				$scope.filedefinationActivites = arrayResult;
			}
    	}).error(function(error){
    		showErrorMessage($scope.fd.getErrorMessages(error));
    	});
	}
	
    $scope.fd.initializeSummaryDialog=function(){
    	if($('[aria-describedby="fileSummary"]').size() > 0)
    	   $('[aria-describedby="fileSummary"]').remove();
    	$("#fileSummary").dialog({
			autoOpen: false,
			resizable : false,
			width : 900,
			modal : true,
			closeOnEscape : false
		});
		$(".close-file-summary-popup").click(function(){
			$("#fileSummary").dialog('close');
		});
    }
    
    $scope.fd.openListSummaryDialog=function(fileDefObj){
		$scope.fd.fileSummaryBO=fileDefObj.fileSummaryBO;
		if($scope.fd.fileSummaryBO==null){
			showInfoMessage("Summary doesn't exists for this list.");
		}else{
			$("#fileSummary").dialog('open');
			$scope.fd.fileSummaryBO.audienceName=$scope.fd.getAudienceName(fileDefObj.audienceID);
			if(fileDefObj.fileSource.sourceType==='D')
				$scope.fd.fileSummaryBO.sourceType='Desktop';
			else if(fileDefObj.fileSource.sourceType==='R')
				$scope.fd.fileSummaryBO.sourceType='Remote server';
			else if(fileDefObj.fileSource.sourceType==='B')
				$scope.fd.fileSummaryBO.sourceType='Remote DB';
			else if(fileDefObj.fileSource.sourceType==='L')
				$scope.fd.fileSummaryBO.sourceType='Local Server';
			if(fileDefObj.fileType==='B')
				$scope.fd.fileSummaryBO.fileType='Base';
			else if(fileDefObj.fileType==='D')
				$scope.fd.fileSummaryBO.fileType='Dimension';
			else if(fileDefObj.fileType==='R')
				$scope.fd.fileSummaryBO.fileType='Resub';
			else if(fileDefObj.fileType==='U')
				$scope.fd.fileSummaryBO.fileType='Unsub';
			angular.forEach($scope.fd.statusArray,function(statusObject){
				if(statusObject.key===$scope.fd.fileSummaryBO.status)
					$scope.fd.fileSummaryBO.UIStatus=statusObject.value;
			});
		}
    }
    
    $scope.fd.timeTaken = function(start,end){
		if(start!=null && end!=null){
			var remainder;
			var milliseconds=Math.abs(end-start);
			if(milliseconds!==undefined && milliseconds!==null && milliseconds!==0){
				remainder = milliseconds % (24*60*60*1000);
				var hours=Math.floor((remainder)/(60*60*1000));
				remainder= milliseconds % (60*60*1000);
				var minutes=Math.floor((remainder)/(60*1000));
				remainder= milliseconds % (60*1000);
				var seconds=Math.floor((remainder)/1000);
				hours=hours > 9 ? "" + hours: "0" + hours;
				minutes=minutes > 9 ? "" + minutes: "0" + minutes;
				seconds=seconds > 9 ? "" + seconds: "0" + seconds;
				return hours+":"+minutes+":"+seconds;
			}else{
				return "00:00:00";
			}
		}else{
			return '--';
		}
	}
	
	$scope.fd.activitysearchByValueDates = function(serachValue, fromDate,toDate , event) {
		var activitySearchCri = {};
		activitySearchCri.fileDefinitionID = $scope.fileDef.fileDefinitionID;
		//activitySearchCri.pageno = 1;
		//activitySearchCri.pagesize = 7;
		if (event.type == "click" || event.keyCode == 13) {
			if (serachValue == "Started On") {
				if(fromDate == undefined || fromDate == ""){
					showErrorMessage("Please Select the FromDate.");
			    	return;
				}else if(toDate == undefined || toDate == ""){
					showErrorMessage("Please Select the ToDate.");
			    	return;
				}
			}
			if (serachValue == "Completed On") {
				if(fromDate == undefined || fromDate == ""){
					showErrorMessage("Please Select the FromDate.");
			    	return;
				}else if(toDate == undefined || toDate == ""){
					showErrorMessage("Please Select the ToDate.");
			    	return;
				}
			}
			if (serachValue == "Started On") {
				activitySearchCri.startedFromDate = fromDate;
				activitySearchCri.startedToDate = toDate;
				if(new Date(fromDate) > new Date(toDate)){
			    	showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");
			    	return;
			    }
			} else if (serachValue == "Completed On") {
				activitySearchCri.completedFromDate = fromDate;
				activitySearchCri.completedToDate = toDate;
				if(new Date(fromDate) > new Date(toDate)){
			    	showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");
			    	return;
			    }
			}
			getfileActivityBySearchCriteria(activitySearchCri);
		}
		if (((event.keyCode == 8 || event.keyCode == 46) && activitysearchtext.length == 0)) {
			getfileActivityBySearchCriteria(activitySearchCri);
		}
	}
	
	$scope.fd.activitysearchByValue = function(serachValue, activitysearchtext, event) {
		var activitySearchCri = {};
		activitySearchCri.fileDefinitionID = $scope.fileDef.fileDefinitionID;
		//activitySearchCri.pageno = 1;
		//activitySearchCri.pagesize = 7;
		if (event.type == "click" || event.keyCode == 13) {
			if (serachValue == "ID" || serachValue == "Batch ID") {
				if (activitysearchtext == 0) {
					showErrorMessage("Enter "+activitysearchtext+" value more than 0.");
					return;
				}else if (isNaN(activitysearchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    return;		
                }else {
					if(serachValue == "ID"){
						activitySearchCri.fileActivityID = activitysearchtext;
					}else if(serachValue == "Batch ID"){
						activitySearchCri.batchId = activitysearchtext;
					}
				}
			} else if (serachValue == "File Name") {
				activitySearchCri.fileName = activitysearchtext;
			}else if(serachValue == "Status"){
				var status = $scope.fd.activitystatusArray.filter(function(sta){
					return (sta.value==activitysearchtext);
				})
				if(status[0]==undefined){
					showErrorMessage("Please enter valid status.");
					return false;
				}else activitySearchCri.status=status[0].key;
			}
			getfileActivityBySearchCriteria(activitySearchCri);
		}
		if (((event.keyCode == 8 || event.keyCode == 46) && activitysearchtext.length == 0)) {
			getfileActivityBySearchCriteria(activitySearchCri);
		}
	}
	
	
	function getfileActivityBySearchCriteria(activitySearchCri){
		fileDefinitionService.getfileActivityBySearchCriteria(activitySearchCri).success(function(result){
			if(result){
				var arrayResult = [];
				angular.forEach(result,function(key,value){
					var obj = {};
					obj.activities = key;
					arrayResult.push(obj);
				});
				$scope.filedefinationActivites = arrayResult;
			}
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.openActivityDialogBack = function(){
		$scope.fileDef = undefined;
		$scope.fdvo = undefined;
		$scope.filedefinationActivites = undefined;
		$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/filedefinitionlist.html";
    	$scope.fd.initializeFileDefinition();
	}
	
	$scope.fd.selectAllActivities = function(){
		if($scope.filedefinationActivites == undefined)
			return;
		angular.forEach($scope.filedefinationActivites,function(obj){
			angular.forEach(obj.activities,function(obj){
				obj.checked = true;
			});
		});
	}
	
	$scope.fd.clearAllActivities = function(){
		if($scope.filedefinationActivites == undefined)
			return;
		angular.forEach($scope.filedefinationActivites,function(obj){
			angular.forEach(obj.activities,function(obj){
				obj.checked = false;
			});
		});
	}
	$scope.fd.loadPageDetailsAllActivities = function(){
		var activitySearchCri = {};
		activitySearchCri.fileDefinitionID = $scope.fileDef.fileDefinitionID;
		getfileActivityBySearchCriteria(activitySearchCri);
	}
	
	$scope.fd.retryCancelActivities = function(status,filedefinationId){
		
		if($scope.filedefinationActivites == undefined)
			return;
		var finalAct = [];
		angular.forEach($scope.filedefinationActivites,function(obj){
			var selected = $.grep(obj.activities,function(obj){
				return obj.checked == true && obj.status == 'E';
			});
			if(selected.length>0){
				angular.forEach(selected,function(obj){
					finalAct.push(obj);
				});
			}
		});
		if(finalAct.length == 0){
			showErrorMessage("Select atleast one errored activity.");
			return;
		}else{
			var input = "";
			angular.forEach(finalAct,function(obj){
				input = input + obj.fileActivityID + ",";
			});
			if(input == "") return;
			fileDefinitionService.updatefiledefinitionactivitystatus(input.substring(0,input.length-1),status,filedefinationId).success(function(result){
				var activitySearchCri = {};
				activitySearchCri.fileDefinitionID = $scope.fileDef.fileDefinitionID;
				getfileActivityBySearchCriteria(activitySearchCri);
			}).error(function(error){
				showErrorMessage($scope.fd.getErrorMessages(error));
			});
		}
	}
	
$scope.fd.retryCancelActivities = function(status){
		if($scope.filedefinationActivites == undefined)
			return;
		var finalAct = [];
		angular.forEach($scope.filedefinationActivites,function(obj){
			var selected = $.grep(obj.activities,function(obj){
				return obj.checked == true && obj.status == 'E';
			});
			if(selected.length>0){
				angular.forEach(selected,function(obj){
					finalAct.push(obj);
				});
			}
		});
		if(finalAct.length == 0){
			showErrorMessage("Select atleast one errored activity.");
			return;
		}else{
			var input = "";
			angular.forEach(finalAct,function(obj){
				input = input + obj.fileActivityID + ",";
			});
			if(input == "") return;
			fileDefinitionService.updateFileActivitystatus(input.substring(0,input.length-1),status).success(function(result){
				var activitySearchCri = {};
				activitySearchCri.fileDefinitionID = $scope.fileDef.fileDefinitionID;
				getfileActivityBySearchCriteria(activitySearchCri);
			}).error(function(error){
				showErrorMessage($scope.fd.getErrorMessages(error));
			});
		}
	}
	
	$scope.downloadFileActivityLogFiles = function(loadActivity){
		var promise = fileDefinitionService.createzipfile(loadActivity).success(function(result){
			var req = new FormData();
			req.append("zipFilePath", result.response);
			fileDefinitionService.downloadFileActivityLogFiles(req).success(function(result1){
				 var data = new Blob([result1], { type: 'application/zip;charset=utf-8' });
				 FileSaver.saveAs(data, result.response.substring(result.response.lastIndexOf("/")+1,result.response.length));
    		}).error(function(error){
    			showErrorMessage($scope.fd.getErrorMessages(error));
    		});
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	
	$scope.fd.loadPageDetails = function(pageno){		
		$scope.fd.searchCriteria.pageno = pageno;		
		$scope.fd.currentPageNumber=pageno;
			if($scope.fd.fromDate !== undefined && $scope.fd.toDate !== undefined){
				$scope.searchByValue($scope.fd.searchtext,event.type);
			}else{
		var searchCriteria = angular.copy($scope.fd.searchCriteria);
		if($scope.fd.searchtext != undefined && $scope.fd.searchtext != ""){
			if ($scope.fd.searchBy == "ID") {		
	            if ($scope.searchtext == 0) {		
	                showErrorMessage("Enter id value more than 0.");		
	                $scope.searchtext = '';		
	                return false;		
	            }		
	            if (isNaN($scope.searchtext)) {		
	                showErrorMessage("Please Enter Numeric Values Only .");		
	                $scope.searchtext = '';		
	                return;		
	            } else {		
	                searchCriteria.id = $scope.searchtext;		
	            }		
	        } else if ($scope.fd.searchBy == "Name") {		
	            searchCriteria.namelike = $scope.searchtext;		
	        } else if ($scope.fd.searchBy == "Max Files") {		
	            if (isNaN($scope.searchtext)) {		
	                showErrorMessage("Please Enter Numaric Values Only .");		
	                $scope.searchtext = '';		
	                return;		
	            } else {		
	                searchCriteria.maxFiles = $scope.searchtext;		
	            }		
	        } else if ($scope.fd.searchBy == "Ignore Bad") {		
	            searchCriteria.ignorebadfiles = $scope.searchtext;		
	            if ($scope.searchtext != "Y" && $scope.searchtext != "N" && $scope.searchtext != "y" && $scope.searchtext != "n") {		
	                showErrorMessage("Please Enter Y or N only.");		
	                return;		
	            }		
	        } else if ($scope.fd.searchBy == "Created On") {		
	        	searchCriteria.createdFromDate = new Date($scope.fd.fromDate);
                searchCriteria.createdToDate = new Date($scope.fd.toDate);
                if (searchCriteria.createdFromDate > searchCriteria.createdToDate) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }	
	        } else if ($scope.fd.searchBy == "Last Modified") {		
	        	searchCriteria.updatedFromDate = new Date($scope.fd.fromDate);
                searchCriteria.updatedToDate = new Date($scope.fd.toDate)		
                if (searchCriteria.updatedFromDate > searchCriteria.updatedToDate) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }
	        }
		}
		searchCriteria.departmentID = zhapp.loginUser.departmentID;
		var prmoise = $scope.fd.listFileDefinitions(searchCriteria);
		prmoise.then(function(fdList){		
			angular.forEach(fdList.result,function(key){				
				key.show = true;		
			});		
			$scope.fd.fileDefinitionList = fdList.result;		
			$scope.fd.fileActivites = fdList.activies;				
			// console.log(JSON.stringify($scope.fd.fileActivites));
			angular.forEach(fdList.activies,function(key,value){				
    			angular.forEach($scope.fd.fileDefinitionList,function(eachObj){				
        			if(value == eachObj.fileDefinitionID && key != 0){				
        				eachObj.isActivity = true;				
        			}				
    			});				
			});		
		});
			}
	}
	
	
	$scope.fd.fileTypeChange = function(){
		if($scope.fd.fdType == 'R'){
			$scope.fd.createFromList = $.grep($scope.fd.createFromList,function(obj){return obj.key != 'D'});
			$scope.fd.scd.frequency = 'N';
		}else{
			$scope.fd.createFromList = [{key:'R',value:'Remote Server'},
			                            {key:'B',value:'Remote DB'},
			                            {key:'L',value:'Local Server'},
			                            {key:'D',value:'Desktop'}];
			$scope.fd.createFromList = $scope.fd.createFromList;
			$scope.fd.scd.frequency = 'I';
		}
	}
	
	$scope.fd.intializeCal = function(){
		$('.datepicker123').datepicker({
			format: 'mm-dd-yyyy',
			autoclose : true
			});
		$('#timepicker1').timepicker();
	}
	
	$scope.fd.addNewFileDefinition = function(){
		$scope.savedFiledefinition=false;
		$scope.fdobjnotifications=undefined;
		$scope.notifications=undefined;
		$scope.editfilemapping = [];
		$scope.fdobjnotifications=undefined;
		$scope.fd.defaultFiledefinitionValues();
		$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/neworeditfiledefinition.html";
		$scope.fdvo = {};
		$scope.fdvo.sendWorkFlow = 'N';
		$scope.fdvo.channelType = 'E';
		$scope.fdvo.useEncryption = 'N';
		$scope.fdvo.isFileTrigger = 'N';
		$scope.fd.global = 'Y';
		$scope.fd.ignoreEmail = 'Y';
		$scope.fd.HardBounce = 'Y';
		$scope.fd.SoftBounce = 'Y';
		$scope.fd.BlockBounce = 'Y';
		$scope.fd.UnknownBounce = 'Y';
		$scope.fd.departmentList = [];
		$scope.fdvo.fileDefinitionID = undefined;
		$scope.fdvo.fileScheudleID = undefined;
		$scope.fdvo.tableDisposition = $scope.fd.tableDispositionList[0];
		$scope.FileActionMappingVO = {};
		$scope.FileActionMappingVO.nullValueRepresentation = $scope.fd.nullValue[0].key;
		$scope.FileActionMappingVO.dateFormat = $scope.fd.dateFormatList[0].key;
		$scope.FileActionMappingVO.dateDelimiter = $scope.fd.dateDelimiterList[0].key;
		$scope.fd.searchBy = $scope.fd.searchByValues[0];
		$scope.fdvo.fileProcessingOptions = {};
		$scope.fdvo.fileProcessingOptions.ignoreBadFiles = 'N';
		$scope.fdvo.fileProcessingOptions.ignoreBadRecords = 'N';
		$scope.fdvo.fileProcessingOptions.preserveOrder = 'N';
		$scope.fdvo.fileProcessingOptions.mergeDuplicates = 'N';
		$scope.fdvo.timeZone = zhapp.loginUser.timeZone;
		$scope.fd.fdListForClone = [];
		$scope.fd.getAllFileDefinitionList();
		$scope.addnewFileFlag=true;
		$scope.notificationDetails();
		$scope.fd.setTimezone();
	}
	
	
	$scope.resetOnTimeZoneChange=function(){
		$scope.fd.scd.startDate =  zhapp.getCnvDateTime('D',null, $scope.fd.scd.timezone);    			
		$scope.fd.scd.startTime =  zhapp.getCnvDateTime('T',null, $scope.fd.scd.timezone);
		$scope.fd.scd.endDate = $scope.fd.scd.startDate;  
    };	
	$scope.fd.setTimezone = function(){
		$scope.fd.scd.timezone = zhapp.loginUser.timeZone;
		$scope.resetOnTimeZoneChange();
    	$scope.fd.scd.frquencyunit = 0;
    	$scope.fd.scd.dayofeverymonth = 0;
    	$scope.fd.scd.monthlyWeekFreq = $scope.fd.monthlyWeeks[0];
    	$scope.fd.scd.monthlyDayFreq = $scope.fd.weekDays[0];
	}
	
	$scope.fd.resetOnChange = function(){
		$scope.fd.setTimezone();
	}
	
	$scope.fd.getAllFileDefinitionList = function(){
		var list = [];
		var seachcriteria = {};
		seachcriteria.departmentID = zhapp.loginUser.departmentID;
		fileDefinitionService.getAllFileDefintionList(seachcriteria).success(function(result){
			var temp = {};
			temp.key = -1;
			temp.value = "None";
			list.push(temp);
			angular.forEach(result,function(obj,index){
				var temp = {};
				temp.key = index;
				temp.value = obj;
				list.push(temp);
			});
			$scope.$evalAsync(function(){
				$scope.fd.fdListForClone = list;
				$scope.fd.selctedFdForClone = list[0].key;
			});
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.cloneFileDefintion = function(){
		if($scope.fd.selctedFdForClone == undefined){
			return;
		}
		if($scope.fd.selctedFdForClone == -1){
			$scope.fdvo.name = $scope.fdvo.name;
			$scope.fd.fdType = "O";
			$scope.fdvo.fileType = undefined;
			$scope.fd.createFrom = undefined;
			$scope.fdvo.fileFormatSpec = {};
			$scope.fdvo.fileProcessingOptions = {};
			$scope.fd.fdMappingVOList = [];
		 	$scope.fd.dbSelectQueryData = undefined;
		 	$scope.fd.dbSelectQuery = undefined;
		 	$scope.fd.createFrom = undefined;
			$scope.fd.includescrubrules = undefined;
			$scope.fd.fileActionType = 'I';
			$scope.fd.uploadFileName = undefined;
			$scope.fdvo.tableName = undefined;
			$scope.fd.selectedStaggingTable = undefined;
			$scope.fdvo.tableDisposition = $scope.fd.tableDispositionList[0];
			$scope.fdvo.sendWorkFlow = 'N';
			$scope.fdvo.workFlowID = undefined;
			if($scope.notifications)
				$scope.notifications.isEnabled = false;
			$scope.fdvo.isFileTrigger = 'N';
			$scope.fdvo.maxFiles = 1;//undefined;
			return;
		}
		$scope.fd.defaultFiledefinitionValues();
		var criteria = {};
		criteria.filedefinitionId = $scope.fd.selctedFdForClone;
		criteria.departmentID = zhapp.loginUser.departmentID;
		fileDefinitionService.listFileDefinitions(criteria).success(function(result){
			if(result.result && result.result.length > 0){
				var obj = result.result[0];
				obj.fileDefinitionID = 0;
				obj.fileScheduleBO.fileDefinitionID = 0;
				obj.fileScheduleBO.fileScheudleID = 0;
				obj.name=$scope.fdvo.name;
				if(obj.fileSource.sourceType == 'L'){
					obj.fileSource.folderPath= undefined;
					obj.fileSource.filePath=undefined;
				}
				if(obj.fileSource.sourceType == 'D'){
					obj.fileMapping.columnDefinitionList = [];
				}
				$scope.fd.editFileDefinition(obj);
				$scope.fd.isEditMode = 'N';
			}else{
				showErrorMessage('Unable to clone file definition.');
			}
			
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.createFromChange = function(){
		$scope.fd.fdMappingVOList = [];
		$scope.fd.remote = {};
		$scope.fd.db = {};
		$scope.fd.dbSelectQuery = undefined;
		$scope.fd.dbSelectQueryData = undefined;
		if($scope.fd.createFrom == 'R'){
			$scope.fd.getHostList();
		}else if($scope.fd.createFrom == 'B'){
			$scope.fd.getDbSorceList();
		}
		if($scope.fd.createFrom != 'R'){
			$scope.fdvo.useEncryption = 'N';
			$scope.fdvo.encryptionKey = undefined;
		}
	}
	
	$scope.fd.changeHostServer = function(){
		$scope.fd.fdMappingVOList = [];
		$scope.fd.remote.currentFolderselected = '/';
		$scope.fd.remote.currentFolderselectedFile = '/';
		$scope.fd.remote.remoteFolderList = undefined;
	}
	
	
	$scope.fd.getFoldersForRemoteServer = function(){
		if($scope.fd.remote.hostServer == null || $scope.fd.remote.hostServer == undefined){
			alert("Select Host server");
			return;
		}
		var username = $scope.fd.remote.hostServer.username;
		$scope.fd.remote.hostServer.currentPath = '/';
		$scope.fd.remote.remoteFolderList = listRemoteServerFolders($scope.fd.remote.hostServer.fileSourceName,false,$scope.fd.remote.hostServer.currentPath);
		$scope.fd.remote.currentFolderselected = $scope.fd.remote.hostServer.currentPath;
		$scope.fd.remote.currentFolderselectedFile = $scope.fd.remote.hostServer.currentPath;
	}
	
	$scope.fd.loadRemoteFolders = function(){
		var isValidPath=$scope.fd.checkValidPath();
		if (!isValidPath){
			showErrorMessage("Path should not contain double slash'//' ");
			return;
		}
		if($scope.fd.remote.hostServer.protocol == "http" || $scope.fd.remote.hostServer.protocol == "https")return;
//		if(!$scope.fd.remote.currentFolderselected)
//			return;
//		var username = $scope.fd.remote.hostServer.username;
		//$scope.fd.remote.hostServer.currentPath = '/';
		$scope.fd.remote.remoteFolderList = listRemoteServerFolders($scope.fd.remote.hostServer.fileSourceName,false,$scope.fd.remote.currentFolderselected);
	}
	$scope.fd.checkValidPath = function(){
	var flag=true;
	var path=$scope.fd.remote.currentFolderselected;
	var pattern= new RegExp(/\/\//);
	if((path.search(pattern))>-1){
		flag =false;
		return flag;
	}
	return flag;
	}
	$scope.fd.selectFolder = function(folderName){
		if($scope.fd.remote.currentFolder.lastIndexOf('/') == $scope.fd.remote.currentFolder.length-1){
			if(folderName.lastIndexOf('.') != -1){
				$scope.fd.remote.currentFolderselectedFile = $scope.fd.remote.currentFolder+folderName;
			}else{
				$scope.fd.remote.currentFolderselected = $scope.fd.remote.currentFolder+folderName;
				$scope.fd.remote.currentFolderselectedFile = $scope.fd.remote.currentFolder+folderName;
			}
		}else{
			if(folderName.lastIndexOf('.') != -1){
				$scope.fd.remote.currentFolderselectedFile = $scope.fd.remote.currentFolder+"/"+folderName;
			}else{
				$scope.fd.remote.currentFolderselected = $scope.fd.remote.currentFolder+"/"+folderName;
				$scope.fd.remote.currentFolderselectedFile = $scope.fd.remote.currentFolder+"/"+folderName;
			} 
		}
		$('#remotefilelist li').each(function(){
		    if($(this).text() === folderName)
		    	$(this).css("background-color","#d6e1e6");
		    else
		    	$(this).css("background-color","");
		});
	}
	
	function listRemoteServerFolders(fileSoruceName,isTest,currentPath){
		var d = $q.defer();
		var list = [];
		fileDefinitionService.getFoldersFromRemoteServer(fileSoruceName,isTest,currentPath).success(function(result){
			$scope.fd.remote.remoteFolderList = result;
			$scope.fd.remote.currentFolder = currentPath;
			$scope.fd.remote.currentFolderselected = currentPath;
			d.resolve();
		}).error(function(error){
			$scope.fd.remote.currentFolder = undefined;
			if(error.errors[0].message.startsWith("FL0067 : Loading")){
				showErrorMessage("Loading the files list has failed due to an invalid file/directory. Check the input file path and permissions.");
			}else
				showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	$scope.fd.showDbTables = function(){
		var d = $q.defer();
		if($scope.fd.db.dbSource == null || $scope.fd.db.dbSource == undefined){
			alert("select source");
		}
		fileDefinitionService.getDbTablesList($scope.fd.db.dbSource.dbSourceName).success(function(result){
			$scope.fd.db.tablesList = result;
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	$scope.fd.getHostList = function(){
		var d = $q.defer();
		var listCriteria = {};
		fileDefinitionService.listFilesources(listCriteria).success(function(result){
			$scope.fd.remote.hostList = result;
			if($scope.fd.remote.hostList && $scope.fd.remote.hostList.length == 0){
				showErrorMessage("No remote hosts created yet.");
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	$scope.fd.getDbSorceList = function(){
		var d = $q.defer();
		fileDefinitionService.getDbSourceList().success(function(result){
			$scope.fd.db.sourceList = result;
			if($scope.fd.db.sourceList && $scope.fd.db.sourceList.length == 0){
				showErrorMessage("No remote db sources created yet.")
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	
	function sortAudienceList(result){
		var noEmailSms = $.grep(result,function(obj){
			return !(obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var emailSms = $.grep(result,function(obj){
    		return (obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var sorted = noEmailSms.sort(function(a, b){
			if(a.audienceName.toLowerCase() < b.audienceName.toLowerCase()) return -1;
			if(a.audienceName.toLowerCase() > b.audienceName.toLowerCase()) return 1; return 0;
			});
		var finalAudience = [];
		angular.forEach(emailSms,function(obj){
			finalAudience.push(obj);
		});
		angular.forEach(sorted,function(obj){
			finalAudience.push(obj);
		});
		return finalAudience;
	}
	
	$scope.fd.getAudienceList = function(){
		  var d = $q.defer();
		fileDefinitionService.getAudienceList().success(function(result){
				if(result != null && result != undefined && result.length > 0){
					fileDefinitionService.getDeptAudienceList(zhapp.loginUser.departmentID).then(function(data){
		 				if(data.data && data.data.length > 0){
		 					var audienceInfo = [];
		 					angular.forEach(data.data,function(deptAud){
		 						angular.forEach(result,function(totAud){
		 							  if(totAud.audienceId == deptAud.audienceId){
		 								audienceInfo.push(totAud);
		 							  }
		 						});
		 					});
		 					$scope.fd.audienceList = sortAudienceList(audienceInfo);
		 					d.resolve($scope.fd.audienceList);
		 				}else{
		 					showErrorMessage("No audience created yet...");
		 				}
		 			},function(error){
		 				showErrorMessage($scope.fd.getErrorMessages(error));
		 				d.reject(false);
		 			});
				}else{
					showErrorMessage("No audience created yet...");
				}
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject(false);
		});
		return d.promise;
	}
	
	$scope.fd.getEncryptionKeys = function(){
		fileDefinitionService.getEncryptionKeysList().success(function(result){
			if(result != null && result != undefined && result.length > 0){
				$scope.fd.encryptionKeysList = result;
			}else{
				showErrorMessage("No encryption keys exists.");
			}
			
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	

	
	$scope.fd.getSelectQuery = function(tableName){
		$scope.fd.selectedTableName = tableName;
		fileDefinitionService.getSelectQuery($scope.fd.db.dbSource.dbSourceName,tableName).success(function(result){
			$scope.fd.dbSelectQuery = result.query;
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.executeSelectQuery = function(type){
		var d = $q.defer();
		fileDefinitionService.executeSelectQuery($scope.fd.db.dbSource.dbSourceName,$scope.fd.dbSelectQuery).success(function(result){
			if(type == 'S'){
				$scope.fd.dbSelectSampleQueryData = result;
				$(".filedef-remotedb-sample-popup").dialog('open');
			}else if(type == 'E'){
				if($scope.fdvo.fileType == 'B'){
					if($scope.fd.selectedAudience == undefined){
						showErrorMessage("Please Select Audience");
						return;
					}
				}
				$scope.fd.dbSelectQueryData = result;
				prepareMappingDataForDbSource(result);
			}
			$scope.fd.selectedMappingScreen ='Data Mappings';
//			$scope.fd.enableDataMapping = true;
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	
	function prepareMappingDataForDbSource(data){
		$scope.showLoadingDiv = true;
		$scope.fd.fdMappingVOList = [];
		var temp = [];
		angular.forEach(data,function(obj,index){
			if(index == 0){
				angular.forEach(obj,function(childObj){
					var res = {};
					res.key = childObj;
					temp.push(res);
				});
			}
		});
		var data1 = data.slice(1,data.length);
		angular.forEach(data1,function(obj,index){
			angular.forEach(obj,function(childObj,index2){
				var res = temp[index2];
				if(res && res.values){
					res.values.push(childObj);
				}else{
					var values = [];
					values.push(childObj);
					res.values = values;
				}
			});
		});
		setTimeout(function(){
			$.each(temp,function(index,value){
				fileDefMappingVO = {};
				fileDefMappingVO.header = value.key;
				fileDefMappingVO.sampleDataColumns = value.values;
				fileDefMappingVO.sampleDataColumn = value.values[0];
				if($scope.fdvo.fileType == 'R' || $scope.fdvo.fileType == 'U'){
					if($scope.fdvo.channelType == 'E'){
					var selected = $.grep($scope.fd.dataTypes,function(obj){
						return obj.key == 7;
					});
					fileDefMappingVO.dataTypeList = selected;
					}else if($scope.fdvo.channelType == 'S'){
						var selected = $.grep($scope.fd.dataTypes,function(obj){
							return obj.key == 8;
						});
						fileDefMappingVO.dataTypeList = selected;
						}
				}else{
					fileDefMappingVO.dataTypeList = $scope.fd.dataTypes;
				}
				if($scope.fd.audienceColumns != undefined){
					fileDefMappingVO.audienceColumn = $.grep($scope.fd.audienceColumns,function(obj){
						return obj.logicalColumnName == 'Omit';
					})[0];
				}
				fileDefMappingVO.length = 400;
				fileDefMappingVO.disableLength = true;
				fileDefMappingVO.isNullable = 'N';
				$scope.fd.fdMappingVOList.push(fileDefMappingVO);
			});
			mapDefaultColumnsData();
		},1000);
	}
	
	
	$scope.fd.fileChange = function(){
	}
	
	$scope.fd.getDataTypes = function(){
		$scope.fd.dataTypes = [];
		fileDefinitionService.getDataTypes().success(function(result){
			var temp = [];
			angular.forEach(result,function(obj){
				var d = {};
				if(obj.columnType == 'ASCIISTRING'){
					d.key = 20;
				}else if(obj.columnType == 'UNICODESTRING'){
					d.key = 21;
				}else{
					d.key = obj.columnDataType;
				}
				d.value = obj.columnType;
				temp.push(d);
			});
			$scope.fd.dataTypes = temp;
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.getDataTypes();
	
	$scope.fd.audienceColumns = [];
	
	$scope.fd.getAudienceColumns = function(audience,fdobj){
		var d = $q.defer();
		fileDefinitionService.getAudienceColumns(audience.audienceId).success(function(result){
			if(result != null && result != undefined && result.length > 0){
				$scope.fd.audienceColumns = result;
			}else{
				showErrorMessage("no audience columns exists");
				return;
			}
			angular.forEach($scope.fd.audienceColumns,function(obj){
				obj.CustomType ='Audience';
			});
			var obj = {};
			obj.logicalColumnName='Omit';
			obj.physicalColumnName=null;
			obj.isProfilable=null;
			obj.columnDataType = null;
			obj.isKeyColumn=null;
			obj.CustomType ='Audience';
			$scope.fd.audienceColumns.push(obj);
			obj = {};
			obj.logicalColumnName="Is Custom";
			obj.physicalColumnName="custom";
			obj.isProfilable='N';
			obj.columnDataType = 0;
			obj.isKeyColumn='N';
			obj.CustomType ='custom';
			$scope.fd.audienceColumns.push(obj);
			$scope.fd.fdMappingVOList = [];
			addCustomAudienceForEdit(fdobj,d);
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	function getVerticaDbTableColumns(tableName){
		var d = $q.defer();
		fileDefinitionService.getVerticaDbTableColumns(tableName).success(function(result){
			d.resolve(result);
		}).error(function(error){
			d.reject();
		});
		return d.promise;
	}
	
	function prepareCustomAudienceForEdit(data){
		if($scope.fd.audienceColumns){
			var finalData = [];
			angular.forEach(data,function(obj){
				var finalAud = $scope.fd.audienceColumns.slice(0,$scope.fd.audienceColumns.length-2);
				var available = false;
				angular.forEach(finalAud,function(aud){
					if(!available && (obj.isNullable == 'N') && aud.physicalColumnName && (obj.physicalColumnName != aud.physicalColumnName) && (obj.physicalColumnName != 'AUDIENCE_MEMBER_ID') && (obj.physicalColumnName != 'ISNEW_2')){
						var bo = $.grep($scope.editfilemapping,function(editBo){return editBo.isCustomColumn == 'Y' && editBo.physicalColumnName.toUpperCase() == obj.physicalColumnName.toUpperCase();});
						if(bo && bo.length > 0){available = true;finalData.push(bo[0]);}
					}
				});
			});
			if(finalData && finalData.length > 0){
				angular.forEach(finalData,function(obj){
					var res = {};
					res.logicalColumnName=obj.logicalColumnName;
					res.physicalColumnName=obj.physicalColumnName;
					res.isProfilable='N';
					var column = $.grep($scope.fd.dataTypes,function(val1){return val1.value == obj.columnType})[0];
					if(column)
						res.columnDataType = column.key;
					else
						res.columnDataType = 0;
					res.dataType = column;
					res.isKeyColumn='N';
					res.CustomType ='custom';
					res.isUsed = true;
					$scope.fd.audienceColumns.push(res);
				});
			}
		}
	}
	
	function addCustomAudienceForEdit(fdobj,d){
		if($scope.fd.isEditMode == 'Y' && $scope.fdvo.fileType == 'B' && fdobj.status && fdobj.tableName && fdobj.tableName != '' &&(fdobj.status== 'E' || fdobj.status== 'C')){
			var promise  = getVerticaDbTableColumns(fdobj.tableName);
			promise.then(function(data){
				if(data && data.length > 0)
					prepareCustomAudienceForEdit(data);
				d.resolve();
			});
		}else{
			d.resolve();
		}
	}
	
	$scope.fd.channelTypeChange = function(){
		if($scope.fdvo.fileType == 'R' || $scope.fdvo.fileType == 'U'){
			$scope.fd.fdMappingVOList = [];
		}
	}
	
	$scope.browseFile = function(){
        $("#filedefuploadBtn").trigger('click');
	}
	
	function validateFileSpecsOnUploadClick(){
		if(filedefuploadBtn.files[0] == undefined){
			showErrorMessage("Please select the file to upload");
    		return;
    	}
		var fileExt = filedefuploadBtn.files[0].name.substr(filedefuploadBtn.files[0].name.lastIndexOf('.') + 1);
		if(!(fileExt == "txt" || fileExt == "csv")){
    		showErrorMessage("Please select txt or csv file");
    		return;
    	}
		if($scope.fdvo.fileFormatSpec == undefined){
    		showErrorMessage("Please select the Format specification");
    		return;
    	}
		if($scope.fdvo.fileFormatSpec.delimiter == undefined){
    		showErrorMessage("Please select the File delimiter");
    		return;
    	}
    	if($scope.fdvo.fileFormatSpec.textQualifier == undefined){
    		showErrorMessage("Please select the Text qualifier");
    		return;
    	}
    	
    	if( isNaN(parseInt($scope.fdvo.fileFormatSpec.headerRowAtLine)) || $scope.fdvo.fileFormatSpec.headerRowAtLine < 0){
    		showErrorMessage("Provide header row value.");
    		return;
    	}
		if( isNaN(parseInt($scope.fdvo.fileFormatSpec.dataStartsFromLine)) || $scope.fdvo.fileFormatSpec.dataStartsFromLine < 0){
    		showErrorMessage("Provide data starts row value.");
    		return;
    	}
    	if( $scope.fdvo.fileFormatSpec.headerRowAtLine >= $scope.fdvo.fileFormatSpec.dataStartsFromLine ){
    		showErrorMessage("Header row value can not be greater than or equal to data row value.");
    		return;
    	}
    	return true;
	};
	
	
	$scope.fd.uploadOnNextClick = function(){
		if(!validateFileSpecsOnUploadClick())
			return;
		var hubListForData = new FormData();
        hubListForData.append("file", filedefuploadBtn.files[0]);
        hubListForData.append("headerStart", $scope.fdvo.fileFormatSpec.headerRowAtLine);
        hubListForData.append("dataStart", $scope.fdvo.fileFormatSpec.dataStartsFromLine);
        hubListForData.append("delimiter", $scope.fdvo.fileFormatSpec.delimiter);
        hubListForData.append("textQualifier", $scope.fdvo.fileFormatSpec.textQualifier);
        fileDefinitionService.uploadFileContent(hubListForData).success(function(result){
        	$scope.showLoadingDiv = true;
        	if(result == null || result == undefined){
        		showErrorMessage("File is empty.");
        		return;
        	}
        	$scope.fd.isFileUploaded = true;
        	$scope.fd.fdMappingVOList = [];
        	var selected = [];
        	if($scope.fdvo.fileType == 'R' || $scope.fdvo.fileType == 'U'){
				if($scope.fdvo.channelType == 'E'){
					selected = $.grep($scope.fd.dataTypes,function(obj){
						return obj.key == 7;
					});
				}else if($scope.fdvo.channelType == 'S'){
					selected = $.grep($scope.fd.dataTypes,function(obj){
						return obj.key == 8;
					});
				}
			}else{
				selected = $scope.fd.dataTypes;
			}
        	var audienceColumn = [];
        	if($scope.fd.audienceColumns != undefined){
    			audienceColumn = $.grep($scope.fd.audienceColumns,function(obj){
    				return obj.logicalColumnName == 'Omit';
    			})[0];
			}
        	setTimeout(function(){
        		$.each(result,function(index,value){
        			fileDefMappingVO = {};
        			fileDefMappingVO.header = value.key;
        			fileDefMappingVO.sampleDataColumns = value.values;
        			fileDefMappingVO.sampleDataColumn = value.values[0];
        			fileDefMappingVO.dataTypeList = selected;
        			fileDefMappingVO.audienceColumn = audienceColumn;
        			fileDefMappingVO.length = 400;
        			fileDefMappingVO.disableLength = true;
        			fileDefMappingVO.isNullable = 'N';
        			$scope.fd.fdMappingVOList.push(fileDefMappingVO);
        		});
        		mapDefaultColumnsData();        		
        	},1000);
    		
        }).error(function(error){
        	showErrorMessage($scope.fd.getErrorMessages(error));
        });
	}
	
	$scope.fd.headerAndDataRowValidation = function(type){   
		var headerMax = 10;
		var headerMin = 0;
		var value = undefined;
		if(type == 'H'){
			value = $scope.fdvo.fileFormatSpec.headerRowAtLine;
		}else if(type == 'D'){
			value = $scope.fdvo.fileFormatSpec.dataStartsFromLine;
		}
		if(isNaN(value) || value < 0){
			showInfoMessage("value should be numeric and not negative.");
			if(type == 'H'){
				$scope.fdvo.fileFormatSpec.headerRowAtLine = undefined;
			}else if(type == 'D'){
				$scope.fdvo.fileFormatSpec.dataStartsFromLine = undefined;
			}
			return;
		}
    	if(type == 'H' && value > headerMax-1) {
    		showInfoMessage("Maximum allowed value is 9.");
    		$scope.fdvo.fileFormatSpec.headerRowAtLine = 9; 
    		return;
    	}
    	if(type == 'D' && value >= headerMax) {
    		showInfoMessage("Maximum allowed value is 10.");
    		$scope.fdvo.fileFormatSpec.dataStartsFromLine = 10; 
    		return;
    	}
    	if(!isNaN(parseInt($scope.fdvo.fileFormatSpec.headerRowAtLine)) && !isNaN(parseInt($scope.fdvo.fileFormatSpec.dataStartsFromLine)) && $scope.fdvo.fileFormatSpec.headerRowAtLine >= $scope.fdvo.fileFormatSpec.dataStartsFromLine){
    		showInfoMessage("Data starts from value should be greater than header starts from value.");
    		$scope.fdvo.fileFormatSpec.dataStartsFromLine = parseInt($scope.fdvo.fileFormatSpec.headerRowAtLine)+1; 
    		return;
    	}
    	/*if(type == 'M' && value > 99999) {
    		showInfoMessage("Maximum allowed value is 99999.");
    		$scope.fdvo.maxFiles = 99999; 
    		return;
    	}*/
    };
	$scope.fd.mappingAudienceToDatType = function(index,audienceColumn){
		var obj = $scope.fd.fdMappingVOList[index];
		obj.disableSelect = false;
		
		if($scope.fdvo.fileType == 'B' && ($scope.fd.selectedAudience.audienceType != 0 && obj.audienceColumn.CustomType == 'custom')){
			var list = $.grep(obj.dataTypeList,function(data){
				return (data.value != 'EMAIL' && data.value != 'SMS');
			});
			obj.dataTypeList = list;
		}else{
			obj.dataTypeList = $scope.fd.dataTypes;
		}
		if(obj.audienceColumn != null && obj.audienceColumn.logicalColumnName =='Omit'){
			obj.enableEmailAddress = false;
			obj.enableSmsAddress = false;
			obj.disableSelect = true;
			obj.dataType=undefined;
			return;
		}
		if(obj.audienceColumn != null){
			angular.forEach(obj.dataTypeList,function(data){
				if(data.key == obj.audienceColumn.columnDataType){
					if(obj.audienceColumn.physicalColumnName == "EMAIL_ADDRESS"){
						if($scope.fd.selectedAudience != undefined && $scope.fd.selectedAudience.audienceName == 'Email Address Audience'){
							obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == 7})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.disableSelect = true;
							obj.addressType = $scope.fd.emailAddressType[0];
							obj.addressTypeDisable = true;
						}else{
							obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == data.key})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.disableSelect = true;
							obj.addressType = $scope.fd.emailAddressType[0];
							obj.addressTypeDisable = true;
						}
					}else if(obj.audienceColumn.physicalColumnName == "SMS_NUMBER"){
						if($scope.fd.selectedAudience != undefined && $scope.fd.selectedAudience.audienceName == 'Sms Audience'){
						  obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == 8})[0];
						   obj.enableEmailAddress = false;
						   obj.enableSmsAddress = true;
						   obj.disableSelect = true;
						   obj.smsAddressType = $scope.fd.smsAddressType[0];
						   obj.addressTypeDisable = true;
						}else{
						   obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == data.key})[0];
						   obj.enableEmailAddress = false;
						   obj.enableSmsAddress = true;
						   obj.disableSelect = true;
						   obj.smsAddressType = $scope.fd.smsAddressType[0];
						   obj.addressTypeDisable = true;
						}
					}else{
						obj.dataType = data;
						obj.enableEmailAddress = false;
						obj.enableSmsAddress = false;
					}
					if(obj.audienceColumn.CustomType != 'custom' || obj.audienceColumn.isKeyColumn == 'Y'){
						obj.disableSelect = true;
					}
				}
			});
		}
		obj.defaultValue = audienceColumn.defaultValue;
		obj.isNullable = audienceColumn.isNullable;
		
		$scope.fd.fdMappingVOList[index] = obj;
	}
	
	function mapDefaultColumnsData(){
		angular.forEach($scope.fd.fdMappingVOList,function(obj){
			angular.forEach($scope.fd.audienceColumns,function(aobj){
				if(obj.header.toUpperCase() == aobj.logicalColumnName.toUpperCase() || (aobj.physicalColumnName != null && obj.header.toUpperCase() == aobj.physicalColumnName.toUpperCase())){
					if(aobj.physicalColumnName == "EMAIL_ADDRESS"){
						if($scope.fd.selectedAudience != undefined && $scope.fd.selectedAudience.audienceName == 'Email Address Audience'){
							obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == 7})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.addressType = $scope.fd.emailAddressType[0];
							obj.disableSelect = true;
							obj.addressTypeDisable = true;
						}else{
							obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == aobj.columnDataType})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.addressType = $scope.fd.emailAddressType[0];
							obj.addressTypeDisable = true;
						}
					}else if(aobj.physicalColumnName == "SMS_NUMBER"){
					    if($scope.fd.selectedAudience != undefined && $scope.fd.selectedAudience.audienceName == 'Sms Audience'){
						    obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == 8})[0];
							obj.enableEmailAddress = false;
							obj.enableSmsAddress = true;
							obj.smsAddressType = $scope.fd.smsAddressType[0];
							obj.addressTypeDisable = true;
					    }else{
						    obj.dataType = $.grep(obj.dataTypeList,function(obj){return obj.key == aobj.columnDataType})[0];
							obj.enableEmailAddress = false;
							obj.enableSmsAddress = true;
							obj.smsAddressType = $scope.fd.smsAddressType[0];
							obj.addressTypeDisable = true;
					    }
					}else{
						obj.dataType = ($.grep($scope.fd.dataTypes,function(dataObj){return dataObj.key == aobj.columnDataType}))[0];
						obj.enableEmailAddress = false;
						obj.enableSmsAddress = false;
					}
					obj.header = obj.header.replace(/ /g, '');
					obj.audienceColumn = aobj;
					obj.disableSelect = true;
					obj.length = aobj.length;
					obj.disableLength = true;
					obj.defaultValue = aobj.defaultValue;
					obj.isNullable = aobj.isNullable;
					if(aobj.isKeyColumn == 'Y'){
						obj.disableAudience = true;
					}
				}
			});
			
		});
		if($scope.editfilemapping && $scope.editfilemapping.length > 0 && $scope.fd.isEditMode == 'Y' && $scope.fdvo.fileType == 'B'){
			angular.forEach($scope.fd.fdMappingVOList,function(mapping){
				angular.forEach($scope.editfilemapping,function(obj){
					if(obj.columnName ==  mapping.header){
						mapping.audienceColumn = $.grep($scope.fd.audienceColumns,function(object){
							if(obj.isCustomColumn == 'Y'){return 'Is Custom' == object.logicalColumnName;}
							else{return obj.logicalColumnName == object.logicalColumnName;}
						})[0];
						mapping.dataType = $.grep($scope.fd.dataTypes,function(object){return obj.columnType == object.value})[0];
						if(mapping.audienceColumn && mapping.audienceColumn.logicalColumnName != 'Omit' && mapping.audienceColumn.logicalColumnName != 'Is Custom')mapping.disableSelect = true;
						if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == "EMAIL_ADDRESS"){
							mapping.enableEmailAddress = true;
							mapping.enableSmsAddress = false;
							mapping.addressType = $.grep($scope.fd.emailAddressType,function(obj1){
								return obj1[0] == obj.addressType
							})[0];
							mapping.disableSelect = true;
							mapping.addressTypeDisable = true;
						}else if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == "SMS_NUMBER"){
							mapping.enableSmsAddress  = true;
							mapping.enableEmailAddress = false;
							mapping.smsAddressType = $.grep($scope.fd.smsAddressType,function(obj1){
								return obj1[0] == obj.addressType
							})[0];
							mapping.disableSelect = true;
							mapping.addressTypeDisable = true;
						}else{
							if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == 'custom'){
								if(mapping.dataType.value == 'EMAIL'){
									mapping.enableEmailAddress = true;
									mapping.enableSmsAddress = false;
									mapping.addressType = $.grep($scope.fd.emailAddressType,function(obj1){
										return obj1[0] == obj.addressType
									})[0];
								}else if(mapping.dataType.value == 'SMS'){
									mapping.enableSmsAddress  = true;
									mapping.enableEmailAddress = false;
									mapping.smsAddressType = $.grep($scope.fd.smsAddressType,function(obj1){
										return obj1[0] == obj.addressType
									})[0];
								}
							}
						}
					}
				});
			});
		}
		$scope.$evalAsync(function(){
			$scope.fd.fdMappingVOList = $scope.fd.fdMappingVOList;;
			$scope.showLoadingDiv = false;
		});
	}
	
	$scope.fd.intializeActions = function(){
		$("#filedefuploadBtn").change(function(){
			$scope.$apply(function(){
				$scope.fd.uploadFileName = $("#filedefuploadBtn").val();
				if(filedefuploadBtn.files[0] != undefined)
					$scope.fd.uploadFileName = filedefuploadBtn.files[0].name;
			}); 
			
		});
	}
	
	$scope.fd.selectDatatype = function(index,column){
		console.log(column);
		var obj = $scope.fd.fdMappingVOList[index];
		if(obj.header == column.logicalColumnName){
			
		}
		
	}
	
	$scope.fd.changeAddressType = function(type,index){
		var obj = $scope.fd.fdMappingVOList[index];
		obj.length = undefined;
		if(type.value == 'EMAIL'){
			obj.enableEmailAddress = true;
			obj.enableSmsAddress = false;
			if($scope.fd.emailAddressType[0])
				obj.addressType = $scope.fd.emailAddressType[0];
		}else if(type.value == 'SMS'){
			obj.enableSmsAddress  = true;
			obj.enableEmailAddress = false;
			if($scope.fd.smsAddressType[0])
				obj.smsAddressType = $scope.fd.smsAddressType[0];
		}else{
			obj.enableSmsAddress  = false;
			obj.enableEmailAddress = false;
		}
		
		$scope.fd.fdMappingVOList[index] = obj;
	}
	
	$scope.fd.getAddressType = function(){
		fileDefinitionService.getAddressType().success(function(result){
			if(result != null && result != undefined){
				$scope.fd.emailAddressType = result['E'];
				$scope.fd.smsAddressType = result['Z'];
			}else{
				showErrorMessage("No Addresstype exists.");
			}
			
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.getAddressType();
	
	$scope.fd.fetchTableSchema = function(){
		fileDefinitionService.getTableSchema($scope.fd.db.dbSource.dbSourceName,$scope.fd.selectedTableName).success(function(result){
			$scope.fd.tablePropertiesList = result;
			$(".filedef-remotedb-popup").dialog('open');
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	/* Query Builder Start*/
	
	$scope.fd.onQueryBuilderButtonClick = function(){
		$scope.fd.valueAndJoin = 'Value';
		$scope.fd.ascDescSelected = "ASC";
		$scope.fd.whereAndOrSelected = 'AND';
		$scope.fd.orderByValueChecked = false;
		fileDefinitionService.getDbTablesList($scope.fd.db.dbSource.dbSourceName).success(function(result){
			$scope.queryBuilderTables = result;
			$(".queryBuilderPopup").dialog('open');
			clearFieldsQB();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	};
	
	$scope.fd.getSelectedTableName = function(tableName){ 
		$scope.fd.preparedQuery="";
		$scope.queryBuilderTableColname = "";
		$scope.queryBuilderTablename = tableName.toString();
		
		/*tableColsArray = ["customerid", "VARCHAR", "128", null, "NO", "NON-UNIQUE"]*/
		return fileDefinitionService.getTableSchema($scope.fd.db.dbSource.dbSourceName,$scope.queryBuilderTablename).success(function(result){
			$scope.queryBuilderColoums = [];
			$scope.columnObjects = [];
			$scope.queryBuild = [];
			$.each( result, function( tableNameDetails, tableColsArray ) {
				/*for(var i=0;i<tableColsArray.length;i++){*/
					$scope.queryBuilderColoums.push(tableName+"."+tableColsArray[0]);
					$scope.columnObjects.push(tableColsArray[1]);
				/*}*/
			});
			
			if($scope.columnObjects[0].type=='VARCHAR'){
				$scope.displayOperators = ['=', '!=', 'like'];
			}else{
				$scope.displayOperators = ['=', '!=', '<', '>', '<=', '>='];
			}
			
			$scope.queryBuild.whereCondColName=$scope.queryBuilderColoums[0];
			$scope.queryBuild.joinCondition=$scope.queryBuilderColoums[0];
			$scope.queryBuild.operator = $scope.displayOperators[0];
			addTitlesToSelectBox("qb-table-field option");
			
		});
		
		
		
	};
	
	$scope.fd.setQueryBuilder = function(columnName){
		var select = "SELECT";
		var from = "FROM";
		var orderBy = "";
		$scope.queryBuilderTableColname = columnName.toString();
		$scope.fd.preparedQuery = select +" "+$scope.queryBuilderTableColname +" "+ from +" "+$scope.queryBuilderTablename;
		$scope.queryBuild.whereCondColName = $scope.queryBuilderColoums[0];
		$scope.fd.orderByVaueChecked();
	};
	
	
	$scope.fd.orderByVaueChecked = function(){
		
		if(!$scope.fd.orderByValueChecked){
			$scope.orderByQuery="";
			$scope.fd.orderByColName="";
			if($scope.fd.preparedQuery.indexOf("ORDER BY")>-1){
				var splitedQuery = $scope.fd.preparedQuery.split('ORDER BY');
				var tempQuery = splitedQuery[0];
				$scope.fd.preparedQuery =tempQuery+ $scope.orderByQuery;
				$scope.fd.preparedQuery = ($scope.fd.preparedQuery).replace(/ +(?= )/g,'');
			}
		}else{
			$scope.fd.orderByColName = $scope.queryBuilderColoums[0];
			$scope.fd.addSelectedTable($scope.queryBuilderColoums[0]);
		}
	};
	
	
	$scope.fd.clearQueryBuilderFields = function() {
		clearFieldsQB();
	};
	
	$scope.fd.addSelectedTable = function(tableCol){
		$scope.fd.orderByColName = tableCol;
		if($scope.fd.orderByColName){
			$scope.orderByQuery = " ORDER BY "+$scope.fd.orderByColName + " "+ $scope.fd.ascDescSelected;
			if($scope.fd.preparedQuery.indexOf("ORDER BY")>-1){
				var splitedQuery = $scope.fd.preparedQuery.split('ORDER BY');
				var tempQuery = splitedQuery[0];
				$scope.fd.preparedQuery =tempQuery+ $scope.orderByQuery;
				$scope.fd.preparedQuery = ($scope.fd.preparedQuery).replace(/ +(?= )/g,'');
			}else{
				$scope.fd.preparedQuery +=$scope.orderByQuery; 
				$scope.fd.preparedQuery = ($scope.fd.preparedQuery).replace(/ +(?= )/g,'');
			}
		}
		
	};
	
	
	$scope.fd.onWhereAdd = function(){
		if($scope.fd.modelValue || $scope.fd.valueAndJoin=='Join' || $scope.fd.valueAndJoin=='Dynamic'){
			if($scope.queryBuild.selColName){
				var partialQuery="";
				var whereClause="";
				var tempQuery = "";
				var modelValueLike = '';
				if($scope.fd.valueAndJoin=='Value'){
					if($scope.queryBuild.operator=="like"){
						modelValueLike="'%"+$scope.fd.modelValue+"%'";
					}else{
						modelValueLike = "'"+$scope.fd.modelValue+"'";
					}
					tempQuery = $scope.queryBuild.whereCondColName + " " + $scope.queryBuild.operator + " " +modelValueLike;
				}else if($scope.fd.valueAndJoin=='Join'){
					tempQuery = " "+$scope.queryBuild.whereCondColName+" = "+ $scope.queryBuild.joinCondition;
				}else if($scope.fd.valueAndJoin=='Dynamic'){
					tempQuery = " "+$scope.queryBuild.whereCondColName+" = "+ $scope.queryBuild.dynamicCondition;
				}
				
				if($scope.fd.preparedQuery.indexOf(" WHERE ") == -1){
					whereClause = " WHERE "+tempQuery;
				}else{
					whereClause = " "+$scope.fd.whereAndOrSelected+" "+tempQuery;
				}
				if($scope.fd.preparedQuery.indexOf(" ORDER BY ")>-1){
					partialQuery = whereClause;
					$scope.fd.preparedQuery+=partialQuery;
					var OrderByPosition = $scope.fd.preparedQuery.indexOf(" ORDER BY ");
					var partialString = $scope.fd.preparedQuery.slice(OrderByPosition,$scope.fd.preparedQuery.length);
					var initialQuery = $scope.fd.preparedQuery.slice(0,OrderByPosition);
					var whereString = '';
					var andString = '';
					var orderByString = ''; 
					if(partialString.indexOf(" WHERE ") > -1){
						orderByString = partialString.slice(0,partialString.indexOf(" WHERE "));
						whereString= partialString.slice(partialString.indexOf(" WHERE "),partialString.length);
					}else{
						if(partialString.indexOf(" AND ") > -1){
							orderByString = partialString.slice(0,partialString.indexOf(" AND "));
							andString= partialString.slice(partialString.indexOf(" AND "),partialString.length);
						}
						if(partialString.indexOf(" OR ") > -1){
							orderByString = partialString.slice(0,partialString.indexOf(" OR "));
							andString= partialString.slice(partialString.indexOf(" OR "),partialString.length);
						}
					}
					$scope.fd.preparedQuery = initialQuery+whereString+andString+orderByString ;
					$scope.fd.preparedQuery = ($scope.fd.preparedQuery).replace(/ +(?= )/g,'');
				}else{
					partialQuery = whereClause;
					$scope.fd.preparedQuery += partialQuery;
					$scope.fd.preparedQuery = ($scope.fd.preparedQuery).replace(/ +(?= )/g,'');
				}
			}
		}
	};
	
	$scope.fd.enableAddQueryBuild = function(){
		if($scope.fd.modelValue || $scope.fd.valueAndJoin=='Join' || $scope.fd.valueAndJoin=='Dynamic'){
			if($scope.queryBuild.selColName){
				return false;
			}else{
				return true;
			}
		}else{
			return true;
		}
	};
	
	$scope.fd.changeWhereValue = function(){
		$scope.fd.enableAddQueryBuild();
		if($scope.fd.valueAndJoin=='Join'){
			$scope.fd.modelValue = '';
			$scope.fd.modelValueDisable=true;
		}else if($scope.fd.valueAndJoin=='Dynamic'){
			$scope.fd.modelValue = '';
			$scope.fd.modelValueDisable=true;
			$scope.queryBuild.dynamicCondition='#';
			$('#dynamicSqlQuery').val('#').trigger('liszt:updated'); 
		}else{
			$scope.fd.modelValue = '';
			$scope.fd.modelValueDisable=false;
		}
	};
	
	
	$scope.fd.executeQueryBuild = function() {
		if($scope.fd.preparedQuery!='' && $scope.fd.preparedQuery!=null){
			$scope.fd.isQBQueryExist = true;
			$scope.fd.executeQuery($scope.fd.preparedQuery,true);
		}
	};
	
	
	$scope.fd.executeQuery = function(query,flag){
		if(!query || query.length==0){
			return;
		}
		$scope.fd.queryRecords =[];
		if($scope.fd.createListDBSourceVO!=undefined && $scope.fd.createListDBSourceVO.profilemap!=undefined){
			$.each($scope.fd.createListDBSourceVO.profilemap,function(index,value){
				$scope.fd.createListDBSourceVO.profilemap[index]=undefined;
			});
		}
		if($scope.fd.createListDBSourceVO!=undefined && $scope.fd.createListDBSourceVO.columns!=undefined){
			$.each($scope.fd.createListDBSourceVO.columns,function(index,value){
				$scope.fd.createListDBSourceVO.columns[index]=undefined;
			});
		}
		if(checkForRestrictedKeyWords(query)){
			var defer=$q.defer();
			$scope.fd.recordCount = null;
			if(query.length>0){
				$scope.fd.selectedQuery = query;
				fileDefinitionService.executeSelectQuery($scope.fd.db.dbSource.dbSourceName,query).error(function (data){
					showErrorMessage(data.error);
				}).success(function(data){
					$scope.fd.queryRecords = data;
					defer.resolve();
					if(flag)
						$('.executeSQLQuery').dialog('open');
				});
			}
			return defer.promise;
		}
	};
	
	$scope.fd.recordCountClick = function(){
			$scope.fd.recordCount = $scope.fd.queryRecords.length-1;
	};
	
	function checkForRestrictedKeyWords(query){
		var RESTRICTED  = ["insert into","update table","drop table","create table","alter table","delete from","truncate table","create database","drop database","drop index","create index","create sequence","drop sequence","create function","create procedure","drop procedure", "rename table"];
		var infractions = new Array();
		for ( var i=0;i<=RESTRICTED.length;i++)
		{
			var term  = RESTRICTED[i]+"";
			var contains = query.toLowerCase().split(term);
			if ( contains.length > 1 ){
				infractions.push(term);
				var regExp=new RegExp(term,"gi");
				query = query.replace(regExp, "");
			}
		}
		if ( infractions.length > 0 ) {
			showErrorMessage("The following restricted terms were removed from your text input:"+infractions.join(", "));
			return false;
		}else{
			return true;
		}
			
	}
	
	$scope.fd.refreshQueryBuilder = function(){
		return fileDefinitionService.getDbTablesList($scope.fd.db.dbSource.dbSourceName).success(function(result){
			$scope.queryBuilderTables = result;
			clearFieldsQB();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
	};
	
	$scope.fd.exportQueryBuilder = function(){
		if($scope.fd.preparedQuery && $scope.fd.preparedQuery != '')
			$scope.fd.dbSelectQuery = $scope.fd.preparedQuery;
	}
	
	
	function clearFieldsQB(){
		$scope.fd.orderByValueChecked = false;
		$scope.fd.orderByColName = "";
		$scope.queryBuilderColoums = [];
		$scope.queryBuild = [];
		$scope.queryBuild.selTableName = "";
		$scope.queryBuild.selColName = "";
		$scope.queryBuild.whereCondColName = "";
		$scope.queryBuild.operator = "";
		$scope.queryBuild.joinCondition = "";
		$scope.queryBuild.orderBy = "";
		$scope.fd.preparedQuery = "";
		$scope.fd.whereAndOrSelected = "AND";
		$scope.fd.ascDescSelected = "ASC";
		$scope.fd.modelValue = "";
		$scope.fd.valueAndJoin = "Value";
		$scope.fd.isQBQueryExist = false;
		$scope.fd.modelValueDisable=false;
		$scope.custIdInput="";
		$scope.emailAddInput="";
	}
	
	function addTitlesToSelectBox(id){
		setTimeout(function()  {
			var options = document.querySelectorAll("#"+id);
		    if (options) {
		        for (var i = 0; i < options.length; i++) {
		            options[i].title = options[i].textContent;
		        }
		    }
		},0);
	}
	
	
	$scope.fd.validateFileDefinition = function(){
		if(!$scope.fdvo.name){
			showErrorMessage("Provide file definition name");
			return;
		}
		if(!$scope.fdvo.fileType){
			showErrorMessage("select file definition type");
			return;
		}
		if($scope.fdvo.fileType != 'R' && $scope.fdvo.fileType != 'U' && $scope.fdvo.fileType != 'D' &&  !$scope.fd.selectedAudience){
			showErrorMessage("select audience type");
			return;
		}
		if(!$scope.fd.createFrom){
			showErrorMessage("select source type");
			return;
		}
		if($scope.fd.createFrom == 'R' && !$scope.fd.remote.hostServer){
			showErrorMessage("select host type");
			return;
		}
	}
	$scope.fd.validateFileMapping = function(){
		
		if(!$scope.fdvo.fileMapping){
			return;
		}
		var isValid=true;
		angular.forEach($scope.fdvo.fileMapping.columnDefinitionList,function(columnDefinition,upKey){
			angular.forEach($scope.fdvo.fileMapping.columnDefinitionList, function(columnDefinitionDown,downKey){
				if( isValid && upKey!=downKey && columnDefinitionDown.physicalColumnName==columnDefinition.physicalColumnName && $scope.fd.selectedAudience && $scope.fd.selectedAudience.audienceType!=0 && columnDefinitionDown.columnType!='Omit' ){
					if(columnDefinitionDown.columnType=='EMAIL' || columnDefinitionDown.columnType=='SMS' ){
						isValid=false;
					}					 
				}
			});
		});
		return isValid;
	}
	$scope.fd.isEnablefrequency = function(key){
		if($scope.fd.fdType== 'O'){
			if(key == 'O' || key == 'I'){
				return false;
			}else{
				return true;
			}
		}
	}
	
	$scope.fd.resetFiledefinition = function(){
		$scope.fd.selectedAudience = undefined;
		$scope.fd.audienceColumns = undefined;
		$scope.fd.createFrom = undefined;
		$scope.fd.remote.hostServer = undefined;
		$scope.fd.isFileUploaded = false;
//		$scope.fd.selectedMappingScreen = undefined;
		if($scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
			$scope.fdvo.channelType = 'E';
			$scope.fdvo.isFileTrigger = 'N';
			fileDefinitionService.getAllFileDepartments().success(function(result){
	    		$scope.fd.departments = [];
	    		$scope.fd.deptSelectAll = false;
	    		angular.forEach(result,function(key,val){
	    			var obj = {};
	    			obj.id = val;
	    			obj.name = key;
	    			obj.isSelected = true;
	    			$scope.fd.departments.push(obj);				
				});
	    		$scope.fd.deptSelectAll = true;
			}).error(function(error){
				showErrorMessage($scope.fd.getErrorMessages(error));
			});
		}
		/*if($scope.fdvo.fileType == 'B' || $scope.fdvo.fileType == 'D'){
			$scope.fdvo.isFileTrigger = 'Y';
		}*/
		if($scope.fdvo.fileType == 'D'){
			$scope.fd.tableDispositionList = ['Append'];
			$scope.fd.listStagingTables();
		}else{
			$scope.fd.tableDispositionList = ['Append','Replace'];
			$scope.fd.selectedStaggingTable = ["Select an Option"];
		}
		if($scope.fdvo.fileType == 'D' || $scope.fdvo.fileType == 'B'){
			$scope.fd.getTriggeredWorkFlows();
		}
	}
	
	$scope.fd.listStagingTables = function(){
		var d = $q.defer();
		fileDefinitionService.getStagingTables().success(function(result){
			$scope.fd.stagingTablesList = result;
			if(result == null || result == undefined || result.length == 0){
				showErrorMessage("No staging tables available.");
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	$scope.fd.getTriggeredWorkFlows = function(){
		fileDefinitionService.getTriggeredWorkFlows(zhapp.loginUser.departmentID).success(function(result){
			$scope.fd.workFlows = [];
			if(result != null && result != undefined && result.length > 0){
				var list = [];
				angular.forEach(result,function(obj){
					var temp = {};
					temp = obj.listWorkflowEditor;
					temp.id = obj.id;
					list.push(temp);
				});
			angular.forEach(list,function(obj){
					if(obj.enablemode == "Y"){
						$scope.fd.workFlows.push(obj);
					}
				});
			}
			/*else{
				showErrorMessage("No Work flows exists.");
			}*/
			
		}).error(function(error){
			//showErrorMessage($scope.fd.getErrorMessages(error));
		});
	}
	
	$scope.fd.prepareStaggingMappingColumns = function(){
		var staggingcolumnsList = [];
		if($scope.fd.selectedStaggingTable){
			var columns = $scope.fd.selectedStaggingTable.physicalColumns;
			angular.forEach(columns,function(obj){
				if( obj.physicalColumnName.toUpperCase() != 'AUDIENCE_MEMBER_ID' &&
				    obj.physicalColumnName.toUpperCase() != 'AUDIENCE_TYPE_ID' &&
					obj.physicalColumnName.toUpperCase() != 'MODIFIED_DT' &&
					obj.physicalColumnName.toUpperCase() != 'CREATION_DT' &&
					obj.physicalColumnName.toUpperCase() != 'BATCH_ID' &&
					obj.physicalColumnName.toUpperCase() != 'SRC_FILE_ID' ){
					var cobj = {};
					cobj.columnDataType = obj.columnDataType;
					cobj.defaultValue = obj.columnDefaultValue;
					cobj.isNullable = obj.isNullable;
					cobj.length = obj.columnDataLength;
					cobj.isKeyColumn = null;
					cobj.isProfilable = null;
					cobj.CustomType ='Audience';
					cobj.logicalColumnName = obj.physicalColumnName;
					cobj.physicalColumnName = obj.physicalColumnName;
					
					staggingcolumnsList.push(cobj);
				}
			});
			var obj = {};
			obj.logicalColumnName='Omit';
			obj.physicalColumnName=null;
			obj.isProfilable=null;
			obj.columnDataType = null;
			obj.isKeyColumn=null;
			obj.CustomType ='Audience';
			staggingcolumnsList.push(obj);;
			
			if($scope.fdvo.fileType != 'D'){
				obj = {};
				obj.logicalColumnName="Is Custom";
				obj.physicalColumnName="custom";
				obj.isProfilable='N';
				obj.columnDataType = 0;
				obj.isKeyColumn='N';
				obj.CustomType ='custom';
				staggingcolumnsList.push(obj);
			}
			$scope.fd.audienceColumns = staggingcolumnsList;
		}
		if($scope.fd.fdMappingVOList != undefined && $scope.fd.audienceColumns){
			angular.forEach($scope.fd.fdMappingVOList,function(obj){
				obj.disableSelect = false;
				obj.audienceColumn = $scope.fd.audienceColumns[$scope.fd.audienceColumns.length-1];
			});
		}
	}
	
	function hasDuplicateEmails(array) {
	    var valuesSoFar = [];
	    for (var i = 0; i < array.length; ++i) {
	        var value = array[i];
	        if (valuesSoFar.indexOf(value) !== -1) {
	            return true;
	        }
	        valuesSoFar.push(value);
	    }
	    return false;
	}
	
	$scope.fd.saveFileDefinition = function(){
		$scope.fd.validateFileDefinition();
		
		if($scope.fdvo.fileType == 'B' || $scope.fdvo.fileType == 'D'){
			$scope.fdvo.channelType = undefined;
		}
		if($scope.fdvo.fileType == 'D'){
			if($scope.fd.selectedStaggingTable){
				$scope.fdvo.tableName = $scope.fd.selectedStaggingTable.physicalTableName;
			}
		}
		
		if($scope.fd.scd.scheduleactivemode=='Y' ){
			$scope.fdvo.status = 'W';
		}
		else{
			$scope.fdvo.status = 'B';
		}
		$scope.fdvo.departmentID = zhapp.loginUser.departmentID;
		$scope.fdvo.fileAction = $scope.fd.fileActionType;
		$scope.fdvo.fileMapping = createFileMappingVO();
		if(!$scope.fd.validateFileMapping()){
			showErrorMessage("A column can be mapped only once.");
			return;
		};
		if($scope.fdvo.fileType == 'B' || $scope.fdvo.fileType == 'D'){
			if($scope.fdvo.fileMapping == undefined)return;
		}
		$scope.fdvo.createdBy = zhapp.loginUser.userName;
		$scope.fdvo.updatedBy = zhapp.loginUser.userName;
		if($scope.fd.selectedAudience){
			$scope.fdvo.audienceID = $scope.fd.selectedAudience.audienceId;
		}else{
			$scope.fdvo.audienceID = 0;
		}
		if($scope.fdvo.fileType == 'D' || $scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
			$scope.fdvo.audienceID = 0;
		}
		$scope.fdvo.scheduleactivemode = $scope.fd.scd.scheduleactivemode;
		if($scope.fdvo.scheduleactivemode == 'Y'){
			$scope.fdvo.fileScheduleBO = prepareFileScheduleVoForSave();
			if($scope.fdvo.fileScheduleBO == undefined) return;
		}else{
			$scope.fdvo.fileScheduleBO = null;
		}
		$scope.fdvo.fileSource = prepareFileSourceSpecVO();
		$scope.fdvo.fileFormatSpec = prepareFileFormatSpec();
		$scope.fdvo.fileProcessingOptions = prepareFileProcessingOptions();
		if($scope.notifications && $scope.notifications.isEnabled){
			var flag = false;
			angular.forEach($scope.notifications.notificationStatuses,function(obj){
				if(!flag && obj.isEnabled){
					flag = true;
				}				
			});
			if(!flag){
				showErrorMessage("Please Select Atleast One Status");
				return;
			}
			if(validateEmailAddresses() == null){
				showErrorMessage("Please Enter Valid Comma Seperated Emails");
				return;
			}
			var emailArray = $scope.notifications.defaultEmailAddresses.split(',');
			if(emailArray && emailArray.length > 10){
				showErrorMessage("Common Recipients should be less than 10.");
				return;
			}
			if(hasDuplicateEmails(emailArray)){
				showErrorMessage("Duplicate Emails Exist");
				return;
			}
			flag = false;
			var isemaillengthexceed = false;
			angular.forEach($scope.notifications.notificationStatuses,function(notification){
				if(notification.isEnabled && !flag && notification.emailAddresses){
					emailArray =  notification.emailAddresses.split(',');
					if(!isemaillengthexceed && emailArray && emailArray.length > 10){
						isemaillengthexceed = true;
					}
					if(!flag && hasDuplicateEmails(emailArray)){
						flag = true;
					}
				}
			});
			if(isemaillengthexceed){
				showErrorMessage("	Selected Recipients should be less than 10.");
				return;
			}
			if(flag){
				showErrorMessage("Duplicate Emails Exist");
				return;
			}
			/*var notificationObj = $scope.notifications;
			angular.forEach(notificationObj.notificationStatuses,function(obj){
				if(obj.isEnabled && (obj.emailAddresses == undefined || obj.emailAddresses.length == 0)){
					obj.emailAddresses = notificationObj.defaultEmailAddresses;
				}
			});*/
			$scope.fdvo.notifications =angular.copy($scope.notifications);
		}else{
			$scope.fdvo.notifications =angular.copy($scope.notifications);
		}
		if($scope.fdvo.fileType == 'D'){
			if($scope.fdvo.sendWorkFlow == 'N'){
				$scope.fdvo.workFlowID = 0;
			}
		}		
		$scope.fdvo.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
		$scope.fdvo.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');
		if($scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
			$scope.fdvo.unsubResubProperties = $scope.fd.saveDepartments();	
			if($scope.fdvo.unsubResubProperties == undefined){
				showErrorMessage("Please Select Atleast one Department");
				return;
			}
		}
		$scope.fdvo.maxFiles = 1;
		if($scope.fd.scd.scheduleactivemode == 'N' || ($scope.fd.scd.scheduleactivemode == 'Y' && $scope.fd.scd.frequency == 'I') || $scope.fdvo.fileType != 'B'){
			$scope.fdvo.isFileTrigger = 'N';
		}
		if($scope.editfilemapping && $scope.editfilemapping.length > 0 && $scope.fd.isEditMode == 'Y' && $scope.fdvo.fileType == 'B'){
			var exist = true;
			angular.forEach($scope.editfilemapping,function(obj){
				if(exist && obj.isCustomColumn == 'N'){
					var existLogicalName = $.grep($scope.fd.fdMappingVOList,function(val){
						if(val.audienceColumn && val.dataType)
							return val.audienceColumn.physicalColumnName == obj.physicalColumnName && val.dataType.value == obj.columnType;
					})[0];
					if(!existLogicalName && obj.columnType != "Omit" ){
						exist = false;
						showErrorMessage("LogicalColumn "+obj.logicalColumnName+" should be mapped");
						return;
					}
				}
			});
			if(!exist){
				return;
			}
			exist = true;
			if($scope.fd.audienceColumns){
				angular.forEach($scope.fd.audienceColumns,function(obj){
					if(exist && obj.isUsed){
						var existLogicalName = $.grep($scope.fd.fdMappingVOList,function(val){
							if(val.audienceColumn && val.audienceColumn.logicalColumnName == 'Is Custom' && val.dataType)
								return val.header == obj.logicalColumnName && val.dataType.key == obj.columnDataType;
							else if(val.audienceColumn && val.dataType)
								return val.audienceColumn.logicalColumnName == obj.logicalColumnName && val.dataType.key == obj.columnDataType;
						})[0];
						if(!existLogicalName){
							exist = false;
							showErrorMessage("Column "+obj.logicalColumnName+" should be mapped as "+($.grep($scope.fd.dataTypes,function(val1){return val1.key == obj.columnDataType})[0]).value);
							return;
						}
					}
				});
			}
			if(!exist){
				return;
			}
		}
		if($scope.fdvo.tableName != undefined && $scope.fdvo.tableName.length > 0){
    		var valid = $scope.fdvo.tableName.charAt(0).match(/[a-z]/i);
    		if(valid==null || valid == undefined){
    			showErrorMessage("Table name should not start with number or special character.");
    			return false;
    		}
		}
		//console.log(JSON.stringify($scope.fdvo));
		var hubListForData = new FormData();
		if(filedefuploadBtn.files.length!=0){
			hubListForData.append("file", filedefuploadBtn.files[0]);
		}
		hubListForData.append("fileDefinitionBO", JSON.stringify($scope.fdvo));
		fileDefinitionService.saveFileDefinition(hubListForData).success(function(result){
			/*$scope.fdvo.fileDefinitionID = result.fileDefinitionID;
			if($scope.fdvo.scheduleactivemode == 'Y'){
			$scope.fdvo.fileScheudleID = result.fileScheduleBO.fileScheudleID;
			}*/
			$scope.fdobjnotifications=undefined;
			$scope.fdvo = undefined;
	    	$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/filedefinitionlist.html";
	    	$scope.fd.searchCriteria = undefined;
	    	$scope.fd.initializeFileDefinition();
		}).error(function(error){
			showErrorMessage($scope.fd.getErrorMessages(error));
		});
		
	}
	function validateEmailAddresses(){
		if($scope.notifications.defaultEmailAddresses){
			var emailArray = $scope.notifications.defaultEmailAddresses.split(',');
			var flag = false;
			angular.forEach(emailArray,function(email){
				if(!flag && !validateEmail(email)){
					flag = true;
				}
			});
			if(flag)
				return null;
			flag = false;
			angular.forEach($scope.notifications.notificationStatuses,function(notification){
				if(notification.isEnabled && !flag && notification.emailAddresses){
					var innerFlag = false;
					emailArray =  notification.emailAddresses.split(',');
					angular.forEach(emailArray,function(email){
						if(!innerFlag && !validateEmail(email)){
							innerFlag = true;
							flag = true;
						}
					});
				}
			});
			if(flag)
				return null;
			else 
				return true;
		}
	}
	function prepareFileProcessingOptions(){
		var fileProcessingOptions = {};
		if($scope.fd.createFrom != 'B'){
			if($scope.fdvo.fileProcessingOptions != undefined){
				fileProcessingOptions.ignoreBadFiles =  $scope.fdvo.fileProcessingOptions.ignoreBadFiles;
				fileProcessingOptions.ignoreBadRecords = $scope.fdvo.fileProcessingOptions.ignoreBadRecords;
				fileProcessingOptions.preserveOrder = $scope.fdvo.fileProcessingOptions.preserveOrder;
				fileProcessingOptions.mergeDuplicates = $scope.fdvo.fileProcessingOptions.mergeDuplicates;
				
			}
		}
		return fileProcessingOptions;
	}
	function prepareFileFormatSpec(){
		var fileFormatSpec = {};
		if($scope.fd.createFrom != 'B'){
			if($scope.fdvo.fileFormatSpec != undefined){
				fileFormatSpec.delimiter = $scope.fdvo.fileFormatSpec.delimiter;
				fileFormatSpec.textQualifier = $scope.fdvo.fileFormatSpec.textQualifier;
				fileFormatSpec.headerRowAtLine = $scope.fdvo.fileFormatSpec.headerRowAtLine;
				fileFormatSpec.dataStartsFromLine = $scope.fdvo.fileFormatSpec.dataStartsFromLine;
			}
		}
		return fileFormatSpec;
	}
	$scope.validateFilenamePattern = function(fileNamePattern){
		if(/\*\*/.test(fileNamePattern)){
			showErrorMessage("File name pattern is not accept multiple stars.")
			$scope.fd.remote.fileNamePattern=undefined;
			return false;
		}
	};
	function prepareFileSourceSpecVO(){
		var fileSourceSpecVO = {};
		fileSourceSpecVO.sourceType = $scope.fd.createFrom;
		if($scope.fd.createFrom == 'R'){
			fileSourceSpecVO.sourceName = $scope.fd.remote.hostServer.fileSourceName;
			fileSourceSpecVO.fileNamePattern = $scope.fd.remote.fileNamePattern;
			if($scope.fd.remote.currentFolderselected != undefined && ($scope.fd.remote.currentFolderselected.endsWith(".txt") || $scope.fd.remote.currentFolderselected.endsWith(".csv"))){
				fileSourceSpecVO.folderPath = $scope.fd.remote.currentFolderselected.substring(0,$scope.fd.remote.currentFolderselected.lastIndexOf('/'));
			}else{
				fileSourceSpecVO.folderPath = $scope.fd.remote.currentFolderselected;
			}
//			if($scope.fd.remote.hostServer.protocol=='http' || $scope.fd.remote.hostServer.protocol=='https'){
//				fileSourceSpecVO.folderPath = $scope.fd.remote.hostServer.hostname.substring(0,$scope.fd.remote.hostServer.hostname.lastIndexOf('/'));
//			}
		}else if($scope.fd.createFrom == 'B'){
			if($scope.fd.db.dbSource != undefined){
				fileSourceSpecVO.sourceName = $scope.fd.db.dbSource.dbSourceName;
			}
			fileSourceSpecVO.query = $scope.fd.dbSelectQuery;
			fileSourceSpecVO.sourceTable = $scope.fd.selectedTableName;
		}else if($scope.fd.createFrom == 'L'){
			fileSourceSpecVO.filePath = $scope.fd.filePath;
			fileSourceSpecVO.fileNamePattern = $scope.fd.fileNamePattern;
		}else if($scope.fd.createFrom == 'D'){
			fileSourceSpecVO.filePath = $scope.fd.filePath;
    	}
		fileSourceSpecVO.fileName = '';
		return fileSourceSpecVO;
	}
	
	function prepareFileScheduleVoForSave(){
		var fileScheduleVO = {};
		if($scope.fdvo.fileScheudleID){
			fileScheduleVO.fileScheudleID = $scope.fdvo.fileScheudleID;
		}
		if($scope.fdvo.fileDefinitionID){
			fileScheduleVO.fileDefinitionID = $scope.fdvo.fileDefinitionID;
		}
		fileScheduleVO.frequency = $scope.fd.scd.frequency;
		fileScheduleVO.timeZone = $scope.fd.scd.timezone;
		if ($scope.fd.scd.frequency == 'I') {
        	fileScheduleVO.scheduleStartDate  = zhapp.getCnvDateTime('DTS',null,$scope.fd.scd.timezone);
        	fileScheduleVO.schedulenextdue = null;
            fileScheduleVO.scheduleEndDate = zhapp.getCnvDateTime('DTS',null,$scope.fd.scd.timezone);
            fileScheduleVO.frequencyUnit = 0;
            fileScheduleVO.includeDays = 0;
            fileScheduleVO.dayOfEveryMonth = 0;
            return fileScheduleVO;
        }else if($scope.fd.scd.frequency == 'O'){
        	if($scope.fd.scd.startDate == undefined){
        		showErrorMessage("Invalid ScheduleStartDate");
        		return;
        	}
        	fileScheduleVO.scheduleStartDate  = $scope.fd.scd.startDate+" "+$scope.fd.scd.startTime+":00";
        	fileScheduleVO.schedulenextdue = null;
            fileScheduleVO.scheduleEndDate = $scope.fd.scd.startDate+" "+$scope.fd.scd.startTime+":00";
            fileScheduleVO.frequencyUnit = 0;
            fileScheduleVO.includeDays = 0;
            fileScheduleVO.dayOfEveryMonth = 0;
            return fileScheduleVO;
        }else if($scope.fd.scd.frequency != 'I' && $scope.fd.scd.frequency != 'O'){
        	if($scope.fd.scd.startDate == "" || $scope.fd.scd.startTime == ""){
        		showErrorMessage("Invalid ScheduleStartDate");
        		return;
        	}
        	if($scope.fd.scd.endDate == ""){
        		showErrorMessage("Invalid ScheduleEndDate");
        		return;
        	}
        	fileScheduleVO.scheduleStartDate  = $scope.fd.scd.startDate+" "+$scope.fd.scd.startTime+":00";
        	fileScheduleVO.schedulenextdue = null;
            fileScheduleVO.scheduleEndDate = $scope.fd.scd.endDate+" 23:59:59";
        	if($scope.fd.scd.frequency == 'N'){
        		if($scope.fd.scd.frquencyunit == undefined){
            		showErrorMessage("Invalid FrequencyUnit");
            		return;
            	}
                fileScheduleVO.frequencyUnit = $scope.fd.scd.frquencyunit;
                fileScheduleVO.includeDays = 0;
                fileScheduleVO.dayOfEveryMonth = 0;
                return fileScheduleVO;
        	}else if($scope.fd.scd.frequency == 'D'){
        		fileScheduleVO.frequencyUnit = 0;
        		fileScheduleVO.includeDays = 0;
                fileScheduleVO.dayOfEveryMonth = 0;
        		return fileScheduleVO;       		
        	}else if($scope.fd.scd.frequency == 'W'){
        		fileScheduleVO.frequencyUnit = 0;
                fileScheduleVO.dayOfEveryMonth = 0;
        		fileScheduleVO.includeDays = 0;
                angular.forEach($scope.fd.selectedDays, function(value, key) {
                    if (value == 'S')
                    	fileScheduleVO.includeDays = fileScheduleVO.includeDays + 1;
                    else if (value == 'M')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 2;
                    else if (value == 'T')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 4;
                    else if (value == 'W')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 8;
                    else if (value == 'H')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 16;
                    else if (value == 'F')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 32;
                    else if (value == 'U')
                        fileScheduleVO.includeDays = fileScheduleVO.includeDays + 64;
                });
        		return fileScheduleVO;       		
        	}else if($scope.fd.scd.frequency == 'M'){
        		if($scope.fd.scd.monthlyschdfreq != undefined && $scope.fd.scd.monthlyschdfreq == 'D'){
                	fileScheduleVO.monthlySchdFreq = 'D';
                	fileScheduleVO.dayOfEveryMonth = $scope.fd.scd.dayofeverymonth;
                	fileScheduleVO.frequencyUnit = 0;
            		fileScheduleVO.includeDays = 0;
                }else if($scope.fd.scd.monthlyschdfreq != undefined && $scope.fd.scd.monthlyschdfreq == 'T'){
                	fileScheduleVO.monthlySchdFreq = 'T';
                	fileScheduleVO.monthlyWeekFreq = $scope.fd.scd.monthlyWeekFreq;
                	fileScheduleVO.monthlyDayFreq = $scope.fd.scd.monthlyDayFreq;
                	fileScheduleVO.frequencyUnit = 0;
                    fileScheduleVO.dayOfEveryMonth = 0;
            		fileScheduleVO.includeDays = 0;
                }        		
        		return fileScheduleVO;       		
        	}
        }
	}
	
	function createFileMappingVO(){
		var list = [];
		var fileActionMappingVO = {};
		if($scope.FileActionMappingVO && $scope.FileActionMappingVO.nullValueRepresentation){
			fileActionMappingVO.nullValueRepresentation = $scope.FileActionMappingVO.nullValueRepresentation;
		}
//		if($scope.FileActionMappingVO && $scope.FileActionMappingVO.booleanFormat){
			fileActionMappingVO.booleanFormat = "YESNO";
//		}
		if($scope.FileActionMappingVO && $scope.FileActionMappingVO.dateFormat){
			fileActionMappingVO.dateFormat = $scope.FileActionMappingVO.dateFormat;
		}
		if($scope.FileActionMappingVO && $scope.FileActionMappingVO.dateDelimiter){
			fileActionMappingVO.dateDelimiter = $scope.FileActionMappingVO.dateDelimiter;
		}
			if($scope.fd.validateScrubrule()){
			if($scope.fd.endingwithtext && $scope.fd.endingwithtext != null)
			fileActionMappingVO.scrubrulesEndingWithText=$scope.fd.endingwithtext;
			console.log(fileActionMappingVO.scrubrulesEndingWithText);
			}else
        	return false;
		$scope.fd.setScrubRulesForSave();
		if($scope.fd.includescrubrules && $scope.fd.includescrubrules != 0){
			fileActionMappingVO.enableScrubRules = 'Y';
		}else{
			fileActionMappingVO.enableScrubRules = 'N';
		}
		fileActionMappingVO.includeScrubRules = $scope.fd.includescrubrules;
		var columnidFlag = false;
		angular.forEach($scope.fd.fdMappingVOList,function(data,index){
			if(!columnidFlag){
				if($scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
					if(data.dataType == undefined){
						return;
					}
				}else{
					if(data.audienceColumn == undefined){
						return;
					}
				}
				var columnDefinitionList = {};
				columnDefinitionList.columnPositionInFile = index;
				columnDefinitionList.columnName = data.header;
				if(!data.header || (data.header && data.header.length <= 0)){
					showErrorMessage("ColumnId should not be empty.");
					columnidFlag = true;
					return;
				};
				if(data.audienceColumn && data.audienceColumn.CustomType == 'Audience'){
					columnDefinitionList.isCustomColumn = 'N';
				}else{
					if(data.audienceColumn)
						columnDefinitionList.isCustomColumn = 'Y';
				}
				if($scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
					columnDefinitionList.isCustomColumn = 'N';
					columnDefinitionList.length = 1600;
					columnDefinitionList.defaultValue = null;
					columnDefinitionList.isNullable = 'N';
				}else{
					columnDefinitionList.defaultValue = data.defaultValue;
					if(data.isNullable)
						columnDefinitionList.isNullable = data.isNullable;
					else 
						columnDefinitionList.isNullable = 'N';
					columnDefinitionList.unsubscribe = data.unSubAddList;
				}
				if($scope.fdvo.fileType == 'B' || $scope.fdvo.fileType == 'D'){
					if(data.audienceColumn){
						if(data.audienceColumn.logicalColumnName == 'Omit'){
							columnDefinitionList.columnType = "Omit";
							list.push(columnDefinitionList);
							return;
						}
						if(data.audienceColumn.logicalColumnName == 'Is Custom')
							columnDefinitionList.logicalColumnName = columnDefinitionList.columnName;
						else 
							columnDefinitionList.logicalColumnName = data.audienceColumn.logicalColumnName;
						if(data.audienceColumn.physicalColumnName=="custom")
							columnDefinitionList.physicalColumnName = data.audienceColumn.physicalColumnName+columnDefinitionList.columnName;
						else
							columnDefinitionList.physicalColumnName = data.audienceColumn.physicalColumnName;
						
						var selectedAud = $scope.fd.selectedAudience;
						if(selectedAud != undefined && selectedAud.logicalTables != undefined){
							columnDefinitionList.physicalTableName = $.grep(selectedAud.logicalTables,function(obj){return obj.tableType == 0})[0].physicalTableName;
							columnDefinitionList.logicalTableName = $.grep(selectedAud.logicalTables,function(obj){return obj.tableType == 0})[0].logicalTableName;					
						}
						if($scope.fdvo.fileType == 'D' && $scope.fd.selectedStaggingTable){
							columnDefinitionList.physicalTableName = $scope.fd.selectedStaggingTable.physicalTableName;
						}
						if(data.audienceColumn.length)columnDefinitionList.length = data.audienceColumn.length;
						else columnDefinitionList.length = 400;
						
						if(data.audienceColumn.physicalColumnName=="custom")
							columnDefinitionList.physicalTableName = undefined;
						if(data.audienceColumn.isNullable)
							columnDefinitionList.isNullable = data.audienceColumn.isNullable;
					}
					if(data.enableEmailAddress){columnDefinitionList.addressType=data.addressType[0];}
					if(data.enableSmsAddress){columnDefinitionList.addressType=data.smsAddressType[0];}
					if(data.defaultValue)
						columnDefinitionList.defaultValue = data.defaultValue;
				}
				if(data.dataType){
					columnDefinitionList.columnType = data.dataType.value;
					if(data.dataType.value == 'UNICODESTRING' || data.dataType.value == 'ASCIISTRING'){
						columnDefinitionList.columnType = "STRING";
					}
				}
				list.push(columnDefinitionList);
			}
		});
		if(columnidFlag){
			return null;
		}else{
			fileActionMappingVO.columnDefinitionList = list;
			return fileActionMappingVO;
		}
		
	}
	
	$scope.fd.removeMappingcolumn = function(index){
		if($scope.fd.fdMappingVOList.length > 1){
			$scope.fd.fdMappingVOList.splice(index,1);
		}else{
			showErrorMessage("Atleast one column should be configured");
		}
		
	}
	
	$scope.fd.loadScheduleEvents = function() {
    	
        $('.timepicker').timepicker({
            showSeconds: false,
            showMeridian: false,
            defaultTime: false,
            disableFocus: false,
            minuteStep: 1
        });
        $('.cal-icon').click(function() {
            $(this).prev("input").trigger('focus');
        });
        $(".scheduleTimeField,.toDateField").datepicker({
            autoclose: true,
            todayHighlight: true,
            //startDate: new Date()
        });
    };
    
    $scope.fd.selectedDays = [];
    
    $scope.fd.addOrRemoveWeekDays = function(weekDay) {
       if($scope.fd.selectedDays.indexOf(weekDay) == -1){
    	   $scope.fd.selectedDays.push(weekDay);
       }else{
    	   $scope.fd.selectedDays.splice($scope.fd.selectedDays.indexOf(weekDay),1);
       }
    };
	
    $scope.fd.listFileDefinitions = function(criteria){
    	var d = $q.defer();
    	fileDefinitionService.listFileDefinitions(criteria).success(function(result){
    		if(result.result[0])$scope.fd.totalRecords = result.totalRecords;		
			else $scope.fd.totalRecords=-1;
    		d.resolve(result);
    	}).error(function(error){
    		d.reject(error);
    		showErrorMessage($scope.fd.getErrorMessages(error));
    	});
    	return d.promise;
    }
    
//    $scope.fd.enableDataMappingTab = function(){
    	/*if($scope.fd.createFrom == null || $scope.fd.createFrom == undefined || $scope.fd.createFrom == ''){
    		showErrorMessage("Select create from");
    		return
    	}
    	if($scope.fd.createFrom == 'R' && ($scope.fd.remote.currentFolderselected == null || $scope.fd.remote.currentFolderselected == undefined || $scope.fd.remote.currentFolderselected == '')){
    		showErrorMessage("Select remote source");
    		return;
    	}
    	
    	if($scope.fd.createFrom == 'B' && ($scope.fd.dbSelectQueryData == null || $scope.fd.dbSelectQueryData  == undefined || $scope.fd.dbSelectQueryData == '')){
    		showErrorMessage("Select database source");
    		return;
    	}
    	if(!$scope.fdvo.fileType){
    		showErrorMessage("Select source type");
    		return;
    	}
    	if((!$scope.fdvo.fileType || $scope.fdvo.fileType == 'B') && !$scope.fd.selectedAudience ){
    		showErrorMessage("Select audience");
    		return;
    	}
    	if($scope.fd.createFrom == 'R' && !$scope.fdvo.fileFormatSpec.delimiter){
    		showErrorMessage("Select file delimiter");
    		return;
    	}
    	if($scope.fd.createFrom == 'R' && !$scope.fdvo.fileFormatSpec.headerRowAtLine){
    		showErrorMessage("Select header row");
    		return;
    	}
    	if($scope.fd.createFrom == 'R' && !$scope.fdvo.fileFormatSpec.dataStartsFromLine){
    		showErrorMessage("Select data row");
    		return;
    	}
    	if($scope.fdvo.fileType == 'D' && !$scope.fd.selectedStaggingTable){
    		showErrorMessage("select staging table.");
    		return;
		}*/
//    	$scope.fd.enableDataMapping = true;
//    }
    
    
    $scope.fd.selectedMappingScreen = 'Data Mappings';
    $scope.fd.setScrubRulesForSave=function(){
    	//fileActionMappingVO.scrubrulesEndingWithText = $scope.fd.endingwithtext;
		$scope.fd.includescrubrules = 0;
		if($scope.fd.remrepeatdots)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,0);
		if($scope.fd.remdoublequotes)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,1);
		if($scope.fd.reminvalid)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,2);
		if($scope.fd.remrepeatat)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,3);
		if($scope.fd.removedot)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,4);
		if($scope.fd.changeunderscore)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,5);
		if($scope.fd.removesinglequoteatend)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,6);
		if($scope.fd.removesinglequoteatbegin)
		   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,7);
		if($scope.fd.enclosedoublequotes)
	  	   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,8);
		if($scope.fd.remwhitespace)
	  	   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,9);
		if($scope.fd.changeemail)
	       $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,10);
		if($scope.fd.removeplus)
	  	   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,11);
		if($scope.fd.removewhitespacesms)
	  	   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,12);
		if($scope.fd.removeminus)
	  	   $scope.fd.includescrubrules = $scope.fd.includescrubrules + Math.pow(2,13);    		  
	};
    
	$scope.fd.validateScrubrule=function(){
		if($scope.fd.changeemail){
			if($scope.fd.endingwithtext==null){
				showErrorMessage("Specify value for rule - Change the email address ending with textbox.");
				return false;
			}
			$scope.fd.endingwithtext=$scope.fd.endingwithtext.trim();
			if($scope.fd.endingwithtext.length==0){
				showErrorMessage("Specify value for rule - Change the email address ending with textbox.");
				return false;
			}
			else{
				var strArr = $scope.fd.endingwithtext.split(",");
				var isInvalid = false;
				var token;
				var strArr2;
				var subtoken;
				if(strArr != null) {
					for(var i=0; i<strArr.length; i++) {
						token = strArr[i].trim();
						if(token.length == 0) {
							isInvalid = true;
							break;
						} else {
							strArr2 = token.split(" to ");
							if(strArr2 != null && strArr2.length == 2) {
								for(var j=0; j<strArr2.length; j++) {
									subtoken = strArr2[j].trim();
									if(subtoken.length == 0) {
										isInvalid = true;
										break;
									} 
								}
							} else {
								isInvalid = true;
								break;
							}	 	
						}
					}
				} else {
					isInvalid = true;
				}
				if(isInvalid) { 					
					showErrorMessage("Invalid value specified for rule - Change the email address ending with textbox.");
					return false;
				}
			}	
		}else
			$scope.fd.endingwithtext=null;
		return true;
	};
	
	$scope.fd.setScrubRulesForDisplay=function(){
		$scope.fd.remrepeatdots=false;
    	$scope.fd.remdoublequotes=false;
    	$scope.fd.reminvalid=false;
    	$scope.fd.remrepeatat=false;
    	$scope.fd.removedot=false;
    	$scope.fd.changeunderscore=false;
    	$scope.fd.removesinglequoteatend=false;
    	$scope.fd.removesinglequoteatbegin=false;
    	$scope.fd.enclosedoublequotes=false;
    	$scope.fd.remwhitespace=false;
    	$scope.fd.changeemail=false;
    	$scope.fd.removeplus=false;
    	$scope.fd.removewhitespacesms=false;
    	$scope.fd.removeminus=false;
		//$scope.fd.endingwithtext=null;
		var sum=$scope.fd.includescrubrules;
		while(sum>0){
    		var pow=Math.floor(Math.log(sum)/Math.log(2));
    		var sum=sum-Math.pow(2,pow);
    		switch(pow){
    		  case 0:  $scope.fd.remrepeatdots=true;
    		  		   break;
    		  case 1:  $scope.fd.remdoublequotes=true;
	  		  		   break;
    		  case 2:  $scope.fd.reminvalid=true;
	  		  		   break;
    		  case 3:  $scope.fd.remrepeatat=true;
	  		  		   break;
    		  case 4:  $scope.fd.removedot=true;
	  		           break;
    		  case 5:  $scope.fd.changeunderscore=true;
	  		  		   break;
    		  case 6:  $scope.fd.removesinglequoteatend=true;
	  		  		   break;
    		  case 7:  $scope.fd.removesinglequoteatbegin=true;
    		  		   break;
    		  case 8:  $scope.fd.enclosedoublequotes=true;
		  		   	   break;
    		  case 9:  $scope.fd.remwhitespace=true;
		  		   	   break;
    		  case 10: $scope.fd.changeemail=true;
		  		       break;
    		  case 11: $scope.fd.removeplus=true;
		  		       break;
    		  case 12: $scope.fd.removewhitespacesms=true;
		  		       break;
    		  case 13: $scope.fd.removeminus=true;
		  		       break;    		  
    		};
    	};
	};
    
	
	$scope.fd.setScrubRulesForDisplay();
	
	
	$scope.fd.resetScrubRules=function(){		
		$scope.fd.remrepeatdots = true;
		$scope.fd.remrepeatat = true;
		$scope.fd.reminvalid = true;
		$scope.fd.changeunderscore = true;
		$scope.fd.removedot = true;
		$scope.fd.removesinglequoteatbegin = true;
		$scope.fd.removesinglequoteatend = true;
		$scope.fd.enclosedoublequotes = true;
		$scope.fd.remwhitespace = true;
		$scope.fd.remdoublequotes = true;
		$scope.fd.changeemail = false;
		$scope.fd.endingwithtext = null;
		$scope.fd.removeplus=true;
		$scope.fd.removewhitespacesms=true;
		$scope.fd.removeminus=true;
		if($scope.fd.tableName=='AUDIENCE_SMS' || $scope.fd.tableName=='zh_audience_sms' || $scope.fd.tableName=='ZH_AUDIENCE_SMS'){
			$scope.fd.remrepeatdots = false;
			$scope.fd.remrepeatat = false;
			$scope.fd.reminvalid = false;
			$scope.fd.changeunderscore = false;
			$scope.fd.removedot = false;
			$scope.fd.removesinglequoteatbegin = false;
			$scope.fd.removesinglequoteatend = false;
			$scope.fd.remwhitespace = false;
			$scope.fd.remdoublequotes = false;
			$scope.fd.enclosedoublequotes = false;
		}
		if($scope.fd.tableName=='AUDIENCE_EMAIL' || $scope.fd.tableName=='zh_audience_email' || $scope.fd.tableName=='ZH_AUDIENCE_EMAIL'){
			$scope.fd.removeplus=false;
			$scope.fd.removewhitespacesms=false;
			$scope.fd.removeminus=false;
		}
	};
    
    
    $scope.fd.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = error.error;
    	}
    	return msg;
    }
    
    if(sessionStorage.getItem('queryParams')){
    	$scope.fd.preInitializeFileDefinition();
    	var promise = $scope.fd.getAudienceList();
    	promise.then(function(res){
    		var searchCriteria = {};
        	searchCriteria.id = JSON.parse(sessionStorage.getItem('queryParams')).value;
        	searchCriteria.departmentID = JSON.parse(sessionStorage.getItem('queryParams')).departmentId;
        	sessionStorage.removeItem('queryParams');
            var promisefdlist = $scope.fd.listFileDefinitions(searchCriteria);		
    			promisefdlist.then(function(fdList){		
    				angular.forEach(fdList.result,function(key){				
    					key.show = true;		
    				});		
    				$scope.fd.fileDefinitionList = fdList.result;		
    				$scope.fd.fileActivites = fdList.activies;				
    				// console.log(JSON.stringify($scope.fd.fileActivites));
    				if($scope.fd.fileDefinitionList <= 0){
    	    			  $scope.fd.infoMessage = "No Files Found";
    	    				//showErrorMessage("No Files Found");
    	    			  return;
    	    		}
    				angular.forEach(fdList.activies,function(key,value){				
    	    			angular.forEach($scope.fd.fileDefinitionList,function(eachObj){				
    	        			if(value == eachObj.fileDefinitionID && key != 0){				
    	        				eachObj.isActivity = true;				
    	        			}				
    	    			});				
    				});
    				$scope.fd.openListSummaryDialog($scope.fd.fileDefinitionList[0]);
    		});
    	});
    }else{
    	$scope.fd.initializeFileDefinition();
    }
    
    function prepareFileSorceSpecVOForEdit(sourceobj){
    	var d = $q.defer();
    	if(sourceobj != null){
	    	$scope.fd.createFrom = sourceobj.sourceType;
	    	if($scope.fd.createFrom == 'B'){
	    		var promise = $scope.fd.getDbSorceList();
	        	promise.then(function(){
	        		$scope.fd.db.dbSource = $.grep($scope.fd.db.sourceList,function(obj){
	            		return obj.dbSourceName == sourceobj.sourceName;
	            	})[0];
	        		$scope.fd.dbSelectQuery = sourceobj.query;
	        		$scope.fd.selectedTableName = sourceobj.sourceTable;
	        		var promise2 = $scope.fd.showDbTables();
	        		promise2.then(function(){
	        			/*var promise3 = $scope.fd.executeSelectQuery('E');
	        			promise3.then(function(){*/
	        				d.resolve();
	        			/*});*/
	        		});
	        	});
	    	}else if($scope.fd.createFrom == 'R'){
	    		$scope.fd.remote.fileNamePattern = sourceobj.fileNamePattern;
	    		$scope.fd.remote.currentFolderselected = sourceobj.folderPath;
	    		$scope.fd.remote.currentFolderselectedFile = sourceobj.folderPath;
	    		var promise = $scope.fd.getHostList();
	    		promise.then(function(){
	    			$scope.fd.remote.hostServer = $.grep($scope.fd.remote.hostList,function(fobj){
	    				return fobj.fileSourceName == sourceobj.sourceName;
	    			})[0];
	    			d.resolve();
	    			/*var promise2 = listRemoteServerFolders(sourceobj.sourceName,false,sourceobj.folderPath);
	    			promise2.then(function(){
	    				d.resolve();
	    			});*/
	    		});
	    	}else if($scope.fd.createFrom == 'L'){
				$scope.fd.filePath = sourceobj.filePath;
				$scope.fd.fileNamePattern = sourceobj.fileNamePattern;
				d.resolve();
			}
	    	else if($scope.fd.createFrom == 'D'){
	    		$scope.fd.filePath = sourceobj.filePath;
	    		d.resolve();
	    	}
    	}
    	return d.promise;
    }
    
    function prepareFileMappingVOForEdit(mappingobj,fdobj){
    	$scope.fd.fileActionType = fdobj.fileAction;
    	
    	if(fdobj.fileType == 'D'){
    		var promise = $scope.fd.listStagingTables();
    		promise.then(function(){
    			$scope.fd.selectedStaggingTable = $.grep($scope.fd.stagingTablesList,function(obj){
    				return obj.physicalTableName == fdobj.tableName;
    			})[0];
    			$scope.fd.prepareStaggingMappingColumns();
    			prepareDataMappingVOForEdit(mappingobj);
    		});
    	}else if(fdobj.fileType == 'B'){
    		if(fdobj.audienceID != 0 && fdobj.audienceID != null && fdobj.audienceID != undefined){
        		$scope.fd.selectedAudience = $.grep($scope.fd.audienceList,function(obj){
        			return obj.audienceId == fdobj.audienceID;
        		})[0];
        	}
    		var promise = $scope.fd.getAudienceColumns($scope.fd.selectedAudience,fdobj);
    		promise.then(function(){
    			prepareDataMappingVOForEdit(mappingobj);
    		});
    	}else{
    		prepareDataMappingVOForEdit(mappingobj);
    	}
    }
    
    function prepareDataMappingVOForEdit(mappingobj){
    		$scope.fd.fdMappingVOList = [];
    		angular.forEach(mappingobj.columnDefinitionList,function(obj){
    			fileDefMappingVO = {};
    			fileDefMappingVO.header = obj.columnName;
    			fileDefMappingVO.sampleDataColumns = undefined;
    			fileDefMappingVO.sampleDataColumn = undefined;
    			if($scope.fdvo.fileType == 'R' || $scope.fdvo.fileType == 'U'){
    				if($scope.fdvo.channelType == 'E'){
					var selected = $.grep($scope.fd.dataTypes,function(obj){
						return obj.key == 7;
					});
					fileDefMappingVO.dataTypeList = selected;
    				}else if($scope.fdvo.channelType == 'S'){
						var selected = $.grep($scope.fd.dataTypes,function(obj){
							return obj.key == 8;
						});
						fileDefMappingVO.dataTypeList = selected;
    				}
    			}else{
    				fileDefMappingVO.dataTypeList = $scope.fd.dataTypes;
    			}
    			fileDefMappingVO.dataType = $.grep($scope.fd.dataTypes,function(dobj){
        			return dobj.value == obj.columnType;
        		})[0];
    			if($scope.fdvo.fileType == 'B' || $scope.fdvo.fileType == 'D'){
    				fileDefMappingVO.audienceColumn = $.grep($scope.fd.audienceColumns,function(data){
    					if(obj.isCustomColumn == 'Y')return 'Is Custom' == data.logicalColumnName;
    					else return data.logicalColumnName == obj.logicalColumnName;
            		})[0];
    				if(fileDefMappingVO.audienceColumn){
    					if(fileDefMappingVO.audienceColumn.physicalColumnName == "EMAIL_ADDRESS" || fileDefMappingVO.audienceColumn.physicalColumnName == "SMS_NUMBER"){
    						fileDefMappingVO.addressTypeDisable = true;
    					}
    				}else{
    					fileDefMappingVO.audienceColumn =  $.grep($scope.fd.audienceColumns,function(obj){return obj.logicalColumnName == 'Omit';})[0];
    				}
    			}
    			fileDefMappingVO.defaultValue = obj.defaultValue;
    			fileDefMappingVO.isNullable = obj.isNullable;
    			fileDefMappingVO.length = obj.length;
    			obj.disableLength = true;
    			if(obj.addressType){
    				if(obj.columnType == "EMAIL"){
    					fileDefMappingVO.addressType = $.grep($scope.fd.emailAddressType,function(email){return email[0] == obj.addressType;})[0];
    					fileDefMappingVO.enableEmailAddress = true;
    				}else if(obj.columnType == "SMS"){
    					fileDefMappingVO.smsAddressType = $.grep($scope.fd.smsAddressType,function(sms){return sms[0] == obj.addressType;})[0];
    					fileDefMappingVO.enableSmsAddress = true;
    				}
    				
    			}
    			if(obj.logicalColumnName != null  && obj.logicalColumnName.toUpperCase() != "OMIT"){
    				fileDefMappingVO.disableSelect = true;
    			}
    			$scope.fd.fdMappingVOList.push(fileDefMappingVO);
    		});
    	$scope.fd.fdMappingVOList = $scope.fd.fdMappingVOList;
    	
    }
    
    function prepareScheduleVOForEdit(schobj,fdobj){
    	$scope.fd.scd.scheduleactivemode = fdobj.scheduleactivemode;
    	$scope.fdvo.fileDefinitionID = fdobj.fileDefinitionID;
    	if(fdobj.scheduleactivemode == 'Y' || (fdobj.scheduleactivemode == 'N' && schobj.fileScheudleID && schobj.fileScheudleID != 0)){
	    	$scope.fdvo.fileScheudleID = schobj.fileScheudleID;
	    	$scope.fd.scd.frequency = schobj.frequency;
	    	$scope.fd.scd.frquencyunit = schobj.frequencyUnit;
	    	$scope.fd.scd.monthlyDayFreq= schobj.monthlyDayFreq;
	    	$scope.fd.scd.monthlyschdfreq = schobj.monthlySchdFreq;
	    	$scope.fd.scd.monthlyWeekFreq = schobj.monthlyWeekFreq;
	    	$scope.fd.scd.endDate = schobj.scheduleEndDate;
	    	var startdate = schobj.scheduleStartDate;
	    	if(startdate != null){
		    	var date = startdate.split(' ')[0];
		    	var time = startdate.split(' ')[1].substring(0,startdate.split(' ')[1].lastIndexOf(':'));
		    	$scope.fd.scd.startDate = date;
		    	$scope.fd.scd.startTime = time;
	    	}
	    	if(schobj.monthlySchdFreq != undefined){
	    		$scope.fd.scd.monthlyschdfreq = schobj.monthlySchdFreq;
	    		if(schobj.monthlySchdFreq == 'D'){
	    			$scope.fd.scd.dayofeverymonth = schobj.dayOfEveryMonth;
	            }else if(schobj.monthlySchdFreq == 'T'){
	            	$scope.fd.scd.monthlyWeekFreq = schobj.monthlyWeekFreq;
	            	$scope.fd.scd.monthlyDayFreq = schobj.monthlyDayFreq;
	            }
	    	}
	    	if(schobj.scheduleEndDate != null){
	    		$scope.fd.scd.endDate = schobj.scheduleEndDate.split(' ')[0];
	    	}
	    	$scope.fd.scd.timezone = schobj.timeZone;
    	}else{
    		$scope.fd.setTimezone();
    	}
    }
    
    $scope.fd.editFileDefinition = function(obj){
    	$scope.savedFiledefinition= true;
    	$scope.fdvo = {};
    	$scope.fd.defaultFiledefinitionValues();
    	$scope.fd.isEditMode = 'Y';
    	var fdObj = angular.copy(obj);
    	$scope.fdobjnotifications=angular.copy(fdObj.notifications);
    	if(fdObj.fileMapping && fdObj.fileMapping.columnDefinitionList)
    		$scope.editfilemapping = fdObj.fileMapping.columnDefinitionList;
    	if(fdObj.fileSource && fdObj.fileSource.sourceType == 'D'){
			fdObj.fileMapping.columnDefinitionList = [];
		}
    	if(fdObj.fileScheduleBO.frequency != undefined){
    		if(fdObj.fileScheduleBO.frequency == 'I' || fdObj.fileScheduleBO.frequency == 'O'){
        		$scope.fd.fdType = 'O';
        	}else{
        		$scope.fd.fdType = 'R';
        		$scope.fd.createFromList = $.grep($scope.fd.createFromList,function(obj){return obj.key != 'D'});
        	}
    	}else{
    		$scope.fd.fdType = 'O';
    	}
    	$scope.fdvo = fdObj;
    	if(fdObj.fileProcessingOptions)
    		$scope.fdvo.fileProcessingOptions = fdObj.fileProcessingOptions;
    	setTimeout(function(){
    		var promise = prepareFileSorceSpecVOForEdit(fdObj.fileSource);
        	promise.then(function(){
        		setTimeout(function(){
        			prepareFileMappingVOForEdit(fdObj.fileMapping,fdObj);
        		},1000);
        	});
    	},500);
    	
    	$timeout(function() { prepareScheduleVOForEdit(fdObj.fileScheduleBO,fdObj);}, 500);
    	$scope.fdvo.fileFormatSpec = fdObj.fileFormatSpec;
    	//$scope.fdvo.fileScheduleVO = fdObj.fileSchedule;
    	$scope.fdvo.FileSourceSpecVO = fdObj.fileSource;
    	if($scope.fdvo.FileSourceSpecVO && $scope.fdvo.FileSourceSpecVO.sourceType == 'R'){
    		$timeout(function() { $scope.fd.loadRemoteFolders();}, 1500);
    	}
    	if(fdObj.notifications){
    		if(fdObj.notifications.notificationStatuses){
    			angular.forEach(fdObj.notifications.notificationStatuses,function(obj){
    				if(obj.isEnabled && obj.emailAddresses != null && obj.emailAddresses == fdObj.notifications.defaultEmailAddresses){
    					obj.emailAddresses = undefined;
    				}
    			});
    		}
    		$scope.notifications = fdObj.notifications;
    	}
    	$scope.FileActionMappingVO = fdObj.fileMapping;
		$scope.fd.includescrubrules = fdObj.fileMapping.includeScrubRules;
		$scope.fd.endingwithtext=fdObj.fileMapping.scrubrulesEndingWithText;
		$scope.fd.setScrubRulesForDisplay();
		$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/neworeditfiledefinition.html";
		prepareDepartmentsUnSubAndReSub(fdObj.unsubResubProperties);
		if(fdObj.fileAction)
			$scope.fd.fileActionType = fdObj.fileAction;
		if(fdObj.tableDisposition){
			$scope.fdvo.tableDisposition = fdObj.tableDisposition;
		}
		if(fdObj.useEncryption == 'Y'){
			$scope.fdvo.encryptionKey = fdObj.encryptionKey;
		}
		if($scope.fdvo.fileType == 'D' || $scope.fdvo.fileType == 'B'){
    		if(fdObj.sendWorkFlow=='Y' && fdObj.workFlowID != 0){
    			fileDefinitionService.getTriggeredWorkFlows(zhapp.loginUser.departmentID).success(function(result){
    				$scope.fd.workFlows = [];
    				if(result != null && result != undefined && result.length > 0){
    					var list = [];
    					angular.forEach(result,function(obj){
    						var temp = {};
    						temp = obj.listWorkflowEditor;
    						temp.id = obj.id;
    						list.push(temp);
    					});
    					angular.forEach(list,function(obj){
    						if(obj.enablemode == "Y"){
    							$scope.fd.workFlows.push(obj);
    						}
    					});
    	    			$scope.fdvo.sendWorkFlow = 'Y';
    	    			$scope.fdvo.workFlowID = fdObj.workFlowID;
    				}
    			});
    		}else{
    			fileDefinitionService.getTriggeredWorkFlows(zhapp.loginUser.departmentID).success(function(result){
    				$scope.fd.workFlows = [];
    				if(result != null && result != undefined && result.length > 0){
    					var list = [];
    					angular.forEach(result,function(obj){
    						var temp = {};
    						temp = obj.listWorkflowEditor;
    						temp.id = obj.id;
    						list.push(temp);
    					});
    					angular.forEach(list,function(obj){
    						if(obj.enablemode == "Y"){
    							$scope.fd.workFlows.push(obj);
    						}
    					});
    				}
    			});
    			$scope.fdvo.sendWorkFlow = 'N';
    			$scope.fdvo.workFlowID = undefined;
    		}
		}
    }
    
   
    function prepareDepartmentsUnSubAndReSub(unsubResubProperties){
    	
    	if(unsubResubProperties == null){
    		return;
    	}
    	if($scope.fdvo.fileType == 'U' || $scope.fdvo.fileType == 'R'){
			fileDefinitionService.getAllFileDepartments().success(function(result){
	    		$scope.fd.departments = [];
	    		$scope.fd.deptSelectAll = false;
	    		angular.forEach(result,function(key,val){
	    			var obj = {};
	    			obj.id = val;
	    			obj.name = key;
	    			obj.isSelected = false;
	    			$scope.fd.departments.push(obj);				
				});
	    		if($scope.fdvo.fileType == 'U'){
	    			$scope.fd.ignoreEmail = unsubResubProperties.ignoreEmail;
	    			$scope.fd.global = unsubResubProperties.global;
	    			if(unsubResubProperties.enabledepartment == 'Y'){
	    				$scope.fd.department = 'Y';
	    				var depts = unsubResubProperties.departments.split(",");
	    				if(depts.indexOf("-1") == -1){
		    				for(var i = 0; i < depts.length; i++) {
		    					angular.forEach($scope.fd.departments,function(department){
		    						if(department.id == depts[i]){
		    							department.isSelected = true;
		    						}
		    					});
		    				}
		    				var selectedDepts = $.grep($scope.fd.departments,function(obj){
		    	    			return obj.isSelected == true;
		    	    		});
		    				if(selectedDepts.length == $scope.fd.departments.length){
		    					$scope.fd.deptSelectAll = true;
		    				}else{
		    					$scope.fd.deptSelectAll = false;
		    				}
	    				}else{
	    					$scope.fd.deptSelectAll = true;
	    					angular.forEach($scope.fd.departments,function(department){
	    						department.isSelected = true;
	    					});
	    				}
	    			}			
	    		}else if($scope.fdvo.fileType == 'R'){
	    			$scope.fd.global = unsubResubProperties.global;
	    			$scope.fd.ignoreEmail = unsubResubProperties.ignoreEmail;
	    			$scope.fd.HardBounce = unsubResubProperties.hardBounce;
	    			$scope.fd.SoftBounce = unsubResubProperties.softBounce;
	    			$scope.fd.BlockBounce = unsubResubProperties.blockBounce;
	    			$scope.fd.UnknownBounce = unsubResubProperties.unknownBounce;
	    			if(unsubResubProperties.enabledepartment == 'Y'){
	    				$scope.fd.department = 'Y';
	    				var depts = unsubResubProperties.departments.split(",");
	    				if(depts.indexOf("-1") == -1){
		    				for(var i = 0; i < depts.length; i++) {
		    					angular.forEach($scope.fd.departments,function(department){
		    						if(department.id == depts[i]){
		    							department.isSelected = true;
		    						}
		    					});
		    				}
		    				var selectedDepts = $.grep($scope.fd.departments,function(obj){
		    	    			return obj.isSelected == true;
		    	    		});
		    				if(selectedDepts.length == $scope.fd.departments.length){
		    					$scope.fd.deptSelectAll = true;
		    				}
	    				}else{
	    					$scope.fd.deptSelectAll = true;
	    					angular.forEach($scope.fd.departments,function(department){
	    						department.isSelected = true;
	    					});
	    				}
	    			}
	    		}
			}).error(function(error){
				showErrorMessage($scope.fd.getErrorMessages(error));
			});
		}
    }
    
    
    function dateToNormalStringUtil(d){
    	var hh = d.getHours(); 
    	var min = d.getMinutes(); 
    	var suffix = "AM"; 
    	var hours = hh;
    	if (min.toString().length == 1) 
    	    min = "0" + min;        	
    	var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
        return Datetime;
    };
    
    $scope.fd.searchByValues = [{		
        'key': 'ID',		
        'value': 'ID'		
    }, {		
        'key': 'Name',		
        'value': 'Name'		
    }, {		
        'key': 'Created On',		
        'value': 'Created On'		
    }, {		
        'key': 'Last Modified',		
        'value': 'Last Modified'		
    }];		
    $scope.fd.activitysearchByValues = [ 
        {
			'key' : 'ID',
			'value' : 'ID'
		},/*{
			'key' : 'File ID',
			'value' : 'File ID'
		},*/  {
			'key' : 'File Name',
			'value' : 'File Name'
		}, {
			'key' : 'Status',
			'value' : 'Status'
		},  {
			'key' : 'Started On',
			'value' : 'Started On'
		}, {
			'key' : 'Completed On',
			'value' : 'Completed On'
		}, {
			'key' : 'Batch ID',
			'value' : 'Batch ID'
		} ];
   
 $scope.activitysearchBy = $scope.fd.activitysearchByValues[0].value;
    		
 $scope.loadScheduleEvents = function() {		
    			
        $('.timepicker').timepicker({		
            showSeconds: false,		
            showMeridian: false,		
            defaultTime: false,		
            disableFocus: false,		
            minuteStep: 1		
        });		
        $('.cal-icon').click(function() {		
            $(this).prev("input").trigger('focus');		
        });		
        $(".scheduleTimeField").datepicker({		
            autoclose: true,		
            todayHighlight: true,		
            //startDate: new Date()		
        });		
    };		
    		
    $scope.clearSearch = function(){
    	$scope.fd.searchtext = '';
		$scope.fd.searchBy = "ID";
    	$scope.fd.loadPageDetails(1);
    }
    
    
    $scope.searchByValue = function(serachValue, event) {		
        // alert(event.keyCode);
        if (event.type == "click" || event =="click" || event.keyCode == 13) {		
            var searchCriteria = {};		
            //if($scope.fd.currentPageNumber === undefined )		
                searchCriteria.pageno = $scope.fd.searchCriteria.pageno;            
             // else
              	 //searchCriteria.pageno=$scope.fd.currentPageNumber; 
            if(serachValue != undefined && event.type == "click"){
            	event.keyCode = 8;
            	$scope.fd.searchtext = serachValue;
            }
            searchCriteria.pagesize = 7;	
            $scope.searchtext = serachValue;		
            if ($scope.fd.searchBy == "ID") {		
                if ($scope.searchtext == 0) {		
                    showErrorMessage("Enter id value more than 0.");		
                    $scope.searchtext = '';		
                    return false;		
                }		
                if (isNaN($scope.searchtext)) {		
                    showErrorMessage("Please Enter Numeric Values Only .");		
                    $scope.searchtext = '';		
                    return;		
                } else {		
                    searchCriteria.id = $scope.searchtext;		
                }		
            } else if ($scope.fd.searchBy == "Name") {		
                searchCriteria.namelike = $scope.searchtext;		
            } else if ($scope.fd.searchBy == "Max Files") {		
                if (isNaN($scope.searchtext)) {		
                    showErrorMessage("Please Enter Numaric Values Only .");		
                    $scope.searchtext = '';		
                    return;		
                } else {		
                    searchCriteria.maxFiles = $scope.searchtext;		
                }		
            } else if ($scope.fd.searchBy == "Ignore Bad") {		
                searchCriteria.ignorebadfiles = $scope.searchtext;		
                if ($scope.searchtext != "Y" && $scope.searchtext != "N" && $scope.searchtext != "y" && $scope.searchtext != "n") {		
                    showErrorMessage("Please Enter Y or N only.");		
                    return;		
                }		
            } else if ($scope.fd.searchBy == "Created On") {
            	if($scope.fd.fromDate == undefined ||$scope.fd.fromDate.trim().length==0 ){
            		  showErrorMessage("Please Select FromDate.");		
                      return;
            	}
            	else
            		searchCriteria.createdFromDate = $scope.fd.fromDate+" 00:00:00";
            	if($scope.fd.toDate == undefined ||$scope.fd.toDate.trim().length==0 ){
            			showErrorMessage("Please Select ToDate.");		
                		return;
            	}
            	else
            		searchCriteria.createdToDate = $scope.fd.toDate+" 23:59:59";
                if (new Date($scope.fd.fromDate) > new Date($scope.fd.toDate)) {		
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }	            
            } else if ($scope.fd.searchBy == "Last Modified") {		
            	if($scope.fd.fromDate == undefined ||$scope.fd.fromDate.trim().length==0 ){
          		  showErrorMessage("Please Select FromDate.");		
                    return;
            	}
            	else
            	   searchCriteria.updatedFromDate = $scope.fd.fromDate+" 00:00:00";
            	if($scope.fd.toDate == undefined ||$scope.fd.toDate.trim().length==0 ){
        			showErrorMessage("Please Select ToDate.");		
            		return;
            	}
            	else
                    searchCriteria.updatedToDate = $scope.fd.toDate+" 23:59:59";
                if (new Date($scope.fd.fromDate) > new Date($scope.fd.toDate)) {	
                    showErrorMessage("Please Select the FromDate is LessThan or Equal to ToDate.");		
                    return;		
                }
            }
            searchCriteria.departmentID = zhapp.loginUser.departmentID;            		
            var promisefdlist = $scope.fd.listFileDefinitions(searchCriteria);		
    			promisefdlist.then(function(fdList){		
    				angular.forEach(fdList.result,function(key){				
    					key.show = true;		
    				});		
    				$scope.fd.fileDefinitionList = fdList.result;		
    				$scope.fd.fileActivites = fdList.activies;				
    				// console.log(JSON.stringify($scope.fd.fileActivites));
    				if($scope.fd.fileDefinitionList <= 0){
    	    			  $scope.fd.infoMessage = "No Files Found";
    	    				//showErrorMessage("No Files Found");
    	    			  return;
    	    		}
    				angular.forEach(fdList.activies,function(key,value){				
    	    			angular.forEach($scope.fd.fileDefinitionList,function(eachObj){				
    	        			if(value == eachObj.fileDefinitionID && key != 0){				
    	        				eachObj.isActivity = true;				
    	        			}				
    	    			});				
    				});		
    			});		
            		
           		
        }		
        if ((event.keyCode == 8 || event.keyCode == 46) && $scope.fd.searchtext.length == 0) {		
            $scope.fd.loadPageDetails(1);
            
        }		
    }
    
    $scope.fd.navigateBack = function(){
		showCommonConfirmMessage("Do you want to save changes?","Confirm","Yes","No",450,function(value){
			if(value == false){
				$scope.fdvo = undefined;
		    	$scope.fdhome.fileDefinitionTemplate = "filedefinition/templates/filedefinitionlist.html";
		    	$scope.fd.searchCriteria = undefined;
		    	$scope.fd.initializeFileDefinition();
			}else{
				$scope.fd.saveFileDefinition();
			}
		});
    }
    $scope.fd.addField = function(){
    	if(!$scope.fd.isFileUploaded && $scope.fd.createFrom == 'D'){
    		showErrorMessage('Upload File.');
    		return;
    	}
    	var filedefmappingvo = {};
    	filedefmappingvo.header = 'column_'+$scope.fd.fdMappingVOList.length;
    	filedefmappingvo.isnullable = 'Y';
    	filedefmappingvo.defaultValue = undefined; 
    	filedefmappingvo.length = 400;
    	if($scope.fdvo.fileType == 'B' && $scope.fd.selectedAudience && $scope.fd.selectedAudience.audienceType != 0){
			var list = $.grep($scope.fd.dataTypes,function(data){
				return (data.value != 'EMAIL' && data.value != 'SMS');
			});
			filedefmappingvo.dataTypeList = list;
		}else{
			filedefmappingvo.dataTypeList = $scope.fd.dataTypes;
		}
    	filedefmappingvo.sampleDataColumns = [];
    	$scope.fd.fdMappingVOList.push(filedefmappingvo);
    }
    
    $scope.fd.selectDepartments = function(){
    	$scope.departments = angular.copy($scope.fd.departments);
    	$('.seldept-pop').dialog('open');
    }
    
    $scope.fd.updateSelection = function(dept){
    	//dept.isSelected = !dept.isSelected;
    	if(dept.isSelected){
    		var selectedDepts = $.grep($scope.fd.departments,function(obj){
    			return obj.isSelected == false;
    		});
    		if(selectedDepts.length > 0){
    			$scope.fd.deptSelectAll = false;
    		}else{
    			$scope.fd.deptSelectAll = true;
    		}
    	}else{
    		$scope.fd.deptSelectAll = false;
    	}
    }
    
    $scope.fd.selectAllDeptsList=function() {
    	if($scope.fd.deptSelectAll){
    		angular.forEach($scope.fd.departments,function(obj){
    			obj.isSelected = true;
    		});
    	}else{
    		angular.forEach($scope.fd.departments,function(obj){
    			obj.isSelected = false;
    		});
    	}
	};
	$scope.fd.cancelDepartments = function(){
		if($scope.departments){
			$scope.fd.departments = [];
			$scope.$evalAsync(function(){
				$scope.fd.departments = $scope.departments;
				var selectedDepts = $.grep($scope.fd.departments,function(obj){
	    			return obj.isSelected == true;
	    		});
				if(selectedDepts && selectedDepts.length == $scope.fd.departments.length){
					$scope.fd.deptSelectAll = true;
				}else{
					$scope.fd.deptSelectAll = false;
				}
			});
		}
		
	}
	
	$scope.fd.saveDepartments = function(){
		var obj = {};
		if($scope.fdvo.fileType == 'U'){
			obj.ignoreEmail = $scope.fd.ignoreEmail;
			obj.global = $scope.fd.global;
			if($scope.fd.department == 'Y'){
				obj.enabledepartment = $scope.fd.department;
				var res = "";
				angular.forEach($scope.fd.departments,function(obj){
					if(obj.isSelected == true){
						res = res + obj.id +",";
					}
				});
				if(res == ""){
					showErrorMessage("Please select the Departments.");
					return;
				}
				 if(res.length > 1){
					 res = res.substring(0,res.length-1);
				 }
				 obj.departments = res;
			}
		}else if($scope.fdvo.fileType == 'R'){
			obj.ignoreEmail = $scope.fd.ignoreEmail;
			obj.global = $scope.fd.global;
			if($scope.fd.department == 'Y'){
				obj.enabledepartment = $scope.fd.department;
				var res = "";
				angular.forEach($scope.fd.departments,function(obj){
					if(obj.isSelected == true){
						res = res + obj.id +",";
					}
				});
				if(res == ""){
					showErrorMessage("Please select the Departments.");
					return;
				}
				 if(res.length > 1){
					 res = res.substring(0,res.length-1);
				 }
				 obj.departments = res;
			}
			obj.hardBounce = $scope.fd.HardBounce;
			obj.softBounce = $scope.fd.SoftBounce;
			obj.blockBounce = $scope.fd.BlockBounce;
			obj.unknownBounce = $scope.fd.UnknownBounce;
		}
		$(".seldept-pop").dialog("close");
		return obj;
		
	}
	
    $scope.fd.initializePopups = function(){
    	if($scope.fdhome.fileDefinitionTemplate != "filedefinition/templates/filedefinitionlist.html"){
    		$(".filedef-remotedb-popup,.filedef-remotedb-sample-popup,.filedef-remotedb-popup,.queryBuilderPopup,.executeSQLQuery,.seldept-pop").dialog({
    			autoOpen: false,
    			resizable : false,
    			width : 900,
    			modal : true,
    			closeOnEscape : false
    		});
    		$(".filesInFolder").dialog({
    			autoOpen: false,
    			resizable : false,
    			modal : true,
    			closeOnEscape : false,
    			maxWidth:600,
    	        maxHeight: 400,
    	        width: 600,
    	        height: 400,
    	        draggable: false,
    	        close: function( event, ui ) {
    	        	$scope.mapDataForRemoteServer($scope.fd.remoteFileData);
    	        }
    		});
    		
    		$(".filedef-remotedb-popup").dialog({
    			open : function(){
    				$('.fil-properties-scroll').slimScroll({
    		 			color: '#a9a9a9',
    		 			height: '300px',
    		 			size: '6px',
    		 			wheelStep:1,
    		 			railVisible: true,
    		 			alwaysVisible: false
    		 		});
    			}
    		});
    		
    		$(".close-popup").click(function(){
    			$(".filedef-remotedb-popup,.filedef-remotedb-sample-popup,.filedef-remotedb-popup,.queryBuilderPopup,.executeSQLQuery,.seldept-pop,.filesInFolder").dialog('close');
    		});
    		$(".close-popupsub").click(function(){
    			$(".executeSQLQuery").dialog('close');
    		});
    		
    	}
    }
   
     
    $scope.fd.getEncryptedKeyList = function(){
    	fileDefinitionService.getEncryptedKeysList().success(function(result){
    		$scope.fd.encryptionKeysList = result;
    	}).error(function(error){
    		
    	});
    }
    
    $scope.fd.upmove = function(index){
    	if (index == -1) {
            return false;
        }
        if ($scope.fd.fdMappingVOList[index - 1]) {
            $scope.fd.fdMappingVOList.splice(index - 1, 2, $scope.fd.fdMappingVOList[index], $scope.fd.fdMappingVOList[index - 1]);
        } else {
            return 0;
        }

    }
    
    $scope.fd.downMove = function(index){
    	$scope.fd.downMove = function(index) {
        if (index == -1) {
            return false;
        }
        if ($scope.fd.fdMappingVOList[index + 1]) {
            $scope.fd.fdMappingVOList.splice(index, 2, $scope.fd.fdMappingVOList[index + 1], $scope.fd.fdMappingVOList[index]);
        } else {
            return 0;
        }
    }
    }
    $scope.fd.showmapping = function(){
    	if($scope.fd.createFrom == 'R' || $scope.fd.createFrom == 'B' || $scope.fd.createFrom == 'D' || $scope.fd.createFrom == 'L'){
    		return false;
    	}else{
    		return true;
    	}
    }
    $scope.mapDataForRemoteServer = function(result){
    		$scope.showLoadingDiv = true;
			if(result != null){
				$scope.fd.fdMappingVOList = [];
				var selected = [];
				if($scope.fdvo.fileType == 'R' || $scope.fdvo.fileType == 'U'){
    				if($scope.fdvo.channelType == 'E'){
    					selected = $.grep($scope.fd.dataTypes,function(obj){
						return obj.key == 7;
					});
    				}else if($scope.fdvo.channelType == 'S'){
						selected = $.grep($scope.fd.dataTypes,function(obj){
							return obj.key == 8;
						});
    				}
    			}else{
    				selected = $scope.fd.dataTypes;
    			}
				setTimeout(function(){
					$.each(result,function(index,value){
		    			fileDefMappingVO = {};	    			
		    			fileDefMappingVO.header = value.key;
	    				fileDefMappingVO.sampleDataColumns = value.values;
	    				fileDefMappingVO.sampleDataColumn = value.values[0];
	    				fileDefMappingVO.dataTypeList = selected;
		    			if($scope.fd.audienceColumns != undefined){
			    			fileDefMappingVO.audienceColumn = $.grep($scope.fd.audienceColumns,function(obj){
			    				return obj.logicalColumnName == 'Omit';
			    			})[0];
		    			}
		    			fileDefMappingVO.length = 400;
		    			fileDefMappingVO.disableLength = true;
		    			fileDefMappingVO.isNullable = 'N';
		    			$scope.fd.fdMappingVOList.push(fileDefMappingVO);
		    		});
					mapDefaultColumnsData(); 
				},1000);
	    		
			}else{
				$scope.showLoadingDiv = false;
			}
			$scope.fd.remoteFileData = [];
    }
    $scope.fd.getFilesInFolder = function(){
    	$scope.fd.filesInFolder = {};
    	$scope.fd.filesInFolder.head = [];
		$scope.fd.filesInFolder.data = [];
		var headerrow = "0";
		var datarow = "1";
		var delimit = ",";
		var textqualifier = "NONE";
		if($scope.fdvo.fileFormatSpec != null){
			if($scope.fdvo.fileFormatSpec.delimiter)delimit = $scope.fdvo.fileFormatSpec.delimiter;
			if($scope.fdvo.fileFormatSpec.textQualifier)textqualifier = $scope.fdvo.fileFormatSpec.textQualifier;
			if($scope.fdvo.fileFormatSpec.headerRowAtLine)headerrow = $scope.fdvo.fileFormatSpec.headerRowAtLine;
			if($scope.fdvo.fileFormatSpec.dataStartsFromLine)datarow = $scope.fdvo.fileFormatSpec.dataStartsFromLine;
		}
    	if($scope.fd.remote.hostServer.protocol=='http' || $scope.fd.remote.hostServer.protocol=='https'){
    		var rfileexten = $scope.fd.remote.hostServer.hostname.substring($scope.fd.remote.hostServer.hostname.lastIndexOf(".") + 1,$scope.fd.remote.hostServer.hostname.length); 
    		if(rfileexten.toLowerCase()=="txt" || rfileexten.toLowerCase()=="csv"){
    			fileDefinitionService.getFoldersFromRemoteServerWithDelimiter($scope.fd.remote.hostServer.fileSourceName,true,$scope.fd.remote.hostServer.hostname,headerrow,datarow,delimit,textqualifier).success(function(result){
    				if(result != null){
    					var allRows = [];
    					var length = undefined;
    					angular.forEach(result,function(obj,index){
    						//index = index.substring(0,index.lastIndexOf('_'));
    						if(obj.length == 0)return;
            				$scope.fd.filesInFolder.head.push(obj.key);
            				allRows.push(obj.values)
            				if(!length)
            					length = obj.values.length;
            			});
            			for(var i=0;i<length;i++){
            				var row = [];
            				angular.forEach(allRows,function(obj,index){
            			        row.push(obj[i]);
                			});
            				$scope.fd.filesInFolder.data.push(row);
            			}
            			$(".filesInFolder").dialog('open');
            			$scope.fd.remoteFileData = result;
            			//setTimeout(function(){$scope.mapDataForRemoteServer(result);},10);
        			}
        		}).error(function(error){
        			showErrorMessage("File is Not Available");
            	});
    		}else{
    			showErrorMessage("Please select csv or text file");
    			return;
    		}
    	}else{
    		var rfileexten = $scope.fd.remote.currentFolderselectedFile.substring($scope.fd.remote.currentFolderselectedFile.lastIndexOf(".") + 1,$scope.fd.remote.currentFolderselectedFile.length); 
    		if(rfileexten.toLowerCase()=="txt" || rfileexten.toLowerCase()=="csv"){
    			fileDefinitionService.getFoldersFromRemoteServerWithDelimiter($scope.fd.remote.hostServer.fileSourceName,true,$scope.fd.remote.currentFolderselectedFile,headerrow,datarow,delimit,textqualifier).success(function(result){
    				if(result != null){
    					var allRows = [];
    					var length = undefined;
    					angular.forEach(result,function(obj,index){
    						//index = index.substring(0,index.lastIndexOf('_'));
    						if(obj.length == 0)return;
            				$scope.fd.filesInFolder.head.push(obj.key);
            				allRows.push(obj.values)
            				if(!length)
            					length = obj.values.length;
            			});
            			for(var i=0;i<length;i++){
            				var row = [];
            				angular.forEach(allRows,function(obj,index){
            			        row.push(obj[i]);
                			});
            				$scope.fd.filesInFolder.data.push(row);
            			}
            			//$scope.mapDataForRemoteServer(result);
            			$(".filesInFolder").dialog('open');
            			$scope.fd.remoteFileData = result;
            			//setTimeout(function(){$scope.mapDataForRemoteServer(result);},10);
        			}
        		}).error(function(error){
        			if(error.errors[0].message.startsWith("FL0067 : Loading")){
        				showErrorMessage("Select a file to view the sample data");
        			}else
        			showErrorMessage($scope.fd.getErrorMessages(error));
        		});
    		}else{
    			showErrorMessage("Please select csv or text file");
    			return;
    		}
    	}
    }
    
    $scope.restrictSpecialChars = function(){
    	if($scope.fdvo.tableName != undefined && $scope.fdvo.tableName.length > 0){
    		var count = 0;
    		//$scope.fdvo.tableName = $scope.fdvo.tableName.replace(/(^[^a-zA-Z]|[^_$a-zA-Z0-9])/g, '');
    		$scope.tablePrefix = ["ADHOC_","DE_","DIM_","RV_","S_D_","STG_","S_F_"];
    		angular.forEach($scope.tablePrefix, function(value, key) {
    		  if ($scope.fdvo.tableName.startsWith(value)) {
    			  count++;
    		  }
    		});
    		var valid = $scope.fdvo.tableName.charAt(0).match(/[a-z]/i);
    		if(valid==null || valid == undefined){
    			showErrorMessage("Table name should not start with number or special character.");
    		}
    		if(count > 0){
    			showErrorMessage("System tables are not allowed.");
    			$scope.fdvo.tableName='';
    		}
    	}
    }
    
    $scope.restrictSpecialCharForDataMap = function(index){
    	var obj = $scope.fd.fdMappingVOList[index];
    	if(obj && obj.header && obj.header != ''){
    		obj.header = obj.header.replace(/(^[^a-zA-Z]|[^_$a-zA-Z0-9])/g, '');
    		$scope.fd.fdMappingVOList[index] = obj;
    	}
    }
   
    $scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.fd.searchCriteria.sortorder = 'DESC';
		}else{
			$scope.fd.searchCriteria.sortorder = 'ASC';
		}
		
		if($scope.adminModule.sortby == 'createdon'){
			$scope.fd.searchCriteria.sortby='createdate';
		}else{
			$scope.fd.searchCriteria.sortby=$scope.adminModule.sortby;
		}
		$scope.fd.searchCriteria.departmentID = zhapp.loginUser.departmentID;
		var promisefdlist = $scope.fd.listFileDefinitions($scope.fd.searchCriteria);		
		promisefdlist.then(function(fdList){		
			angular.forEach(fdList.result,function(key){				
				key.show = true;		
			});		
			$scope.fd.fileDefinitionList = fdList.result;		
			$scope.fd.fileActivites = fdList.activies;				
			angular.forEach(fdList.activies,function(key,value){				
    			angular.forEach($scope.fd.fileDefinitionList,function(eachObj){				
        			if(value == eachObj.fileDefinitionID && key != 0){				
        				eachObj.isActivity = true;				
        			}				
    			});				
			});		
		});
		
    });
    $scope.fd.resetSearch = function(){
    	$scope.fd.searchtext=undefined;
    	$scope.fd.fromDate=undefined;
    	$scope.fd.toDate=undefined;
    	$scope.fd.currentPageNumber=1;
    	$(".toDateField").datepicker('setDate', 'today');
    }
    $scope.setEncriptionValue = function(){
		$scope.$evalAsync(function(){
			$scope.fdvo.encryptionKey = $scope.fdvo.encryptionKey;
		});
    }   
    
}]);
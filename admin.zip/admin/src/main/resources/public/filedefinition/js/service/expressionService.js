zhapp.factory('expressionService',['$http','$q',function fileDefinitionService($http,$q){
	return {
		getAllExpressions : function(criteria){
			return $http({
				method : 'POST',
				url : '/expression/getAllExpressions',
				data : criteria
			});
		},
		
		saveExpressions : function(obj){
			return $http({
				method : 'POST',
				url : '/expression/saveExpression',
				data : obj
			});
		},
		
		validateExpression : function(request){
			return $http({
				method : 'POST',
				url : '/expression/validateExpression',
				headers: { 'Content-Type': undefined },
				data : request
			});
		},
		
		deleteExpression : function(expressionId){
			return $http({
				method : 'DELETE',
				url : '/expression/deleteExpression/'+expressionId,
				
			})
		}
		
	}
}]);
zhapp.factory('fileDefinitionService',['$http','$q',function fileDefinitionService($http,$q){
	return {
		getHostList : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllFileSources'
			});
		},
		
		getDeptAudienceList : function(departmentId){
			return $http({
				method : 'GET',
				url : '/getDeptSpecificAudiences/'+departmentId
			});
		},
		
		getAudienceList : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllAudiences'
			});
		},
		
		getFoldersFromRemoteServer : function(fileSoruceName,isFiles,currentPath){
			var obj = {};
			obj.fileSourceName = fileSoruceName;
			obj.isFiles = isFiles;
			obj.filePath = currentPath;
			return $http({
				method : 'POST',
				url : '/file/testFileSourceAndLoadFiles',
				data : obj
			});
		},
		getFoldersFromRemoteServerWithDelimiter : function(fileSoruceName,isFiles,currentPath,headerrow,datarow,delimit,textqualifier){
			var obj = {};
			obj.fileSourceName = fileSoruceName;
			obj.isFiles = isFiles;
			obj.filePath = currentPath;
			obj.headerrow = headerrow;obj.datarow=datarow;obj.delimit=delimit;obj.textqualifier=textqualifier;
			return $http({
				method : 'POST',
				url : '/file/testFileSourceAndLoadFilesWithDelimiter',
				data : obj
			});
		},		
		getDbSourceList : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllDBSources'
			});
		},
		
		getDbTablesList : function(dbSourceName){
			return $http({
				method : 'GET',
				url : '/file/fetchTablesFromRemoteDB/'+dbSourceName
			});
		},
		
		getFileLayoutList : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllFileFormats'
			});
		},
		
		getEncryptionKeysList : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllEncryptionKeys'
			});
		},
		
		getSelectQuery : function(dbSourceName,tableName){
			return $http({
				method : 'GET',
				url : '/file/prepareSelectQueryOnTable/'+dbSourceName+'/'+tableName
			});
		},
		
		executeSelectQuery : function(dbSourceName,query){
			return $http({
				method : 'POST',
				url : '/file/executeSelectQueryOnTable',
				data : {
					"dbSourceName" : dbSourceName,
					"query" : query
				}
			});
		},
		
		uploadFileContent : function(hubListForData){
			  return $http({
	                method: 'POST',
	                url: '/file/fileUpload',
	                data:hubListForData,
	                headers: { 'Content-Type': undefined }
	            });
		},
	
		getAudienceColumns : function(audienceId){
			return $http({
				method : 'GET',
				url : '/file/getAudienceBaseColumns/'+audienceId
			});
		},
		
		getAddressType : function(){
			return $http({
				method : 'GET',
				url : '/file/getAllAddressTypes',
				data : {}
			});
		},
		
		getTableSchema : function(dbSourceName,tableName){
			return $http({
				method : 'GET',
				url : '/file/getTableMetaData/'+dbSourceName+'/'+tableName
			});
		},
		
		listFileDefinitions : function(searchCriteria){
			return $http({
				method : 'POST',
				url : '/file/getAllFileDefinitions',
				data : searchCriteria
			});
		},
		
		getAllFileDefinitionByID : function(id){
			return $http({
				method : 'GET',
				url : '/file/getFileDefinitionByID/'+id
			});
		},
		
		updatefiledefinitionactivitystatus : function(fileactivityid,status,filedefinitionId){
			return $http({
				method : 'GET',
				url : '/file/updatefiledefinitionactivitystatus/'+fileactivityid+'/'+status+'/'+filedefinitionId
			});
		},
		
		updateFileActivitystatus : function(fileactivityid,status,filedefinitionId){
			return $http({
				method : 'GET',
				url : '/file/updateFileActivitystatus/'+fileactivityid+'/'+status
			});
		},
		
		getfileActivityBySearchCriteria: function(searchCriteria) {
           return $http({
				method : 'POST',
				url : '/file/getAllFileActivities',
				data : searchCriteria
			});
        },
        
        getfileActivityByCriteria: function(searchCriteria) {
            return $http({
 				method : 'POST',
 				url : '/file/getallfileactivitiesbycriteria',
 				data : searchCriteria
 			});
         },
        
        getBatchActivityBySearchCriteria: function(searchCriteria) {
            return $http({
                method: 'GET',
                url: '/file/getAllFileBatchActivities'
            });
        },
  
        saveFileDefinition : function(fdvo){
        	return $http({
        		method : 'POST',
        		url : '/file/saveFileDefinition',
        		data :fdvo,
        		headers: { 'Content-Type': undefined }
        	});
        },
        
        openActivityDialog : function(filedefID){
        	return $http({
				method : 'GET',
				url : '/file/getfileactivities/'+filedefID
			});
        },
        
        getStagingTables : function(){
        	return $http({
        		method : 'GET',
        		url : '/file/getAllStagingTables'
        	});
        },
        
        getDepartmentNotifications : function(){
        	return $http({
        		method : 'GET',
        		url : '/file/getDepartmentNotifications/1'
        	});
        },
        
        getAllFileDefintionList : function(searchCriteria){
        	return $http({
        		method : 'POST',
        		url : '/file/getAllFileDefinitionsNames',
        		data : searchCriteria
        	});
        },
        
        getAllFileDepartments : function(){
        	return $http({
        		method : 'POST',
        		url : '/file/getAllDepartments',
        		data : {}
        	});
        },
        getTriggeredWorkFlows : function(deptid){
        	return $http({
        		method : 'GET',
        		url : '/datatransforms/getMasterWorkflows/'+deptid
        	});
        },
        
        getEncryptedKeysList : function(){
        	return $http({
        		method : 'GET',
        		url : '/file/getAllEncryptionKeys'
        	});
        },
        
        getAllTablesAndFiles : function(sourceType,audienceID){
			return $http({
				method : 'GET',
				url : '/file/getAllTablesAndFiles/'+sourceType+'/'+audienceID
			});
		},
		getDepartmentSpecificProperty : function(searchCriteria){
			return $http({
				method : 'POST',
				url : '/getDepartmentSpecificProperty',
				data : searchCriteria
			});
		},
		getTimeZones: function() {
            return $http({
                method: 'GET',
                url: '/datatransforms/getTimeZones'
            });
        },
        createzipfile : function(activity){
			return $http({
				method : 'POST',
				url : '/file/createzipfile',
				data : activity
			});
		},
		downloadFileActivityLogFiles : function(request){
			return $http({
				method : 'POST',
				url : '/file/downloadfileactivitylog',
				headers: { 'Content-Type': undefined },
				responseType:'arraybuffer',
				data : request
			});
		},
		getAllFileActivityByFileDefId : function(filedefID){
        	return $http({
				method : 'GET',
				url : '/file/getAllFileActivityByFileDefId/'+filedefID
			});
        },
        
        getDataTypes : function(){
        	return $http({
				method : 'GET',
				url : '/file/getAllColumnTypes/'
			});
        },
        
        listFilesources: function() {
            return $http({
                method: 'GET',
                url: 'listFileSources'
            });
        },
        fileactivityByFiledefinitionid: function(id) {
            return $http({
                method: 'GET',
                url: '/file/fileactivitybyfiledefinitionid/'+id
            });
        },
        getVerticaDbTableColumns: function(tableName) {
            return $http({
                method: 'GET',
                url: '/file/getverticadbtablecolumns/'+tableName
            });
        }
	}
}]);
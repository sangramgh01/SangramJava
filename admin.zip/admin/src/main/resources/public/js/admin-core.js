function loadAccordionEvents(){
	$('.accordion > .contentcontainer').hide();
	$(".accordion >  a").on("click",function() {
		$(this).parent().next().toggle();
		$(this).parent().toggleClass('minusicon');
		return false;
	});
	$(".accordion > div > a").on( "click", function() {
		$(this).parent().next().toggle();
		$(this).parent().toggleClass('minusicon');
		return false;
	});
}
function loadScrollEvents(){
	$('.scroll').slimScroll({
		color: '#a9a9a9',
		height: '300px',
		size: '6px',
		wheelStep:1,
		railVisible: true,
		alwaysVisible: true
	});	
}
function setDeptRgtHeaderWidth() {
	if (screen.width >= 1900)
		$(".l-rightpanel").css("width", "1535px");
	if (navigator.appName === 'Microsoft Internet Explorer')
		$("#headerDepartments").width($("#listOfDepartments").width() - 9);
	else
		$("#headerDepartments").width($("#listOfDepartments").width());
};

function setAudienceRgtHeaderWidth() {
	if (screen.width >= 1900)
		$(".l-rightpanel").css("width", "1535px");
	if (navigator.appName === 'Microsoft Internet Explorer')
		$("#admin_audiences_div_headerAudiences").width($("#admin_audience_lst_basetable_tables_chzn").width() - 9);
	else
		$("#admin_audiences_div_headerAudiences").width($("#admin_audience_lst_basetable_tables_chzn").width());
};

function showErrorMessage(message) {
	$("#errormessage")[0].innerHTML = message;
	$("#error-dialog").dialog('option', 'title', 'Warning');
	$("#error-dialog").dialog('open');
}

function showInfoMessage(message) {
	$("#errormessage")[0].innerHTML = message;
	$("#error-dialog").dialog('option','position', 'center');
	$("#error-dialog").dialog('option', 'title', 'Info');
	$("#error-dialog").dialog('open');
}

// Call the below method to show confirmation
function showCommonConfirmMessage(message, title, trueBtnValue, falseBtnValue,
		width, callBack, paramsObject) {
	$("#confirm-message")[0].innerHTML = message;

	if (!trueBtnValue) {
		$("#common-confirmBtn").hide();
	} else {
		$("#common-confirmBtn").show();
		$("#common-confirmBtn")[0].innerHTML = trueBtnValue;
	}
	if (!falseBtnValue) {
		$("#common-confirmCloseBtn").hide();
		// $("#common-confirmCloseBtn").attr('style', 'display:none');
	} else {
		$("#common-confirmCloseBtn").show();
		$("#common-confirmCloseBtn")[0].innerHTML = falseBtnValue;
	}

	// $("#common-confirm-dialog").dialog('option', 'title', title);
	$("#common-confirm-dialog").dialog({
		width : width,
		title : title
	});
	$("#common-confirm-dialog").dialog('open');

	var confirmBtnData = $._data($('#common-confirmBtn')[0], 'events');
	if (confirmBtnData == undefined
			|| (confirmBtnData != undefined && confirmBtnData['click'] == undefined)) {
		$("#common-confirmBtn").click(function() {
			$("#common-confirm-dialog").dialog("close");
			try {
				if (paramsObject)
					callBack(true, paramsObject);
				else
					callBack(true);
			} catch (err) {

			}
			$("#common-confirmBtn").unbind("click");
			$("#common-confirmCloseBtn").unbind("click");
			callBack = undefined;
		});
	}

	var confirmCloseBtnData = $
			._data($('#common-confirmCloseBtn')[0], 'events');
	if (confirmCloseBtnData == undefined
			|| (confirmCloseBtnData != undefined && confirmCloseBtnData['click'] == undefined)) {
		$("#common-confirmCloseBtn").click(function() {
			$("#common-confirm-dialog").dialog("close");
			try {
				if (paramsObject)
					callBack(false, paramsObject);
				else
					callBack(false);
			} catch (err) {

			}
			$("#common-confirmCloseBtn").unbind("click");
			$("#common-confirmBtn").unbind("click");
			// callBack=undefined;
		});
	}

}

function loadCommonDialogs() {
	$("#common-confirm-dialog").dialog({
		width : 450,
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		closeOnEscape : false
	});
	$("#common-confirm-dialog").dialog("moveToTop").parent('.ui-dialog')
			.addClass("popup-on-loaing");

	$("#error-dialog").dialog({
		width : 450,
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		closeOnEscape : false
	});
	$("#errorCloseBtn").click(function() {
		$("#error-dialog").dialog("close");
	});
	$(".delete-dialog").dialog({
		width : 450,
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		closeOnEscape : false
	});
	$(".edit-audience").dialog(
	        {
	        	width:450,
				autoOpen: false,
				draggable: false, 
				resizable: false, 
				modal: true, 
				autoReposition: true,
				closeOnEscape: false			
	        });
}

function initializeEditDepartmentDialog(){
	 $(".editDepartmentDialog").dialog({
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		width : 430
	});
}
function initialzeConfigDialogs(module){
	if(module==="DOMAIN"){
		$("#adminDomainsAdd").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}
	else if(module==="ADMIN_USERMANAGEMENT"){
		$("#adminUserAdd").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false, width:404});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}
	else if(module==="FILESOURCE"){
		$("#admin_div_addfilesource").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false, width:600});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}
	else if(module==="DBSOURCE"){
		$("#admin_div_adddbsource").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false, width:600});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}
	else if(module==="ADDRESSTYPE"){
		$("#admin_configurations_div_addaddresstype").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}else if(module==="FILEENCRYPTION"){
		$("#admin_div_addfileencryption").hide();
		$( ".dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false, width:600});
		$(window).resize(function(){ $(".dialog-popup7,.dialog-popup17").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( ".dialog-popup7,.dialog-popup17" ).dialog( "close" );	return false;}); 
	}else if(module==="THROTTLING"){
		$( "#admin_configurations_div_addthrottling").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false,width:1200});
		$(window).resize(function(){ $("#admin_configurations_div_addthrottling").dialog("option","position","center"); });
		$( ".close-popup" ).click(function() {$( "#admin_configurations_div_addthrottling" ).dialog( "destroy" );	return false;}); 
	}
	else if(module==="UNSUBS"){
		$("#adminunsubcustom").hide();
		$( ".close-popup" ).click(function() {
			$("#adminunsubcustom").hide();hideDisableBack(); 
			$(".regkey-pop").dialog('close');
		});
		  
	      $( ".regkey-pop,.dialog-popup7,.dialog-popup17").dialog({ autoOpen: false,modal:true, draggable: false, resizable: false, autoReposition: true,closeOnEscape: false});
	      $( ".regkey-pop").dialog({ width: 500 });
	      $(".regkey-pop").hide();
	  }
}

function hideDisableBack(){
	$('.l-rightpanel').css({'margin-top': '0px'});
	$('.disableBack').hide();	
	$('.rgt-headerfix').css({position: 'fixed'});
	$('.rgt-headerfix').css("height", "auto");
	$('.rgt-headerfix').css('padding-top',"12px");
	if($('body').scrollLeft() !== 0 || $('html').scrollLeft()  > 0 ){
		$('.rgt-headerfix').css('margin-left',mrgleft);
	}
}
function showDisableBack(){
	$('.disableBack').show();
	$('.l-rightpanel').css({'margin-top': '-90px'});
	$('.rgt-headerfix').css({position: 'inherit'});
	$('.rgt-headerfix').css('padding-top',"0px");
	$('.rgt-headerfix').css("height", "0px");
	if($('body').scrollLeft() !== 0 || $('html').scrollLeft()  > 0 ){
		$('.rgt-headerfix').css('margin-left','0px');
	}	
}

function initializeRestrictedPatternsDialog(){
	 $(".dialog-popup16").dialog({
			autoOpen : false,
			draggable : false,
			resizable : false,
			modal : true,
			autoReposition : true,
			width : 500
	 });
}

function initializeBackDialog(){
	 $(".back-dialog").dialog({
			autoOpen : false,
			draggable : false,
			resizable : false,
			modal : true,
			autoReposition : true,
			width : 450
	 });
} 

function getPaginationPageSizes(totalRows){
	var pageSizes;
	if(totalRows.length>10){
		pageSizes = [10,20];
	}else if(totalRows.length>20){
		pageSizes = [10,20,totalRows.length];
	}else{
		pageSizes = [10]
	}
	return pageSizes;
}
function showDepartmentErrorMessage(responseObj){
	if(responseObj.errors!=null && responseObj.errors.length > 0)
		showErrorMessage(responseObj.errors[0].message);
	else
		showErrorMessage(responseObj.message);
}
function initializeAdobeAnalyticsDialogs(){
	$("#adv-opt-popup").dialog({
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		width : 1108
	});
}
function initializeTrashDialogDepartment(){
	$(".adminTrashDialog").dialog({
		autoOpen : false,
		draggable : false,
		resizable : false,
		modal : true,
		autoReposition : true,
		width : 1108
	});
	loadScrollEvents();
}
function showConfigurationErrorMessage(responseObj){
	if(responseObj.errors!=null && responseObj.errors.length > 0)
		showErrorMessage(responseObj.errors[0].message);
	else
		showErrorMessage(responseObj.message);
}

function removeDepartmentDialogsFromDom(){
	$(".adminTrashDialog").dialog("destroy" );
	$("#adv-opt-popup").dialog("destroy" );
	$(".dialog-popup16").dialog("destroy" );
	$(".editDepartmentDialog").dialog("destroy" );
	 $(".back-dialog").dialog("destroy");
}

function removeConfigurationDialogsFromDom(){
	if ($('.dialog-popup17').hasClass('ui-dialog-content'))
		$(".ui-dialog-content").filter(".dialog-popup17").dialog("destroy");
	if ($('.dialog-popup7').hasClass('ui-dialog-content'))
		$(".ui-dialog-content").filter(".dialog-popup7").dialog("destroy");
}
function isNullOrUndefined(obj){
	if(obj === null || obj === undefined)
		return true;
	return false;
}
function isNotNullOrUndefined(obj){
	if(obj !== null && obj !== undefined)
		return true;
	return false;
}

function validateEmail(emailStr) {
    var atcount = 0;
    for (var i = 0; i < emailStr.length; i++) {
        if (emailStr.charAt(i) === "@") 
        	atcount++;
    }
    if (atcount > 1) 
    	return false;
    if (emailStr.indexOf(".") === -1) 
    	return false;
    if (emailStr.indexOf("..") !== -1)
        return false;
    var dotpos = 0;
    var ichar;
    for (i = dotpos; i < emailStr.length; i++) {
        ichar = emailStr.charAt(i);
        if (ichar === ".") 
        	dotpos = i;
    }
    for (i = dotpos + 1; i < emailStr.length; i++) {
        ichar = emailStr.charAt(i);
        if ((!isNaN(Number(ichar))) || (ichar === "_")) {
            return false;
        }
    }
    var pattern = /^[0-9a-zA-Z\-\_.\"!#$%&'*+-\/=?^_`{|}~]+@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
    return emailStr.match(pattern);
};

function validateDomainName(domainName){
	if(typeof domainName !== 'string') 
	    return false;
	if (domainName.length > 253)
		return false;
	var parts = domainName.split('.');
	if (parts.length <= 1) 
		return false;
	var tld = parts.pop();
	var tldRegex = /^[a-zA-Z0-9]+$/gi;
	if (!tldRegex.test(tld)) 
		return false;
	var isValid = parts.every(function (host) {
		var hostRegex = /^(?!:\/\/)([a-zA-Z0-9]+|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])$/gi;
		return hostRegex.test(host);
	});
	return isValid;
}

zhapp.controller("adminController",['$scope','$rootScope','adminListingService',function($scope,$rootScope,adminListingService) {
	$scope.adminModule={};
	$scope.adminModule.adminworkarea='deptarea' ;
	$scope.adminModule.leftTemplate = "/adminleftnav.html";
	$scope.adminModule.templateSrc="/department/templates/listDepartments.html";
	$scope.commondialogs ="/commons/commondialogs.html"; 
	$scope.adminModule.openFileDefAcc = false;
	$scope.adminModule.openAudienceAcc = false;
	$scope.adminModule.openConfigSubMenu = false;
	$scope.adminModule.openUserManagementSubMenu = false; // User Management
	$scope.adminModule.openWorkflowSubMenu = false;
	$scope.adminModule.openExpressionSubMenu = false;
	$rootScope.activeMenuItem = 'Settings';

	$scope.adminModule.loadPartialScripts=function(adminworkarea){
		$rootScope.activeMenuItem = 'Settings';
		$rootScope.activeMenuSubItem = "";
		$("#admin_leftpane_lnk_orderby").show();
		$("#admin_leftpane_lnk_sortby").show();
		$scope.adminModule.templateSrc=undefined;
		$scope.adminModule.adminworkarea=adminworkarea;
		if(adminworkarea === 'fdarea'){
			if($scope.adminModule.templateSrc === 'filedefinition/templates/filedefinitionhome.html'){
				$scope.$broadcast('loadFileDefinition');
			}else{
				$scope.adminModule.templateSrc = 'filedefinition/templates/filedefinitionhome.html';
				$scope.$broadcast('loadFileDefinition');
			}
			if(!$scope.adminModule.openFilesSubMenu) 
				$scope.adminModule.openFilesSubMenu = true;
			else 
				$scope.adminModule.openFilesSubMenu = false;
			$('.fdactivityContainer').toggle();
		}else if(adminworkarea === 'fdactivity'){
			$scope.adminModule.templateSrc="filedefinition/templates/filebatchactivityhome.html";
			//$scope.$broadcast ('fdactivity');
			setTimeout(function(){$scope.$broadcast ('fdactivity');},400);
		}else if(adminworkarea === 'deptarea'){
			$scope.adminModule.templateSrc="department/templates/listDepartments.html";
		}else if(adminworkarea === 'audienceArea'){
			$scope.adminModule.adminworkarea = 'systemAudience';
			adminListingService.loadAudiance="System";
			$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
			$scope.$broadcast ('systemAudience');
			if(!$scope.adminModule.openAudienceAcc) 
				$scope.adminModule.openAudienceAcc = true;
			else
				$scope.adminModule.openAudienceAcc = false;
			$('.adminAudience').toggle();
		}else if(adminworkarea === 'systemAudience'){
			adminListingService.loadAudiance="System";
			//$scope.$evalAsync(function(){
				$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
			//	setTimeout(function(){$scope.$broadcast ('systemAudience');},0);
				$scope.$broadcast ('systemAudience');
			//});
		}else if(adminworkarea === 'customAudience'){
			adminListingService.loadAudiance="Custom";
			//$scope.$evalAsync(function(){
				$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
			//	setTimeout(function(){$scope.$broadcast ('customAudience');},5);
				$scope.$broadcast ('customAudience');
			// });
		}else if(adminworkarea === 'transformeditor'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/transformeditor.html';
			$scope.$emit('transformeditor');
			$scope.$broadcast ('transformeditor');
			$scope.adminworkarea='transformeditor';
		}
		else if(adminworkarea === 'workfloweditor'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/workfloweditor.html';
			$scope.adminworkarea='workfloweditorarea';
			$scope.adminModule.adminworkarea='workfloweditor';
			$scope.$broadcast ('workfloweditor');
			if(!$scope.adminModule.openWorkflowSubMenu) 
				$scope.adminModule.openWorkflowSubMenu = true;
			else 
				$scope.adminModule.openWorkflowSubMenu = false;
			$('.workflowContainer').toggle();
		}
		else if(adminworkarea === 'workfloweditorarea'){
	    	 $scope.adminworkarea='workfloweditorarea';
			 $scope.adminModule.adminworkarea='workfloweditor';
			 $scope.$broadcast ('workfloweditor');
	    }else if(adminworkarea === 'workflowactivity'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/workflowactivity.html';
			$scope.$broadcast('workflowactivity');
		}
		else if(adminworkarea === 'listarea'){
			if($scope.adminModule.templateSrc === "list/templates/listhome.html"){
				$scope.$broadcast('loadListOnClick');
			}else{
				$scope.adminModule.templateSrc="list/templates/listhome.html";
				$scope.$broadcast('loadListOnClick');
			}
		}else if(adminworkarea === 'userManagementArea'){
			  $rootScope.activeMenuItem = 'Users';
				$scope.adminModule.templateSrc="userManagement/templates/listusers.html";
				$scope.adminModule.adminworkarea="userManagementArea";
				$rootScope.$broadcast('reLoadUsersList');
		}else if(adminworkarea === 'configarea'){
			if(!$scope.adminModule.openConfigSubMenu) 
				$scope.adminModule.openConfigSubMenu = true;
			else 
				$scope.adminModule.openConfigSubMenu = false;
			$('.configContainer').toggle();
			$scope.adminModule.templateSrc="configuration/templates/domains.html";
			$scope.adminModule.adminworkarea="domainsarea";
		}
		if(adminworkarea === 'domainsarea'){
			$scope.adminModule.templateSrc="configuration/templates/domains.html";
		}else if(adminworkarea === 'filesourcearea'){
			$scope.adminModule.templateSrc="configuration/templates/filesources.html";
			$("#admin_leftpane_lnk_orderby").hide();
			$("#admin_leftpane_lnk_sortby").hide();
		}else if(adminworkarea === 'fileencryptionarea'){
			$scope.adminModule.templateSrc="configuration/templates/fileencryptions.html";
		}else if(adminworkarea === 'databasesourcearea'){
			$scope.adminModule.templateSrc="configuration/templates/databasesources.html";
		}else if(adminworkarea === 'addresstypesarea'){
			$scope.adminModule.templateSrc="configuration/templates/addresstypes.html";
		}else if(adminworkarea === 'throttlingarea'){
			$scope.adminModule.templateSrc="configuration/templates/throttling.html";
		}else if(adminworkarea === 'unsubarea'){
			if(!$scope.adminModule.openUnsubSubMenu)
				$scope.adminModule.openUnsubSubMenu = true;
			else 
				$scope.adminModule.openUnsubSubMenu = false;
			$('.unsubContainer').toggle();
			$scope.adminModule.templateSrc="configuration/templates/systemUnsubKeywords.html";
			$scope.adminModule.adminworkarea="systemunsubarea";
		}else if(adminworkarea === 'systemunsubarea'){
			$scope.adminModule.templateSrc="configuration/templates/systemUnsubKeywords.html";
		}else if(adminworkarea === 'customunsubarea'){
			$scope.adminModule.templateSrc="configuration/templates/customUnsubKeywords.html";
		}else if(adminworkarea === 'editdepartmentarea'){
			$scope.adminModule.templateSrc="department/templates/editDepartmentLayout.html";
		}else if(adminworkarea === 'editaudiencearea'){
			$scope.adminModule.templateSrc="audience/templates/addOrEditAudience.html";
		}else if(adminworkarea === 'derivedfields'){
			if(!$scope.adminModule.openExpressionSubMenu) 
				$scope.adminModule.openExpressionSubMenu = true;
			else 
				$scope.adminModule.openExpressionSubMenu = false;
			$('.expressionContainer').toggle();
			$scope.adminModule.templateSrc="filedefinition/templates/systemexpressions.html";
			$scope.adminModule.adminworkarea="derivedfieldsystem";
			setTimeout(function(){$scope.$broadcast ('derivedfieldsystem');},400);
		}if(adminworkarea === 'derivedfieldsystem'){
			$scope.adminModule.templateSrc="filedefinition/templates/systemexpressions.html";
			setTimeout(function(){$scope.$broadcast ('derivedfieldsystem');},5);
		}else if(adminworkarea === 'derivedfieldcustom'){
			$scope.adminModule.templateSrc="filedefinition/templates/customexpressions.html";
			setTimeout(function(){$scope.$broadcast ('derivedfieldcustom');},5);
		}
		//User Management Sub Menu Calling Here
		if(adminworkarea === 'userManagementUserArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/userManagement.html";
		}else if(adminworkarea === 'userManagementGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/groupManagement.html";
		}else if(adminworkarea === 'userManagementRuleArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleManagement.html";
		}else if(adminworkarea === 'userManagementRuleUserArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleUserManagement.html";
		}else if(adminworkarea === 'userManagementRuleGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleGroupManagement.html";
		}else if(adminworkarea === 'userManagementUserGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/userGroupManagement.html";
		}
		//Closing User Management Sub Menu 
		$(".dialog-popup4" ).dialog('destroy'); //check User Management 
	};
	
	/*$scope.loadingPartialScriptsCompleted=function(adminworkarea){
		$("#admin_leftpane_lnk_orderby").show();
		$("#admin_leftpane_lnk_sortby").show();
		$scope.adminModule.templateSrc=undefined;
		$scope.adminModule.adminworkarea=adminworkarea;
		if(adminworkarea === 'fdarea'){
			if($scope.adminModule.templateSrc === 'filedefinition/templates/filedefinitionhome.html'){
				$scope.$broadcast('loadFileDefinition');
			}else{
				$scope.adminModule.templateSrc = 'filedefinition/templates/filedefinitionhome.html';
				$scope.$broadcast('loadFileDefinition');
			}
		}else if(adminworkarea === 'deptarea'){
			$scope.adminModule.templateSrc="department/templates/listDepartments.html";
		}else if(adminworkarea === 'audienceArea'){
			$scope.adminModule.adminworkarea = 'systemAudience';
			$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
			setTimeout(function(){$scope.$broadcast ('systemAudience');},1000);
			if(!$scope.adminModule.openAudienceAcc) 
					$scope.adminModule.openAudienceAcc = true;
			else
					$scope.adminModule.openAudienceAcc = false;
			$('.adminAudience').toggle();
		}else if(adminworkarea === 'systemAudience'){
			$scope.$evalAsync(function(){
				$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
				setTimeout(function(){$scope.$broadcast ('systemAudience');},5);
			});
		}else if(adminworkarea === 'customAudience'){
			$scope.$evalAsync(function(){
				$scope.adminModule.templateSrc="audience/templates/audiencehomerightpane.html";
				setTimeout(function(){$scope.$broadcast ('customAudience');},5);
			 });
		}else if(adminworkarea === 'transformeditor'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/transformeditor.html';
			$scope.$emit('transformeditor');
			$scope.$broadcast ('transformeditor');
			$scope.adminworkarea='transformeditor';
		}
		else if(adminworkarea === 'workfloweditor'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/workfloweditor.html';
			$scope.adminworkarea='workfloweditorarea';
			$scope.adminModule.adminworkarea='workfloweditor';
			$scope.$broadcast ('workfloweditor');
			if(!$scope.adminModule.openWorkflowSubMenu) 
				$scope.adminModule.openWorkflowSubMenu = true;
			else 
				$scope.adminModule.openWorkflowSubMenu = false;
			$('.workflowContainer').toggle();
		}
		else if(adminworkarea === 'workfloweditorarea'){
	    	 $scope.adminworkarea='workfloweditorarea';
			 $scope.adminModule.adminworkarea='workfloweditor';
			 $scope.$broadcast ('workfloweditor');
	    }else if(adminworkarea === 'workflowactivity'){
			$scope.adminModule.templateSrc = 'datatransforms/templates/workflowactivity.html';
		}
		else if(adminworkarea === 'listarea'){
			if($scope.adminModule.templateSrc === "list/templates/listhome.html"){
				$scope.$broadcast('loadListOnClick');
			}else{
				$scope.adminModule.templateSrc="list/templates/listhome.html";
				$scope.$broadcast('loadListOnClick');
			}
		}else if(adminworkarea === 'userManagementArea'){
			if(!$scope.adminModule.openUserManagementSubMenu) $scope.adminModule.openUserManagementSubMenu = true;
			else $scope.adminModule.openUserManagementSubMenu = false;
			$('.userManagementContainer').toggle();
			$scope.adminModule.templateSrc="userManagement/htmlFiles/userManagement.html";
			$scope.adminModule.adminworkarea="userManagementUserArea";
		}else if(adminworkarea === 'configarea'){
			if(!$scope.adminModule.openConfigSubMenu) 
				$scope.adminModule.openConfigSubMenu = true;
			else 
				$scope.adminModule.openConfigSubMenu = false;
			$('.configContainer').toggle();
			$scope.adminModule.templateSrc="configuration/templates/domains.html";
			$scope.adminModule.adminworkarea="domainsarea";
		}
		if(adminworkarea === 'domainsarea'){
			$scope.adminModule.templateSrc="configuration/templates/domains.html";
		}else if(adminworkarea === 'filesourcearea'){
			$scope.adminModule.templateSrc="configuration/templates/filesources.html";
			$("#admin_leftpane_lnk_orderby").hide();
			$("#admin_leftpane_lnk_sortby").hide();
		}else if(adminworkarea === 'fileencryptionarea'){
			$scope.adminModule.templateSrc="configuration/templates/fileencryptions.html";
		}else if(adminworkarea === 'databasesourcearea'){
			$scope.adminModule.templateSrc="configuration/templates/databasesources.html";
		}else if(adminworkarea === 'addresstypesarea'){
			$scope.adminModule.templateSrc="configuration/templates/addresstypes.html";
		}else if(adminworkarea === 'throttlingarea'){
			$scope.adminModule.templateSrc="configuration/templates/throttling.html";
		}else if(adminworkarea === 'unsubarea'){
			if(!$scope.adminModule.openUnsubSubMenu)
				$scope.adminModule.openUnsubSubMenu = true;
			else 
				$scope.adminModule.openUnsubSubMenu = false;
			$('.unsubContainer').toggle();
			$scope.adminModule.templateSrc="configuration/templates/systemUnsubKeywords.html";
			$scope.adminModule.adminworkarea="systemunsubarea";
		}else if(adminworkarea === 'systemunsubarea'){
			$scope.adminModule.templateSrc="configuration/templates/systemUnsubKeywords.html";
		}else if(adminworkarea === 'customunsubarea'){
			$scope.adminModule.templateSrc="configuration/templates/customUnsubKeywords.html";
		}else if(adminworkarea === 'editdepartmentarea'){
			$scope.adminModule.templateSrc="department/templates/editDepartmentLayout.html";
		}else if(adminworkarea === 'editaudiencearea'){
			$scope.adminModule.templateSrc="audience/templates/addOrEditAudience.html";
		}else if(adminworkarea === 'derivedfields'){
			if(!$scope.adminModule.openExpressionSubMenu) 
				$scope.adminModule.openExpressionSubMenu = true;
			else 
				$scope.adminModule.openExpressionSubMenu = false;
			$('.expressionContainer').toggle();
			$scope.adminModule.templateSrc="filedefinition/templates/systemexpressions.html";
			$scope.adminModule.adminworkarea="derivedfieldsystem";
		}if(adminworkarea === 'derivedfieldsystem'){
			$scope.adminModule.templateSrc="filedefinition/templates/systemexpressions.html";
		}else if(adminworkarea === 'derivedfieldcustom'){
			$scope.adminModule.templateSrc="filedefinition/templates/customexpressions.html";
		}
		//User Management Sub Menu Calling Here
		if(adminworkarea === 'userManagementUserArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/userManagement.html";
		}else if(adminworkarea === 'userManagementGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/groupManagement.html";
		}else if(adminworkarea === 'userManagementRuleArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleManagement.html";
		}else if(adminworkarea === 'userManagementRuleUserArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleUserManagement.html";
		}else if(adminworkarea === 'userManagementRuleGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/ruleGroupManagement.html";
		}else if(adminworkarea === 'userManagementUserGroupArea'){
			$scope.adminModule.templateSrc="userManagement/htmlFiles/userGroupManagement.html";
		}
		//Closing User Management Sub Menu 
		$(".dialog-popup4" ).dialog('destroy'); //check User Management 
	};
	
	$rootScope.$on("loadingPartialScriptsCompleted",function(event,adminworkarea){
		$scope.loadingPartialScriptsCompleted(adminworkarea);
	});*/
	
	$scope.adminModule.defaultSortCriteria=function(){
		$scope.adminModule.sortorder = 'descending';
		$scope.adminModule.sortby = 'createdon' ;
	};
	
	$scope.adminModule.resetSortByAndOrder=function(){
		$scope.adminModule.sortorder='ascending';
		$scope.adminModule.sortby='name';
		
	};
	$scope.adminModule.sort=function(){
		adminListingService.listingCriteriaChanged($scope.adminModule.sortorder,$scope.adminModule.sortby);
	};
	
	if(sessionStorage.getItem('queryParams')){
		confirmMessageDialog();
    	var queryParams = JSON.parse(sessionStorage.getItem('queryParams'));
    	if(queryParams.modulename && queryParams.modulename == "file"){
    		$scope.adminModule.defaultSortCriteria();
    		$scope.adminModule.loadPartialScripts('fdarea');
    	}else if(queryParams.modulename && queryParams.modulename == "workflow"){
    		$scope.adminModule.defaultSortCriteria();
    		$scope.adminModule.loadPartialScripts('workfloweditor');
    	}
    }else{
    	$scope.adminModule.resetSortByAndOrder();
    	$scope.adminModule.sort();
    }
	
	//JQuery events call
	$scope.adminModule.loadJQueryEvents=function(){
		loadAccordionEvents();
		loadScrollEvents();
		var wh = $(window).height()-90;
		$(".adminscroll").css({'height': wh});
		$('.adminscroll').slimScroll({
 			color: '#a9a9a9',
 			height: '300px',
 			size: '6px',
 			wheelStep:1,
 			railVisible: true,
 			alwaysVisible: true
 		});	
	};
	$scope.adminModule.loadCommonDialogs=function(){
		loadCommonDialogs();
	};
	$scope.adminhelpURL = function(){
		 window.open(zhapp.help_host+'/help/default.htm?admin.htm', '_blank');
	}
}]);
zhapp.factory('adminListingService',function($rootScope){
    var messenger = {
    	sortorder : 'ascending',
    	sortby : 'name',
        listingCriteriaChanged:function(sortorder, sortby) {
        	this.sortorder=sortorder;
        	this.sortby=sortby;
            $rootScope.$broadcast('listingCriteriaChanged');
        }
    };
    return messenger;
});

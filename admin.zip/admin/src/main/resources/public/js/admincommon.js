/**
 * 
 */
zhapp.directive('numaric', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^0-9]/g, '');

                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});

zhapp.directive('vmtaAllowedCharacters', function () {
	  return {
		    require: 'ngModel',
		    link: function (scope, element, attr, ngModelCtrl) {
		      function fromUser(text) {
		        var transformedInput = text.replace(/[^\w\s]/g, '');
		        if(transformedInput !== text) {
		            ngModelCtrl.$setViewValue(transformedInput);
		            ngModelCtrl.$render();
		        }
		        return transformedInput;  
		      }
		      ngModelCtrl.$parsers.push(fromUser);
		    }
	 }; 
});

zhapp.directive('integerRange', function() {
	  return {
	    require: 'ngModel',
	    link: function (scope, element, attr, ngModelCtrl) {
	      function fromUser(text) {
	    	text=text.toString();
	        var transformedInput = text.replace(/[^0-9]/g, '');
	        if(transformedInput !== text) {
	            ngModelCtrl.$setViewValue(transformedInput);
	            ngModelCtrl.$render();
	        }
	        if(transformedInput === text && transformedInput > 2147483647)
	    	{
	    		showErrorMessage("Entered Data is Invalid, Threshold value should be less than 2147483647.");	    
	    		transformedInput="2147483647";
	    	}
	        if(transformedInput !== text) {
	            ngModelCtrl.$setViewValue(transformedInput);
	            ngModelCtrl.$render();
	        }
	        return transformedInput;  
	      }
	      ngModelCtrl.$parsers.push(fromUser);
	    }
	  }; 
});

//space and underscore used
zhapp.directive('zetanumaricalphaanother', function() {
	  return {
	    require: 'ngModel',
	    link: function (scope, element, attr, ngModelCtrl) {
	      function fromUser(text) {
	        var transformedInput = text.replace(/[^a-zA-Z0-9 _]/g, '');	      
	        if(transformedInput !== text) {
	            ngModelCtrl.$setViewValue(transformedInput);
	            ngModelCtrl.$render();
	        }
	        return transformedInput;  
	      }
	      ngModelCtrl.$parsers.push(fromUser);
	    }
	  }; 
});

zhapp.directive('hubtagsaallowedcharacters', function () {
	  return {
		    require: 'ngModel',
		    link: function (scope, element, attr, ngModelCtrl) {
		      function fromUser(text) {
		        var transformedInput = text.replace(/[^\w\s~@^&*()=+{};"',<>?|\\\+]/g, '');
		        if(transformedInput !== text) {
		            ngModelCtrl.$setViewValue(transformedInput);
		            ngModelCtrl.$render();
		        }
		        return transformedInput;  
		      }
		      ngModelCtrl.$parsers.push(fromUser);
		    }
	 }; 
});


zhapp.filter('uniqueFilter',function(){
	// ArrayOf object, datawich you want to get,//Dept to replace with defaut in
	// case of folder & catcodes.
	return function(data,returnType,deptName){
		var selectedElements=[];
		for(var i=0;i<data.length;i++){
			if(data[i].hasOwnProperty(returnType)){
				if(data[i].checked){
					if((returnType=="catcode" || returnType=="foldername")){
						if((deptName)&&(data[i][returnType])&&(deptName.toLowerCase()==data[i][returnType].toLowerCase())){
								selectedElements.push("default");
						}
						else {
							var name=String(data[i][returnType]).replace(/\'/g, "\\'");
							selectedElements.push(name);
						}
					}else{	
						if((data[i][returnType]+"").indexOf("'")>-1)
						{
							var name=String(data[i][returnType]).replace(/\'/g, "\\'");
							selectedElements.push(name);
						}else
							selectedElements.push(data[i][returnType]);
					}
				}
			}else{
				if(data[i].checked){
					selectedElements.push(data[i]);
				}
			}
		}
		return selectedElements;
	};
});

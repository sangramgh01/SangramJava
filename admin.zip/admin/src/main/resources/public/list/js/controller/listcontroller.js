zhapp.controller("listcontroller",['$scope','$rootScope','listService','fileDefinitionService','$q', 'departmentService','Blob','FileSaver','$timeout','$filter',function($scope,$rootScope,listService,fileDefinitionService,$q,departmentService,Blob,FileSaver,$timeout,$filter) {
	$scope.editfilemapping = [];
	$scope.list = {};
	$scope.leftmenu = {};
	$scope.list.listleftpanel = 'list/templates/listhomeleft.html';
	$scope.list.notificationstemp = "filedefinition/templates/listfilenotifications.html";
	$scope.list.totalRecords = -1;		
	$scope.list.currentPageNumber=1;
	$scope.list.searchCriteria = {};		
	$scope.list.searchCriteria.pageno = 1;		
	$scope.list.searchCriteria.pagesize = 7;			
	$scope.list.searchCriteria.sortby="listid";		
	$scope.list.searchCriteria.sortorder="DESC";
	$scope.list.mtfValueId=-1;
	$scope.list.mtCValueId=-1;
	$scope.list.isFileUploaded = false;
	$rootScope.activeMenuItem = 'Lists';
	$scope.list.loadPageDetails = function(pageno){		
		$scope.list.searchCriteria.pageno = pageno;		
		$scope.list.currentPageNumber=pageno;		
		$scope.list.listLists($scope.list.searchCriteria);		
	}
	$scope.list.selectedMappingScreen='Data Mappings';
	$scope.admin  = true;
	if(zhapp.scriptProvider.componentName == "list"){
		$scope.admin  = false;
		$scope.list.type = 'A';
	}else if(zhapp.scriptProvider.componentName == "admin"){
		$scope.admin  = true;
	}
	
	
	$scope.list.listTypeList = [{key:'G',value:'General purpose'},
	                      {key:'S',value:'Seed'},
	                      {key:'T',value:'Test'}];
	
	$scope.list.listTypeForfd = [{key:'G',value:'General purpose'},
	  	                      {key:'S',value:'Seed'},
	  	                      {key:'T',value:'Test'},
	  	                      {key:'U',value:'Unsub'},
	  	                      {key:'R',value:'Resub'}];
	
	$scope.list.createFromList = [{key:'D',value:'Desktop'},{key:'R',value:'Remote server'},{key:'B',value:'Remote DB'}];
	$scope.list.fileDelimiterList = ['|',',','tab',';'];
	
	$scope.list.dataTypes=[{key:'5',value:'INT'},{key:'0',value:'STRING'},{key:'2',value:'FLOAT'},
	                     {key:'4',value:'BOOLEAN'},{key:'1',value:'BIGINT'},{key:'3',value:'DATETIME'},
	                     {key:'6',value:'BYTEINT'},{key:'7',value:'EMAIL'},{key:'8',value:'SMS'},
	                     {key:'9',value:'TIMESTAMP'},{key:'10',value:'DATE'},{key:'11',value:'TIME'},
	                     {key:'12',value:'DECIMAL'},{key:'13',value:'DOUBLE'} ];
	
	$scope.list.nullValue = [{'key': 'NL','value': 'Null'}, {'key': 'ES','value': 'Empty String'}];
	$scope.list.statusArray = [{'key':'W','value':'Waiting'},{'key':'B','value':'Preparing'},{'key':'E','value':'Errored'},{'key':'I','value':'In Progress'},{'key':'C','value':'Completed'},{'key':'U','value':'Waiting to retry'},{'key':'X','value':'Completed'},{'key':'K','value':'In Progress'},{'key':'P','value':'Preparing'}];
	
    $scope.list.booleanFormatList = [{'key': 'YESNO','value': 'Yes/No'},
                               {'key': 'YN','value': 'Y/N'},
                               {'key': 'TF','value': 'T/F'},
                               {'key': 'TRFL','value': 'True/False'},
                               {'key': 'OZ','value': 'One/Zero'}];
    
    $scope.list.dateFormatList = [ {'key':'YMD','value':'YYYY-MM-DD hh:mm:ss'},
	                          {'key':'YMDT','value':'YYYY-MM-DD T hh:mm:ss'},
	                          {'key':'DMY','value':'DD-MM-YYYY hh:mm:ss'},
	                          {'key':'MDY','value':'MM-DD-YYYY hh:mm:ss'},
	                          {'key':'MONDY','value':'MMM-DD-YYYY hh:mm:ss'},
	                          {'key':'DMONY','value':'DD-MMM-YYYY hh:mm:ss'}];
    
    $scope.list.dateDelimiterList = [{'key':' ','value':'Space'},
	                                {'key':'-','value':'-'},
	                                {'key':'/','value':'/'}];
    
    $scope.list.frequencies = [{'key': 'I','value': 'Immediately'},
                             {'key': 'O','value': 'Once Later'}];
    
    $scope.list.timeZoneData = zhapp.timeZoneData;
    $scope.notifications = {};
	$scope.notifications.isEnabled = false;
	$scope.notifications.notificationStatuses = [{"isEnabled":false,"name":"Errored"},{"isEnabled":false,"name":"Executing"},
                                                 {"isEnabled":false,"name":"Completed"}];
	$scope.allnotifications = [{"key":"Errored","name":"Errored"},{"key":"Executing","name":"In - Progress"},
                          {"key":"Completed","name":"Completed"}];
	
	
	
	$scope.getNotificationVal = function(key){
		return $.grep($scope.allnotifications,function(obj){return obj.key == key;})[0].name;
	}
	
	$scope.notificationDetails = function (){
		var deptNotiCriteria = {}
		deptNotiCriteria.departmentId = zhapp.loginUser.departmentID;
		deptNotiCriteria.propertyKey = "NOTIFICATIONS";
		fileDefinitionService.getDepartmentSpecificProperty(deptNotiCriteria).success(function(result){
			if(result && result.objectValue != null && result.objectValue.notifications != null){
				var listNotifications = $.grep(result.objectValue.notifications,function(obj){return obj.notificationTypeName == 'Lists'})[0];
				if(listNotifications.isEnabled || $scope.addnewListFlag){
					$scope.addnewListFlag=false;
					var actualListNotifications = [];
					angular.forEach(listNotifications.notificationStatuses,function(obj){
						var selected = $.grep($scope.allnotifications,function(obj1){return obj1.key == obj.name;})[0];
						if(selected){
						actualListNotifications.push(obj);
						}
					});
					listNotifications.notificationTypeName = undefined;
					listNotifications.notificationStatuses = actualListNotifications;
					$scope.notifications = listNotifications;
				}
			}
    	});
	}
	
	$scope.notificationdisable = function(val){
		if(val == 'D'){
				$scope.notifications.isEnabled = false;
				$scope.notifications.defaultEmailAddresses = undefined;
				angular.forEach($scope.notifications.notificationStatuses,function(obj){obj.isEnabled = false;obj.emailAddresses = undefined;});
		}else{
			if( $scope.savedListItem==true || $scope.fdobjnotifications){
				$scope.notifications=angular.copy($scope.fdobjnotifications);
				$scope.notifications.isEnabled = true;
				if ($scope.fdobjnotifications.isEnabled===false){
					$scope.addnewListFlag=false;
					$scope.notificationDetails();
				}
			}else{
				$scope.notifications.isEnabled = true;
				$scope.addnewListFlag=false;
				$scope.notificationDetails()
			}
		}
	}
    $scope.list.dateCreated=[{key:"Select All","value":undefined},{key:"Today", value:"today"},{key:"Yesterday", value:"yesterday"},{key:"This Week", value:"thisweek"},{key:"Last Week", value:"lastweek"},{key:"This Month", value:"thismonth"}];
	$scope.list.fileTextQualifierList = ['None','\'','\"'];
	$scope.list.frequency = 'O';
	$scope.list.useEncryption = 'N';
	$scope.list.remote = {};
	$scope.list.db = {};
	$scope.leftmenu.filterCriteria = {};
	$scope.leftmenu.filterCriteria.sortOrder='DESC';
	 $scope.leftmenu.fileType='Select All';
	 $scope.leftmenu.filterCriteria.sortBy='createdate';
	 $scope.leftmenu.categorySelected='Select All';
	 $scope.leftmenu.foldSelected='Select All';
	 
	
	$scope.leftmenu.orderingChange = function(order){
		$scope.list.searchCriteria.sortorder = order;
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	$scope.leftmenu.setSelectedFolderIds = function(folderID){
		zhapp.folderAndCategoryContainer.list.folderId = folderID;
			if(folderID=='ALL'){
				$scope.list.searchCriteria.folderid = undefined;
			}else{
				$scope.list.searchCriteria.folderid = folderID;
			}
			 if($scope.leftmenu.categorySelected == 'Select All'){
				 $scope.list.searchCriteria.categoryid=undefined;
			}if($scope.leftmenu.fileType=='Select All'){
				$scope.list.searchCriteria.listtype=undefined;
			}
			$scope.list.listLists($scope.list.searchCriteria);
	}
	
	$scope.leftmenu.setSelectedCatCodes = function(categoryID){
		zhapp.folderAndCategoryContainer.list.categoryId = categoryID;
			if(categoryID=='ALL'){
				$scope.list.searchCriteria.categoryid=undefined;
			}else{
				$scope.list.searchCriteria.categoryid = categoryID;
			}
			if ($scope.leftmenu.foldSelected == 'Select All'){
				 $scope.list.searchCriteria.folderid=undefined;
			}if($scope.leftmenu.fileType=='Select All'){
				$scope.list.searchCriteria.listtype=undefined;
			}
			$scope.list.listLists($scope.list.searchCriteria);
		
	}
	
	$scope.leftmenu.sortByChange = function(sortBy){
		if($scope.leftmenu.foldSelected == 'Select All'){
			$scope.list.searchCriteria.folderid=undefined;
		}if ($scope.leftmenu.categorySelected == 'Select All'){
			$scope.list.searchCriteria.categoryid=undefined;
		}if ($scope.leftmenu.fileType=='Select All'){
			$scope.list.searchCriteria.listtype=undefined;
		}
		$scope.list.searchCriteria.sortby=sortBy;		
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	$scope.leftmenu.setFileTypeChanged = function(listType){
		if($scope.leftmenu.foldSelected == 'Select All'){
			$scope.list.searchCriteria.folderid=undefined;
		}if ($scope.leftmenu.categorySelected == 'Select All'){
			$scope.list.searchCriteria.categoryid=undefined;
		} if (listType=='ALL'){
			$scope.list.searchCriteria.listtype=undefined;
		}else{
			$scope.list.searchCriteria.listtype=listType;
		}
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	$scope.prepareSearchCriteria = function(){
		if($scope.leftmenu.foldSelected == 'Select All'){
			$scope.list.searchCriteria.folderid=undefined;
		}if ($scope.leftmenu.categorySelected == 'Select All'){
			$scope.list.searchCriteria.categoryid=undefined;
		} if ($scope.leftmenu.fileType && $scope.leftmenu.fileType == 'Select All'){
			$scope.list.searchCriteria.listtype=undefined;
		}else{
			$scope.list.searchCriteria.listtype= $scope.leftmenu.fileType;
		}
		if($scope.leftmenu.statusSelectAll){
			$scope.list.searchCriteria.status = undefined;
		}else{
			var status = "";
			angular.forEach($scope.leftmenu.allStatus,function(obj){
				if(obj.checked){
					status = status + obj.key + ",";
				}
			});
			if(status != ""){
				$scope.list.searchCriteria.status = status.substring(0,status.length-1);
			}else{
				$scope.list.searchCriteria.status = undefined;
			}
			
		}
		if($scope.leftmenu.datecreatedSelectAll){
			$scope.list.searchCriteria.datesearch = undefined;
		}else{
			var datesearch = "";
			angular.forEach($scope.leftmenu.dateCreated,function(obj){
				if(obj.checked == true){
					datesearch = datesearch + obj.value + ",";
				}
			});
			if(datesearch == ""){
				$scope.list.searchCriteria.datesearch = undefined;
			}else{
				$scope.list.searchCriteria.datesearch = datesearch.substring(0,datesearch.length-1);;
			}
		}
	}
		
	$scope.selectAllStatusChange = function(){
		if($scope.leftmenu.statusSelectAll){
    		angular.forEach($scope.leftmenu.allStatus,function(obj){
    			obj.checked = true;
    		});
    	}else{
    		angular.forEach($scope.leftmenu.allStatus,function(obj){
    			obj.checked = false;
    		});
    	}
		$scope.prepareSearchCriteria();
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	
	$scope.selectAllStatus = function(status){
		if(status.checked){
    		var selectedSatus = $.grep($scope.leftmenu.allStatus,function(obj){
    			return obj.checked == false;
    		});
    		if(selectedSatus.length > 0){
    			$scope.leftmenu.statusSelectAll = false;
    		}else{
    			$scope.leftmenu.statusSelectAll = true;
    		}
    	}else{
    		$scope.leftmenu.statusSelectAll = false;
    	}
		$scope.prepareSearchCriteria();
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	
	$scope.updateSelectedStatus = function(status){
    	if(status.checked){
    		var selectedSatus = $.grep($scope.leftmenu.allStatus,function(obj){
    			return obj.checked == false;
    		});
    		if(selectedSatus.length > 0){
    			$scope.leftmenu.statusSelectAll = false;
    		}else{
    			$scope.leftmenu.statusSelectAll = true;
    		}
    	}else{
    		$scope.leftmenu.statusSelectAll = false;
    	}
	}
	
	$scope.selectAllDateCreated = function(){
		if($scope.leftmenu.datecreatedSelectAll){
    		angular.forEach($scope.leftmenu.dateCreated,function(obj){
    			obj.checked = true;
    		});
    	}else{
    		angular.forEach($scope.leftmenu.dateCreated,function(obj){
    			obj.checked = false;
    		});
    	}
		$scope.prepareSearchCriteria();
		$scope.list.listLists($scope.list.searchCriteria);
	}
	$scope.changeDateCreated = function(date){
    	if(date.checked){
    		var selectedSatus = $.grep($scope.leftmenu.dateCreated,function(obj){
    			return obj.checked == false;
    		});
    		if(selectedSatus.length > 0){
    			$scope.leftmenu.datecreatedSelectAll = false;
    		}else{
    			$scope.leftmenu.datecreatedSelectAll = true;
    		}
    	}else{
    		$scope.leftmenu.datecreatedSelectAll = false;
    	}
    	$scope.prepareSearchCriteria();
		$scope.list.listLists($scope.list.searchCriteria);
	}
	
	$scope.selectAllTypeSelectAll = function(){
		if($scope.leftmenu.typeSelectAll){
    		angular.forEach($scope.leftmenu.allTypes,function(obj){
    			obj.checked = true;
    		});
    	}else{
    		angular.forEach($scope.leftmenu.allTypes,function(obj){
    			obj.checked = false;
    		});
    	}
	}
	$scope.updateSelectedListType = function(status){
    	if(status.checked){
    		var selectedSatus = $.grep($scope.leftmenu.allTypes,function(obj){
    			return obj.checked == false;
    		});
    		if(selectedSatus.length > 0){
    			$scope.leftmenu.typeSelectAll = false;
    		}else{
    			$scope.leftmenu.typeSelectAll = true;
    		}
    	}else{
    		$scope.leftmenu.typeSelectAll = false;
    	}
	}
	
	
	$scope.leftmenu.filesList = [{id: '1', name: 'file 1' },{ id: '2', name: 'file 2' },{ id: '3', name: 'file 3' }];
	$scope.leftmenu.allStatus = [{'key':'W','value':'Waiting'},{'key':'E','value':'Errored'},{'key':'I','value':'In Progress'},{'key':'C','value':'Completed'},{'key':'U','value':'Waiting to retry'},{'key':'P','value':'Preparing'}];
	$scope.leftmenu.dateCreated=[{key:"Today", value:"T"},{key:"Yesterday", value:"Y"},{key:"This Week", value:"TW"},{key:"Last Week", value:"LW"},{key:"This Month", value:"TM"}];
	//$scope.leftmenu.allStatus = [{'key':'W','value':'Waiting'},{'key':'B','value':'Preparing'},{'key':'E','value':'Errored'},{'key':'I','value':'In Progress'},{'key':'C','value':'Completed'},{'key':'U','value':'Waiting to retry'},{'key':'X','value':'Completed'},{'key':'K','value':'In Progress'}];
	$scope.leftmenu.allTypes=[  {key:"General Purpose", value:"G"},
		 	                    {key:"Seed", value:"S"},
		 	                    {key:"Test", value:"T"}
		 	                    ];
	$scope.leftmenu.datecreatedSelectAll = true;
	$scope.leftmenu.statusSelectAll = true;
	angular.forEach($scope.leftmenu.allStatus,function(obj){obj.checked = true;});
	angular.forEach($scope.leftmenu.dateCreated,function(obj){obj.checked = true;});
	
	$scope.$on('loadListOnClick',function(){
		$scope.list.defaultAdhocListValues();
		$scope.list.loadPageDetails(1);
		$scope.list.listTemplate = 'list/templates/listoflists.html';
	});
	
	$scope.list.defaultAdhocListValues = function(){
		$('.buttons').show();
		 $scope.list.totalRecords = -1;		
			$scope.list.currentPageNumber=1;
			$scope.list.searchCriteria = {};		
			$scope.list.searchCriteria.pageno = 1;		
			$scope.list.searchCriteria.pagesize = 7;			
			$scope.list.searchCriteria.sortby="createdate";
			$scope.list.searchCriteria.sortorder="DESC";
			$scope.list.frequency = 'O';
			$scope.list.ignoreBadFiles = 'N';
			$scope.list.ignoreBadRecords = 'N';
			$scope.list.preserveOrder = 'N';
			$scope.list.mergeDuplicates = 'N';
			$scope.list.isEditMode = 'N';	
			$scope.list.uploadFileName = undefined;
			$scope.list.remote = {};
			$scope.list.db = {};
			$scope.list.db.sourceList = [];
			$scope.tempList = $scope.list.filesList;
			$scope.selectedColumnsList = [];
			$scope.list.fileDefinitionList = [];
			$scope.list.tablesList = [];
			$scope.list.fdFilesList = [];
			$scope.enableList = true;
			$scope.list.sourceType = 'T';
			$scope.list.channelType = 'E';
			$scope.list.selectedRow  = 0;
			$scope.list.name = undefined;
		 	$scope.list.type = 'A';
		 	$scope.list.fileFormatSpec = {};
			 $scope.list.selectedFolder = undefined;
			 $scope.list.selectedCategory = undefined;
			 $scope.list.selectedAudience = undefined;
			 $scope.list.listType = undefined;
			 $scope.list.createFrom = undefined;
			 $scope.list.dbSelectQuery = undefined;
			 $scope.list.dbSelectQueryData = [];
			 $scope.list.fdMappingVOList = [];
			 $scope.list.scheduleactivemode = 'N';
			 $scope.list.emailSmsDefaultValues();
			 $scope.list.uploadFileName = undefined;
			 $scope.list.fdMappingVOList = [];
			 $scope.list.nullValueRepresentation = $scope.list.nullValue[0].key;
			 $scope.list.emailSmsDefaultValues();
			 $scope.list.filesInFolder = {};
			$scope.list.filesInFolder.head = [];
			$scope.list.filesInFolder.data = [];
			$scope.list.isFileUploaded = false;
			$scope.list.showaddfolder=false;
			$scope.list.showcategory=false;
			$scope.editfilemapping = [];
	 }
	 
	 $scope.list.emailSmsDefaultValues = function(){
		 /* email & sms rules checked bydefault */
			$scope.list.remrepeatdots = false;
			$scope.list.remdoublequotes = false;
			$scope.list.reminvalid = false;
			$scope.list.remrepeatat = false;
			$scope.list.removedot = false;
			$scope.list.changeunderscore = false;
			$scope.list.removesinglequoteatend = false;
			$scope.list.removesinglequoteatbegin = false;
			$scope.list.enclosedoublequotes = false;
			$scope.list.remwhitespace = false;
			
			$scope.list.removeplus = true;
			$scope.list.removewhitespacesms = true;
			$scope.list.removeminus = true;
	 }
	
	$scope.list.selectAllLists = function(){
		angular.forEach($scope.list.adhocList, function(listdetail){
			listdetail.checked = true;
		});
	};
	
	$scope.list.clearListSelection = function(){
		angular.forEach($scope.list.adhocList, function(listdetail){
			listdetail.checked = false;
		});
	};
	
	$scope.list.changeCreationType = function(){
		$scope.list.listID = undefined;
		if($scope.list.type == 'A'){
			$scope.list.listType = undefined;
			$scope.list.selectedAudience = undefined;
	    	var listcriteria = {};
	    	listcriteria.sourcetype='A';
	    	listcriteria.departmentID = zhapp.loginUser.departmentID;
	    	listService.listAdhocLists(listcriteria).success(function(result){
	    		if(result.result.length > 0){
	    			$scope.list.fdListForClone = [];
		    		var temp = {};
		    		temp.name = "None";
					$scope.list.fdListForClone.push(temp);
					angular.forEach(result.result,function(obj){
						$scope.list.fdListForClone.push(obj);
					});
					$scope.list.selctedFdForClone = $scope.list.fdListForClone[0];
	    		}
	    	}).error(function(error){
	    		showErrorMessage($scope.list.getErrorMessages(error));
	    	});
		}else{
			$scope.list.selectedListTypeForFd = undefined;
			$scope.list.selctedFdForClone = undefined;
			$scope.list.selectedAudience = undefined;
			$scope.list.listType = undefined;
			$scope.list.dataMappingVo = [];
			$scope.list.selectedSource = undefined;
			if($scope.list.selectedAudience != undefined){
    	    	$scope.list.getTablesList($scope.list.sourceType,$scope.list.selectedAudience.audienceId);
    		}
		}
	}
	
	$scope.list.changeSourceType = function(){
		$scope.list.selectedSource = undefined;
		$scope.list.dataMappingVo = [];
		if($scope.list.selectedAudience != undefined){
	    	$scope.list.getTablesList($scope.list.sourceType,$scope.list.selectedAudience.audienceId);
		}
	}
	
	$scope.list.cloneFileDefintion = function(){
		if($scope.list.selctedFdForClone == undefined){
			return;
		}
		if($scope.list.selctedFdForClone != null && $scope.list.selctedFdForClone.name == 'None'){
			var name = $scope.list.name
			$scope.list.defaultAdhocListValues();
			$scope.list.name = name;
			if($scope.notifications)
				$scope.notifications.isEnabled = false;
			return;
		}
		if($scope.list.type == 'A'){
			var listobj = angular.copy($scope.list.selctedFdForClone);
			
			listobj.name = $scope.list.name;
			listobj.listID = undefined;
	    	$scope.list.listType = listobj.listType;
	    	$scope.list.sourceType = listobj.sourceType;
	    	/*$scope.list. = listobj.sourceType;
	    	$scope.list. = listobj.status;
	    	$scope.list. = listobj.tableName;
	    	$scope.list. = listobj.updatedBy;
	    	$scope.list. = listobj.categoryID;*/
    		$scope.list.type = 'A';
    		//$scope.list.name = listobj.name;
        	$scope.list.listID = listobj.listID;
        	$scope.list.editList(listobj);
        	$scope.list.isEditMode = 'N';
    		/*var promise = $scope.list.initializeListForEdit();
    		promise.then(function(){
    			$scope.list.listTemplate = 'list/templates/neworeditlist.html';
    			$scope.list.selectedFolder = $.grep($scope.list.foldersList,function(obj){
    				return obj.folderid == listobj.folderID;
    			})[0];
    			
    			$scope.list.selectedCategory = $.grep($scope.list.categoriesList,function(obj){
    				return obj.categoryid = listobj.categoryID;
    			})[0];
    			
    			
    		});*/
		}
	}
	
	
	$scope.list.moveList = function(){
		$scope.list.selectedFodlderid = undefined;
		$scope.list.selectedCatid = undefined;
		if($scope.list.adhocList.length==0){
			return false;
		}
		var getSelectedlist = $.grep($scope.list.adhocList,function(obj){
			return obj.checked == true;
		});
		if(getSelectedlist.length == 0){
			showInfoMessage("Select a list to move");
		}else{
			var criteria = {};
			criteria.departmentId = zhapp.loginUser.departmentID;
			criteria.type = 'A';
			departmentService.listFolders(criteria).success(function(result){
				console.log(result);
				$scope.list.moveToFoldersList = [];
	    		angular.forEach(result,function(folder){
	    			var obj = {};
	    			obj.id = folder.folderid;
	    			obj.foldername = folder.foldername;
	    			$scope.list.moveToFoldersList.push(obj);
				});
	    		if($scope.list.moveToFoldersList.length > 0)
	    			showMoveToListFolderview();
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}
	};
	
	function showMoveToListFolderview(){
		$scope.list.movedToRadioButton="fold_view";
		$(".movinglist").toggle();
		showpopUp();
	}
	
	$scope.list.refreshList = function(){
		$scope.list.loadPageDetails(1);
	}
	
	$scope.leftmenu.showTrash = function(){
		var deptId = zhapp.loginUser.departmentID;
		listService.getTrashFolderList(deptId).success(function(result){
			$scope.leftmenu.trashList = result;
			angular.forEach($scope.leftmenu.trashList,function(results){
				angular.forEach($scope.leftmenu.foldersList,function(folder){
					if(results.previousFolderID===folder.folderid){
						results.previousFolderName=folder.foldername;
					}
				});
			}); 
			//$scope.leftmenu.allTrashEntries = false;
			$(".trash-popup").dialog('open');
    	}).error(function(error){
    		showErrorMessage($scope.list.getErrorMessages(error));
    	});
	}
	
	$scope.leftmenu.selectedTrashEntries = true;
	$scope.leftmenu.onSelectAllTrashEntries = function(){
		if($scope.leftmenu.allTrashEntries){
    		angular.forEach($scope.leftmenu.trashList,function(obj){
    			obj.checked = true;
    		});
    	}else{
    		angular.forEach($scope.leftmenu.trashList,function(obj){
    			obj.checked = false;
    		});
    	}
		var selectedTrashList = $.grep($scope.leftmenu.trashList,function(obj){
			return obj.checked == true;
		});
		if(selectedTrashList.length > 0){
			$scope.leftmenu.selectedTrashEntries = false;
		}else{
			$scope.leftmenu.selectedTrashEntries = true;
		}
	}
	$scope.leftmenu.changeTrashDetails = function(trashDetails){
    	if(trashDetails.checked){
    		var selectedSatus = $.grep($scope.leftmenu.trashList,function(obj){
    			return obj.checked == false;
    		});
    		if(selectedSatus.length > 0){
    			$scope.leftmenu.allTrashEntries = false;
    		}else{
    			$scope.leftmenu.allTrashEntries = true;
    		}
    	}else{
    		$scope.leftmenu.allTrashEntries = false;
    	}
    	var selectedTrashList = $.grep($scope.leftmenu.trashList,function(obj){
			return obj.checked == true;
		});
		if(selectedTrashList.length > 0){
			$scope.leftmenu.selectedTrashEntries = false;
		}else{
			$scope.leftmenu.selectedTrashEntries = true;
		}
	}
	
	$scope.leftmenu.emptyTrash = function(){
		$scope.leftmenu.deleteTrashEntries();
	}
	
	$scope.leftmenu.closeTrash = function(){
		$scope.list.loadPageDetails(1);
	}
	
	$scope.leftmenu.restoreListFromTrash = function(){
		var selectedTrashList = $.grep($scope.leftmenu.trashList,function(obj){
			return obj.checked == true;
		});
		if(selectedTrashList.length > 0){
			var ids = "";
			angular.forEach(selectedTrashList,function(obj){
				ids = ids + obj.listID + ",";
    		});
			ids = ids.substring(0,ids.length-1);
			var deptID = zhapp.loginUser.departmentID;
			listService.updateFolerOrCategory("folderid","updatefolderid",ids,deptID).success(function(result){
				if(result.resultval == 1){
					listService.getTrashFolderList(deptID).success(function(result){
						$scope.leftmenu.trashList = result;
			    	});
				}
			}).error(function(error){
				showConfigurationErrorMessage(error);
			});
		}
	}
	
	$scope.leftmenu.deleteTrashEntries = function(){
		var selectedTrashList = $.grep($scope.leftmenu.trashList,function(obj){
			return obj.checked == true;
		});
		if(selectedTrashList.length > 0){
			var ids = "";
			angular.forEach(selectedTrashList,function(obj){
				ids = ids + obj.listID + ",";
    		});
			ids = ids.substring(0,ids.length-1);
			showCommonConfirmMessage("Are you sure you want to permanently delete the selected list(s)?","Confirm","Yes","No",450,function(value){
				if(value == true){
					listService.deleteAdhocList(ids).success(function(result){
						var deptId = zhapp.loginUser.departmentID;
						if(result.resultval == 1){
							listService.getTrashFolderList(deptId).success(function(result){
								$scope.leftmenu.trashList = result;
					    	});
						}
					});
				}
			});
		}
	}
	
	
	$scope.list.deleteListPopUp = function(){
		if($scope.list.adhocList.length==0){
			return false;
		}
		var getSelectedlist = $.grep($scope.list.adhocList,function(obj){
			return obj.checked == true;
		});
		if(getSelectedlist.length>0){			
			var msg="Are you sure you want to delete the selected list(s)?";
			showCommonConfirmMessage(msg,"Confirm","Yes","No",450,function(value){
				if(value == true){
					if(getSelectedlist.length > 0){
						var ids = "";
						var listNames = "";
						if(getSelectedlist.length == 1){
							ids = getSelectedlist[0].listID;
							listNames = ids + getSelectedlist[0].name;
						}else{
							angular.forEach(getSelectedlist,function(obj){
								ids = ids + obj.listID + ",";
								listNames = listNames + obj.listID + obj.name + ",";
							})
							ids = ids.substring(0,ids.length-1);
							listNames = listNames.substring(0,listNames.length-1);
						}
						var deptID = zhapp.loginUser.departmentID;
						listService.updateFolerOrCategory(listNames,"trash",ids,deptID).success(function(result){
							$scope.list.loadPageDetails(1);
						}).error(function(error){
							showErrorMessage($scope.list.getErrorMessages(error));
						});
					}
				}
			});
		}else{
			showInfoMessage("You must select an item from the list before deleting it.");
		};
	};
	
	$scope.list.resetRadioButtons=function(param){
		if(param=='categories')	{
			$scope.list.movedToRadioButton="cat_view";
			var criteria = {};
			criteria.departmentId = zhapp.loginUser.departmentID;
			criteria.type = 'A';
			departmentService.listCategories(criteria).success(function(result){
				$scope.list.moveToCategoriesList = [];
	    		angular.forEach(result,function(category){
	    			var obj = {};
	    			obj.id = category.categoryid;
	    			obj.catcode = category.categorycode;
	    			$scope.list.moveToCategoriesList.push(obj);
				});
				
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}			  
		else{
			$scope.list.movedToRadioButton="fold_view";
			var criteria = {};
			criteria.departmentId = zhapp.loginUser.departmentID;
			criteria.type = 'A';
			departmentService.listFolders(criteria).success(function(result){
				$scope.list.moveToFoldersList = [];
	    		angular.forEach(result,function(folder){
	    			var obj = {};
	    			obj.id = folder.folderid;
	    			obj.foldername = folder.foldername;
	    			$scope.list.moveToFoldersList.push(obj);
				});
	    		
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}
	  };
	  $scope.list.setmoveToListFolder = function(id){
			$scope.list.mtfValueId=id;
			$scope.list.mtCValueId=-1;
	  }
	  
	  
	  $scope.list.setmoveToListCat = function(id){
		  $scope.list.mtfValueId=-1;
			$scope.list.mtCValueId=id;
	  }
	  
	  $scope.list.cancel = function(){
		  $scope.list.moveToFoldersList = [];
		  $scope.list.moveToCategoriesList = [];
		  $scope.list.mtfValueId=-1;
			$scope.list.mtCValueId=-1;
			hidepopUp();
	  }
	  function showpopUp(){
		    $('.disableBack').show();	
		}
	  function hidepopUp(){
		  $scope.list.moveToFoldersList = [];
		  $scope.list.moveToCategoriesList = [];
		  $scope.list.mtfValueId=-1;
			$scope.list.mtCValueId=-1;
			$('.l-rightpanel').css({'margin-top': '0px'});
		    $('.movinglist').hide();
			$('.disableBack').hide();	
			$('.rgt-headerfix').css({position: 'fixed'});
			$('.rgt-headerfix').css("height", "auto");
			$('.rgt-headerfix').css('padding-top',"12px");
	  }
	  $scope.list.movelistsToFolderOrCategory=function(){
		  	if($scope.list.mtfValueId==-1 && $scope.list.mtCValueId==-1){
				showInfoMessage("Select a folder or category");
				return;
		  	}		  
			if($scope.list.movedToRadioButton=="fold_view"){
				var temp = $.grep($scope.list.adhocList,function(obj){
					return obj.checked == true;
				});
				if(temp.length > 0){
					var ids = "";
					if(temp.length == 1){
						ids = temp[0].listID
					}else{
						angular.forEach(temp,function(obj){
							ids = ids + obj.listID + ",";
						})
						ids = ids.substring(0,ids.length-1);
					}
					var deptID = zhapp.loginUser.departmentID;
					listService.updateFolerOrCategory("folderid",$scope.list.mtfValueId,ids,deptID).success(function(result){
						console.log(result);
						hidepopUp();
						$scope.list.loadPageDetails(1);
					}).error(function(error){
						showConfigurationErrorMessage(error);
					});
				}
				
			}		 
			else if($scope.list.movedToRadioButton=="cat_view"){
				var temp = $.grep($scope.list.adhocList,function(obj){
					return obj.checked == true;
				});
				if(temp.length > 0){
					var ids = "";
					if(temp.length == 1){
						ids = temp[0].listID
					}else{
						angular.forEach(temp,function(obj){
							ids = ids + obj.listID+ ",";
						})
						ids = ids.substring(0,ids.length-1);
					}
					var deptID = zhapp.loginUser.departmentID;
					listService.updateFolerOrCategory("categoryid",$scope.list.mtCValueId,ids,deptID).success(function(result){
						console.log(result);
						hidepopUp();
						$scope.list.loadPageDetails(1);
					}).error(function(error){
						showConfigurationErrorMessage(error);
					});
				}
			} 
		};
	$scope.list.loadScheduleEvents = function() {
    	
        $('.timepicker').timepicker({
            showSeconds: false,
            showMeridian: false,
            defaultTime: false,
            disableFocus: false,
            minuteStep: 1
        });
        $('.cal-icon').click(function() {
            $(this).prev("input").trigger('focus');
        });
        $(".scheduleTimeField").datepicker({
            autoclose: true,
            todayHighlight: true,
            //startDate: new Date()
        });
    };
    $scope.list.listTypeChangeForFd = function(){
    	$scope.list.dataMappingVo = [];
    	if($scope.list.selectedListTypeForFd == 'S' || $scope.list.selectedListTypeForFd == 'T'){
			$scope.list.audienceList = $.grep($scope.list.audienceList,function(obj){
    		return obj.audienceType == 1;
    		});
		}else{
			$scope.list.audienceList = fileDefinitionService.getDeptAudienceList(zhapp.loginUser.departmentID).success(function(result){
				$scope.list.audienceList = [];
			if(result != null && result != undefined && result.length > 0){
				$scope.list.audienceList = sortAudienceList(result);
			}	
			return 	$scope.list.audienceList;	
			});
			if($scope.list.selectedListTypeForFd == 'U' || $scope.list.selectedListTypeForFd == 'R'){
				$scope.list.getFildefinitionListForFd(); 
			}
		}
    }
    
	$scope.list.changelistType = function(){
		$scope.list.selectedAudience = undefined;
		$scope.list.dataMappingVo = undefined;
		$scope.list.sourceType = 'T';
		if($scope.list.listType == 'U' || $scope.list.listType == 'R'){
			$scope.list.getFildefinitionList();
		}
		var promise = $scope.getDeptSpecListAudinces();
		promise.then(function(result){
			 if($scope.list.audienceList.length > 0){
				 if($scope.list.listType == 'T'){
					   $scope.list.audienceList =  $filter('filter')($scope.list.audienceList,{audienceName:'Email Address Audience'},true);
					   if($scope.list.audienceList.length == 0){
						   showErrorMessage("Department does not have access to Email Address Audiences.");
						   return false;
					   }
				}else if($scope.list.listType == 'S'){
					$scope.list.audienceList = $.grep($scope.list.audienceList,function(obj){
			    	     return obj.audienceName != "Sms Audience";
			    	});	
				}else{
					return 	$scope.list.audienceList;	
				}
			 }else{
				 showErrorMessage("Department does not have Audiences.");
				 return false;
			 }
		});
	}
	
	$scope.getDeptSpecListAudinces = function(){
		     var d = $q.defer();
			 var prom = $scope.list.getAudienceList(); 
			 prom.then(function(result){
				 if($scope.list.audienceList.length > 0){
					 fileDefinitionService.getDeptAudienceList(zhapp.loginUser.departmentID).success(function(result){
							var audienceInfo = [];
							var totAudiences = [];
							totAudiences = $scope.list.audienceList;
							$scope.list.audienceList = [];
							if(result != null && result != undefined && result.length > 0){
								angular.forEach(totAudiences,function(totAud){
			 						angular.forEach(result,function(deptAud){
			 							  if(totAud.audienceId == deptAud.audienceId){
			 								audienceInfo.push(totAud);
			 							  }
			 						});
			 					});
								$scope.list.audienceList = sortAudienceList(audienceInfo);
							}
							d.resolve();
						}).error(function(error){
							showErrorMessage("No audience created yet for this Department...");
							d.reject();
						});
				 }
			 });
		return d.promise;
	}
	
	
	$scope.list.addNewList = function(){
		$scope.fdobjnotifications=undefined;
		$scope.savedListItem=false;
		$scope.editfilemapping = [];
		$scope.list.audienceColumns = undefined;
		$scope.list.getEncryptedKeyList();
		$scope.list.listTemplate = 'list/templates/neworeditlist.html';
		$scope.list.initializeListForEdit();
		$scope.list.isEditMode = 'N';
		$scope.list.listID = undefined;
		$scope.list.fileDefinitionID = undefined;
		$scope.list.fileScheudleID = undefined;
		$scope.list.changeemail=false;
		$scope.list.nullValueRepresentation = $scope.list.nullValue[0].key;
//		$scope.list.booleanFormat = $scope.list.booleanFormatList[0].key;
		$scope.list.dateFormat = $scope.list.dateFormatList[0].key;
		$scope.list.dateDelimiter = $scope.list.dateDelimiterList[0].key;
		$scope.list.fileFormatSpec = {};
		$scope.list.frequency = 'I';
		$scope.list.useEncryption = 'N';
		$scope.list.encryptionKey = undefined;
		$scope.list.mergeDuplicates = 'N';
		$scope.addnewListFlag=true;
		if($scope.list.type == 'A'){
			$scope.notificationDetails();
	    	var listcriteria = {};
	    	listcriteria.sourcetype='A';
	    	listcriteria.departmentID = zhapp.loginUser.departmentID;
	    	listService.listAdhocLists(listcriteria).success(function(result){
	    		if(result.result.length > 0){
	    			$scope.list.fdListForClone = [];
		    		var temp = {};
		    		temp.name = "None";
					$scope.list.fdListForClone.push(temp);
					angular.forEach(result.result,function(obj){
						$scope.list.fdListForClone.push(obj);
					});
					$scope.list.selctedFdForClone = $scope.list.fdListForClone[0];
	    		}
	    	}).error(function(error){
	    		showErrorMessage($scope.list.getErrorMessages(error));
	    	});
	    	//$scope.list.getNotificationsByDeptID();
	    	$scope.list.setTimezone();
	    	//$scope.list.getAddressType();
		}else{
			if($scope.list.selectedAudience != undefined){
    	    	$scope.list.getTablesList($scope.list.sourceType,$scope.list.selectedAudience.audienceId);
    		}
		}
		
	}
	$scope.list.getAddressType = function(){
		fileDefinitionService.getAddressType().success(function(result){
			if(result != null && result != undefined){
				$scope.list.emailAddressType = result['E'];
				$scope.list.smsAddressType = result['Z'];
			}else{
				showErrorMessage("No Addresstype exists.");
			}
			
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	}
	$scope.list.getAddressType();
	
	$scope.resetOnTimeZoneChange=function(){
		$scope.list.startDate =  zhapp.getCnvDateTime('D',null, $scope.list.timezone);    			
		$scope.list.startTime =  zhapp.getCnvDateTime('T',null, $scope.list.timezone);
    };
    
	$scope.list.setTimezone = function(){
		$scope.list.timezone = zhapp.loginUser.timeZone;
		$scope.list.tz = zhapp.loginUser.timeZone;
		$scope.resetOnTimeZoneChange();
	}
	
	$scope.list.resetOnChange = function(){
		$scope.list.setTimezone();
	}
	
	
	 function listRemoteServerFolders(fileSoruceName,isTest,currentPath){
			var d = $q.defer();
			var list = [];
			fileDefinitionService.getFoldersFromRemoteServer(fileSoruceName,isTest,currentPath).success(function(result){
				$scope.list.remote.remoteFolderList = result;
				$scope.list.remote.currentFolder = currentPath;
				$scope.list.remote.currentFolderselected = currentPath;
				$scope.list.remote.currentFolderselectedFile = currentPath;
				d.resolve();
			}).error(function(error){
				$scope.list.remote.currentFolder = undefined;
				showErrorMessage($scope.list.getErrorMessages(error));
				d.reject();
			});
			return d.promise;
	 }
	 $scope.list.getFilesInFolder = function(){
		 	if($scope.list.selectedAudience == undefined){
	    		showErrorMessage("Please select the Audience");
	    		return;
	    	}
		 	$scope.list.filesInFolder = {};
	    	$scope.list.filesInFolder.head = [];
			$scope.list.filesInFolder.data = [];
			var headerrow = "0";
			var datarow = "1";
			var delimit = ",";
			var textqualifier = "NONE";
			if($scope.list.fileFormatSpec != null){
				if($scope.list.fileFormatSpec.delimiter)delimit = $scope.list.fileFormatSpec.delimiter;
				if($scope.list.fileFormatSpec.textQualifier)textqualifier = $scope.list.fileFormatSpec.textQualifier;
				if($scope.list.fileFormatSpec.headerRowAtLine)headerrow = $scope.list.fileFormatSpec.headerRowAtLine;
				if($scope.list.fileFormatSpec.dataStartsFromLine)datarow = $scope.list.fileFormatSpec.dataStartsFromLine;
			}
	    	if($scope.list.remote.hostServer.protocol=='http' || $scope.list.remote.hostServer.protocol=='https'){
	    		var rfileexten = $scope.list.remote.hostServer.hostname.substring($scope.list.remote.hostServer.hostname.lastIndexOf(".") + 1,$scope.list.remote.hostServer.hostname.length); 
	    		if(rfileexten.toLowerCase()=="txt" || rfileexten.toLowerCase()=="csv"){
	    			fileDefinitionService.getFoldersFromRemoteServerWithDelimiter($scope.list.remote.hostServer.fileSourceName,true,$scope.list.remote.hostServer.hostname,headerrow,datarow,delimit,textqualifier).success(function(result){
	    				if(result != null){
	    					var allRows = [];
	    					var length = undefined;
	    					angular.forEach(result,function(obj,index){
	    						if(obj.length == 0)return;
	    						$scope.list.filesInFolder.head.push(obj.key);
	            				allRows.push(obj.values)
	            				if(!length)
	            					length = obj.values.length;
	            			});
	            			for(var i=0;i<length;i++){
	            				var row = [];
	            				angular.forEach(allRows,function(obj,index){
	            			        row.push(obj[i]);
	                			});
	            				$scope.list.filesInFolder.data.push(row);
	            			}
	            			$(".filesInFolder").dialog('open');
	            			setTimeout(function(){$scope.mapDataForRemoteServer(result);},10);
	        			}
	        		}).error(function(error){
	        			showErrorMessage("File is Not Available");
	        		});
	    		}else{
	    			showErrorMessage("Please select csv or text file");
	    			return;
	    		}
	    	}else{
	    		var rfileexten = $scope.list.remote.currentFolderselectedFile.substring($scope.list.remote.currentFolderselectedFile.lastIndexOf(".") + 1,$scope.list.remote.currentFolderselectedFile.length); 
	    		if(rfileexten.toLowerCase()=="txt" || rfileexten.toLowerCase()=="csv"){
	    			fileDefinitionService.getFoldersFromRemoteServerWithDelimiter($scope.list.remote.hostServer.fileSourceName,true,$scope.list.remote.currentFolderselectedFile,headerrow,datarow,delimit,textqualifier).success(function(result){
	    				if(result != null){
	    					var allRows = [];
	    					var length = undefined;
	    					angular.forEach(result,function(obj,index){
	    						if(obj.length == 0)return;
	    						$scope.list.filesInFolder.head.push(obj.key);
	            				allRows.push(obj.values)
	            				if(!length)
	            					length = obj.values.length;
	            			});
	            			for(var i=0;i<length;i++){
	            				var row = [];
	            				angular.forEach(allRows,function(obj,index){
	            			        row.push(obj[i]);
	                			});
	            				$scope.list.filesInFolder.data.push(row);
	            			}
	            			$(".filesInFolder").dialog('open');
	            			setTimeout(function(){$scope.mapDataForRemoteServer(result);},10);
	        			}
	        		}).error(function(error){
	        			if(error.errors[0].message.startsWith("FL0067 : Loading")){
	        				showErrorMessage("Select a file to view the sample data");
	        			}else
	        			showErrorMessage($scope.list.getErrorMessages(error));
	        		});
	    		}else{
	    			showErrorMessage("Please select csv or text file");
	    			return;
	    		}
	    	}
	}
	 
	 
	 $scope.mapDataForRemoteServer = function(result){
			if(result != null){
				$scope.list.fdMappingVOList = [];
	    		$.each(result,function(index,value){
	    			fileDefMappingVO = {};
	    			fileDefMappingVO.header = value.key.replace(/ /g, '');
	    			fileDefMappingVO.sampleDataColumns = value.values;
	    			fileDefMappingVO.sampleDataColumn = value.values[0];
	    			fileDefMappingVO.dataTypeList = $scope.list.dataTypes;
	    			if($scope.list.audienceColumns != undefined){
		    			fileDefMappingVO.audienceColumn = $.grep($scope.list.audienceColumns,function(obj){
		    				return obj.logicalColumnName == 'Omit';
		    			})[0];
	    			}
	    			fileDefMappingVO.isNullable = 'N';
	    			fileDefMappingVO.length = 400;
	    			fileDefMappingVO.disableLength = true;
	    			$scope.list.fdMappingVOList.push(fileDefMappingVO);
	    		});
	    		mapDefaultColumnsData(); 
			}
 }
	
	$scope.tempList = $scope.list.filesList;
	$scope.selectedColumnsList = [];
	
	$scope.list.fileDefinitionList = [];
	$scope.list.tablesList = [];
	$scope.list.fdFilesList = [];
	$scope.enableList = true;
	$scope.list.sourceType = 'T';
//	$scope.list.type = 'A';
	
	
	$scope.list.initializeListForEdit = function(){
		$scope.list.defaultAdhocListValues();
		var d = $q.defer();
		var promise = [];
		promise.push($scope.list.getFoldersList());
		promise.push($scope.list.getCategoriesList());
		promise.push($scope.list.getEncryptedKeyList());
		$q.all(promise).then(function(data){
			d.resolve();
		});
		return d.promise;
	}
	
	
	$scope.list.getFoldersList = function(){
		var d = $q.defer();
		var criteria = {};
		criteria.departmentId = zhapp.loginUser.departmentID;
		criteria.type = 'A';
		departmentService.listFolders(criteria).success(function(result){
			var res = [];
			angular.forEach(result,function(folder){
    			if(folder.foldername!='TRASH'){
    				res.push(folder);
    			}
			});
			$scope.list.foldersList=res;
			if(zhapp.scriptProvider.componentName == "list"){
				$scope.leftmenu.foldersList = $scope.list.foldersList;
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	$scope.list.getCategoriesList = function(){
		var d = $q.defer();
		var criteria = {};
		criteria.departmentId = zhapp.loginUser.departmentID;
		criteria.type = 'A';
		departmentService.listCategories(criteria).success(function(result){
			var res = [];
			angular.forEach(result,function(category){
    			if(category.categorycode!='TRASH'){
    				res.push(category);
    			}
			});
			$scope.list.categoriesList = res;
			if(zhapp.scriptProvider.componentName == "list"){
				$scope.leftmenu.categoriesList = $scope.list.categoriesList;
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	function sortAudienceList(result){
		var noEmailSms = $.grep(result,function(obj){
			return !(obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var emailSms = $.grep(result,function(obj){
    		return (obj.audienceType == 1 || obj.audienceType == 4);
    	});
		var sorted = noEmailSms.sort(function(a, b){
			if(a.audienceName.toLowerCase() < b.audienceName.toLowerCase()) return -1;
			if(a.audienceName.toLowerCase() > b.audienceName.toLowerCase()) return 1; return 0;
			});
		var finalAudience = [];
		angular.forEach(emailSms,function(obj){
			finalAudience.push(obj);
		});
		angular.forEach(sorted,function(obj){
			finalAudience.push(obj);
		});
		return finalAudience;
	}
	
	$scope.list.getAudienceList = function(){
		var d = $q.defer();
		fileDefinitionService.getAudienceList().success(function(result){
			if(result != null && result != undefined && result.length > 0){
				$scope.list.audienceList = sortAudienceList(result);
			}else{
				showErrorMessage("No audience created yet...");
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
	
	$scope.list.getFildefinitionListForFd = function(){
		var d = $q.defer();
		var criteria = {};
		if($scope.list.selectedListTypeForFd == 'U' || $scope.list.selectedListTypeForFd == 'R'){
			if($scope.list.selectedListTypeForFd == 'U')
				criteria.fileType = 'U';
			else
				criteria.fileType = 'R';
		}else{
			criteria.audienceId = $scope.list.selectedAudience.audienceId;
		}
		criteria.departmentID = zhapp.loginUser.departmentID;
		listService.getFileDefinitionList(criteria).success(function(result){
			$scope.list.fileDefinitionList = result.result;
			if(result.result && result.result.length == 0){
				showErrorMessage('No filedefinitions found');
			}else{
				var temp = [];
				angular.forEach($scope.list.fileDefinitionList,function(obj,index){
					if(obj.tableName && obj.tableName != ''){
						temp.push(obj.tableName);
					}
				});
				$scope.list.tablesList = temp;
				//$scope.list.mapListData();
				if($scope.list.sourceType == 'F'){
					
				}
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		if($scope.list.selectedAudience != undefined){
	    	$scope.list.getTablesList($scope.list.sourceType,$scope.list.selectedAudience.audienceId);
		}
		return d.promise;
	}
	
	$scope.list.selectedRow  = 0;
	$scope.list.mapListData = function(){
		var columnList = [];
		var mappingList = [];
		if($scope.list.sourceType == 'F' && $scope.list.selectedSource && $scope.list.selectedSource.fileMapping && $scope.list.selectedSource.fileMapping.columnDefinitionList){
			columnList = $scope.list.selectedSource.fileMapping.columnDefinitionList;
			if(columnList){
				angular.forEach(columnList,function(obj){
					var mappingvo = {};
					mappingvo.columnName = obj.columnName;
					mappingvo.columnType = obj.columnType;
					mappingvo.defaultValue = obj.defaultValue;
					mappingvo.isNullable=obj.isNullable;
					mappingvo.length=obj.length;
					mappingvo.logicalColumnName=obj.logicalColumnName;
					mappingvo.useInList = 'Y';
					mappingvo.unsubscribe = obj.unsubscribe;
					mappingList.push(mappingvo);
				});
				
				$scope.list.dataMappingVo = mappingList;
				
			}
		}else if($scope.list.sourceType == 'T'){
			var temp = $.grep($scope.list.fileDefinitionList,function(obj){
				return obj.tableName == $scope.list.selectedSource;
			})[0];
			if(temp != undefined && temp.fileMapping && temp.fileMapping.columnDefinitionList){
				columnList = temp.fileMapping.columnDefinitionList;
			} 
			if(columnList){
				angular.forEach(columnList,function(obj){
					var mappingvo = {};
					mappingvo.columnName = obj.columnName;
					mappingvo.columnType = obj.columnType;
					mappingvo.defaultValue = obj.defaultValue;
					mappingvo.isNullable=obj.isNullable;
					mappingvo.length=obj.length;
					mappingvo.logicalColumnName=obj.logicalColumnName;
					mappingvo.useInList = 'Y';
					mappingvo.unsubscribe = obj.unsubscribe;
					mappingList.push(mappingvo);
				});
				
				$scope.list.dataMappingVo = mappingList;
			}
		}
		$scope.list.selectedMappingScreen='Data Mappings';
	}
	
	$scope.list.removeMappedColumn = function(index){
		$scope.list.dataMappingVo.splice(index,1);
	}
	
	$scope.list.headerAndDataRowValidation = function(type) 
	{   
		var headerMax = 10;
		var headerMin = 0;
		var value = undefined;
		if(type == 'H'){
			value = $scope.list.fileFormatSpec.headerRowAtLine;
		}else if(type == 'D'){
			value = $scope.list.fileFormatSpec.dataStartsFromLine;
		}
		if(isNaN(value) || value < 0){
			showInfoMessage("value should be numeric and not negative.");
			if(type == 'H'){
				$scope.list.fileFormatSpec.headerRowAtLine = undefined;
			}else if(type == 'D'){
				$scope.list.fileFormatSpec.dataStartsFromLine = undefined;
			}
			return;
		}
    	if(type == 'H' && value > headerMax-1) {
    		showInfoMessage("Maximum allowed value is 9.");
    		$scope.list.fileFormatSpec.headerRowAtLine = 9; 
    		return;
    	}
    	if(type == 'D' && value > headerMax) {
    		showInfoMessage("Maximum allowed value is 10.");
    		$scope.list.fileFormatSpec.dataStartsFromLine = 10; 
    		return;
    	}
    	if(!isNaN(parseInt($scope.list.fileFormatSpec.headerRowAtLine)) && !isNaN(parseInt($scope.list.fileFormatSpec.dataStartsFromLine))  && $scope.list.fileFormatSpec.headerRowAtLine >= $scope.list.fileFormatSpec.dataStartsFromLine){
    		showInfoMessage("Data starts from value should be greater than header starts from value.");
    		$scope.list.fileFormatSpec.dataStartsFromLine = parseInt($scope.list.fileFormatSpec.headerRowAtLine)+1; 
    		return;
    	}
    };
	$scope.list.getTablesList = function(sourceType,audienceID){
		fileDefinitionService.getAllTablesAndFiles(sourceType,audienceID).success(function(result){
			$scope.list.tablesList = [];
			//$scope.list.dataMappingVo = [];
			angular.forEach(result,function(value){				
				if(sourceType == 'T'){
					if(value[1] != null){
						$scope.list.tablesList.push(value[1]);
					}
				}
				else{
					if(value[1] != null){
						$scope.list.tablesList.push(value[1]);
					}
				}
			});
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	}
	
	$scope.list.fileDefinitionFilesList = function(fdId){
		listService.getFilesListOfFileDefinition(fdId).success(function(result){
			$scope.list.fdFilesList = result;
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	}
	
    $scope.list.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = 'unexpected error occured';
    	}
    	return msg;
    }
    
    $scope.list.saveListForFd = function(){
    	var listvo = {};
    	listvo.listID = $scope.list.listID;
    	listvo.name = $scope.list.name;
    	listvo.deptID = zhapp.loginUser.departmentID;
    	listvo.status = 'C';
    	listvo.createdBy = zhapp.loginUser.userName;
    	listvo.updatedBy = zhapp.loginUser.userName;
    	listvo.listType = $scope.list.selectedListTypeForFd;
    	if($scope.list.sourceType == 'F' && $scope.list.selectedSource){
    		listvo.fileDefinitionID  = $scope.list.selectedSource.fileDefinitionID;
    	}else if($scope.list.sourceType == 'T' && $scope.list.selectedSource){
    		listvo.tableName = $scope.list.selectedSource;
    	}
    	if($scope.list.selectedAudience){
    		listvo.audienceID = $scope.list.selectedAudience.audienceId;
    	}
    	
    	if($scope.list.selectedListTypeForFd == 'R' || $scope.list.selectedListTypeForFd == 'U'){
    		listvo.channelType = $scope.list.channelType;
    	}
    	listvo.sourceType = $scope.list.sourceType;
    	if($scope.list.selectedFolder){
    		listvo.folderID = $scope.list.selectedFolder.folderid;
    	}
    	if($scope.list.selectedCategory){
    		listvo.categoryID = $scope.list.selectedCategory.categoryid;
    	}
    	//listvo.status = 'W'
    	listvo.columnDefinitionList = $scope.list.dataMappingVo;
    	listvo.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
    	listvo.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');
    	listService.saveListDefinition(listvo).success(function(result){
//    		$scope.list.listID = result.listID;
    		$scope.fdobjnotifications=undefined;
    		$scope.list.listTemplate = 'list/templates/listoflists.html';
        	$scope.list.initializeList();
    	}).error(function(error){
    		showErrorMessage($scope.list.getErrorMessages(error));
    	});
    	
    }
    
    $scope.list.listLists = function(listcriteria){
    	var d = $q.defer();
//    	var listcriteria = {};
    	listcriteria.departmentID = zhapp.loginUser.departmentID;
    	listService.listAdhocLists(listcriteria).success(function(result){
    		angular.forEach(result.result,function(list){
    			var selected = $.grep($scope.list.audienceList,function(obj){return obj.audienceId == list.audienceID})[0];
    			if(selected != undefined)
    				list.audienceName = selected.audienceName;
    		});
    		$scope.list.adhocList = result.result;
    		if($scope.list.adhocList == 0){
				$scope.infoMessage = "No lists Available"; 
			}
    		if(result.result[0])$scope.list.totalRecords = result.totalRecords;		
			else $scope.list.totalRecords=-1;
    		d.resolve();
    	}).error(function(error){
    		showErrorMessage($scope.list.getErrorMessages(error));
    		d.reject();
    	});
    	return d.promise;
    }
    
    $scope.list.foldersList = $scope.list.getFoldersList();
    $scope.list.categoriesList = $scope.list.getCategoriesList();
	$scope.list.folderName = function(aid){
    	var obj = $.grep($scope.list.foldersList,function(data){
    		return (data.folderid == aid);
    	});
    	if(obj && obj.length > 0){
    		return obj[0].foldername;
    	}else{
    		return '--';
    	}
    }
	
	$scope.list.listTypeValue = function(key){
    	var obj = $.grep($scope.list.listTypeList,function(data){
    		return (data.key == key);
    	});
    	if(obj && obj.length > 0){
    		return obj[0].value;
    	}else{
    		return '--';
    	}
    }
	
	$scope.list.categoryName = function(aid){
    	var obj = $.grep($scope.list.categoriesList,function(data){
    		return (data.categoryid == aid);
    	});
    	if(obj && obj.length > 0){
    		return obj[0].categorycode;
    	}else{
    		return '--';
    	}
    }
    
    $scope.list.getAudienceName = function(aid){
    	var obj = $.grep($scope.list.audienceList,function(data){
    		return (data.audienceId == aid);
    	});
    	if(obj && obj.length > 0){
    		return obj[0].audienceName;
    	}else{
    		return 'None';
    	}
    }
    
    $scope.list.initializeList = function(){
    	$scope.list.selctedFdForClone = undefined;
    	var promise = $scope.getDeptSpecListAudinces();
    	promise.then(function(){
    		if(zhapp.folderAndCategoryContainer.list.folderId=="ALL"){
        		$scope.leftmenu.foldSelected ='Select All';
    			$scope.list.searchCriteria.folderid = undefined;
    		}else{
    			$scope.leftmenu.foldSelected =zhapp.folderAndCategoryContainer.list.folderId; 
    			$scope.list.searchCriteria.folderid = zhapp.folderAndCategoryContainer.list.folderId; 
    		}
    		if(zhapp.folderAndCategoryContainer.list.categoryId=="ALL"){
        		$scope.leftmenu.categorySelected = "Select All";
        		$scope.list.searchCriteria.categoryid = undefined;

        	}else{
        			$scope.leftmenu.categorySelected = zhapp.folderAndCategoryContainer.list.categoryId;
        			$scope.list.searchCriteria.categoryid = zhapp.folderAndCategoryContainer.list.categoryId;
        	}
    		var promiseLists = $scope.list.listLists($scope.list.searchCriteria);
    		promiseLists.then(function(){
    		});
    	});
    }
    $scope.list.initializeNotifiedList = function(searchCriteria){
    	$scope.list.selctedFdForClone = undefined;
    	var promise = $scope.list.getAudienceList();
    	promise.then(function(){
    		listService.listAdhocLists(searchCriteria).success(function(result){
        		angular.forEach(result.result,function(list){
        			var selected = $.grep($scope.list.audienceList,function(obj){return obj.audienceId == list.audienceID})[0];
        			if(selected != undefined)
        				list.audienceName = selected.audienceName;
        		});
        		$scope.list.adhocList = result.result;
        		if($scope.list.adhocList == 0){
    				$scope.infoMessage = "No lists Available"; 
    			}
        		if(result.result[0])$scope.list.totalRecords = result.totalRecords;		
    			else $scope.list.totalRecords=-1;
        		if($scope.list.adhocList && $scope.list.adhocList.length > 0){
    				$scope.list.openListSummaryDialog($scope.list.adhocList[0]);
    			}
        	}).error(function(error){
        		showErrorMessage($scope.list.getErrorMessages(error));
        	});
    	});
    }
    
    function getListIdByFiledefinitionId(id,departmentId){
    	var d = $q.defer();
    	var search = {};
    	search.departmentID = departmentId;
    	search.filedefinitionid = id;
    	listService.listAdhocLists(search).success(function(result){
			if(result.result && result.result.length > 0){
				d.resolve(result.result[0]);
			}else{
				d.reject();
			}
		}).error(function(error){
			d.reject();
		});
    	return d.promise;
    }
    
    if(sessionStorage.getItem('queryParams')){
    	$scope.list.listTemplate = 'list/templates/listoflists.html';
    	var id = JSON.parse(sessionStorage.getItem('queryParams')).value;
    	var departmentId = JSON.parse(sessionStorage.getItem('queryParams')).departmentId;
    	sessionStorage.removeItem('queryParams');
    	var promise = getListIdByFiledefinitionId(id,departmentId);
    	promise.then(function(res){
    		var search = {};
        	search.listid = res.listID;
        	search.departmentID = departmentId;
        	$scope.list.initializeNotifiedList(search);
    	});
    }else{
    	$scope.list.listTemplate = 'list/templates/listoflists.html';
    	$scope.list.initializeList();
    }
    $scope.list.editListForFd = function(list){
    	$scope.list.dataMappingVo = [];
    	var promise = [];
    	$scope.list.listID = list.listID;
		$scope.list.name = list.name;
		$scope.list.selectedListTypeForFd = list.listType;
		$scope.list.sourceType = list.sourceType;
    	$scope.list.selectedAudience = $.grep($scope.list.audienceList,function(obj){return obj.audienceId == list.audienceID})[0];
		promise.push($scope.list.getFoldersList());
		promise.push($scope.list.getCategoriesList());
		promise.push($scope.list.getFildefinitionListForFd());
		$q.all(promise).then(function(data){
			prePareEditListVO(list);
			$scope.list.listTemplate = 'list/templates/neworeditlist.html';
		});
    }
    
    function prePareEditListVO(list){
		
		$scope.list.selectedFolder = $.grep($scope.list.foldersList,function(obj){return obj.folderid == list.folderID})[0];
		$scope.list.selectedCategory = $.grep($scope.list.categoriesList,function(obj){return obj.categoryid == list.categoryID})[0];
		if($scope.list.sourceType == 'F'){
			$scope.list.selectedSource = $.grep($scope.list.fileDefinitionList,function(obj){
				return obj.fileDefinitionID == list.fileDefinitionID;
				})[0];
			$scope.list.dataMappingVo = list.columnDefinitionList;
			//$scope.list.mapListData();
		}else if($scope.list.sourceType == 'T'){
			$scope.list.selectedSource =list.tableName;
			$scope.list.fileDefinitionID=list.fileDefinitionID;
			$scope.list.dataMappingVo = list.columnDefinitionList;
			//$scope.list.mapListData();
		}
    }
    
    $scope.list.navigateBack = function(){
    	showCommonConfirmMessage("Do you want to save changes?","Confirm","Yes","No",450,function(value){
			if(value == false){
				$scope.list.listTemplate = 'list/templates/listoflists.html';
		    	$scope.list.initializeList();
			}else{
				$scope.list.saveList();
			}
		});
    }
    
    $scope.list.createFromChange = function(){
    	if($scope.list.createFrom == 'R'){
			$scope.list.getHostList();
		}else if($scope.list.createFrom == 'B'){
			$scope.list.getDbSorceList();
		}
    	if($scope.list.createFrom != 'R'){
    		$scope.list.useEncryption = 'N';
    		$scope.list.encryptionKey = undefined;
    	}
    	$scope.list.uploadFileName = undefined;
		$scope.list.fdMappingVOList = [];
		$scope.list.nullValueRepresentation = $scope.list.nullValue[0].key;
		$scope.list.emailSmsDefaultValues();
    }
    
    $scope.list.getFildefinitionList = function(){
    	if($scope.list.type == 'A'){
    		$scope.list.getAudienceColumns($scope.list.selectedAudience);
    		$scope.list.fdMappingVOList = [];
    	}
    }
    
    $scope.list.intializeActions = function(){
		$("#filedefuploadBtn").change(function(){
			$scope.$apply(function(){
				$scope.list.uploadFileName = $("#filedefuploadBtn").val();
				if(filedefuploadBtn.files[0] != undefined)
					$scope.list.uploadFileName = filedefuploadBtn.files[0].name;
			}); 
			
		});
	}
    
    $scope.list.getHostList = function(){
    	var d = $q.defer();
		var listCriteria = {};
		fileDefinitionService.getHostList(listCriteria).success(function(result){
			$scope.list.remote.hostList = result;
			if($scope.list.remote.hostList && $scope.list.remote.hostList.length == 0){
				showErrorMessage("No remote hosts created yet.");
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
    }
    
    $scope.list.getDbSorceList = function(){
    	var d = $q.defer();
		fileDefinitionService.getDbSourceList().success(function(result){
			$scope.list.db.sourceList = result;
			if($scope.list.db.sourceList && $scope.list.db.sourceList.length == 0){
				showErrorMessage("No remote db sources created yet.")
			}
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
    }
    
    $scope.list.changeHostServer = function(){
    	$scope.list.remote.currentFolderselected = '/';
    	$scope.list.remote.currentFolderselectedFile = '/';
		$scope.list.fdMappingVOList = [];
		$scope.list.remote.remoteFolderList = undefined;
		
    }
    
    $scope.list.getFoldersForRemoteServer = function(){
    	if(!$scope.list.remote.currentFolderselected)return;
    	var isValidPath=$scope.list.checkValidPath()
    	if (!isValidPath){
			showErrorMessage("Path should not contain double slash'//' ");
			return;
		}
    	if($scope.list.remote.hostServer.protocol == "http" || $scope.list.remote.hostServer.protocol == "https")return;
    	var d = $q.defer();
		var list = [];
		fileDefinitionService.getFoldersFromRemoteServer($scope.list.remote.hostServer.fileSourceName,false,$scope.list.remote.currentFolderselected).success(function(result){
			$scope.list.remote.remoteFolderList = result;
			$scope.list.remote.currentFolder = $scope.list.remote.currentFolderselected;
			d.resolve();
		}).error(function(error){
			$scope.list.remote.currentFolder = undefined;
			if(error.errors[0].message.startsWith("FL0067 : Loading")){
				showErrorMessage("Loading the files list has failed due to an invalid file/directory. Check the input file path and permissions.");
			}else
				showErrorMessage($scope.fd.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
    }
    $scope.list.checkValidPath = function(){
    	var flag=true;
    	var path=$scope.list.remote.currentFolderselected
    	var pattern= new RegExp(/\/\//);
    	if((path.search(pattern))>-1){
    		flag =false;
    		return flag;
    	}
    	return flag;
    }
    $scope.list.selectFolder = function(folderName){
    	if($scope.list.remote.currentFolder.lastIndexOf('/') == $scope.list.remote.currentFolder.length-1){
    		if(folderName.lastIndexOf('.') != -1){
				$scope.list.remote.currentFolderselectedFile = $scope.list.remote.currentFolder+folderName;
			}else{
				$scope.list.remote.currentFolderselected = $scope.list.remote.currentFolder+folderName;
				$scope.list.remote.currentFolderselectedFile = $scope.list.remote.currentFolder+folderName;
			}
		}else{
			if(folderName.lastIndexOf('.') != -1){
				$scope.list.remote.currentFolderselectedFile = $scope.list.remote.currentFolder+"/"+folderName;
			}else{
				$scope.list.remote.currentFolderselected = $scope.list.remote.currentFolder+"/"+folderName;
				$scope.list.remote.currentFolderselectedFile = $scope.list.remote.currentFolder+"/"+folderName;
			}
		}
    	$('#remotelistlist li').each(function(){
		    if($(this).text() === folderName)
		    	$(this).css("background-color","#d6e1e6");
		    else
		    	$(this).css("background-color","");
		});
    }
    
    $scope.list.showDbTables = function(){
    	var d = $q.defer();
		if($scope.list.db.dbSource == null || $scope.list.db.dbSource == undefined){
			alert("select source");
		}
		fileDefinitionService.getDbTablesList($scope.list.db.dbSource.dbSourceName).success(function(result){
			$scope.list.db.tablesList = result;
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
    }
    
    $scope.list.getSelectQuery = function(tableName){
    	$scope.list.selectedTableName = tableName;
		fileDefinitionService.getSelectQuery($scope.list.db.dbSource.dbSourceName,tableName).success(function(result){
			$scope.list.dbSelectQuery = result.query;
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
    }
    
    $scope.list.executeSelectQuery = function(type){
    	var d = $q.defer();
		fileDefinitionService.executeSelectQuery($scope.list.db.dbSource.dbSourceName,$scope.list.dbSelectQuery).success(function(result){
			if(type == 'S'){
				$scope.list.dbSelectSampleQueryData = result;
				$(".filedef-remotedb-sample-popup").dialog('open');
			}else if(type == 'E'){
				if($scope.list.selectedAudience == undefined){
					showErrorMessage("Please Select Audience");
					return;
				}
				$scope.list.dbSelectQueryData = result;
				prepareMappingDataForDbSource(result);
			}
			$scope.list.selectedMappingScreen ='Data Mappings';
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
    }
    
    $scope.list.fetchTableSchema = function(){
    	if($scope.list.selectedTableName !=undefined ){
		fileDefinitionService.getTableSchema($scope.list.db.dbSource.dbSourceName,$scope.list.selectedTableName).success(function(result){
			$scope.list.tablePropertiesList = result;
			$(".filedef-remotedb-popup").dialog('open');
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
    	}else{
			showErrorMessage("Select Table Name !!!")
		}
	}
    
    function prepareMappingDataForDbSource(data){
		$scope.list.fdMappingVOList = [];
		var temp = [];
		angular.forEach(data,function(obj,index){
			if(index == 0){
				angular.forEach(obj,function(childObj){
					var res = {};
					res.key = childObj;
					temp.push(res);
				});
			}
		});
		var data1 = data.slice(1,data.length);
		angular.forEach(data1,function(obj,index){
			angular.forEach(obj,function(childObj,index2){
				var res = temp[index2];
				if(res && res.values){
					res.values.push(childObj);
				}else{
					var values = [];
					values.push(childObj);
					res.values = values;
				}
			});
		});
		$.each(temp,function(index,value){
			fileDefMappingVO = {};
			fileDefMappingVO.header = value.key;
			fileDefMappingVO.sampleDataColumns = value.values;
			fileDefMappingVO.sampleDataColumn = value.values[0];
			fileDefMappingVO.dataTypeList = $scope.list.dataTypes;
			fileDefMappingVO.length = 400;
			fileDefMappingVO.isNullable = 'N';
			if($scope.list.audienceColumns != undefined){
				fileDefMappingVO.audienceColumn = $.grep($scope.list.audienceColumns,function(obj){
					return obj.logicalColumnName == 'Omit';
				})[0];
			}
			$scope.list.fdMappingVOList.push(fileDefMappingVO);
		});
		mapDefaultColumnsData();
	}
	
    $scope.browseFile = function(){
        $("#filedefuploadBtn").trigger('click');
	}
    
    
    $scope.list.uploadOnNextClick = function(){
    	if(filedefuploadBtn.files[0] == undefined){
    		showErrorMessage("Please select the file to upload");
    		return;
    	}
    	var fileExt = filedefuploadBtn.files[0].name.substr(filedefuploadBtn.files[0].name.lastIndexOf('.') + 1);
    	if(!(fileExt == "txt" || fileExt == "csv")){
    		showErrorMessage("Please select txt or csv file");
    		return;
    	}
    	if($scope.list.fileFormatSpec.delimiter == undefined){
    		showErrorMessage("Please select the File delimiter");
    		return;
    	}
    	if($scope.list.fileFormatSpec.textQualifier == undefined){
    		showErrorMessage("Please select the Text qualifier");
    		return;
    	}
    	if($scope.list.selectedAudience == undefined){
    		showErrorMessage("Please select the Audience");
    		return;
    	}
    	
    	if( isNaN(parseInt($scope.list.fileFormatSpec.headerRowAtLine )) || $scope.list.fileFormatSpec.headerRowAtLine < 0 ){
    		showErrorMessage("Provide header row value.");
    		return;
    	}
		if( isNaN(parseInt($scope.list.fileFormatSpec.dataStartsFromLine)) || $scope.list.fileFormatSpec.dataStartsFromLine < 0){
    		showErrorMessage("Provide data starts row value.");
    		return;
    	}
    	if( $scope.list.fileFormatSpec.headerRowAtLine >= $scope.list.fileFormatSpec.dataStartsFromLine ){
    		showErrorMessage("Header row value can not be greater than or equal to data row value.");
    		return;
    	}
    	var hubListForData = new FormData();
        hubListForData.append("file", filedefuploadBtn.files[0]);
        hubListForData.append("headerStart", $scope.list.fileFormatSpec.headerRowAtLine);
        hubListForData.append("dataStart", $scope.list.fileFormatSpec.dataStartsFromLine);
        hubListForData.append("delimiter", $scope.list.fileFormatSpec.delimiter);
        hubListForData.append("textQualifier", $scope.list.fileFormatSpec.textQualifier);
        fileDefinitionService.uploadFileContent(hubListForData,$scope.list.fileFormatSpec.headerRowAtLine,$scope.list.fileFormatSpec.dataStartsFromLine,$scope.list.fileFormatSpec.delimiter).success(function(result){
        	if(result == null || result == undefined){
        		showErrorMessage("File is empty.");
        		return;
        	}
        	$scope.list.isFileUploaded = true;
        	$scope.list.fdMappingVOList = [];
    		$.each(result,function(index,value){
    			fileDefMappingVO = {};
    			fileDefMappingVO.header = value.key.replace(/ /g, '');
    			fileDefMappingVO.sampleDataColumns = value.values;
    			fileDefMappingVO.sampleDataColumn = value.values[0];
    			fileDefMappingVO.dataTypeList = $scope.list.dataTypes;
    			fileDefMappingVO.length = 400;
    			fileDefMappingVO.isNullable = 'N';
    			if($scope.list.audienceColumns != undefined){
	    			fileDefMappingVO.audienceColumn = $.grep($scope.list.audienceColumns,function(obj){
	    				return obj.logicalColumnName == 'Omit';
	    			})[0];
    			}
    			$scope.list.fdMappingVOList.push(fileDefMappingVO);
    		});
    		mapDefaultColumnsData();
    		$scope.list.selectedMappingScreen ='Data Mappings';
        }).error(function(error){
        	showErrorMessage($scope.list.getErrorMessages(error));
        });
    }
    
    function mapDefaultColumnsData(){
		angular.forEach($scope.list.fdMappingVOList,function(obj){
			angular.forEach($scope.list.audienceColumns,function(aobj){
				if(obj.header.toUpperCase() == aobj.logicalColumnName.toUpperCase() || (aobj.physicalColumnName != null && obj.header.toUpperCase() == aobj.physicalColumnName.toUpperCase())){
					if(aobj.physicalColumnName == "EMAIL_ADDRESS"){
						if($scope.list.selectedAudience != undefined && $scope.list.selectedAudience.audienceName == 'Email Address Audience'){
							obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == 7})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.addressType = $scope.list.emailAddressType[0];
							obj.disableSelect = true;
							obj.addressTypeDisable = true;
						}else{
							obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == aobj.columnDataType})[0];
							obj.enableEmailAddress = true;
							obj.enableSmsAddress = false;
							obj.addressType = $scope.list.emailAddressType[0];
							obj.disableSelect = true;
							obj.addressTypeDisable = true;
						}
					}else if(aobj.physicalColumnName == "SMS_NUMBER"){
						if($scope.list.selectedAudience != undefined && $scope.list.selectedAudience.audienceName == 'Sms Audience'){
							obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == 8})[0];
							obj.enableEmailAddress = false;
							obj.enableSmsAddress = true;
							obj.smsAddressType = $scope.list.smsAddressType[0];
							obj.disableSelect = true;
							obj.addressTypeDisable = true;
						}else{
							obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == aobj.columnDataType})[0];
							obj.enableEmailAddress = false;
							obj.enableSmsAddress = true;
							obj.smsAddressType = $scope.list.smsAddressType[0];
							obj.disableSelect = true;
							obj.addressTypeDisable = true;
						}
					}else{
						obj.dataType = ($.grep($scope.list.dataTypes,function(dataObj){return dataObj.key == aobj.columnDataType}))[0];
						obj.enableEmailAddress = false;
						obj.enableSmsAddress = false;
					}
					obj.audienceColumn = aobj;
					obj.disableSelect = true;
					obj.length = aobj.length;
					obj.disableLength = true;
					obj.defaultValue = aobj.defaultValue;
					obj.isNullable = aobj.isNullable;
					if(aobj.isKeyColumn == 'Y'){
						obj.disableAudience = true;
					}
				}
			});
			
		});
		if($scope.editfilemapping && $scope.editfilemapping.length > 0&& $scope.list.isEditMode == 'Y'){
			angular.forEach($scope.list.fdMappingVOList,function(mapping){
				angular.forEach($scope.editfilemapping,function(obj){
					if(obj.columnName ==  mapping.header){
						mapping.audienceColumn = $.grep($scope.list.audienceColumns,function(object){
							if(obj.isCustomColumn == 'Y'){return 'Is Custom' == object.logicalColumnName;}
							else{return obj.logicalColumnName == object.logicalColumnName;}
						})[0];
						
						mapping.dataType = $.grep($scope.list.dataTypes,function(object){return obj.columnType == object.value})[0];
						if(mapping.audienceColumn && mapping.audienceColumn.logicalColumnName != 'Omit' && mapping.audienceColumn.logicalColumnName != 'Is Custom')mapping.disableSelect = true;
						if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == "EMAIL_ADDRESS"){
							mapping.enableEmailAddress = true;
							mapping.enableSmsAddress = false;
							mapping.addressType = $.grep($scope.list.emailAddressType,function(obj1){
								return obj1[0] == obj.addressType
							})[0];
							mapping.disableSelect = true;
							mapping.addressTypeDisable = true;
						}else if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == "SMS_NUMBER"){
							mapping.enableSmsAddress  = true;
							mapping.enableEmailAddress = false;
							mapping.smsAddressType = $.grep($scope.list.smsAddressType,function(obj1){
								return obj1[0] == obj.addressType
							})[0];
							mapping.disableSelect = true;
							mapping.addressTypeDisable = true;
						}else{
							if(mapping.audienceColumn && mapping.audienceColumn.physicalColumnName == 'custom'){
								if(mapping.dataType.value == 'EMAIL'){
									mapping.enableEmailAddress = true;
									mapping.enableSmsAddress = false;
									mapping.addressType = $.grep($scope.list.emailAddressType,function(obj1){
										return obj1[0] == obj.addressType
									})[0];
								}else if(mapping.dataType.value == 'SMS'){
									mapping.enableSmsAddress  = true;
									mapping.enableEmailAddress = false;
									mapping.smsAddressType = $.grep($scope.list.smsAddressType,function(obj1){
										return obj1[0] == obj.addressType
									})[0];
								}
							}
						}
					}
				});
			});
		}
		$scope.$evalAsync(function(){
			$scope.list.fdMappingVOList = $scope.list.fdMappingVOList;
		});
		
	}
    
    $scope.list.getAudienceColumns = function(audience,fdobj){
		var d = $q.defer();
		fileDefinitionService.getAudienceColumns(audience.audienceId).success(function(result){
			if(result != null && result != undefined && result.length > 0){
				$scope.list.audienceColumns = result;
			}else{
				showErrorMessage("no audience columns exists");
			}
			angular.forEach($scope.list.audienceColumns,function(obj){
				obj.CustomType ='Audience';
			});
			var obj = {};
			obj.logicalColumnName='Omit';
			obj.physicalColumnName=null;
			obj.isProfilable=null;
			obj.columnDataType = null;
			obj.isKeyColumn=null;
			obj.CustomType ='Audience';
			$scope.list.audienceColumns.push(obj);
			obj = {};
			obj.logicalColumnName="Is Custom";
			obj.physicalColumnName="custom";
			obj.isProfilable='N';
			obj.columnDataType = 0;
			obj.isKeyColumn='N';
			obj.CustomType ='custom';
			$scope.list.audienceColumns.push(obj);
			addCustomAudienceForEdit(fdobj,d);
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
			d.reject();
		});
		return d.promise;
	}
    
    function getVerticaDbTableColumns(tableName){
		var d = $q.defer();
		fileDefinitionService.getVerticaDbTableColumns(tableName).success(function(result){
			d.resolve(result);
		}).error(function(error){
			d.reject();
		});
		return d.promise;
	}
	
	function prepareCustomAudienceForEdit(data){
		if($scope.list.audienceColumns){
			var finalData = [];
			angular.forEach(data,function(obj){
				var finalAud = $scope.list.audienceColumns.slice(0,$scope.list.audienceColumns.length-2);
				var available = false;
				angular.forEach(finalAud,function(aud){
					if(!available && (obj.isNullable == 'N') && aud.physicalColumnName && (obj.physicalColumnName != aud.physicalColumnName) && (obj.physicalColumnName != 'AUDIENCE_MEMBER_ID') && (obj.physicalColumnName != 'ISNEW_2')){
						var bo = $.grep($scope.editfilemapping,function(editBo){return editBo.isCustomColumn == 'Y' && editBo.physicalColumnName.toUpperCase() == obj.physicalColumnName.toUpperCase();});
						if(bo && bo.length > 0){available = true;finalData.push(bo[0]);}
					}
				});
			});
			if(finalData && finalData.length > 0){
				angular.forEach(finalData,function(obj){
					var res = {};
					res.logicalColumnName=obj.logicalColumnName;
					res.physicalColumnName=obj.physicalColumnName;
					res.isProfilable='N';
					var column = $.grep($scope.list.dataTypes,function(val1){return val1.value == obj.columnType})[0];
					if(column)
						res.columnDataType = column.key;
					else
						res.columnDataType = 0;
					res.dataType = column;
					res.isKeyColumn='N';
					res.CustomType ='custom';
					res.isUsed = true;
					$scope.list.audienceColumns.push(res);
				});
			}
		}
	}
	
	function addCustomAudienceForEdit(fdobj,d){
		if($scope.list.isEditMode == 'Y' && fdobj.status && $scope.tableName && $scope.tableName != '' && (fdobj.status== 'E' || fdobj.status== 'C')){
			var promise  = getVerticaDbTableColumns($scope.tableName);
			promise.then(function(data){
				if(data && data.length > 0)
					prepareCustomAudienceForEdit(data);
				d.resolve();
			});
		}else{
			d.resolve();
		}
	}
    
    $scope.list.addField = function(){
    	if(!$scope.list.isFileUploaded && $scope.list.createFrom == 'D'){
    		showErrorMessage('Upload File.');
    		return;
    	}
    	var filedefmappingvo = {};
    	filedefmappingvo.header = 'column_'+$scope.list.fdMappingVOList.length;
    	filedefmappingvo.isnullable = 'Y';
    	filedefmappingvo.defaultValue = undefined; 
    	filedefmappingvo.length = 400;
    	if($scope.list.selectedAudience && $scope.list.selectedAudience.audienceType != 0){
			var list = $.grep($scope.list.dataTypes,function(data){
				return (data.value != 'EMAIL' && data.value != 'SMS');
			});
			filedefmappingvo.dataTypeList = list;
		}else{
			filedefmappingvo.dataTypeList = $scope.list.dataTypes;
		}
    	filedefmappingvo.sampleDataColumns = [];
    	$scope.list.fdMappingVOList.push(filedefmappingvo);
    }
    
    $scope.list.removeMappingcolumn = function(index){
		if($scope.list.fdMappingVOList.length > 1){
			$scope.list.fdMappingVOList.splice(index,1);
		}else{
			showErrorMessage("Atleast one column should be configured");
		}
		
	}
    
    
    /* Query Builder Start*/
	
	$scope.list.onQueryBuilderButtonClick = function(){
		$scope.list.valueAndJoin = 'Value';
		$scope.list.ascDescSelected = "ASC";
		$scope.list.whereAndOrSelected = 'AND';
		$scope.list.orderByValueChecked = false;
		fileDefinitionService.getDbTablesList($scope.list.db.dbSource.dbSourceName).success(function(result){
			$scope.queryBuilderTables = result;
			$(".queryBuilderPopup").dialog('open');
			clearFieldsQB();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	};
	
	
	$scope.list.getSelectedTableName = function(tableName){ 
		$scope.list.preparedQuery="";
		$scope.queryBuilderTableColname = "";
		$scope.queryBuilderTablename = tableName.toString();
		
		/*tableColsArray = ["customerid", "VARCHAR", "128", null, "NO", "NON-UNIQUE"]*/
		return fileDefinitionService.getTableSchema($scope.list.db.dbSource.dbSourceName,$scope.queryBuilderTablename).success(function(result){
			$scope.queryBuilderColoums = [];
			$scope.columnObjects = [];
			$scope.queryBuild = [];
			$.each( result, function( tableNameDetails, tableColsArray ) {
				/*for(var i=0;i<tableColsArray.length;i++){*/
					$scope.queryBuilderColoums.push(tableName+"."+tableColsArray[0]);
					$scope.columnObjects.push(tableColsArray[1]);
				/*}*/
			});
			
			if($scope.columnObjects[0].type=='VARCHAR'){
				$scope.displayOperators = ['=', '!=', 'like'];
			}else{
				$scope.displayOperators = ['=', '!=', '<', '>', '<=', '>='];
			}
			
			$scope.queryBuild.whereCondColName=$scope.queryBuilderColoums[0];
			$scope.queryBuild.joinCondition=$scope.queryBuilderColoums[0];
			$scope.queryBuild.operator = $scope.displayOperators[0];
			addTitlesToSelectBox("qb-table-field option");
			
		});
		
		
		
	};
	
	$scope.list.setQueryBuilder = function(columnName){
		var select = "SELECT";
		var from = "FROM";
		var orderBy = "";
		$scope.queryBuilderTableColname = columnName.toString();
		$scope.list.preparedQuery = select +" "+$scope.queryBuilderTableColname +" "+ from +" "+$scope.queryBuilderTablename;
		$scope.queryBuild.whereCondColName = $scope.queryBuilderColoums[0];
		$scope.list.orderByVaueChecked();
	};
	
	
	$scope.list.orderByVaueChecked = function(){
		
		if(!$scope.list.orderByValueChecked){
			$scope.orderByQuery="";
			$scope.list.orderByColName="";
			if($scope.list.preparedQuery.indexOf("ORDER BY")>-1){
				var splitedQuery = $scope.list.preparedQuery.split('ORDER BY');
				var tempQuery = splitedQuery[0];
				$scope.list.preparedQuery =tempQuery+ $scope.orderByQuery;
				$scope.list.preparedQuery = ($scope.list.preparedQuery).replace(/ +(?= )/g,'');
			}
		}else{
			$scope.list.orderByColName = $scope.queryBuilderColoums[0];
			$scope.list.addSelectedTable($scope.queryBuilderColoums[0]);
		}
	};
	
	
	$scope.list.clearQueryBuilderFields = function() {
		clearFieldsQB();
	};
	
	$scope.list.addSelectedTable = function(tableCol){
		$scope.list.orderByColName = tableCol;
		if($scope.list.orderByColName){
			$scope.orderByQuery = " ORDER BY "+$scope.list.orderByColName + " "+ $scope.list.ascDescSelected;
			if($scope.list.preparedQuery.indexOf("ORDER BY")>-1){
				var splitedQuery = $scope.list.preparedQuery.split('ORDER BY');
				var tempQuery = splitedQuery[0];
				$scope.list.preparedQuery =tempQuery+ $scope.orderByQuery;
				$scope.list.preparedQuery = ($scope.list.preparedQuery).replace(/ +(?= )/g,'');
			}else{
				$scope.list.preparedQuery +=$scope.orderByQuery; 
				$scope.list.preparedQuery = ($scope.list.preparedQuery).replace(/ +(?= )/g,'');
			}
		}
		
	};
	
	
	$scope.list.onWhereAdd = function(){
		if($scope.list.modelValue || $scope.list.valueAndJoin=='Join' || $scope.list.valueAndJoin=='Dynamic'){
			if($scope.queryBuild.selColName){
				var partialQuery="";
				var whereClause="";
				var tempQuery = "";
				var modelValueLike = '';
				if($scope.list.valueAndJoin=='Value'){
					if($scope.queryBuild.operator=="like"){
						modelValueLike="'%"+$scope.list.modelValue+"%'";
					}else{
						modelValueLike = "'"+$scope.list.modelValue+"'";
					}
					tempQuery = $scope.queryBuild.whereCondColName + " " + $scope.queryBuild.operator + " " +modelValueLike;
				}else if($scope.list.valueAndJoin=='Join'){
					tempQuery = " "+$scope.queryBuild.whereCondColName+" = "+ $scope.queryBuild.joinCondition;
				}else if($scope.list.valueAndJoin=='Dynamic'){
					tempQuery = " "+$scope.queryBuild.whereCondColName+" = "+ $scope.queryBuild.dynamicCondition;
				}
				
				if($scope.list.preparedQuery.indexOf(" WHERE ") == -1){
					whereClause = " WHERE "+tempQuery;
				}else{
					whereClause = " "+$scope.list.whereAndOrSelected+" "+tempQuery;
				}
				if($scope.list.preparedQuery.indexOf(" ORDER BY ")>-1){
					partialQuery = whereClause;
					$scope.list.preparedQuery+=partialQuery;
					var OrderByPosition = $scope.list.preparedQuery.indexOf(" ORDER BY ");
					var partialString = $scope.list.preparedQuery.slice(OrderByPosition,$scope.list.preparedQuery.length);
					var initialQuery = $scope.list.preparedQuery.slice(0,OrderByPosition);
					var whereString = '';
					var andString = '';
					var orderByString = ''; 
					if(partialString.indexOf(" WHERE ") > -1){
						orderByString = partialString.slice(0,partialString.indexOf(" WHERE "));
						whereString= partialString.slice(partialString.indexOf(" WHERE "),partialString.length);
					}else{
						if(partialString.indexOf(" AND ") > -1){
							orderByString = partialString.slice(0,partialString.indexOf(" AND "));
							andString= partialString.slice(partialString.indexOf(" AND "),partialString.length);
						}
						if(partialString.indexOf(" OR ") > -1){
							orderByString = partialString.slice(0,partialString.indexOf(" OR "));
							andString= partialString.slice(partialString.indexOf(" OR "),partialString.length);
						}
					}
					$scope.list.preparedQuery = initialQuery+whereString+andString+orderByString ;
					$scope.list.preparedQuery = ($scope.list.preparedQuery).replace(/ +(?= )/g,'');
				}else{
					partialQuery = whereClause;
					$scope.list.preparedQuery += partialQuery;
					$scope.list.preparedQuery = ($scope.list.preparedQuery).replace(/ +(?= )/g,'');
				}
			}
		}
	};
	
	$scope.list.enableAddQueryBuild = function(){
		if($scope.list.modelValue || $scope.list.valueAndJoin=='Join' || $scope.list.valueAndJoin=='Dynamic'){
			if($scope.queryBuild.selColName){
				return false;
			}else{
				return true;
			}
		}else{
			return true;
		}
	};
	
	
	$scope.list.changeWhereValue = function(){
		$scope.list.enableAddQueryBuild();
		if($scope.list.valueAndJoin=='Join'){
			$scope.list.modelValue = '';
			$scope.list.modelValueDisable=true;
		}else if($scope.list.valueAndJoin=='Dynamic'){
			$scope.list.modelValue = '';
			$scope.list.modelValueDisable=true;
			$scope.queryBuild.dynamicCondition='#';
			$('#dynamicSqlQuery').val('#').trigger('liszt:updated'); 
		}else{
			$scope.list.modelValue = '';
			$scope.list.modelValueDisable=false;
		}
	};
	
	
	$scope.list.executeQueryBuild = function() {
		if($scope.list.preparedQuery!='' && $scope.list.preparedQuery!=null){
			$scope.list.isQBQueryExist = true;
			$scope.list.executeQuery($scope.list.preparedQuery,true);
		}
	};
	
	
	$scope.list.executeQuery = function(query,flag){
		if(!query || query.length==0){
			return;
		}
		$scope.list.queryRecords =[];
		if($scope.list.createListDBSourceVO!=undefined && $scope.list.createListDBSourceVO.profilemap!=undefined){
			$.each($scope.list.createListDBSourceVO.profilemap,function(index,value){
				$scope.list.createListDBSourceVO.profilemap[index]=undefined;
			});
		}
		if($scope.list.createListDBSourceVO!=undefined && $scope.list.createListDBSourceVO.columns!=undefined){
			$.each($scope.list.createListDBSourceVO.columns,function(index,value){
				$scope.list.createListDBSourceVO.columns[index]=undefined;
			});
		}
		if(checkForRestrictedKeyWords(query)){
			var defer=$q.defer();
			$scope.list.recordCount = null;
			if(query.length>0){
				$scope.list.selectedQuery = query;
				fileDefinitionService.executeSelectQuery($scope.list.db.dbSource.dbSourceName,query).error(function (data){
					showErrorMessage(data.error);
				}).success(function(data){
					$scope.list.queryRecords = data;
					defer.resolve();
					if(flag)
						$('.executeSQLQuery').dialog('open');
				});
			}
			return defer.promise;
		}
	};
	
	$scope.list.recordCountClick = function(){
			$scope.list.recordCount = $scope.list.queryRecords.length-1;
	};
	
	function checkForRestrictedKeyWords(query){
		var RESTRICTED  = ["insert into","update table","drop table","create table","alter table","delete from","truncate table","create database","drop database","drop index","create index","create sequence","drop sequence","create function","create procedure","drop procedure", "rename table"];
		var infractions = new Array();
		for ( var i=0;i<=RESTRICTED.length;i++)
		{
			var term  = RESTRICTED[i]+"";
			var contains = query.toLowerCase().split(term);
			if ( contains.length > 1 ){
				infractions.push(term);
				var regExp=new RegExp(term,"gi");
				query = query.replace(regExp, "");
			}
		}
		if ( infractions.length > 0 ) {
			showErrorMessage("The following restricted terms were removed from your text input:"+infractions.join(", "));
			return false;
		}else{
			return true;
		}
			
	}
	
	$scope.list.refreshQueryBuilder = function(){
		return fileDefinitionService.getDbTablesList($scope.list.db.dbSource.dbSourceName).success(function(result){
			$scope.queryBuilderTables = result;
			clearFieldsQB();
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	};
	
	$scope.list.exportQueryBuilder = function(){
		if($scope.list.preparedQuery && $scope.list.preparedQuery != '')
			$scope.list.dbSelectQuery = $scope.list.preparedQuery;
	}
	
	function clearFieldsQB(){
		$scope.list.orderByValueChecked = false;
		$scope.list.orderByColName = "";
		$scope.queryBuilderColoums = [];
		$scope.queryBuild = [];
		$scope.queryBuild.selTableName = "";
		$scope.queryBuild.selColName = "";
		$scope.queryBuild.whereCondColName = "";
		$scope.queryBuild.operator = "";
		$scope.queryBuild.joinCondition = "";
		$scope.queryBuild.orderBy = "";
		$scope.list.preparedQuery = "";
		$scope.list.whereAndOrSelected = "AND";
		$scope.list.ascDescSelected = "ASC";
		$scope.list.modelValue = "";
		$scope.list.valueAndJoin = "Value";
		$scope.list.isQBQueryExist = false;
		$scope.list.modelValueDisable=false;
		$scope.custIdInput="";
		$scope.emailAddInput="";
	}
	
	function addTitlesToSelectBox(id){
		setTimeout(function()  {
			var options = document.querySelectorAll("#"+id);
		    if (options) {
		        for (var i = 0; i < options.length; i++) {
		            options[i].title = options[i].textContent;
		        }
		    }
		},0);
	}
    
    $scope.list.mappingAudienceToDatType = function(index,audienceColumn){
		var obj = $scope.list.fdMappingVOList[index];
		obj.disableSelect = false;
		
		if($scope.list.selectedAudience.audienceType != 0 && obj.audienceColumn.CustomType == 'custom'){
			var list = $.grep(obj.dataTypeList,function(data){
				return (data.value != 'EMAIL' && data.value != 'SMS');
			});
			obj.dataTypeList = list;
		}else{
			obj.dataTypeList = $scope.list.dataTypes;
		}
		if(obj.audienceColumn.logicalColumnName =='Omit'){
			obj.enableEmailAddress = false;
			obj.enableSmsAddress = false;
			obj.dataType = undefined;
//			obj.disableSelect = true;
			return;
		}
		angular.forEach(obj.dataTypeList,function(data){
			if(data.key == obj.audienceColumn.columnDataType){
				if(obj.audienceColumn.physicalColumnName == "EMAIL_ADDRESS"){
					if($scope.list.selectedAudience != undefined && $scope.list.selectedAudience.audienceName == 'Email Address Audience'){
						obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == 7})[0];
						obj.enableEmailAddress = true;
						obj.enableSmsAddress = false;
						obj.disableSelect = true;
						obj.addressType = $scope.list.emailAddressType[0];
						obj.addressTypeDisable = true;
					}else{
						obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == obj.audienceColumn.columnDataType})[0];
						obj.enableEmailAddress = true;
						obj.enableSmsAddress = false;
						obj.disableSelect = true;
						obj.addressType = $scope.list.emailAddressType[0];
						obj.addressTypeDisable = true;
					}
				}else if(obj.audienceColumn.physicalColumnName == "SMS_NUMBER"){
					if($scope.list.selectedAudience != undefined && $scope.list.selectedAudience.audienceName == 'Sms Audience'){
						obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == 8})[0];
						obj.enableEmailAddress = false;
						obj.enableSmsAddress = true;
						obj.disableSelect = true;
						obj.smsAddressType = $scope.list.smsAddressType[0];
						obj.addressTypeDisable = true;
					}else{
						obj.dataType = $.grep(obj.dataTypeList,function(obj1){return obj1.key == obj.audienceColumn.columnDataType})[0];
						obj.enableEmailAddress = false;
						obj.enableSmsAddress = true;
						obj.disableSelect = true;
						obj.smsAddressType = $scope.list.smsAddressType[0];
						obj.addressTypeDisable = true;
					}
				}else{
					obj.enableEmailAddress = false;
					obj.enableSmsAddress = false;
					obj.dataType = data;
				}
				if(obj.audienceColumn.CustomType != 'custom' || obj.audienceColumn.isKeyColumn == 'Y'){
					obj.disableSelect = true;
				}
			}
		});
		if(audienceColumn.length){
			obj.length = audienceColumn.length;
		}
		obj.defaultValue = audienceColumn.defaultValue;
		obj.isNullable = audienceColumn.isNullable;
		$scope.list.fdMappingVOList[index] = obj;
	}
    
    $scope.list.changeAddressType = function(type,index){
		var obj = $scope.list.fdMappingVOList[index];
		obj.length = undefined;
		if(type.value == 'EMAIL'){
			obj.enableEmailAddress = true;
			obj.enableSmsAddress  = false;
			if($scope.list.emailAddressType[0])
				obj.addressType = $scope.list.emailAddressType[0];
			
		}else if(type.value == 'SMS'){
			obj.enableSmsAddress  = true;
			obj.enableEmailAddress = false;
			if($scope.list.smsAddressType[0])
				obj.smsAddressType = $scope.list.smsAddressType[0];
		}else{
			obj.enableSmsAddress  = false;
			obj.enableEmailAddress = false;
		}
		$scope.list.fdMappingVOList[index] = obj;
	}
    
    $scope.addNewFolder = function(){
        if($scope.list.showaddfolder)
              {
              var d = $q.defer();
              var folder={};
              folder.folderid=0;
              folder.departmentid=zhapp.loginUser.departmentID;
              folder.foldername=$scope.list.newfoldername;
              folder.type='A';//$scope.fldr.folderType;
              folder.parentfolderid=0;
              listService.saveFolder(folder).success(function(result){
                    $scope.list.selectedFolder = result;
                    $scope.list.foldersList.push(result);
                    d.resolve();
              }).error(function(responseObj){
                    showDepartmentErrorMessage(responseObj);
                    d.reject();
              });
              return d.promise;
              }
      }
    $scope.addNewCategory = function(){
    	if($scope.list.showcategory){
    		var d = $q.defer();
    		var category={};
    		category.categoryid=0;
    		category.departmentid=zhapp.loginUser.departmentID;
    		category.categorycode=$scope.list.newcategoryname;//$scope.cat.addCategoryName;
    		category.type='A';//$scope.cat.categoryType;
    		category.description="";//$scope.cat.addCategoryDescription;
    		departmentService.saveCategory(category).success(function(result){
    			$scope.list.selectedCategory = result;
    			$scope.list.categoriesList.push(result);
    			d.resolve();
    		}).error(function(responseObj){
    			showDepartmentErrorMessage(responseObj);
    			d.reject();
    		});
    		return d.promise;
    	}
    }
    $scope.addFolderAndCat = function(){
    	var d = $q.defer();
    	var promise = [];
        promise.push($scope.addNewFolder());
        promise.push($scope.addNewCategory());
        $q.all(promise).then(function(){
        	d.resolve();
        });
        return d.promise;
    }

    $scope.list.saveList = function(){
    	if($scope.list.type == 'F'){
    		$scope.list.saveListForFd();
    	}else if($scope.list.type == 'A'){
    		var promise = $scope.addFolderAndCat();
    		promise.then(function(){
            	var fdvo = $scope.list.saveFiledefinition();
        		if(fdvo == null)return;
            		var listvo = {};
            		if($scope.list.listID){
            			listvo.listID = $scope.list.listID;
            		}
//            		listvo.fileDefinitionID = fdvo.fileDefinitionID;
            		listvo.name = $scope.list.name;
            		listvo.listType = $scope.list.listType;
            		if($scope.list.selectedAudience){
                		listvo.audienceID = $scope.list.selectedAudience.audienceId;
                	}
                	if($scope.list.selectedFolder){
                		listvo.folderID = $scope.list.selectedFolder.folderid;
                	}
                	if($scope.list.selectedCategory){
                		listvo.categoryID = $scope.list.selectedCategory.categoryid;
                	}
            		//listvo.channelType =
            		//listvo.tableName =
            		listvo.deptID = zhapp.loginUser.departmentID;
            		if($scope.list.scheduleactivemode == 'Y'){
            			listvo.status = 'W';
            		}else if($scope.list.scheduleactivemode == 'N'){
            			listvo.status = 'P';
            		}
            		
            		listvo.sourceType = 'A';
            		listvo.createdBy = zhapp.loginUser.userName;
            		listvo.updatedBy = zhapp.loginUser.userName;
            		listvo.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
            		listvo.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');
            		//list.filter =
            		listvo.columnDefinitionList = fdvo.fileMapping.columnDefinitionList;//assign file definition list columndefinitionlist
            		var hubListForData = new FormData();
            		hubListForData.append("file", filedefuploadBtn.files[0]);
            		hubListForData.append("fileDefinitionBO", JSON.stringify(fdvo));
            		hubListForData.append("listDefinitionBO", JSON.stringify(listvo));
            		listService.saveFileAndListDefinition(hubListForData).success(function(result){
            			//$scope.list.listID = result.listID;
            			//
            			/*if(result.categoryID==0){
                	        zhapp.folderAndCategoryContainer.list.categoryId ="ALL";
						}else{
							zhapp.folderAndCategoryContainer.list.categoryId = result.categoryID;
						}
            			zhapp.folderAndCategoryContainer.list.folderId = result.folderID;*/
            			$scope.fdobjnotifications=undefined;
            			$scope.list.listTemplate = 'list/templates/listoflists.html';
            	    	$scope.list.initializeList();
                	}).error(function(error){
                    showErrorMessage($scope.list.getErrorMessages(error));	
              	            
                	});
                  
            });
    	}
    	
    }
    
    function hasDuplicateEmails(array) {
	    var valuesSoFar = [];
	    for (var i = 0; i < array.length; ++i) {
	        var value = array[i];
	        if (valuesSoFar.indexOf(value) !== -1) {
	            return true;
	        }
	        valuesSoFar.push(value);
	    }
	    return false;
	}
    
    $scope.list.saveFiledefinition = function(){
//    	var d = $q.defer();
    	var filedefvo = {};
    	var fileMappingVerificationErrorflag=false;
    	if($scope.list.fileDefinitionID){
    		filedefvo.fileDefinitionID = $scope.list.fileDefinitionID;
    	}
    	filedefvo.name = $scope.list.name;
    	if($scope.list.selectedAudience != undefined){
    		filedefvo.audienceID = $scope.list.selectedAudience.audienceId;
    	}
    	filedefvo.fileSource = prepareFileSourceSpecVO();
    	filedefvo.fileMapping = createFileMappingVO();
    	angular.forEach(filedefvo.fileMapping.columnDefinitionList,function(columnDefinition,upKey){
			angular.forEach(filedefvo.fileMapping.columnDefinitionList, function(columnDefinitionDown,downKey){
				if(upKey!=downKey && columnDefinitionDown.physicalColumnName==columnDefinition.physicalColumnName&& $scope.list.selectedAudience.audienceType!=0 && columnDefinitionDown.columnType!='Omit' ){
					if(columnDefinitionDown.columnType=='EMAIL' || columnDefinitionDown.columnType=='SMS' ){
						fileMappingVerificationErrorflag=true;
					}					 
				}
			});
		});
    	if(fileMappingVerificationErrorflag){
    		showErrorMessage("A column can be mapped only once.");
    		return;
    	}
    	if($scope.list.listType == 'G'){
    		if(filedefvo.fileMapping == undefined)return;
		}
    	filedefvo.fileFormatSpec = preparefileFormatSpecVO();
    	filedefvo.fileProcessingOptions = preparefileProcessingOptionsVO();
    	filedefvo.scheduleactivemode = $scope.list.scheduleactivemode;
    	if($scope.list.scheduleactivemode == 'Y') {
    		filedefvo.fileScheduleBO = prepareFileScheduleVoForSave();
    		if(filedefvo.fileScheduleBO == null){
    			return;
    		}
    	}else{
    		filedefvo.fileScheduleBO = {};
    	}
		filedefvo.departmentID = zhapp.loginUser.departmentID;
		filedefvo.fileAction = 'I';
		filedefvo.createdBy = zhapp.loginUser.userName;
		filedefvo.updatedBy = zhapp.loginUser.userName;
		filedefvo.sendWorkFlow = 'N';
		filedefvo.isFileTrigger = 'N';
		filedefvo.fileType = 'A';
		filedefvo.maxFiles = 1;
		filedefvo.tableDisposition = 'Append';
		if($scope.list.scheduleactivemode == 'Y' ){
			filedefvo.status = 'W';
		}
		else{
			filedefvo.status = 'B';
		}
		filedefvo.useEncryption =  $scope.list.useEncryption;
		if($scope.list.useEncryption == 'Y'){
			filedefvo.encryptionKey = $scope.list.encryptionKey;
		}else{
			filedefvo.encryptionKey = undefined;
		}
		filedefvo.timeZone = $scope.list.tz;
		
		if($scope.notifications.isEnabled){
			var flag = false;
			angular.forEach($scope.notifications.notificationStatuses,function(obj){
				if(!flag && obj.isEnabled){
					flag = true;
				}				
			});
			if(!flag){
				showErrorMessage("Please Select Atleast One Status");
				return;
			}
			if(validateEmailAddresses() == null){
				showErrorMessage("Please Enter Valid Comma Seperated Emails");
				return;
			}
			var emailArray = $scope.notifications.defaultEmailAddresses.split(',');
			if(emailArray && emailArray.length > 10){
				showErrorMessage("Common Recipients should be less than 10.");
				return;
			}
			if(hasDuplicateEmails(emailArray)){
				showErrorMessage("Duplicate Emails Exist");
				return;
			}
			flag = false;
			var isemaillengthexceed = false;
			angular.forEach($scope.notifications.notificationStatuses,function(notification){
				if(notification.isEnabled && !flag && notification.emailAddresses){
					emailArray =  notification.emailAddresses.split(',');
					if(!isemaillengthexceed && emailArray && emailArray.length > 10){
						isemaillengthexceed = true;
					}
					if(!flag && hasDuplicateEmails(emailArray)){
						flag = true;
					}
				}
			});
			if(isemaillengthexceed){
				showErrorMessage("	Selected Recipients should be less than 10.");
				return;
			}
			if(flag){
				showErrorMessage("Duplicate Emails Exist");
				return;
			}
			filedefvo.notifications = $scope.notifications;
		}else{
			filedefvo.notifications = $scope.notifications;
		}
		filedefvo.updateDate = zhapp.getCnvDateTime('DTS',null,'UTC');
		filedefvo.createDate = zhapp.getCnvDateTime('DTS',null,'UTC');
		if($scope.editfilemapping && $scope.editfilemapping.length > 0&& $scope.list.isEditMode == 'Y'){
			var exist = true;
			angular.forEach($scope.editfilemapping,function(obj){
				if(exist && obj.isCustomColumn == 'N'){
					var existLogicalName = $.grep($scope.list.fdMappingVOList,function(val){
						if(val.audienceColumn)
							return val.audienceColumn.physicalColumnName == obj.physicalColumnName && val.dataType.value == obj.columnType;
					})[0];
					if(!existLogicalName){
						exist = false;
						showErrorMessage("LogicalColumn "+obj.logicalColumnName+" should be mapped");
						return;
					}
				}
			});
			if(!exist){
				return;
			}
			exist = true;
			if($scope.list.audienceColumns){
				angular.forEach($scope.list.audienceColumns,function(obj){
					if(exist && obj.isUsed){
						var existLogicalName = $.grep($scope.list.fdMappingVOList,function(val){
							if(val.audienceColumn && val.audienceColumn.logicalColumnName == 'Is Custom' && val.dataType)
								return val.header == obj.logicalColumnName && val.dataType.key == obj.columnDataType;
							else if(val.audienceColumn && val.dataType)
								return val.audienceColumn.logicalColumnName == obj.logicalColumnName && val.dataType.key == obj.columnDataType;
						})[0];
						if(!existLogicalName){
							exist = false;
							showErrorMessage("Column "+obj.logicalColumnName+" should be mapped as "+($.grep($scope.list.dataTypes,function(val1){return val1.key == obj.columnDataType})[0]).value);
							return;
						}
					}
				});
			}
			if(!exist){
				return;
			}
		}
		return filedefvo;
    }
    
    function validateEmailAddresses(){
		if($scope.notifications.defaultEmailAddresses){
			var emailArray = $scope.notifications.defaultEmailAddresses.split(',');
			var flag = false;
			angular.forEach(emailArray,function(email){
				if(!flag && !validateEmail(email)){
					flag = true;
				}
			});
			if(flag)
				return null;
			flag = false;
			angular.forEach($scope.notifications.notificationStatuses,function(notification){
				if(notification.isEnabled && !flag && notification.emailAddresses){
					var innerFlag = false;
					emailArray =  notification.emailAddresses.split(',');
					angular.forEach(emailArray,function(email){
						if(!innerFlag && !validateEmail(email)){
							innerFlag = true;
							flag = true;
						}
					});
				}
			});
			if(flag)
				return null;
			else 
				return true;
		}
	}
    
    function prepareFileScheduleVoForSave(){
    	var fileScheduleVO = {};
    	if($scope.list.scheduleactivemode == 'Y') {
	    	if($scope.list.fileScheudleID){
	    		fileScheduleVO.fileScheudleID = $scope.list.fileScheudleID;
	    		fileScheduleVO.fileDefinitionID = $scope.list.fileDefinitionID;
	    	}
			fileScheduleVO.frequency = $scope.list.frequency;
			fileScheduleVO.timeZone = $scope.list.timezone;
			
			if ($scope.list.frequency == 'I') {
	        	fileScheduleVO.scheduleStartDate  = zhapp.getCnvDateTime('DTS',null,$scope.list.timezone);
	        	fileScheduleVO.schedulenextdue = null;
	            fileScheduleVO.scheduleEndDate = zhapp.getCnvDateTime('DTS',null,$scope.list.timezone);
	            fileScheduleVO.frequencyUnit = 0;
	            fileScheduleVO.includeDays = 0;
	            fileScheduleVO.dayOfEveryMonth = 0;
	            return fileScheduleVO;
	        }else if($scope.list.frequency == 'O'){
	        	if($scope.list.startDate == ""){
	        		showErrorMessage("Invalid ScheduleStartDate");
	        		return;
	        	}
	        	fileScheduleVO.scheduleStartDate  = $scope.list.startDate+" "+$scope.list.startTime+":00";
	        	fileScheduleVO.schedulenextdue = null;
	            fileScheduleVO.scheduleEndDate = $scope.list.startDate+" "+$scope.list.startTime+":00";
	            fileScheduleVO.frequencyUnit = 0;
	            fileScheduleVO.includeDays = 0;
	            fileScheduleVO.dayOfEveryMonth = 0;
	            return fileScheduleVO;
	        }
    	}
		return fileScheduleVO;
    }
    
    function prepareFileSourceSpecVO(){
    	var fileSourceSpecVO = {};
		fileSourceSpecVO.sourceType = $scope.list.createFrom;
		if($scope.list.createFrom == 'R'){
			fileSourceSpecVO.sourceName = $scope.list.remote.hostServer.fileSourceName;
			if(!$scope.list.remote.fileNamePattern){
				fileSourceSpecVO.fileNamePattern = "*";
			}else{
				fileSourceSpecVO.fileNamePattern = $scope.list.remote.fileNamePattern;
			}
			if($scope.list.remote.currentFolderselected != undefined && ($scope.list.remote.currentFolderselected.endsWith(".txt") || $scope.list.remote.currentFolderselected.endsWith(".csv"))){
				fileSourceSpecVO.folderPath = $scope.list.remote.currentFolderselected.substring(0,$scope.list.remote.currentFolderselected.lastIndexOf('/'));
			}else{
				fileSourceSpecVO.folderPath = $scope.list.remote.currentFolderselected;
			}
//			if($scope.list.remote.hostServer.protocol=='http' || $scope.list.remote.hostServer.protocol=='https'){
//				fileSourceSpecVO.folderPath = $scope.list.remote.hostServer.hostname.substring(0,$scope.list.remote.hostServer.hostname.lastIndexOf('/'));
//			}
		}else if($scope.list.createFrom == 'B'){
			fileSourceSpecVO.sourceName = $scope.list.db.dbSource.dbSourceName;
			fileSourceSpecVO.query = $scope.list.dbSelectQuery;
			fileSourceSpecVO.sourceTable = $scope.list.selectedTableName;
		}
//		fileSourceSpecVO.fileName = '';
		return fileSourceSpecVO;
    }
    
    function createFileMappingVO(){
		var list = [];
		var fileActionMappingVO = {};
		if($scope.list.nullValueRepresentation){
			fileActionMappingVO.nullValueRepresentation = $scope.list.nullValueRepresentation;
		}
//		if($scope.list.booleanFormat){
			fileActionMappingVO.booleanFormat = "YESNO";
//		}
		if($scope.list.dateFormat){
			fileActionMappingVO.dateFormat = $scope.list.dateFormat;
		}
		if($scope.list.dateDelimiter){
			fileActionMappingVO.dateDelimiter = $scope.list.dateDelimiter;
		}
		$scope.list.setScrubRulesForSave();
		if($scope.list.includescrubrules && $scope.list.includescrubrules != 0){
			fileActionMappingVO.enableScrubRules = 'Y';
		}else{
			fileActionMappingVO.enableScrubRules = 'N';
		}
		fileActionMappingVO.includeScrubRules = $scope.list.includescrubrules;
		if($scope.list.validateScrubrule()){
			if($scope.list.endingwithtext && $scope.list.endingwithtext != null)
			fileActionMappingVO.scrubrulesEndingWithText=$scope.list.endingwithtext;
			console.log(fileActionMappingVO.scrubrulesEndingWithText);
			}else
        	return ;
		
		
		angular.forEach($scope.list.fdMappingVOList,function(data,index){
			if(data.audienceColumn == undefined){
				return;
			}
			if($scope.list.listType == 'G'){
				if(data.dataType == undefined){
					return;
				}
			}
			var columnDefinitionList = {};
			columnDefinitionList.columnPositionInFile = index;
			columnDefinitionList.columnName = data.header;
			if(data.audienceColumn && data.audienceColumn.CustomType == 'Audience'){
				columnDefinitionList.isCustomColumn = 'N';
			}else{
				columnDefinitionList.isCustomColumn = 'Y';
			}
			
			columnDefinitionList.defaultValue = data.defaultValue;
			if(data.isNullable)
				columnDefinitionList.isNullable = data.isNullable;
			else
				columnDefinitionList.isNullable = 'N';
			columnDefinitionList.unsubscribe = data.unSubAddList;
			columnDefinitionList.useInList = 'Y';
			if(data.audienceColumn){
				if(data.audienceColumn.logicalColumnName == 'Omit'){
					return;
				}
				if(data.audienceColumn.logicalColumnName == 'Is Custom')
					columnDefinitionList.logicalColumnName = columnDefinitionList.columnName;
				else 
					columnDefinitionList.logicalColumnName = data.audienceColumn.logicalColumnName;
				columnDefinitionList.physicalColumnName = data.audienceColumn.physicalColumnName;
				
				if(data.audienceColumn.physicalColumnName=="custom")
					columnDefinitionList.physicalColumnName = data.audienceColumn.physicalColumnName+columnDefinitionList.columnName;
				else
					columnDefinitionList.physicalColumnName = data.audienceColumn.physicalColumnName;
				var selectedAud = $scope.list.selectedAudience;
				if(selectedAud != undefined && selectedAud.logicalTables != undefined){
					columnDefinitionList.physicalTableName = $.grep(selectedAud.logicalTables,function(obj){return obj.tableType == 0})[0].physicalTableName;
					columnDefinitionList.logicalTableName = $.grep(selectedAud.logicalTables,function(obj){return obj.tableType == 0})[0].logicalTableName;					
				}
				if(data.audienceColumn.length)columnDefinitionList.length = data.audienceColumn.length;
				else columnDefinitionList.length = 400;
				
				if(data.audienceColumn.physicalColumnName=="custom")
					columnDefinitionList.physicalTableName = undefined;
				if(data.audienceColumn.isNullable)
					columnDefinitionList.isNullable = data.audienceColumn.isNullable;
			}
			
			if(data.enableEmailAddress)columnDefinitionList.addressType=data.addressType[0];
			if(data.enableSmsAddress)columnDefinitionList.addressType=data.smsAddressType[0];
			if(data.defaultValue)
				columnDefinitionList.defaultValue = data.defaultValue;
			if(data.dataType){
				columnDefinitionList.columnType = data.dataType.value;
				if(data.dataType.value == 'UNICODESTRING' || data.dataType.value == 'ASCIISTRING'){
					columnDefinitionList.columnType = "STRING";
				}
			}
			
			list.push(columnDefinitionList);
		});
		fileActionMappingVO.columnDefinitionList = list;
		return fileActionMappingVO;
	}
    $scope.list.validateScrubrule=function(){
		if($scope.list.changeemail){
			if($scope.list.endingwithtext==null){
				showErrorMessage("Specify value for rule - Change the email address ending with textbox.");
				return false;
			}
			$scope.list.endingwithtext=$scope.list.endingwithtext.trim();
			if($scope.list.endingwithtext.length==0){
				showErrorMessage("Specify value for rule - Change the email address ending with textbox.");
				return false;
			}
			else{
				var strArr = $scope.list.endingwithtext.split(",");
				var isInvalid = false;
				var token;
				var strArr2;
				var subtoken;
				if(strArr != null) {
					for(var i=0; i<strArr.length; i++) {
						token = strArr[i].trim();
						if(token.length == 0) {
							isInvalid = true;
							break;
						} else {
							strArr2 = token.split(" to ");
							if(strArr2 != null && strArr2.length == 2) {
								for(var j=0; j<strArr2.length; j++) {
									subtoken = strArr2[j].trim();
									if(subtoken.length == 0) {
										isInvalid = true;
										break;
									} 
								}
							} else {
								isInvalid = true;
								break;
							}	 	
						}
					}
				} else {
					isInvalid = true;
				}
				if(isInvalid) { 					
					showErrorMessage("Invalid value specified for rule - Change the email address ending with textbox.");
					return false;
				}
			}	
		}else
			$scope.list.endingwithtext=null;
		return true;
	};
	
    
    function preparefileFormatSpecVO(){
    	var fileformatvo = {};
    	fileformatvo.delimiter = $scope.list.fileFormatSpec.delimiter;
    	fileformatvo.textQualifier = $scope.list.fileFormatSpec.textQualifier;
    	fileformatvo.headerRowAtLine =$scope.list.fileFormatSpec.headerRowAtLine;
    	fileformatvo.dataStartsFromLine = $scope.list.fileFormatSpec.dataStartsFromLine;
    	return fileformatvo;
    }
    
    function preparefileProcessingOptionsVO(){
    	var fileProcessingOptionsVO = {};
    	fileProcessingOptionsVO.ignoreBadFiles = $scope.list.ignoreBadFiles;
    	fileProcessingOptionsVO.ignoreBadRecords = $scope.list.ignoreBadRecords;
    	fileProcessingOptionsVO.preserveOrder = $scope.list.preserveOrder;
    	fileProcessingOptionsVO.mergeDuplicates = $scope.list.mergeDuplicates;
    	return fileProcessingOptionsVO;
    }
    
    $scope.list.setScrubRulesForSave=function(){
		$scope.list.endingwithtext = $scope.list.endingwithtext;
		$scope.list.includescrubrules = 0;
		if($scope.list.remrepeatdots)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,0);
		if($scope.list.remdoublequotes)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,1);
		if($scope.list.reminvalid)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,2);
		if($scope.list.remrepeatat)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,3);
		if($scope.list.removedot)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,4);
		if($scope.list.changeunderscore)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,5);
		if($scope.list.removesinglequoteatend)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,6);
		if($scope.list.removesinglequoteatbegin)
		   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,7);
		if($scope.list.enclosedoublequotes)
	  	   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,8);
		if($scope.list.remwhitespace)
	  	   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,9);
		if($scope.list.changeemail)
	       $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,10);
		if($scope.list.removeplus)
	  	   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,11);
		if($scope.list.removewhitespacesms)
	  	   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,12);
		if($scope.list.removeminus)
	  	   $scope.list.includescrubrules = $scope.list.includescrubrules + Math.pow(2,13);    		  
	};
	
	$scope.leftmenu.initializePopup = function(){
		$(".trash-popup").dialog({
			autoOpen: false,
			resizable : false,
			width : 900,
			modal : true,
			closeOnEscape : false
		});
		$(".close-popup").click(function(){
			$(".trash-popup").dialog('close');
		});
	}
	
	$scope.list.initializePopup = function(){
		$(".filedef-remotedb-popup,.filedef-remotedb-sample-popup,.filedef-remotedb-popup,.queryBuilderPopup,.executeSQLQuery,.trash-popup").dialog({
			autoOpen: false,
			resizable : false,
			width : 900,
			modal : true,
			closeOnEscape : false
		});
		$(".filesInFolder").dialog({
			autoOpen: false,
			resizable : false,
			modal : true,
			closeOnEscape : false,
			maxWidth:600,
	        maxHeight: 400,
	        width: 600,
	        height: 400,
	        draggable: false
		});
		$(".filedef-remotedb-popup").dialog({
			open : function(){
				$('.fil-properties-scroll').slimScroll({
		 			color: '#a9a9a9',
		 			height: '300px',
		 			size: '6px',
		 			wheelStep:1,
		 			railVisible: true,
		 			alwaysVisible: false
		 		});
			}
		});
		
		$(".close-popup").click(function(){
			$(".filesInFolder,.filedef-remotedb-popup,.filedef-remotedb-sample-popup,.filedef-remotedb-popup,.queryBuilderPopup,.executeSQLQuery,.movinglist,.trash-popup").dialog('close');
		});
		$(".close-popupsub").click(function(){
			$(".executeSQLQuery").dialog('close');
		});
		
		$(".closebtn").click(function() {
			$('.movinglist').hide();
			$('.disableBack').hide();	
			$('.rgt-headerfix').css({position: 'fixed'});
			$('.rgt-headerfix').css("height", "auto");
			$('.rgt-headerfix').css('padding-top',"12px");
		});
	}
	
	 function dateToNormalStringUtil(d){
    	var hh = d.getHours(); 
    	var min = d.getMinutes(); 
    	var suffix = "AM"; 
    	var hours = hh;
    	if (min.toString().length == 1) 
    	    min = "0" + min;        	
    	var Datetime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+hours+":"+min+":"+d.getSeconds();            
        return Datetime;
    };
    
    $scope.list.getEncryptedKeyList = function(){
    	fileDefinitionService.getEncryptedKeysList().success(function(result){
    		$scope.list.encryptionKeysList = result;
    	}).error(function(error){
    		
    	});
    }
    
    $scope.list.homeEditListClick=function(listobj){
    	if($scope.list.canClickListEditHome(listobj)){
    		$rootScope.activeMenuItem = 'Lists';
    		$scope.list.editList(listobj);
    	}
    		
    }
    
    $scope.list.canClickListEditHome=function(listobj){
    	var validStatus=new Set(['B', 'E', 'C', 'U', 'X', 'K', 'P']); 
    	return validStatus.has(listobj.status);
    }
    
    $scope.list.initializeSummaryDialog=function(){
    	if($('[aria-describedby="listSummary"]').size() > 0)
    	   $('[aria-describedby="listSummary"]').remove();
    	$("#listSummary").dialog({
			autoOpen: false,
			resizable : false,
			width : 900,
			modal : true,
			closeOnEscape : false
		});
		$(".close-list-summary-popup").click(function(){
			$("#listSummary").dialog('close');
		});
		$('.scroll').slimScroll({
			color: '#ccc',
			size: '6px',
			wheelStep:1,
			railVisible: true,
			alwaysVisible: false
		});	
    }
    
    $scope.list.openListSummaryDialog=function(listObj){
    	listService.getFileDefinitionByID(listObj.fileDefinitionID).success(function(result){
    		$scope.list.listSummaryBO=result.fileSummaryBO;
    		if($scope.list.listSummaryBO==null){
    			showInfoMessage("Summary doesn't exists for this list.");
    		}else{
    			$("#listSummary").dialog('open');
    			$scope.list.listSummaryBO.audienceName=$scope.list.getAudienceName(listObj.audienceID);
    			if(result.fileSource.sourceType==='D')
    				$scope.list.listSummaryBO.sourceType='Desktop';
    			else if(result.fileSource.sourceType==='R')
    				$scope.list.listSummaryBO.sourceType='Remote server';
    			else if(result.fileSource.sourceType==='B')
    				$scope.list.listSummaryBO.sourceType='Remote DB';
    			else if(result.fileSource.sourceType==='L')
    				$scope.list.listSummaryBO.sourceType='Local Server';
    			if(listObj.listType==='G')
    				$scope.list.listSummaryBO.listType='General purpose';
    			else if(listObj.listType==='S')
    				$scope.list.listSummaryBO.listType='Seed';
    			else if(listObj.listType==='T')
    				$scope.list.listSummaryBO.listType='Test';
    			angular.forEach($scope.list.statusArray,function(statusObject){
    				if(statusObject.key===$scope.list.listSummaryBO.status)
    					$scope.list.listSummaryBO.UIStatus=statusObject.value;
    			});
    			var domainWiseCount=[];
    			if($scope.list.listSummaryBO.domainWiseCount!=null){
    				angular.forEach($scope.list.listSummaryBO.domainWiseCount,function(value,key){
        				var obj={};
        				obj.key=key;
        				obj.value=value;
        				domainWiseCount.push(obj);
        			});
    			}
    			$scope.list.listSummaryBO.domainWiseCountUI=domainWiseCount;
    		}
    	}).error(function(error){
    		showErrorMessage($scope.list.getErrorMessages(error));
    	});
    }
    
    $scope.list.timeTaken = function(start,end){
		if(start!=null && end!=null){
			var remainder;
			var milliseconds=Math.abs(end-start);
			if(milliseconds!==undefined && milliseconds!==null && milliseconds!==0){
				remainder = milliseconds % (24*60*60*1000);
				var hours=Math.floor((remainder)/(60*60*1000));
				remainder= milliseconds % (60*60*1000);
				var minutes=Math.floor((remainder)/(60*1000));
				remainder= milliseconds % (60*1000);
				var seconds=Math.floor((remainder)/1000);
				hours=hours > 9 ? "" + hours: "0" + hours;
				minutes=minutes > 9 ? "" + minutes: "0" + minutes;
				seconds=seconds > 9 ? "" + seconds: "0" + seconds;
				return hours+":"+minutes+":"+seconds;
			}else{
				return "00:00:00";
			}
		}else{
			return '--';
		}
	}
	
    $scope.list.editList = function(listobj){
    	$rootScope.menuItemEditflag = false;
    	$rootScope.activeMenuSubItem = " - " +listobj.name;
    	$scope.savedListItem=true;
    	$scope.list.defaultAdhocListValues();
    	$scope.list.listID = listobj.listID;
      	$scope.list.listType = listobj.listType;
    	$scope.list.sourceType = listobj.sourceType;
    	if($scope.list.sourceType == 'A'){
    		$scope.tableName = listobj.tableName;
    		$scope.list.prepareFileDefinitionForListEdit(listobj.fileDefinitionID);
    		var promise = $scope.list.initializeListForEdit();
    		promise.then(function(){
    			$scope.list.selectedAudience = $.grep($scope.list.audienceList,function(obj){
    	    		return obj.audienceId == listobj.audienceID;
    	    	})[0];
    			$scope.list.listTemplate = 'list/templates/neworeditlist.html';
    			$scope.list.selectedFolder = $.grep($scope.list.foldersList,function(obj){
    				return obj.folderid == listobj.folderID;
    			})[0];
    			
    			$scope.list.selectedCategory = $.grep($scope.list.categoriesList,function(obj){
    				return obj.categoryid == listobj.categoryID;
    			})[0];
    			$scope.list.type = 'A';
        		$scope.list.name = listobj.name;
            	$scope.list.listID = listobj.listID;
            	if($scope.list.selctedFdForClone != null && $scope.list.selctedFdForClone.fileDefinitionID != null){
            		$scope.list.fileDefinitionID = undefined;
            	}else{
            		$scope.list.fileDefinitionID = listobj.fileDefinitionID;
            	}
            	$scope.list.sourceType = listobj.sourceType;
    			$scope.list.listType = listobj.listType;
    		});
    	}else{
    		$scope.list.type = 'F';
    		 $scope.list.editListForFd(listobj);
    		 $scope.list.selectedAudience = $.grep($scope.list.audienceList,function(obj){
    	    		return obj.audienceId == listobj.audienceID;
    	    	})[0];
    		 if($scope.list.selectedAudience != undefined){
    	    	$scope.list.getTablesList($scope.list.sourceType,$scope.list.selectedAudience.audienceId);
    		 }
    	}
    	$scope.list.isEditMode = 'Y';	
    }
    
    $scope.list.prepareFileDefinitionForListEdit = function(fid){
    	fileDefinitionService.getAllFileDefinitionByID(fid).success(function(result){
    		if(result != undefined){
				var obj = result;
				$scope.list.editFileDefinition(obj);
			}else{
				showErrorMessage('Unable to edit list definition.');
			}
			
    	});
    }
    
    
    $scope.list.editFileDefinition = function(fdObj){
    	if($scope.list.selctedFdForClone != null && $scope.list.selctedFdForClone.fileDefinitionID != null){
    		if(fdObj.fileSource.sourceType == 'D'){
    			fdObj.fileMapping.columnDefinitionList = [];
			}
    		fdObj.fileDefinitionID = undefined;
    		if(fdObj.fileScheduleBO){
    			fdObj.fileScheduleBO.fileDefinitionID = undefined;
        		fdObj.fileScheduleBO.fileScheudleID = undefined;
    		}
    	}
    	if(fdObj.fileMapping && fdObj.fileMapping.columnDefinitionList)
    		$scope.editfilemapping = fdObj.fileMapping.columnDefinitionList;
    	if(fdObj.fileSource.sourceType == 'D'){
			fdObj.fileMapping.columnDefinitionList = [];
		}
    	$scope.list.fileDefinitionID = fdObj.fileDefinitionID;
    	$scope.list.tz=fdObj.timeZone;
    	var promise = prepareFileSorceSpecVOForEdit(fdObj.fileSource);
    	promise.then(function(){
    		prepareFileMappingVOForEdit(fdObj.fileMapping,fdObj);
    	});
    	
    	prepareScheduleVOForEdit(fdObj.fileScheduleBO,fdObj);
    	
    	$scope.list.fileFormatSpec = fdObj.fileFormatSpec;
    	$scope.list.fileScheduleVO = fdObj.fileSchedule;
    	$scope.list.FileSourceSpecVO = fdObj.fileSource;
    	if($scope.list.FileSourceSpecVO && $scope.list.FileSourceSpecVO.sourceType == 'R'){
    		$timeout(function() { $scope.list.getFoldersForRemoteServer();}, 1500);
    	}
    	$scope.list.ignoreBadFiles = fdObj.fileProcessingOptions.ignoreBadFiles;
    	$scope.list.ignoreBadRecords = fdObj.fileProcessingOptions.ignoreBadRecords;
    	$scope.list.preserveOrder = fdObj.fileProcessingOptions.preserveOrder;
    	$scope.list.mergeDuplicates = fdObj.fileProcessingOptions.mergeDuplicates;
    	if(fdObj.notifications){
    		if(fdObj.notifications.notificationStatuses){
    			angular.forEach(fdObj.notifications.notificationStatuses,function(obj){
    				if(obj.isEnabled && obj.emailAddresses != null && obj.emailAddresses == fdObj.notifications.defaultEmailAddresses){
    					obj.emailAddresses = undefined;
    				}
    			});
    		}
    		$scope.notifications = fdObj.notifications;
    		$scope.fdobjnotifications=angular.copy(fdObj.notifications);
    	}
    	$scope.list.FileActionMappingVO = {};
    	$scope.list.mergeDuplicates = 'N';
    	if(fdObj.encryptionKey){
    		$scope.list.useEncryption = 'Y';
    		$scope.list.encryptionKey = fdObj.encryptionKey;
    	}
    }
    
    function prepareFileSorceSpecVOForEdit(sourceobj){
    	var d = $q.defer();
    	$scope.list.createFrom = sourceobj.sourceType;
    	if($scope.list.createFrom == 'B'){
    		var promise = $scope.list.getDbSorceList();
        	promise.then(function(){
        		$scope.list.db.dbSource = $.grep($scope.list.db.sourceList,function(obj){
            		return obj.dbSourceName == sourceobj.sourceName;
            	})[0];
        		$scope.list.dbSelectQuery = sourceobj.query;
        		$scope.list.selectedTableName = sourceobj.sourceTable;
        		var promise2 = $scope.list.showDbTables();
        		promise2.then(function(){
//        			var promise3 = $scope.list.executeSelectQuery('E');
//        			promise3.then(function(){
        				d.resolve();
//        			});
        		});
        	});
    	}else if($scope.list.createFrom == 'R'){
    		$scope.list.remote.fileNamePattern = sourceobj.fileNamePattern;
    		$scope.list.remote.currentFolderselected = sourceobj.folderPath;
    		$scope.list.remote.currentFolderselectedFile = sourceobj.folderPath;
    		var promise = $scope.list.getHostList();
    		promise.then(function(){
    			$scope.list.remote.hostServer = $.grep($scope.list.remote.hostList,function(fobj){
    				return fobj.fileSourceName == sourceobj.sourceName;
    			})[0];
    			d.resolve();
    			/*var promise2 = listRemoteServerFolders(sourceobj.sourceName,'N',sourceobj.folderPath);
    			promise2.then(function(){
    				d.resolve();
    			});*/
    		});
    	}else{
    		d.resolve();
    	}
    	
    	return d.promise;
    }
    
    $scope.list.channelTypeChange = function(){
		if($scope.list.selectedListTypeForFd == 'R' || $scope.list.selectedListTypeForFd == 'U'){
			$scope.list.fdMappingVOList = [];
		}
	}

    function prepareFileMappingVOForEdit(mappingobj,fdobj){
    	if(fdobj.fileType == 'A'){
    		if(fdobj.audienceID != 0 && fdobj.audienceID != null && fdobj.audienceID != undefined){
        		$scope.list.selectedAudience = $.grep($scope.list.audienceList,function(obj){
        			return obj.audienceId == fdobj.audienceID;
        		})[0];
        	}
    		var promise = $scope.list.getAudienceColumns($scope.list.selectedAudience,fdobj);
    		promise.then(function(){
    			prepareDataMappingVOForEdit(mappingobj);
    		});
    		$scope.list.includescrubrules = mappingobj.includeScrubRules;
    		$scope.list.setScrubRulesForDisplay();
    		$scope.list.nullValueRepresentation =($.grep($scope.list.nullValue,function(data){
    			return data.key == mappingobj.nullValueRepresentation;
    		})[0]).key;
    		
    		$scope.list.booleanFormat="YESNO"
//    		$scope.list.booleanFormat = ($.grep($scope.list.booleanFormatList,function(data){
//    			return data.key == mappingobj.booleanFormat;
//    		})[0]).key;
    		
    		$scope.list.dateFormat = ($.grep($scope.list.dateFormatList,function(data){
    			return data.key == mappingobj.dateFormat;
    		})[0]).key;
    		$scope.list.dateDelimiter = ($.grep($scope.list.dateDelimiterList,function(data){
    			return data.key == mappingobj.dateDelimiter;
    		})[0]).key;
    	}
    }
    
    function prepareDataMappingVOForEdit(mappingobj){
    	if($scope.list.createFrom == 'R' || $scope.list.createFrom == 'D' || $scope.list.createFrom == 'L' || $scope.list.createFrom == 'B'){
    		$scope.list.fdMappingVOList = [];
    		angular.forEach(mappingobj.columnDefinitionList,function(obj){
    			fileDefMappingVO = {};
    			fileDefMappingVO.header = obj.columnName;
    			fileDefMappingVO.sampleDataColumns = undefined;
    			fileDefMappingVO.sampleDataColumn = undefined;
    			fileDefMappingVO.dataTypeList = $scope.list.dataTypes;
    			fileDefMappingVO.dataType = $.grep($scope.list.dataTypes,function(dobj){
        			return dobj.value == obj.columnType;
        		})[0];
				fileDefMappingVO.audienceColumn = $.grep($scope.list.audienceColumns,function(data){
					if(obj.isCustomColumn == 'Y')return 'Is Custom' == data.logicalColumnName;
					else return data.logicalColumnName == obj.logicalColumnName;
        		})[0];
				if(fileDefMappingVO.audienceColumn){
					if(fileDefMappingVO.audienceColumn.physicalColumnName == "EMAIL_ADDRESS" || fileDefMappingVO.audienceColumn.physicalColumnName == "SMS_NUMBER"){
						fileDefMappingVO.addressTypeDisable = true;
					}
				}
    			fileDefMappingVO.defaultValue = obj.defaultValue;
    			fileDefMappingVO.isNullable = obj.isNullable;
    			fileDefMappingVO.length = obj.length;
    			obj.disableLength = true;
    			if(obj.addressType){
    				if(obj.columnType == "EMAIL"){
    					fileDefMappingVO.addressType = $.grep($scope.list.emailAddressType,function(email){return email[0] == obj.addressType;})[0];
    					fileDefMappingVO.enableEmailAddress = true;
    				}else if(obj.columnType == "SMS"){
    					fileDefMappingVO.smsAddressType = $.grep($scope.list.smsAddressType,function(sms){return sms[0] == obj.addressType;})[0];
    					fileDefMappingVO.enableSmsAddress = true;
    				}
    			}
    			$scope.list.fdMappingVOList.push(fileDefMappingVO);
    		});
    	}
    	$scope.list.fdMappingVOList = $scope.list.fdMappingVOList;
    	
    }
    
    function prepareScheduleVOForEdit(schobj,fdobj){
    	$scope.list.scheduleactivemode = fdobj.scheduleactivemode;
    	if(fdobj.scheduleactivemode == 'Y'){
	    	$scope.list.fileScheudleID = schobj.fileScheudleID;
	    	$scope.list.frequency = schobj.frequency;
	    	$scope.list.endDate = schobj.scheduleEndDate;
	    	var startdate = schobj.scheduleStartDate;
	    	var date = startdate.split(' ')[0];
	    	var time = startdate.split(' ')[1].substring(0,startdate.split(' ')[1].lastIndexOf(':'));
	    	$scope.list.startDate = date;
	    	$scope.list.startTime = time;
	    	$scope.list.timezone = schobj.timeZone;
    	}else{
    		$scope.list.setTimezone();
    	}
    }
    
    $scope.list.searchByName = function(event){
    	if (event.type == "click" || event.keyCode == 13) {
    		if ($scope.list.searchText.length == 0) {		
                 showErrorMessage("Please Enter value to search");		
                 $scope.searchtext = '';		
                 return false;		
             }
    		$scope.prepareSearchCriteria();
    		var listcriteria = $scope.list.searchCriteria;
    		listcriteria.pageno =1;
    		listcriteria.pagesize = 7;	
    		listcriteria.name = $scope.list.searchText;
    		listcriteria.departmentID = zhapp.loginUser.departmentID;
    		listService.listAdhocLists(listcriteria).success(function(result){
        		$scope.list.adhocList = result.result;
        		if(result.result[0]){
        			$scope.list.currentPageNumber=1;
        			$scope.list.totalRecords = result.totalRecords;		
        		}
    			else{ $scope.list.totalRecords=-1;}
        		
        		if($scope.list.totalRecords <= 0){
        			$scope.infoMessage = "No Lists Found"; 
      			  	//showErrorMessage("No Lists Found");
      			  return;
      		}
        		
        	}).error(function(error){
        		showErrorMessage($scope.list.getErrorMessages(error));
        	});
    	}
    	if ((event.keyCode == 8 || event.keyCode == 46) && $scope.list.searchText.length == 0) {	
    		$scope.list.searchCriteria.name = undefined;
    		$scope.list.loadPageDetails(1);
      }
    }
    
    $scope.list.clearSearch = function(){
    	$scope.list.searchCriteria.name = undefined;
    	$scope.list.searchText = '';
    	$scope.list.loadPageDetails(1);
    }
    
    $scope.list.setScrubRulesForDisplay=function(){
		$scope.list.remrepeatdots=false;
    	$scope.list.remdoublequotes=false;
    	$scope.list.reminvalid=false;
    	$scope.list.remrepeatat=false;
    	$scope.list.removedot=false;
    	$scope.list.changeunderscore=false;
    	$scope.list.removesinglequoteatend=false;
    	$scope.list.removesinglequoteatbegin=false;
    	$scope.list.enclosedoublequotes=false;
    	$scope.list.remwhitespace=false;
    	$scope.list.changeemail=false;
    	$scope.list.removeplus=false;
    	$scope.list.removewhitespacesms=false;
    	$scope.list.removeminus=false;
		//$scope.list.endingwithtext=$scope.list.endingwithtext;
		var sum=$scope.list.includescrubrules;
		while(sum>0){
    		var pow=Math.floor(Math.log(sum)/Math.log(2));
    		var sum=sum-Math.pow(2,pow);
    		switch(pow){
    		  case 0:  $scope.list.remrepeatdots=true;
    		  		   break;
    		  case 1:  $scope.list.remdoublequotes=true;
	  		  		   break;
    		  case 2:  $scope.list.reminvalid=true;
	  		  		   break;
    		  case 3:  $scope.list.remrepeatat=true;
	  		  		   break;
    		  case 4:  $scope.list.removedot=true;
	  		           break;
    		  case 5:  $scope.list.changeunderscore=true;
	  		  		   break;
    		  case 6:  $scope.list.removesinglequoteatend=true;
	  		  		   break;
    		  case 7:  $scope.list.removesinglequoteatbegin=true;
    		  		   break;
    		  case 8:  $scope.list.enclosedoublequotes=true;
		  		   	   break;
    		  case 9:  $scope.list.remwhitespace=true;
		  		   	   break;
    		  case 10: $scope.list.changeemail=true;
		  		       break;
    		  case 11: $scope.list.removeplus=true;
		  		       break;
    		  case 12: $scope.list.removewhitespacesms=true;
		  		       break;
    		  case 13: $scope.list.removeminus=true;
		  		       break;    		  
    		};
    	};
	};
	$scope.list.defaultAdhocListValues();
	$scope.list.addFolder = function(){
		if(!$scope.list.showaddfolder)
		{
			$scope.list.newfoldername = undefined;
			$scope.list.showaddfolder=true;
		}
		if($scope.list.newfoldername == undefined || $scope.list.newfoldername.length == 0){
			return;
		}
		var folder={};
		folder.folderid=0;
		folder.departmentid=zhapp.loginUser.departmentID;
		folder.foldername=$scope.list.newfoldername;
		folder.type='A';//$scope.fldr.folderType;
		folder.parentfolderid=0;
		listService.saveFolder(folder).success(function(result){
			$scope.list.foldersList = $scope.list.getFoldersList();
			var criteria = {};
			criteria.departmentId = zhapp.loginUser.departmentID;
			criteria.type = 'A';
			departmentService.listFolders(criteria).success(function(result){
				$scope.list.foldersList = result;
				$scope.list.selectedFolder = $.grep($scope.list.foldersList,function(obj){
    				return obj.foldername == $scope.list.newfoldername;
    			})[0];
				$scope.list.newfoldername = undefined;
				$scope.list.showaddfolder=false;
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
		
	}
	
	
	$scope.list.addCategory = function(){
		if(!$scope.list.showcategory)
		{
			$scope.list.newcategoryname = undefined;
			$scope.list.showcategory=true;
		}
		if($scope.list.newcategoryname == undefined || $scope.list.newcategoryname.length == 0){
			return;
		}
		var category={};
		category.categoryid=0;
		category.departmentid=zhapp.loginUser.departmentID;
		category.categorycode=$scope.list.newcategoryname;//$scope.cat.addCategoryName;
		category.type='A';//$scope.cat.categoryType;
		category.description="";//$scope.cat.addCategoryDescription;
		departmentService.saveCategory(category).success(function(result){
			var criteria = {};
			criteria.departmentId = zhapp.loginUser.departmentID;
			criteria.type = 'A';
			departmentService.listCategories(criteria).success(function(result){
				$scope.list.categoriesList = result;
				$scope.list.selectedCategory = $.grep($scope.list.categoriesList,function(obj){return obj.categorycode == $scope.list.newcategoryname})[0];
				$scope.list.newcategoryname = undefined;
				$scope.list.showcategory=false;
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}).error(function(responseObj){
			showDepartmentErrorMessage(responseObj);
		});
	}
	
	
	   $scope.list.upmove = function(index){
	    	if (index == -1) {
	            return false;
	        }
	        if ($scope.list.fdMappingVOList[index - 1]) {
	            $scope.list.fdMappingVOList.splice(index - 1, 2, $scope.list.fdMappingVOList[index], $scope.list.fdMappingVOList[index - 1]);
	        } else {
	            return 0;
	        }

	    }
	    
	    $scope.list.downMove = function(index){
	    	$scope.list.downMove = function(index) {
		        if (index == -1) {
		            return false;
		        }
		        if ($scope.list.fdMappingVOList[index + 1]) {
		            $scope.list.fdMappingVOList.splice(index, 2, $scope.list.fdMappingVOList[index + 1], $scope.list.fdMappingVOList[index]);
		        } else {
		            return 0;
		        }
	    	}
	    }
	    
	    $scope.list.showmapping = function(){
	    	if($scope.list.createFrom == 'R' || $scope.list.createFrom == 'B' || $scope.list.createFrom == 'D'){
	    		return false;
	    	}else{
	    		return true;
	    	}
	    }
	    
    $scope.restrictSpecialCharForDataMap = function(index){
    	var obj = $scope.list.fdMappingVOList[index];
    	if(obj && obj.header && obj.header != ''){
    		obj.header = obj.header.replace(/(^[^a-zA-Z]|[^_$a-zA-Z0-9])/g, '');
    		$scope.list.fdMappingVOList[index] = obj;
    	}
    }
	
	$scope.$on('listingCriteriaChanged', function () {
		if($scope.adminModule.sortorder == 'descending'){
			$scope.list.searchCriteria.sortorder = 'DESC';
		}else{
			$scope.list.searchCriteria.sortorder = 'ASC';
		}
		if($scope.adminModule.sortby == 'createdon'){
			$scope.list.searchCriteria.sortby='createdate';
		}else{
			$scope.list.searchCriteria.sortby=$scope.adminModule.sortby;
		}
		$scope.list.listLists($scope.list.searchCriteria);
    });
		
	$scope.leftmenu.loadCommonDialogs=function(){
		$(".accordion .contentcontainer").hide();
		var wh = $(window).height()-90;
		$(".listscroll").css({'height': wh});
		$('.listscroll').slimScroll({
 			color: '#a9a9a9',
 			height: '300px',
 			size: '6px',
 			wheelStep:1,
 			railVisible: true,
 			alwaysVisible: true
 		});	
		loadCommonDialogs();
		if(zhapp.scriptProvider.componentName == "list"){
			$('.accordion > .contentcontainer').hide();
		}
	};
	
	$scope.listhelpURL = function(){
		 window.open(zhapp.help_host+'/help/default.htm?lists.htm', '_blank');
	}
	
	$scope.downloadAdhocListLogFiles = function(list){
		if(list.fileDefinitionID != undefined){
			fileDefinitionService.getAllFileActivityByFileDefId(list.fileDefinitionID).success(function(loadActivity){
				if(loadActivity != undefined){
					var promise = fileDefinitionService.createzipfile(loadActivity).success(function(result){
						var req = new FormData();
						req.append("zipFilePath", result.response);
						fileDefinitionService.downloadFileActivityLogFiles(req).success(function(result1){
							 var data = new Blob([result1], { type: 'application/zip;charset=utf-8' });
							 FileSaver.saveAs(data, result.response.substring(result.response.lastIndexOf("/")+1,result.response.length));
			    		}).error(function(error){
			    			showConfigurationErrorMessage(error);
			    		});
					}).error(function(error){
						showConfigurationErrorMessage(error);
					});
				}				
			}).error(function(error){
				showErrorMessage($scope.list.getErrorMessages(error));
			});
		}
	}
	
	$scope.list.getDataTypes = function(){
		$scope.list.dataTypes = [];
		fileDefinitionService.getDataTypes().success(function(result){
			var temp = [];
			angular.forEach(result,function(obj){
				var d = {};
				if(obj.columnType == 'ASCIISTRING'){
					d.key = 20;
				}else if(obj.columnType == 'UNICODESTRING'){
					d.key = 21;
				}else{
					d.key = obj.columnDataType;
				}
				d.value = obj.columnType;
				temp.push(d);
			});
			$scope.list.dataTypes = temp;
		}).error(function(error){
			showErrorMessage($scope.list.getErrorMessages(error));
		});
	}
	$scope.list.getDataTypes();
	
}]);

zhapp.factory('listService',['$http','$q',function listService($http,$q){
	return {
		getFileDefinitionList : function(criteria){
			return $http({
				url : '/file/getAllFileDefinitions',
				method : 'POST',
				data : criteria
			});
		},
		
		getFilesListOfFileDefinition : function(fdId){
			return $http({
				method : 'GET',
				url : '/file/getFilesByFileDefinition/'+fdId
			});
		},
		
		getTablesList : function(){
			return $http({
				method : 'GET',
				url : ''
			});
		},
		
		getFoldersList : function(criteria){
			return $http({
				method : 'POST',
				url : '/listFolders',
				data :criteria
			});
		},
		
		getCategoriesList : function(criteria){
			return $http({
				method : 'POST',
				url : '/listCategories',
				data : criteria
			});
		},
		
		saveListDefinition : function(listvo){
			return $http({
				method : 'POST',
				url : '/list/saveList',
				data : listvo
			});
		},
		
		saveFileAndListDefinition : function(obj){
			return $http({
				method : 'POST',
				url : '/list/saveListAndFile',
				data :obj,
				headers: { 'Content-Type': undefined }
			});
		},
		
		listAdhocLists : function(listcriteria){
			return $http({
				method : 'POST',
				url : '/list/getAllLists',
				data : listcriteria
			});
		},
		
		updateFolerOrCategory : function(column,value,listId,deptId){
			return $http({
				method : 'GET',
				url : '/list/updateFolerOrCategory/'+column+'/'+value+'/'+listId+'/'+deptId
			});
		},
		
		deleteAdhocList : function(listId){
			return $http({
				method : 'GET',
				url : '/list/deleteList/'+listId
			});
		},
		
		saveFolder: function(folderBO){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/saveFolder',
        		data: folderBO
        	});
        },
        saveCategory: function(categoryBO){
        	return $http({
        		method: 'POST',
        		url: zhapp.admin_host+'/saveCategory',
        		data: categoryBO
        	});
        },
        
        getTrashFolderList : function(deptId){
			return $http({
				method : 'GET',
				url : '/list/getTrashFolderList/'+deptId
			});
		},
		
		getFileDefinitionByID : function(fileDefinitionId){
			return $http({
				url : '/file/getFileDefinitionByID/'+fileDefinitionId,
				method : 'GET',
			});
		},
		getalllistsids : function(listId){
			return $http({
				url : '/list/getalllistsids/'+listId,
				method : 'GET',
			});
		}
	}
}]);
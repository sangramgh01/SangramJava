zhapp.controller("Group_Controller_userManagement", ['$scope', '$q', 'Group_Service_userManagement', 'Group_Validations_userManagement', '$timeout', 'uiGridConstants', function($scope, $q, Group_Service_userManagement, Group_Validations_userManagement, $timeout, uiGridConstants) {
      $scope.groupUserManagement = {};
      $scope.groupUserManagement.groupList = {};
      var loginUserCustomerID=zhapp.loginUser.customerID;

      var ifInActive='<div ng-class="{\'grey\':row.entity.status==\'I\' }"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }" ui-grid-cell></div></div>';
      $scope.gridOptions = {
        paginationPageSize: 15,
        paginationPageSizes: [15, 30, 45],
        enableFiltering: false,
        enableColumnMenus: false,
        onRegisterApi: function(gridApi) {
          $scope.gridApi = gridApi;
        },
        enableVerticalScrollbar: 0,
        enableHorizontalScrollbar: 0,
        rowTemplate:ifInActive,
        columnDefs: [
           {
            field: 'groupName',
            name: 'Group Name'
          }, {
            field: 'description',
            name: 'Description'
          },
          { field:'status', name: 'Status',
	    	  cellTemplate: '<div ng-if="row.entity.status==\'A\'">Active</div><div ng-if="row.entity.status==\'I\'">In-Active</div>'
	      },
          {
            field: 'Actions',
            cellClass: 'actioncell',
            cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>',
            	/* +
              '<a href="javascript:void(0)" ng-click="grid.appScope.deleteUserDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',*/
            width: '60',
            enableSorting: false,
            enableFiltering: false,
            headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'
          }

        ]
      };
      // To do Filtering
      $scope.toggleFiltering = function() {
        $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
      };

      // Filtering Header
      $scope.filteredHeader = function(row, rowRenderIndex, col, colRenderIndex) {
        if (col.filters[0].term) {
          return 'header-filtered';
        } else {
          return '';
        }
      };

      $scope.groupUserManagement.listGroups = function() {
    	  
        Group_Service_userManagement.listGroups(loginUserCustomerID).success(function(result) {
          $scope.groupUserManagement.groupList = result;
          $scope.$evalAsync(function() {
            $scope.gridOptions.data = result;
            $scope.gridData = $scope.gridOptions.data;
          });
        }).error(function(result) {
          showConfigurationErrorMessage(result);
        });
      };

      //To Open Add Group Pop Up
      $scope.groupUserManagement.saveGroupDialog = function() {
        if ($("#adminGroupAdd").css('display') === 'none') {
          $scope.groupUserManagement.addGroupObj = {};
          $scope.groupUserManagement.addGroupObj.groupName = '';
          $scope.groupUserManagement.addGroupObj.description = '';
          showDisableBack();
          $("#adminGroupAdd").show();
        }
      };

      //To Close Add Group Pop up
      $scope.groupUserManagement.closeAddGroupDialog = function() {
        $("#adminGroupAdd").hide();
        hideDisableBack();
      };

      //Add Group Method
      $scope.groupUserManagement.addGroup = function() {


        var canSave = Group_Validations_userManagement.validateGroupData($scope.groupUserManagement.addGroupObj);
        if (!canSave)
          return;

        $scope.groupUserManagement.addGroupObj.customerId = loginUserCustomerID;
        $scope.groupUserManagement.addGroupObj.createdBy = zhapp.loginUser.userName;
        $scope.groupUserManagement.addGroupObj.updatedBy=zhapp.loginUser.userName;
        Group_Service_userManagement.addGroup($scope.groupUserManagement.addGroupObj).success(function() {
          showInfoMessage("Group created successfully");
          //$scope.groupUserManagement.addGroupObj={};
          //$scope.groupUserManagement.listGroups();
          $("#adminGroupAdd").hide();
          hideDisableBack();
          $scope.groupUserManagement.listGroups();
        }).error(function(error) {
        	if(error.errors[0].message.includes("Group Name")){
        		var displayMessage=error.errors[0].message.split(".");
        		showErrorMessage(displayMessage[1]);
        	}
        	else	
          showConfigurationErrorMessage(error);
        }); // closing of add group method
         
      }

        //Update Group Method
        $scope.groupUserManagement.editGroup = function() {    
          var canSave = Group_Validations_userManagement.validateGroupData($scope.groupUserManagement.addGroupObj);
          if (!canSave)
            return;
          $scope.groupUserManagement.addGroupObj.customerID = loginUserCustomerID;
          $scope.groupUserManagement.addGroupObj.updatedBy=zhapp.loginUser.userName;
          var updateGroupObject = $scope.groupUserManagement.addGroupObj;
          delete updateGroupObject.createdBy;
          delete updateGroupObject.createDate;
          delete updateGroupObject.updateDate;
          
          Group_Service_userManagement.updateGroup(updateGroupObject).success(function() {    
            showInfoMessage("Group Updated successfully");
            //$scope.groupUserManagement.addGroupObj={};
            //$scope.groupUserManagement.listGroups();
            $('.dialog-popup17').dialog('close');
            hideDisableBack();
            $scope.groupUserManagement.listGroups();
          }).error(function(error) {
            showConfigurationErrorMessage(error);
          });

        }; //close edit/update group    

        //To open edit Dialogue
        $scope.openEditDialog = function(groupUserManagement) {
          $scope.groupUserManagement.addGroupObj = angular.copy(groupUserManagement);
          $(".dialog-popup17").dialog('option', 'title', "Edit Group");
          $(".dialog-popup17").dialog("open");
        };

        // Delete pop up
        $scope.deleteUserDialog = function(groupUserManagement) {
          $scope.groupUserManagement.addGroupObj = groupUserManagement;
          showCommonConfirmMessage("Delete Group?", "Confirm", "Yes", "No", 350, $scope.groupUserManagement.deleteUser);
        };

        // Delete Operation
        $scope.groupUserManagement.deleteUser = function(flag) {
          if (flag) {

            Group_Service_userManagement.deleteGroup($scope.groupUserManagement.addGroupObj.groupID).success(function() {
              showInfoMessage("Group deleted successfully")
                //$scope.groupUserManagement.addGroupObj={};
                //$scope.groupUserManagement.listGroups();
              $scope.groupUserManagement.listGroups();
            }).error(function(error) {
              showConfigurationErrorMessage(error);
            });
          }
        };

        $scope.eliminateGreateLesser = function(event) {
          if (event.shiftKey && (event.keyCode === 188 || event.keyCode === 190)) event.preventDefault();
        };

        $timeout(function() {
          removeConfigurationDialogsFromDom();
          initialzeConfigDialogs("DOMAIN");
        });


      }]);
zhapp.controller("RuleGroup_Controller_userManagement",['$scope','$q','RuleGroup_Service_userManagement','$timeout','uiGridConstants',function($scope,$q,RuleGroup_Service_userManagement,$timeout,uiGridConstants) {
	$scope.ruleGroupUserManagement={};

	getAllGroupsForBasedOnCustomer();
	getAllRulesBasedOnCustomer();	
	$scope.selected_id="";
	$scope.AddedOnes=false;
	
	function getAllGroupsForBasedOnCustomer() {
	      RuleGroup_Service_userManagement.getAllGroups(zhapp.loginUser.customerID).success(function(result){
	    	  $scope.removeInActiveGroups=result;
	        	for (var i=0;i<$scope.removeInActiveGroups.length;i++) {
					if($scope.removeInActiveGroups[i].status == "I"){
						$scope.removeInActiveGroups.splice(i, 1);
						--i;
						 //delete $scope.removeInActives[i];
					}
				}  
	      	  $scope.AllGroupsForUserGroup  = $scope.removeInActiveGroups;
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	
	function getAllRulesBasedOnCustomer() {  
		 RuleGroup_Service_userManagement.RuleGroupListRulesBasedOncustCode(zhapp.loginUser.custCode).success(function(result){
	    	  $scope.listA=[];		
			$scope.removeInActives=result;
				
				for (var i=0;i<$scope.removeInActives.length;i++) {
					if($scope.removeInActives[i].status == "I"){
						$scope.removeInActives.splice(i, 1);
						--i;
						 //delete $scope.removeInActives[i];
					}
				}
				$scope.listA = $scope.removeInActives;
				
				/*for (i in $scope.changingRuleIdObject) {
				 str = JSON.stringify($scope.changingRuleIdObject[i]);
				 str = str.replace("ruleId","ruleID");
				 var converted  = JSON.parse(str);
				 $scope.listA.push(converted);
				 }*/
				
				$scope.AllRulesBaseonCustCode =  $scope.listA;
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	
	
	$scope.getRulesByGroupId = function(selected_id) {
		document.getElementById("RGStartDate").value="";
		document.getElementById("RGEndDate").value="";
		
		if (selected_id !== "") {
			reset();
			$scope.one = false;
			$scope.two = false;
			$scope.checkCheckBox = false;
			getRulesByGroupIdCall(selected_id);
		} else {
			showErrorMessage("Please Select The Rule From The List");
			getAllRulesBasedOnCustomer();
			$scope.listB="";
			document.getElementById("allUsersForRuleGroup").focus();
		}
	};
	
	
	function getRulesByGroupIdCall(selected_id) {
		
		 $scope.listA = angular.copy($scope.AllRulesBaseonCustCode);
	      //get All Rules Based upon User ID 
		 RuleGroup_Service_userManagement.RulesWithGroupId(selected_id).success(function(result){
			 
			 if (result == "" || result == undefined) {
		            showErrorMessage('No Rules Were Found With The Selected Group');
		              $scope.selectedB = [];
		      }
			 
	    	    $scope.RulesWithUserIDData = result;
	    	    $scope.RulesByID = angular.copy($scope.RulesWithUserIDData);    
	            $scope.listB = angular.copy($scope.RulesWithUserIDData);
	    	    
	    	    $scope.currentUserTimeZone= zhapp.loginUser.timeZone;
	    		$scope.currentTimeofUser = zhapp.getCnvDateTime('DTS',null, $scope.currentUserTimeZone);
	    	    $scope.splitTime= $scope.currentTimeofUser.split("+");
	    	    $scope.splitTime.splice(1,1); 
	    	    $scope.currentTimeofSelectedUser= $scope.splitTime[0];
	    	    $scope.replacedMinus= $scope.currentTimeofSelectedUser.replace(/ /g, '-');
	        	$scope.replacedScopes=$scope.replacedMinus.replace(/:/g, '-');
	        	$scope.finalDate=$scope.replacedScopes.split("-");

		    	$('.form_datetimeForRuleGroup').datetimepicker({
			  		format: "yyyy-mm-dd hh:ii:ss",
			  		todayHighlight: false,
			  		autoclose: true,
			  		pickerPosition: "top-left",
			  		todayBtn: true,
			  		minuteStep: 1,
			  		startDate: new Date($scope.finalDate[0],$scope.finalDate[1]-1,$scope.finalDate[2],$scope.finalDate[3],$scope.finalDate[4],$scope.finalDate[5])
			      }); 
		    	 

	            var i = 0;
	            for (i in $scope.listB) {
	              var delId = arrayObjectIndexOf($scope.listA, $scope.listB[i].ruleId, "ruleId");
	              if(delId !=-1)
    	              $scope.listA.splice(delId, 1);
	            }

	            
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	      
	}//Closing
	
	
		
	$scope.AssignRules = function() {
		
		if($scope.selected_id=="" || $scope.selected_id== undefined){
    		showErrorMessage("Please Select The Rule First");
    		return;
    	}
		
		findAddedAndDeletedIDs();
		

	      if($scope.AddedOnes == false && $scope.DeletedOnes == false ){
	    	  showErrorMessage("Please assign or delete anything from the list") 
	    	  return;
	      }
	      
	      if($scope.AddedOnes != false && $scope.DeletedOnes != false ){
	       var dateValue=verifyDates();
	       
	        if(dateValue == true){
	        	AssignRulesToGroups($scope.AddedOnes);
	        	
	        	for (i in $scope.DeletedOnes) {
		    		  //var userGroupID = findRuleGroupID($scope.GroupsByID,$scope.DeletedOnes[i], "groupID");
						deleteRuleGroup($scope.DeletedOnes[i]);
		            }
	        	
	        	showCommonConfirmMessage("Rules Added and Deleted Successfully To The Selected Group","Info","Ok",null,450,function(flag){
		        		if(flag){
		        			addedAndDeletedEmpty();
		        		}
		        	});     
	        }
	      }//ending if !=false !== false
	      
	      else if($scope.AddedOnes !=false && $scope.DeletedOnes == false ){
	    	  var dateValue=verifyDates();
		        if(dateValue == true){
		        	AssignRulesToGroups($scope.AddedOnes);
		        	showCommonConfirmMessage("Rules Added Successfully To The Selected Group","Info","Ok",null,450,function(flag){
  		        		if(flag){
  		        			addedAndDeletedEmpty();
  		        		}
  		        	});
		        }    
	      }
	      
	      else if($scope.AddedOnes == false && $scope.DeletedOnes != false ){
	    	  for (i in $scope.DeletedOnes) {
	    		  //var userGroupID = findRuleGroupID($scope.GroupsByID,$scope.DeletedOnes[i], "groupID");
					deleteRuleGroup($scope.DeletedOnes[i]);
	            }
	    	  
	    	  showCommonConfirmMessage("Deletion Completed Successfully","Info","Ok",null,450,function(flag){
	        		if(flag){
	        			addedAndDeletedEmpty();
	        		}
	        	}); 
	      }

	    };//closing assign
	    
	    
	    function findAddedAndDeletedIDs(){

			var DummyGroups = [];
			var nowListB = [];
			
			var forDeleteDummyRules=[]; //Because ruleGroupId is needed to delete items
	        var forDeletenowListB=[];  //Because ruleGroupId is needed to delete items

			for (var i = 0; i < $scope.RulesByID.length; i++) {
				DummyGroups.push($scope.RulesByID[i].ruleId);
				forDeleteDummyRules.push($scope.RulesByID[i].ruleGroupId);
			}

			for (var j = 0; j < $scope.listB.length; j++) {
				nowListB.push($scope.listB[j].ruleId);
				forDeletenowListB.push($scope.listB[j].ruleGroupId);
			}
			
			 var c = angular.copy(forDeleteDummyRules);
		     var d = angular.copy(forDeletenowListB);

			var foundedAdd=FindAddedGroupIDs(nowListB, DummyGroups);
		    var foundedDel=FindDeletedGroupIDs(c, d);
	  	    
	  	    $scope.AddedOnes=foundedAdd;
	  	    $scope.DeletedOnes=foundedDel;

  	 }
		  
	function addedAndDeletedEmpty(){
		getRulesByGroupIdCall($scope.selected_id);
		document.getElementById("RGStartDate").value="";
		document.getElementById("RGEndDate").value="";
		$scope.AddedOnes=false;
		$scope.DeletedOnes=false;	
	}
	
	function verifyDates(){
		var startDate=document.getElementById("RGStartDate").value;
	    var endDate=document.getElementById("RGEndDate").value;
	    
	    if(startDate == ""){
	    	  showErrorMessage("Please select start date");
	    	  //document.getElementById("RGStartDate").focus();
	    	  return false;
	    	  
	      }
	      else if(endDate == ""){
	    	  showErrorMessage("Please select end date");
	    	  //document.getElementById("RGEndDate").focus();
	    	  return false
	      }
	      else if(startDate>endDate){
		    	  showErrorMessage("End Date Should Not Be Less Than Start Date");
		    	  document.getElementById("RGEndDate").focus();
		    	  return false;
		      }
	      else if(angular.equals(startDate,endDate)){
		    	  showErrorMessage("START DATE & END DATE Should Not Be Same");
		    	  //document.getElementById("RGEndDate").focus();
		    	  return false;
		      }
	      else
	    	 {
	    	  return true;
	    	 }
	}
	
    function resetUserData(){
    	$scope.RGStartDate="";
    	$scope.RGEndDate="";
    }

	function FindDeletedGroupIDs(inDummy, inListB) {
		var delItems = [];
		for (var i = 0; i < inDummy.length; i++) {
			if (inListB.indexOf(inDummy[i]) == -1) {
				delItems.push(inDummy[i]);
			}
		}
		 if (delItems == "") {
		        return false;
		      } else { 
		        return delItems;
		      }
		}

		function findRuleGroupID(myArray, searchTerm, property) {
			for (var i = 0, len = myArray.length; i < len; i++) {
				if (myArray[i][property] === searchTerm) {
					//alert("Foun UserGroup ID is: " + myArray[i].ruleGroupId);
					return myArray[i].ruleGroupId;

				}
			}
			return -1;
		}
	

	function FindAddedGroupIDs(src, dest) {
		var index;
		for (var i = 0; i < dest.length; i++) {
			index = src.indexOf(dest[i]);
			if (index > -1) {
				src.splice(index, 1);
			}
		}
		  if (src == "") {
	          return false;
	        } else {
	          return src;
	        }
	}

	//Adding Rules To The Selected Group
	function AssignRulesToGroups(src) {
		var s1 = src.toString();

		var RuleGroupBO = {};
		RuleGroupBO.groupId = $scope.selected_id;
		RuleGroupBO.ruleId = src[0];
		RuleGroupBO.ruleIds = s1;
		RuleGroupBO.createdBy=zhapp.loginUser.userName;
		RuleGroupBO.updatedBy=zhapp.loginUser.userName;
		RuleGroupBO.startDate = document.getElementById("RGStartDate").value;
		RuleGroupBO.endDate = document.getElementById("RGEndDate").value;
			
		RuleGroup_Service_userManagement.Assign(RuleGroupBO).success(function(result){
			
		}).error(function(result){
			showConfigurationErrorMessage(result);
			return;
		});
	}
	
	//Deleting Rules To The Selected Group
	function deleteRuleGroup(delItem) {
		
		RuleGroup_Service_userManagement.Delete(delItem).success(function(result){
		}).error(function(result){
			showConfigurationErrorMessage(result);
			return;
		});
	}
	
	
	/*function afterSaveOrDelete(){
		getAllRulesBasedOnCustomer();
		getRulesByGroupIdCall(document.getElementById("allUsersForRuleGroup").value);
	}*/

	// Dual List Logic Starts From Here

	$scope.selectedA = [];
	$scope.selectedB = [];

	$scope.checkedB = false;

	function arrayObjectIndexOf(myArray, searchTerm, property) {
		for (var i = 0, len = myArray.length; i < len; i++) {
			if (myArray[i][property] === searchTerm)
				return i;
		}
		return -1;
	}

	function checkForDuplicateID(myArray, searchTerm, property) {
		for (var i = 0, len = myArray.length; i < len; i++) {
			if (myArray[i][property] === searchTerm)
				return false;
		}
		return true;
	}

	$scope.fromAvailableToAssign = function() {
		beforeMove();
		var existData = [];
		var FirstCheck = $scope.selected_id;//document.getElementById("allUsersForRuleGroup").value;
		if (FirstCheck !== "") {

			if ($scope.selectedA.length > 0) {
				var i = 0;
				for (i in $scope.selectedA) {
					var moveId = arrayObjectIndexOf($scope.listA,$scope.selectedA[i], "ruleId");
					var duplicateCheck = checkForDuplicateID($scope.listB,$scope.selectedA[i], "ruleId");

					if (duplicateCheck !== false) {
						$scope.listB.push($scope.listA[moveId]);
						var delId = arrayObjectIndexOf($scope.listA,$scope.selectedA[i], "ruleId");
						$scope.listA.splice(delId, 1);
					} else {
						existData.push($scope.selectedA[i]);
					}// closing duplicate check ELSE

				} // closing For Loop
				reset();

				if (existData.length > 0) {
					showErrorMessage("RuleID(s) "
							+ existData
							+ " is already exist in Assigned Groups.Please Select Another One");
				}
			} else {
				showErrorMessage("Select The Rule From Available Rules");
				document.getElementById("GroupsDataByID").focus();
				return -1;
			}
		} else {
			showErrorMessage("Please Select The Group First");
			document.getElementById("allUsersForRuleGroup").focus();
			reset();
		}
		findAddedAndDeletedIDs();

	};

	$scope.fromAssignToAvailable = function() {
		beforeMove();
		var FirstCheck = document.getElementById("allUsersForRuleGroup").value;
		if (FirstCheck !== "") {
			if ($scope.selectedB.length > 0) {
				var i = 0;
				for (i in $scope.selectedB) {
					var moveId = arrayObjectIndexOf($scope.listB,$scope.selectedB[i], "ruleId");
					$scope.listA.push($scope.listB[moveId]);
					var delId = arrayObjectIndexOf($scope.listB,$scope.selectedB[i], "ruleId");
					$scope.listB.splice(delId, 1);
				}
				reset();
			} else {
				showErrorMessage("Select The Group From Assigned Groups");
				document.getElementById("assignedGroups").focus();
				return -1;
			}
		}// closing If FirstCheck
		else {
			showErrorMessage("Please Select The Rule First");
			document.getElementById("allUsersForRuleGroup").focus();
			reset();
		}
		findAddedAndDeletedIDs();
	};

	function reset() {
		$scope.selectedA = [];
		$scope.selectedB = [];
		$scope.toggle = 0;
	}

	function beforeMove() {
		$scope.one = false;
		$scope.two = false;
		$scope.checkCheckBox = false;
		$scope.checkCheckBoxB = false;

	}
	$scope.toggleA = function() {
		var i = 0;
		if ($scope.checkCheckBox) {
			$scope.checkCheckBox = false;
			$scope.selectedA = [];
			$scope.one = false;
		} else {
			$scope.checkCheckBox = true;
			$scope.selectedA = [];
			for (i in $scope.listA) {
				$scope.selectedA.push($scope.listA[i].ruleId);
			}
		}

	};

	$scope.toggleB = function() {
		var i = 0;
		if ($scope.checkCheckBoxB) {
			$scope.checkCheckBoxB = false;
			$scope.selectedB = [];
			$scope.two = false;
			for (i in $scope.listB) {
		         if(!$scope.listB[i].hasOwnProperty("status"))
		            $scope['changeToDisable'+$scope.listB[i].ruleId] = {'border-bottom':'1px solid #ccc'};
		          }
		} else {
			$scope.checkCheckBoxB = true;
			$scope.selectedB = [];
			for (i in $scope.listB) {
				$scope.selectedB.push($scope.listB[i].ruleId);
				$scope['changeToDisable'+$scope.listB[i].ruleId] = {'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
			}
		}
	};

	$scope.selectA = function(i) {
		$scope.one = false;
		var index = $scope.selectedA.indexOf(i);
		if (index > -1) {
			$scope.selectedA.splice(index, 1);
		} else {
			$scope.selectedA.push(i);
		}
	};

	 $scope.selectB = function(i) {
	        $scope.two = false;
	        var index = $scope.selectedB.indexOf(i);
	        if (index > -1) {
	          $scope.selectedB.splice(index, 1);
	          $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc'};
	        } else {
	          $scope.selectedB.push(i);
	          $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
	        }
	 };
	
     
     $scope.checkGroupSelectedOrNot = function(){
   	  if($scope.selected_id == "" ||  $scope.selected_id == undefined) {  
   		  showErrorMessage("Please Select The Group First","Warning","Yes","No",450,function(flag) {
                 if(flag){
                	 document.getElementById("allUsersForRuleGroup").focus();
                	 $('.form_datetimeForRuleGroup').datetimepicker('hide');
	                  return;
                 	}    
                 });
   		  return;
   	  }
     };

	
}]);
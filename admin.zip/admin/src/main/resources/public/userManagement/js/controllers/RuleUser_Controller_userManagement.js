zhapp.controller("RuleUser_Controller_userManagement",['$scope','$q','RuleUser_Service_userManagement','$timeout','uiGridConstants',function($scope,$q,RuleUser_Service_userManagement,$timeout,uiGridConstants) {
	$scope.ruleUserUserManagement={};
	getAllUserForBasedOnCustomer();
	getAllRulesBasedOnCustomer();
	$scope.selected_id="";
	$scope.AddedOnes=false;
	   	   
	   function getAllUserForBasedOnCustomer(){
		   
		   RuleUser_Service_userManagement.getAllUsersForRuleUser(zhapp.loginUser.customerID).success(function(result){
			   $scope.removeInActiveUsers=result;
				
				for (var i=0;i<$scope.removeInActiveUsers.length;i++) {
					if($scope.removeInActiveUsers[i].status == "I"){
						$scope.removeInActiveUsers.splice(i, 1);
						--i;
						 //delete $scope.removeInActives[i];
					}
				}
			   
			   $scope.AllUsersForUserGroup = $scope.removeInActiveUsers;
			}).error(function(result){
				showConfigurationErrorMessage(result);
			});
		};
		
	
	
	 function getAllRulesBasedOnCustomer(){
			
		 RuleUser_Service_userManagement.RuleUserListRulesBasedOncustCode(zhapp.loginUser.custCode).success(function(result){
				$scope.listA=[];	
				$scope.removeInActives=result;
				
				for (var i=0;i<$scope.removeInActives.length;i++) {
					if($scope.removeInActives[i].status == "I"){
						$scope.removeInActives.splice(i, 1);
						--i;
						 //delete $scope.removeInActives[i];
					}
				}
				$scope.listA = $scope.removeInActives;
				
				/*for (i in $scope.changingRuleIdObject) {
				 str = JSON.stringify($scope.changingRuleIdObject[i]);
				 str = str.replace("ruleId","ruleId");
				 var converted  = JSON.parse(str);
				 $scope.listA.push(converted);
				 }*/
				$scope.AllRulesBaseonCustCode =  $scope.listA;

			}).error(function(result){
				showConfigurationErrorMessage(result);

			});
	 }

	 $scope.getRulesByUserID = function(selected_id) {
		 
		 document.getElementById("RUStartDate").value ="";
	     document.getElementById("RUEndDate").value="";
	        
	      if (selected_id !== "") {
	        reset();
	        $scope.one = false;
	        $scope.two = false;
	        $scope.checkCheckBox = false;
	        getRulesByUserIDCall(selected_id);
	      } else {
	    	  showErrorMessage("Please Select The User First");
	    	  getAllRulesBasedOnCustomer();
	    	  $scope.listB="";
	          document.getElementById("allUsersBasedOnCustomer").focus();
	      }
	    };
	    
    
	    function getRulesByUserIDCall(selected_id) {
	      $scope.listA = angular.copy($scope.AllRulesBaseonCustCode);
	      
	      //get All Rules Based upon User ID 
	      RuleUser_Service_userManagement.RulesWithUsersID(selected_id).success(function(result){
	    	  	    	 
	    	    $scope.RulesWithUserIDData = result;
	    	    //console.log($scope.RulesWithUserIDData);
	    	    $scope.RulesByID = angular.copy($scope.RulesWithUserIDData);    
	            $scope.listB = angular.copy($scope.RulesWithUserIDData);

	    	    $scope.displayTimeZone= $scope.RulesWithUserIDData[0].timeZone;    
	    	   
	    	    $scope.currentTimeofUser = zhapp.getCnvDateTime('DTS',null, $scope.RulesWithUserIDData[0].timeZone);
	    	    $scope.splitTime= $scope.currentTimeofUser.split("+");
	    	    $scope.splitTime.splice(1,1); 
	    	    $scope.currentTimeofSelectedUser= $scope.splitTime[0];
	    	    $scope.replacedMinus= $scope.currentTimeofSelectedUser.replace(/ /g, '-');
		    	$scope.replacedScopes=$scope.replacedMinus.replace(/:/g, '-');
		    	$scope.finalDate=$scope.replacedScopes.split("-");
		    	
		    	intializeDatePicker();
		    	
	            var i = 0;
	            for (i in $scope.listB) {
	              var delId = arrayObjectIndexOf($scope.listA, $scope.listB[i].ruleId, "ruleId");
	              if(delId !=-1)
    	              $scope.listA.splice(delId, 1);
	            }

	            if (result[0].ruleUserId == null || result[0].ruleUserId == "" || result == undefined && (result[0].timeZone != "" ||  result[0].timeZone !=null)) {
			        showErrorMessage('No Rules Were Found With The Selected User');
			        $scope.RulesByID=[];
			        $scope.listB=[];
			        
			        }
		    	  else
		    		 if(result == "" || result == undefined){
		    			 showErrorMessage('Something Went Wrong.Pleasen Try Again.');
		    			 return;
		    		 } 
		    	  
	            
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	      
	    } //Closing
	       
	    $scope.AssignUsers = function() {
	    	
	    	if($scope.selected_id=="" || $scope.selected_id== undefined){
	    		showErrorMessage("Please Select The User First");
	    		return;
	    	}
	    	
	    	findAddedAndDeletedIDs();
	    	
	    	
	    	if($scope.AddedOnes == false && $scope.DeletedOnes == false ){
	  	    	showErrorMessage("Please Assign or Delete Anything From The List");
	  	    	return;
	  	      }
	  	      
	  	      if($scope.AddedOnes != false && $scope.DeletedOnes != false ){
	  	       var dateValue=verifyDates();
	  	        if(dateValue == true){
	  	        	AssignRulesToUsers($scope.AddedOnes);
	  	        	
	  	        	for (i in $scope.DeletedOnes) {
	  	        		//var ruleUserId = findRuleUserID($scope.RulesByID,$scope.DeletedOnes[i], "ruleId");
	  	        		deleteRuleUser($scope.DeletedOnes[i]);
	  		            }
	  	        	showCommonConfirmMessage("Rules Added and Deleted Successfully To The Selected User","Info","Ok",null,450,function(flag){
  		        		if(flag){
  		        			addedAndDeletedEmpty();
  		        		}
  		        	});       	
	  	        }
	  	      }//ending if !=false !== false
	  	      
	  	      else if($scope.AddedOnes !=false && $scope.DeletedOnes == false ){
	  	    	  var dateValue=verifyDates();
	  		        if(dateValue == true){
	  		        	AssignRulesToUsers($scope.AddedOnes);	
	  		        	showCommonConfirmMessage("Rules Added Successfully To The Selected User","Info","Ok",null,450,function(flag){
	  		        		if(flag){
	  		        			addedAndDeletedEmpty();
	  		        		}
	  		        	});
	  		        }      
	  	      }
	  	      
	  	      else if($scope.AddedOnes ==false && $scope.DeletedOnes != false ){
	  	    	  for (i in $scope.DeletedOnes) {
	  	    		  //var ruleUserId = findRuleUserID($scope.RulesByID,$scope.DeletedOnes[i], "ruleId");
	  	    		  deleteRuleUser($scope.DeletedOnes[i]);
	  	            }
	  	    	showCommonConfirmMessage("Deletion Completed Successfully","Info","Ok",null,450,function(flag){
		        		if(flag){
		        			addedAndDeletedEmpty();
		        		}
		        	});
	  	      }
	    	

	  	   };//closing assign
	  	   
	  	   
	  	   
	  	 function findAddedAndDeletedIDs(){

		        var DummyRules = [];
		        var nowListB = [];
		        
		        var forDeleteDummyRules=[]; //Because we want ruleUserId  to delete items
		        var forDeletenowListB=[];  //Because we want ruleUserId to delete items

		        for (var i = 0; i < $scope.RulesByID.length; i++) {
		        	DummyRules.push($scope.RulesByID[i].ruleId);
		        	forDeleteDummyRules.push($scope.RulesByID[i].ruleUserId);
		        }

		        for (var j = 0; j < $scope.listB.length; j++) {
		          nowListB.push($scope.listB[j].ruleId);
		          if($scope.listB[j].hasOwnProperty("ruleUserId") == true){
		        	  forDeletenowListB.push($scope.listB[j].ruleUserId);
		          }
		        }
		        
		        var c = angular.copy(forDeleteDummyRules);
		        var d = angular.copy(forDeletenowListB);
		        
		        var foundedAdd=FindAddedRuleIDs(nowListB, DummyRules);
		  	    var foundedDel=FindDeletedRuleUserIDs(c, d);
		  	    
		  	    $scope.AddedOnes=foundedAdd;
		  	    $scope.DeletedOnes=foundedDel;
  
	  	 }
	  	    
	  	  function addedAndDeletedEmpty(){	 
	  		  
	  		var promise = new Promise(function(fulfill, reject) {
	  			var refreshLists=true;
	  		  if (refreshLists == true) {
	  			 fulfill(refreshLists);	
	  		  }
	  		    
	  		   else 
	  		    reject(refreshLists);
	  		  
	  		}); 	
	  		
	  		promise.then(function(refreshLists) {
	  			 
		  		 getRulesByUserIDCall($scope.selected_id);
		  		 document.getElementById("RUStartDate").value ="";
			     document.getElementById("RUEndDate").value="";
			     $scope.AddedOnes=false;
				 $scope.DeletedOnes=false;
		  	}, function(refreshLists) {
		  		
		  	});
	  	 }
	  	  
	  	
	  	    
	  	    function verifyDates(){
	  			var startDate=document.getElementById("RUStartDate").value;
	  		    var endDate=document.getElementById("RUEndDate").value;

	  		    if(startDate == ""){
	  		    	showErrorMessage("Please Select Start Date");
	  		    	 //document.getElementById("RUStartDate").focus();
	  		    	  return false;
	  		    	  
	  		      }
	  		      else if(endDate == ""){
	  		    	showErrorMessage("Please Select End Date");
	  		    	 //document.getElementById("RUEndDate").focus();
	  		    	  return false;
	  		      }
	  		      else if(startDate>endDate){
	  		    	  showErrorMessage("End Date Should Not Be Less Than Start Date");
	  		    	  document.getElementById("RUEndDate").focus();
	  		    	  return false;
	  		      }
	  		      else if(angular.equals(startDate,endDate)){
	  		    	  showErrorMessage("START DATE & END DATE Should Not Be Same");
	  		    	  document.getElementById("RUEndDate").focus();
	  		    	  return false;
	  		      }
	  		      else
	  		    	 {
	  		    	  return true;
	  		    	 }
	  		}
	      
	      function resetUserData(){
	      	$scope.RUStartDate="";
	      	$scope.RUEndDate="";
	      }
	     
	      //To find deleted items 
	      function FindDeletedRuleUserIDs(inDummy, inListB) {
	        var delItems = [];
	        for (var i = 0; i < inDummy.length; i++) {
	          if (inListB.indexOf(inDummy[i]) == -1) {
	            delItems.push(inDummy[i]);
	          }
	        }

	        if (delItems == "") {
	          return false;
	        } else { 
	          return delItems;
	        }
	      }

	      //To find rule user id
	      function findRuleUserID(myArray, searchTerm, property) {
	        for (var i = 0, len = myArray.length; i < len; i++) {
	          if (myArray[i][property] == searchTerm) {
	            //alert("Found RuleUser ID is: " + myArray[i].ruleUserId);
	            return myArray[i].ruleUserId;

	          }
	        }
	        return -1;
	      }

	     
	      
	      function FindAddedRuleIDs(src, dest) {
	        var index;
	        for (var i = 0; i < dest.length; i++) {
	          index = src.indexOf(dest[i]);
	          if (index > -1) {
	            src.splice(index, 1);
	          }
	        }
	        if (src == "") {
	            return false;
	          } else {
	            return src;
	          }
	      }

	      function AssignRulesToUsers(src) {
	        var s1 = src.toString();

	        var RuleUserBO = {};
	        
	        RuleUserBO.userId = $scope.selected_id;
	        RuleUserBO.ruleId = src[0];
	        RuleUserBO.ruleIds = s1;
	        RuleUserBO.createdBy=zhapp.loginUser.userName;
	        RuleUserBO.updatedBy=zhapp.loginUser.userName;
	        RuleUserBO.startDate = document.getElementById("RUStartDate").value;
	        RuleUserBO.endDate = document.getElementById("RUEndDate").value;

	        
	        RuleUser_Service_userManagement.Assign(RuleUserBO).success(function(result){  	
			}).error(function(result){
				showConfigurationErrorMessage(result);
				return;
			});
	        
	      }
	      
	      function deleteRuleUser(delItem) {
	    	  
		    	 RuleUser_Service_userManagement.Delete(delItem).success(function(result){  
				}).error(function(result){
					showConfigurationErrorMessage(result);
					return;
				});

		 }
	      
	      /*function afterSaveOrDelete(){
	    	getAllRulesBasedOnCustomer();
	    	getRulesByUserIDCall(document.getElementById("allUsersBasedOnCustomer").value);
	  	  }*/

	      //Dual List Logic Starts From Here

	      $scope.selectedA = [];
	      $scope.selectedB = [];

	      $scope.checkedB = false;

	      function arrayObjectIndexOf(myArray, searchTerm, property) {
	        for (var i = 0, len = myArray.length; i < len; i++) {
	          if (myArray[i][property] == searchTerm) return i;
	        }
	        return -1;
	      }

	      function checkForDuplicateID(myArray, searchTerm, property) {
	        for (var i = 0, len = myArray.length; i < len; i++) {
	          if (myArray[i][property] == searchTerm) return false;
	        }
	        return true;
	      }

	      $scope.fromAvailableToAssign = function() {
	        beforeMove();
	        var existData = [];
	        var FirstCheck = $scope.selected_id;
	        if (FirstCheck !== "") {

	          if ($scope.selectedA.length > 0) {
	            var i = 0;
	            for (i in $scope.selectedA) {
	              var moveId = arrayObjectIndexOf($scope.listA, $scope.selectedA[i], "ruleId");
	              var duplicateCheck = checkForDuplicateID($scope.listB, $scope.selectedA[i], "ruleId");

	              if (duplicateCheck !== false) {
	                $scope.listB.push($scope.listA[moveId]);
	                var delId = arrayObjectIndexOf($scope.listA, $scope.selectedA[i], "ruleId");
	                $scope.listA.splice(delId, 1);
	              } else {
	                existData.push($scope.selectedA[i]);
	              } //closing duplicate check ELSE

	            } //closing For Loop			
	            reset();

	            if (existData.length > 0) {
	            	showErrorMessage("RuleId(s) " + existData + " is Already Exist in Assigned Users.Please Select Another One");
	            }
	          } else {
	        	  showErrorMessage("Select The Rule From Available Rules");
	            //document.getElementById("GroupsDataByID").focus();
	            return -1;
	          }
	        } else {
	        	showErrorMessage("Please Select The User First");
	          document.getElementById("allUsersBasedOnCustomer").focus();
	          reset();
	        }
	        
	        findAddedAndDeletedIDs();

	      };

	      $scope.fromAssignToAvailable = function() {
	        beforeMove();
	        var FirstCheck = $scope.selected_id;
	        if (FirstCheck !== "") {
	          if ($scope.selectedB.length > 0) {
	            var i = 0;
	            for (i in $scope.selectedB) {
	              var moveId = arrayObjectIndexOf($scope.listB, $scope.selectedB[i], "ruleId");
	              $scope.listA.push($scope.listB[moveId]);
	              var delId = arrayObjectIndexOf($scope.listB, $scope.selectedB[i], "ruleId");
	              $scope.listB.splice(delId, 1);
	            }
	            reset();
	          } else {
	        	  showErrorMessage("Select The Rule From Assigned Rules");
	            document.getElementById("assignedGroups").focus();
	            return -1;
	          }
	        } //closing If FirstCheck
	        else {
	        	showErrorMessage("Please select the User first");
	          document.getElementById("allUsersBasedOnCustomer").focus();
	          reset();
	        }
	        
	        findAddedAndDeletedIDs();
	      };

	      function reset() {
	        $scope.selectedA = [];
	        $scope.selectedB = [];
	        $scope.toggle = 0;
	      }

	      function beforeMove() {
	        $scope.one = false;
	        $scope.two = false;
	        $scope.checkCheckBox = false;
	        $scope.checkCheckBoxB = false;

	      }
	      $scope.toggleA = function() {
	        var i = 0;
	        if ($scope.checkCheckBox) {
	          $scope.checkCheckBox = false;
	          $scope.selectedA = [];
	          $scope.one = false;
	        } else {
	          $scope.checkCheckBox = true;
	          $scope.selectedA = [];
	          for (i in $scope.listA) {
	            $scope.selectedA.push($scope.listA[i].ruleId);
	          }
	        }

	      };

	      $scope.toggleB = function() {
	        var i = 0;
	        if ($scope.checkCheckBoxB) {
	          $scope.checkCheckBoxB = false;
	          $scope.selectedB = [];
	          $scope.two = false;
	          for (i in $scope.listB) {
		         if(!$scope.listB[i].hasOwnProperty("status"))
		            $scope['changeToDisable'+$scope.listB[i].ruleId] = {'border-bottom':'1px solid #ccc'};
		       }
	        } else {
	          $scope.checkCheckBoxB = true;
	          $scope.selectedB = [];
	          for (i in $scope.listB) {
	            $scope.selectedB.push($scope.listB[i].ruleId);
	            $scope['changeToDisable'+$scope.listB[i].ruleId] = {'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
	          }
	          
	        }
	        
	        
	      };

	      $scope.selectA = function(i) {
	        $scope.one = false;
	        var index = $scope.selectedA.indexOf(i);
	        if (index > -1) {
	          $scope.selectedA.splice(index, 1);
	        } else {
	          $scope.selectedA.push(i);
	        }
	      };

	      $scope.selectB = function(i) {
	        $scope.two = false;
	        var index = $scope.selectedB.indexOf(i);
	        if (index > -1) {
	          $scope.selectedB.splice(index, 1);
	          $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc'};
	        } else {
	          $scope.selectedB.push(i);
	          $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
	        }
	      };
	     

	 	 $scope.checkUserSelectedOrNot = function(ElementID){
	 		findAddedAndDeletedIDs();
	    	  if($scope.selected_id == "" ||  $scope.selected_id == undefined) {  
	    		  showErrorMessage("Please Select The User First","Warning","Yes","No",450,function(flag) {
	                  if(flag){
	                	  document.getElementById("allUsersBasedOnCustomer").focus();
	                	  $('.form_datetimeForRuleUser').datetimepicker('hide');
		                  return;
	                  	}    
	                  });
	    		  return;
	    	  } 
	    	  else if($scope.AddedOnes == false) {
	    		  showErrorMessage("Please Assign Rules To The User First");
	    		  $('.form_datetimeForRuleUser').datetimepicker('remove');
                  return;
	    	  } 
	    	  else{
	    		  intializeDatePicker();
	    		  if(ElementID.srcElement.id == "RUStartDate")
	    		    $('#RUStartDate').focus();
	    		  else
	    		    $('#RUEndDate').focus();
	    	  }
	      };
	      
	      function intializeDatePicker(){
	    	  
	    	  $('.form_datetimeForRuleUser').datetimepicker({
		    		format: "yyyy-mm-dd hh:ii:ss",
			  		todayHighlight: false,
			  		autoclose: true,
			  		pickerPosition: "top-left",
			  		todayBtn: true,
			  		minuteStep: 1,
			  		startDate: new Date($scope.finalDate[0],$scope.finalDate[1]-1,$scope.finalDate[2],$scope.finalDate[3],$scope.finalDate[4],$scope.finalDate[5])
		 	      }); 
	      }

}]);
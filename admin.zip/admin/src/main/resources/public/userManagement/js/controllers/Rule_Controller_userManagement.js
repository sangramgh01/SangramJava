zhapp.controller("Rule_Controller_userManagement",['$scope','$q','Rule_Service_userManagement','Rule_Validations_userManagement','$timeout','uiGridConstants',function($scope,$q,Rule_Service_userManagement,Rule_Validations_userManagement,$timeout,uiGridConstants) {
	$scope.ruleUserManagement={};
	listResources();
	listAccessTypes();
	
	var promise = new Promise(function(resolve, reject) {
		
		$scope.currentUserTimeZone= zhapp.loginUser.timeZone;
		$scope.currentTimeofUser = zhapp.getCnvDateTime('DTS',null, $scope.currentUserTimeZone);
	    $scope.splitTime= $scope.currentTimeofUser.split("+");
	    $scope.splitTime.splice(1,1); 
	    $scope.currentTimeofSelectedUser= $scope.splitTime[0];
	    $scope.replacedMinus= $scope.currentTimeofSelectedUser.replace(/ /g, '-');
    	$scope.replacedScopes=$scope.replacedMinus.replace(/:/g, '-');
    	$scope.finalDate=$scope.replacedScopes.split("-");
    	
		  if ($scope.finalDate != "" || $scope.finalDate != undefined ) {
		    resolve('Converted');
		  }
		  else {
		    reject(Error("Error While Gtetting The Current User Time.Pleas Try Again"));
		  }
		});
	
		promise.then(function(result) {
			$('.form_datetimeForRule').datetimepicker({
		  		format: "yyyy-mm-dd hh:ii:ss",
		  		todayHighlight: true,
		  		autoclose: true,
		  		pickerPosition: "top-left",
		  		todayBtn: true,
		  		minuteStep: 1,
		  		startDate:new Date($scope.finalDate[0],$scope.finalDate[1]-1,$scope.finalDate[2],$scope.finalDate[3],$scope.finalDate[4],$scope.finalDate[5])
		      }); 	 
		}, function(err) {
			showConfigurationErrorMessage(err);
		});
	
	
	
	var ifInActive='<div ng-class="{\'grey\':row.entity.status==\'I\' }"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }" ui-grid-cell></div></div>';
	
	$scope.gridOptions = {
			
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
			rowTemplate:ifInActive,
		    columnDefs: [
		      { field:'resource', name: 'Resource'},
		      { field:'operator', name: 'Operator' },
		      { field:'sourceAttributeName', name: 'Source Attribute Name' },
		      { field:'targetAttributeName', name: 'Target Attribute Name' },  
		      { field:'accessType', name: 'Access Type' },
		      { field:'status', name: 'Status',
		    	  cellTemplate: '<div ng-if="row.entity.status==\'A\'">Active</div><div ng-if="row.entity.status==\'I\'">In-Active</div>'},
		      {field: 'Actions',cellClass:'actioncell',
		    	cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>'+
		    		'</a></div>',
		    		width: '60',enableSorting: false,enableFiltering: false,
		    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
                        
		    ]
	};
	
	// To do Filtering
	$scope.toggleFiltering = function(){
	    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
	    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	// Filtering Header
	$scope.filteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	  
	function listResources(){
		Rule_Service_userManagement.listResources(zhapp.loginUser.customerID).success(function(result){	
			$scope.AllResources=result;	
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	function listAccessTypes(){
		Rule_Service_userManagement.listAccessTypes(zhapp.loginUser.customerID).success(function(result){	
			$scope.AccesTypeData=result;			
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	}
	
	$scope.ruleUserManagement.listRules=function(){
	
	      Rule_Service_userManagement.listRulesBasedOncustCode(zhapp.loginUser.custCode).success(function(result){
			$scope.ruleUserManagement.ruleList = result;
			$scope.$evalAsync(function(){ 
			$scope.gridOptions.data = result;
			//$scope.AllRules=result;
			$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
	};
	
	
	$scope.operatorData = [
	            		    {operator : ">"},
	            		    {operator : ">="},
	            		    {operator : "<"},
	            		    {operator : "<="},
	            		    {operator : "=="},
	            		    {operator : "!="},
	            		    {operator : "&&"},
	            		    {operator : "||"},
	            		    {operator : "!"},
	            		];
	
	//To Open Add Rule Pop
	$scope.ruleUserManagement.saveRuleDialog=function(){  
		
		 if ($("#adminRuleAdd").css('display') === 'none'){
			$scope.ruleUserManagement.addRuleObj={};
			$scope.ruleUserManagement.addRuleObj.customerId=zhapp.loginUser.customerID; 
			$scope.ruleUserManagement.addRuleObj.resource='';
			$scope.ruleUserManagement.addRuleObj.accessType='';
			$scope.ruleUserManagement.addRuleObj.operator='';
			$scope.ruleUserManagement.addRuleObj.sourceAttributeName='';
			$scope.ruleUserManagement.addRuleObj.targetAttributeName='';
			$scope.ruleUserManagement.addRuleObj.startDate='';
			$scope.ruleUserManagement.addRuleObj.endDate=''; 
			showDisableBack();
			$("#adminRuleAdd").show();			
		 }
	};
	// To Save Rule Through Rest Call
	$scope.ruleUserManagement.addRule=function(){
		
		var canSave = Rule_Validations_userManagement.validateRuleData($scope.ruleUserManagement.addRuleObj);
		if(!canSave) 
			return;
		$scope.ruleUserManagement.addRuleObj.createdBy=zhapp.loginUser.userName;
		$scope.ruleUserManagement.addRuleObj.updatedBy=zhapp.loginUser.userName;
		Rule_Service_userManagement.addRule($scope.ruleUserManagement.addRuleObj).success(function(result){
			 showInfoMessage("Rule added successfully");
		     $("#adminRuleAdd").hide();
			 hideDisableBack();	
			 $scope.ruleUserManagement.listRules();
	       	
		}).error(function(result){
			if(result.errors[0].message.includes("Duplicate")){
        		var displayMessage=result.errors[0].message.split(".");
        		showErrorMessage(displayMessage[1]);
        	}
        	else	
			showConfigurationErrorMessage(result);
		});	
	};//Closing Saving Rule through Rest Call
	
	
	//Update Rule Starting
	$scope.ruleUserManagement.editRule = function() {
		var canSave = Rule_Validations_userManagement.validateRuleData($scope.ruleUserManagement.addRuleObj);
		if(!canSave) 
			return;
		
		if($scope.ruleUserManagement.duplicateRow.status == 'I' && $scope.ruleUserManagement.addRuleObj.status == 'A' &&
				angular.equals($scope.ruleUserManagement.duplicateRow.endDate,$scope.ruleUserManagement.addRuleObj.endDate)){		
			showCommonConfirmMessage("Do you want to change the END DATE of this RULE ?","Alert","Yes","No",450,function(flag) {
                if(flag){
                	document.getElementById("admin_rule_txt_updateEndDate").focus();
                    return;
                }else
                	$scope.updateRule();          
                });
		}	else
			$scope.updateRule();
	
	}; //close edit/update Rule 
	      
	      $scope.updateRule=function(){
	    	  $scope.ruleUserManagement.addRuleObj.updatedBy=zhapp.loginUser.userName;
				Rule_Service_userManagement.updateRule($scope.ruleUserManagement.addRuleObj).success(function(result){
			        showInfoMessage("Rule Updated successfully");
			        $('.dialog-popup17').dialog('close');
					hideDisableBack();
					$scope.ruleUserManagement.listRules();
				}).error(function(result){
					showConfigurationErrorMessage(result);
				});
	      };
	
	
	//To Close Add Rule Pop up
	$scope.ruleUserManagement.closeAddUserDialog=function(){
		$("#adminRuleAdd").hide();
		hideDisableBack();
	};
	
	//To open edit Dialogue
	$scope.openEditDialog=function(ruleUserManagement){
		$scope.ruleUserManagement.addRuleObj = angular.copy(ruleUserManagement);
		$scope.ruleUserManagement.duplicateRow=angular.copy(ruleUserManagement);
		$(".dialog-popup17").dialog('option', 'title',"Edit Rule");
		$(".dialog-popup17").dialog( "open" );
	};
	
	// Delete pop up
	$scope.deleteRuleDialog=function(ruleUserManagement){		
		$scope.ruleUserManagement.addRuleObj=ruleUserManagement;
		showCommonConfirmMessage("Delete Rule?","Confirm","Yes","No",350,$scope.ruleUserManagement.deleteRule);
	};
	
	// Delete Operation 
	$scope.ruleUserManagement.deleteRule=function(flag){
		if(flag){				
			Rule_Service_userManagement.deleteRule($scope.ruleUserManagement.addRuleObj.ruleId).success(function(){
			showInfoMessage("Rule deleted successfully");
			$scope.ruleUserManagement.listRules();
		});
		}
	};
	
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))	event.preventDefault();
	};
	
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("ADMIN_USERMANAGEMENT");
	});
	 //validations 
    function verifyRuleDates(startDate,endDate){
	    if(startDate == ""){
	    	  showInfoMessage("Please select start date");
	    	  //document.getElementById("ruleStartDate").focus(); 
	    	  return false; 
	      }
	      else if(endDate == ""){
	    	  showInfoMessage("Please select end date");
	    	  //document.getElementById("ruleEndDate").focus();
	    	  //document.getElementById("ruleUpdateEndDate").focus();
	    	  return false
	      }
	      else if(startDate>endDate){
		    	  showErrorMessage("END DATE Should Not Be Less Than START DATE");
		    	  return false;
		      }
	      else
	    	 {
	    	  return true;
	    	 }
	}
    
    function validateSourceAttName(srcName){
    	
    	if (srcName == undefined || srcName == "") {
            showInfoMessage("Source Attribute Name shouldn't be empty");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          } else if (srcName.length > 101) {
            showInfoMessage("Source Attribute Name should be less than 100 characters");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          } else if (/[^a-zA-Z0-9\s]/.test(srcName)) {
            showInfoMessage('Source Attribute Name Should Be Alphanumeric');
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          } else return true;
    }
    
    function validateTargetAttName(tarName){
    	
    	if (tarName == undefined || tarName == "") {
            showInfoMessage("Target Attribute Name shouldn't be empty");
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } else if (tarName.length > 101) {
            showInfoMessage("Target Attribute Name should be less than 100 characters");
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } else if (/[^a-zA-Z0-9\s]/.test(tarName)) {
            showInfoMessage('Target Attribute Name Should Be Alphanumeric');
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } else return true;
    }
	
	
	
}]);
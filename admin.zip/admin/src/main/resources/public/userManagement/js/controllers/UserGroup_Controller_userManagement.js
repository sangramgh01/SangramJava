zhapp.controller("UserGroup_Controller_userManagement",['$scope','$q','UserGroup_Service_userManagement','$timeout','uiGridConstants',function($scope,$q,UserGroup_Service_userManagement,$timeout,uiGridConstants) {
	$scope.ruleGroupUserManagement={};
	var loginUserDetails={};
	loginUserDetails=zhapp.loginUser;
	$scope.selected_id="";
		
    getAllUsersForUserGroup();
    getAllGroupsForUserGroup();

    function getAllUsersForUserGroup() {
    	
        UserGroup_Service_userManagement.GetAllUsers(zhapp.loginUser.customerID).success(function(result){
        	
        	$scope.removeInActiveUsers=result;
        	for (var i=0;i<$scope.removeInActiveUsers.length;i++) {
				if($scope.removeInActiveUsers[i].status == "I"){
					$scope.removeInActiveUsers.splice(i, 1);
					--i;
					 //delete $scope.removeInActives[i];
				}
			}  
      	  $scope.AllUserOfCustomer  = $scope.removeInActiveUsers;
  		}).error(function(result){
  			showConfigurationErrorMessage(result);
  		});

      }
    
    function getAllGroupsForUserGroup() {
    	
      UserGroup_Service_userManagement.getAllGroups(loginUserDetails.customerID).success(function(result){  
    	  
    	  $scope.removeInActiveGroups=result;
      	  for (var i=0;i<$scope.removeInActiveGroups.length;i++) {
				if($scope.removeInActiveGroups[i].status == "I"){
					$scope.removeInActiveGroups.splice(i, 1);
					--i;
					 //delete $scope.removeInActives[i];
				}
			}  
    	  $scope.groupDataForUserGroup  = $scope.removeInActiveGroups;
    	  $scope.listA = $scope.removeInActiveGroups;
		}).error(function(result){
			showConfigurationErrorMessage(result);
		});
    }

    

    $scope.geGroupsById = function(selected_id) {
      if (selected_id !== "") {
        reset();
        $scope.one = false;
        $scope.two = false;
        $scope.checkCheckBox = false;
        getGroupsByIdCall(selected_id);
      } else {
        showErrorMessage("Please Select The User First");
        document.getElementById("groupsForUserGroup").focus();
        resetLists();
      }
    }
   
    
    function getGroupsByIdCall(selected_id) {
      $scope.listA = angular.copy($scope.groupDataForUserGroup);

      
      UserGroup_Service_userManagement.GroupsWithUserID(selected_id).success(function(result){
    	  
    	  if (result == "" || result == undefined) {
              showErrorMessage('No Groups Were Found With The Selected User');
              document.getElementById("groupsForUserGroup").focus();
              $scope.selectedB = [];
            }
    	  
    	  $scope.GroupWithIdData = result;
          $scope.GroupsByID = angular.copy($scope.GroupWithIdData);
          //console.log($scope.GroupsByID);
          $scope.listB = angular.copy($scope.GroupWithIdData);
        
          var i = 0;
          for (i in $scope.listB) {
            var delId = arrayObjectIndexOf($scope.listA,$scope.listB[i].groupId,"groupId");
            if(delId !=-1)
	        $scope.listA.splice(delId, 1);
          }
          //console.log($scope.listB);

		}).error(function(result){
			showConfigurationErrorMessage(result);
		});

    } // Closing
    

    $scope.AssignUserOnGroups = function() {
    	
    	if($scope.selected_id=="" || $scope.selected_id== undefined){
    		showErrorMessage("Please Select The Group First");
    		return;
    	}
    	
      var DummyGroups = [];
      var nowListB = [];

      for (var i = 0; i < $scope.GroupsByID.length; i++) {
        DummyGroups.push($scope.GroupsByID[i].groupId);
      }

      for (var j = 0; j < $scope.listB.length; j++) {
        nowListB.push($scope.listB[j].groupId);
      }
      
      var c = angular.copy(DummyGroups);
      var d = angular.copy(nowListB);

      var foundedAdd=FindAddedGroupIDs(nowListB, DummyGroups);
      var foundedDel=FindDeletedGroupIDs(c, d);
      
      if(foundedAdd == false && foundedDel == false ){
    	  showErrorMessage("Please Assign or Delete Anything From The List");
    	  return;
      }
      
      if(foundedAdd != false && foundedDel != false ){
    	  		AssignRulesToUsers(foundedAdd);	
	        	for (i in foundedDel) {
		    		 var userGroupID = findUserGroupID($scope.GroupsByID,foundedDel[i], "groupId");
	        		deleteUserGroupUser(userGroupID);
		            }
	        	showCommonConfirmMessage("Group(s) Added and Deleted Successfully To The Selected User","Info","Ok",null,450,function(flag){
		        		if(flag){
		        			addedAndDeletedEmpty();
		        		}
		        	});     
	      }//ending if !=false !== false
	      
	      else if(foundedAdd !=false && foundedDel == false ){

	    	  AssignRulesToUsers(foundedAdd);
		        	showCommonConfirmMessage("Group(s) Added Successfully To The Selected User","Info","Ok",null,450,function(flag){
 		        		if(flag){
 		        			addedAndDeletedEmpty();
 		        		}
 		        	});          
	      }
	      
	      else if(foundedAdd == false && foundedDel != false ){
	    	  for (i in foundedDel) {
	    		  var userGroupID = findUserGroupID($scope.GroupsByID,foundedDel[i], "groupId");
	    		  deleteUserGroupUser(userGroupID);
	            }
	    	  
	    	  showCommonConfirmMessage("Deletion Completed Successfully","Info","Ok",null,450,function(flag){
	        		if(flag){
	        			addedAndDeletedEmpty();
	        		}
	        		else
	        			alert("Please Click ");
	        	}); 
  
       } //Closing All Adding and Deleting Conditions

    } //Closing Assigning UserGroup
    
    function addedAndDeletedEmpty(){
		getGroupsByIdCall($scope.selected_id);		
	}
    
    var delItems = [];
    function FindDeletedGroupIDs(inDummy, inListB) {
      delItems = [];
      for (var i = 0; i < inDummy.length; i++) {
        if (inListB.indexOf(inDummy[i]) == -1) {
          delItems.push(inDummy[i]);
        }
      }

      if (delItems == "") {
        return false;
      } else { 
        return delItems;
      }
      
    }

    function findUserGroupID(myArray, searchTerm, property) {
      for (var i = 0, len = myArray.length; i < len; i++) {
        if (myArray[i][property] == searchTerm) {
         // showInfoMessage("Found UserGroup ID is: " + myArray[i].id);
          return myArray[i].userGroupId;

        }
      }
      return -1;
    }


    function FindAddedGroupIDs(src, dest) {
    	
      var index;
      for (var i = 0; i < dest.length; i++) {
        index = src.indexOf(dest[i]);
        if (index > -1) {
          src.splice(index, 1);
        }
      }
      if (src == "") {
        return false;
      } else {
        return src;
      }
      
    }

    function AssignRulesToUsers(src) {
      var s1 = src.toString();
      
      var UserGroupBO = {};

      UserGroupBO.userId = $scope.selected_id;
      UserGroupBO.groupId =src[0]; 
      UserGroupBO.groupIds = s1;
      UserGroupBO.createdBy = zhapp.loginUser.userName;
      UserGroupBO.updatedBy=zhapp.loginUser.userName;
      
  	  UserGroup_Service_userManagement.Assign(UserGroupBO).success(function(result){
        s1="";
        return true;
		}).error(function(result){
			showConfigurationErrorMessage(result);
			return;
		});

    }
    
    function deleteUserGroupUser(delItem) {
    	
    	UserGroup_Service_userManagement.Delete(delItem).success(function(result){
  		}).error(function(result){
  			showConfigurationErrorMessage(result);
  			return;
  		});

    }
    
    
    /*function afterSaveOrDelete(){
    	getAllGroupsForUserGroup();
    	getGroupsByIdCall(document.getElementById("groupsForUserGroup").value);
    }*/

    // Dual List Logic Starts From Here

    $scope.selectedA = [];
    $scope.selectedB = [];

    $scope.checkedB = false;

    function arrayObjectIndexOf(myArray, searchTerm, property) {
      for (var i = 0, len = myArray.length; i < len; i++) {
        if (myArray[i][property] == searchTerm)
          return i;
      }
      return -1;
    }

    function checkForDuplicateID(myArray, searchTerm, property) {
      for (var i = 0, len = myArray.length; i < len; i++) {
        if (myArray[i][property] == searchTerm)
          return false;
      }
      return true;
    }

    $scope.fromAvailableToAssign = function() {
      beforeMove();
      var existData = [];
      var FirstCheck = $scope.selected_id;//document.getElementById("groupsForUserGroup").value;
      if (FirstCheck !== "") {

        if ($scope.selectedA.length > 0) {
          var i = 0;
          for (i in $scope.selectedA) {
            var moveId = arrayObjectIndexOf($scope.listA,$scope.selectedA[i], "groupId");
            var duplicateCheck = checkForDuplicateID($scope.listB,$scope.selectedA[i], "groupId");

            if (duplicateCheck !== false) {
              $scope.listB.push($scope.listA[moveId]);
              var delId = arrayObjectIndexOf($scope.listA,$scope.selectedA[i], "groupId");
              $scope.listA.splice(delId, 1);
            } else {
              existData.push($scope.selectedA[i]);
            } // closing duplicate check ELSE

          } // closing For Loop
          reset();

          if (existData.length > 0) {
            showErrorMessage("GroupId(s) " + existData + " is Already Exist in Assigned Groups.Please Select Another One");
          }
        } else {
          showErrorMessage("Select The Groups From Available Groups");
          //document.getElementsById("listAUserManagement").focus();
          return -1;
        }
      } else {
        showErrorMessage("Please Select The User First");
        document.getElementById("groupsForUserGroup").focus();
        reset();
      }
    };

    //Moving operation from Assigned Groups To Available Groups
    $scope.fromassignToAvailable = function() {
      beforeMove();
      var FirstCheck = $scope.selected_id;//document.getElementById("groupsForUserGroup").value;
      if (FirstCheck !== "") {
        if ($scope.selectedB.length > 0) {
          var i = 0;
          for (i in $scope.selectedB) {
            var moveId = arrayObjectIndexOf($scope.listB,$scope.selectedB[i], "groupId");
            $scope.listA.push($scope.listB[moveId]);
            var delId = arrayObjectIndexOf($scope.listB,$scope.selectedB[i], "groupId");
            $scope.listB.splice(delId, 1);
          }
          reset();
        } else {
          showErrorMessage("Select The Groups From Assigned Groups");
          return -1;
        }
      } // closing If FirstCheck
      else {
        showErrorMessage("Please Select The User First");
        document.getElementById("groupsForUserGroup").focus();  
      }
    };

    function reset() {
      $scope.selectedA = [];
      $scope.selectedB = [];
      $scope.toggle = 0;
    }

    function beforeMove() {
      $scope.one = false;
      $scope.two = false;
      $scope.checkCheckBox = false;
      $scope.checkCheckBoxB = false;

    }
    
    function resetLists(){
    	$scope.listA=[];$scope.listB=[];
    }
    
    //Selecting Users From Available Users
    $scope.toggleA = function() {
      var i = 0;
      if ($scope.checkCheckBox) {
        $scope.checkCheckBox = false;
        $scope.selectedA = [];
        $scope.one = false;
      } else {
        $scope.checkCheckBox = true;
        $scope.selectedA = [];
        for (i in $scope.listA) {
          $scope.selectedA.push($scope.listA[i].groupId);
        }
      }

    };
    
    //Array to store selected items from ListA / Available Users
    $scope.selectA = function(i) {
      $scope.one = false;
      var index = $scope.selectedA.indexOf(i);
      if (index > -1) {
        $scope.selectedA.splice(index, 1);
      } else {
        $scope.selectedA.push(i);
      }
    };

    
  //Selecting Users From Assigned Users
    $scope.toggleB = function() {
      var i = 0;
      if ($scope.checkCheckBoxB) {
        $scope.checkCheckBoxB = false;
        $scope.selectedB = [];
        $scope.two = false;
        for (i in $scope.listB) {
	         if(!$scope.listB[i].hasOwnProperty("status"))
	            $scope['changeToDisable'+$scope.listB[i].groupId] = {'border-bottom':'1px solid #ccc'};
	       }
      } else {
        $scope.checkCheckBoxB = true;
        $scope.selectedB = [];
        for (i in $scope.listB) {
          $scope.selectedB.push($scope.listB[i].groupId);
          $scope['changeToDisable'+$scope.listB[i].groupId] = {'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
        }
      }
    };

   
    
    //Array to store selected items from ListB / Assigned Users
    $scope.selectB = function(i) {
      $scope.two = false;
      var index = $scope.selectedB.indexOf(i);
      if (index > -1) {
        $scope.selectedB.splice(index, 1);
        $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc'};
      } else {
        $scope.selectedB.push(i);
        $scope['changeToDisable'+i]={'border-bottom':'1px solid #ccc','background-color':'rgb(243, 243, 243)','color':'black'};
      }
    };

	
}]);
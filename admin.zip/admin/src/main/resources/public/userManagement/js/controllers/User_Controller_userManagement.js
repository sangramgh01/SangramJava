zhapp.controller("User_Controller_userManagement",['$scope','$q','User_Service_userManagement','User_Validations_userManagement','$timeout','uiGridConstants',function($scope,$q,User_Service_userManagement,User_Validations_userManagement,$timeout,uiGridConstants) {
	$scope.userUserManagement={};
	$scope.copyiedData={};
	$scope.disableNotifications = true;
	$scope.userConfirmPassword='';

	//Un-comment below code when user Send Notiifcation is enabled as per higher authorities orders- Check with #12345 this code in this Page
	/*$scope.checkDisableing = function(thisValue) {
	      $scope.disableNotifications = !$scope.disableNotifications;

	      if ($scope.disableNotifications === false) {
	        $scope.myStyle = {
	          'background-color': 'white',
	          'border-radius': '5px',
	          'padding': '10px'
	        };
	      } else {
	        $scope.myStyle = {
	          'background-color': '#ccc',
	          'border-radius': '5px',
	          'padding': '10px'
	        };
	        $scope.userUserManagement.addUserObj.userInfo.approvalMandatory='N';
			$scope.userUserManagement.addUserObj.userInfo.sendNotification='N';
			$scope.userUserManagement.addUserObj.userInfo.allDepartments='N';
			$scope.userUserManagement.addUserObj.userNotification.listStatus='N';
			$scope.userUserManagement.addUserObj.userNotification.detailedReportStatus='N';
			$scope.userUserManagement.addUserObj.userNotification.campaignStatus='Disable';
			$scope.userUserManagement.addUserObj.userNotification.emailAddressList="";
	        //$scope.userUserManagement.addUserObj.userNotification.campaignStatus = 'Disable';
	        //$scope.userUserManagement.addUserObj = {};
	      }
	    };*/
	 
	var ifInActive='<div ng-class="{\'grey\':row.entity.status==\'I\' }"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }" ui-grid-cell></div></div>';	    
	$scope.gridOptions = {
			paginationPageSize: 15,
		    paginationPageSizes :[15,30,45],
		    enableFiltering: false,
		    enableColumnMenus: false,
		    onRegisterApi: function(gridApi){
		        $scope.gridApi = gridApi;
		      },
		    enableVerticalScrollbar: 0,
			enableHorizontalScrollbar: 0,
			rowTemplate:ifInActive,
		    columnDefs: [
		      { field:'userName', name: 'User Name'},
		      { field:'firstName', name: 'First Name' },
		      { field:'emailID',name: 'Email Address' },
		      { field:'middleName',name: 'Middle Name' },
		      { field:'lastName',name: 'Last Name' },
		      { field:'status', name: 'Status',
		    	  cellTemplate: '<div ng-if="row.entity.status==\'A\'">Active</div><div ng-if="row.entity.status==\'I\'">In-Active</div>'
		      },
		      {field: 'Actions',cellClass:'actioncell',
		    	cellTemplate: '<div><a href="javascript:void(0)"><img src="images/edit-icon.png" title="Edit" ng-click="grid.appScope.openEditDialog($parent.$parent.row.entity)"></a>',
		    		/*+
		    		'<a href="javascript:void(0)" ng-click="grid.appScope.deleteUserDialog($parent.$parent.row.entity)" ><img src="images/cancel.png" title="Delete" )"></a></div>',*/
		    		width: '60',enableSorting: false,enableFiltering: false,
		    		headerCellTemplate: '<div style="padding:2px;"><span>Actions</span><span><a href="javascript:void(0)"><img ng-click="grid.appScope.toggleFiltering()" src="images/filter.png" title="Filter" )"></a></span></div>'}
                        
		    ]
	};
	// To do Filtering
	$scope.toggleFiltering = function(){
	    $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
	    $scope.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
	};
	
	// Filtering Header
	$scope.filteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	    if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
	  };
	
	$scope.userUserManagement.listUsers=function(){
		var customerID=zhapp.loginUser.customerID;
		User_Service_userManagement.listCustomerUsers(customerID).success(function(result){
			$scope.allUsersDataBasedOnCustId=result;
			//If Mobile Number is havign 0 in result then making it as a Empty
			angular.forEach($scope.allUsersDataBasedOnCustId,function(userDetails){
				
				if(userDetails.userInfo != null && userDetails.userInfo != undefined && userDetails.userInfo != ""){
				 if(userDetails.userInfo.mobileNumber != null && userDetails.userInfo.mobileNumber != undefined && userDetails.userInfo.mobileNumber == 0)
					userDetails.userInfo.mobileNumber = "";
				}

			});
			
			$scope.$evalAsync(function(){ 
			$scope.gridOptions.data =$scope.allUsersDataBasedOnCustId;
			$scope.gridData=$scope.gridOptions.data;
			});
		}).error(function(result){
			showConfigurationErrorMessage(result.error[0]);
		});
		
	};
	
	
	 
	    $scope.listingCriteria={};
		$scope.listingCriteria.sortUsing='departmentname';
		$scope.listingCriteria.sortBy='ascending';
		$scope.listingCriteria.pageNumber=1;
		$scope.listingCriteria.pageSize=1000; 
		$scope.listingCriteria.nameLike;
		
		
		User_Service_userManagement.getAllDepartsments($scope.listingCriteria).success(function(result){	
		$scope.departmentLists_userManagement = result;
		}).error(function(result){
			showConfigurationErrorMessage(result.error[0]);
		});
		
		User_Service_userManagement.listGroups(zhapp.loginUser.customerID).success(function(result) {
	          $scope.groupsForUser= result; 
	        }).error(function(result) {
	          showConfigurationErrorMessage(result);
	        });
	
	
	//To Open Add User Pop
	$scope.isNewUserForm = true;
	$scope.userUserManagement.saveUserDialog=function(){  
		
		 if ($("#adminUserAdd").css('display') === 'none'){
			$scope.userUserManagement.addUserObj={};
			$scope.userUserManagement.addUserObj.userInfo={};
			$scope.userUserManagement.addUserObj.userNotification={};
			$scope.userUserManagement.addUserObj.userName='';
			$scope.userUserManagement.addUserObj.emailID='';
			$scope.userUserManagement.addUserObj.password='';
			$scope.userUserManagement.addUserObj.departmentID='';
			//document.getElementById('admin_user_txt_confirmPassword').value=null;
			$scope.userConfirmPassword="";
			$scope.userUserManagement.addUserObj.firstName='';
			$scope.userUserManagement.addUserObj.middleName='';
			$scope.userUserManagement.addUserObj.lastName='';			
			$scope.userUserManagement.addUserObj.timeZone='';
			$scope.userUserManagement.addUserObj.userInfo.approvalMandatory='N';
			$scope.userUserManagement.addUserObj.userInfo.sendNotification='N';
			$scope.userUserManagement.addUserObj.userInfo.mobileNumber='';
			$scope.userUserManagement.addUserObj.userInfo.allDepartments='N';
			$scope.userUserManagement.addUserObj.userNotification.listStatus='N';
			$scope.userUserManagement.addUserObj.userNotification.detailedReportStatus='N';
			$scope.userUserManagement.addUserObj.userNotification.campaignStatus='Disable';
			$scope.userUserManagement.addUserObj.userNotification.emailAddressList="";
			$scope.userUserManagement.addUserObj.groupID='';
			
			showDisableBack();
			$scope.isNewUserForm = true;
			$("#adminUserAdd").show();				
		 }
	};
	// To Save User Through Rest Call
	$scope.userUserManagement.addUser=function(){
		var confirmPassword=document.getElementById("admin_user_txt_confirmPassword").value;
		var passWordValidation = true ;
		var currentPassword=document.getElementById("admin_user_txt_password").value;
		$scope.userUserManagement.addUserObj.password=currentPassword;
		var canSave = User_Validations_userManagement.validateUserData($scope.userUserManagement.addUserObj,confirmPassword,passWordValidation);
		if(!canSave) 
			return;
		$scope.userUserManagement.addUserObj.customerID=zhapp.loginUser.customerID;
		$scope.userUserManagement.addUserObj.createdBy=zhapp.loginUser.userName;
		$scope.userUserManagement.addUserObj.updatedBy=zhapp.loginUser.userName;
		User_Service_userManagement.saveUser($scope.userUserManagement.addUserObj).success(function(){
					$("#adminUserAdd").hide();
					showInfoMessage("User created successfully");	
					hideDisableBack();
				$scope.userUserManagement.listUsers();
			}).error(function(error){
				//alert(error[0]);
				showConfigurationErrorMessage(error);
			});
	};//Closing Saving user through Rest Call
	
	//To Close Add User Pop up
	$scope.userUserManagement.closeAddUserDialog=function(){	
		document.getElementById('admin_user_txt_confirmPassword').value='';
		$("#adminUserAdd").hide();
		hideDisableBack();
	};
	
	//To open edit Dialogue
	$scope.openEditDialog=function(userUserManagement){
		
		$scope.isNewUserForm = false;
		$scope.userUserManagement.addUserObj = angular.copy(userUserManagement);
		$scope.copyiedData=angular.copy(userUserManagement);
		
		//Un-comment below code when user Send Notiifcation is enabled as per higher authorities orders - #12345
	 /*     if ($scope.userUserManagement.addUserObj.userInfo.sendNotification == '' || $scope.userUserManagement.addUserObj.userInfo.sendNotification == 'Y') {
	          $scope.myStyleUpdate = {
	            'background-color': 'white',
	            'border-radius': '5px',
	            'padding': '0px'
	          };
	          $scope.updateDisableNotifications = false;
	        } else {
	          $scope.myStyleUpdate = {
	            'background-color': '#ccc',
	            'border-radius': '5px',
	            'padding': '0px'
	          };
	          $scope.updateDisableNotifications = true;	         
	        } */ 
		$(".dialog-popup17").dialog('option', 'title',"Edit User");
		$(".dialog-popup17").dialog('option',"position", 'top');
		$(".dialog-popup17").dialog( "open" );
	};
	
	//Un-comment below code when user Send Notiifcation is enabled as per higher authorities orders - #12345
	
	/*$scope.checkDisableingForUpdate = function(thisValue) {
	      $scope.updateDisableNotifications = !$scope.updateDisableNotifications;
	      if ($scope.updateDisableNotifications == false) {
	        $scope.myStyleUpdate = {
	          'background-color': 'white',
	          'border-radius': '5px',
	          'padding': '10px'
	        };
	      } else {
	        $scope.myStyleUpdate = {
	          'background-color': '#ccc',
	          'border-radius': '5px',
	          'padding': '10px'
	        };      
	        $scope.userUserManagement.addUserObj.userInfo.approvalMandatory= $scope.copyiedData.userInfo.approvalMandatory;
			$scope.userUserManagement.addUserObj.userInfo.sendNotification= $scope.copyiedData.userInfo.sendNotification;
			$scope.userUserManagement.addUserObj.userInfo.allDepartments= $scope.copyiedData.userInfo.allDepartments;
			$scope.userUserManagement.addUserObj.userNotification.listStatus= $scope.copyiedData.userNotification.listStatus;
			$scope.userUserManagement.addUserObj.userNotification.detailedReportStatus= $scope.copyiedData.userNotification.detailedReportStatus;
			$scope.userUserManagement.addUserObj.userNotification.campaignStatus= $scope.copyiedData.userNotification.campaignStatus;
			$scope.userUserManagement.addUserObj.userNotification.emailAddressList= $scope.copyiedData.userNotification.emailAddressList;
			
	        $scope.userUserManagement.addUserObj.userInfo = $scope.copyiedData.userInfo;
	        $scope.userUserManagement.addUserObj.userNotification = $scope.copyiedData.userNotification;
	      }
	    };*/
	
	//Update User Method
	$scope.userUserManagement.updateUser = function() {    
		var passWordValidation=false;
		var canSave = User_Validations_userManagement.validateUserData($scope.userUserManagement.addUserObj,$scope.userUserManagement.addUserObj.password,passWordValidation);
		if(!canSave) 
			return;
      $scope.userUserManagement.addUserObj.customerID = zhapp.loginUser.customerID;//loginUser.customerID
      $scope.userUserManagement.addUserObj.updatedBy=zhapp.loginUser.userName;
      var updateUserObject = $scope.userUserManagement.addUserObj;
      delete updateUserObject.createdBy;
      delete updateUserObject.createDate;
      delete updateUserObject.updateDate;

      User_Service_userManagement.updateUser(updateUserObject).success(function() {    
    	  if (zhapp.loginUser.userName==updateUserObject.userName && updateUserObject.status=='I'){
          	showCommonConfirmMessage("User will logout now as login user deactivated.","Info","Ok",null,450,function(flag){
          		sessionStorage.clear();
  				navigateToPage('/Shibboleth.sso/Logout');
          	});
  		}else{
  			 showInfoMessage("User Updated successfully");
         	//$scope.groupUserManagement.addGroupObj={};
          	//$scope.groupUserManagement.listGroups();
          	$('.dialog-popup17').dialog('close');
          	hideDisableBack();
         	$scope.userUserManagement.listUsers();
  		}
      }).error(function(error) {
        showConfigurationErrorMessage(error);
      });

    }; //close edit/update group   
	
	// Delete pop up
	$scope.deleteUserDialog=function(userUserManagement){		
		$scope.userUserManagement.addUserObj=userUserManagement;
		showCommonConfirmMessage("Delete User?","Confirm","Yes","No",350,$scope.userUserManagement.deleteUser);
	};
	
	// Delete Operation
	$scope.userUserManagement.deleteUser=function(flag){
		if(flag){					
			User_Service_userManagement.deleteUser($scope.userUserManagement.addUserObj.userID).success(function(){
			showInfoMessage("User deleted successfully");
			$scope.userUserManagement.listUsers();
		}).error(function(error) {
	        showConfigurationErrorMessage(error);
	        //console.log($scope.userUserManagement.addUserObj.userID);
	      });
		}
	};
	
	$scope.eliminateGreateLesser=function(event){	
		if(event.shiftKey&&(event.keyCode===188||event.keyCode===190))	event.preventDefault();
	};
	
	$timeout(function(){
		removeConfigurationDialogsFromDom();
		initialzeConfigDialogs("ADMIN_USERMANAGEMENT");
	});
	
	
	 /** START: Time Zone */
    /** List of time zones to be displayed on the UI*/
    
    $scope.timeZoneData_userManagement = [{
      "regionid": "US/Samoa",
      "regionvalue": "(GMT -11:00) SST US/Samoa"
    }, {
      "regionid": "US/Hawaii",
      "regionvalue": "(GMT -10:00) HST US/Hawaii"
    }, {
      "regionid": "US/Alaska",
      "regionvalue": "(GMT -08:00) AKDT US/Alaska"
    }, {
      "regionid": "America/Los_Angeles",
      "regionvalue": "(GMT -07:00) PDT America/Los Angeles"
    }, {
      "regionid": "US/Arizona",
      "regionvalue": "(GMT -07:00) MST US/Arizona"
    }, {
      "regionid": "America/Denver",
      "regionvalue": "(GMT -06:00) MDT America/Denver"
    }, {
      "regionid": "America/Chicago",
      "regionvalue": "(GMT -05:00) CDT America/Chicago"
    }, {
      "regionid": "America/Caracas",
      "regionvalue": "(GMT -04:30) VET America/Caracas"
    }, {
      "regionid": "America/New_York",
      "regionvalue": "(GMT -04:00) EDT America/New York"
    }, {
      "regionid": "America/Sao_Paulo",
      "regionvalue": "(GMT -03:00) BRT America/Sao Paulo"
    }, {
      "regionid": "America/Noronha",
      "regionvalue": "(GMT -02:00) FNT America/Noronha"
    }, {
      "regionid": "Atlantic/Azores",
      "regionvalue": "(GMT)AZOST Atlantic/Azores"
    }, {
      "regionid": "Europe/London",
      "regionvalue": "(GMT +01:00) BST Europe/London"
    }, {
      "regionid": "Africa/Cairo",
      "regionvalue": "(GMT +02:00) EET Africa/Cairo"
    }, {
      "regionid": "Europe/Paris",
      "regionvalue": "(GMT +02:00) CEST Europe/Paris"
    }, {
      "regionid": "Europe/Moscow",
      "regionvalue": "(GMT +03:00) MSK Europe/Moscow"
    }, {
      "regionid": "Asia/Muscat",
      "regionvalue": "(GMT +04:00) GST Asia/Muscat"
    }, {
      "regionid": "Asia/Karachi",
      "regionvalue": "(GMT +05:00) PKT Asia/Karachi"
    }, {
      "regionid": "Asia/Calcutta",
      "regionvalue": "(GMT +05:30) IST Asia/Calcutta"
    }, {
      "regionid": "Asia/Dhaka",
      "regionvalue": "(GMT +06:00) BDT Asia/Dhaka"
    }, {
      "regionid": "Asia/Bangkok",
      "regionvalue": "(GMT +07:00) ICT Asia/Bangkok"
    }, {
      "regionid": "Australia/Perth",
      "regionvalue": "(GMT +08:00) AWST Australia/Perth"
    }, {
      "regionid": "Japan",
      "regionvalue": "(GMT +09:00) JST Japan"
    }, {
      "regionid": "Australia/Sydney",
      "regionvalue": "(GMT +11:00) AEDT Australia/Sydney"
    }, {
      "regionid": "Pacific/Noumea",
      "regionvalue": "(GMT +11:00) NCT Pacific/Noumea"
    }, {
      "regionid": "Asia/Kamchatka",
      "regionvalue": "(GMT +12:00) PETT Asia/Kamchatka"
    }];
	
}]);
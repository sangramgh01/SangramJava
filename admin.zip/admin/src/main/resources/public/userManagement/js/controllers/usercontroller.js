function userController($scope,$q,userManagementService,UserValidationsService){
	$scope.user = {};
	$scope.user.userId = 0;
	$scope.user.selectedDepartmentCount = 0;
	$scope.userDeptSearch = {};
	//$scope.user.toolAccessList = [{name:'Conversation',value:'Conversations',checked:'N'},{name:'Approvals',checked:'N',value:'Approvals'},{name:'Deployments',checked:'N',value:"Deployment (Sending of a Conversation)"},
	//	{name:'Message Contents',checked:'N',value:"Message Content"},{name:'Web Pages',checked:'N',value:"Web Pages"},{name:'Lists',checked:'N',value:"Lists"},{name:'Reports',checked:'N',value:"Reports"},{name:'Admin',checked:'N',value:"Admin Settings"}];
	function listDepartments(){
		var q = $q.defer();
		 var listingCriteria={};
		listingCriteria.sortUsing='departmentname';
		listingCriteria.sortBy='ascending';
		userManagementService.listDepartments(listingCriteria).success(function(result){
			$scope.user.departmentList = result;
			initializeSlimScroll();
			q.resolve();
		}).error(function(error){
			q.reject();
		});
		return q.promise;
	};
	
	function initializeSlimScroll(){
		$('.user-dept-list-container').slimScroll({
 			color: '#a9a9a9',
 			size: '8px',
 			wheelStep:1,
 			railVisible: true,
 			alwaysVisible: false
 		});	
	};
	
	
	$scope.user.saveOrUpdate = function(){
		if($scope.user.userId != 0){
			updateUser();
		}else{
			createUser();
		}
	};
	
	function updateUser(){
		var userBO = prepareUserBO();
		var canSave = UserValidationsService.validateUserData(userBO,$scope.user.departmentList);
		if(!canSave){
			return;
		}
		userManagementService.updateUser(userBO).success(function(result){
			showInfoMessage("user updated successfully.");
			$scope.$parent.adminModule.templateSrc="userManagement/templates/listusers.html";
		}).error(function(error){
			showErrorMessage($scope.user.getErrorMessages(error));
		});
	};
	
	function createUser(){
		var userBO = prepareUserBO();
		var canSave = UserValidationsService.validateUserData(userBO,$scope.user.departmentList);
		if(!canSave){
			return;
		}
		userManagementService.createUser(userBO).success(function(result){
			showInfoMessage("user created successfully.");
			$scope.$parent.adminModule.templateSrc="userManagement/templates/listusers.html";
		}).error(function(error){
			showErrorMessage($scope.user.getErrorMessages(error));
		});
	};
	
	function prepareUserBO(){
		var userBO = $scope.userBO?$scope.userBO:{};
		var userInfo = userBO.userInfo?userBO.userInfo:{};
		var list = "";
		angular.forEach($scope.user.toolAccessList,function(obj){
			if(obj.checked == 'Y'){
				list = list+','+obj.toolname;
			}
		});
		list = list.substring(1);
		userInfo.rules = list;
		list = '';
		angular.forEach($scope.user.departmentList,function(obj){
			if(obj.checked == 'Y'){
				list = list+","+obj.departmentID;
			}
		});
		userInfo.mobileNumber = $scope.user.mobileNumber;
		userBO.userInfo = userInfo;
		list = list.substring(1);
		userBO.listDepts = list;
		userBO.customerID = zhapp.loginUser.customerID;
		userBO.custCode = zhapp.loginUser.custCode;
		return userBO;
	};
	
	$scope.user.selectAllToolAccessChanged = function(){
		if($scope.user.toolAccessSelectAll == 'Y')
			angular.forEach($scope.user.toolAccessList,function(obj){obj.checked = 'Y'});
		else
			angular.forEach($scope.user.toolAccessList,function(obj){obj.checked = 'N'});
	};
	
	$scope.user.toolAccessChanged = function(){
		var flag = isAllObjectsSelected($scope.user.toolAccessList);
		$scope.user.toolAccessSelectAll = flag ? 'Y' : 'N';
	};
	
	function isAllObjectsSelected(list){
		var flag = true;
		angular.forEach(list,function(obj){
			if(obj.checked != 'Y'){
				flag = false;
			}
		});
		return flag;
	};
	
	$scope.user.selectAllDeptChanged = function(){
		if($scope.user.deptSelectAll == 'Y'){
			angular.forEach($scope.user.departmentList,function(obj){obj.checked = 'Y'});
			$scope.user.selectedDepartmentCount = $scope.user.departmentList.length;
		}
		else{
			angular.forEach($scope.user.departmentList,function(obj){obj.checked = 'N'});
			$scope.user.selectedDepartmentCount = 0;
		}
			
	};
	
	$scope.user.selectDeptChanged = function(){
		var flag = true;
		var count = 0;
		angular.forEach($scope.user.departmentList,function(obj){
			if(obj.checked != 'Y'){
				flag = false;
			}else if(obj.checked == 'Y')
				count++;
		});
		$scope.user.deptSelectAll = flag ? 'Y' : 'N';
		$scope.user.selectedDepartmentCount = count;
	};
	
	function isCreateUserDataProvided(){
		 var temp = $.grep($scope.user.toolAccessList,function(obj){return obj.checked == 'Y'});
			if(temp.length > 0){
				return true;
			}
			var departmentList = $.grep($scope.user.departmentList,function(obj){return obj.checked == 'Y'});
			if(departmentList.length > 0){
				return true;
			}
		if(!$scope.userBO){
			return false;
		}
		if($scope.userBO.userName){
			return true;
		}else if($scope.userBO.emailID){
			return true;
	    }else if($scope.userBO.firstName){
		   return true;
        }else if($scope.userBO.middleName){
	       return true;
        }else if($scope.userBO.lastName){
	       return true;
        }else if($scope.user.mobileNumber){
	       return true;
        }else if($scope.userBO.timeZone){
	      return true;
        }
       
		return false;
	};
	
	$scope.user.cancelUser = function(){
            var userIDData = $scope.UsrObj;
            var userBO = prepareUserBO();
		var flag = false;
		if($scope.user.userId == 0){
			if(isCreateUserDataProvided()){
				flag = true;
			}
		}else{
			var userIDData = $scope.UsrObj;
            userIDData.custCode = zhapp.loginUser.custCode;
			var userBO = prepareUserBO();
			var DeptUserBO = $scope.userBO;
			if(!angular.equals(userIDData,DeptUserBO)|| !angular.equals(userBO.listDepts,userIDData.listDepts)){
				flag = true;
			}
		}
		if(flag){
			showCommonConfirmMessage("Do you want save User?","Alert","Yes","No",450,function(flag) {
				 if(flag){
	                   $scope.user.saveOrUpdate().then(function(){
	                	   $scope.$parent.adminModule.templateSrc="userManagement/templates/listusers.html";
	                   });
	             }else
	                   $scope.$parent.adminModule.templateSrc="userManagement/templates/listusers.html";     
	        });
		}else
		$scope.$parent.adminModule.templateSrc="userManagement/templates/listusers.html";
	};
	
	function prepareEditUserData(userData){
		$scope.user.userId = userData.userID;
		$scope.userBO = userData;
		$scope.user.mobileNumber = userData.userInfo.mobileNumber;
		if(userData.userInfo.rules){
			angular.forEach(userData.userInfo.rules.split(','),function(obj){
				angular.forEach($scope.user.toolAccessList,function(tObj){
					if(tObj.toolname == obj){
						tObj.checked = 'Y';
					}
				});
			});
			$scope.user.toolAccessChanged();
		}
		if(userData.listDepts){
			angular.forEach(userData.listDepts.split(','),function(obj){
				angular.forEach($scope.user.departmentList,function(tObj){
					if(tObj.departmentID == obj){
						tObj.checked = 'Y';
					}
				});
			});
			$scope.user.selectDeptChanged();
		}
	};
	
	function getUserDataById(userId){
		var defer = $q.defer();
		userManagementService.getUserByID(userId).success(function(result){
			$scope.UsrObj=angular.copy(result);
			defer.resolve(result);
		}).error(function(error){
			defer.reject();
		});
		return defer.promise;
	};
	
	$scope.user.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = error.error;
    	}
    	return msg;
    }
	
	function getAccessToolsList(){
		var d = $q.defer();
		userManagementService.getAccessToolsList().success(function(result){
			$scope.user.toolAccessList = result;
			d.resolve();
		}).error(function(error){
			showErrorMessage($scope.user.getErrorMessages(error));
			d.reject();
		});
	};
	
	
	function init(){
		var promise = [];
		promise.push(listDepartments());
		promise.push(getAccessToolsList());
		$q.all(promise).then(function(){
			var userData = userManagementService.userData;
			if(userData && userData.userID){
				getUserDataById(userData.userID).then(function(userData){
					prepareEditUserData(userData);
				},function(error){
					showErrorMessage($scope.user.getErrorMessages(error));
				});
			}
			userManagementService.userData = undefined;
		});
	};
	init();
	
	$scope.user.timeZoneList = [{
	      "regionid": "US/Samoa",
	      "regionvalue": "(GMT -11:00) SST US/Samoa"
	    }, {
	      "regionid": "US/Hawaii",
	      "regionvalue": "(GMT -10:00) HST US/Hawaii"
	    }, {
	      "regionid": "US/Alaska",
	      "regionvalue": "(GMT -08:00) AKDT US/Alaska"
	    }, {
	      "regionid": "America/Los_Angeles",
	      "regionvalue": "(GMT -07:00) PDT America/Los Angeles"
	    }, {
	      "regionid": "US/Arizona",
	      "regionvalue": "(GMT -07:00) MST US/Arizona"
	    }, {
	      "regionid": "America/Denver",
	      "regionvalue": "(GMT -06:00) MDT America/Denver"
	    }, {
	      "regionid": "America/Chicago",
	      "regionvalue": "(GMT -05:00) CDT America/Chicago"
	    }, {
	      "regionid": "America/Caracas",
	      "regionvalue": "(GMT -04:30) VET America/Caracas"
	    }, {
	      "regionid": "America/New_York",
	      "regionvalue": "(GMT -04:00) EDT America/New York"
	    }, {
	      "regionid": "America/Sao_Paulo",
	      "regionvalue": "(GMT -03:00) BRT America/Sao Paulo"
	    }, {
	      "regionid": "America/Noronha",
	      "regionvalue": "(GMT -02:00) FNT America/Noronha"
	    }, {
	      "regionid": "Atlantic/Azores",
	      "regionvalue": "(GMT)AZOST Atlantic/Azores"
	    }, {
	      "regionid": "Europe/London",
	      "regionvalue": "(GMT +01:00) BST Europe/London"
	    }, {
	      "regionid": "Africa/Cairo",
	      "regionvalue": "(GMT +02:00) EET Africa/Cairo"
	    }, {
	      "regionid": "Europe/Paris",
	      "regionvalue": "(GMT +02:00) CEST Europe/Paris"
	    }, {
	      "regionid": "Europe/Moscow",
	      "regionvalue": "(GMT +03:00) MSK Europe/Moscow"
	    }, {
	      "regionid": "Asia/Muscat",
	      "regionvalue": "(GMT +04:00) GST Asia/Muscat"
	    }, {
	      "regionid": "Asia/Karachi",
	      "regionvalue": "(GMT +05:00) PKT Asia/Karachi"
	    }, {
	      "regionid": "Asia/Calcutta",
	      "regionvalue": "(GMT +05:30) IST Asia/Calcutta"
	    }, {
	      "regionid": "Asia/Dhaka",
	      "regionvalue": "(GMT +06:00) BDT Asia/Dhaka"
	    }, {
	      "regionid": "Asia/Bangkok",
	      "regionvalue": "(GMT +07:00) ICT Asia/Bangkok"
	    }, {
	      "regionid": "Australia/Perth",
	      "regionvalue": "(GMT +08:00) AWST Australia/Perth"
	    }, {
	      "regionid": "Japan",
	      "regionvalue": "(GMT +09:00) JST Japan"
	    }, {
	      "regionid": "Australia/Sydney",
	      "regionvalue": "(GMT +11:00) AEDT Australia/Sydney"
	    }, {
	      "regionid": "Pacific/Noumea",
	      "regionvalue": "(GMT +11:00) NCT Pacific/Noumea"
	    }, {
	      "regionid": "Asia/Kamchatka",
	      "regionvalue": "(GMT +12:00) PETT Asia/Kamchatka"
	    }];
	
};

userController.$inject = ['$scope','$q','userManagementService','UserValidationsService'];
zhapp.controller("userController",userController);
zhapp.controller("listUserController",['$scope','$rootScope','$filter','userManagementService',function($scope,$rootScope,$filter,userManagementService){
	
	$scope.userHome = {};
	$scope.userHome.showFilter = false;
	$scope.userHome.searchUserName = '';
	$scope.userHome.StatusList = [{name:'Select All',value:''},{name:'Active',value:'A'},{name:'Inactive',value:'I'}];
	$scope.userHome.gridOptions = {
	        paginationPageSize: 25,
	        paginationPageSizes: [10, 25, 50],
	        enableFiltering: false,
	        enableColumnMenus: false,
	        onRegisterApi: function(gridApi) {
	          $scope.userHome.gridApi = gridApi;
	        },
	        headerRowHeight: 40,
	        enableVerticalScrollbar: 1,
		    enableHorizontalScrollbar: 0,
	        columnDefs: [
	        	{ field:'action',name:'',cellTemplate: '<div id="admin_usrManagement_search_edit_{{$parent.$parent.row.entity.userName}}" class="gridEditUserColumn"><i data-ng-click="grid.appScope.userHome.editUser($parent.$parent.row.entity)"></i></div>',width:'30',enableSorting:false},
	            { field: 'userName',name: 'User Name',sort: {direction: 'asc',priority: 0,icon:'gridEmptyClass'},sortDirectionCycle:['asc','desc'],headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div class="ui-grid-cell-contents" id="admin_usrManagement_view_{{col.colDef.field}}" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"> {{COL_FIELD CUSTOM_FILTERS}}</div>'},
	            { field: 'emailID',name: 'Email Address',sortDirectionCycle:['asc','desc'],headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div class="ui-grid-cell-contents" id="admin_usrManagement_view_{{col.colDef.field}}" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"> {{COL_FIELD CUSTOM_FILTERS}}</div>'},
	            { field: 'firstName',name: 'First Name',sortDirectionCycle:['asc','desc'],headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div class="ui-grid-cell-contents" id="admin_usrManagement_view_{{col.colDef.field}}" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"> {{COL_FIELD CUSTOM_FILTERS}}</div>'},
	            {field: 'middleName',name: 'Middle Name',sortDirectionCycle:['asc','desc'],headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div class="ui-grid-cell-contents" id="admin_usrManagement_view_{{col.colDef.field}}" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"> {{COL_FIELD CUSTOM_FILTERS}}</div>'},
	            {field: 'lastName',name: 'Last Name',sortDirectionCycle:['asc','desc'],headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div class="ui-grid-cell-contents" id="admin_usrManagement_view_{{col.colDef.field}}" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"> {{COL_FIELD CUSTOM_FILTERS}}</div>'},
	            {field: 'status',name: 'Status',headerCellTemplate:'userManagement/templates/headerCellTemplate.html',cellTemplate:'<div id="admin_usrManagement_view_{{co1l.colDef.field}}" class="ui-grid-cell-contents" ng-class="{ \'userGrisRowFade\': $parent.$parent.row.entity.status!=\'A\' }"><i data-ng-if="$parent.$parent.row.entity.status==\'A\'">Active</i><i data-ng-if="$parent.$parent.row.entity.status==\'I\'">Inactive</i></div>',sortDirectionCycle:['asc','desc']},
	        ]
	        //rowTemplate :  '<div><div ng-class="{ \'userGrisRowFade\': row.entity.status!=\'A\' }" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div></div>'
	      };
	
	
	$scope.userHome.editUser = function(data){
		 $rootScope.activeMenuItem = 'Edit User Settings';
		 $rootScope.userMgmtIdFlag='edit';
		userManagementService.userData = data;
		$scope.$parent.adminModule.templateSrc = 'userManagement/templates/createoredituser.html';
	};
	
	$scope.userHome.navigateToNewUser = function(){
		  $rootScope.activeMenuItem = 'New User Settings';
		  $rootScope.userMgmtIdFlag='new';
		$scope.$parent.adminModule.templateSrc = 'userManagement/templates/createoredituser.html';
	};
	
	function loadUsersList(){
		var listingCriteria = {};
		listingCriteria.sortBy = 'asc';
		listingCriteria.sortUsing = 'username';
		listingCriteria.customerId = zhapp.loginUser.customerID;
		$rootScope.activeMenuItem = 'Users';
		userManagementService.getusersList(listingCriteria).success(function(result){
			result = $filter('orderBy')(result,'userName');
			$scope.userHome.gridOptions.data = result;
		}).error(function(error){
			showErrorMessage($scope.userHome.getErrorMessages(error));
		});
	};
	
	$scope.userHome.searchUserByFilter = function(){
		if($scope.userHome.filterCriteria){
			$scope.userHome.filterCriteria.customerId = zhapp.loginUser.customerID;
			userManagementService.filterUserList($scope.userHome.filterCriteria).success(function(result){
				$scope.userHome.gridOptions.data = result;
				$scope.userHome.showFilter = false;
				sessionStorage.setItem('filterCriteria',JSON.stringify($scope.userHome.filterCriteria));
			}).error(function(error){
				showErrorMessage($scope.userHome.getErrorMessages(error));
			});
		}
	};
	
	$scope.userHome.serachUserByName = function(){
		if(!$scope.userHome.searchUserName){
			loadUsersList();
		}else{
			var filterCriteria = {};
			filterCriteria.UserName = $scope.userHome.searchUserName;
			filterCriteria.customerId = zhapp.loginUser.customerID;
			userManagementService.filterUserList(filterCriteria).success(function(result){
				$scope.userHome.gridOptions.data = result;
			}).error(function(error){
				showErrorMessage($scope.userHome.getErrorMessages(error));
			});
		}
	};
	
	$scope.userHome.getErrorMessages = function(error){
    	var msg = undefined;
    	if(error.errors){
			angular.forEach(error.errors,function(result){
	    		if(msg == undefined){
	    			msg = result.message;
	    		}else{
	    			msg= msg+"<br>"+result.message;
	    		}
	    	});
    	}else if(error.error){
    		msg = error.error;
    	}
    	return msg;
    };
    
    $scope.userHome.searchUsersByName = function(){
    	if (event.type == "click" || event.keyCode == 13) {
            if (!$scope.userHome.searchUserName || $scope.userHome.searchUserName.length == 0) {
                showErrorMessage("Please Enter user name to search");
                return false;
            }
            $scope.userHome.serachUserByName();
    	}else{
    		var temp = $(".search-container input")[0] ? $($(".search-container input")[0]).val():null;
    		if(!temp || (temp && temp.length == 0))
    			loadUsersList();
    	}
    };
    
    $scope.userHome.getAllUsers = function(){
    	loadUsersList();
    };
    
    $scope.userHome.clearFilterCriteria = function(){
    	$scope.userHome.filterCriteria={};
    	sessionStorage.removeItem('filterCriteria');
    	$scope.userHome.getAllUsers();
    };
    
	
	function init(){
		if(sessionStorage.getItem('filterCriteria')){
			$scope.userHome.filterCriteria = JSON.parse(sessionStorage.getItem('filterCriteria'));
			$scope.userHome.searchUserByFilter();
		}else
			loadUsersList();
	};
	
	$rootScope.$on('reLoadUsersList',function(event){
		init();
	});
	
	$scope.userHome.assignHeightToGrid = function(){
		var height = $(window).height() - $(".action-container").height();
		$(".usercustomgrid").height(height - 115);
	};
	
	init();
}]);
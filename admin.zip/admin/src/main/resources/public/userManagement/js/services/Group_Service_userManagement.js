zhapp.factory('Group_Service_userManagement', ['$http', function($http) {
    return {
    	listGroups: function(customerID) {	
    		
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getGroupsBycustId/'+ customerID,     
            });   
        },
        addGroup: function(groupData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/saveGroup',
                data:groupData,
            });
        },
        updateGroup: function(updateData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/updateGroup',
                data:updateData,
            });
        },
        deleteGroup: function(deleteID) {	
        	return $http({
                method: 'DELETE',
                url: zhapp.security_host+'/deleteGroup/'+ deleteID,     
            });
        }
    }
}]);
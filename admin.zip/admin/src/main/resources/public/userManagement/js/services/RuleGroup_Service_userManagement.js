zhapp.factory('RuleGroup_Service_userManagement', ['$http', function($http) {
    return {
    	getAllGroups: function(customerID) {	
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getGroupsBycustId/'+ customerID,     
            });  
        },
        
        RuleGroupListRulesBasedOncustCode: function(custCode) {		     
                return $http({
                    method: 'GET',
                    url: zhapp.security_host+'/getRulesBycustCode/'+ custCode,     
                });
          },    
    
        RulesWithGroupId: function(selectedId) {	
        	return $http({
                method: 'GET',
                url: zhapp.security_host+'/getRuleUserByGroupId/'+selectedId,     
            });
      },
      
      Delete: function(selectedId) {	
          return $http({
              method: 'DELETE',
              url: zhapp.security_host+'/deleteRuleGroup/'+ selectedId,     
          });
        },
        
        Assign: function(assignData) {	
            return $http({
            	 method: 'POST',
                 url: zhapp.security_host+'/saveMultiGroupRule',
                 data:assignData,
                
            });
          }
      
    }
}]);
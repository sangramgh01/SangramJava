zhapp.factory('RuleUser_Service_userManagement', ['$http', function($http) {
    return {
    	getAllUsersForRuleUser: function(customerID) {	
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getUsersBycustId/'+ customerID,     
            });
        },
    
    /*UsersWithId: function(selectedId,customerID) {	
        return $http({
            method: 'GET',
            url: zhapp.security_host+'/getUsersByRuleIDandCustID/'+selectedId+','+customerID,     
        });
      },*/
      RuleUserListRulesBasedOncustCode: function(custCode) {		       
              return $http({
                  method: 'GET',
                  url: zhapp.security_host+'/getRulesBycustCode/'+ custCode,     
              });
        },      
      Delete: function(selectedId) {	
          return $http({
              method: 'DELETE',
              url: zhapp.security_host+'/deleteRuleUser/'+ selectedId,     
          });
        },
        
        Assign: function(assignData) {	
            return $http({
            	 method: 'POST',
                 url: zhapp.security_host+'/saveMultiUserRule',
                 data:assignData,
                
            });
          },
          
        RulesWithUsersID:function(userID) {	
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getRulesByUserID/'+ userID,     
            });
        }
      
    }
}]);
zhapp.factory('Rule_Service_userManagement', ['$http', function($http) {
    return {
    	listRulesBasedOncustCode: function(custCode) {	       
            return $http({
                method: 'GET',
                url: zhapp.security_host+'/getRulesBycustCode/'+ custCode,     
            });
        },
        listResources: function(customerID) {	       
            return $http({
                method: 'GET',
                url: zhapp.security_host+'/getAllResourcesByCustomerId/'+ customerID,     
            });
        },
        listAccessTypes: function(customerID) {	       
            return $http({
                method: 'GET',
                url: zhapp.security_host+'/getAllAccesstypesByCustomerId/'+ customerID,     
            });
        },
        addRule: function(ruleData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/saveRule',
                data:ruleData,
            });
        },
        updateRule: function(updateData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/updateRule',
                data:updateData,
            });
        },
        deleteRule: function(deleteID) {	
            return $http({
                method: 'DELETE',
                url: zhapp.security_host+'/deleteRule/'+ deleteID,     
            });
        }
    }
}]);
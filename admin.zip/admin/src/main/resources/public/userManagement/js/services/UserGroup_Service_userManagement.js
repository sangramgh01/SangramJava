zhapp.factory('UserGroup_Service_userManagement', ['$http', function($http) {
    return {
    	getAllGroups: function(customerID) {	
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getGroupsBycustId/'+ customerID,     
            });   
        },
        GetAllUsers: function(customerID) {	
        	return $http({
                method: 'GET',
                url: zhapp.security_host+'/getUsersBycustId/'+ customerID,     
            });
        },
        GroupsWithUserID: function(selectedId) {	
        return $http({
            method: 'GET',
            url: zhapp.security_host+'/getGroupsByUserId/'+ selectedId,     
        });
      },
      
      Delete: function(selectedId) {	
          return $http({
              method: 'DELETE',
              url: zhapp.security_host+'/deleteUserGroup/'+ selectedId,     
          });
        },
        
        Assign: function(assignData) {	
            return $http({
            	 method: 'POST',
                 url: zhapp.security_host+'/saveMultiUserGroupWithGroupIds',
                 data:assignData,
                
            });
          }
      
    }
}]);
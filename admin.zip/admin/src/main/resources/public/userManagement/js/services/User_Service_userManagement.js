zhapp.factory('User_Service_userManagement', ['$http', function($http) {
    return {
    	/*listUsers: function(ListingCriteria) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/getAllUsers',
                data:ListingCriteria,
            });
        },*/
        
        saveUser: function(userData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/saveUser',
                data:userData,
            });
        },
        updateUser: function(userUpdateData) {	
            return $http({
                method: 'POST',
                url: zhapp.security_host+'/updateUser',
                data:userUpdateData,
            });
        },
        deleteUser: function(deleteID) {	
            return $http({
                method: 'DELETE',
                url: zhapp.security_host+'/deleteUser/'+ deleteID,     
            });
        },
        listCustomerUsers:function(custID) {	
        	 return $http({
                 method: 'GET',
                 url: zhapp.security_host+'/getUsersBycustId/'+ custID,     
             });
        },
        getAllDepartsments: function(listingCriteria) {	
        	return $http({
                method: 'POST',
                url: 'listDepartments',
                data: listingCriteria
            });
        },
        listGroups: function(customerID) {	
    		return $http({
                method: 'GET',
                url: zhapp.security_host+'/getGroupsBycustId/'+ customerID,     
            });   
        },
        
    }
}]);
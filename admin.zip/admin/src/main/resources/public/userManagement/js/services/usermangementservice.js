zhapp.factory('userManagementService', ['$http', function($http) {
	var UserData = undefined;
    return {
    	listDepartments: function(listingCriteria) {
            return $http({
                method: 'POST',
                url: 'getAllDepartments',
                data: listingCriteria
            });
        },
        
        createUser : function(userBO){
        	return $http({
        		method : 'POST',
        		url: zhapp.security_host+'/saveUser',
        		data:userBO
        	});
        },
        
        updateUser : function(userBO){
        	return $http({
        		method : 'POST',
        		url: zhapp.security_host+'/updateUser',
        		data:userBO
        	});
        },
        
        getusersList : function(listingCriteria){
        	return $http({
        		method: 'POST',
        		url: zhapp.security_host+'/getAllUsers',
        		data:listingCriteria
        	});
        },
        
        getUserByID : function(userId){
        	return $http({
        		method: 'GET',
        		url: zhapp.security_host+'/getUserByID/'+userId
        	});
        },
        
        filterUserList : function(filterCriteria){
        	return $http({
        		method:'POST',
        		url : zhapp.security_host+'/searchUsers',
        		data:filterCriteria
        	});
        },
        
        getAccessToolsList : function(){
        	return $http({
        		method:'GET',
        		url : zhapp.security_host+'/getToolList'
        	});
        }
    }
}]);
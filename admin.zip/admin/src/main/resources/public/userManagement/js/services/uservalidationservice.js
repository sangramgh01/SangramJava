zhapp.factory('UserValidationsService',[ function() {
	var obj = {};
	obj.validateUserData = function(userData, departmentList) {
		// Validate UserName
		if (userData.userName == undefined
				|| userData.userName == ""
				|| userData.userName.length == 0) {
			showErrorMessage("Username shouldn't be empty");
			return false;
		} else if (userData.userName.length > 200) {
			showErrorMessage("User name should be less than 200 characters");
			return false;
		} else if (userData.userName.length < 2) {
			showErrorMessage("Username is shorter than the minimum allowed length.This must be atleast 2 characters long");
			return false; 
		}else if (/\s/g.test(userData.userName)) {
			showErrorMessage('User name should not contain white spaces');
			return false;
		} else if (/[^a-zA-Z0-9_]/.test(userData.userName)) {
			showErrorMessage('User name should be alphanumeric');
			return false;
		}

		// Validate Email
		var verifyEmail = userData.emailID;
		if(verifyEmail){
			/*var atpos = verifyEmail.indexOf("@");
			var dotpos = verifyEmail.lastIndexOf(".");
			if (verifyEmail === "" && verifyEmail === undefined) {
				showErrorMessage("Please enter your Email Address.");
				return false;
			} else if (atpos < 1 || dotpos < atpos + 2
					|| dotpos + 2 >= verifyEmail.length) {
				showErrorMessage("\'" + verifyEmail
						+ "\' is not a valid Email Address");
				return false;
			}*/
			
			var mailPattren = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
			if(!mailPattren.test(verifyEmail)){
				showErrorMessage(verifyEmail+" Email Address is not valid");
				return false;
			}
			
		}else{
			showErrorMessage("Please enter your Email Address.");
			return false;
		}

		

		// Validation For Department
		var flag = false;
		angular.forEach(departmentList, function(obj) {
			if (obj.checked == 'Y') {
				flag = true;
			}
		});
		if (!flag) {
			showErrorMessage("Select atleast one department");
			return false;
		}

		// Validate First Name
		if (userData.firstName == ""
				|| userData.firstName == undefined) {
			showErrorMessage('First Name should not be empty');
			return false;
		}

		if (/[^a-zA-Z0-9 ]/.test(userData.firstName)) {
			showErrorMessage('First Name Should Be Alphanumeric');
			return false;
		}
		
		if (userData.firstName && userData.firstName.length > 20) {
			showErrorMessage("First Name should be less than 20 characters");
			return false;
		}

		if (userData.lastName == ""
				|| userData.lastName == undefined) {
			showErrorMessage('last Name should not be empty');
			return false;
		}
		if (userData.lastName !== "") {
			if (/[^a-zA-Z0-9 ]/.test(userData.lastName)) {
				showErrorMessage('Last Name Should Be Alphanumeric');
				return false;
			}
		}
		
		if (userData.lastName && userData.lastName.length > 20) {
			showErrorMessage("Last Name should be less than 20 characters");
			return false;
		}
		
		if (userData.middleName && userData.middleName.length > 20) {
			showErrorMessage("Middle Name should be less than 20 characters");
			return false;
		}
		
			// Validate Mobile
		var phoneno = /([0-9+-])+[0-9]$/;
        var onlydigits = /^\d+$/;
        var mobileno = String(userData.userInfo.mobileNumber).replace(/[^0-9]/g, '');
        if (userData.userInfo.mobileNumber != "" && userData.userInfo.mobileNumber != undefined) {
        	 if (phoneno.test(userData.userInfo.mobileNumber) || onlydigits.test(userData.userInfo.mobileNumber)) {
                 if(mobileno.length< 10){
                                 showErrorMessage("Mobile Number Must Have Minimum 10 Digits");
                                 return false;
                 }
        	 } else {
                 showErrorMessage("Mobile Number Is Not Valid ");
                 return false;
        	 }
        } 
				

			// Time Zone Validation
			if (userData.timeZone == ""
					|| userData.timeZone == undefined
					|| userData.timeZone.length == 0) {
				showErrorMessage("Please select the Time-Zone");
				return false;
			}
			return true;
		}
		return obj;
}]);
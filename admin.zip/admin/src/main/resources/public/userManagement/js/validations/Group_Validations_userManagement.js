zhapp.factory('Group_Validations_userManagement', [function() {
	var obj={};
	obj.validateGroupData = function(groupData){
		
		if (groupData.groupName == undefined ||groupData.groupName == "" || groupData.groupName.length == 0) {
	          showInfoMessage("Group Name shouldn't be empty");
	          return false;
	        } else if (groupData.groupName.length > 51) {
	          showInfoMessage("Group Name should be less than 50 characters");
	          return false;
	        } else if (/[^a-zA-Z0-9\s]/.test(groupData.groupName)) {
	          showInfoMessage('Group Name Should Be Alphanumeric');
	          return false;
	        }
		return true;
	}
	return obj;

}]);
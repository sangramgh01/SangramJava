zhapp.factory('Rule_Validations_userManagement', [function() {
	var obj={};
	obj.validateRuleData = function(ruleData){
		
		if (ruleData.resource == undefined || ruleData.resource  == "" || ruleData.resource.length===0) {
			showErrorMessage("Please select the Resource");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          }
		
		if (ruleData.accessType == undefined || ruleData.accessType  == "" || ruleData.accessType.length===0) {
			showErrorMessage("Please select the Access Type");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          }
	    
		//Uncomment Below Code When Higher officials said to active adding RULE in Usermanagement
		
		/*if (ruleData.operator == undefined || ruleData.operator  == "" || ruleData.operator.length===0) {
			showErrorMessage("Please select the Operator");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          }
		
		if (ruleData.sourceAttributeName == undefined || ruleData.sourceAttributeName == "" || ruleData.sourceAttributeName.length===0) {
			showErrorMessage("Source Attribute Name shouldn't be empty");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          } else if (ruleData.sourceAttributeName.length > 101) {
        	  showErrorMessage("Source Attribute Name should be less than 100 characters");
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          } else if (/[^a-zA-Z0-9\s]/.test(ruleData.sourceAttributeName)) {
        	  showErrorMessage('Source Attribute Name Should Be Alphanumeric');
            //document.getElementById("ruleSourceAttributeName").focus();
            return false;
          }
		if (ruleData.targetAttributeName == undefined || ruleData.targetAttributeName == "" || ruleData.targetAttributeName.length===0) {
			showErrorMessage("Target Attribute Name shouldn't be empty");
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } else if (ruleData.targetAttributeName.length > 101) {
        	  showErrorMessage("Target Attribute Name should be less than 100 characters");
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } else if (/[^a-zA-Z0-9\s]/.test(ruleData.targetAttributeName)) {
        	  showErrorMessage('Target Attribute Name Should Be Alphanumeric');
            //document.getElementById("ruleTargetAttributeName").focus();
            return false;
          } */
		
		if(ruleData.startDate == ""){
			showErrorMessage("Please select start date");
	    	  //document.getElementById("ruleStartDate").focus(); 
	    	  return false; 
	      }
		
		if(ruleData.endDate == ""){
			showErrorMessage("Please select end date");
	    	  //document.getElementById("ruleStartDate").focus(); 
	    	  return false; 
	      }
		
		if(ruleData.startDate > ruleData.endDate){
	    	  showErrorMessage("END DATE Should Not Be Less Than START DATE");
	    	  return false;
	      }
		
		if(angular.equals(ruleData.startDate,ruleData.endDate)){
	    	  showErrorMessage("START DATE & END DATE Should Not Be Same");
	    	  return false;
	      }
		
		return true;
	}
	return obj;

}]);
zhapp.factory('User_Validations_userManagement', [function() {
	var obj={};
	obj.validateUserData = function(userData,confirmPassword,PasswordValidation){ //upDateCheck - Check Whether it is Update or not to Avoid Passwoprd Validation in Updation..?
		
		//Validate UserName
		if (userData.userName == undefined || userData.userName == "" || userData.userName.length == 0) {
	        showErrorMessage("Username shouldn't be empty");
	        return false;
	      } else if (userData.userName.length > 201) {
	        showErrorMessage("User Name should be less than 200 characters");
	        return false;
	      } else if (/\s/g.test(userData.userName)) {
	        showErrorMessage('User Name Should NOT contain White spaces');
	        return false;
	      } else if (/[^a-zA-Z0-9_]/.test(userData.userName)) {
	        showErrorMessage('User Name Should Be Alphanumeric');
	        return false;
	      } 
		
		//Validate Email 
		  var verifyEmail = userData.emailID;
	      var atpos = verifyEmail.indexOf("@");
	      var dotpos = verifyEmail.lastIndexOf(".");

	      if (verifyEmail === "") {
	        showErrorMessage("Please enter your Email Address.");
	        return false;
	      } else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= verifyEmail.length) {
	    	  showErrorMessage("\'" + verifyEmail + "\' is not a valid Email Address");
	        return false;
	      }
	      
	      
	    //Password Validation
	      if(PasswordValidation == true){
	      if(userData.password == '' || userData.password == undefined){
	    	  showErrorMessage("Password should not be empty");
	            return false;
	      }
	      else if (userData.password.length < 8) {
	            showErrorMessage("Password must have 8 Characters");
	            return false;
	          } else if (userData.password.replace(/[^0-9]/g, "").length < 2) {
	            showErrorMessage("Password Must have 2 Numeric Numbers");
	            return false;
	          } else if (userData.password.replace(/[^#?!@$%^&*-./`,;[\]{\}\"()\|=_+~]/g, "").length < 2) {
	            showErrorMessage("Password Must have 2 Special Characters");
	            return false;
	          } else if (userData.password.replace(/[^A-Z]/g, "").length < 1) {
	            showErrorMessage("Password Must have 1 Uppercase Letter");
	            return false;
	          } 
	          else if (userData.password.includes(userData.userName)) {
		        showErrorMessage("Password should not contain Username.");
		        return false;
		      }
	          else if(confirmPassword=='' || confirmPassword == undefined || confirmPassword.lemgth == 0){
	        	showErrorMessage("Please confirm your password");
	        	return false;
	          }
	          else if (userData.password != confirmPassword) {
	            showErrorMessage("Password didn't match.");
	            return false;
	          }
	      }
	        
	      //Validation For Department
	        if(userData.departmentID == "" || userData.departmentID == undefined){
	        	  showErrorMessage('Please select department name');
	        	  return false;
		       }
	        
	       //Validation For Group Selection
	        if(PasswordValidation == true){ //Password Validation is not required in Updation.and Also Group Validation is not required.Hence,using Passowrd Validation Token For Group Validation
	        if(userData.groupID == "" || userData.groupID == undefined){
	        	showErrorMessage('Please select group name');
	        	  return false;
	        	}
	        }
	                
	      //Validate First Name
	        if(userData.firstName == "" || userData.firstName == undefined ){
	        	showErrorMessage('First Name should not be empty');
	            return false;
	        }
	        
	        if (/[^a-zA-Z0-9 ]/.test(userData.firstName)) {
	            showErrorMessage('First Name Should Be Alphanumeric');
	            return false;
	          }
	        
	        if (userData.middleName !== "") {
	            if (/[^a-zA-Z0-9 ]/.test(userData.middleName)) {
	              showErrorMessage('Middle Name Should Be Alphanumeric');
	              return false;
	            } 
              }
	        
	        if (userData.lastName !== "") {
	            if (/[^a-zA-Z0-9 ]/.test(userData.lastName)) {
	              showErrorMessage('Last Name Should Be Alphanumeric');
	              return false;
	            }
	        }
	        
	      
	      // Validate Mobile 
	      var phoneno = /^\d{10,12}$/;
	      
	      if (userData.userInfo.mobileNumber != "" && userData.userInfo.mobileNumber != undefined) {
	    	if (String(userData.userInfo.mobileNumber).match(phoneno)) {
	        } else {
	          showErrorMessage("Mobile Number Must Have Minimum 10 Digits");
	          //showErrorMessage("Please Enter 10 Digit Mobile Number");
	          //document.getElementById("userMobielNumber").focus();
	          return false;
	        }
	      } 
	      
	    //Time Zone Validation
	        if ( userData.timeZone == "" || userData.timeZone == undefined || userData.timeZone.length == 0) {
		        showErrorMessage("Please Select The Time-Zone");
		        return false;
		      }

	       /*
	        * send Notifications is disabled as of now.Enable this Validation When Send Notifiactions Feature is released 
	        *  
	        if (userData.userInfo.sendNotification == 'Y') {
	            if (userData.userNotification.emailAddressList != "") {
	            	var emailArray = userData.userNotification.emailAddressList.split(",");
	            	for (var i = 0; i < emailArray.length; i++) {
	                    var j = checkEmailOrNot(emailArray[i]);
	                if (j === false) {
	                  showErrorMessage("\'" + emailArray[i] + "\' is not a valid Email Address in Email Address List");
	                  //document.getElementById("allEmailAddressList").focus();
	                  return false;
	                  break;
	                } else {
	                  continue;
	                }
	              }//for loop
	            } // if loop
	        }//main if loop
         */	       
	        
	        
		
		return true;
	}
	return obj;
	
/*   
 * Enable this function When Send Notifiactions Feature is released 
 * 
 *  function checkEmailOrNot(checkEmailID) {
        var verifyEmail = checkEmailID
        var atpos = verifyEmail.indexOf("@");
        var dotpos = verifyEmail.lastIndexOf(".");
        
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= verifyEmail.length) {
          return false;
        } 
    }*/

}]);
package com.zetaintaractive.zetahub.admin.expression.controller

import org.springframework.util.LinkedMultiValueMap
import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.ExpressionBO

class ExpressionControllerTest extends Specification{
	@Shared
	String url

	@Shared
	RestTemplate restTemplate;

	@Shared
	ExpressionBO expressionBo

	def "init for test methods"() {
		given:
		expressionBo=new ExpressionBO();
		restTemplate = new RestTemplate();
		buildExpression();
		url = "http://localhost:8100/expression/";
	}

	void buildExpression() {
		Map returnValue=new HashMap();
		returnValue.put("type","String")
		expressionBo.setDepartmentID(1);
		expressionBo.setExpressionDSL("SUBSTRING('ZETA',1,2)")
		expressionBo.setName("spocktest63724")
		expressionBo.setCreatedBy("zh17")
		expressionBo.setExpressionType("C".charAt(0));
		expressionBo.setReturnvalue(returnValue)
		expressionBo.setStatus("A".charAt(0))
		expressionBo.setInputParams(new ArrayList());
	}

	def "Creating or Updating expression"() {
		given:

		def response

		def localUrl=url+"saveExpression"
		when:
		response=restTemplate.postForEntity(localUrl,expressionBo,Object.class)
		expressionBo = (ExpressionBO)response.getBody()
		expressionBo.setExpressionID(expressionBo.getExpressionID());
		expressionBo.setName(expressionBo.getName());
		then:
		response!=null

		printf "response for the method save Expreesion===========>"+response;
	}

	def "getting All Expressions"() {
		given:
		Map<String,String> searchCriterai=new LinkedHashMap<>();
		searchCriterai.put("sortby","createdate");
		searchCriterai.put("sortorder","DESC");
		searchCriterai.put("pageno","1");
		searchCriterai.put("pagesize","12");

		def response
		def localUrl=url+"getAllExpressions"
		when:
		response=restTemplate.postForEntity(localUrl,searchCriterai,Object.class);
		then:
		response!=null
		printf "response for the method getting All Expressions===========>"+response
	}

	def "validate Expression"() {
		given:

		def map= new LinkedMultiValueMap<String, String>();
		map.add("expression", "tttttttttttttttttt");
		def response
		def localUrl=url+"validateExpression"
		when:
		response=restTemplate.postForEntity(localUrl,map,Object.class);
		then:
		response!=null
		printf "response for the method validate Expression===========>"+response
	}

	def "Getting Expression by Name"() {
		given:
		def response
		def localUrl=url+"getExpressionByName/"+expressionBo.getName();
		when:
		response=restTemplate.getForEntity(localUrl,Object.class);
		then:
		response!=null
		printf "response for the method Getting Expression by Name===========>"+response
	}

	def "delete Expression by Expression id"() {
		given:
		def response

		def localUrl=url+"deleteExpression"+ "/"+expressionBo.getExpressionID();
		when:
		response=restTemplate.delete(localUrl,Object.class);
		then:
		response!=false
		printf "response for the method delete Expression by Expression id===========>"+response
	}
}

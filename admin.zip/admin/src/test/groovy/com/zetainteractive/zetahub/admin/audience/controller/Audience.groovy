/**
 * Audience.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.controller

import java.sql.Timestamp

import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.admin.audience.constants.Constants
import com.zetainteractive.zetahub.commons.domain.AudienceBO
import com.zetainteractive.zetahub.commons.domain.AudienceKeyColumnsBO
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria
import com.zetainteractive.zetahub.commons.domain.DimensionColumnMappingBO
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO

/**
 * 
 * @Author	   : Dilleswara.Doppa
 * @Created on : Jul 14, 2016 12:18:45 PM
 * @Version	   : 1.7
 * @Description: "Audience" is used for 
 * 
 **/
class Audience extends Specification{

	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	@Shared
	AudienceBO audienceBO;
	@Shared
	LogicalTableBO logicalTableBO;

	def "init for test methods"() {
		given:
		audienceBO=new AudienceBO();
		restTemplate = new RestTemplate();
		url = "http://localhost:8100/audience/";
	}
	void buildAudience() {
		Timestamp createDate = new Timestamp(System.currentTimeMillis());
		println "date  : "+createDate
		audienceBO.setAudienceName("Hotel_Audience_119sas");
		audienceBO.setDepartmentId(1);
		audienceBO.setAudienceType(0);
		audienceBO.setAudienceStatus("N".charAt(0));
		audienceBO.setCreatedBy("uk2");
		audienceBO.setCreatedDate(createDate);
		audienceBO.setUpdatedBy("uk2");
		audienceBO.setUpdatedDate(createDate);
		logicalTableBO=new LogicalTableBO();
		DimensionColumnMappingBO dimensionColumnMappingBO=new DimensionColumnMappingBO();
		LogicalColumnBO logicalColumnBO=new LogicalColumnBO();
		logicalColumnBO.setLogicalColumnName("Audience_uk");
		logicalColumnBO.setPhysicalColumnName("Audience_uk");
		logicalColumnBO.setIsProfilable("N".charAt(0));
		logicalColumnBO.setColumnDataType(2);
		logicalColumnBO.setIsKeyColumn("N".charAt(0));
		List<LogicalColumnBO> LogicalColumnlist=new ArrayList<>();
		LogicalColumnlist << logicalColumnBO
		logicalTableBO.setLogicalColumns(LogicalColumnlist);
		dimensionColumnMappingBO.setBaseLogicalColumnName("New");
		dimensionColumnMappingBO.setDimensionColumnName("New_Aud");
		List<DimensionColumnMappingBO> dimlist=new ArrayList<>();
		dimlist << dimensionColumnMappingBO
		logicalTableBO.setDimensionColumnMappings(dimlist);
		List<LogicalTableBO> logicalTablelist=new ArrayList<LogicalTableBO>();
		logicalTableBO.setLogicalTableName("Audience");
		logicalTableBO.setPhysicalTableId(1);
		logicalTableBO.setTableType(1);
		logicalTablelist << logicalTableBO
		audienceBO.setLogicalTables(logicalTablelist);
	}
	def "save audience method"() {
		println "Setup:start save audience method"
		given:
		def status
		def retValue
		buildAudience()
		def localUrl = url + "saveAudience";
		when:
		retValue = restTemplate.postForEntity(localUrl,audienceBO,AudienceBO.class);

		audienceBO=(AudienceBO)retValue.getBody();
		then:
		retValue!=null
		println "Setup:End save audiencemetada method:::"+retValue
	}
	def "find  by audience name  method"() {
		given:
		def retValue
		def localUrl = url + 'findAudienceByName/{audienceName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,AudienceBO.class, audienceBO.getAudienceName());
		then:
		println "Setup:End find logical columns and table name method:::"
	}
	def "find by id audience  method"() {
		given:
		def retValue
		def localUrl = url + 'findAudienceById/{audienceId}';
		when:
		retValue=restTemplate.getForEntity(localUrl,AudienceBO.class, audienceBO.getAudienceId());
		then:
		println "Setup:End save audiencemetada method:::"+retValue.getBody()
	}
	def "update audience method "() {
		println "Setup:start update audience method"
		given:
		def retValue
		def localUrl = url + 'updateAudience';
		when:
		retValue=restTemplate.postForEntity(localUrl,audienceBO,Boolean.class,audienceBO.getAudienceId());
		then:
		println "Setup:End update columntype method"
	}
	def "find logical columns by audience id method"() {
		given:
		def retValue
		Map<String,String> requestParams = new HashMap<String,String>()
		requestParams.put("audienceId",audienceBO.getAudienceId());
		requestParams.put("physicalTableId",1);
		requestParams.put("logicalTableName","Audience");
		def localUrl = url + '/getLogicalColumnsByAudienceIdAndTableName/{audienceId}/{physicalTableId}/{logicalTableName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,AudienceBO[].class,requestParams);
		then:
		println "Setup:End find logical columns method:::"
	}
	def "find logical columns by audience Id and physical table id method"() {
		given:
		def retValue
		Map<String,String> requestParams = new HashMap<String,String>()
		requestParams.put("audienceId",audienceBO.getAudienceId());
		requestParams.put("physicalTableId",1);
		def localUrl = url + '/getLogicalColumnsByAudienceIdAndPhyTableId/{audienceId}/{physicalTableId}';

		when:
		retValue=restTemplate.getForEntity(localUrl,AudienceBO[].class,requestParams);
		then:
		println "Setup:End find logical columns method:::"+retValue.getBody()
	}
	def "find logical columns by audience Id and physical table id and logical table namemethod"() {
		given:
		def retValue
		Map<String,String> requestParams = new HashMap<String,String>()
		requestParams.put("audienceId",audienceBO.getAudienceId());
		requestParams.put("physicalTableId",1);
		requestParams.put("logicalTableName","Audience");
		def localUrl = url + 'getLogicalColumnsByAudienceIdAndTableName/{audienceId}/{physicalTableId}/{logicalTableName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,AudienceBO[].class,requestParams);
		then:
		println "Setup:End find logical columns method:::"+retValue.getBody()
	}
	def "find by criteria"() {
		given:
		AudienceSearchCriteria listCriteria=new AudienceSearchCriteria();
		listCriteria.setSortUsing("audiencename");
		listCriteria.setSortBy("asc");
		listCriteria.setPageNumber(1);
		listCriteria.setPageSize(7);
		listCriteria.setNameLike("Sms");
		listCriteria.setNameEquals("Sms Audience");
		listCriteria.setAudienceType("System");
		listCriteria.setColumnNames(Constants.AUDIENCE_COLUMNS);
		def localUrl = url + '/findAudiencesByCriteria';
		def retValue
		when:
		retValue = restTemplate.postForEntity(localUrl,listCriteria,AudienceSearchCriteria[].class);
		then:
		println "Setup:End find logical columns method:::"+retValue.getBody()
	}
	def "list All Audience"() {
		given:
		def response;
		def localUrl=url+"listAudience"
		when:
		response=restTemplate.getForEntity(localUrl,AudienceBO[].class);
		then:
		response!=null
		println "Response for The Method list All Audience==============> "+response
	}
	def "Is Audience Exist"() {
		given:
		def response;
		def localUrl=url+"isAudienceExist/{audienceName}"
		when:
		response=restTemplate.getForEntity(localUrl,Boolean.class,audienceBO.getAudienceName());
		then:
		response!=null
		println "Response For The method is audience exist by Name=================> "+response.getBody()
	}
	def "is Audience Exist with AudienceName and AudienceId"() {
		given:
		def response
		def localUrl=url+"isAudienceExistWithNameAndID/"+audienceBO.getAudienceName()+"/"+audienceBO.getAudienceId()
		when:
		response=restTemplate.getForEntity(localUrl,Boolean.class);
		then:
		response!=null
		println "Response==================>"+response.getBody()
	}
	def "get LogicalTable By AudienceId And LogicalTableName"() {
		given:
		def response
		def logicalTableName=audienceBO.getLogicalTables()[0].getLogicalTableName();
		//def logicalColumns=logicaltables.indexOf(0);
		def localUrl=url+"getLogicalTableByAudIdAndLTableName/"+audienceBO.getAudienceId()+"/"+logicalTableName
		when:

		response=restTemplate.getForEntity(localUrl,LogicalTableBO.class);
		then:
		response !=null
		println "Response==================>"+response.getBody();
	}
	def "get Logical Column Base By AudienceID"() {
		given:
		def response
		def localUrl=url+"getLogicalColumnsBaseByAudienceId/{audienceId}"
		when:
		response=restTemplate.getForEntity(localUrl,LogicalColumnBO[].class,audienceBO.getAudienceId());
		then:
		response!=null
		println "Response==================>"+response.getBody()
	}
	def "fetching And Checking LogicalColumnsUsage"() {
		given:
		def resposne
		def localUrl=url+"fetchingAndCheckingLogicalColumnsUsage/{audienceIds}"
		when:
		resposne=restTemplate.getForEntity(localUrl,Object.class,audienceBO.getAudienceId());
		then:
		resposne !=null
		println "Response For the Method==================>"+resposne.getBody()
	}


	def "Find Audience Total Count"() {
		given:
		AudienceSearchCriteria listCriteria=new AudienceSearchCriteria();
		listCriteria.setSortUsing("audiencename");
		listCriteria.setSortBy("asc");
		listCriteria.setPageNumber(1);
		listCriteria.setPageSize(7);
		listCriteria.setNameLike("Sms");
		listCriteria.setNameEquals("Sms Audience");
		listCriteria.setAudienceType("System");
		listCriteria.setColumnNames(Constants.AUDIENCE_COLUMNS);
		def response
		def localUrl=url+"findAudiencesTotalCount"
		when:
		response=restTemplate.postForEntity(localUrl,listCriteria,Long.class);
		then:
		response!=null
		println "Response===============>"+response.getBody()
	}
	def "get Audience Data by Table and Column"() {
		given:
		def response
		def localUrl=url+"getAudienceDataByLTableAndLColumn/"+audienceBO.getAudienceId()+"/"+audienceBO.getLogicalTables()[0].getTableType()+"/"+audienceBO.getLogicalTables()[0]+"/"+audienceBO.getLogicalTables()[0].getLogicalColumns()
		when:

		response=restTemplate.getForEntity(localUrl,Object.class);
		then:
		response!=null
		println "Resposne=============>"+response.getBody();
	}

	def "delete audience method"() {
		println "Setup:start delete audience method"
		given:
		def retValue
		def localUrl = url + 'deleteAudience/{audienceId}';
		when:
		retValue=restTemplate.delete(localUrl,audienceBO.getAudienceId());
		then:
		println "Setup:End find all audience method::"+retValue
	}
}

/**
 * Audience.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.controller

import java.sql.Timestamp

import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.ColumnTypeModelBO

class AudienceColumnTypeModel extends Specification{

	@Shared
	String url	
	@Shared
	RestTemplate restTemplate;
	@Shared
	ColumnTypeModelBO columnTypeModelBO;
	
	def "init for test methods"()
	{
		given:
			 buildColumnType();
			 restTemplate = new RestTemplate();
			 url = "http://localhost:8100/audienceColumnType/";
	}
	void buildColumnType()
	{
		columnTypeModelBO=new ColumnTypeModelBO();
		Timestamp createDate = new Timestamp(System.currentTimeMillis());
		columnTypeModelBO.setColumnType("STRINGG");
		columnTypeModelBO.setColumnValue("STRING");
		columnTypeModelBO.setColumnDataType(12);
		columnTypeModelBO.setDataBaseType("VERTICA");
		columnTypeModelBO.setCreatedBy("zh17");
		columnTypeModelBO.setCreatedDate(createDate);
		columnTypeModelBO.setUpdatedBy("zh17");
		columnTypeModelBO.setUpdatedDate(createDate);
	}
	def "save columntype method "()
	{
		println "Setup:start save columntype method"
		given:
		def retValue
		buildColumnType()
		def localUrl = url + 'saveColumnType';
		when:
		retValue = restTemplate.postForEntity(localUrl,columnTypeModelBO, Long.class);
		columnTypeModelBO.setColumnTypeId(retValue.getBody());
		then:
		retValue!=null
		println "Setup:End save columntype method"
	}
	def "update columntype method "()
	{
		println "Setup:start update columntype method"
		given:
		def retValue
		def localUrl = url + 'updateColumnType';
		when:
		retValue = restTemplate.put(localUrl,columnTypeModelBO, Boolean.class, "");
		then:
		println "retValue::::::::::::::::::::"+retValue 
		println "Setup:End update columntype method"
	}
	def "find all columntype method"()
	{
		println "Setup:start find all columntype method"
		given:
		def retValue
		def localUrl = url + 'findAllColumnTypes';
		when:
		ResponseEntity<ColumnTypeModelBO[]> Columntypevalue=restTemplate.getForEntity(localUrl, ColumnTypeModelBO[].class,"");
		then:
			Columntypevalue != null && Columntypevalue.getBody().size()>0 ;
		println "Setup:End find all columntype method::"+Columntypevalue
	}
	def "find by id columntype  method"()
	{
		println "Setup:start find all columntype method"
		given:
		def retValue
		def localUrl = url + 'findColumnTypeById/'+columnTypeModelBO.getColumnTypeId();
		when:	
		retValue=restTemplate.getForEntity(localUrl,ColumnTypeModelBO.class);
		then:
		println "Setup:End find by id columntype method::"+retValue
	}
	def "delete columntype  method "()
	{
		println "Setup:start delete columntype method"
		given:
		def localUrl=url+'deleteColumnType/'+columnTypeModelBO.getColumnTypeId();
		when:
		restTemplate.delete(localUrl);
		then:
		println "Setup:End find all columntype method::"
	}
}

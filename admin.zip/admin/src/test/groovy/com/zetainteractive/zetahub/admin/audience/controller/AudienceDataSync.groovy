/**
 * AudienceDataSync.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.controller

import org.springframework.web.client.RestTemplate;

import spock.lang.Shared;
import spock.lang.Specification

class AudienceDataSync extends Specification {
	
	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	def audienceId =296
	def requestType='sync'
	def departmentId=1
	
	def "init for test methods"()
	{
		given:
		    
			 restTemplate = new RestTemplate();
			 url = "http://localhost:8100/";
	}
	
	
	def "system Audience Data Sync method"(){
		println "Setup:system audience data sync"
		given:
		def retValue
		def localUrl = url + "systemAudienceDataSync/"+requestType+"/"+departmentId
		println ""+localUrl
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue!=null
			println "Setup:End sync profile columns method:::"+retValue
		 
	}
	
	def "sync profile columns method"()
	{
		println "Setup:start sync profile columns method"
		given:
			def status
			def retValue
			def localUrl = url + 'syncProfileColumns/{audienceId}';
		when:
			retValue = restTemplate.getForEntity(localUrl,Object.class,audienceId);
		then:
			retValue!=null
			println "Setup:End sync profile columns method:::"
	}

}

/**
 * AudienceMataData.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.audience.controller

import java.sql.Timestamp

import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.ColumnStatCountBO
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO

/**
 * 
 * @Author	   : Dilleswara.Doppa
 * @Created on : Jul 14, 2016 12:18:10 PM
 * @Version	   : 1.7
 * @Description: "AudienceMataData" is used for 
 * 
 **/
class AudienceMataData  extends Specification{

	@Shared
	String url

	@Shared
	RestTemplate restTemplate;

	@Shared
	PhysicalTableBO physicalTableBO;

	def "init for physical tables"() {
		given:
		physicalTableBO=new PhysicalTableBO();
		restTemplate = new RestTemplate();
		buildAudienceMetaData()
		url = "http://localhost:8100/physicalTables/";
	}
	void buildAudienceMetaData() {
		Timestamp createDate = new Timestamp(System.currentTimeMillis());
		println "date  : "+createDate
		physicalTableBO.setPhysicalTableName("Spock_Test_Audience12");
		physicalTableBO.setDataSourceId(1);
		physicalTableBO.setSchemaName("NewSchema");
		physicalTableBO.setTableType("R");
		physicalTableBO.setCreatedBy("zh17");
		physicalTableBO.setCreatedDate(createDate);
		physicalTableBO.setUpdatedBy("zh17");
		physicalTableBO.setUpdatedDate(createDate);
		PhysicalColumnBO physicalColumnBO=new PhysicalColumnBO();
		ColumnStatCountBO columnStatCountBO=new ColumnStatCountBO();
		columnStatCountBO.setStatValue("New");
		columnStatCountBO.setStatCount(2);
		List<ColumnStatCountBO> columnStatCountlist=new ArrayList<>();
		columnStatCountlist << columnStatCountBO
		physicalColumnBO.setColumnStatCounts(columnStatCountlist);
		physicalColumnBO.setPhysicalColumnName("Audience_spock");
		physicalColumnBO.setOleDbtype("Audience_spock");
		physicalColumnBO.setColumnDataType(1);
		physicalColumnBO.setColumnDataLength(2);
		physicalColumnBO.setIsNullable("N".charAt(0));
		physicalColumnBO.setColumnDefaultValue("Audience_spock");
		List<PhysicalColumnBO> physicalColumnlist=new ArrayList<>();
		physicalColumnlist << physicalColumnBO
		physicalTableBO.setPhysicalColumns(physicalColumnlist);
	}

	def "Save physical table details"() {
		println "Setup:start save audiencemetada method"
		given:
			def status
			def retValue
			
		def localUrl = url + '/savePhysicalTable';
		when:
			retValue = restTemplate.postForEntity(localUrl,physicalTableBO,Long.class, "");
		then:
			retValue!=null
			physicalTableBO.setPhysicalTableId(retValue.getBody());
			println "Setup:End save audiencemetada method:::"+retValue.getBody()
	}
	def "Find physical table details by physical table name"() {
		given:
		def retValue
		def localUrl = url + '/findPhysicalTableByName/{physicalTableName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,PhysicalTableBO.class, physicalTableBO.getPhysicalTableName());
		then:
		retValue!=null
		println "Setup:End save audiencemetada method:::"+retValue.getBody()
	}
	def "Find physical table details by physical table id"() {
		given:
		def retValue
		def localUrl = url + 'findPhysicalTableById/'+physicalTableBO.getPhysicalTableId();
		when:
		retValue=restTemplate.getForEntity(localUrl,PhysicalTableBO.class);
		then:
		retValue!=null
		println "Setup:End save audiencemetada method:::"+retValue.getBody()
	}

	def "Update physical table details by physical table id"() {
		println "Setup:start update audiencemetada method"
		given:
		def retValue
		def localUrl = url + 'updatePhysicalTable';
		when:
		retValue=restTemplate.postForEntity(localUrl,physicalTableBO,Boolean.class,physicalTableBO.getPhysicalTableId());
		then:
		println "retValue::::::::::::::::::::"+retValue
		println "Setup:End update audiencemetada method"
	}
	def "Find all physical tables"() {
		println "Setup:start find all audience method"
		given:
		def retValue
		def localUrl = url + 'listPhysicalTables';
		when:
		ResponseEntity<PhysicalTableBO[]> audiencevalue=restTemplate.getForEntity(localUrl,PhysicalTableBO[].class,"");
		then:
		audiencevalue !=null && audiencevalue.getBody().size()>0;
		println "Setup:End find all audience metadata method::"+audiencevalue
	}
	def "Find staging tables"() {
		println "Setup:start find all audience method"
		given:
		def retValue
		def localUrl = url + 'findStagingTables';
		when:
		ResponseEntity<PhysicalTableBO[]> audiencevalue=restTemplate.getForEntity(localUrl,PhysicalTableBO[].class,"");
		then:
		println "Setup:End find all audience metadata method::"+audiencevalue
	}
	def "Find physical tables not mapped in Audiences Tables"() {
		println "Setup:start delete audience metadata method"
		given:
		def retValue
		def localUrl = url + '/findPhysicalTablesNotMappedInAudiences';
		when:
		ResponseEntity<PhysicalTableBO[]> audiencevalue=restTemplate.getForEntity(localUrl,PhysicalTableBO[].class,"");
		then:
		println "Setup:End delete audience metadata method::"+audiencevalue
	}

	def "find Physical Tables For Dimensions In Audiences method"(){
		println "Setup:start get Stats Counts List method"
		given:
		def retValue
		def localUrl = url + "findPhysicalTablesForDimensionsInAudiences";
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
		println "Setup:start get Stats Counts List method"+retValue
	}
	def "get Status Count List method"(){
		println "Setup:start get Stats Counts List method"
		given:
		def retValue
		def localUrl = url + "getStatCountsList/"+physicalTableBO.getPhysicalTableId()+"/"+physicalTableBO.getPhysicalColumns()
		when:
		retValue = restTemplate.getForEntity(localUrl,ColumnStatCountBO[].class);
		then:
		println "Setup:start get Stats Counts List method"
	}
	def "Delete physical table details by physical table id"() {
		println "Setup:start delete audience metadata method"
		given:
		def retValue
		def localUrl = url + '/deletePhysicalTable/{physicalTableId}';
		when:
		retValue=restTemplate.delete(localUrl,physicalTableBO.getPhysicalTableId());
		then:
		println "Setup:End delete audience metadata method::"+retValue
	}
}

/**
 * ConfigurationControllerTest.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller

import java.sql.Timestamp

import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.AddressTypeBO
import com.zetainteractive.zetahub.commons.domain.DbSourceBO
import com.zetainteractive.zetahub.commons.domain.DomainBO
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO
import com.zetainteractive.zetahub.commons.domain.FileSourceBO
import com.zetainteractive.zetahub.commons.domain.FolderBO
import com.zetainteractive.zetahub.commons.domain.RestrictedDomainsBO

class ConfigurationControllerTest extends Specification{
	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	@Shared
	EncryptionKeyBO encryptionKeyBO;
	@Shared
	FolderBO folderBO;
	@Shared
	FileSourceBO fileSourceBO;
	@Shared
	AddressTypeBO addressTypeBO;
	@Shared
	RestrictedDomainsBO restrictedDomainsBO;
	@Shared
	DomainBO domainBO;
	@Shared
	DbSourceBO dbSourceBO;
	def "init for configuration table"()
	{
		given:
			 encryptionKeyBO=new EncryptionKeyBO();
			 restTemplate = new RestTemplate();
			 url = "http://localhost:7092/";
	}
	def "get  department"()
	{
		given:
			def status
			def retValue
		def localUrl = url + '/listfileEncryptions';
		when:
			retValue=restTemplate.getForEntity(localUrl,EncryptionKeyBO[].class, "");
		then:
			retValue!=null
	}
	def "create file Source"()
	{
		given:
			def status
			def retValue
			short port=22;
			fileSourceBO=new FileSourceBO();
			fileSourceBO.setHostname("10.219.28.61");
			fileSourceBO.setPort(port);
			fileSourceBO.setProtocol("sftp");
			fileSourceBO.setUsername("zetamail700");
			fileSourceBO.setPassword("bGVvJDEyMw==");
			fileSourceBO.setFileSourceName("fs10");
			fileSourceBO.setCreatedBy("adminUser");
			def localUrl = url + '/createFileSource';
		when:
			retValue = restTemplate.postForEntity(localUrl,fileSourceBO,Long.class);
		then:
			retValue!=null
			
	}
	def "list DB Sources"()
	{
		given:
			def status
			def retValue
			def localUrl = url + '/listDBSources';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO[].class, "");
		then:
			retValue!=null
	}
	def "list file sources"()
	{
		given:
			def status
			def retValue
			def localUrl = url + '/listFileSources';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO[].class, "");
		then:
			retValue!=null
	}
	def "get file source"()
	{
		given:
			def status
			def retValue
			String FileSourceName="fs11";
			def localUrl = url + '/getFileSource/{fileSourceName}';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO.class,FileSourceName);
		  
		then:
			retValue!=null
	}
	def "list address types"()
	{
		given:
			def status
			def retValue
			String FileSourceName="fs11";
			def localUrl = url + '/listAddressTypes';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO[].class,"");
		  
		then:
			retValue!=null
	}
	def "list restricted domains"()
	{
		given:
			def status
			def retValue
			def localUrl = url + '/listRestrictedDomains';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO.class,"");
		  
		then:
			retValue!=null
	}
	def "list domains"()
	{
		given:
			def status
			def retValue
			def localUrl=url + '/listDomains';
		when:
			retValue=restTemplate.getForEntity(localUrl,FileSourceBO[].class,"");
		then:
			retValue!=null
	}
	def "is address type exist"()
	{
		given:
			def status
			def retValue
			String addressvale="address";
		def localUrl = url + '/isAddressTypeExist/{addressTypeName}';
		when:
			retValue=restTemplate.getForEntity(localUrl,Boolean.class, addressvale);
		then:
			retValue!=null
	}
	def "get DB source"()
	{
		given:
			def status
			def retValue
			String dbSourceName="blaster_user29"
			def localUrl = url + '/getDBSource/{dbSourceName}';
		when:
			retValue=restTemplate.getForEntity(localUrl,DbSourceBO.class,dbSourceName);
		then:
			retValue!=null
	}
	def "get restricted domain with department list"()
	{
		given:
			def status
			def retValue
			def localUrl = url + '/getRestrictedDomainWithDepartmentList';
		when:
			retValue=restTemplate.getForEntity(localUrl,ArrayList.class, "");
		then:
			retValue!=null
	}
	def "save address type"()
	{
		given:
			def status
			def retValue
			addressTypeBO=new AddressTypeBO();
			addressTypeBO.setName("address3");
			List<String> channelTypelist=new ArrayList<>();
			channelTypelist.add("E");
			channelTypelist.add("Z");
			addressTypeBO.setChannelType(channelTypelist);
			addressTypeBO.setCreatedBy("Admin");
			def localUrl=url + '/saveAddressType';
		when:
			retValue=restTemplate.postForEntity(localUrl,addressTypeBO,Long.class);
		then:
			retValue!=null
	}
	
	def "update restricted domains address type"()
	{
		given:
			def status
			def retValue
			Timestamp createDate = new Timestamp(System.currentTimeMillis());
			restrictedDomainsBO = new RestrictedDomainsBO();
			HashMap<String,Boolean> restrictedMap=new HashMap<String,Boolean>();
			restrictedMap.put("temporaryinbox.com",false);
			restrictedMap.put("restricteddomain5.com",false);
			restrictedMap.put("temporaryinbox.com",false);
			for(Map.Entry m:restrictedMap.entrySet()){
				System.out.println(m.getKey()+" "+m.getValue());
			   }
			restrictedDomainsBO.setDomains(restrictedMap);
			restrictedDomainsBO.setCreateDate(createDate);
			restrictedDomainsBO.setUpdateDate(createDate);
			restrictedDomainsBO.setCreatedBy("Admin");
			restrictedDomainsBO.setUpdatedBy("Admin");
			def localUrl=url + '/updateRestrictedDomains';
		when:
			retValue=restTemplate.postForEntity(localUrl,restrictedDomainsBO,Long.class);
		then:
		print ":::::::"
	}
	def "save domain"()
	{
		given:
			def status
			def retValue
			domainBO=new DomainBO();
			domainBO.setCode("Same");
			domainBO.setPattern("AA");
			domainBO.setDescription("BB");
			domainBO.setStatus("A".charAt(0));
			domainBO.setCreatedBy("Admin");
			def localUrl=url + '/saveDomain';
		when:
			retValue=restTemplate.postForEntity(localUrl,domainBO,Long.class);
		then:
			retValue!=null
	}
	
	
	def "delete fileSourceName"()
	{
		given:
			def retValue
			fileSourceBO.setFileSourceName("fs10");
			def localUrl=url+'/deleteFileSource/{fileSourceName}';
		when:
			retValue=restTemplate.delete(localUrl,fileSourceBO.getFileSourceName());
		then:
			println "Setup:End find all audience method::"+retValue
	}
	def "delete Domain code"()
	{
		given:
			def retValue
				//domainBO.setCode("Same");
			String code="Same";
			def localUrl=url+'/deleteDomain/{code}';
		when:
		restTemplate.delete(localUrl,domainBO.getCode());
		then:
			println "Setup:End find all audience method::"+retValue
	}
}

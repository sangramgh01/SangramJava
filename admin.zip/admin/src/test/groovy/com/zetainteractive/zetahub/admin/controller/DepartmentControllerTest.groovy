/**
 * DepartmentControllerTest.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller

import java.sql.Timestamp
import java.util.List;

import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap
import org.springframework.web.client.RestTemplate
import org.springframework.http.HttpMethod
import org.springframework.http.RequestEntity
import org.springframework.http.ResponseEntity

import spock.lang.Shared
import spock.lang.Specification


import com.zetainteractive.zetahub.commons.domain.CategoriesListingCriteria
import com.zetainteractive.zetahub.commons.domain.CategoryBO
import com.zetainteractive.zetahub.commons.domain.DepartmentBO
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings
import com.zetainteractive.zetahub.commons.domain.FolderBO
import com.zetainteractive.zetahub.commons.domain.ListingCriteria
import com.zetainteractive.zetahub.commons.domain.FoldersListingCriteria
import com.zetainteractive.zetahub.commons.domain.TestGroup


class DepartmentControllerTest extends Specification  {

	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	@Shared
	DepartmentBO departmentBO;
	@Shared
	FolderBO folderBO;
	@Shared
	ListingCriteria listingCriteria;
	@Shared
	FoldersListingCriteria foldersListingCriteria;
	@Shared
	CategoryBO categoryBO;
	@Shared
	CategoriesListingCriteria categoriesListingCriteria;
	Timestamp createDate = new Timestamp(System.currentTimeMillis());
	def "init for department table"() {
		given:
		departmentBO=new DepartmentBO();
		restTemplate = new RestTemplate();
		//			 url = "http://localhost:7092/";
		url = "http://localhost:8100/";
	}
	/*Below Test cases from 'save Departmnet' to 'delete Deparment' can run with out changing any data */
	def "save Department"() 
	{
		given:
		def status
		def retValue
		departmentBO.setCreateDate(createDate);
		departmentBO.setUpdateDate(createDate);
		departmentBO.setCreatedBy("ADMIN");
		departmentBO.setUpdatedBy("ADMIN");
		//	departmentBO.setDepartmentID();
		departmentBO.setDepartmentName("DEPT-Sp-sht7");
		departmentBO.setApprovalMandatory(false);
		departmentBO.setDomainKeysUsed(false);
		departmentBO.setRestrictedDomainsExists(true);
		DepartmentSettings departmentSettings=new DepartmentSettings();
		List<DepartmentSettings> departmentSettingslist=new ArrayList<>();
		departmentSettings.setCreateDate(createDate);
		departmentSettings.setUpdateDate(createDate);
		departmentSettings.setCreatedBy("Admin");
		departmentSettings.setUpdatedBy("Admin");
		departmentSettings.setDepartmentSettingId(201);
		departmentSettings.setDepartmentID(52);
		departmentSettings.setObjectKey("ADDRESSLIST");
		Map<String,Object> objectValue=new HashMap();
		objectValue.put("fromAddressList",["a@gmail.com"]);
		objectValue.put("replyToAddressList",["abxe@gmail.com"]);
		objectValue.put("responseAddressList",["absx@gmail.com"]);
		departmentSettings.setObjectValue(objectValue);
		departmentSettingslist << departmentSettings
		departmentBO.setDepartmentSettings(departmentSettingslist)
		def localUrl=url + '/saveDepartment';
		when:
		retValue=restTemplate.postForEntity(localUrl,departmentBO,Long.class);
		departmentBO.setDepartmentID((Long)retValue.getBody());
		then:
		retValue!=null
	}
	def "get  department"() 
	{
		given:
		def status
		def retValue
		//			def deptId=401;
		String deptId=departmentBO.getDepartmentID();
		def localUrl = url + '/getDepartment/{departmentId}';
		when:
		retValue=restTemplate.getForEntity(localUrl,DepartmentBO.class,deptId);
		then:
		retValue!= null
		departmentBO.setDepartmentName(retValue.getBody().getDepartmentName());
		departmentBO.setCreateDate(retValue.getBody().getCreateDate());
		departmentBO.setCreatedBy(retValue.getBody().getCreatedBy());
		departmentBO.setUpdateDate(retValue.getBody().getUpdateDate());
		departmentBO.setUpdatedBy(retValue.getBody().getUpdatedBy());
		departmentBO.setDepartmentID(retValue.getBody().getDepartmentID());
		departmentBO.setDepartmentName(retValue.getBody().getDepartmentName());
		departmentBO.setApprovalMandatory(retValue.getBody().getApprovalMandatory());
		departmentBO.setDomainKeysUsed(retValue.getBody().getDomainKeysUsed());
		departmentBO.setRestrictedDomainsExists(retValue.getBody().getRestrictedDomainsExists());
		departmentBO.setDepartmentSettings(retValue.getBody().getDepartmentSettings())
	}
	def "is department exists"() 
	{
		given:
		def status
		def retValue
		def localUrl = url + '/isDepartmentExists/{departmentId}';
		when:
		retValue=restTemplate.getForEntity(localUrl,Boolean.class, departmentBO.getDepartmentID());
		then:
		retValue!=null
		println "retValue::::::::::::::::::::"+retValue
	}
	def "is department name exists"() 
	{
		given:
		def status
		def retValue
		def localUrl = url + 'departmentNameExists/{departmentName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,Boolean.class, departmentBO.getDepartmentName());
		then:
		retValue!=null
		println "retValue::::::::::::::::::::"+retValue
	}
	def "save Category"() 
	{
		given:
		def retValue
		categoryBO = new CategoryBO();
		//	categoryBO.setCategoryid(1);
		categoryBO.setDepartmentid(departmentBO.getDepartmentID());
		categoryBO.setCategorycode('sev');
		categoryBO.setDescription('Pav');
		categoryBO.setType('A'.charAt(0));
		def localUrl=url+'/saveCategory';
		when:
		retValue=restTemplate.postForEntity(localUrl,categoryBO, CategoryBO.class);
		then:
		retValue!=null
		categoryBO.setCategoryid(retValue.getBody().getCategoryid());
		categoryBO.setDepartmentid(retValue.getBody().getDepartmentid());
		categoryBO.setCategorycode(retValue.getBody().getCategorycode());
		categoryBO.setDescription(retValue.getBody().getDescription())
		categoryBO.setType(retValue.getBody().getType());
	}
	def "getCategory"() 
	{
		given:
		//	categoryBO = new CategoryBO();
		//	categoryBO.setCategoryid(1);
		def localUrl=url+"/getCategory/{categoryId}";
		def retValue;
		when:
		retValue=restTemplate.getForEntity(localUrl, Object.class,categoryBO.getCategoryid());
		then:
		retValue!=null
		println "retValue::::::::::::::::::::"+retValue
	}
	def "list departments"() 
	{
		given:
		def status
		def retValue
		listingCriteria=new ListingCriteria();
		listingCriteria.setPageNumber(1);
		listingCriteria.setSortBy("descending");
		listingCriteria.setSortUsing("departmentname");
		listingCriteria.setNameLike(null);
		listingCriteria.setPageSize(10);
		def localUrl=url + '/listDepartments';
		when:
		retValue=restTemplate.postForEntity(localUrl,listingCriteria,DepartmentBO[].class);
		then:
		retValue!=null
	}
	def "departments total Count"() 
	{
		given:
		def status
		def retValue
		listingCriteria=new ListingCriteria();
		listingCriteria.setPageNumber(1);
		listingCriteria.setSortBy("descending");
		listingCriteria.setSortUsing("departmentname");
		listingCriteria.setNameLike(null);
		listingCriteria.setPageSize(10);
		def localUrl=url + '/departmentsTotalCount';
		when:
		retValue=restTemplate.postForEntity(localUrl,listingCriteria,Long.class);
		then:
		retValue!=null
		println "retValue::::::::::::::::::::"+retValue
	}
	def"save folder"() 
	{
		given:
		def retValue
		folderBO=new FolderBO();
		//		folderBO.setFolderid(1);
		folderBO.setDepartmentid(departmentBO.getDepartmentID());
		//		folderBO.setDepartmentid(401)
		folderBO.setFoldername("btestfolder");
		folderBO.setType("A".charAt(0));
		folderBO.setParentfolderid(0);
		def localUrl=url + '/saveFolder';
		when:
		retValue=restTemplate.postForEntity(localUrl,folderBO,FolderBO.class);
		then:
		retValue!=null
		folderBO.setFolderid(retValue.getBody().getFolderid());
		folderBO.setDepartmentid(retValue.getBody().getDepartmentid());
		folderBO.setFoldername(retValue.getBody().getFoldername());
		folderBO.setType(retValue.getBody().getType());
		folderBO.setParentfolderid(retValue.getBody().getParentfolderid());
	}
	def "get Folder"() 
	{
		given:
		//			Long folderId=946
		Long folderId= folderBO.getFolderid();
		def retValue
		def localUrl = url + '/getFolder/{folderId}';
		when:
		retValue=restTemplate.getForEntity(localUrl,FolderBO.class,folderId);
		then:
		retValue!=null
		println "retValue::::::::::::::::::::"+retValue
	}
	def"list folders"() 
	{
		given:
		def retValue
		foldersListingCriteria=new FoldersListingCriteria();
		foldersListingCriteria.setType(folderBO.getType());
		//		foldersListingCriteria.departmentId=401
		foldersListingCriteria.setDepartmentId(folderBO.getDepartmentid());
		def localUrl=url + '/listFolders';
		when:
		retValue=restTemplate.postForEntity(localUrl,foldersListingCriteria,FolderBO[].class);
		then:
		retValue!=null
		List<FolderBO> foldersList = new ArrayList<>();
		for ( FolderBO retVal : (retValue.getBody())){
			foldersList.add(retVal);
		}
		departmentBO.setFoldersList(foldersList);
	}
	def"find folder"()
	{
		given:
		def retValue
		Map<String,Object> requestParams = new HashMap<>()
		//		requestParams.put("folderName","rtestfolder");
		//		requestParams.put("type","A");
		//		requestParams.put("departmentId",401);
		requestParams.put("folderName",folderBO.getFoldername());
		requestParams.put("type",folderBO.getType());
		requestParams.put("departmentId",folderBO.getDepartmentid());
		def
				localUrl=url + '/findFolder';
		when:
		retValue=restTemplate.postForEntity(localUrl,requestParams,FolderBO.class);
		then:
		retValue!= null
		println "retValue::::::::::::::::::::"+retValue
	}
	def "check If Folder Exists"()
	{
		given:
		def retValue
		def localUrl=url+"/checkIfFolderExists";
		Map<String,Object> json= new HashMap<>();
		json.put("type", "A".charAt(0));
		json.put("folderName",folderBO.getFoldername());
		json.put("departmentId",folderBO.getDepartmentid());
		json.put("folderId",folderBO.getFolderid());
		when:
		retValue=restTemplate.postForEntity(localUrl,json,Object.class);
		then:
		retValue!=null
	}
	def "get Department Specific Property"()
	{
		given:
		def retValue
		def localUrl=url+'getDepartmentSpecificProperty';
		Map<String,Object> requestParams = new HashMap<>();
		requestParams.put("departmentId", departmentBO.getDepartmentID())
		requestParams.put("propertyKey","PARAMETERS")
		when:
		retValue = restTemplate.postForEntity(localUrl, requestParams, Object.class)
		then:
		retValue != null
	}
	def "create Department"()
	{
		given:
		def retValue
		def localUrl=url+'createDepartment';
		Map<String,Object> json=new HashMap<>();
		json.put("departmentName", "spock-test9")
		json.put("approvalNeeded", "true")
		json.put("domainKeysNeeded", "false")
		when:
		retValue = restTemplate.postForEntity(localUrl, json, Object.class);
		then:
		retValue != null
	}
	def "check If Category Exists With Type And Dept"()
	{
		given:
		def retValue
		def localUrl=url+"/checkIfCategoryExists";
		Map<String,Object> json= new HashMap<>();
		json.put("type", "A".charAt(0));
		json.put("categoryCode",categoryBO.getCategorycode());
		json.put("departmentId",categoryBO.getDepartmentid());
		json.put("categoryId",categoryBO.getCategoryid());
		when:
		retValue=restTemplate.postForEntity(localUrl,json,Object.class);
		then:
		retValue!=null
	}
	def "list Categories"() 
	{
		given:
		def retValue
		def localUrl=url+"/listCategories";
		categoriesListingCriteria = new CategoriesListingCriteria();
		categoriesListingCriteria.setDepartmentId(departmentBO.getDepartmentID());
		categoriesListingCriteria.setType('A'.charAt(0));
		when:
		retValue=restTemplate.postForEntity(localUrl,categoriesListingCriteria,Object.class)
		List<CategoryBO> categories= retValue.getBody();
		departmentBO.setCategoriesList(categories)
		then:
		retValue!=null
	}
	def "get Mobile For Department"()
	{
		given:
		def retValue
		def localUrl=url+"getMobileForDepartment";
		def departmentID=departmentBO.getDepartmentID();
		when:
		retValue=restTemplate.postForEntity(localUrl,departmentID,Object.class)
		then:
		retValue!=null
	}
	def "list Short Codes"()
	{
		given:
		def retValue
		def localUrl=url+"listShortCodes";
		def departmentID=departmentBO.getDepartmentID();
		when:
		retValue=restTemplate.postForEntity(localUrl,departmentID,Object.class)
		then:
		retValue!=null
	}
	def "create Test Group"()
	{
		given:
		def retValue
		def localUrl=url+"createTestGroup";
		Map<String, Object> json= new HashMap();
		json.put("departmentId", departmentBO.getDepartmentID());
		TestGroup testGroup= new TestGroup();
		testGroup.setCampaignId(0);
		testGroup.setFirstName("Firstnametest2");
		testGroup.setLastName("LastNametest2");
		testGroup.setMobileNumber(9292929192);
		testGroup.setCreateDate(createDate);
		testGroup.setUpdateDate(createDate);
		testGroup.setCreatedBy("Admin1")
		testGroup.setUpdatedBy("Admin1")
		TestGroup testGroup2= new TestGroup();
		testGroup2.setCampaignId(1);
		testGroup2.setFirstName("Fristnametest3");
		testGroup2.setLastName("Lstnametest4");
		testGroup2.setMobileNumber(9192929192);
		testGroup2.setCreateDate(createDate);
		testGroup2.setUpdateDate(createDate);
		testGroup2.setCreatedBy("Admin1")
		testGroup2.setUpdatedBy("Admin1")
		List<TestGroup> listOfTestGroup= new ArrayList<>();
		listOfTestGroup.add(testGroup);
		listOfTestGroup.add(testGroup2);
		json.put("testGroups", listOfTestGroup);
		when:
		retValue=restTemplate.postForEntity(localUrl,json,Object.class);
		then:
		retValue!=null
	}
	def "list Test Groups" ()
	{
		given:
		def retValue
		def localUrl=url+"listTestGroups";
		def departmentID=departmentBO.getDepartmentID();
		when:
		retValue=restTemplate.postForEntity(localUrl,departmentID,Object.class);
		then:
		retValue!=null
	}
	def "update Test Group"()
	{
		given:
		def retValue
		def localUrl=url+"updateTestGroup";
		Map<String, Object> json= new HashMap();
		json.put("departmentId", departmentBO.getDepartmentID());
		TestGroup testGroup= new TestGroup();
		//	testGroup.setCampaignId(0);
		testGroup.setFirstName("Firstnametest2");
		testGroup.setLastName("LastNametest2");
		testGroup.setMobileNumber(9292929193);
		testGroup.setCreateDate(createDate);
		testGroup.setUpdateDate(createDate);
		testGroup.setCreatedBy("Admin1")
		testGroup.setUpdatedBy("Admin1")
		TestGroup testGroup2= new TestGroup();
		testGroup2.setCampaignId(0);
		testGroup2.setFirstName("Fristnametest3");
		testGroup2.setLastName("Lstnametest4");
		testGroup2.setMobileNumber(9192929194);
		testGroup2.setCreateDate(createDate);
		testGroup2.setUpdateDate(createDate);
		testGroup2.setCreatedBy("Admin1")
		testGroup2.setUpdatedBy("Admin1")
		List<TestGroup> listOfTestGroup= new ArrayList<>();
		listOfTestGroup.add(testGroup);
		listOfTestGroup.add(testGroup2)
		json.put("testGroups", listOfTestGroup);
		when:
		retValue=restTemplate.postForEntity(localUrl,json,Object.class);
		then:
		retValue!=null
	}
	def "delete Folder"()
	{
		given:
		def retValue
		//	folderBO= new FolderBO();
		//	folderBO.setFolderid(946);
		def localUrl=url+'/deleteFolder/{folderId}';
		when:
		retValue=restTemplate.delete(localUrl,folderBO.getFolderid());
		then:
		print "retValue:: "+retValue
	}
	def "delete Department"()
	{
		given:
		def retValue
		def localUrl=url+'/deleteDepartment/{departmentId}';
		when:
		retValue=restTemplate.delete(localUrl,departmentBO.getDepartmentID());
		then:
		print "retValue::"
	}

	/* Below Test cases need to run individually and data collecting from database, which mean they don't have dependencies from any test case.
	 * 
	 */
	/* 
	 def "update Department Specific Property" ()
	 {
	 given:
	 def retValue
	 def localUrl=url+'updateDepartmentSpecificProperty';
	 //	List<DepartmentSettings> listdepartmentSettings= departmentBO.getDepartmentSettings();
	 DepartmentSettings departmentSettings = new DepartmentSettings();
	 departmentSettings.departmentSettingId=1634
	 departmentSettings.departmentID=1
	 departmentSettings.objectKey="PARAMETERS"
	 Map<String,Object> objectValue = new HashMap<>();
	 objectValue.put("contentURLCheck", false);
	 objectValue.put("contentHTMLValidator", false);
	 departmentSettings.objectValue=objectValue;
	 when:
	 retValue = restTemplate.postForEntity(localUrl, departmentSettings, Object.class);
	 then:
	 retValue != null
	 }
	 */
	/*def "delete Categories"()
	 {
	 given:
	 def retValue
	 def localUrl=url+"/deleteCategories";
	 Set<Long> categoryIds = new HashSet();
	 categoryIds.add(364);
	 categoryIds.add(366);
	 when:
	 retValue=restTemplate.postForEntity(localUrl,categoryIds,Object.class)
	 then:
	 retValue!=null
	 }*/
	/*def "get Conversations By FolderId" ()
	 {
	 given:
	 def retValue
	 def localUrl=url+"getConversationsByFolderId/{folderId}";
	 def folderId=1
	 when:
	 retValue=restTemplate.getForEntity(localUrl,Object.class,folderId);
	 then:
	 retValue!=null
	 }*/
	/*def "get Contents By FolderId" ()
	 {
	 given:
	 def retValue
	 def localUrl=url+"getConversationsByFolderId/{folderId}";
	 def folderId=1
	 when:
	 retValue=restTemplate.getForEntity(localUrl,Object.class,folderId);
	 then:
	 retValue!=null
	 }*/
	/*def "get Trash Conversations"() 
	 {
	 given:
	 def retVal
	 def deptId =1
	 def localUrl = url+'getTrashConversations/{deptId}'
	 when:
	 retVal = restTemplate.getForEntity(localUrl,Object.class,deptId)
	 then:
	 retVal  != null
	 println "Result :: "+retVal
	 }*/
	/*def "get Trash Contents"()
	 {
	 given:
	 def retVal
	 def folderId =310
	 def localUrl = url+'getTrashContents/{folderId}'
	 when:
	 retVal = restTemplate.getForEntity(localUrl,Object.class,folderId)
	 then:
	 retVal  != null
	 println "Result :: "+retVal
	 }*/
	/*def "delete Contents"()
	 {
	 def retValue
	 def selectedTemplateIds=25
	 def selectedTemplateType="CNB"
	 def localUrl=url+"deleteContents";
	 MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
	 params.add("selectedTemplateIds",812);
	 params.add("selectedTemplateType","IMG")
	 when:
	 retValue=restTemplate.postForEntity(localUrl,params,Object.class);
	 then:
	 retValue !=null
	 }*/
	/*def "restore Contents" () {
	 given:
	 def retValue
	 def localUrl=url+"restoreContents";
	 MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
	 params.add("selectedTemplateIds",132);
	 params.add("selectedTemplateType","IMG")
	 when:
	 retValue=restTemplate.postForEntity(localUrl,params,Object.class);
	 then:
	 retValue !=null
	 }*/
	/*def "empty Trash Contents" () 
	 {
	 given:
	 def retValue
	 def localUrl= url+ "emptyTrashContents";
	 List<Long> convIds = new ArrayList<Long>();
	 convIds.add(699);
	 when:
	 retValue=restTemplate.postForEntity(localUrl,convIds,Object.class);
	 then:
	 retValue !=null
	 }*/
	/*def "restore Conversations"() 
	 {
	 given:
	 def retValue
	 def localUrl= url+ "restoreConversations";
	 List<Long> convIds = new ArrayList<Long>();
	 convIds.add(684);
	 when:
	 retValue=restTemplate.postForEntity(localUrl,convIds,Object.class);
	 then:
	 retValue !=null
	 }*/
	/*def " empty Trash Conversations" () 
	 {
	 given:
	 def retValue
	 def localUrl= url+ "emptyTrashConversations";
	 List<Long> convIds = new ArrayList<Long>();
	 convIds.add(699);
	 when:
	 retValue=restTemplate.postForEntity(localUrl,convIds,Object.class);
	 then:
	 retValue !=null
	 }*/
	/*def "get getGAAuthURL"()
	 {
	 given:
	 Long status=1
	 def retValue
	 def localUrl = url + '/getGAAuthURL';
	 when:
	 retValue=restTemplate.getForEntity(localUrl,String.class,"");
	 then:
	 retValue!=null
	 println "retValue::::::::::::::::::::"+retValue
	 }*/

	/* 
	 def "delete Folders"()
	 {
	 given:
	 Boolean retValue
	 Set<Long> folderIds= new HashSet();
	 folderIds.add(952);
	 folderIds.add(954);
	 def localUrl=url+'/deleteFolders'
	 when:
	 retValue=restTemplate.postForEntity(localUrl,folderIds,Boolean.class);
	 then:
	 print "retValue:: "+retValue
	 }*/

}





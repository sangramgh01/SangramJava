/**
 * MeterQueueControllerTest.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller

import java.sql.Timestamp

import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.admin.dao.MeterQueueDAO;
import com.zetainteractive.zetahub.commons.domain.AudienceSearchCriteria
import com.zetainteractive.zetahub.commons.domain.MeterQueue

class MeterQueueControllerTest extends Specification {

	@Shared
	MeterQueue meterQueue;
	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	Timestamp createDate = new Timestamp(System.currentTimeMillis());
	def "init for MeterQueueController"() {
		given:
		meterQueue=new MeterQueue();
		restTemplate = new RestTemplate();
		url = "http://localhost:8100/";
	}
	
	void buildMeterQueue() {
		meterQueue.setMeterQueueId(0)
		meterQueue.setCreateDate(createDate);
		meterQueue.setUpdateDate(createDate);
		meterQueue.setCreatedBy("zh17");
		meterQueue.setUpdatedBy("zh17");
		meterQueue.setMeterQueueName("Test563");
		meterQueue.setMaxRate00("340");
		meterQueue.setMaxRate01("0");
		meterQueue.setMaxRate02("0");
		meterQueue.setMaxRate03("0");
		meterQueue.setMaxRate04("0");
		meterQueue.setMaxRate05("0");
		meterQueue.setMaxRate06("0");
		meterQueue.setMaxRate07("0");
		meterQueue.setMaxRate08("0");
		meterQueue.setMaxRate09("0");
		meterQueue.setMaxRate10("0");
		meterQueue.setMaxRate11("0");
		meterQueue.setMaxRate12("0");
		meterQueue.setMaxRate13("0");
		meterQueue.setMaxRate14("0");
		meterQueue.setMaxRate15("0");
		meterQueue.setMaxRate16("0");
		meterQueue.setMaxRate17("0");
		meterQueue.setMaxRate18("0");
		meterQueue.setMaxRate19("0");
		meterQueue.setMaxRate20("0");
		meterQueue.setMaxRate21("0");
		meterQueue.setMaxRate22("0");
		meterQueue.setMaxRate23("0");
		meterQueue.setStatus("A".charAt(0));
		meterQueue.setIsDefault("Y".charAt(0));
	}
	def "save Meter Queue method"() {
		given:
		buildMeterQueue()
		def retValue
		def isDefaultOverride = false
		def localUrl=url + 'saveMeterQueue/'+isDefaultOverride;
		when:
		retValue=restTemplate.postForEntity(localUrl,meterQueue,MeterQueue.class);
		meterQueue =  (MeterQueue)retValue.getBody()
		meterQueue.setMeterQueueId(meterQueue.getMeterQueueId());
		meterQueue.setMeterQueueName(meterQueue.getMeterQueueName());
		then:
		retValue!=null
		print "saveMeterQueue retValue::::"+meterQueue.getMeterQueueName()+""+meterQueue.getMeterQueueId()
	}
	def "find meter queue by name method"() {
		given:
		def retValue
		def localUrl=url + 'findMeterQueueByName/{meterQueueName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,MeterQueue.class,meterQueue.getMeterQueueName());
		then:
		retValue!=null
		println "Result MeterQueue : "+meterQueue.getMeterQueueId()
	}
	def "find meter queue by id method"() {
		given:
		def retValue
		def localUrl=url + 'findMeterQueueById/{meterQueueId}'
		when:
		retValue=restTemplate.getForEntity(localUrl,MeterQueue.class,meterQueue.getMeterQueueId());
		then:
		retValue!=null
		println "Result :: "+retValue
	}

	def "list meter queues method"() {
		given:
		def retValue
		def localUrl= url + 'listMeterQueues';
		when:
		retValue=restTemplate.getForEntity(localUrl,MeterQueue[].class);
		then:
		retValue!=null
		println "Result"+retValue
	}

	def "is default meter queue exists for client method"() {
		given:
		def retValue
		def localUrl=url + 'isDefaultMeterQueueExistsForClient';
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}


	def "is meter queue exists method"(){
		given:
		def retValue
		def localUrl=url + 'isMeterQueueExists/{meterQueueName}';
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class,meterQueue.getMeterQueueName());
		then:
		retValue!=null
		print "retValue::::"+retValue
	}

	def "is meter queue exists with name and id method"(){
		given:
		def retValue
		def localUrl=url + 'isMeterQueueExistsWithNameAndId/'+meterQueue.getMeterQueueId()+'/'+meterQueue.getMeterQueueName();
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}
	def "is default meter queue exists for Client method"(){
		given:
		def retValue
		def localUrl=url + 'isDefaultMeterQueueExistsForClient';
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}

	def "existing default meter queue for client method"(){
		given:
		def retValue
		def localUrl=url + 'existingDefaultMeterQueueForClient';
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}

	def "find Meter Queues By Criteria method"(){
		given:
		def retValue
		AudienceSearchCriteria audienceSearchCriteria =  new AudienceSearchCriteria();
		audienceSearchCriteria.setPageNumber(1)
		audienceSearchCriteria.setPageSize(7)
		audienceSearchCriteria.setSortBy("ASC")
		audienceSearchCriteria.setSortUsing("meterqueuename")
		def localUrl=url + 'findMeterQueuesByCriteria';
		when:
		retValue=restTemplate.postForEntity(localUrl,audienceSearchCriteria,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}

	def "list active meter queues method"(){
		given:
		def retValue
		def localUrl=url + 'listActiveMeterQueues';
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue!=null
		print "retValue::::"+retValue
	}

	def "meter queue associated Campaigns method"(){
		given:
		def retValue
		def localUrl=url + 'meterQueueAssociatedCampaigns/{meterQueueId}'
		when:
		retValue=restTemplate.getForEntity(localUrl,Object.class,meterQueue.getMeterQueueId())
		then:
		retValue!=null
		print "retValue::::"+retValue
	}
	def "delete Meter Queue method"() {
		given:
		def retValue
		def localUrl=url + 'deleteMeterQueue/{meterQueueId}';
		when:
		retValue=restTemplate.delete(localUrl,meterQueue.getMeterQueueId(),Boolean.class);
		then:
		retValue != false
		print "retValue::::"+retValue
	}
}

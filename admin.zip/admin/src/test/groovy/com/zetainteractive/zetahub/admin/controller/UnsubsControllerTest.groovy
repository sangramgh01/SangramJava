/**
 * UnsubsControllerTest.groovy :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.admin.controller

import java.sql.Timestamp

import org.springframework.web.client.RestTemplate

import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.Unsubs

class UnsubsControllerTest extends Specification{
	@Shared
	Unsubs unsubs;
	@Shared
	String url
	@Shared
	RestTemplate restTemplate;
	@Shared
	def unsubType="CUSTOM";

	Timestamp createDate = new Timestamp(System.currentTimeMillis());
	def "init for UnsubController"() {
		given:
		unsubs=new Unsubs();
		restTemplate = new RestTemplate();
		url = "http://localhost:8100/";
	}
	void buildUnsubKeyword() {
		unsubs.setCreateDate(createDate);
		unsubs.setUpdateDate(createDate);
		unsubs.setCreatedBy("zh17");
		unsubs.setUpdatedBy("zh17");
		unsubs.setUnsubKeyword("Test0041");
		unsubs.setStatus("A".charAt(0));
		unsubs.setType("HRD");
		unsubs.setCategory("SUBJECT");
	}
	def "Save Unsubs"() {
		given:
		def retValue
		def localUrl=url +'saveUnsubs/'+unsubType;
		buildUnsubKeyword();
		when:
		retValue=restTemplate.postForEntity(localUrl,unsubs,unsubs.class);
		unsubs = (Unsubs)retValue.getBody()
		then:
		retValue!=null
		println "save unsubs retValue::::"+unsubs
	}
	def "find unsubs by name"() {
		given:
		def retValue
		buildUnsubKeyword();
		Map<String,String> requestParams = new HashMap<String,String>()
		requestParams.put("unsubKeyword",unsubs.getUnsubKeyword());
		requestParams.put("ubsubType",unsubType);
		def localUrl=url + 'findUnsubByName/{unsubKeyword}/{ubsubType}';
		when:
		retValue=restTemplate.getForEntity(localUrl,Unsubs.class,requestParams);
		then:
		retValue!=null
		println "::retValue"+retValue
	}

	def "Update Unsubs"() {
		given:
		def retValue
		buildUnsubKeyword()
		unsubs.setType("ING");
		unsubs.setCategory("BODY");
		def localUrl=url +'saveUnsubs/'+unsubType;
		when:
		retValue=restTemplate.postForEntity(localUrl,unsubs,unsubs.class);
		unsubs = (Unsubs)retValue.getBody()
		then:
		retValue!=null
		println "save unsubs retValue::::"+retValue
	}
	def "find unsubs by id "() {
		given:
		def retValue
		Map<String,String> requestParams = new HashMap<String,String>()
		requestParams.put("unsubKeywordId",unsubs.getUnsubKeywordId());
		requestParams.put("unsubType",unsubType);
		def localUrl=url + '/findUnsubById/{unsubKeywordId}/{unsubType}';
		when:
		retValue=restTemplate.getForEntity(localUrl,Unsubs.class,requestParams);
		then:
		retValue!=null
		println "Result::"+retValue
	}

	def "list unsubs"() {
		given:
		def retValue
		def  localUrl = url +'listUnsubs/All/'+unsubType
		when:
		retValue=restTemplate.getForEntity(localUrl,Unsubs[].class,"");
		then:
		retValue!=null
		println "Result::"+retValue
	}

	def "deleteUnsubs by unsubKeywordId and unsubType"(){
		given:
		def retValue
		def  localUrl = url +'deleteUnsubs/'+unsubs.getUnsubKeywordId()+'/'+unsubType
		when:
		retValue=restTemplate.delete(localUrl,Boolean.class);
		then:
		retValue!=false
		println "Result::"+retValue
	}
}

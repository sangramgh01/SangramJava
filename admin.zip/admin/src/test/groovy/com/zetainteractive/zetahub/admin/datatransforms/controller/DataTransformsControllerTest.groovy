package com.zetainteractive.zetahub.admin.datatransforms.controller

import org.springframework.context.ConfigurableApplicationContext
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow
import com.zetainteractive.zetahub.commons.domain.ResponseStatus
import com.zetainteractive.zetahub.commons.domain.TimeZoneData
import com.zetainteractive.zetahub.commons.domain.TransformActivity
import com.zetainteractive.zetahub.commons.domain.TransformEditor
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor
import com.zetainteractive.zetahub.commons.domain.WorkflowTransforms
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger

/**
 * Spock test case for validating data transforms REST Api end points
 * @author Nagendra.Guttha
 * @since 1.7
 */
class DataTransformsControllerTest extends Specification
{
	@Shared
	@AutoCleanup
	ConfigurableApplicationContext context

	@Shared
	String url
	
	/*void setupSpec()
	{
		final Future future = Executors.newSingleThreadExecutor()
								 .submit(
											new Callable()
											{
												@Override
												public ConfigurableApplicationContext call() throws Exception
												{
													return (ConfigurableApplicationContext) SpringApplication.run(Application.class)
												}
											}
										)
		context = future.get(60, TimeUnit.SECONDS)
	}*/
	@Shared
	RestTemplate restTemplate;
	
	@Shared
	DTWWorkflow workflow;
	
	@Shared
	TransformEditor transform;
	
	@Shared
	WorkflowTrigger workflowTrigger;
	
	@Shared
	WorkflowActivity workflowActivity;
	
	@Shared
	TransformActivity transformActivity;
	
	@Shared
	DTWSearchCriteria searchCriteria;
	
	@Shared
	WorkflowEditor  workflowEditor;
	
	def "init for test methods"()
	{
		given:
			 transform = new TransformEditor();
			 workflow  = new DTWWorkflow();
			 workflowEditor = new WorkflowEditor();
			 workflowTrigger = new WorkflowTrigger()
			 workflowActivity = new WorkflowActivity()
			 transformActivity = new TransformActivity()
			 searchCriteria = new DTWSearchCriteria();
			 buildTransform();
			 buildWorkflowEditor()
			 buildWorkflow();
			 buildWorkflowTrigger()
			 buildWorkflowActivity()
			 buildTransformActivity()
			 restTemplate = new RestTemplate();
			 url = "http://localhost:8100/datatransforms/";
			 
	}
	void buildTransform()
	{
		transform.setName(UUID.randomUUID().toString());
		transform.setUsetransaction("Y".charAt(0))
		transform.setTransform("Sample Transform SQL Query..")
		transform.setCreatedby("DataTransformTeam")
		transform.setCreateddate(new Date())
	}
	void buildWorkflow()
	{
		WorkflowTransforms  wt  = new WorkflowTransforms();
		List<WorkflowTransforms> wtList = new ArrayList<>();
		wtList << wt
		workflow.setMappingstep(wtList);
		workflow.setListWorkflowEditor(workflowEditor);
		workflow.setDepartmentId(1);
		workflow.setCreatedby("DataTransformTeam");
		workflow.setCreateddate(new Date());
	}
	void buildWorkflowEditor(){
		workflowEditor.setName(UUID.randomUUID().toString());
		workflowEditor.setSchedulesetting("N".charAt(0));
		workflowEditor.setTimezone("Asia/Calcutta");
		workflowEditor.setEnablemode("N".charAt(0));
		workflowEditor.setRunmode("S".charAt(0));
		workflowEditor.setCreatedBy("DataTransformTeam");
		workflowEditor.setUpdatedBy("DataTransformTeam");
	}
	void buildWorkflowTrigger()
	{
		workflowTrigger.setFileDefinitionId(1l)
		workflowTrigger.setCreatedby("DataTransformTeam")
		workflowTrigger.setCreateddate(new Date())
	}
	void buildWorkflowActivity()
	{
		workflowActivity.setStatus("W".charAt(0))
		workflowActivity.setMessage("Waiting to start ")
		workflowActivity.setStartedOn(new Date())
		workflowActivity.setCompletedOn(new Date())
		workflowActivity.setBatchids("1")
		workflowActivity.setCreatedby("DataTransformTeam")
		workflowActivity.setCreateddate(new Date())
	}
	void buildTransformActivity()
	{
		transformActivity.setStatus("W".charAt(0))
		transformActivity.setMessage("Waiting to start ")
		transformActivity.setStartedOn(new Date())
		transformActivity.setCompletedOn(new Date())
		transformActivity.setCreatedby("DataTransformTeam")
		transformActivity.setCreateddate(new Date())
	}
	
	//Validate create operations
	def "validate create transforms method"()
	{
		given:
			  def retValue
			  def localUrl = url + 'createTransform';
		when:
			retValue = restTemplate.postForEntity( localUrl,transform, ResponseStatus.class, "");
		then:
			retValue !=null
			println 'Transform id :'+retValue.getBody().getId();
			transform.setId(retValue.getBody().getId());
			//transform.setId(retValue.getBody().getId());
	}
	
	
	
	def "validate create workflow method"()
	{
		given:
			  def retValue
			  WorkflowTransforms  wt  = new WorkflowTransforms();
			  wt.setStepId(120);
			  wt.setType("S");
			  List<WorkflowTransforms> wtList = new ArrayList<>();
			  wtList << wt
			  workflow.setMappingstep(wtList)
			  workflow.setSchedule(wt.getType());
			  def localUrl = url + 'createWorkflow';
		when:
			retValue = restTemplate.postForEntity( localUrl,workflow, ResponseStatus.class);
			workflow.setId(retValue.getBody().getId());
		then:
			retValue !=null
			println 'Workflow id : '+retValue.getBody().getId();
	}
	
	def "validate to create master workflow method"()
	{
		given:
			  def retValue
			  WorkflowTransforms  wt  = new WorkflowTransforms();
			  wt.setStepId(transform.getId());
			  wt.setStepId(86);
			  wt.setType("T");
			  List<WorkflowTransforms> wtList = new ArrayList<>();
			  wtList << wt
			  workflow.setMappingstep(wtList)
			  workflow.setSchedule("T");
			  def localUrl = url + 'createWorkflow';
		when:
			retValue = restTemplate.postForEntity( localUrl,workflow, ResponseStatus.class, "");
			workflow.setId(retValue.getBody().getId());
		then:
			retValue !=null
				println 'Workflow id : '+retValue.getBody().getId();
	}
	
	
	def "validate create workflow activity method"()
	{
		given:
			  def retValue
			  workflowActivity.setWorkflowId(112)
			  def localUrl = url + 'createWorkflowActivity';
		when:
			retValue = restTemplate.postForEntity( localUrl,workflowActivity, ResponseStatus.class, "");
			println "WORKFLOW>>>>"+retValue.getBody().getId()
			workflowActivity.setId(retValue.getBody().getId());
		then:
			retValue !=null
	}
	
	def "validate create transform activity for workflow method"()
	{
		given:
			  def retValue
			  transformActivity.setWorkflowactivityid(156)
			  transformActivity.setTransformid(200)
			  def localUrl = url + 'createTransformActivity';
			  println "TRANSFORM WORKFLOW>>>>"+transformActivity.getWorkflowactivityid()
			  println "TRANSFORM WORKFLOW>>>>"+transformActivity.getTransformid()
		when:
			retValue = restTemplate.postForEntity( localUrl,transformActivity, ResponseStatus.class, "");
			transformActivity.setId(retValue.getBody().getId());
		then:
			retValue !=null
	}
	
	
	//Validate read operations
	def "validate all transforms method"()
	{
		given:
			  def localUrl  = url+'getAllTransforms';
		when:
			ResponseEntity<TransformEditor[]> transforms = restTemplate.getForEntity( localUrl, TransformEditor[].class, "");
		then:
			transforms !=null && transforms.getBody().size()>0 ;
	}
	def "validate all workflows method"()
	{
		given:
			  def retValue
			  def localUrl = url + 'getAllWorkflows';
		when:
			retValue = restTemplate.getForEntity( localUrl, DTWWorkflow[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	def "validate master workflows "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getMasterWorkflows';
		when:
			retValue = restTemplate.getForEntity( localUrl, DTWWorkflow[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	def "validate all workflow trigger method"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowId",workflow.getId());
			  requestParams.put("fileDefId","1");
			  def localUrl = url + 'getWorkflowTriggers/{workflowId}/{fileDefId}';
		when:
			retValue =  restTemplate.getForEntity( localUrl, WorkflowTrigger[].class, requestParams);
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate all workflow activities method"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowId",workflow.getId());
			  def localUrl = url + 'getWorkflowActivity/{workflowId}';
		when:
			retValue =  restTemplate.getForEntity( localUrl, WorkflowActivity[].class, requestParams);
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate all transform activity for workflow method"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowActivityId",workflowActivity.getId());
			  requestParams.put("transformId",transform.getId());
			  def localUrl = url + 'getTransformActivity/{workflowActivityId}/{transformId}';
		when:
			retValue =  restTemplate.getForEntity( localUrl, TransformActivity[].class, requestParams);
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate all transform activity negative input"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowActivityId",-1);
			  requestParams.put("transformId",-1);
			  def localUrl = url + 'getTransformActivity/{workflowActivityId}/{transformId}';
		when:
			try{
			  retValue = restTemplate.getForEntity( localUrl, TransformActivity[].class, requestParams);
			}catch(Exception e){}
		then:
			//retValue !=null
			println 'Transform Act..'+retValue;
	}
	def "validate all transform activity input  data wrong"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowActivityId",0);
			  requestParams.put("transformId",-1);
			  def localUrl = url + 'getTransformActivity/{workflowActivityId}/{transformId}';
		when:
			try{	
				retValue =  restTemplate.getForEntity( localUrl, TransformActivity[].class, requestParams);
			}catch(Exception e){}
		then:
			//retValue !=null
			println 'Transform Act E..'+retValue;
	}
	
	def "validate workflow which is used in list"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowId",workflow.getId());
			  def localUrl = url + 'getIsUsedInList/{workflowId}';
		when:
			retValue =  restTemplate.getForEntity(localUrl,Integer.class,requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	
	def "validate get Notification Workflow Mappings"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workFlowId",1);
			  def localUrl = url + 'getNotificationWorkflowMappings/{workFlowId}';
		when:
			retValue =  restTemplate.getForEntity(localUrl,Object.class,requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	
	def "validate  trigger WorkFlow Activity by trigger WorkFlow Activity"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("customerId",5);
			  def localUrl = url + 'triggerWorkFlowActivity/{customerId}';
		when:
			retValue =  restTemplate.getForEntity(localUrl,String.class,requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	def "validate get Workflow By Id"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowId",1);
			  def localUrl = url + '/getWorkflowById/{workflowId}';
		when:
			retValue =  restTemplate.getForEntity(localUrl,DTWWorkflow.class,requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	
	def "validate get Associated Transforms"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowId",1);
			  def localUrl = url + '/getAssociatedTransforms/{workflowId}';
		when:
			retValue =  restTemplate.getForEntity(localUrl,TransformEditor[].class,requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	
	def "validate all transform activity for workflow activity method"()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowActivityId",workflowActivity.getId());
			  def localUrl = url + 'getTransformActivity/{workflowActivityId}';
		when:
			retValue =  restTemplate.getForEntity( localUrl, TransformActivity[].class, requestParams);
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	
	def "validate workflow which has activities associates to it "()
	{
		given:
			  def retValue
			  Map<String,String> requestParams = new HashMap<String,String>()
			  requestParams.put("workflowActivityId",workflowActivity.getId());
			  requestParams.put("workflowId",workflow.getId());
			  def localUrl = url + 'getWorkflowWithActivities/{workflowId}/{workflowActivityId}';
		when:
			retValue =  restTemplate.getForEntity( localUrl, DTWWorkflow.class, requestParams);
		then:
			retValue !=null && retValue.getBody()!=null
	}
	def "validate timezones method"()
	{
		given:
			  def localUrl  = url+'getTimeZones';
		when:
			ResponseEntity<TimeZoneData> timezones = restTemplate.getForEntity( localUrl, TimeZoneData.class, "");
		then:
			timezones !=null;
	}
	//validate update operations
	def "validate update transform method"()
	{
		given:
			  def localUrl = url + 'updateTransform';
			  restTemplate.put( localUrl,transform, "");
		
	}
	
	def "validate update workflow method"()
	{
		given:
			  WorkflowTransforms  wt  = new WorkflowTransforms();
			  wt.setStepId(transform.getId());
			  List<WorkflowTransforms> wtList = new ArrayList<>();
			  wtList << wt
			  workflow.setMappingstep(wtList)
			  def localUrl = url + 'updateWorkflow';
			  workflow.setSchedule("S");
			  restTemplate.put( localUrl,workflow,  "");
	}
	def "validate update workflow trigger method"()
	{
		given:
			  workflowTrigger.setWorkflowId(workflow.getId())
			  def localUrl = url + 'updateWorkflowTrigger';
			  restTemplate.put( localUrl,workflowTrigger,  "");
	}
	def "validate update workflow activity method"()
	{
		given:
			  workflowActivity.setWorkflowId(workflow.getId())
			  def localUrl = url + 'updateWorkflowActivity';
			  restTemplate.put( localUrl,workflowActivity, "");
	}
	def "validate update transform activity for workflow method"()
	{
		given:
			  transformActivity.setWorkflowactivityid(workflowActivity.getId())
			  transformActivity.setTransformid(transform.getId())
			  def localUrl = url + 'updateTransformActivity';
			  restTemplate.put( localUrl,transformActivity, "");
	}
	
	
	def "validate restart workflow activity method"()
	{
		given:
			  workflowActivity.setStatus(Constants.ACTIVITY_ERRORED.charValue());//Make it failed activity
			  workflowActivity.setUpdatedby("DataTransformTeam")
			  def localUrl = url + 'updateWorkflowActivity';
			  restTemplate.put( localUrl,workflowActivity, "" );
			  localUrl = url + 'restartWorkflowActivity';
			  restTemplate.put( localUrl,workflowActivity, "");
	}
	def "validate cancel workflow activity method"()
	{
		given:
			  workflowActivity.setStatus(Constants.ACTIVITY_RETRY.charValue());
			  def localUrl = url + 'cancelWorkflowActivity';
			  restTemplate.put( localUrl,workflowActivity, "");
	}
	
	//validate search operations
	def "validate transform search criteria for transform id "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getTransformsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setId(transform.getId());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,TransformEditor[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate transform search criteria for transform name "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getTransformsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setNamelike(transform.getName());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,TransformEditor[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate transform search criteria for created date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getTransformsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setCreatedFromDate(new java.util.Date().minus(1))
			  searchCriteria.setCreatedToDate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,TransformEditor[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate transform search criteria for updated date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getTransformsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setUpdatedFromdate(new java.util.Date().minus(1))
			  searchCriteria.setUpdatedTodate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,TransformEditor[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate workflow search criteria "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setId(workflow.getId());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,DTWWorkflow[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	def "validate workflow search criteria for created date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setCreatedFromDate(new java.util.Date().minus(1));
			  searchCriteria.setCreatedToDate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,DTWWorkflow[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate workflow search criteria for updated date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowsForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setUpdatedFromdate(new java.util.Date().minus(1))
			  searchCriteria.setUpdatedTodate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,DTWWorkflow[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	
	def "validate workflow activity search criteria "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowActivityForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setId(workflowActivity.getId());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,WorkflowActivity[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	def "validate workflow activity search criteria for created date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowActivityForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setCreatedFromDate(new java.util.Date().minus(1))
			  searchCriteria.setCreatedToDate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,WorkflowActivity[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	def "validate workflow activity search criteria for updated date "()
	{
		given:
			  def retValue
			  def localUrl = url + 'getWorkflowActivityForSearchCriteria';
			  searchCriteria = new DTWSearchCriteria();
			  searchCriteria.setUpdatedFromdate(new java.util.Date().minus(1))
			  searchCriteria.setUpdatedTodate(new java.util.Date());
		when:
			retValue =  restTemplate.postForEntity( localUrl, searchCriteria,WorkflowActivity[].class, "");
		then:
			retValue !=null && retValue.getBody().size()>0
	}
	
	//validate delete operations
	def "validate delete transform method"()
	{
		given:
			  def localUrl = url + 'deleteTransform/{transformId}';
			  restTemplate.delete(localUrl,transform.getId())
	}
	def "validate delete workflow method"()
	{
		given:
			  def localUrl = url + 'deleteWorkflow/{workflowId}';
			  restTemplate.delete(localUrl,workflow.getId())
	}
	def "validate delete workflow trigger method"()
	{
		given:
			  def localUrl = url + 'deleteWorkflowTrigger/{workflowTriggerId}';
			  restTemplate.delete(localUrl,workflowTrigger.getId())
	}
	def "validate delete workflow activitiy method"()
	{
		given:
			  def localUrl = url + 'deleteWorkflowActivity/{workflowActivityId}';
			  restTemplate.delete(localUrl,workflowActivity.getId())
	}
	def "validate delete transform activity for workflow method"()
	{
		given:
			  def localUrl = url + 'deleteTransformActivity/{transformActivityId}';
			  restTemplate.delete(localUrl,transformActivity.getId())
	}
	
	
	/*  Validate remaining udpate oprations*/
	
	def "validate update workflow schedule" (){
	 given:
		 def retValue
		 def localUrl = url + 'updateWorkFlowSchedule';
		 workflowEditor.setName(UUID.randomUUID().toString());
		 workflowEditor.setWorkFlowId(144);
		 workflowEditor.setWorkFlowScheduleId(134);
	 when:
		 retValue = restTemplate.postForEntity( localUrl,workflowEditor, Boolean.class,);
	 then:
		 println 'is workflow schedule udpated : ' + retValue.getBody();
	}
 
 def "validate update workflow status" (){
	 given:
		 def retValue
		 def localUrl = url + 'updateWorkFlowStatus';
		 Map<String,Object> requestParam = new HashMap<String,Object>();
		 requestParam.put("workFlowId",140);
		 requestParam.put("status",'I');
	 when:
		 retValue = restTemplate.postForEntity( localUrl,requestParam, Boolean.class,);
	 then:
		 println 'is workflow status udpated  : '+ retValue.getBody();
 }
 
 def "validate update block or unblock workflow activity" (){
	 given:
		 def localUrl = url + "blockOrUnBlockWorkFlowActivities/{status}/{message}";
		 Map<String,String> requestParam =  new HashMap<String,String>();
		 requestParam.put("status","W");
		 requestParam.put("message","DataTransformTeam testing");
	 when:
		 restTemplate.put(localUrl,"",requestParam);
	 then:
		 println 'End block or unblock workflow activity ';
 }
 
	
}

package com.zetainteractive.zetahub.admin.datatransforms.dao
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

import org.springframework.boot.SpringApplication
import org.springframework.context.ConfigurableApplicationContext

import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

import com.zetainteractive.zetahub.admin.constants.Constants
import com.zetainteractive.zetahub.admin.init.AdminApp
import com.zetainteractive.zetahub.commons.domain.TransformActivity
import com.zetainteractive.zetahub.commons.domain.TransformEditor
import com.zetainteractive.zetahub.commons.domain.Workflow
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity
import com.zetainteractive.zetahub.commons.domain.WorkflowEditor
import com.zetainteractive.zetahub.commons.domain.WorkflowTransforms
import com.zetainteractive.zetahub.commons.domain.WorkflowTrigger


class DataTransformsDaoTest extends Specification
{
	@Shared
	@AutoCleanup
	ConfigurableApplicationContext context

	void setupSpec()
	{
		final Future future = Executors.newSingleThreadExecutor()
								 .submit(
											new Callable()
											{
												@Override
												public ConfigurableApplicationContext call() throws Exception
												{
													return (ConfigurableApplicationContext) SpringApplication.run(AdminApp.class)
												}
											}
										)
		context = future.get(60, TimeUnit.SECONDS)
	}
	@Shared
	DataTransformsDao transformsDao;
	
	@Shared
	Workflow workflow;
	
	@Shared
	TransformEditor transform;
	
	@Shared
	WorkflowTrigger workflowTrigger;
	
	@Shared
	WorkflowActivity workflowActivity;
	
	@Shared
	TransformActivity transformActivity;
	
	def "init for test methods"()
	{
		given:
			 transform = new TransformEditor();
			 workflow  = new Workflow();
			 workflowTrigger = new WorkflowTrigger()
			 workflowActivity = new WorkflowActivity()
			 transformActivity = new TransformActivity()
			 buildTransform();
			 buildWorkflow()
			 buildWorkflowTrigger()
			 buildWorkflowActivity()
			 buildTransformActivity()
			 transformsDao = context.getBean("dataTransformsDao");
			 
	}
	void buildTransform()
	{
		transform.setName(UUID.randomUUID().toString());
		transform.setUsetransaction("Y".charAt(0))
		transform.setTransform("Sample Transform SQL Query..")
		transform.setCreatedby("DataTransformTeam")
		transform.setCreateddate(new Date())
	}
	void buildWorkflow()
	{
		WorkflowEditor  workflowEditor = new WorkflowEditor()
		
		WorkflowTransforms  wt  = new WorkflowTransforms();
		//wt.setListtransformid(transform.getId());
		List<WorkflowTransforms> wtList = new ArrayList<>();
		wtList << wt
		workflow.setListWorkflowEditor(workflowEditor);
		workflow.setMappingTransform(wtList);
		workflow.setCreatedby("DataTransformTeam")
		workflow.setCreateddate(new Date())
	}
	void buildWorkflowTrigger()
	{
		workflowTrigger.setFileDefinitionId(1l)
		workflowTrigger.setCreatedby("DataTransformTeam")
		workflowTrigger.setCreateddate(new Date())
	}
	void buildWorkflowActivity()
	{
		workflowActivity.setStatus("W".charAt(0))
		workflowActivity.setMessage("Waiting to start ")
		workflowActivity.setStartedOn(new Date())
		workflowActivity.setCompletedOn(new Date())
		workflowActivity.setBatchids("1")
		workflowActivity.setCreatedby("DataTransformTeam")
		workflowActivity.setCreateddate(new Date())
	}
	void buildTransformActivity()
	{
		transformActivity.setStatus("W".charAt(0))
		transformActivity.setMessage("Waiting to start ")
		transformActivity.setStartedOn(new Date())
		transformActivity.setCompletedOn(new Date())
		transformActivity.setCreatedby("DataTransformTeam")
		transformActivity.setCreateddate(new Date())
	}
	
	//Validate create operations
	def "validate create transforms method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.saveTransform(transform);
			transform.setId(retValue);
		then:
			retValue !=null
	}
	def "validate create workflow method"()
	{
		given:
			  def retValue
			  WorkflowTransforms  wt  = new WorkflowTransforms();
			  wt.setTransformId(transform.getId());
			  List<WorkflowTransforms> wtList = new ArrayList<>();
			  wtList << wt
			  workflow.setMappingTransform(wtList)
		when:
			retValue = transformsDao.saveWorkflow(workflow)
			workflow.setId(retValue);
		then:
			retValue !=null
	}
	def "validate create workflow trigger method"()
	{
		given:
			  def retValue
			  workflowTrigger.setWorkflowId(workflow.getId())
		when:
			retValue = transformsDao.saveWorkflowTrigger(workflowTrigger)
			workflowTrigger.setId(retValue);
		then:
			retValue !=null
	}
	def "validate create workflow activity method"()
	{
		given:
			  def retValue
			  workflowActivity.setWorkflowId(workflow.getId())
		when:
			retValue = transformsDao.saveWorkflowActivity(workflowActivity)
			workflowActivity.setId(retValue);
		then:
			retValue !=null
	}
	def "validate create transform activity for workflow method"()
	{
		given:
			  def retValue
			  transformActivity.setWorkflowactivityid(workflowActivity.getId())
			  transformActivity.setTransformid(transform.getId())
		when:
			retValue = transformsDao.saveTransformActivity(transformActivity)
			transformActivity.setId(retValue);
		then:
			retValue !=null
	}
	
	//Validate read operations
	def "validate all transforms method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.getAllTransforms();
		then:
			retValue !=null && retValue.size()>0
	}
	def "validate all workflows method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.getAllWorkflows();
		then:
			retValue !=null
	}
	def "validate all workflow trigger method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.getWorkflowTriggers(workflow.getId(),1)
		then:
			retValue !=null && retValue.size()>0
	}
	def "validate all workflow activities method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.getWorkflowActivity(workflow.getId());
		then:
			retValue !=null && retValue.size()>0
	}
	def "validate all transform activity for workflow method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.getTransformActivity(workflowActivity.getId(),transform.getId())
		then:
			retValue !=null && retValue.size()>0
	}
	
	//validate update operations
	def "validate update transform method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.updateTransform(transform);
		then:
			retValue !=null && retValue
	}
	def "validate update workflow method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.updateWorkflow(workflow);
		then:
			retValue !=null && retValue
	}
	def "validate update workflow trigger method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.updateWorkflowTrigger(workflowTrigger);
		then:
			retValue !=null && retValue
	}
	def "validate update workflow activities method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.updateWorkflowActivity(workflowActivity);
		then:
			retValue !=null && retValue
	}
	def "validate update transform activity for workflow method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.updateTransformActivity(transformActivity)
		then:
			retValue !=null && retValue
	}
	
	//Actions
	def "validate restart workflow activity method"()
	{
		given:
			  def retValue
			  workflowActivity.setStatus(Constants.ACTIVITY_ERRORED.charValue());//Make it failed activity
			  workflowActivity.setUpdatedby("DataTransformTeam")
			  transformsDao.updateWorkflowActivity(workflowActivity);
		when:
			retValue = transformsDao.restartWorkflowActivity(workflowActivity);
		then:
			retValue !=null && retValue
	}
	
	def "validate cancel workflow activity method"()
	{
		given:
			  def retValue
			  workflowActivity.setStatus(Constants.ACTIVITY_RETRY.charValue());
		when:
			retValue = transformsDao.cancelWorkflowActivity(workflowActivity);
		then:
			retValue !=null && retValue
	}
	
	//validate delete operations
	def "validate delete transform method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.deleteTransform(transform.getId())
		then:
			retValue !=null && retValue
	}
	def "validate delete workflow method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.deleteWorkflow(workflow.getId())
		then:
			retValue !=null && retValue
	}
	def "validate delete workflow trigger method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.deleteWorkflowTrigger(workflowTrigger.getId());
		then:
			retValue !=null && retValue
	}
	def "validate delete workflow activitiy method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.deleteWorkflowActivity(workflowActivity.getId())
		then:
			retValue !=null && retValue
	}
	def "validate delete transform activity for workflow method"()
	{
		given:
			  def retValue
		when:
			retValue = transformsDao.deleteTransformActivity(transformActivity.getId());
		then:
			retValue !=null && retValue
	}
	
}


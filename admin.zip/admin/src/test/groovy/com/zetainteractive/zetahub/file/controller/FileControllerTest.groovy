package com.zetainteractive.zetahub.file.controller

import java.text.SimpleDateFormat

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext
import org.springframework.core.io.FileSystemResource
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap
import org.springframework.web.client.RestTemplate

import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

import com.fasterxml.jackson.databind.ObjectMapper
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO
import com.zetainteractive.zetahub.commons.domain.FileActionMappingBO
import com.zetainteractive.zetahub.commons.domain.FileActivityBO
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO
import com.zetainteractive.zetahub.commons.domain.FileFormatSpecBO
import com.zetainteractive.zetahub.commons.domain.FileProcessingOptionsBO
import com.zetainteractive.zetahub.commons.domain.FileScheduleBO
import com.zetainteractive.zetahub.commons.domain.FileSourceSpecBO
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO
import com.zetainteractive.zetahub.commons.domain.ListingCriteria
import com.zetainteractive.zetahub.commons.domain.NotificationStatus
import com.zetainteractive.zetahub.commons.domain.Notifications

class FileControllerTest extends Specification{


	@Shared
	@AutoCleanup
	ConfigurableApplicationContext context


	@Shared
	FileDefinitionBO fileDefinitionBO

	@Shared
	String url

	@Shared
	RestTemplate restTemplate

	@Shared
	FileActivityBO fileActivityBO

	@Shared
	String dbSourceName

	@Shared
	String tableName

	@Shared
	String filePath="E:/sample.txt"

	@Shared
	Long audienceID

	@Shared
	String fileSourceName

	@Shared
	HashMap<String,String> executeQueryInput = new HashMap<String,String>()

	@Shared
	Map<String, String> searchCriteria = new HashMap<String, String>();

	@Shared
	Long deleteFileDefinitionID


	@Shared
	FileScheduleBO fileScheduleBO

	@Shared
	Long fileActivityID

	def "prepare FileDefinitionBO object for request"(){
		given: 	url  =  "http://localhost:8100/file/"
		fileDefinitionBO = new FileDefinitionBO()
		restTemplate = new RestTemplate()
	}
	void prepareInput(){
		fileDefinitionBO.setDepartmentID(1);
		fileDefinitionBO.setFileType("B".charAt(0));
		fileDefinitionBO.setAudienceID(296);
		fileDefinitionBO.setTimeZone("Asia/Calcutta");
		fileDefinitionBO.setStatus("W".charAt(0));
		fileDefinitionBO.setScheduleactivemode("Y".charAt(0));
		fileDefinitionBO.setRetryCount(3);
		fileDefinitionBO.setIsFileTrigger("Y".charAt(0));
		fileDefinitionBO.setUseEncryption("Y".charAt(0));
		fileDefinitionBO.setEncryptionKey("zeta");
		fileDefinitionBO.setSendWorkFlow("Y".charAt(0));
		fileDefinitionBO.setWorkFlowID(86);
		fileDefinitionBO.setMaxFiles(3);
		fileScheduleBO = new FileScheduleBO();
		fileScheduleBO.setFileDefintionID(662);
		fileScheduleBO.setFrequency("M".charAt(0));
		fileScheduleBO.setTimeZone("Asia/Calcutta");
		fileScheduleBO.setScheduleStartDate(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-10-2018 00:00:00"));
		fileScheduleBO.setScheduleEndDate(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-11-2018 00:00:00"));
		fileScheduleBO.setSchedulenextdue(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-12-2018 00:00:00"));
		fileScheduleBO.setFrequencyUnit(1);
		fileScheduleBO.setIncludeDays(3);
		fileScheduleBO.setMonthlySchdFreq("D".charAt(0));
		fileScheduleBO.setDayOfEveryMonth(3);
		fileScheduleBO.setCreatedBy("admin");
		fileDefinitionBO.setFileScheduleBO(fileScheduleBO);
		FileSourceSpecBO fileSourceSpecBO = new FileSourceSpecBO();
		fileSourceSpecBO.setSourceType("L".charAt(0));
		fileSourceSpecBO.setSourceName("blaster_user29");
		fileSourceSpecBO.setFolderPath();
		fileSourceSpecBO.setFileNamePattern();
		fileSourceSpecBO.setQuery("select customerid,email,htmlcontent,textcontent from HPTAG_C150_25_3_R3");
		fileSourceSpecBO.setSourceTable("HPTAG_C150_25_3_R3");
		fileSourceSpecBO.setFilePath();
		fileDefinitionBO.setFileSource(fileSourceSpecBO);
		fileDefinitionBO.setCreatedBy("admin");
		FileFormatSpecBO fileFormatSpecBO = new FileFormatSpecBO();
		fileFormatSpecBO.setDelimiter(",");
		fileFormatSpecBO.setTextQualifier("None");
		fileFormatSpecBO.setHeaderRowAtLine(1);
		fileFormatSpecBO.setDataStartsFromLine(2);
		fileFormatSpecBO.setHeaderInColumn("Y".charAt(0));
		fileDefinitionBO.setFileFormatSpec(fileFormatSpecBO);
		Map<String,String> unsubResubProperties = new HashMap<String,String>();
		unsubResubProperties.put("ignoreEmail", "Y");
		fileDefinitionBO.setUnsubResubProperties(unsubResubProperties);
		fileDefinitionBO.setFileAction("S".charAt(0));
		fileDefinitionBO.setTableName("");
		fileDefinitionBO.setTableDisposition("0");
		FileActionMappingBO fileMapping  = new FileActionMappingBO();
		fileMapping.setIncludeScrubRules(1);
		fileMapping.setEnableScrubRules("Y".charAt(0));
		fileMapping.setBooleanFormat("YesNo");
		fileMapping.setDateFormat("YMD");
		fileMapping.setDateDelimiter(" ");
		fileMapping.setNullValueRepresentation("NL");

		List<ColumnDefinitionBO> columnDefinitionList = new ArrayList<ColumnDefinitionBO>();
		ColumnDefinitionBO columnDefinitionBO = new ColumnDefinitionBO();
		columnDefinitionBO.setColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setColumnType("STRING");
		columnDefinitionBO.setIsCustomColumn("Y".charAt(0));
		columnDefinitionBO.setLength(1);
		columnDefinitionBO.setDefaultValue("EMAIL_ADDRESS");
		columnDefinitionBO.setIsNullable("Y".charAt(0));
		columnDefinitionBO.setColumnPositionInFile(1);
		columnDefinitionBO.setLogicalColumnName("Email Address");
		columnDefinitionBO.setLogicalTableName("TABLE 1");
		columnDefinitionBO.setPhysicalColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setPhysicalTableName("EMAIL_ADDRESS");
		columnDefinitionBO.setUnsubscribe("Y".charAt(0));
		columnDefinitionList.add(columnDefinitionBO);
		fileMapping.setColumnDefinitionList(columnDefinitionList);
		fileDefinitionBO.setFileMapping(fileMapping);
		fileActivityBO = new FileActivityBO();
		fileActivityBO.setFileName("spockfileactivity_2");
		fileActivityBO.setStatus("Y".charAt(0));
		fileActivityBO.setMessage("file");
		fileActivityBO.setStartedOn(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-10-2018 00:00:00"));
		fileActivityBO.setCompletedOn(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-10-2018 00:00:00"));
		FileSummaryBO fileSummaryBO = new FileSummaryBO ();
		fileSummaryBO.setTotalCount(1);
		fileSummaryBO.setFinalCount(1);
		fileSummaryBO.setUnsubCount(1);
		fileSummaryBO.setResubCount(1);
		fileSummaryBO.setInvalidCount(1);
		fileSummaryBO.setDuplicateCount(1);
		fileSummaryBO.setScrubbedEmails(1);
		fileActivityBO.setFileSummaryBO(fileSummaryBO);
		fileActivityBO.setBatchId(1);
		fileActivityBO.setIgnorefilePath("E:\temp");
		fileActivityBO.setDatabaseLogPath("D:\temp");
		fileActivityBO.setActivitySource("Y".charAt(0));
		fileActivityBO.setSourceInfo("source");
		//fileActivityBO.setFileDefinitionID(1234L);
		fileActivityBO.setCreatedBy("admin");

		Notifications notifications =  new Notifications()
		notifications.setIsEnabled(false);
		notifications.setDefaultEmailAddresses("")
		List<NotificationStatus> notificationStatuses = new ArrayList<NotificationStatus>();
		NotificationStatus notificationStatus = new NotificationStatus();
		notificationStatus.setIsEnabled(false)
		notificationStatus.setName("Executing")
		notificationStatus.setEmailAddresses("")
		notificationStatuses.add(notificationStatus)
		notifications.setNotificationStatuses(notificationStatuses)
		fileDefinitionBO.setNotifications(notifications)
		dbSourceName = "MySql_DBsource"
		tableName='ADDRESS'
	}
	void prepareLocalInput(){
		prepareInput()
		fileDefinitionBO.setName("spocktestfile_132");
		FileSourceSpecBO fileSourceSpecBO = new FileSourceSpecBO();
		fileSourceSpecBO.setSourceType("D".charAt(0));
		fileSourceSpecBO.setSourceName();
		fileSourceSpecBO.setFolderPath();
		fileSourceSpecBO.setFileNamePattern();
		fileDefinitionBO.setFileSource(fileSourceSpecBO);
		FileProcessingOptionsBO fileProcessingOptionsBO = new FileProcessingOptionsBO();
		fileProcessingOptionsBO.setIgnoreBadFiles("Y".charAt(0))
		fileProcessingOptionsBO.setIgnoreBadRecords("Y".charAt(0))
		fileProcessingOptionsBO.setPreserveOrder("Y".charAt(0))
		fileProcessingOptionsBO.setMergeDuplicates("N".charAt(0))
		fileDefinitionBO.setFileProcessingOptions(fileProcessingOptionsBO)
	}
	void prepareRemoteServerInput(){
		prepareInput()
		fileDefinitionBO.setName("spocktestfile_142");
		FileSourceSpecBO fileSourceSpecBO = new FileSourceSpecBO();
		fileSourceSpecBO.setSourceType("R".charAt(0));
		fileSourceSpecBO.setSourceName("10.98.8.144");
		fileSourceSpecBO.setFolderPath("/home/qaftp2");
		fileSourceSpecBO.setFileNamePattern("remotefile");
		fileDefinitionBO.setFileSource(fileSourceSpecBO);
		FileProcessingOptionsBO fileProcessingOptionsBO = new FileProcessingOptionsBO();
		fileProcessingOptionsBO.setIgnoreBadFiles("Y".charAt(0))
		fileProcessingOptionsBO.setIgnoreBadRecords("Y".charAt(0))
		fileProcessingOptionsBO.setPreserveOrder("Y".charAt(0))
		fileProcessingOptionsBO.setMergeDuplicates("N".charAt(0))
		fileDefinitionBO.setFileProcessingOptions(fileProcessingOptionsBO)
		FileActionMappingBO fileMapping  = new FileActionMappingBO();
		fileMapping.setIncludeScrubRules(14336);
		fileMapping.setEnableScrubRules("Y".charAt(0));
		fileMapping.setBooleanFormat("YESNO");
		fileMapping.setDateFormat("YMD");
		fileMapping.setDateDelimiter(" ");
		fileMapping.setNullValueRepresentation("NL");
		List<ColumnDefinitionBO> columnDefinitionList = new ArrayList<ColumnDefinitionBO>();
		ColumnDefinitionBO columnDefinitionBO = new ColumnDefinitionBO();
		columnDefinitionBO.setColumnName("column_0");
		columnDefinitionBO.setColumnType("EMAIL");
		columnDefinitionBO.setIsCustomColumn("Y".charAt(0));
		columnDefinitionBO.setLength(1600);
		columnDefinitionBO.setAddressType("1")
		columnDefinitionBO.setDefaultValue("EMAIL_ADDRESS");
		columnDefinitionBO.setIsNullable("Y".charAt(0));
		columnDefinitionBO.setColumnPositionInFile(0);
		columnDefinitionBO.setLogicalColumnName("Email Address");
		columnDefinitionBO.setLogicalTableName("Email Address");
		columnDefinitionBO.setPhysicalColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setPhysicalTableName("AUDIENCE_EMAIL");
		columnDefinitionBO.setUnsubscribe("Y".charAt(0));
		columnDefinitionList.add(columnDefinitionBO);
		fileMapping.setColumnDefinitionList(columnDefinitionList);
	}
	void prepareRemoteDBInput(){
		prepareInput()
		fileDefinitionBO.setName("spocktestfile_152");
		fileDefinitionBO.setTableName("")
		FileSourceSpecBO fileSourceSpecBO = new FileSourceSpecBO();
		fileSourceSpecBO.setSourceType("B".charAt(0));
		fileSourceSpecBO.setSourceName("MySql_DBsource");
		fileSourceSpecBO.setQuery("select user_id,first_name,last_name,salary,Details_Exist,email_address,mobile_number from AUTO_CUST_DBTABLE")
		fileSourceSpecBO.setSourceTable("AUTO_CUST_DBTABLE");
		fileDefinitionBO.setFileSource(fileSourceSpecBO);
		FileFormatSpecBO fileFormatSpecBO = new FileFormatSpecBO();
		FileActionMappingBO fileMapping  = new FileActionMappingBO();
		fileMapping.setIncludeScrubRules(1);
		fileMapping.setEnableScrubRules("Y".charAt(0));
		fileMapping.setBooleanFormat("YesNo");
		fileMapping.setDateFormat("YMD");
		fileMapping.setDateDelimiter(" ");
		fileMapping.setNullValueRepresentation("NL");List<ColumnDefinitionBO> columnDefinitionList = new ArrayList<ColumnDefinitionBO>();
		ColumnDefinitionBO columnDefinitionBO = new ColumnDefinitionBO();
		columnDefinitionBO.setColumnName("user_id_1");
		columnDefinitionBO.setColumnType("EMAIL");
		columnDefinitionBO.setIsCustomColumn("N".charAt(0));
		columnDefinitionBO.setLength(1);
		columnDefinitionBO.setDefaultValue("NULL");
		columnDefinitionBO.setIsNullable("Y".charAt(0));
		columnDefinitionBO.setColumnPositionInFile(1);
		columnDefinitionBO.setLogicalColumnName("Email Address");
		columnDefinitionBO.setLogicalTableName("Email Address");
		columnDefinitionBO.setPhysicalColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setPhysicalTableName("AUDIENCE_EMAIL");
		columnDefinitionList.add(columnDefinitionBO);
		fileMapping.setColumnDefinitionList(columnDefinitionList);
	}
	
	def "save Remote File Definition method"() {
		given:
		def retValue
		prepareRemoteServerInput()
		MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
		ObjectMapper objectMapper = new ObjectMapper();
		String strFileDefJSON = objectMapper.writeValueAsString(fileDefinitionBO)
		params.add("fileDefinitionBO",strFileDefJSON);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		HttpEntity<LinkedMultiValueMap<String, Object>> requestEntity = new HttpEntity<LinkedMultiValueMap<String, Object>>(params, headers);
		def localUrl = url + 'saveFileDefinition'
		when:
		retValue = restTemplate.postForEntity(localUrl,requestEntity,Object.class);
		then:
		retValue !=null
	}
	def "save Remote DB Definition method"() {
		given:
		def retValue
		prepareRemoteDBInput()
		MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
		ObjectMapper objectMapper = new ObjectMapper();
		String strFileDefJSON = objectMapper.writeValueAsString(fileDefinitionBO)
		params.add("fileDefinitionBO",strFileDefJSON);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		HttpEntity<LinkedMultiValueMap<String, Object>> requestEntity = new    HttpEntity<LinkedMultiValueMap<String, Object>>(params, headers);
		def localUrl = url + 'saveFileDefinition'
		when:
		retValue = restTemplate.postForEntity(localUrl,requestEntity,Object.class);
		then:
		retValue !=null
	}
	def "save Local File Definition method"() {
		given:
		def retValue
		prepareLocalInput()
		MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
		ObjectMapper objectMapper = new ObjectMapper();
		String strFileDefJSON = objectMapper.writeValueAsString(fileDefinitionBO)
		params.add("fileDefinitionBO",strFileDefJSON);
		params.add("file",new FileSystemResource(filePath))
		def localUrl = url + 'saveFileDefinition'
		when:
		retValue = restTemplate.postForEntity(localUrl,params,Object.class)
		fileDefinitionBO = (FileDefinitionBO)retValue.getBody()
		then:
		retValue !=null
		println retValue
	}
	def "save File Activity method"() {
		given:
		prepareInput()
		fileActivityBO.setFileDefinitionID(fileDefinitionBO.getFileDefinitionID());
		def retValue
		def localUrl = url + "saveFileActivity"
		when:
		retValue = restTemplate.postForEntity( localUrl,fileActivityBO, Long.class);
		fileActivityID = (Long)retValue.getBody()
		then:
		retValue !=null
	}
	
	def "get All File Activities By File defintion  Id  method"(){
		given:
		def retValue
		def localUrl = url + "getAllFileActivitiesByFileId/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get File Activity  method"(){
		given:
		def retValue
		def localUrl = url + "getFileActivity/"+fileActivityID
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "get File Activity "+retValue
	}
	def "get file activities  method"(){
		given:
		def retValue
		println fileActivityBO.getFileActivityID()
		def localUrl = url + "getfileactivities/"+fileActivityID
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "get File activities "+retValue
	}
	def "get All File Activity By File Def Id  method"(){
		given:
		def retValue
		println fileDefinitionBO.getFileDefinitionID()
		def localUrl = url + "getAllFileActivityByFileDefId/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,FileActivityBO.class)
		then:
		retValue !=null
	}
	def "get All File Activities method"() {
		given:
		def retValue
		searchCriteria.put("pageno","1");
		searchCriteria.put("pagesize","7");
		def localUrl = url + "getAllFileActivities"
		when:
		retValue = restTemplate.postForEntity(localUrl,searchCriteria,Object.class);
		then:
		retValue !=null
		println "Result::"+retValue
	}
	def "get All File Definitions method"() {
		given:
		def retValue
		def localUrl = url + "getAllFileDefinitions"
		searchCriteria.put("departmentID","1");
		searchCriteria.put("pageno","1");
		searchCriteria.put("pagesize","7");
		searchCriteria.put("sortby","fileactivityid");
		searchCriteria.put("sortorder","DESC");
		when:
		retValue = restTemplate.postForEntity( localUrl,searchCriteria, Object.class);
		then:
		retValue !=null
		println "getAllFileDefinitions"+retValue
	}
	def "fetch all the tables from remote DB "(){
		given:
		def retValue
		def dbSourceName="Vertica_QASetup2"
		def localUrl = url + "fetchTablesFromRemoteDB/"+dbSourceName
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result "+retValue
	}
	def "prepare select query on given data source and table "(){
		given:
		def retValue
		prepareRemoteDBInput()
		def localUrl = url + "prepareSelectQueryOnTable/"+fileDefinitionBO.getFileSource().getSourceName()+"/"+fileDefinitionBO.getFileSource().getSourceTable()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "execute select query on given data source and query "(){
		given:
		def retValue
		prepareRemoteDBInput()
		def localUrl = url + "/executeSelectQueryOnTable"
		executeQueryInput.put("dbSourceName",fileDefinitionBO.getFileSource().getSourceName())
		executeQueryInput.put("query",fileDefinitionBO.getFileSource().getQuery())
		when:
		retValue = restTemplate.postForEntity( localUrl,executeQueryInput, Object.class)
		then:
		retValue !=null
	}
	def "get table metadata from given data source and table name "(){
		given:
		def retValue
		prepareRemoteDBInput()
		def localUrl = url + "getTableMetaData/"+fileDefinitionBO.getFileSource().getSourceName()+"/"+fileDefinitionBO.getFileSource().getSourceTable()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get Audience base table columns from the given audience id "(){
		given:
		def retValue
		def localUrl = url+"getAudienceBaseColumns/"+fileDefinitionBO.getAudienceID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "file upload method"(){
		given:
		def retValue
		def localUrl = url + 'fileUpload'
		MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
		params.add("file",new FileSystemResource(filePath))
		params.add("headerStart",1)
		params.add("dataStart",2)
		params.add("delimiter",",")
		params.add("textQualifier","None")
		when:
		retValue = restTemplate.postForEntity(localUrl,params,Object.class)
		then:
		retValue !=null
	}
	def "get All File Definitions For Trigger method"(){
		given:
		def retValue
		searchCriteria.put("departmentID",fileDefinitionBO.getDepartmentID());
		searchCriteria.put("pageno","1");
		searchCriteria.put("pagesize","7");
		searchCriteria.put("sortby","fileactivityid");
		searchCriteria.put("sortorder","DESC");
		def localUrl = url + "getAllFileDefinitionsForTrigger"
		when:
		retValue = restTemplate.postForEntity(localUrl,searchCriteria,Object.class)
		then:
		retValue !=null
		println "End"+retValue
	}
	def "get File Definition By ID method"(){
		given:
		def retValue
		def localUrl = url + "getFileDefinitionByID/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result"+retValue
	}
	def "get all Audiences"(){
		given:
		def retValue
		def localUrl = url+"/getAllAudiences"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get all File sources"(){
		given:
		def retValue
		def localUrl = url+"/getAllFileSources"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result"+retValue
	}
	def "get all DB sources"(){
		given:
		def retValue
		def localUrl = url+"/getAllDBSources"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result"+retValue
	}
	def "get all Address types"(){
		given:
		def retValue
		def localUrl = url+"/getAllAddressTypes"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "get all Address types"+retValue
	}
	def "get All Column Types  method"(){
		given:
		def retValue
		def localUrl = url + "getAllColumnTypes"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "get All Column Types"+retValue
	}

	def "file activity by file definition id  method"(){
		given:
		def retValue
		def localUrl = url + "fileactivitybyfiledefinitionid/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result"+retValue
	}
	
	def "get All File Definitions By Logical Column names method"(){
		given:
		def retValue
		def logicalColumnName
		def logicalTableName
		def localUrl = url + "/getAllFileDefinitionsByLogicalColumn/"+logicalColumnName+"/"+logicalTableName
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get All Staging Tables  method"(){
		given:
		def retValue
		def localUrl = url + "getAllStagingTables"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get All Encryption Keys  method"(){
		given:
		def retValue
		def localUrl = url + "getAllEncryptionKeys"
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get All Departments  method"(){
		given:
		def retValue
		def localUrl = url + "getAllDepartments"
		ListingCriteria listingCriteria = new ListingCriteria()
		listingCriteria.setSortBy("ASC")
		listingCriteria.setSortUsing("departmentname")
		listingCriteria.setPageNumber(1)
		listingCriteria.setPageSize(7)
		when:
		retValue = restTemplate.postForEntity(localUrl,listingCriteria,Object.class)
		then:
		retValue !=null
		println ""+retValue
	}
	def "get All File Definitions Names  method"(){
		given:
		def retValue
		def localUrl = url + "getAllFileDefinitionsNames"
		searchCriteria.put("departmentID",1);
		when:
		retValue = restTemplate.postForEntity(localUrl,searchCriteria,Object.class)
		then:
		retValue !=null
		println ""+retValue
	}
	def "get All Tables And Files  method"(){
		given:
		def retValue
		def sourceType='T'
		def localUrl = url + "getAllTablesAndFiles/"+sourceType+"/"+fileDefinitionBO.getAudienceID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "update schedule  method"(){
		given:
		def retValue
		def localUrl = url + "updateschedule"
		fileScheduleBO = new FileScheduleBO();
		fileScheduleBO.setFileScheudleID(fileScheduleBO.getFileScheudleID())
		fileScheduleBO.setFileDefintionID(fileDefinitionBO.getFileDefinitionID());
		fileScheduleBO.setFrequency("M".charAt(0));
		fileScheduleBO.setScheduleStartDate(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-10-2018 00:00:00"));
		fileScheduleBO.setScheduleEndDate(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-11-2018 00:00:00"));
		fileScheduleBO.setSchedulenextdue(new SimpleDateFormat("dd-MM-YYYY hh:mm:ss").parse("30-12-2018 00:00:00"));
		fileScheduleBO.setFrequencyUnit(1);
		fileScheduleBO.setIncludeDays(3);
		fileScheduleBO.setMonthlySchdFreq("D".charAt(0));
		fileScheduleBO.setDayOfEveryMonth(3);
		fileScheduleBO.setCreatedBy("zh17");
		when:
		retValue = restTemplate.postForEntity(localUrl,fileScheduleBO,Object.class)
		then:
		retValue !=null
	}
	def "update File Definition Status  method"(){
		given:
		def retValue
		def localUrl = url + "updateFileDefinitionStatus"
		def Map<String,String> requestData =  new HashMap<>();
		requestData.put("fileDefinitionId",fileDefinitionBO.getFileDefinitionID());
		requestData.put("fileDefinitionStatus","I");
		when:
		retValue = restTemplate.postForEntity(localUrl,requestData,Object.class)
		then:
		retValue !=null
	}
	def "update File Activity status  method"(){
		given:
		def retValue
		def status='C'
		def localUrl = url + "updateFileActivitystatus/"+fileActivityID+"/"+status
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "get vertica db table columns  method"(){
		given:
		def retValue
		
		def localUrl = url + "getverticadbtablecolumns/"+tableName
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
		println "Result"+retValue
	}
	def "update file definition activity status  method"(){
		given:
		def retValue
		def status='C'
		def localUrl = url + "updatefiledefinitionactivitystatus/"+fileActivityID+"/"+status+"/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class)
		then:
		retValue !=null
	}
	def "delete File Activity method"() {
		given:
		def retValue
		def localUrl = url + "deleteFileActivity/"+fileActivityID
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue !=null
	}
	def "delete File Definition method"() {
		given:
		def retValue
		def localUrl = url + "deleteFileDefinition/"+fileDefinitionBO.getFileDefinitionID()
		when:
		retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
		retValue !=null
	}
}
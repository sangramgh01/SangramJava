package com.zetainteractive.zetahub.file.controller

import java.util.ArrayList
import java.util.List;
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

import org.springframework.boot.SpringApplication
import org.springframework.context.ConfigurableApplicationContext
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate

import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification;

import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO

class ListControllerTest extends Specification{
	
	
	@Shared
	@AutoCleanup
	ConfigurableApplicationContext context

	@Shared
	ListDefinitionBO listDefinitionBO;
	@Shared
	String url;

	@Shared
	RestTemplate restTemplate;
	
	@Shared
	Map<String, String> searchCriteria = new HashMap<String, String>();


	def "prepare FileDefinitionBO object for request"(){
		given: 	url  =  "http://localhost:7092/list/";
		prepareInput();
		restTemplate = new RestTemplate();
	}
	
	void prepareInput(){
		listDefinitionBO = new ListDefinitionBO();
		List<ColumnDefinitionBO> columnDefinitionList = new ArrayList<ColumnDefinitionBO>();
		ColumnDefinitionBO columnDefinitionBO = new ColumnDefinitionBO();
		columnDefinitionBO.setColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setColumnType("STRING");
		columnDefinitionBO.setIsCustomColumn("N".charAt(0));
		columnDefinitionBO.setLength(400);
		columnDefinitionBO.setUseInList("Y".charAt(0));
		columnDefinitionBO.setDefaultValue("EMAIL_ADDRESS");
		columnDefinitionBO.setIsNullable("N".charAt(0));
		columnDefinitionBO.setColumnPositionInFile(1);
		columnDefinitionBO.setLogicalColumnName("Email Address");
		columnDefinitionBO.setLogicalTableName("EMAIL_ADDRESS");
		columnDefinitionBO.setPhysicalColumnName("EMAIL_ADDRESS");
		columnDefinitionBO.setPhysicalTableName("EMAIL_ADDRESS");
		columnDefinitionBO.setUnsubscribe("Y".charAt(0));
		columnDefinitionBO.setAddressType("Home");
		columnDefinitionList.add(columnDefinitionBO);
		listDefinitionBO.setName("test_19Aug_1");
		listDefinitionBO.setListType("G".charAt(0));
		listDefinitionBO.setAudienceID(368);
		listDefinitionBO.setSourceType("F".charAt(0));
		listDefinitionBO.setTableName("ADHOC_LIST");
		listDefinitionBO.setFolderID(1);
		listDefinitionBO.setCategoryID(3);
		listDefinitionBO.setColumnDefinitionList(columnDefinitionList);
		listDefinitionBO.setPreviousFolderID(0);
		listDefinitionBO.setDeptID(1);
		listDefinitionBO.setStatus("W".charAt(0));
		listDefinitionBO.setFileDefinitionID(165);
		listDefinitionBO.setChannelType("E".charAt(0));
		listDefinitionBO.setFilter("");
		listDefinitionBO.setCreatedBy("admin");
	}
	
	def "saveList method"()
	{
		given:
			def retValue
			def localUrl = url + "saveList"
		when:
			retValue = restTemplate.postForEntity( localUrl,listDefinitionBO, Object.class);
		then:
			retValue !=null
	}
	
	def "getAllLists method"()
	{
		given:
			def retValue
			def localUrl = url + "getAllLists"
		when:
			retValue = restTemplate.postForEntity(localUrl,searchCriteria,Object.class);
		then:
			retValue !=null
	}
	
	def "deleteAdhocList method"()
	{
		given:
			def retValue
			def localUrl = url + "deleteAdhocList/1"
		when:
			retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
			retValue !=null
	}
	
	
	def "getColumnDefinitionList method"()
	{
		given:
			def retValue
			def type = ""
			def audienceId = ""
			def localUrl = url + "/getColumnDefinitionList/"+type+"/"+audienceId
		when:
			retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
			retValue !=null
	}
	
	
	def "getAllLists method by pagenation"()
	{
		given:
			def retValue
			def pageno = ""
			def audienceId = ""
			def localUrl = url + "/getAllAdhocList/"+pageno+"/"+pageSize
		when:
			retValue = restTemplate.getForEntity(localUrl,Object.class);
		then:
			retValue !=null
	}
}

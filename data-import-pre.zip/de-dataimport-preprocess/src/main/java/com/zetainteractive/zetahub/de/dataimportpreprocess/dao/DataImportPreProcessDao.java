/**
 * DataImportDao.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimportpreprocess.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:30:50 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcessDao" is used for 
 */

public interface DataImportPreProcessDao {
	/**
	 * 
	 * 
	 * Method Name 	: createTempTable
	 * Description 	: The Method "createTempTable" is used for 
	 * Date    		: Oct 7, 2016, 1:36:36 AM
	 * @param tempTableDDL
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	public boolean createTempTable(String tempTableDDL) throws SQLException;
	/**
	 * 
	 * 
	 * Method Name 	: loadDatatoTempTable
	 * Description 	: The Method "loadDatatoTempTable" is used for 
	 * Date    		: Oct 7, 2016, 1:36:45 AM
	 * @param copyCommand
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	public boolean loadDataToTempTable(String copyCommand) throws SQLException;

	public Long getNewBatchId();
	/**
	 * 
	 * @param fileDefinitionId
	 * @return
	 */
	public List<String> getActivitiesDetails(Long fileDefinitionId);
	/**
	 * 
	 * @param fileDefinitionId
	 * @return
	 */
	public HashMap<Long, List<String>> getRetryActivityDetails(Long fileDefinitionId);
	/**
	 * 
	 * Method Name 	: dropTable
	 * Description 	: The Method "dropTable" is used for 
	 * Date    		: Oct 12, 2016, 2:50:54 PM
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws 		: 
	 */
	public boolean dropTable(String tempTableName);
}

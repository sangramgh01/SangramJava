/**
 * DataImportPreProcessDaoImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimportpreprocess.dao.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.de.dataimportpreprocess.dao.DataImportPreProcessDao;

/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:31:06 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcessDaoImpl" is used for 
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS)
public class DataImportPreProcessDaoImpl implements DataImportPreProcessDao {
	
	@Autowired
	@Qualifier("whJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	@Qualifier("preProcessClientJdbcTemplate")
	JdbcTemplate custJdbcTemplate;
	
	
	private ZetaLogger logger = new ZetaLogger(this.getClass());

	/**
	 * 
	 * Method Name 	: createTempTable
	 * Description 		: The Method "createTempTable" is used for 
	 * Date    			: Oct 6, 2016, 11:56:35 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public boolean createTempTable(String tempTableDDL) throws SQLException{
		logger.debug("Create temp table Query :: "+tempTableDDL);
		jdbcTemplate.execute(tempTableDDL);
		
		return true;
	}

	/**
	 * 
	 * Method Name 	: loadDatatoTempTable
	 * Description 		: The Method "loadDatatoTempTable" is used for 
	 * Date    			: Oct 6, 2016, 11:56:35 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public boolean loadDataToTempTable(String query) throws SQLException{
		logger.debug("Temp table load Query :: "+query);
		 jdbcTemplate.execute(query);
		 return true;
	}
	
	@Override
	public Long getNewBatchId() {
		return jdbcTemplate.queryForObject("select nextval('FORGEIDSEQUENCE')",Long.class);
	}
	
	@Override
	public List<String> getActivitiesDetails(Long fileDefinitionId) {
		String query = "SELECT STATUS from LFD_FILEACTIVITY WHERE filedefinitionid="+fileDefinitionId+" AND STATUS IN ('R','E','P')";
		return custJdbcTemplate.queryForList(query,String.class);
	}

	@Override
	public HashMap<Long, List<String>> getRetryActivityDetails(Long fileDefinitionId) {
		logger.debug("Begin : "+getClass().getName()+" : getRetryActivityDetails(Long fileDefinitionId)");
		HashMap<Long,List<String>> activityMap= new HashMap<>();
		List<String> fnames=null;
		Long batchId = null;
		
		String query = "SELECT batchId from LFD_FILEACTIVITY WHERE filedefinitionid="+fileDefinitionId+" AND STATUS='R'";
		List<Long> batchIds = custJdbcTemplate.queryForList(query, Long.class);
		if(batchIds!=null && !batchIds.isEmpty()){
			batchId = batchIds.get(0);
			query = "SELECT filename from LFD_FILEACTIVITY WHERE filedefinitionid="+fileDefinitionId+" AND STATUS IN ('R','P') AND batchId="+batchId;
			fnames = custJdbcTemplate.queryForList(query,String.class);
		}else{
			query = "SELECT batchId from LFD_FILEACTIVITY WHERE filedefinitionid="+fileDefinitionId+" AND STATUS='P'";
			batchIds = custJdbcTemplate.queryForList(query,Long.class);
			if(batchIds!=null && !batchIds.isEmpty()){
				batchId = batchIds.get(0);
				query = "SELECT filename from LFD_FILEACTIVITY WHERE filedefinitionid="+fileDefinitionId+" AND STATUS IN ('P') AND batchId="+batchId;
				fnames = custJdbcTemplate.queryForList(query,String.class);
			}
		}
		if(batchId!=null && fnames!=null)
			activityMap.put(batchId, fnames);
		logger.debug("End : "+getClass().getName()+" : getRetryActivityDetails(Long fileDefinitionId)");
		return activityMap;
	}

	/**
	 * 
	 * Method Name 	: dropTable
	 * Description 		: The Method "dropTable" is used for 
	 * Date    			: Oct 12, 2016, 2:51:11 PM
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public boolean dropTable(String tempTableName) {
		logger.debug("Begin : "+getClass().getName()+" : dropTable(String tempTableName)");
		boolean result = false;
		try {
			if (tempTableName != null && tempTableName.length() > 0) {
				logger.debug("Drop query for TEMP Table:::::::::   DROP TABLE IF EXISTS " + tempTableName);
				jdbcTemplate.execute("DROP TABLE IF EXISTS " + tempTableName);
				result = true;
			}
		} catch (Exception e) {
			result = false;
		}
		logger.debug("End : "+getClass().getName()+" : dropTable(String tempTableName)");
		return result;
		
	}
}

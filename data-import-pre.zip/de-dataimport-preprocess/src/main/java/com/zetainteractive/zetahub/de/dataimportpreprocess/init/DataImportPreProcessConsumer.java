package com.zetainteractive.zetahub.de.dataimportpreprocess.init;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.kafka.AvroSimpleConsumer;
import com.zetainteractive.zetahub.bootstarter.ZetaContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.CommonNotificationBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.EncryptionKeyBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.LogicalTableBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.NotificationStatus;
import com.zetainteractive.zetahub.commons.domain.Notifications;
import com.zetainteractive.zetahub.de.commons.BatchStatus;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.commons.DataImportProgress;
import com.zetainteractive.zetahub.de.commons.KafkaGroupNames;
import com.zetainteractive.zetahub.de.commons.KafkaTopicNames;
import com.zetainteractive.zetahub.de.dao.DataImportProgressDao;
import com.zetainteractive.zetahub.de.dataimportpreprocess.process.DataImportPreProcess;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessorDependencyCalls;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:25:13 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcessConsumer" is used for 
 */
@Component
public class DataImportPreProcessConsumer extends AvroSimpleConsumer {

	@Autowired
	DIPreProcessorDependencyCalls dependencyCalls;
	
	ZetaLogger logger=new ZetaLogger(this.getClass());
	
	@Autowired
	DataImportPreProcess dataImportProcess;
	
	@Autowired
	DataImportProgressDao dataImportProgressDao;
	
	/**
	 * 
	 * @param group
	 * @param topic
	 * @param schemaStringConstructor "DataImportPreProcessConsumer" is used for
	 * @throws Exception 
	 */
	public DataImportPreProcessConsumer() throws Exception {
		super(ZetaUtil.getHelper().getTopicGroup(KafkaGroupNames.getDATAIMPORTPREPROCESSGROUP()), ZetaUtil.getHelper().getTopic(KafkaTopicNames.getDATAIMPORTPREPROCESSTOPIC()));
		try {
			//pollingInterval = ZetaUtil.getHelper().getConfig().getConfigValueInt("kafka-topic-poll-interval", 3600000)
			pollingInterval =ZetaUtil.getHelper().getConfig().getConfigValueInt("dataimport-kafka-topic-pollinterval", 3600000);
		} catch (Exception e) {
			logger.error("Exception Occured while creating consumer : "+e.getMessage(),e);
		}
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.kafka.AvroSimpleConsumer#processMessage(org.apache.avro.generic.GenericRecord, java.util.List)
	 */
	@Override
	public boolean processMessage(ConsumerRecord<String, byte[]> consumerRecord, GenericRecord header, List<GenericRecord> records){
		logger.info("Got the processMessage call " + header.toString() + " : " + records.size());
		Long fileDefinitionId=null;
		DataImportDTO  dataImportDTO=null;
		DataImportProgress dataImportProgress=null;
		try {
				dataImportDTO=new DataImportDTO();
			    long offset=consumerRecord.offset();
				int partition=consumerRecord.partition();
				Integer userid = (Integer)header.get("userid");
				String customerCode=header.get("customer_code").toString();
				String userName=header.get("username").toString();
				logger.info("Customer code :: "+customerCode+"  username :: "+userName);
				initializeContext(customerCode,userName,userid);
				ZetaUtil.getHelper().setLoggingContextKey(header.get("context_key").toString());
				GenericRecord scheduleObj = records.get(0);
				fileDefinitionId = (Long) scheduleObj.get("FileDefintionID");
				
				logger.info("Got Message from partition number :::"+partition+" and offset :: "+offset+"  filedeinitionid:: "+fileDefinitionId);
				dataImportProgress=dataImportProgressDao.getDataImportProgressByType(offset, partition, ZetaUtil.getHelper().getTopic(KafkaTopicNames.getDATAIMPORTPREPROCESSTOPIC()),fileDefinitionId,"D");
				if(dataImportProgress==null){
					dataImportProgress=prepareDataImportProgress(offset, partition);
				}
				if (dataImportProgress.getPreprocess_status() == BatchStatus.READY.getValue()){
					dataImportProgress.setPreprocess_status(BatchStatus.IN_PROGRESS.getValue());
					dataImportProgress.setSourceId(fileDefinitionId);
					dataImportProgress.setSourceType('D');
					
					dataImportProgress.setUpdatedBy(userName);
					dataImportProgress.setCreatedBy(userName);
					dataImportDTO=prepareDataImportDTO(fileDefinitionId,dataImportDTO);
					
					dataImportDTO.setCustCode(customerCode);
					
					if ("DIMENTION".equals(dataImportDTO.getImportType()))
						dataImportProgress.setAudienceId(-1);
					else if ("UNSUB".equals(dataImportDTO.getImportType()) || "RESUB".equals(dataImportDTO.getImportType())){
						long audienceId=0;
						logger.debug("Audience type  is :: "+dataImportDTO.getAudienceType());
						if ("EMAIL".equals(dataImportDTO.getAudienceType()))
							audienceId=dependencyCalls.getAudienceIdByName("Email Address Audience");
						else
							audienceId=dependencyCalls.getAudienceIdByName("Sms Audience");
						logger.info("Audience id is :: "+audienceId);
						dataImportProgress.setAudienceId(audienceId);
					}else{
						logger.info("Audience id is :: "+dataImportDTO.getAudienceId());
						dataImportProgress.setAudienceId(dataImportDTO.getAudienceId());
					}
					
					dataImportProgress.setDataImportProgressID(dataImportProgressDao.createDataImportProgress(dataImportProgress));
					dataImportDTO.setDataImportProgress(dataImportProgress);
					dataImportProcess.processFileDefinition(dataImportDTO);
					dataImportProgressDao.updateDataPreProcessStatus(dataImportProgress);
				}else{
					logger.info("Message already processed with offset :: "+offset+" and partition :: "+partition+" filedefinitionid :: "+fileDefinitionId);
				}
				
		}catch (Exception e) {
			try {
				if(fileDefinitionId!=null && fileDefinitionId>0)
					dependencyCalls.updateFileDefinitionStatus('E',dataImportDTO,e.getMessage());
				if(dataImportProgress!=null){
					dataImportProgress.setPreprocess_status(BatchStatus.ERRORED.getValue());
					dataImportProgressDao.updateDataPreProcessStatus(dataImportProgress);
				}
					
			} catch (Exception e1) {
				logger.error(e1.getMessage(),e1);
			}
			logger.error("Exception occured while importing data for fileDefinition ::",e);
		}finally {
			try {
				ZetaUtil.getHelper().clearLoggingContextKey();
			} catch (Exception e2) {
				logger.error(e2.getMessage(),e2);
			}
		}
		return true;
	}

	/**
	 * 
	 * Method Name 	: prepareDataImportDTO
	 * Description 	: The Method "prepareDataImportDTO" is used for 
	 * Date    		: Oct 6, 2016, 6:46:03 PM
	 * @param header
	 * @param records
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: DataImportDTO
	 * @throws 		:
	 */
	private DataImportDTO prepareDataImportDTO(Long fileDefintionId,DataImportDTO dataImportDTO) throws Exception {
		logger.info("Begin :: prepareDataImportDTO");
		Map<String,String> defaultValueMap=new HashMap<>();
		FileDefinitionBO fileDefinition = dependencyCalls.getFileDefintion(fileDefintionId);
		boolean isNonAudienceImport = false;
		boolean isUnsubResub=false;
		AudienceBO audienceDetails = null;
		if(fileDefinition.getFileType().equals(PreProcessorConstants.IMPORT_TYPE_ADHOC.toString().charAt(0))){
			dataImportDTO.setImportType("ADHOCIMPORT");
			String listType=dependencyCalls.getListType(fileDefintionId);
			if(listType != null)
				dataImportDTO.setListType(listType.charAt(0));
		}else if(fileDefinition.getFileType().equals(PreProcessorConstants.IMPORT_TYPE_DIMENTION.toString().charAt(0))){
			dataImportDTO.setImportType("DIMENTION");
			isNonAudienceImport = true;
		}else if(fileDefinition.getFileType().equals(PreProcessorConstants.IMPORT_TYPE_BASE.toString().charAt(0))){
			dataImportDTO.setImportType("BATCHIMPORT");
		}else if(fileDefinition.getFileType().equals(PreProcessorConstants.IMPORT_TYPE_RESUB.toString().charAt(0))){
			dataImportDTO.setImportType("RESUB");
			isNonAudienceImport = true;
			isUnsubResub = true;
		}else if(fileDefinition.getFileType().equals(PreProcessorConstants.IMPORT_TYPE_UNSUB.toString().charAt(0))){
			dataImportDTO.setImportType("UNSUB");
			isNonAudienceImport = true;
			isUnsubResub = true;
		}
		if(!isNonAudienceImport){
			audienceDetails = dependencyCalls.getAudience(fileDefinition.getAudienceID());
			if(audienceDetails.getAudienceType()==1)
				   dataImportDTO.setAudienceType("EMAIL");
			else if(audienceDetails.getAudienceType()==4)
				   dataImportDTO.setAudienceType("SMS");
			else if(audienceDetails.getAudienceType()==0)
				   dataImportDTO.setAudienceType("CUSTOM");
		}else{
			if(isUnsubResub){
				String TABLE_EMAIL = "AUDIENCE_EMAIL";
				String TABLE_SMS = "AUDIENCE_SMS";
				if(fileDefinition.getChannelType().equals('E')){
					dataImportDTO.setAudienceType("EMAIL");
					dataImportDTO.setBaseTablePhysicalName(TABLE_EMAIL);
				}else if(fileDefinition.getChannelType().equals('S')){
					dataImportDTO.setAudienceType("SMS");
					dataImportDTO.setBaseTablePhysicalName(TABLE_SMS);
				}
			}else{
				dataImportDTO.setBaseTablePhysicalName(fileDefinition.getTableName());
				dataImportDTO.setAudienceType("NONAUD");
			}
			
		}
		
		
		dataImportDTO.setFileDefinitionId(fileDefintionId);
		dataImportDTO.setFileDefinitionBO(fileDefinition);
		dataImportDTO.setListid(fileDefintionId);
		dataImportDTO.setAudienceId((fileDefinition.getAudienceID()==null)?0L:fileDefinition.getAudienceID());
		
		// Notification mails added to dataimportdto
		dataImportDTO.setIsNotificationEnabled(false);
		Map<String,String> notificationMails=new HashMap<>();
		if (fileDefinition.getNotifications() !=null && fileDefinition.getNotifications().getIsEnabled()){
			dataImportDTO.setIsNotificationEnabled(true);
			notificationMails=getNotificationEmailDetails(fileDefinition.getNotifications());
		}
		DepartmentSettings departmentSettings=dependencyCalls.getNotificationsFromDepartment(fileDefinition.getDepartmentID());
		CommonNotificationBO commonNotificationBO=getNotificationStatus(departmentSettings, fileDefinition.getFileType()=='A' ? "Lists" :"Files");
		if (commonNotificationBO != null && commonNotificationBO.getIsEnabled()){
			dataImportDTO.setIsNotificationEnabled(true);
			notificationMails=getDepartmentEmailDetails(commonNotificationBO, notificationMails);
		}
		dataImportDTO.setNotificationEmails(notificationMails);
		//End notification messages
		
		if(fileDefinition.getUseEncryption() == 'Y'){
			EncryptionKeyBO encryptionKeyBO = getEncryptionKeyBO(fileDefinition.getEncryptionKey());
			if(encryptionKeyBO != null)
				dataImportDTO.setEncryptionKeyBO(encryptionKeyBO);
		}
		
		if(fileDefinition.getFileMapping()!=null && fileDefinition.getFileMapping().getColumnDefinitionList()!=null){
			List<Column> columns=new ArrayList<>();
			List<ColumnDefinitionBO> columnDefinitionList=fileDefinition.getFileMapping().getColumnDefinitionList();
			for(ColumnDefinitionBO columnDefinition : columnDefinitionList){
				if (columnDefinition.getColumnType() !=null && !columnDefinition.getColumnType().equalsIgnoreCase("Omit")){
				Column column=new Column();
				String colName ;
				column.setIsCustomColumn((columnDefinition.getIsCustomColumn()==null||columnDefinition.getIsCustomColumn()=='N')?false:true);
				if(columnDefinition.getPhysicalColumnName()==null){
					colName = columnDefinition.getColumnName().replaceAll("[^a-zA-Z0-9]+","_");
				}else{
					if(column.isIsCustomColumn()){
						colName = columnDefinition.getPhysicalColumnName().replaceAll("[^a-zA-Z0-9]+","_");
					}else{
						colName =columnDefinition.getPhysicalColumnName();
					}
					
				}
				column.setColumnName(colName);
				column.setDataType(changeDataType(columnDefinition.getColumnType()));
				
				column.setIsNullable((columnDefinition.getIsNullable()==null||columnDefinition.getIsNullable()=='N')?false:true);
				column.setLength(columnDefinition.getLength());
				if(columnDefinition.getAddressType()!=null)
					column.setCategoryType(Long.parseLong(columnDefinition.getAddressType()));
				if(!isNonAudienceImport){
					dataImportDTO.setBaseTablePhysicalName(getPhysicalTableName(columnDefinitionList));
					for(LogicalTableBO logicalTableBO : audienceDetails.getLogicalTables()){
						if(logicalTableBO.getPhysicalTableName().equalsIgnoreCase(columnDefinition.getPhysicalTableName())){//Get only base columns
							for(LogicalColumnBO logicalColumn : logicalTableBO.getLogicalColumns()){
								if(logicalColumn.getPhysicalColumnName().equals(columnDefinition.getPhysicalColumnName()) 
									&& logicalColumn.getIsKeyColumn()=='Y')
									column.setIsKey(true);
							}
						}
					}
				}
				if (!isUnsubResub) {
					if (columnDefinition.getDefaultValue() != null)
						column.setDefaultValue(columnDefinition.getDefaultValue());
					else if (defaultValueMap.get(columnDefinition.getPhysicalColumnName()) != null)
						column.setDefaultValue(defaultValueMap.get(columnDefinition.getPhysicalColumnName()));
					else if (columnDefinition.getIsCustomColumn() != 'Y'){
						defaultValueMap.putAll(dependencyCalls.getPhysicalColumnsAndDefaultValues(columnDefinition.getPhysicalTableName()));
						if (defaultValueMap.get(columnDefinition.getPhysicalColumnName()) != null)
							column.setDefaultValue(defaultValueMap.get(columnDefinition.getPhysicalColumnName()));
					}
				}
				if(isUnsubResub){
					if(dataImportDTO.getImportType().equals("UNSUB")){
						column.setIsUnsub(true);
					}else{
						column.setIsUnsub(false);
					}
				}			
				else
					column.setIsUnsub((columnDefinition.getUnsubscribe()==null || columnDefinition.getUnsubscribe()=='N')?false:true);
				column.setColumnPositionInFile(columnDefinition.getColumnPositionInFile());
				columns.add(column);
				}
			}
			if(!isNonAudienceImport || isUnsubResub){
				Column column=new Column();
				column.setColumnName("ISNEW_2");
				column.setDataType("BOOLEAN");
				columns.add(column);
			}
			
			
			
			dataImportDTO.setColumns(columns);
			dataImportDTO.setIsWorkFlowAssociated((fileDefinition.getSendWorkFlow()==null || fileDefinition.getSendWorkFlow()=='N')?false:true);
			dataImportDTO.setWorkFlowID((fileDefinition.getWorkFlowID()==null)?0L:fileDefinition.getWorkFlowID());
			dataImportDTO.setFileActivityIds(new ArrayList<Long>());
			dataImportDTO.setTempTableName(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid());
			dataImportDTO.setFileAction(fileDefinition.getFileAction());
			dataImportDTO.setTableDisposition(fileDefinition.getTableDisposition());
		}
		logger.info("End :: prepareDataImportDTO");
		return dataImportDTO;
	}
	
	private void initializeContext(String customerCode,String userName,Integer userId) throws Exception{
		ZetaContext ctx = ZetaUtil.getHelper(customerCode, null);
		UserBO uBo = new UserBO();
		uBo.setUserID(userId);
		uBo.setUserName(userName);
		ctx.setUser(uBo);
	}
	
	private String changeDataType(String columnType){
		String changedDataType=columnType;
		switch(changedDataType){
			case "BYTEINT" : 
			case "INT"     :   changedDataType="INTEGER";
			                   break;
			case "DATETIME":   changedDataType="TIMESTAMP";
			                   break;
			case "DECIMAL" :   changedDataType="DOUBLE";
			                   break;
			case "STRING"  :   changedDataType="VARCHAR";
			                   break;
		}
		return changedDataType;
	}
	/**
	 * 
	 * 
	 * Method Name 	: getNotificationEmailDetails
	 * Description 	: The Method "getNotificationEmailDetails" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param notifications
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: Map<String,String>
	 * @throws 		:
	 */
	public Map<String,String> getNotificationEmailDetails(Notifications notifications) throws Exception {
		Map<String,String> emailAddresses=new HashMap<>();
		if (notifications.getDefaultEmailAddresses() != null )
			emailAddresses.put("default", notifications.getDefaultEmailAddresses());
		List<NotificationStatus> notificationStatusList=notifications.getNotificationStatuses();
		for (NotificationStatus notificationStatus :notificationStatusList){
			if (notificationStatus.getIsEnabled()){
				if( notificationStatus.getEmailAddresses() !=null)
					emailAddresses.put(notificationStatus.getName(), notificationStatus.getEmailAddresses());
				else 
					emailAddresses.put(notificationStatus.getName(), "-");
			}
		}
		return emailAddresses;	
	}
	
	/**
	 * 
	 * 
	 * Method Name 	: getDepartmentEmailDetails
	 * Description 	: The Method "getDepartmentEmailDetails" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param commonNotificationBO
	 * @param emailAddresses
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: Map<String,String>
	 * @throws 		:
	 */
	public Map<String,String> getDepartmentEmailDetails(CommonNotificationBO commonNotificationBO,Map<String,String> emailAddresses) throws Exception {
		if (commonNotificationBO.getDefaultEmailAddresses() != null && !emailAddresses.containsKey("default"))
			emailAddresses.put("default", commonNotificationBO.getDefaultEmailAddresses());
		List<NotificationStatus> notificationStatusList=commonNotificationBO.getNotificationStatuses();
		for (NotificationStatus notificationStatus :notificationStatusList){
			if (notificationStatus.getIsEnabled()){
				if( notificationStatus.getEmailAddresses() !=null 
						&& (!emailAddresses.containsKey(notificationStatus.getName()) ||"-".equals(emailAddresses.get(notificationStatus.getName()))))	
						emailAddresses.put(notificationStatus.getName(), notificationStatus.getEmailAddresses());
				else if(!emailAddresses.containsKey(notificationStatus.getName()))
					emailAddresses.put(notificationStatus.getName(), "-");
			} 
			
		}
		return emailAddresses;	
	}
	
	private EncryptionKeyBO getEncryptionKeyBO(String encryptionKey) throws Exception{
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity<?> entity = new HttpEntity<>(headers);
		List<EncryptionKeyBO> response = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/listfileEncryptions", HttpMethod.GET, entity, new ParameterizedTypeReference<List<EncryptionKeyBO>>() {}).getBody();
		EncryptionKeyBO encryptionKeyBO = null;
		for(EncryptionKeyBO encryptionBO : response){
			if(encryptionBO.getEncryptionKeyName() != null && encryptionBO.getEncryptionKeyName().equals(encryptionKey)){
				encryptionKeyBO = encryptionBO;
				break;
			}
		}
		return encryptionKeyBO;
	}
	
	public String getPhysicalTableName(final List<ColumnDefinitionBO> list) {
		return list.stream().filter(rr -> rr.getPhysicalTableName()!= null).findFirst().get().getPhysicalTableName();
    }
	
	private DataImportProgress prepareDataImportProgress(long offset,int partition){
		DataImportProgress dataImportProgress=new DataImportProgress();
		dataImportProgress.setPreprocess_offSet(offset);
		dataImportProgress.setPreprocess_partition(partition);
		dataImportProgress.setPreprocess_status(BatchStatus.READY.getValue());
		
		dataImportProgress.setImportprocess_offSet(-1l);
		dataImportProgress.setImportprocess_partition(0);
		dataImportProgress.setImportprocess_status(0);
		
		dataImportProgress.setWorkflowprocess_offSet(-1l);
		dataImportProgress.setWorkflowprocess_partition(0);
		dataImportProgress.setWorkflowprocess_status(0);
		
		return dataImportProgress;
		
	}
	
	private CommonNotificationBO getNotificationStatus(DepartmentSettings departmentSettings,String notificationName){
		CommonNotificationBO commonNotificationBO=null;
		try {
			if (departmentSettings !=null ){
				ObjectMapper objectMapper=new ObjectMapper();
				NotificationBO notificationBO=objectMapper.convertValue(departmentSettings.getObjectValue(),NotificationBO.class);
				if (notificationBO !=null && notificationBO.getNotifications() !=null && !notificationBO.getNotifications().isEmpty()){
					for (CommonNotificationBO cmnNotificationBO: notificationBO.getNotifications()){
						if (cmnNotificationBO.getNotificationTypeName().equalsIgnoreCase(notificationName)){
							commonNotificationBO=cmnNotificationBO;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return commonNotificationBO;
	}
}

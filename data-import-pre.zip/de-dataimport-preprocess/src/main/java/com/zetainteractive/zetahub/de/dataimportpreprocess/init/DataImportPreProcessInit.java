/**
 * 
 */
package com.zetainteractive.zetahub.de.dataimportpreprocess.init;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.zetainteractive.zetahub.bootstarter.BootInitializer;
import com.zetainteractive.zetahub.bootstarter.SpringApplicationContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;

/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 7:04:58 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcessInit" is used for 
 */
@SpringBootApplication
@EnableAutoConfiguration (exclude={DataSourceAutoConfiguration.class})
@Configuration
@ComponentScan(basePackages = { "com.zetainteractive.zetahub.de.*, com.zetainteractive.zetahub.commons.Util" })
public class DataImportPreProcessInit {

	/**
	 * Method Name 	: main
	 * Description 	: The Method "main" is used for 
	 * Date    		: Oct 6, 2016, 7:05:11 PM
	 * @param args
	 * @throws Exception
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	 public static void main(String[] args) throws Exception {

		BootInitializer.runApp(DataImportPreProcessInit.class, args);
		ApplicationContext context = SpringApplicationContext.getContext();
		//Now lets get an instance of the ZetaHelper
		ZetaUtil zetaUtil = new ZetaUtil();
		ZetaLogger logger = new ZetaLogger(DataImportPreProcessInit.class);
		logger.info("DE Data Import App Started...");

		String brokerList = zetaUtil.getHelper().getConfig().getConfigValueString("kafka-broker-list", null);
		
		DataImportPreProcessConsumer consumer = context.getBean(DataImportPreProcessConsumer.class);
		
		consumer.setBrokerList(brokerList);
		consumer.addBrokerConfig("admin-ga-app-client-id", zetaUtil.getHelper().getAppId());
		consumer.start();
		
		/* start an executor service */
		ExecutorService executor = Executors.newFixedThreadPool(1);
		executor.submit(consumer);

		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				executor.shutdown();
				try {
					executor.awaitTermination(5000, TimeUnit.MILLISECONDS);
					DataImportPreProcessProducer producer = SpringApplicationContext.getContext().getBean(DataImportPreProcessProducer.class);
					producer.stopProducer();
				} catch (InterruptedException e) {
					e.printStackTrace();
					logger.error("Exception occured in DE DataImport App :",e);
				}
			}
		});

	}

}

package com.zetainteractive.zetahub.de.dataimportpreprocess.init;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericData.Record;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.avro.AvroUtil;
import com.zetainteractive.kafka.AvroSimpleProducer;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.commons.KafkaTopicNames;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 3, 2016 5:18:15 PM
 * @Version	   : 1.7
 * @Description: "ContentSchedulerProducer" is used for 
 * 
 *
 */
@Component
public class DataImportPreProcessProducer{

	AvroSimpleProducer producer;
	ZetaLogger logger = new ZetaLogger(getClass());	
	
	/**
	 * @param dataImportDTO
	 * @throws Exception
	 */
	public void addMessageToQueue(DataImportDTO dataImportDTO) throws Exception{
		Record record=makeObject(makeSchema(),dataImportDTO);
		produceMessage(dataImportDTO,record);
	}
	
	private Schema makeChildSchema(){
		return SchemaBuilder.record("ColumnInfo").namespace("com.zetainteractive.avro").fields()
							.name("columnName").type().nullable().stringType().noDefault()
							.name("dataType").type().nullable().stringType().noDefault()
							.name("defaultValue").type().nullable().stringType().noDefault()
							.name("isKey").type().nullable().booleanType().noDefault()
							.name("categoryType").type().nullable().longType().noDefault()
							.name("isNullable").type().nullable().booleanType().noDefault()
							.name("isCustomColumn").type().nullable().booleanType().noDefault()
							.name("length").type().nullable().intType().noDefault()
							.name("isUnsub").type().nullable().booleanType().noDefault()
				            .endRecord();
	}
	
	private Schema makeSchema(){
		Schema columnSchema=makeChildSchema();
		return SchemaBuilder.record("DataImportDTO").namespace("com.zetainteractive.avro").fields()
							.name("import_type").type().nullable().stringType().noDefault()
							.name("audience_type").type().nullable().stringType().noDefault()
							.name("temp_table_name").type().nullable().stringType().noDefault()
							.name("base_table_name").type().nullable().stringType().noDefault()
							.name("columns").type().array().items(columnSchema).noDefault()
							.name("file_activity_ids").type().array().items().longType().noDefault()
							.name("is_workflow_associated").type().nullable().booleanType().noDefault()
							.name("workflow_associated").type().nullable().longType().noDefault()
							.name("file_definition_id").type().nullable().longType().noDefault()
							.name("audience_id").type().longType().noDefault()
							.name("file_action").type().nullable().stringType().noDefault()
							.name("table_disposition").type().nullable().stringType().noDefault()
							.name("isNotificationEnabled").type().nullable().booleanType().noDefault()
							.name("notificationEmails").type().nullable().stringType().noDefault()
							.name("isInvalidRecordsExist").type().nullable().booleanType().noDefault()
							.name("file_summary").type().nullable().stringType().noDefault()
							.name("listType").type().nullable().stringType().noDefault()
							.endRecord();
	}
	
	private Record makeObject(Schema schema, DataImportDTO dataImportDTO) throws JsonProcessingException {
		ObjectMapper objectMapper=new ObjectMapper();
		List<Record> childRecords=new ArrayList<>();
		for(Column column : dataImportDTO.getColumns()){
			Record childRecord=new GenericData.Record(makeChildSchema());
			childRecord.put("columnName",column.getColumnName());
			childRecord.put("dataType",column.getDataType());
			childRecord.put("defaultValue",column.getDefaultValue());
			childRecord.put("isKey",column.getIsKey());
			childRecord.put("categoryType",column.getCategoryType());
			childRecord.put("isNullable",column.getIsNullable());
			childRecord.put("isCustomColumn",column.getIsCustomColumn());
			childRecord.put("length",column.getLength());
			childRecord.put("isUnsub",column.getIsUnsub());
			childRecords.add(childRecord);
		}
		Record record = new GenericData.Record(schema);
	    record.put("import_type",dataImportDTO.getImportType());
	    record.put("audience_type",dataImportDTO.getAudienceType());
	    record.put("temp_table_name",dataImportDTO.getTempTableName());
	    record.put("file_activity_ids",dataImportDTO.getFileActivityIds());
	    record.put("columns",childRecords);
	    record.put("base_table_name",dataImportDTO.getBaseTablePhysicalName());
	    record.put("is_workflow_associated",dataImportDTO.getIsWorkFlowAssociated());
	    record.put("workflow_associated",dataImportDTO.getWorkFlowID());
	    record.put("file_definition_id",dataImportDTO.getFileDefinitionId());
	    record.put("audience_id",dataImportDTO.getAudienceId());
	    record.put("file_action",dataImportDTO.getFileAction().toString());
	    record.put("table_disposition",dataImportDTO.getTableDisposition());
	    record.put("isNotificationEnabled", dataImportDTO.getIsNotificationEnabled());
	    record.put("notificationEmails", AvroUtil.getMapAsString(dataImportDTO.getNotificationEmails()));
	    record.put("isInvalidRecordsExist", dataImportDTO.getIsInvalidRecordsExist());
	    record.put("file_summary",objectMapper.writeValueAsString(dataImportDTO.getFileDefinitionBO().getFileSummaryBO()));
	    if (dataImportDTO.getListType() != null )
	    	record.put("listType", String.valueOf(dataImportDTO.getListType()));
	    return record;
	}

	
	private boolean produceMessage(DataImportDTO dataImportDTO,Record record) throws Exception{
		try{
			if(producer==null){
				producer = new AvroSimpleProducer(makeSchema().toString());
				String brokerList = ZetaUtil.getHelper().getConfig().getConfigValueString("kafka-broker-list", null);
				producer.configure(brokerList);
				producer.start();
			}
			producer.addHeader("meta", makeSchema().toString());
	        producer.addHeader("from_process", "dataimport-pre-process");
	        producer.addHeader("to_process",  "dataimport");
	        producer.addHeader("payload_type", "inline");
	        producer.addHeader("payload_location", "inline");
	        producer.addHeader("processing_behavior", "1");
	        producer.addHeader("batch_progress_id", -1L);
	        producer.addHeader("customer_code", dataImportDTO.getCustCode());
	        producer.addHeader("username", ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser", "dataimportuser"));
	        producer.addHeader("trigger_id", 0L);
	        producer.addHeader("conversation_id",  -1L);
	        producer.addHeader("wave_id", -1L);
	        producer.addHeader("campaign_id", -1L);
	        producer.addHeader("blast_id", -1L);
	        producer.addHeader("relative_blastid", -1L);
	        producer.addHeader("batch_id", -1L);
	        producer.addHeader("is_test", "N");
	        producer.addHeader("test_sample_id", 0L);
			producer.addHeader("batch_progress_id", dataImportDTO.getDataImportProgress().getDataImportProgressID());
			producer.addHeader("userid", 1);
	        producer.addHeader("schema", makeSchema().toString());
	        producer.addHeader("context_key", ZetaUtil.getHelper().getLoggingContextKey());
	        Future<RecordMetadata> reFuture = producer.produceMessage(ZetaUtil.getHelper().getTopic(KafkaTopicNames.getDATAIMPORTTOPIC()),record);
			if (reFuture != null) {
				RecordMetadata metadata = reFuture.get();
				logger.info("Message sent to Topic :: ["+metadata.topic()+"] Partition :: ["+metadata.partition()+"] Offset :: ["+metadata.offset()+"]");
			}
		}catch (InterruptedException ie) {
			logger.error("Producer failed to send message with InterruptedException :: "+ie.getMessage(), ie);
		} catch (ExecutionException ee) {
			logger.error("Producer failed to send message with ExecutionException :: "+ee.getMessage(), ee);
		} catch (TimeoutException te) {
		    logger.error("Producer failed to send message with TimeoutException :: "+te.getMessage(), te);
		} catch (KafkaException ke) {
			logger.error("Producer failed to send message with KafkaException :: "+ke.getMessage(), ke);
		}
		return true;
	}
	
	public void stopProducer(){
		if(producer!=null)
			producer.stop();
	}
}

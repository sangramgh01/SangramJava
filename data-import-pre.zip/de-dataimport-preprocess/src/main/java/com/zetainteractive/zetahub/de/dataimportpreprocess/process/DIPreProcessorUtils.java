package com.zetainteractive.zetahub.de.dataimportpreprocess.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.file.CodecFactory;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.io.FileExistsException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.zetainteractive.csv.CSVLine;
import com.zetainteractive.fileutils.bo.FileUtilContext;
import com.zetainteractive.fileutils.plugin.FileSystemUtilsPlugin;
import com.zetainteractive.fileutils.plugin.impl.FileSystemUtilPluginFactory;
import com.zetainteractive.fileutils.util.FileSystemTypeConstants;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.scrub.DataScrub;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.Util.PBEncryptionUtil;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimportpreprocess.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessConstants;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessorDependencyCalls;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.GPGEncryptionUtil;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.PGPEncryptionUtil;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
import com.zetainteractive.zetahub.de.util.Base64Util;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

@Component
public class DIPreProcessorUtils {

	
	ZetaLogger logger = new ZetaLogger(DIPreProcessorUtils.class);
	Schema recordSchema;
	Map<String,String> cacheStorage;
	File dataFile;
	DataImportDTO dataImportDTO;
	DataFileWriter<GenericRecord> dataFileWriter;
	
	
	DIPreProcessorDependencyCalls diPreProcessorDependencyCalls;
	/**
	 * for thread safe creating thread local objects
	 * @param diPreProcessorDependencyCalls
	 */
	public DIPreProcessorUtils(DIPreProcessorDependencyCalls diPreProcessorDependencyCalls){
		this.diPreProcessorDependencyCalls=diPreProcessorDependencyCalls;
		
	}

	/**
	 * @param dataImportDTO
	 * @param recordSchema
	 * @param dataFile
	 * @param cacheStorage
	 */
	public void setFileDetails(DataImportDTO dataImportDTO,Schema recordSchema,File dataFile,Map<String,String> cacheStorage){
		this.dataFile=dataFile;
		this.cacheStorage=cacheStorage;
		this.recordSchema=recordSchema;
		this.dataImportDTO=dataImportDTO;
	}
	
	/**
	 * @param dataImportDTO
	 * @param recordSchema
	 * @param cacheStorage
	 */
	public void setDatabaseDetails(DataImportDTO dataImportDTO,Schema recordSchema,Map<String,String> cacheStorage){
		this.cacheStorage=cacheStorage;
		this.recordSchema=recordSchema;
		this.dataImportDTO=dataImportDTO;
	}
	public DataImportDTO readFileData() throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : readFileData()");
		boolean isErrored=false;
		String[] csvDataLine = null;
		boolean invalidRecords = false;
		CSVLine csvLine=null;
		String line;
		String ignorePath=dataImportDTO.getFileActivity().getIgnorefilePath();
		boolean headerExists = dataImportDTO.getFileDefinitionBO().getFileFormatSpec().getHeaderRowAtLine()!=0?true:false;
		String delimiter = dataImportDTO.getFileDefinitionBO().getFileFormatSpec().getDelimiter();
		String textQualifier = dataImportDTO.getFileDefinitionBO().getFileFormatSpec().getTextQualifier();
		File ignDirectory = new File(ignorePath);
		if(!ignDirectory.exists()){
			ignDirectory.mkdirs();
		}
		//if file name contains special character replacing with "_" FOR reference  ZHPE-6699
		String fileName=FilenameUtils.getBaseName(dataFile.getName()).replaceAll(DIPreProcessConstants.SPECIAL_CHARACTERS, "_");
		ignorePath = new StringBuilder(ignDirectory.getAbsolutePath()+File.separator).append(fileName).append(".ignore").toString();
		String duplicatePath = new StringBuilder(ignDirectory.getAbsolutePath()+File.separator).append(fileName).append(".dup").toString();
		BufferedReader bufferedReader = null;
		Map<String, String> maileableColumns = getMaileableColumns(dataImportDTO);
		List<String> keyColumns = getKeyColumns(dataImportDTO);
		String avroFilePath=null;
		File avroFile=null;
		boolean ignoreBadRec = dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords()=='Y' ? true : false;
		try {
			dataImportDTO.setIgnoreFilePath(ignorePath);
			bufferedReader = readDataFromFile(dataFile,delimiter);
			avroFilePath = new StringBuilder(dataFile.getParent()).append(File.separator).append(fileName).append(".avro").toString();
			dataFileWriter = new DataFileWriter<>(new GenericDatumWriter<GenericRecord>(recordSchema));
			dataFileWriter.setCodec(CodecFactory.snappyCodec());
			avroFile= new File(avroFilePath);
			dataFileWriter.create(this.recordSchema,avroFile);
			long recordCount = 1;
			long inputRecordsCount = 0;
			//If the delimiter is tab then paasing value as \t
			if(delimiter.equalsIgnoreCase("tab"))
				delimiter="\\t";
			if(!textQualifier.equalsIgnoreCase("None") )
				csvLine=new CSVLine(delimiter,textQualifier);
			else	
				csvLine=new CSVLine(delimiter);
			while((line = bufferedReader.readLine()) != null) {
				try {
					csvDataLine=csvLine.splitCSVLine(line);
					if((headerExists && recordCount>1)|| !headerExists){
						boolean validRecord=generateGenericRecord(csvDataLine,recordCount,maileableColumns,keyColumns,ignorePath,duplicatePath);
						if (validRecord)
							invalidRecords = validRecord;
						inputRecordsCount++;
					}else if(headerExists && recordCount == 1 ){
						writeIgnoreFile(csvDataLine, ignorePath,"Reason For Rejection");
					}
				} catch (Exception e) {
					if(dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords()==null || dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords().equals('N')){
						throw e;
					}else{
						Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
						dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
						writeIgnoreFile(new String[]{line}, ignorePath,e.getMessage());
					}
				}
				recordCount++;
			}
			logger.info("Avro File generation completed.");
			if(ignoreBadRec) 
			{
				try {
					FileSystemUtilsPlugin fileUtils=null;
					FileUtilContext fileUtilContext=null;
					PBEncryptionUtil pbEncryptionUtil=new PBEncryptionUtil();
					String password=pbEncryptionUtil.transform("extract", ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-ignore-records-export-password", null));
					String host=ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-ignore-records-export-host", null);
					String username=ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-ignore-records-export-username",null);
					Integer port=ZetaUtil.getHelper().getConfig().getConfigValueInt("dataimport-ignore-records-export-port",0);
					String folderpath=ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-ignore-records-export-folderpath", null);
				    fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SFTP);
				    if(host!=null&&username!=null&&password!=null&&port!=0&&folderpath!=null){
						    fileUtilContext= new FileUtilContext(host, username,password, port, 15000);
						    String localfilepath=ignorePath.substring(0, ignorePath.lastIndexOf(File.separator)+1);
						    String timestamp=new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
				            String changedFilename=fileName+timestamp+"_rejects"+dataImportDTO.getFileDefinitionId()+".csv";
				            fileUtilContext.setRemoteFilePath(folderpath);
			                fileUtilContext.setLocalFilePath(localfilepath);
				    		fileUtils.setContext(fileUtilContext);
				    		fileUtils.uploadFile(fileName+".ignore");
				    		fileUtils.renameFile(folderpath+"/"+fileName+".ignore", folderpath+"/"+changedFilename);
					}
				} catch (Exception e) {
					logger.error("Ignore record export failed due to ::"+e.getMessage(),e);
				}
			}
			dataImportDTO.setIsInvalidRecordsExist(invalidRecords);
			dataImportDTO.setIgnoreFilePath(ignorePath);
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInputRecordsCount(inputRecordsCount);
			logger.info("Total rows processed: " + recordCount );
			logger.info("Total unique rows: " + cacheStorage.size());
			dataImportDTO.setAvroFilePath(avroFilePath);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			dataImportDTO.getFileActivity().setMessage(e.getMessage());
			isErrored=true;
			throw e;
		}
		finally {
			if(bufferedReader!=null)
				bufferedReader.close();
			if(dataFileWriter!=null)
				dataFileWriter.close();
			if(isErrored){
				moveFile(dataFile,PreProcessorConstants.STATUS_ERRORED);
				if(avroFile != null)
					moveFile(avroFile,PreProcessorConstants.STATUS_ERRORED);
			}else
				moveFile(dataFile,PreProcessorConstants.STATUS_COMPLETED);
		}
		logger.debug("End : "+getClass().getName()+" : readFileData()");
		return dataImportDTO;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public DataImportDTO readDatabaseData() throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : readDatabaseData()");
		boolean invalidRecords = false;
		String ignorePath=dataImportDTO.getFileActivity().getIgnorefilePath();
		File ignDirectory = new File(ignorePath+File.separator+"logs");
		if(!ignDirectory.exists()){
			ignDirectory.mkdirs();
		}
		ignorePath = new StringBuilder(ignDirectory.getAbsolutePath()).append(File.separator).append(dataImportDTO.getFileDefinitionId()).append(".ignore").toString();
		String duplicateFilePath=new StringBuilder(ignDirectory.getAbsolutePath()).append(File.separator).append(dataImportDTO.getFileDefinitionId()).append(".dup").toString();
		ResultSet rs=null;
		Connection con=null;
		Statement stmt = null;
		String query=null;
		Map<String, String> maileableColumns = getMaileableColumns(dataImportDTO);
		List<String> keyColumns = getKeyColumns(dataImportDTO);
		try {
			
			initializeContext(dataImportDTO.getCustCode());
			DbSourceBO dbSourceBO = diPreProcessorDependencyCalls.getDBSource(dataImportDTO.getFileDefinitionBO().getFileSource().getSourceName());
			dataFileWriter = new DataFileWriter<>(new GenericDatumWriter<GenericRecord>(recordSchema));
			dataFileWriter.setCodec(CodecFactory.snappyCodec());
			dataFileWriter.create(this.recordSchema, new File(dataImportDTO.getAvroFilePath()));
			long recordCount = 1;
			con = getConnection(dbSourceBO.getDbvendor(),dbSourceBO.getHostname(),dbSourceBO.getPort(),dbSourceBO.getSchemaName(),dbSourceBO.getUsername(),dbSourceBO.getPassword()); 
			query = dataImportDTO.getFileDefinitionBO().getFileSource().getQuery();
			query = query.replaceAll(";+$", "");
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			int  columnCount = rs.getMetaData().getColumnCount();
			if(dbSourceBO.getDbvendor().equalsIgnoreCase(DIPreProcessConstants.DBTYPE_ORACLE))
				columnCount-=1;
			while(rs.next()){
				String record[] = new String[columnCount];
				for(int i=1;i<=columnCount;i++)
				{	
					int j = i-1;		
					record[j] = rs.getString(i);
					if(record[j]==null)
						continue;
					if(dbSourceBO.getDbvendor().equalsIgnoreCase(DIPreProcessConstants.DBTYPE_ORACLE)){
						String columntype = rs.getMetaData().getColumnTypeName(i);
						if(columntype.equalsIgnoreCase("TimeStamp")||columntype.equalsIgnoreCase("Date"))
						{
							DateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
							record[j] = dateFormatter.format(rs.getDate(i));
						}
					}else if(dbSourceBO.getDbvendor().equalsIgnoreCase(DIPreProcessConstants.DBTYPE_MYSQL) || (dbSourceBO.getDbvendor().equalsIgnoreCase(DIPreProcessConstants.DBTYPE_MSSQL))){
						Matcher matcher = DIPreProcessConstants.DatePatternWithZero.matcher(record[j].toString());
						if(matcher.matches()){
							if(record[j].toString().endsWith(".0")){
								String dateStr = record[j].toString();
								int index = dateStr.indexOf(".0");
								dateStr = dateStr.substring(0, index);
								record[j] = dateStr;
							}
						}
					}
				}
				invalidRecords = invalidRecords || generateGenericRecord(record,recordCount,maileableColumns,keyColumns,ignorePath,duplicateFilePath);
				recordCount++;
			}
			dataImportDTO.setIsInvalidRecordsExist(invalidRecords);
			dataImportDTO.setIgnoreFilePath(ignorePath);
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInputRecordsCount(recordCount-1);
			logger.info("Total rows processed: " + recordCount );
			logger.info("Total unique rows: " + cacheStorage.size());
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		finally {
			if(rs!=null && !rs.isClosed())
				rs.close();
			if(stmt!=null && !stmt.isClosed())
				stmt.close();
			if(con!=null && !con.isClosed())
				con.close();
			if(dataFileWriter!=null)
				dataFileWriter.close();
		}
		logger.debug("End : "+getClass().getName()+" : readDatabaseData()");
		return dataImportDTO;
	}
	
	/**
	 * 
	 * Method Name 	: initializeContext
	 * Description 	: The Method "initializeContext" is used for 
	 * Date    		: Dec 12, 2016, 9:02:50 PM
	 * @param custCode
	 * @param  		:
	 * @return 		: void
	 * @throws Exception 
	 * @throws 		: 
	 */
	private void initializeContext(String custCode) throws Exception {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), custCode);
		String Username=ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser", "dataimportuser");
		httpHeaders.add(BootStarterConstants.USERNAME.toString(),Username);
		UserBO response = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("security")+"/getUserByName/"+Username, HttpMethod.GET, new HttpEntity<>(httpHeaders), UserBO.class).getBody();
		ZetaUtil.getHelper().setUser(response);
	}

	private Boolean generateGenericRecord(String[] lineElements,Long recordCount,Map<String, String> maileableColumns,List<String> keyColumns,String ignorePath,String dupFilePath) throws Exception{
		String isValid="Y";
		Boolean invalidRecord=false;
		Character ignoreBadRecords = dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords();
		Map<String,Boolean> scrubResults = new HashMap<>();
		String dateFormat = dataImportDTO.getFileDefinitionBO().getFileMapping().getDateFormat();
		String dateDelimiter = dataImportDTO.getFileDefinitionBO().getFileMapping().getDateDelimiter();
		Integer scrubValue = dataImportDTO.getFileDefinitionBO().getFileMapping().getIncludeScrubRules();
		String timeStamp = new SimpleDateFormat("yyyy-MMM-dd").format(new Date());
		String audienceTableName = null;
		String ScrubrulesEndingWithText=null;
		if(dataImportDTO.getImportType().equalsIgnoreCase("RESUB") || dataImportDTO.getImportType().equalsIgnoreCase("UNSUB") ){
			if(dataImportDTO.getFileDefinitionBO().getChannelType().equals('E')){
				audienceTableName = "AUDIENCE_EMAIL";
			}else if(dataImportDTO.getFileDefinitionBO().getChannelType().equals('S')){
				audienceTableName = "AUDIENCE_SMS";
			}
		}else{
			audienceTableName=getPhysicalTableName(dataImportDTO.getFileDefinitionBO().getFileMapping().getColumnDefinitionList());
		}
		ScrubrulesEndingWithText=dataImportDTO.getFileDefinitionBO().getFileMapping().getScrubrulesEndingWithText();
		GenericRecord record = null;
		int mappingColumnLength="DIMENTION".equals(dataImportDTO.getImportType()) ? dataImportDTO.getColumns().size() :dataImportDTO.getColumns().size()-1;// Non-audience doesn't contains ISNEW_2 column.
		if(lineElements.length>=mappingColumnLength){// processing record only it has more than the length of the mapped columns.
			try {
				record = generateGenericRecord(lineElements,dataImportDTO.getColumns(),dataImportDTO.getFileDefinitionBO().getFileMapping().getNullValueRepresentation());
			} catch (NumberFormatException ne) {
				String errMsg = "";
				String[] splitMsg = ne.getMessage().split("\"");
				if(splitMsg.length > 1)
					errMsg = "Invalid data found for column \""+  splitMsg[1].trim() + "\".";
				else
					errMsg = ne.getMessage();
				if(ignoreBadRecords==null || ignoreBadRecords.equals('N'))
					throw new Exception(errMsg);
				else{
					Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
					dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
					writeIgnoreFile(lineElements, ignorePath, errMsg);
				}
			} catch(Exception e){
				if(ignoreBadRecords==null || ignoreBadRecords.equals('N')){
					throw e;
				}else{
					logger.info("Invalid record provided.");
					scrubResults.put("invalidData", true);
				}
			}
			if (record!=null){
				if(dataImportDTO.getAudienceId() == 0 && !(dataImportDTO.getImportType().equals("RESUB") || dataImportDTO.getImportType().equals("UNSUB"))){
						record.put(DIPreProcessConstants.BATCH_ID,dataImportDTO.getFileActivity().getBatchId());
						record.put(DIPreProcessConstants.SRC_FILE_ID,dataImportDTO.getFileActivity().getFileActivityID());
				}
				
				record.put("timestamp_dup", timeStamp);
				if(keyColumns.isEmpty()){
					keyColumns = getKeyColumnsForNonAudience(dataImportDTO);
				}
				String keyHash = generateKeyHash(record,keyColumns);
				record.put("keyhash", keyHash);
				processScrubRules(record,maileableColumns,scrubValue,dateFormat,dateDelimiter,scrubResults,ScrubrulesEndingWithText);
				processValidateRules(record,maileableColumns,scrubValue,scrubResults);
				if(ignoreBadRecords==null || ignoreBadRecords.equals('N')){
					if(!scrubResults.get("isDateValid") || !scrubResults.get("isEmailValid") || !scrubResults.get("isSmsValid")){
						dataImportDTO.setIsInvalidRecordsExist(true);
						throw new Exception("Bad records in file -> Date val:"+scrubResults.get("isDateValid")+" Email val :"+scrubResults.get("isEmailValid")+"SMS Val : "+scrubResults.get("isSmsValid"));
					}else{
						if(cacheStorage.get(keyHash)==null){// if record not exists in cache
							record.put("isValid", String.valueOf(isValid));
							dataFileWriter.append(record);
							cacheStorage.put(keyHash, "");
						}else{
							writeIgnoreFile(lineElements, dupFilePath, "-Duplicate Record.");
						}
					}
				}else{
					if (audienceTableName.equalsIgnoreCase("AUDIENCE_EMAIL") || audienceTableName.equalsIgnoreCase("AUDIENCE_SMS")) {
						if(!scrubResults.get("isDateValid") || !scrubResults.get("isEmailValid") || !scrubResults.get("isSmsValid")){
							logger.info("Writing Bad record to ignore file -> Date val:"+scrubResults.get("isDateValid")+" Email val :"+scrubResults.get("isEmailValid")+"SMS Val : "+scrubResults.get("isSmsValid"));
							if (!scrubResults.get("isDateValid"))
									writeIgnoreFile(lineElements,ignorePath,DIPreProcessConstants.DATE_ERROR_MSG);
							else if (!scrubResults.get("isEmailValid"))
									writeIgnoreFile(lineElements,ignorePath,DIPreProcessConstants.EMAIL_ERROR_MSG);
							else if (!scrubResults.get("isSmsValid"))
									writeIgnoreFile(lineElements,ignorePath,DIPreProcessConstants.SMS_ERROR_MSG);
							Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
							dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
						}else{
							if(cacheStorage.get(keyHash)==null){
								record.put("isValid", String.valueOf(isValid));
								dataFileWriter.append(record);
								cacheStorage.put(keyHash, "");
							}else{
								writeIgnoreFile(lineElements, dupFilePath, "-Duplicate Record.");
							}
						}
					}else{
						if (!scrubResults.get("isDateValid") || (dataImportDTO.getListType() != null && dataImportDTO.getListType() == 'S' ) && !scrubResults.get("isEmailValid")) {
							Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
							dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
							if (!scrubResults.get("isDateValid")){
								logger.info("Writing Bad record to ignore file -> Date val:"+scrubResults.get("isDateValid"));
								writeIgnoreFile(lineElements, ignorePath,DIPreProcessConstants.DATE_ERROR_MSG);
							}else if (!scrubResults.get("isEmailValid")){
								writeIgnoreFile(lineElements,ignorePath,DIPreProcessConstants.EMAIL_ERROR_MSG);
							}
						}else{
							if (!scrubResults.get("isEmailValid") && !scrubResults.get("isSmsValid")) {
								invalidRecord = true;
								isValid = "F";
							} else if (!scrubResults.get("isEmailValid")) {
								invalidRecord = true;
								isValid = "E";
							} else if (!scrubResults.get("isSmsValid")) {
								invalidRecord = true;
								isValid = "S";
							} else if(maileableColumns.containsKey(PreProcessorConstants.EMAIL_DATATYPE.toString()) || maileableColumns.containsKey(PreProcessorConstants.SMS_DATATYPE.toString())){
								if((maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString())!=null 
										&& !maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString()).isEmpty()) 
										|| (maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString())!=null 
												&& !maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString()).isEmpty())){
									// Each file contains individual temp table.If one file contains invalid records then ISVALID column added to that temp table
									//but if other files doesn't contain that invalid records then ISVALID column not created to other temp table.
									// Due to this merge temp table failing.
									invalidRecord = true;
									isValid = "Y";
								}
							}
							record.put("isValid", String.valueOf(isValid));
							if(cacheStorage.get(keyHash)==null){
								dataFileWriter.append(record);
								cacheStorage.put(keyHash, "");
							}else{
								writeIgnoreFile(lineElements, dupFilePath, "-Duplicate Record.");
							}
						}
					}
				}
			}else{
				if (scrubResults.containsKey("invalidData") && scrubResults.get("invalidData")){
					writeIgnoreFile(lineElements, ignorePath, DIPreProcessConstants.ROW_ERROR_MSG);
					Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
					dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
				}
			}
		}else{// no sufficient data is provided for the record so treating it as a invalid record.
			if(ignoreBadRecords==null || ignoreBadRecords.equals('N')){
				throw new Exception("Record lenth is not matches the mapped columns.");
			}else{
				logger.info("Record lenth is not matches the mapped columns -> writing invalid record to ignore file -> Date val:"+scrubResults.get("isDateValid"));
				Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
				dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount+1);
				writeIgnoreFile(lineElements,ignorePath,DIPreProcessConstants.LENGTH_ERROR_MSG);
			}
		}
		if(recordCount % 1000 == 0)
			logger.debug("Processed record count : " + recordCount);
		return invalidRecord;
	}
	
	/**
	 * Method Name 	: moveFile
	 * Description 	: The Method "moveFile" is used for 
	 * Date    		: Oct 13, 2016, 5:39:05 PM
	 * @param dataFile
	 * @param status
	 * @param  		:
	 * @return 		: void
	 * @throws IOException 
	 * @throws 		:
	 */
	public void moveFile(File srcFile, PreProcessorConstants status) throws IOException {
		logger.debug("Begin : "+getClass().getName()+" : moveFile(File srcFile, PreProcessorConstants status)");
		String folderpath = FilenameUtils.getFullPath(srcFile.getAbsolutePath())+File.separator+"done";
		logger.info("moving files to :: "+folderpath);
		File file = new File(folderpath);
		if(!file.exists()){
			file.mkdirs();
		}
		File destFile = null;
		if(status.equals(PreProcessorConstants.STATUS_COMPLETED)){
			destFile = new File(file.getPath()+File.separator+FilenameUtils.getName(srcFile.getAbsolutePath())+"_"+System.currentTimeMillis()+".done");
		}else if(status.equals(PreProcessorConstants.STATUS_ERRORED)){
			destFile = new File(file.getPath()+File.separator+FilenameUtils.getName(srcFile.getAbsolutePath())+"_"+System.currentTimeMillis()+".bad");
		}
		try{
			FileUtils.moveFile(srcFile, destFile);
		}catch(FileExistsException exception){
			//DO NOTHING
		}
		logger.debug("End : "+getClass().getName()+" : moveFile(File srcFile, PreProcessorConstants status)");
	}

	private GenericRecord generateGenericRecord(String[] data,List<Column> columns,String nullValueRepresentation) throws Exception{
		GenericRecord genericRecord  = new GenericData.Record(recordSchema);
		List<Field> fields = recordSchema.getFields();
		String dataType ;
		//Not mapping ISNEW_2
		int colSize = columns.size();
		if(columns.get(colSize-1).getColumnName().equalsIgnoreCase("ISNEW_2")){
			colSize = colSize-1;
		}
		for(int i=0;i<colSize;i++){
			Column column=columns.get(i);
			Integer columnPosition=column.getColumnPositionInFile();
			if(("NL".equals(nullValueRepresentation) && "Null".equalsIgnoreCase(data[columnPosition].trim())) || ("ES".equals(nullValueRepresentation) && "".equals(data[columnPosition].trim()))){
				data[columnPosition]=null;
			}
			Field field = fields.get(i);
			if(field.schema().getType().equals(Schema.Type.UNION)){
				dataType = field.schema().getTypes().stream().findFirst().get().getName();
			}else{
				dataType = field.schema().getType().getName();
			}
			switch(dataType){
	          case "int"       : if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
	        	  					genericRecord.put(i, Integer.parseInt(data[columnPosition]));
	          					else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
	          						genericRecord.put(i, Integer.parseInt(column.getDefaultValue()));
	          					 break;	
	          case "string"    : if(null != data[columnPosition] && data[columnPosition].trim().length()>0) 
	        	  					genericRecord.put(i, data[columnPosition]);
	          					else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
	          						genericRecord.put(i, column.getDefaultValue());
								 break;
	          case "boolean"   : if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
	        	  				 	genericRecord.put(i,getBooleanValue(data[columnPosition]) );
								 else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
									 genericRecord.put(i,getBooleanValue(column.getDefaultValue()) );
								 break;
	          case "long" 	   : if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
	        	  					genericRecord.put(i, Long.parseLong(data[columnPosition]));
								 else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
									 genericRecord.put(i, Long.parseLong(column.getDefaultValue()));
	          					break;
	          case "float"     : if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
	        	  					genericRecord.put(i, Float.parseFloat(data[columnPosition]));
								 else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
									 genericRecord.put(i, Float.parseFloat(column.getDefaultValue()));
								break;
	          case "double"   : if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
	        	  					genericRecord.put(i, Double.parseDouble(data[columnPosition]));
								 else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
									genericRecord.put(i, Double.parseDouble(column.getDefaultValue()));
	          					break;
	          default : 		 if(null != data[columnPosition] && data[columnPosition].trim().length()>0)
									genericRecord.put(i, data[columnPosition]);
								 else if(column.getDefaultValue()!=null && column.getDefaultValue().length()>0)
									genericRecord.put(i, column.getDefaultValue());
	          					 break;
	        }
		}
		return genericRecord;
	}

	/**
	 * 
	 * Method Name 	: getBooleanValue
	 * Description 	: The Method "getBooleanValue" is used for 
	 * Date    		: Oct 17, 2016, 3:21:42 AM
	 * @param string
	 * @return
	 * @param  		:
	 * @return 		: Object
	 * @throws 		: 
	 */
	private boolean getBooleanValue(String value) {
		boolean ret = false;
		switch (value.toUpperCase()) {
		case "Y":
		case "T":
		case "1":
		case "TRUE":
		case "YES":ret = true;
				break;
		case "N": 
		case "F": 
		case "0":
		case "FALSE":
		case "NO":ret = false;
			break;
		default:
			break;
		}
		return ret;
	}

	private void processScrubRules(GenericRecord record,Map<String,String> maileableColumns,Integer scrubValue,String dateFormat,String delimiter,Map<String,Boolean> scrubResults,String ScrubrulesEndingWithText)throws Exception{
		boolean booleanValid = true;
		boolean dateValid = true;
		DataScrub dataScrub = new DataScrub();
		Long scrubbedEmailCount = 0L;
		Long scrubbedSMSCount = 0L;
		if(maileableColumns!=null && !maileableColumns.isEmpty()){
			if(maileableColumns.containsKey(PreProcessorConstants.EMAIL_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString()).isEmpty()){
					scrubbedEmailCount=dataScrub.scrubEmailColumns(record, maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString()), scrubValue,ScrubrulesEndingWithText);
				}
			}
			if(maileableColumns.containsKey(PreProcessorConstants.SMS_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString()).isEmpty()){
					scrubbedSMSCount=dataScrub.scrubSMSColumns(record, maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString()), scrubValue);
				}
			}
			if(maileableColumns.containsKey(PreProcessorConstants.DATETIME_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.DATETIME_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.DATETIME_DATATYPE.toString()).isEmpty()){
					dateValid=dataScrub.scrubAndValidateDateColumns(record, maileableColumns.get(PreProcessorConstants.DATETIME_DATATYPE.toString()),PreProcessorConstants.DATETIME_DATATYPE.toString(),dateFormat,delimiter);
				}
			}
			if(maileableColumns.containsKey(PreProcessorConstants.TIMESTAMP_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.TIMESTAMP_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.TIMESTAMP_DATATYPE.toString()).isEmpty()){
					dateValid=dataScrub.scrubAndValidateDateColumns(record, maileableColumns.get(PreProcessorConstants.TIMESTAMP_DATATYPE.toString()),PreProcessorConstants.TIMESTAMP_DATATYPE.toString(),dateFormat,delimiter);
				}
			}
			if(maileableColumns.containsKey(PreProcessorConstants.DATE_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.DATE_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.DATE_DATATYPE.toString()).isEmpty()){
					dateValid=dataScrub.scrubAndValidateDateColumns(record, maileableColumns.get(PreProcessorConstants.DATE_DATATYPE.toString()),PreProcessorConstants.DATE_DATATYPE.toString(),dateFormat,delimiter);
				}
			}
		}
		scrubResults.put("isBooleanValid", booleanValid);
		scrubResults.put("isDateValid", dateValid);
		if(scrubbedSMSCount > 0 || scrubbedEmailCount > 0){
			Long scrubbedRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getScrubbedRecordsCount();
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setScrubbedRecordsCount(scrubbedRecordsCount+1);
		}
	}

	private void processValidateRules(GenericRecord record,Map<String,String> maileableColumns,Integer scrubValue,Map<String,Boolean> scrubResults) {
		boolean emailValid = true;
		boolean smsValid = true;
		DataScrub dataScrub = new DataScrub();
		if(maileableColumns!=null && !maileableColumns.isEmpty()){
			//process email scrub
			if(maileableColumns.containsKey(PreProcessorConstants.EMAIL_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString()).isEmpty()){
					//apply rules
					emailValid = dataScrub.isEmailValid(record, maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString()));
				}
			}
			//process sms scrub
			if(maileableColumns.containsKey(PreProcessorConstants.SMS_DATATYPE.toString())){
				if(maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString())!=null 
						&& !maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString()).isEmpty()){
					//apply rules
					String smsCols = maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString());
					if(smsCols!=null && smsCols.trim().length()>0)
						smsValid = dataScrub.isSMSValid(record, maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString()));
				}
			}
		}
		scrubResults.put("isEmailValid", emailValid);
		scrubResults.put("isSmsValid", smsValid);
	}

	private void writeIgnoreFile(String[] csvLine,String ignorePath,String message)throws Exception{
		long length = 0;
		File ignoreFile = new File(ignorePath);
		if (ignoreFile.exists()) {
			length = ignoreFile.length();
		}
		String data;
		if (message!=null)
			data = new StringBuilder().append("  ").append(StringUtils.join(csvLine,",")).append("-").append(message).append("  \n").toString();
		else
			data = new StringBuilder().append("  ").append(StringUtils.join(csvLine,",")).append("  \n").toString();
		
		RandomAccessFile rwChannel = new RandomAccessFile(ignorePath, "rw");
		rwChannel.seek(length);
		rwChannel.writeBytes(data);
		rwChannel.close();
	}

	private String generateKeyHash(GenericRecord genericRecord,List<String> keyColumns) throws NoSuchAlgorithmException {
		StringBuilder hashBuilder = new StringBuilder();
		for (String keyColumn : keyColumns) {
			hashBuilder.append(genericRecord.get(keyColumn));
		}
		String keyData=hashBuilder.toString();
		MessageDigest md = MessageDigest.getInstance("SHA1");
        md.reset();
        byte[] buffer =keyData.getBytes();
        md.update(buffer);
        byte[] digest = md.digest();
        String uniqueKey = "";
        for (int i = 0; i < digest.length; i++) {
        	uniqueKey +=  Integer.toString( ( digest[i] & 0xff ) + 0x100, 16).substring( 1 );
        }
        return uniqueKey;
	}

	private List<String> getKeyColumns(DataImportDTO dataImportDTO) {
		List<String> keyColumns = new ArrayList<>();
		for (Column column : dataImportDTO.getColumns()) {
			if(column.getIsKey()){
				keyColumns.add(column.getColumnName());
			}
		}
		return keyColumns;
	}
	
	private List<String> getKeyColumnsForNonAudience(DataImportDTO dataImportDTO) {
		List<String> keyColumns = new ArrayList<>();
		for (Column column : dataImportDTO.getColumns()) {
				keyColumns.add(column.getColumnName());
		}
		return keyColumns;
	}

	private Map<String,String> getMaileableColumns(DataImportDTO dataImportDTO) throws Exception{
		Map<String,String> maileableColumns = new HashMap<>();
		logger.info("Getting mailable columns.");
		Integer avroRecordPosition=0;
		StringBuilder omitPositions=new StringBuilder();
		for (ColumnDefinitionBO columnDefinitionBO : dataImportDTO.getFileDefinitionBO().getFileMapping().getColumnDefinitionList()) {
			if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.DATETIME_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.DATETIME_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.DATETIME_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.DATETIME_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.DATETIME_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.SMS_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.SMS_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.SMS_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.SMS_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.SMS_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.EMAIL_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.EMAIL_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.EMAIL_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.EMAIL_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.EMAIL_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.TIMESTAMP_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.TIMESTAMP_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.TIMESTAMP_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.TIMESTAMP_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.TIMESTAMP_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.DATE_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.DATE_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.DATE_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.DATE_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.DATE_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if(columnDefinitionBO.getColumnType().equalsIgnoreCase(PreProcessorConstants.BOOLEAN_DATATYPE.toString())){
				if(maileableColumns.containsKey(PreProcessorConstants.BOOLEAN_DATATYPE.toString())){
					String value = new StringBuilder().append(maileableColumns.get(PreProcessorConstants.BOOLEAN_DATATYPE.toString())).append(",").append(avroRecordPosition).toString();
					maileableColumns.put(PreProcessorConstants.BOOLEAN_DATATYPE.toString(), value);
				}else{
					maileableColumns.put(PreProcessorConstants.BOOLEAN_DATATYPE.toString(), String.valueOf(avroRecordPosition));
				}
			}else if ("Omit".equalsIgnoreCase(columnDefinitionBO.getColumnType())){
				omitPositions.append(columnDefinitionBO.getColumnPositionInFile()).append(",");
			}
			avroRecordPosition++;
		}
		// List won't provide sequential order due to that 
		if (omitPositions.toString().trim().length()>0){
			String[] positions=omitPositions.toString().substring(0, omitPositions.toString().length()-1).split(",");
			for (String position: positions){
				int pos=Integer.parseInt(position);
				for(String key : maileableColumns.keySet()){
					StringBuilder validAvroPositions=new StringBuilder();
					for (String avroPosition:maileableColumns.get(key).split(",")){
						if (avroPosition.trim().length()>0){
							//If in between columns any omit column found then avro position also decreasing by one to validate and scrub proper column data.Why because avro doesn't contain omit columns
							int value=Integer.parseInt(avroPosition);
							if (value>pos)
								validAvroPositions.append(value-1).append(",");
							else
								validAvroPositions.append(value).append(",");
						}
							
					}
					maileableColumns.put(key, validAvroPositions.toString().substring(0, validAvroPositions.toString().length()-1));
				}
				
			}
		}
		logger.info("Mailable columns size :: "+maileableColumns.size()); 
		return maileableColumns;
	}

	private BufferedReader readDataFromFile(File dataFile,String delim) throws Exception  {
		BufferedReader bufferedReader=null;		
		try {
			logger.info("Started reading file with delimiter ::"+delim);
			//Special treatment if the delimiter is tab
			boolean isGzipped = isGzipped(dataFile);
			logger.info("Is file encrypted :: "+isGzipped);
			if(dataImportDTO.getEncryptionKeyBO() != null){
				if(isGzipped){
					bufferedReader = new BufferedReader(new InputStreamReader(new GZIPInputStream(getDecripedInputStream())));
				}else{
					bufferedReader = new BufferedReader(new InputStreamReader(getDecripedInputStream(),Charset.forName("utf-8")));
				}
			}else{
				if(isGzipped){
					bufferedReader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(dataFile))));
				}else{
					bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(dataFile),Charset.forName("utf-8")));
				}
			}
				
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
		}
		
		return bufferedReader;
	}
	
	private InputStream getDecripedInputStream() throws FileNotFoundException, Exception{
		try{
			InputStream is = null;
			if(dataImportDTO.getEncryptionKeyBO().getEncryptionType().equals("PGP")){
				boolean success = false;
				try {
					success = new GPGEncryptionUtil().runGnuPG("gpg --list-keys "+dataImportDTO.getEncryptionKeyBO().getEncryptionKeyName() , null, 'N');
				} catch (Exception e) {
					logger.error("runGnuPG failed ::"+e.getMessage(), e);	
				}
				logger.debug("created decrypted file success::"+success);
				if(!success){
					String outputkeyFilePath = System.getProperty("java.io.tmpdir")+"/private.key";
					FileUtils.writeStringToFile(new File(outputkeyFilePath), dataImportDTO.getEncryptionKeyBO().getPrivatekey());
					try {
						new GPGEncryptionUtil().runGnuPG("gpg --allow-secret-key-import --import "+outputkeyFilePath , null, 'N');
					} catch (Exception e) {logger.error("created decryptef file success"+e.getMessage());}
				}
				String outputFilePath = System.getProperty("java.io.tmpdir")+"/"+dataFile.getName();
				File outputFile = new File(outputFilePath);
				logger.debug("created decripted file ::"+outputFile.getAbsolutePath());
				if(outputFile.exists())outputFile.delete();
				new PGPEncryptionUtil().decryptFile(new FileInputStream(dataFile), dataImportDTO.getEncryptionKeyBO().getPrivatekey(), dataImportDTO.getEncryptionKeyBO().getPassphrase(),outputFilePath);
				is = FileUtils.openInputStream(outputFile);
			}else if(dataImportDTO.getEncryptionKeyBO().getEncryptionType().equals("GPG")){
				boolean success = false;
				try {
					success = new GPGEncryptionUtil().runGnuPG("gpg --list-keys "+dataImportDTO.getEncryptionKeyBO().getEncryptionKeyName() , null, 'N');
				} catch (Exception e) {
					logger.error("runGnuPG failed ::"+e.getMessage(), e);	
				}
				logger.debug("created decrypted file success::"+success);
				if(!success){
					String outputkeyFilePath = System.getProperty("java.io.tmpdir")+"/private.key";
					FileUtils.writeStringToFile(new File(outputkeyFilePath), dataImportDTO.getEncryptionKeyBO().getPrivatekey());
					try {
						new GPGEncryptionUtil().runGnuPG("gpg --allow-secret-key-import --import "+outputkeyFilePath , null, 'N');
					} catch (Exception e) {logger.error("created decryptef file success"+e.getMessage());}
				}
				String outputFile = System.getProperty("java.io.tmpdir")+"/"+dataFile.getName();
				File file = new File(outputFile);
				logger.debug("created decripted file ::"+file.getAbsolutePath());
				if(file.exists())file.delete();
				boolean res = new GPGEncryptionUtil().decryptFile(dataFile.getAbsolutePath(), dataImportDTO.getEncryptionKeyBO().getPrivatekey(), dataImportDTO.getEncryptionKeyBO().getPassphrase(),outputFile);
				if(res){
					is = FileUtils.openInputStream(file);
				}
			}
			return is;
		}catch(Exception e){
			logger.error("method getDecripedInputStream exception ::"+e);
			throw new Exception("File Decryption failed");
		}
	}
	
	private Boolean isGzipped(File f) throws IOException {
	    InputStream is = null;
	    try {
	        is = new FileInputStream(f);
	        byte [] signature = new byte[2];
	        int nread = is.read( signature ); //read the gzip signature
	        return nread == 2 && signature[ 0 ] == (byte) 0x1f && signature[ 1 ] == (byte) 0x8b;
	    } catch (IOException e) {
	        return false;
	    } finally {
	        if(is!=null){
	        	is.close();
	        }
	    }
	}
	
	private Connection getConnection(String vendor,String host,long port,String db_Name,String user,String passwd) throws DataImportException
	{
			logger.info("Begin: getConnection(): vendor "+vendor+ " host : "+host + " port : "+port+ " db_Name : "+db_Name+ " user : "+user);			
		    Connection con = null;
		    String url = null;
	        String driver=null;
	        String schemaName = null;
		    try {
		        if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_MYSQL)) {
		        	url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mysql-driver",null);
				} else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_ORACLE)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-oracle-driver",null);
				} else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_MSSQL)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-mssql-driver",null);
				} else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_TERADATA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-teradata-driver",null);
				}else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_NETEZZA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-netezza-driver",null);
				}else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_POSTGRES)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-postgres-driver",null);
				}else if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_VERTICA)) {
					url = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-url",null);
		        	driver = ZetaUtil.getHelper().getConfig().getConfigValueString("admin-dbsource-vertica-driver",null);
				    if(db_Name != null && db_Name.contains(".")){
				    	schemaName = db_Name.split(Pattern.quote("."))[1];
				    	db_Name = db_Name.split(Pattern.quote("."))[0];
				    }
				}
		        url = CommonUtil.replaceValuesInStringTemplate(url,host,port,db_Name);
				if(vendor.equalsIgnoreCase(DIPreProcessConstants.DBTYPE_VERTICA) && schemaName != null){      	                                                                      
					url=url+"?searchpath="+schemaName;
				} 
				Class.forName(driver).newInstance();  
				String decodedPassword = new Base64Util().decode(passwd);
				logger.error("DB URL"+url );
				con = DriverManager.getConnection(url,user,decodedPassword);
		    }catch(Exception e) {
		    	logger.error("DB URL"+url );
		    	logger.error("Exception: getConnection()",e);
		    	throw new DataImportException("F00002",null,Level.FATAL,e);
		    }finally{
		    	logger.info("End: getConnection()");
			}
		  return con;
	}
	public String getPhysicalTableName(final List<ColumnDefinitionBO> list) {
		return list.stream().filter(rr -> rr.getPhysicalTableName()!= null).findFirst().get().getPhysicalTableName();
        
    }
	
}

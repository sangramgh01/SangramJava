/**
 * DataImportPreProcess.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimportpreprocess.process;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceSpecBO;
import com.zetainteractive.zetahub.de.commons.BatchStatus;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dao.DataImportProgressDao;
import com.zetainteractive.zetahub.de.dataimportpreprocess.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimportpreprocess.init.DataImportPreProcessProducer;
import com.zetainteractive.zetahub.de.dataimportpreprocess.process.impl.DIPreProcessor;
import com.zetainteractive.zetahub.de.dataimportpreprocess.service.DataImportPreProcessService;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessConstants;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessorDependencyCalls;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:41:22 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcess" is used for 
 */
@Component
public class DataImportPreProcess {
	
	@Autowired
	DataImportPreProcessService dIPreProcessservice;
	
	@Autowired
	DIPreProcessorDependencyCalls dependencyCalls;
	
	@Autowired
	DataImportPreProcessProducer processProducer;
	
	@Autowired
	DataImportProgressDao dataImportProgressDao;
	
	ZetaLogger logger=new ZetaLogger(this.getClass()); 
	
	/**
	 * 
	 * @param dataImportDTO
	 * @throws Exception
	 */
	public void processFileType(DataImportDTO dataImportDTO) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : processFileType(DataImportDTO dataImportDTO)");
		List<File> retryFiles=null;
		List<String> tempTables=new ArrayList<>();
		List<String> fileNames=new ArrayList<>();
		try{
			List<FileActivityBO> retryActiivities=null;
			List<File> filesToProcess = new ArrayList<>();
			dataImportDTO.setErrorMessages(new HashMap<>());
			Map<String,List<File>> fileDetails=dIPreProcessservice.getFilesToProcess(dataImportDTO.getFileDefinitionBO());
			if (fileDetails.containsKey(DIPreProcessConstants.RETRY)){
				retryFiles=fileDetails.get(DIPreProcessConstants.RETRY);
				filesToProcess.addAll(retryFiles);
				Map<String,List<FileActivityBO>> retryDetails=dependencyCalls.getRetryFileActivites(dataImportDTO.getFileDefinitionBO().getFileDefinitionID());
				retryActiivities=getRetryFileActivities(retryDetails);
			}
			if (fileDetails.containsKey(DIPreProcessConstants.COMMON)){
				filesToProcess.addAll(fileDetails.get(DIPreProcessConstants.COMMON));
			}
			List<Future<Boolean>> results=new ArrayList<>();
			List<FileActivityBO> activityBOs=new ArrayList<>();
			Long batchId = dIPreProcessservice.getNewBatchId();
			if(filesToProcess==null || filesToProcess.isEmpty()){
				dependencyCalls.createSkippedFileActivity(dataImportDTO.getFileDefinitionBO(), batchId, "-", "-");
				logger.info("There are no files to process.");
				throw new Exception("There are no files to process.");
			}
			List<DIPreProcessor> diPreProcessors=new ArrayList<>();
			ExecutorService executor = Executors.newFixedThreadPool(filesToProcess.size());
			Map<String,String> cacheStorage  =  new ConcurrentHashMap<String, String>(); // using to dedup based on hash key, value is always empty.
			long startTime = System.nanoTime();
			
			int counter=0;
			for(File file : filesToProcess) {
				FileActivityBO fileActivityBO =null;
				//Save file activity
				logger.info("Spanning thread for File :: "+file.getName());
				fileNames.add(file.getName());
				String ignoreFilePath = file.getParent()+File.separator+"logs";
				if (retryFiles == null || !retryFiles.contains(file)){
					fileActivityBO = dependencyCalls.createFileActivity(dataImportDTO.getFileDefinitionBO(),batchId,ignoreFilePath,file.getName());
				}else{
					fileActivityBO=getFileActivityBO(retryActiivities, file.getName());
				}
				//Copy DTO to another object and set activity info to cloned object
				DataImportDTO threaLocalDTO=(DataImportDTO) SerializationUtils.clone((Serializable)dataImportDTO);
				threaLocalDTO.setFileActivityId(fileActivityBO.getFileActivityID());
				threaLocalDTO.setFileActivity(fileActivityBO);
				
				//Creating temp table for each thread
				if (counter==0){
					threaLocalDTO.setTempTableName(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid());
					tempTables.add(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid());
				}else{
					threaLocalDTO.setTempTableName(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid()+"_"+counter);
					tempTables.add(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid()+"_"+counter);
				}
				counter++;
				//Add newly created acitivity id to original DTO
				dataImportDTO.getFileActivityIds().add(fileActivityBO.getFileActivityID());
				
				//Add acitivity to activityBOs lists
				activityBOs.add(fileActivityBO);
				//Initialize thread with cloned dto and file
				//Creating new instance due to thread safe
				DIPreProcessor preProcess = new DIPreProcessor(dependencyCalls, dIPreProcessservice,ZetaUtil.getHelper().getLoggingContextKey());
				
				preProcess.setFileToProcess(file);
				preProcess.setDataImportDTO(threaLocalDTO,cacheStorage);
				diPreProcessors.add(preProcess);
				results.add(executor.submit(preProcess));
			}
			executor.shutdown();
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setFileName(StringUtils.join(fileNames,','));
			Boolean ignoreBadFiles=canIgnoreBadFiles(dataImportDTO);
			Boolean canContinue=updateActivitesBasedOnResults(results,activityBOs,dataImportDTO.getFileDefinitionBO().getUpdatedBy());
			List<Long> completedActivities = getUnErroredActivityIds(activityBOs);
			logger.info("File Def Id :: "+dataImportDTO.getFileDefinitionId()+" canContinue :: "+canContinue+" ignoreBadFiles:: "+ignoreBadFiles+"  completedActivities size :: "+completedActivities.size());
			dataImportDTO.getDataImportProgress().setBatchID(batchId);
			if(dataImportDTO.getFileAction().equals('I')){
				if(canContinue || (ignoreBadFiles && !completedActivities.isEmpty() )){
						updateSummaryCounts(diPreProcessors,dataImportDTO);
						updateDuplicateCountsForSummary(dataImportDTO,cacheStorage);
						dataImportDTO.setFileActivityIds(completedActivities);
						dataImportDTO.setIsInvalidRecordsExist(isInvalidRecordsExist(diPreProcessors));
						if(!tempTables.isEmpty() ){
							tempTables=getUnerroredTempTables(tempTables, activityBOs);
							if (tempTables.contains(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid())){
								tempTables.remove(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid());
								if (!tempTables.isEmpty()){
									dIPreProcessservice.mergeTempTables(tempTables, dataImportDTO);
								}
							}else{
								dIPreProcessservice.mergeTempTables(tempTables, PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid());
							}
							dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.COMPLETED.getValue());
							dataImportProgressDao.updateDataPreProcessStatus(dataImportDTO.getDataImportProgress());
							processProducer.addMessageToQueue(dataImportDTO);
							
						}else{
							dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.COMPLETED.getValue());
							dataImportProgressDao.updateDataPreProcessStatus(dataImportDTO.getDataImportProgress());
							processProducer.addMessageToQueue(dataImportDTO);
						}
				}else{
					pauseUnErroredActivities(activityBOs,dataImportDTO.getFileDefinitionBO().getUpdatedBy());
					dIPreProcessservice.dropTable(dataImportDTO.getTempTableName());
					String errorMessage=getErrorMessage(filesToProcess, dataImportDTO);
					dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_ERRORED.toString().charAt(0),dataImportDTO,errorMessage);
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.ERRORED.getValue());
				}
			}else if(dataImportDTO.getFileAction().equals('S')){
				if(canContinue || (ignoreBadFiles && !completedActivities.isEmpty() )){
					updateSummaryCounts(diPreProcessors,dataImportDTO);
					updateDuplicateCountsForSummary(dataImportDTO,cacheStorage);
					for(FileActivityBO fileActivityBO : activityBOs){
						if(completedActivities.contains(fileActivityBO.getFileActivityID())){
							fileActivityBO.setStatus(PreProcessorConstants.STATUS_COMPLETED.toString().charAt(0));
							fileActivityBO.setCompletedOn(new Date());
							dependencyCalls.updateFileActivity(fileActivityBO,dataImportDTO.getFileDefinitionBO().getUpdatedBy());
						}
					}
					if(!completedActivities.isEmpty()){
						dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_COMPLETED.toString().charAt(0),dataImportDTO,null);
						dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.COMPLETED.getValue());
					}else{
						String errorMessage=getErrorMessage(filesToProcess, dataImportDTO);
						dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_ERRORED.toString().charAt(0),dataImportDTO,errorMessage);
						dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.ERRORED.getValue());
					}
				}else{
					pauseUnErroredActivities(activityBOs,dataImportDTO.getFileDefinitionBO().getUpdatedBy());
					String errorMessage=getErrorMessage(filesToProcess, dataImportDTO);
					dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_ERRORED.toString().charAt(0),dataImportDTO,errorMessage);
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.ERRORED.getValue());
				}
			}
			if(cacheStorage!=null && cacheStorage.size()>0){
				logger.info("cache size :: "+cacheStorage.size()+" Clearing cache for batch :: "+batchId);
				cacheStorage.clear();
			}
				
			logger.info("Data Import preprocess processed all files in  Batch:: "+batchId +" in :: "+ (System.nanoTime() - startTime) / 1000000L + " ms");
		}catch(DataImportException die){
			if("DI0004".equalsIgnoreCase(die.getErrorCode()))
				logger.info("Unable to get files to process");
			throw die;
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw e;
		}finally {
			try {
				if (!tempTables.isEmpty()){
					for (String tempTable: tempTables){
						dIPreProcessservice.dropTable(tempTable);
					}
				}
				
			} catch (Exception e2) {
				logger.error(e2.getMessage(),e2);
			}
			logger.debug("End : "+getClass().getName()+" : processFileType(DataImportDTO dataImportDTO)");
		}
	}
	
	/**
	 * 
	 * @param dataImportDTO
	 * @throws Exception 
	 */
	public void processDataBaseType(DataImportDTO dataImportDTO) throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : processDataBaseType(DataImportDTO dataImportDTO)");
		try{
			dataImportDTO.setErrorMessages(new HashMap<>());
			String localFolderPath = dIPreProcessservice.getLocalFolderPath(dataImportDTO.getFileDefinitionBO().getFileType());
			Long batchId = dIPreProcessservice.getNewBatchId();
			ExecutorService executor = Executors.newFixedThreadPool(1);
			Map<String,String> cacheStorage  =  new ConcurrentHashMap<String, String>(); // using to dedup based on hash key, value is always empty.
			long startTime = System.nanoTime();
			//Save file activity
			logger.info("Spanning thread for Database File Definition Processing");
			String ignoreFilePath = localFolderPath+File.separator+dataImportDTO.getFileDefinitionId()+File.separator+"ignore";
			String avroFilePath = localFolderPath+File.separator+dataImportDTO.getFileDefinitionId()+File.separator+dataImportDTO.getFileDefinitionId()+".avro";
			FileActivityBO fileActivityBO = dependencyCalls.createFileActivity(dataImportDTO.getFileDefinitionBO(),batchId,ignoreFilePath,dataImportDTO.getFileDefinitionId()+".avro");
			//Add newly created acitivity id to original DTO
			dataImportDTO.setAvroFilePath(avroFilePath);
			dataImportDTO.setFileActivityId(fileActivityBO.getFileActivityID());
			dataImportDTO.setFileActivity(fileActivityBO);
			dataImportDTO.getFileActivityIds().add(fileActivityBO.getFileActivityID());
			//Initialize pre processor
			//Creating new instance due to thread safe
			DIPreProcessor preProcess = new DIPreProcessor(dependencyCalls, dIPreProcessservice,ZetaUtil.getHelper().getLoggingContextKey());
			preProcess.setImportFromDatabase(true);
			preProcess.setDataImportDTO(dataImportDTO,cacheStorage);
			Future<Boolean> result=executor.submit(preProcess);
			executor.shutdown();
			//Based on result, place message into queue.
			Boolean canContinue=result.get();
			dataImportDTO.getDataImportProgress().setBatchID(batchId);
			if(dataImportDTO.getFileAction().equals('I')){
				if(canContinue){
					updateDuplicateCountsForSummary(dataImportDTO,cacheStorage);
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.COMPLETED.getValue());
					dataImportProgressDao.updateDataPreProcessStatus(dataImportDTO.getDataImportProgress());
					processProducer.addMessageToQueue(dataImportDTO);
				}
				else{
					dIPreProcessservice.dropTable(dataImportDTO.getTempTableName());
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.ERRORED.getValue());
				}
			}else if(dataImportDTO.getFileAction().equals('S')){ 
				if(canContinue){
					updateDuplicateCountsForSummary(dataImportDTO,cacheStorage);
					fileActivityBO.setStatus(PreProcessorConstants.STATUS_COMPLETED.toString().charAt(0));
					fileActivityBO.setCompletedOn(new Date());
					dependencyCalls.updateFileActivity(fileActivityBO,dataImportDTO.getFileDefinitionBO().getUpdatedBy());
					dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_COMPLETED.toString().charAt(0),dataImportDTO,null);
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.COMPLETED.getValue());
				}else{
					String errorMessage="-";
					if (dataImportDTO.getErrorMessages().containsKey("db"))
						errorMessage=dataImportDTO.getErrorMessages().get("db");
					dependencyCalls.updateFileDefinitionStatus(PreProcessorConstants.STATUS_ERRORED.toString().charAt(0),dataImportDTO,errorMessage);
					dataImportDTO.getDataImportProgress().setPreprocess_status(BatchStatus.ERRORED.getValue());
				}
			}
			//Clear cache storage and continue
			if(cacheStorage!=null && cacheStorage.size()>0){
				logger.info("cache size :: "+cacheStorage.size()+" Clearing cache for batch :: "+batchId);
				cacheStorage.clear();
			}
			logger.info("Data Import preprocess processed with  Batch:: "+batchId +" in :: "+ (System.nanoTime() - startTime) / 1000000L + " ms");
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw e;
		}
		logger.debug("End : "+getClass().getName()+" : processDataBaseType(DataImportDTO dataImportDTO)");
	}
	
	/**
	 * @param dataImportDTO
	 * @throws Exception 
	 */
	public void processFileDefinition(DataImportDTO dataImportDTO) throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : processFileDefinition(DataImportDTO dataImportDTO)");
		FileSourceSpecBO fileSource=dataImportDTO.getFileDefinitionBO().getFileSource();
		if(fileSource!=null && fileSource.getSourceType()=='B')
			processDataBaseType(dataImportDTO);
		else
			processFileType(dataImportDTO);
		logger.debug("End : "+getClass().getName()+" : processFileDefinition(DataImportDTO dataImportDTO)");
	}
	
	private Boolean updateActivitesBasedOnResults(List<Future<Boolean>> results,List<FileActivityBO> activityBOs,String userName) throws InterruptedException, ExecutionException, DataImportException{
		Boolean canContinue=true;
		for(int i=0;i<results.size();i++){
			Boolean result=results.get(i).get();
			if(!result){
				FileActivityBO fileActivityBO=activityBOs.get(i);
				fileActivityBO.setStatus(DIPreProcessConstants.ACTIVITY_ERRORED);
				fileActivityBO.setCompletedOn(new Date());
				dependencyCalls.updateFileActivity(fileActivityBO,userName);
			}
			canContinue=canContinue && result;
		}
		return canContinue;
	}
	
	private Boolean canIgnoreBadFiles(DataImportDTO dataImportDTO){
		Boolean ignoreBadFiles=false;
		if(dataImportDTO.getFileDefinitionBO().getFileProcessingOptions()!=null 
		   && dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadFiles()!=null
		   && dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadFiles()=='Y')
		   ignoreBadFiles=true;
		return ignoreBadFiles;
	}
	
	private void pauseUnErroredActivities(List<FileActivityBO> activityBOs,String userName) throws DataImportException{
		for(FileActivityBO fileActivityBO : activityBOs){
			if(fileActivityBO.getStatus()!=DIPreProcessConstants.ACTIVITY_ERRORED){
				fileActivityBO.setStatus(DIPreProcessConstants.ACTIVITY_PAUSED);
				fileActivityBO.setCompletedOn(new Date());
				dependencyCalls.updateFileActivity(fileActivityBO,userName);
			}
		}
	}
	private List<Long> getUnErroredActivityIds(List<FileActivityBO> activityBOs){
		List<Long> retList=new ArrayList<>();
		for(FileActivityBO fileActivityBO : activityBOs){
			if(fileActivityBO.getStatus()!=DIPreProcessConstants.ACTIVITY_ERRORED)
				retList.add(fileActivityBO.getFileActivityID());
		}
		return retList;
	}
	private String getErrorMessage(List<File> filesList,DataImportDTO dataImportDTO){
		String errorMessage="-";
		Map<String,String> errorMessages=dataImportDTO.getErrorMessages();
		for (File file:filesList){
			if (errorMessages.containsKey(file.getName())){
				errorMessage= errorMessages.get(file.getName());
				break;
			}
		}
		return errorMessage;
	}
	
	private List<FileActivityBO> getRetryFileActivities(Map<String,List<FileActivityBO>> activities) throws JsonParseException, JsonMappingException, JsonProcessingException, IOException{
		List<FileActivityBO> retryActivities=new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();
		if (activities!= null && !activities.isEmpty()){
			for (String key:activities.keySet()){
				if (activities.get(key)!= null && !activities.get(key).isEmpty()){
					for (Object object: activities.get(key)){
						FileActivityBO fileActivityBO=objectMapper.readValue(objectMapper.writeValueAsString(object), FileActivityBO.class);
						if (fileActivityBO.getStatus() == 'R' || fileActivityBO.getStatus() == 'P'){
							retryActivities.add(fileActivityBO);
						}
					}
				}
			}
		}
		return retryActivities;
	}
	private FileActivityBO getFileActivityBO(final List<FileActivityBO> list, final String fileName) {
		return list.stream().filter(rr -> rr.getFileName().equals(fileName)).findFirst().get();
        
    }
	
	private List<String> getUnerroredTempTables(List<String> tables,List<FileActivityBO> activityBOs){
		List<String>  filterList=new ArrayList<>();
		for (int i=0;i<activityBOs.size();i++){
			if (activityBOs.get(i).getStatus() != DIPreProcessConstants.ACTIVITY_ERRORED)
				filterList.add(tables.get(i));
		}
		return filterList;
	}
	
	private Boolean isInvalidRecordsExist(List<DIPreProcessor> diPreProcessors){
		boolean isInvalidRecordsExist=false;
		if (!diPreProcessors.isEmpty()){
			for (DIPreProcessor diPreProcessor : diPreProcessors){
				if(diPreProcessor.getDataImportDTO() != null &&diPreProcessor.getDataImportDTO().getIsInvalidRecordsExist()){
					isInvalidRecordsExist=diPreProcessor.getDataImportDTO().getIsInvalidRecordsExist();
					break;
				}
			}
		}
		return isInvalidRecordsExist;
	}
	
	private void updateSummaryCounts(List<DIPreProcessor> diPreProcessors,DataImportDTO dataImportDTO){
		Long inputRecordsCount=0L;
		Long scrubbedRecordsCount=0L;
		Long invalidRecordsCount=0L;
		for(DIPreProcessor diPreProcessor : diPreProcessors){
			inputRecordsCount+=diPreProcessor.getDataImportDTO().getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount();
			scrubbedRecordsCount+=diPreProcessor.getDataImportDTO().getFileDefinitionBO().getFileSummaryBO().getScrubbedRecordsCount();
			invalidRecordsCount+=diPreProcessor.getDataImportDTO().getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
		}
		dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInputRecordsCount(inputRecordsCount);
		dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setScrubbedRecordsCount(scrubbedRecordsCount);
		dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setInvalidRecordsCount(invalidRecordsCount);
	}
	
	private void updateDuplicateCountsForSummary(DataImportDTO dataImportDTO,Map<String,String> cacheStorage){
		Long inputRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount();
		Long invalidRecordsCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount();
		Long duplicateRecordsCount=inputRecordsCount-cacheStorage.size()-invalidRecordsCount;
		dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setDuplicateRecordsCount(duplicateRecordsCount);
	}
}

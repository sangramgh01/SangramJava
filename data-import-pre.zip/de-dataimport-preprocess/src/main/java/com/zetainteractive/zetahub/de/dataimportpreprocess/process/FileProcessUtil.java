package com.zetainteractive.zetahub.de.dataimportpreprocess.process;

import java.util.concurrent.Callable;

import com.zetainteractive.fileutils.plugin.FileSystemUtilsPlugin;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

/**
 * @Author	   : Sreekhar.Kandala
 * @Created on : Feb 7, 2017 6:45:37 PM
 * @Version	   : 1.7
 * @Description: "FileProcessUtil" is used for  download remote files parllel 
 */
public class FileProcessUtil implements Callable<Boolean>{
	
	
	ZetaLogger logger = new ZetaLogger(getClass());
	FileSystemUtilsPlugin fileUtils;
	String remoteFilePath;
	String doneFilePath;
	
	public FileSystemUtilsPlugin getFileUtils() {
		return fileUtils;
	}

	public void setFileUtils(FileSystemUtilsPlugin fileUtils) {
		this.fileUtils = fileUtils;
	}

	@Override
	public Boolean call() throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : call()");
		boolean downloadStatus=false;
		try {
			downloadStatus = fileUtils.downloadFile();
			if(downloadStatus)
				fileUtils.moveFile(remoteFilePath,doneFilePath,false);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return downloadStatus;
		}
		logger.debug("End : "+getClass().getName()+" : call()");
		return downloadStatus;
	}

	public String getRemoteFilePath() {
		return remoteFilePath;
	}

	public void setRemoteFilePath(String remoteFilePath) {
		this.remoteFilePath = remoteFilePath;
	}

	public String getDoneFilePath() {
		return doneFilePath;
	}

	public void setDoneFilePath(String doneFilePath) {
		this.doneFilePath = doneFilePath;
	}
	

}

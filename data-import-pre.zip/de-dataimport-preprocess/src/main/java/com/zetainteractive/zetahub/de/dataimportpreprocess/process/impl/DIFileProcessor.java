package com.zetainteractive.zetahub.de.dataimportpreprocess.process.impl;

public class DIFileProcessor implements Runnable{

	/**
	 * 
	 * Method Name 	: run
	 * Description 		: The Method "run" is used for 
	 * Date    			: Oct 6, 2016, 9:39:41 PM
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		
	}
	
}

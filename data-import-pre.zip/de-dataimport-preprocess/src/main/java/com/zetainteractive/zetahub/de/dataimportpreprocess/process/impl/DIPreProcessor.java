package com.zetainteractive.zetahub.de.dataimportpreprocess.process.impl;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.SchemaBuilder.FieldAssembler;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.ZetaContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimportpreprocess.process.DIPreProcessorUtils;
import com.zetainteractive.zetahub.de.dataimportpreprocess.service.DataImportPreProcessService;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessConstants;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessorDependencyCalls;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
@Component
@Scope("prototype")
public class DIPreProcessor implements Callable<Boolean>{
	
	DataImportPreProcessService preProcessorService;
	
	DIPreProcessorDependencyCalls dependencyCalls;
	
	DIPreProcessorUtils diPreProcessorUtils;
	
	private File fileToProcess;
	
	private DataImportDTO dataImportDTO;
	
	Boolean importFromDatabase=false;
	
	Map<String,String> cacheStorage;
	
	String contextKey;
	
	
	ZetaLogger logger = new ZetaLogger(getClass());
	/**
	 * for thread safe creating thread local objects
	 * @param dependencyCalls
	 * @param preProcessorService
	 */
	public DIPreProcessor(DIPreProcessorDependencyCalls dependencyCalls,DataImportPreProcessService preProcessorService,String contextKey){
		this.dependencyCalls=dependencyCalls;
		this.preProcessorService=preProcessorService;
		this.diPreProcessorUtils=new DIPreProcessorUtils(dependencyCalls);
		this.contextKey=contextKey;
	}
	
	/**
	 * @return the fileToProcess
	 */
	public File getFileToProcess() {
		return fileToProcess;
	}
	/**
	 * @param fileToProcess the fileToProcess to set
	 */
	public void setFileToProcess(File fileToProcess) {
		this.fileToProcess = fileToProcess;
	}
	/**
	 * @return the dataImportDTO
	 */
	public DataImportDTO getDataImportDTO() {
		return dataImportDTO;
	}
	/**
	 * @param dataImportDTO the dataImportDTO to set
	 */
	public void setDataImportDTO(DataImportDTO dataImportDTO,Map<String,String> cacheStorage) {
		this.dataImportDTO = dataImportDTO;
		this.cacheStorage = cacheStorage;
	}
	/**
	 * 
	 * Method Name 	: run
	 * Description 		: The Method "run" is used for 
	 * Date    			: Oct 6, 2016, 8:25:14 PM
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public Boolean call() {
		logger.debug("Begin : "+getClass().getName()+" : call()");
		Boolean retStatus=false;
		Schema schema=null;
		try {
			initializeContext(dataImportDTO.getCustCode());
			ZetaUtil.getHelper().setLoggingContextKey(contextKey);
			schema=makeSchema(dataImportDTO.getColumns());
			logger.info("Generated Schema after make:: "+schema.toString());
			if(!importFromDatabase){
				logger.info("Started Processing for File :: "+fileToProcess.getName());
				diPreProcessorUtils.setFileDetails(dataImportDTO,schema,fileToProcess,cacheStorage);
				dataImportDTO = diPreProcessorUtils.readFileData();
			}else{
				diPreProcessorUtils.setDatabaseDetails(dataImportDTO,schema,cacheStorage);
				dataImportDTO = diPreProcessorUtils.readDatabaseData();
			}
			if(dataImportDTO.getFileAction().equals('I')){
				boolean result = preProcessorService.createTempTable(dataImportDTO);
				if(result){
					retStatus = preProcessorService.loadDataToTempTable(dataImportDTO);
					if(retStatus)
						diPreProcessorUtils.moveFile(new File(dataImportDTO.getAvroFilePath()), PreProcessorConstants.STATUS_COMPLETED);
				}
			}else if(dataImportDTO.getFileAction().equals('S')){
				retStatus=true;
			}
		} catch (Exception e) {
			try {
				// Dropping temp table if exists 
				preProcessorService.dropTable(dataImportDTO.getTempTableName());
				
				if(dataImportDTO.getAvroFilePath()!=null)
					diPreProcessorUtils.moveFile(new File(dataImportDTO.getAvroFilePath()), PreProcessorConstants.STATUS_ERRORED);
				
				dataImportDTO.getFileActivity().setMessage(e.getMessage());
				if (!importFromDatabase)
					dataImportDTO.getErrorMessages().put(fileToProcess.getName(), e.getMessage());
				else
					dataImportDTO.getErrorMessages().put("db",e.getMessage());
			} catch (Exception ie) {
				logger.error(""+e.getMessage(),e);
			}
			logger.error(""+e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : call()");
		return retStatus;
	}
	
	private Schema makeSchema(List<Column> columns){
		FieldAssembler<Schema> fields=SchemaBuilder.record("Row").namespace("com.zetainteractive.avro").fields();
		for(Column column : columns){
			if(!column.getColumnName().equalsIgnoreCase("ISNEW_2"))
				getSchemaType(column,fields);
		}
		if(dataImportDTO.getAudienceId() == 0 && !(dataImportDTO.getImportType().equals("RESUB") || dataImportDTO.getImportType().equals("UNSUB"))){
				fields=fields.name(DIPreProcessConstants.BATCH_ID).type().longType().noDefault();
				fields=fields.name(DIPreProcessConstants.SRC_FILE_ID).type().longType().noDefault();
		}
		fields=fields.name("isValid").type().stringType().noDefault();
		fields=fields.name("timestamp_dup").type().stringType().noDefault();
		fields=fields.name("keyhash").type().stringType().noDefault();
		
		return fields.endRecord();
	}
	private void getSchemaType(Column column,FieldAssembler<Schema> fields){
		Character isNullable=(column.getIsNullable())?'Y':'N';
		String defaultValue=column.getDefaultValue();
        switch(column.getDataType()){
          case "BYTEINT"   :  
          case "INTEGER"   : if(isNullable=='N' && defaultValue!=null){
        	  					fields=fields.name(column.getColumnName()).type().intType().intDefault(Integer.parseInt(defaultValue));
          					 }else if(isNullable=='N' && defaultValue==null){
          						fields=fields.name(column.getColumnName()).type().intType().noDefault();
          					 }else if(isNullable=='Y' && defaultValue!=null){
          						fields=fields.name(column.getColumnName()).type().nullable().intType().intDefault(Integer.parseInt(defaultValue));
          					 }else if(isNullable=='Y' && defaultValue==null){
          						fields=fields.name(column.getColumnName()).type().nullable().intType().noDefault();
          					 }
          					 break;	
          case "BIGINT"    : if(isNullable=='N' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().longType().longDefault(Long.parseLong(defaultValue));
							 }else if(isNullable=='N' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().longType().noDefault();
							 }else if(isNullable=='Y' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().nullable().longType().longDefault(Long.parseLong(defaultValue));
							 }else if(isNullable=='Y' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().nullable().longType().noDefault();
							 }
							 break;
          case "VARCHAR"   :
          case "DATETIME"  : 
          case "EMAIL"     : 
          case "SMS"       :
          case "TIMESTAMP" :
          case "DATE"      :
          case "TIME"      : if(isNullable=='N' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().stringType().stringDefault(defaultValue);
							 }else if(isNullable=='N' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().stringType().noDefault();
							 }else if(isNullable=='Y' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().nullable().stringType().stringDefault(defaultValue);
							 }else if(isNullable=='Y' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().nullable().stringType().noDefault();
							 }
							 break;
          case "BOOLEAN"   : if(isNullable=='N' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().booleanType().booleanDefault(Boolean.parseBoolean(defaultValue));
							 }else if(isNullable=='N' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().booleanType().noDefault();
							 }else if(isNullable=='Y' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().nullable().booleanType().booleanDefault(Boolean.parseBoolean(defaultValue));
							 }else if(isNullable=='Y' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().nullable().booleanType().noDefault();
							 }
							 break;
          case "FLOAT"     : if(isNullable=='N' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().floatType().floatDefault(Float.parseFloat(defaultValue));
							 }else if(isNullable=='N' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().floatType().noDefault();
							 }else if(isNullable=='Y' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().nullable().floatType().floatDefault(Float.parseFloat(defaultValue));
							 }else if(isNullable=='Y' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().nullable().floatType().noDefault();
							 }
							 break;
          case "DOUBLE"    :
          case "DECIMAL"   : if(isNullable=='N' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().doubleType().doubleDefault(Float.parseFloat(defaultValue));
							 }else if(isNullable=='N' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().doubleType().noDefault();
							 }else if(isNullable=='Y' && defaultValue!=null){
								fields=fields.name(column.getColumnName()).type().nullable().doubleType().doubleDefault(Float.parseFloat(defaultValue));
							 }else if(isNullable=='Y' && defaultValue==null){
								fields=fields.name(column.getColumnName()).type().nullable().doubleType().noDefault();
							 }
							 break;
        }
	}
	/**
	 * @return the importFromDatabase
	 */
	public Boolean getImportFromDatabase() {
		return importFromDatabase;
	}
	/**
	 * @param importFromDatabase the importFromDatabase to set
	 */
	public void setImportFromDatabase(Boolean importFromDatabase) {
		this.importFromDatabase = importFromDatabase;
	}
	
	private void initializeContext(String customerCode) throws Exception{
		ZetaContext ctx = ZetaUtil.getHelper(customerCode, null);
		UserBO uBo = new UserBO();
		uBo.setUserID(1);
		uBo.setUserName(ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser", "dataimportuser"));
		ctx.setUser(uBo);
	}
	
}

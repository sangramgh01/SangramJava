/**
 * DataImportPreProcessService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimportpreprocess.service;

import java.io.File;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimportpreprocess.exception.DataImportException;

/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:42:14 PM
 * @Version	   : 1.7
 * @Description: "DataImportPreProcessService" is used for 
 */
public interface DataImportPreProcessService {

	/**
	 * 
	 * Method Name 	: getFilesToProcess
	 * Description 	: The Method "getFilesToProcess" is used for 
	 * Date    		: Oct 6, 2016, 8:01:48 PM
	 * @param fileDefinitionBO
	 * @return
	 * @param  		:
	 * @return 		: List<File>
	 * @throws Exception 
	 * @throws 		: 
	 */
	public Map<String,List<File>> getFilesToProcess(FileDefinitionBO fileDefinitionBO) throws DataImportException;
	/**
	 * 
	 * 
	 * Method Name 	: createTempTable
	 * Description 	: The Method "createTempTable" is used for 
	 * Date    		: Oct 6, 2016, 11:58:32 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	public boolean createTempTable(DataImportDTO dataImportDTO) throws SQLException;
	/**
	 * 
	 * 
	 * Method Name 	: loadDatatoTempTable
	 * Description 	: The Method "loadDatatoTempTable" is used for 
	 * Date    		: Oct 6, 2016, 11:58:37 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	public boolean loadDataToTempTable(DataImportDTO dataImportDTO) throws SQLException;
	
	public Long getNewBatchId();
	public Map<Long, List<String>> getRetryActivityDetails(Long fileDefinitionID) throws Exception;
	public FileSourceBO getFileSource(String fileSourceName) throws Exception;
	
	public Boolean dropTable(String tableName) throws Exception;
	
	/**
	 * 
	 * @param fileType
	 * @return
	 * @throws Exception
	 */
	public String getLocalFolderPath(Character fileType) throws Exception;
	
	/**
	 * 
	 * 
	 * Method Name 	: mergeTempTables
	 * Description 	: The Method "mergeTempTables" is used for all tables are exist
	 * Date    		: 27 Mar 2017, 15:57:17
	 * @param tempTables
	 * @param dataImportDTO
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: boolean
	 * @throws 		:
	 */
	public boolean mergeTempTables(List<String> tempTables,DataImportDTO dataImportDTO) throws Exception;
	/**
	 * 
	 * 
	 * Method Name 	: mergeTempTables
	 * Description 	: The Method "mergeTempTables" is used for if main temp table not exist then creating 
	 * Date    		: 27 Mar 2017, 15:57:24
	 * @param tempTables
	 * @param tableName
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: boolean
	 * @throws 		:
	 */
	boolean mergeTempTables(List<String> tempTables, String tableName) throws Exception;
	
}

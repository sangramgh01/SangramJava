package com.zetainteractive.zetahub.de.dataimportpreprocess.service.impl;

import java.io.File;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zetainteractive.files.FileUtil;
import com.zetainteractive.fileutils.bo.FileUtilContext;
import com.zetainteractive.fileutils.exception.FileSystemUtilException;
import com.zetainteractive.fileutils.plugin.FileSystemUtilsPlugin;
import com.zetainteractive.fileutils.plugin.impl.FileSystemUtilPluginFactory;
import com.zetainteractive.fileutils.util.FileSystemTypeConstants;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Constants.Constants;
import com.zetainteractive.zetahub.commons.Util.Base64Util;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimportpreprocess.dao.DataImportPreProcessDao;
import com.zetainteractive.zetahub.de.dataimportpreprocess.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimportpreprocess.process.FileProcessUtil;
import com.zetainteractive.zetahub.de.dataimportpreprocess.service.DataImportPreProcessService;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessConstants;
import com.zetainteractive.zetahub.de.dataimportpreprocess.util.DIPreProcessorDependencyCalls;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
/**
 * @Author	   : Krishna.Polisetti
 * @Created on : Oct 6, 2016 6:45:37 PM
 * @Version	   : 1.7
 * @Description: "DataImportServiceImpl" is used for 
 */
@Component
public class DataImportServiceImpl implements DataImportPreProcessService {

	
	ZetaLogger logger = new ZetaLogger(getClass());
	
	@Autowired
	DataImportPreProcessDao dataImportDao;
	
	@Autowired
	DIPreProcessorDependencyCalls dependencyCalls;

	/**
	 * 
	 * 
	 * Method Name 	: getFilesToProcess
	 * Description 		: The Method "getFilesToProcess" is used for 
	 * Date    			: Oct 12, 2016, 2:39:56 PM
	 * @param fileDefinitionBO
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: 
	 * @throws 		:
	 */
	
	@Override
	public Map<String,List<File>> getFilesToProcess(FileDefinitionBO fileDefinitionBO) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getFilesToProcess(FileDefinitionBO fileDefinitionBO)");
		Character sourceType = fileDefinitionBO.getFileSource().getSourceType();
		List<File> filesList = null;
		List<File> retryFileList = null;
		HashMap<Long, List<String>> retryActivityDetails = null;
		Map<String,List<File>> fileDetails=null;
		try {
			fileDetails=new HashMap<>();
			retryActivityDetails = dataImportDao.getRetryActivityDetails(fileDefinitionBO.getFileDefinitionID());
			String localFolderPath = getLocalFolderPath(fileDefinitionBO.getFileType());
			localFolderPath = localFolderPath+File.separator+fileDefinitionBO.getFileDefinitionID();
			logger.info("Getting files from location :: "+localFolderPath);
			if(localFolderPath==null || localFolderPath.trim().length()==0){
				throw new DataImportException("Local Folder Path Was Null");
			}
			if(null != sourceType && sourceType == 'R') {
				File localDir =new File(localFolderPath); 
				if (!localDir.exists())
					localDir.mkdirs();
				List<File> fileDownload = fileDownload(fileDefinitionBO,localFolderPath);
				if(retryActivityDetails!=null && !retryActivityDetails.isEmpty()){
					retryFileList = getRetryFiles(localFolderPath,retryActivityDetails);
					filesList = getFinalFiles(localFolderPath,fileDefinitionBO.getFileSource().getFileNamePattern(),retryFileList);
				}else{
					filesList = getFiles(localFolderPath,fileDownload,fileDefinitionBO.getFileSource().getFileNamePattern());
				}
			}else{
				if(retryActivityDetails != null && retryActivityDetails.size()>0){
					retryFileList=getRetryFiles(localFolderPath,retryActivityDetails);
				}
				filesList = getFiles(localFolderPath,retryFileList);
			}
			if (retryFileList != null && !retryFileList.isEmpty())
				fileDetails.put(DIPreProcessConstants.RETRY, retryFileList);
			if (filesList != null && !filesList.isEmpty())
				fileDetails.put(DIPreProcessConstants.COMMON, filesList);
		} catch (Exception e) {
			logger.info("Exception occured while getting files to process.",e);
			throw new DataImportException("Exception occured while getting files to process.",e);
		}
		logger.debug("End : "+getClass().getName()+" : getFilesToProcess(FileDefinitionBO fileDefinitionBO)");
		return fileDetails;
	}

	@Override
	public String getLocalFolderPath(Character fileType) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : getLocalFolderPath(Character fileType)");
		String filePath = ZetaUtil.getHelper().getConfig().getConfigValueString("dataimport-folder",null);
		if(filePath!=null){
			String custCode = ZetaUtil.getHelper().getCustomerID().toLowerCase();
			String fullFilePath = filePath + File.separator + custCode; 
			if(fileType=='A'){
				fullFilePath += File.separator+"adhocimport";
			}else{
				fullFilePath += File.separator+"batchimport";
			}

			if(fileType=='B'){
				fullFilePath += File.separator+"base";
			}else if(fileType=='D'){
				fullFilePath += File.separator+"dim";
			}else if(fileType=='U'){
				fullFilePath += File.separator+"unsub";
			}else if(fileType=='R'){
				fullFilePath += File.separator+"resub";
			}
			return fullFilePath;
		}
		logger.debug("End : "+getClass().getName()+" : getLocalFolderPath(Character fileType)");
		return null;
	}

	@Override
	public boolean createTempTable(DataImportDTO dataImportDTO) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : createTempTable(DataImportDTO dataImportDTO)");
		dataImportDao.dropTable(dataImportDTO.getTempTableName());
		String crateTemptableDDL = prepareStageCreateTempTableQuery(dataImportDTO);
		logger.debug("End : "+getClass().getName()+" : createTempTable(DataImportDTO dataImportDTO)");
		return dataImportDao.createTempTable(crateTemptableDDL);
	}

	@Override
	public boolean loadDataToTempTable(DataImportDTO dataImportDTO) throws SQLException{
		logger.debug("Begin : "+getClass().getName()+" : loadDataToTempTable(DataImportDTO dataImportDTO)");
		String columns = prepareColumnsForCopyQuery(dataImportDTO);
		String exceptionsLog = dataImportDTO.getIgnoreFilePath()+"exceptions.txt";
		String rejecteddata = dataImportDTO.getIgnoreFilePath()+"rejected.txt";
		String copyQuery = null;
		
		if(dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords()==null || 
			dataImportDTO.getFileDefinitionBO().getFileProcessingOptions().getIgnoreBadRecords()=='N'){
			if(dataImportDTO.isIsInvalidRecordsExist()){
				copyQuery = "copy "+dataImportDTO.getTempTableName()+"("+columns+",ISVALID,timestamp_dup filler varchar,keyhash filler varchar) from local '"+dataImportDTO.getAvroFilePath()+
						"' with parser public.fAvroParser(flatten_arrays=true) EXCEPTIONS '"+exceptionsLog+"' REJECTED DATA '"+rejecteddata+"' ABORT ON ERROR";
			}else{
				copyQuery = "copy "+dataImportDTO.getTempTableName()+"("+columns+",isValid filler varchar,timestamp_dup filler varchar,keyhash filler varchar) from local '"+dataImportDTO.getAvroFilePath()+
						"' with parser public.fAvroParser(flatten_arrays=true) EXCEPTIONS '"+exceptionsLog+"' REJECTED DATA '"+rejecteddata+"' ABORT ON ERROR";
			}
			
		}else{
			if(dataImportDTO.isIsInvalidRecordsExist()){
				copyQuery = "copy "+dataImportDTO.getTempTableName()+"("+columns+",ISVALID,timestamp_dup filler varchar,keyhash filler varchar) from local '"+dataImportDTO.getAvroFilePath()+
				"' with parser public.fAvroParser(flatten_arrays=true) REJECTMAX 0 EXCEPTIONS '"+exceptionsLog+"' REJECTED DATA '"+rejecteddata+"'";
			}else{
				copyQuery = "copy "+dataImportDTO.getTempTableName()+"("+columns+",isValid filler varchar,timestamp_dup filler varchar,keyhash filler varchar) from local '"+dataImportDTO.getAvroFilePath()+
						"' with parser public.fAvroParser(flatten_arrays=true) REJECTMAX 0 EXCEPTIONS '"+exceptionsLog+"' REJECTED DATA '"+rejecteddata+"'";
			}
			
		}
		logger.debug("End : "+getClass().getName()+" : loadDataToTempTable(DataImportDTO dataImportDTO)");
		return dataImportDao.loadDataToTempTable(copyQuery);
	}
	
	/**
	 * @param hubImportStaging
	 * @param tempTableName
	 * @param hubListVo
	 * @return
	 */
	private String prepareStageCreateTempTableQuery(DataImportDTO dataImportDTO)
	{
		logger.info("List Id:: " +dataImportDTO.getListid()+"  Begin: prepareStageCreateTempTableQuery(HubImportStaging hubImportStaging)");

		String query="";
		String[] dtsDefault = getDefaultvaluesString(dataImportDTO);

		String queryColumsVsDataType = prepareColumnsVsDataTypes(dataImportDTO,dtsDefault);

		if(dataImportDTO.isIsInvalidRecordsExist()){
			queryColumsVsDataType = queryColumsVsDataType.replace("ISNEW_2 BOOLEAN", "ISNEW_2 BOOLEAN ENCODING BLOCK_DICT,ISVALID CHAR ENCODING BLOCK_DICT");
		}

		if(dataImportDTO.getAudienceId() > 0 || dataImportDTO.getImportType().equals("RESUB") || dataImportDTO.getImportType().equals("UNSUB"))
			query="CREATE TABLE IF NOT EXISTS "+dataImportDTO.getTempTableName()+"("+queryColumsVsDataType+",AUDIENCE_MEMBER_ID_2 BIGINT) ORDER BY AUDIENCE_MEMBER_ID_2";
		else{
			queryColumsVsDataType+=","+DIPreProcessConstants.BATCH_ID+" BIGINT";
			queryColumsVsDataType+=","+DIPreProcessConstants.SRC_FILE_ID+" BIGINT";
			query="CREATE TABLE IF NOT EXISTS "+dataImportDTO.getTempTableName()+"("+queryColumsVsDataType+")";
		}

		dtsDefault=null;

		logger.debug("Create table query ::  \n"+query);

		return query;
	}
	private Boolean checkIfBatchIdExists(List<Column> columns){
		Boolean retValue=false;
		for(Column column : columns){
			if(DIPreProcessConstants.BATCH_ID.equalsIgnoreCase(column.getColumnName())){
				retValue=true;
				break;
			}
		}
		return retValue;
	}
	private Boolean checkIfSrcFileIdExists(List<Column> columns){
		Boolean retValue=false;
		for(Column column : columns){
			if(DIPreProcessConstants.SRC_FILE_ID.equalsIgnoreCase(column.getColumnName())){
				retValue=true;
				break;
			}
		}
		return retValue;
	}

	/**
	 * 
	 * @param hubImportStaging
	 * @param hubListVo
	 * @return
	 */
	private String[] getDefaultvaluesString(DataImportDTO dataImportDTO){
		String dtsDefault[]=new String[dataImportDTO.getColumns().size()];
		int idx=0;
		for(Column hubListMapping : dataImportDTO.getColumns()) {	
			dtsDefault[idx]=hubListMapping.getDataType(); 			 
			idx++;
		}
		return dtsDefault;
	}

	/**
	 * 
	 * @param hubImportStaging
	 * @param dataTypes
	 * @return
	 */
	private String prepareColumnsVsDataTypes(DataImportDTO dataImportDTO,String dataTypes[])
	{
		logger.info("List Id:: " +dataImportDTO.getListid()+"  Begin: com.zt.ebiz.handler.HubListHandlerVerticaImpl:prepareColumnsVsDataTypes(String columns[],String dataTypes[])");

		String query="";
		String dataType="";

		List<Column> columns = dataImportDTO.getColumns();
		for(int i=0;i<columns.size();i++)
		{
			Column column = columns.get(i);
			if(dataTypes[i].endsWith(PreProcessorConstants.EMAIL_DATATYPE.toString()) 
					|| dataTypes[i].endsWith(PreProcessorConstants.SMS_DATATYPE.toString())
					|| dataTypes[i].endsWith("VARCHAR")
					)
				dataType="VARCHAR("+column.getLength()+") ENCODING GZIP_COMP";			
			else if(dataTypes[i].endsWith(PreProcessorConstants.SMS_DATATYPE.toString()))
				dataType="VARCHAR("+column.getLength()+") ENCODING GZIP_COMP";
			else if(dataTypes[i].contains("DOUBLE"))
				dataType = dataTypes[i].replace("DOUBLE","DOUBLE PRECISION");
			else
				
				dataType=dataTypes[i];

			if( (column.getDefaultValue()!= null && column.getDefaultValue().length()!=0 ) && !(column.getDefaultValue().equalsIgnoreCase("NULL"))){
				if(dataType.contains("NOT NULL")) dataType=dataType.replace("NOT NULL", "");

			}
			if(columns.size()-1==i)
				query+=column.getColumnName()+ " "+dataType;
			else
				query+=column.getColumnName()+ " "+dataType+",";
		}
		return query;

	}

	@Override
	public Long getNewBatchId(){
		return dataImportDao.getNewBatchId();
	}

	@Override
	public Map<Long, List<String>> getRetryActivityDetails(Long fileDefinitionID) throws Exception{
		return dataImportDao.getRetryActivityDetails(fileDefinitionID);
	}

	@Override
	public FileSourceBO getFileSource(String fileSourceName) throws Exception {
		return dependencyCalls.getFileSource(fileSourceName);
	}

	private List<File> fileDownload(FileDefinitionBO fileDefinitionBO,String localFolderPath) throws Exception{
		String fileNamePattern = fileDefinitionBO.getFileSource().getFileNamePattern();
		if(localFolderPath!=null && localFolderPath.trim().length()>0){
			List<String> remoteFileList = null;
			FileSourceBO fileSource = getFileSource(fileDefinitionBO.getFileSource().getSourceName());
			if(fileSource!=null){
				remoteFileList = downloadFilesFromServer(fileSource, fileDefinitionBO, localFolderPath);
				if(remoteFileList!=null && !remoteFileList.isEmpty()){
					File[] files = FileUtil.getFilesSortedByLastModifedDate(localFolderPath, fileNamePattern);
					return Arrays.asList(files);
				}
			}else{
				logger.error("File source getting null with file source name :: "+fileDefinitionBO.getFileSource().getSourceName());
			}
		}
		return null;
	}

	private List<String> downloadFilesFromServer(FileSourceBO fileSource,FileDefinitionBO fileDefinitionBO,String localPath) throws Exception{
		List<String> files = new ArrayList<>();
		//get from remote server
		int sessionTimeout= 2000;
		String folderPath = fileDefinitionBO.getFileSource().getFolderPath();
		Base64Util base64Util = new Base64Util();
		String wildCard = fileDefinitionBO.getFileSource().getFileNamePattern();
		String password = base64Util.decode(fileSource.getPassword());
		FileUtilContext context = new FileUtilContext(fileSource.getHostname(), fileSource.getUsername(), password, fileSource.getPort(), sessionTimeout);
		context.setLocalFilePath(localPath);
		context.setRemoteFilePath(folderPath);
		FileSystemUtilsPlugin fileUtils=null;
		if (fileSource.getProtocol().equalsIgnoreCase(Constants.HTTP_PROTOCOL)
				|| fileSource.getProtocol().equalsIgnoreCase(Constants.HTTPS_PROTOCOL)) {
			//Http contains single file and connecting with url. 
			context.setUrlString(fileSource.getHostname());
			context.setLocalFilePath(localPath+File.separator+fileSource.getHostname().substring(fileSource.getHostname().lastIndexOf("/")));
			fileUtils = new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.HTTP);
		} else {
			fileUtils=getFileSystemPlugin(fileSource.getProtocol());
		}
		fileUtils.setContext(context);
		fileUtils.connect();
		if (fileSource.getProtocol().equalsIgnoreCase(Constants.HTTP_PROTOCOL)
				|| fileSource.getProtocol().equalsIgnoreCase(Constants.HTTPS_PROTOCOL)) {
			boolean isDownloaded=fileUtils.downloadFile();
			if (isDownloaded){
				logger.info("Successfully file downloaded.");
				files.add(localPath+File.separator+fileSource.getHostname().substring(fileSource.getHostname().lastIndexOf("/")));
			}else
				throw new Exception("Failed to download file.");
		}else{
			String[] filesList = fileUtils.listFiles(false,true,true);
			String newPathdir = "";
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
			if(filesList.length > 0){
				File localPathDir=new File(localPath);
				if(!localPathDir.exists())
					localPathDir.mkdirs();
				newPathdir = folderPath+File.separator+"DONE";
				if(wildCard==null)
					wildCard="*";
				int i = 0;
				List<FileProcessUtil> fileProcessUtils=new ArrayList<>();
				
				for (String fileName : filesList) {
					logger.debug("File name :: "+ fileName+" pattern :: "+wildCard);
					if(!FilenameUtils.wildcardMatch(fileName, wildCard, IOCase.SENSITIVE) ||  fileName.endsWith(".avro"))
						continue;
					FileSystemUtilsPlugin fileUtil= getFileSystemPlugin(fileSource.getProtocol());
					String remoteFilePath;
					if (!folderPath.endsWith(File.separator))
						remoteFilePath = new StringBuilder(folderPath).append(File.separator).append(fileName).toString();
					else
						remoteFilePath = new StringBuilder(folderPath).append(fileName).toString();
					
					String localFilePath;
					if (!localPath.endsWith(File.separator))
						localFilePath = new StringBuilder(localPath).append(File.separator).append(fileName).toString();
					else
						localFilePath = new StringBuilder(localPath).append(fileName).toString();
					
					logger.info("Local file path :: "+localFilePath+"   Remote File Path :: "+remoteFilePath);
					context.setLocalFilePath(localFilePath);
					context.setRemoteFilePath(remoteFilePath);
					fileUtil.setContext(context);
					
					String[] fileNames=fileName.split("\\.");
					FileProcessUtil fileProcessUtil=new FileProcessUtil();
					fileProcessUtil.setFileUtils(fileUtil);
					fileProcessUtil.setRemoteFilePath(remoteFilePath);
					fileProcessUtil.setDoneFilePath(newPathdir+File.separator+fileNames[0]+dateFormat.format(new Date())+"_done"
										+fileDefinitionBO.getFileDefinitionID()+"."+ (fileNames.length >1 ? fileNames[1] :""));
					fileProcessUtils.add(fileProcessUtil);
					if(i==0)
						fileUtil.createFolder(newPathdir);
					i++;	
					files.add(localPath+File.separator+fileName);
				
				}
				boolean isAllowParllel=ZetaUtil.getHelper().getConfig().getConfigValueBoolean("di-enable-parallel-file-download", false);
				logger.info("Allow parllel flag value is ::: "+isAllowParllel);
				if (!fileProcessUtils.isEmpty() ){
						//Implementing concurrent parallel downloading files from remote server.
					if (isAllowParllel){
						ExecutorService executor = Executors.newFixedThreadPool(fileProcessUtils.size());
						List<Future<Boolean>> results=new ArrayList<>();
						for (FileProcessUtil fileProcessUtil : fileProcessUtils){
							results.add(executor.submit(fileProcessUtil));
						}
						executor.shutdown();
						Boolean canContinue=true;
						for (Future<Boolean> future : results){
							if (!future.get())
								canContinue=false;
						}
						if (!canContinue){
							logger.error("Failed to download file from remote server.");
							throw new  Exception("Failed to download file from remote server.");
						}
					}else{
						//If parallel download is not enabled then downloading files sequentially. 
						for (FileProcessUtil fileProcessUtil : fileProcessUtils){
							FileSystemUtilsPlugin fileUtil=fileProcessUtil.getFileUtils();
							boolean downloadStatus = fileUtil.downloadFile();
							if(downloadStatus){
								fileUtil.moveFile(fileProcessUtil.getRemoteFilePath(),fileProcessUtil.getDoneFilePath(),false);
							}
						}
					}
				}
			}
		}
		return files;
	}

	private List<File> getFiles(String filesPath, List<File> fileDownload, String pattern) {
		List<File> returnList = new ArrayList<>();
		for(int i=1;i<=3 && returnList.isEmpty();i++){
			File[] files = FileUtil.getFilesSortedByLastModifedDate(filesPath, pattern);
			for (File file : files) {
				if (!file.isDirectory() && fileDownload.contains(file))
					returnList.add(file);
			}
		}
		return returnList;
	}

	private List<File> getFiles(String filesPath,List<File> retryFiles)throws Exception {
		List<File> returnList = new ArrayList<>();
		logger.info("Getting files in drop location.");
		for(int i=1;i<=3 && returnList.isEmpty();i++){
			File[] files = FileUtil.getFilesSortedByLastModifedDate(filesPath, "*");
			for(File fl : files) {
				if (!fl.isDirectory() && (retryFiles == null || !retryFiles.contains(fl))
						&& !(fl.getName().endsWith(".avro")))
					returnList.add(fl);
			}
		}
		return returnList;
	}

	private List<File> getRetryFiles(String filesPath ,HashMap<Long,List<String>> retryDetails) {
		List<File> returnList = new ArrayList<>();
		File file=null;
		File pausedFile=null;
		for (Entry<Long, List<String>> entry : retryDetails.entrySet()) {
			List<String> fileNames = entry.getValue();
			for (String fileName : fileNames) {
				file = new File(filesPath+File.separator+fileName);
				if(file.exists()){
					returnList.add(file);
				}else{
					pausedFile=new File(filesPath+File.separator+fileName+".paused");
					if(pausedFile.exists()){
						pausedFile.renameTo(new File(filesPath+File.separator+fileName));
						file=new File(filesPath+File.separator+fileName);
						if(file.exists())
							returnList.add(file);
					}else{
						//						String message=EbizUtil.getDynamicMessage("BI055", null);
						//						updateFileActivityStatus(retryyDetails.entrySet().iterator().next().getKey(), Constants.ERRORED,hublistvo.getId() , message, fname);
						//						preProcessorService.updateFileActivityStatus();
					}
				}
			}
		}
		return returnList;
	}

	private List<File> getFinalFiles(String filesPath,String fileNamePattern,List<File> retryFiles) {
		List<File> returnList = new ArrayList<>();
		for(int i=1;i<=3 && returnList.isEmpty();i++){
			File[] files = FileUtil.getFilesSortedByLastModifedDate(filesPath, fileNamePattern);
			for (File fl : files) {
				if (!fl.isDirectory() && (retryFiles == null || !retryFiles.contains(fl)))
					returnList.add(fl);
			}
		}
		return returnList;
	}
	
	/**
	 * 
	 * @param hubImportStaging
	 * @param dataTypes
	 * @return
	 */
	private String prepareColumnsForCopyQuery(DataImportDTO dataImportDTO)
	{
		logger.info("List Id:: " +dataImportDTO.getListid()+"  Begin: com.zt.ebiz.handler.HubListHandlerVerticaImpl:prepareColumnsVsDataTypes(String columns[],String dataTypes[])");

		StringBuilder sb = new StringBuilder();
		List<Column> columns = dataImportDTO.getColumns();
		for(int i=0;i<columns.size();i++)
		{
			Column column = columns.get(i);
			
			if(column.getColumnName().equals("ISNEW_2")){
				sb.append(column.getColumnName()+" AS 'Y',");
				sb.append("AUDIENCE_MEMBER_ID_2 AS NEXTVAL('FORGEIDSEQUENCE') ,");
			}
			else{
				sb.append(column.getColumnName()+",");
			}
		}
		if(dataImportDTO.getAudienceId() == 0 && !(dataImportDTO.getImportType().equals("RESUB") || dataImportDTO.getImportType().equals("UNSUB"))){
			sb.append(DIPreProcessConstants.BATCH_ID+",");
			sb.append(DIPreProcessConstants.SRC_FILE_ID+",");
		}
		if(columns.size() > 0)
			return sb.substring(0,sb.lastIndexOf(","));
		else
			return sb.toString();
	}

	@Override
	public Boolean dropTable(String tableName) throws Exception {
		return dataImportDao.dropTable(tableName);
	}

	@Override
	public boolean mergeTempTables(List<String> tempTables,DataImportDTO dataImportDTO) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : mergeTempTables(List<String> tempTables,DataImportDTO dataImportDTO)");
		StringBuilder query=new StringBuilder();
		String mergeQuery=null;
		try {
			query.append("INSERT /*+ direct */ INTO ").append(PreProcessorConstants.TEMP_TABLE_PREFIX.toString()+dataImportDTO.getListid())
				.append(" SELECT * FROM (");
			for (String tempTable : tempTables){
				query.append(" SELECT * FROM ").append(tempTable).append(" UNION");
			}
			if (query.toString().trim().endsWith("UNION"))
				mergeQuery=query.toString().trim().substring(0, query.toString().trim().length()-5);
			else
				mergeQuery=query.toString();
			mergeQuery=mergeQuery+") A";
			logger.debug("Merge query :::: "+mergeQuery);
			dataImportDao.loadDataToTempTable(mergeQuery);
			
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw e;
		}
		logger.debug("End : "+getClass().getName()+" : mergeTempTables(List<String> tempTables,DataImportDTO dataImportDTO)");
		return true;
	}
	
	@Override
	public boolean mergeTempTables(List<String> tempTables,String tableName) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : mergeTempTables(List<String> tempTables,String tableName)");
		StringBuilder query=new StringBuilder();
		String mergeQuery=null;
		try {
			query.append("CREATE TABLE ").append(tableName).append(" AS ")
				.append(" SELECT * FROM (");
			for (String tempTable : tempTables){
				query.append(" SELECT * FROM ").append(tempTable).append(" UNION");
			}
			if (query.toString().trim().endsWith("UNION"))
				mergeQuery=query.toString().trim().substring(0, query.toString().trim().length()-5);
			else
				mergeQuery=query.toString();
			mergeQuery=mergeQuery+") A";
			logger.debug("Merge query :::: "+mergeQuery);
			dataImportDao.loadDataToTempTable(mergeQuery);
			
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw e;
		}
		logger.debug("End : "+getClass().getName()+" : mergeTempTables(List<String> tempTables,String tableName)");
		return true;
	}
	
	private FileSystemUtilsPlugin getFileSystemPlugin(String protocol) throws FileSystemUtilException{
		if (protocol.equalsIgnoreCase(Constants.FTP_PROTOCOL)) {
			return  new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.FTP);
		} else if (protocol.equalsIgnoreCase(Constants.SFTP_PROTOCOL)) {
			return  new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SFTP);
		} else if (protocol.equalsIgnoreCase(Constants.SCP_PROTOCOL)) {
			return new FileSystemUtilPluginFactory().getFileUtils(FileSystemTypeConstants.SCP);
		}
		return null;
	}
	
}

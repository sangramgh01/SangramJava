package com.zetainteractive.zetahub.de.dataimportpreprocess.util;

import java.util.regex.Pattern;

/**
 * @author Lakshmi.Medarametla
 *
 */
public class DIPreProcessConstants {
	public static final Character ACTIVITY_ERRORED='E';
	public static final Character ACTIVITY_PAUSED='P';
	public static final String BATCH_ID = "BATCH_ID";
	public static final String SRC_FILE_ID = "SRC_FILE_ID";
	public static String DBTYPE_MYSQL = "MYSQL";
	public static String DBTYPE_ORACLE = "ORACLE";
	public static String DBTYPE_MSSQL = "MSSQL";
	public static String DBTYPE_TERADATA = "TERADATA";
	public static String DBTYPE_NETEZZA = "NETEZZA";
	public static String DBTYPE_POSTGRES = "POSTGRES";
	public static String DBTYPE_VERTICA = "VERTICA";
	public static String NOTIFICATION_COMPLETE_MSG = "Completed";
	public static final  String SPECIAL_CHARACTERS = "[^0-9a-zA-Z.]";
	
	public static final  String DATE_ERROR_MSG = "Invalid data for date column";
	public static final  String EMAIL_ERROR_MSG = "Invalid data for email column";
	public static final  String SMS_ERROR_MSG = "Invalid data for sms column";
	public static final  String LENGTH_ERROR_MSG = "Record length doesn't match with the mapped column";
	public static final  String ROW_ERROR_MSG = "Invalid record provided";
	
	
	
	
	public static String RETRY = "retryFiles";
	public static String COMMON = "scheduleFiles";
	public static final Pattern DatePatternWithZero = Pattern
			.compile("(((19|20)[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])++[\\s]++((([0-1]{1}[0-9]{1})|([2]{1}[0-3]{1}))[:][0-5]{1}[0-9]{1}[:][0-5]{1}[0-9]{1}[.][0]{1}))");
	
}

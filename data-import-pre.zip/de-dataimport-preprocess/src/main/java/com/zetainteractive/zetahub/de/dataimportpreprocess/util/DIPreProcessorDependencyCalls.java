package com.zetainteractive.zetahub.de.dataimportpreprocess.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.DbSourceBO;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileSourceBO;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.commons.enums.NotificationStatusTypes;
import com.zetainteractive.zetahub.commons.enums.TemplateCodes;
import com.zetainteractive.zetahub.de.commons.DEConstants;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.commons.domain.AlertBO;
import com.zetainteractive.zetahub.de.commons.domain.AlertStatus;
import com.zetainteractive.zetahub.de.commons.domain.JobType;
import com.zetainteractive.zetahub.de.dataimportpreprocess.exception.DataImportException;
import com.zetainteractive.zetahub.de.exporter.bo.PreProcessorConstants;
import com.zetainteractive.zetahub.de.util.AlertingUtil;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * @author lakshmi.medarametla
 *
 */
@Component
public class DIPreProcessorDependencyCalls {
	
	private String adminEndPoint;
	private RestRequestHandler restHandler = new RestRequestHandler();
	ZetaLogger logger = new ZetaLogger(getClass().getName());
	/**
	 * @param customerCode
	 * @param userName
	 * @param searchCriteria
	 * @return
	 * @throws SchedulerException
	 */
	public FileDefinitionBO getFileDefintion(Long fileDefintionId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getFileDefintion(Long fileDefintionId)");
		FileDefinitionBO response = null;
		try{
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response = restHandler.exchange(adminEndPoint+"/file/getFileDefinitionByID/"+fileDefintionId, HttpMethod.GET, entity, FileDefinitionBO.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0002",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getFileDefintion(Long fileDefintionId)");
		return response;
	}
	
	/**
	 * @param fileDefinition
	 * @return
	 * @throws DataImportException
	 */
	public FileActivityBO createFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : createFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName)");
		Long response = null;
		FileActivityBO fileActivityBO=new FileActivityBO();
		try{
			initializeContext();
			fileActivityBO.setFileDefinitionID(fileDefinition.getFileDefinitionID());
			fileActivityBO.setStatus('I');
			fileActivityBO.setStartedOn(new Date());
			fileActivityBO.setMessage("File activity scheduled");
			fileActivityBO.setBatchId(batchId);
			fileActivityBO.setIgnorefilePath(ignoreFilePath);
			fileActivityBO.setCreatedBy(fileDefinition.getUpdatedBy());
			fileActivityBO.setUpdatedBy(fileDefinition.getUpdatedBy());
			fileActivityBO.setFileName(fileName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(fileActivityBO);
			response=restHandler.exchange(adminEndPoint+"/file/saveFileActivity",HttpMethod.POST,entity,Long.class).getBody();
			fileActivityBO.setFileActivityID(response);
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : createFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName)");
		return fileActivityBO;
	}
	
	/**
	 * @param audienceId
	 * @return
	 * @throws DataImportException
	 */
	public AudienceBO getAudience(Long audienceId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getAudience(Long audienceId)");
		AudienceBO response = null;
		try{
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response = restHandler.exchange(adminEndPoint+"/audience/findAudienceById/"+audienceId, HttpMethod.GET, entity, AudienceBO.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getAudience(Long audienceId)");
		return response;
	}
	
	/**
	 * @param filedefId
	 * @return
	 * @throws DataImportException
	 */
	public LinkedHashMap<String, List<FileActivityBO>> getRetryFileActivites(Long fileDefintionId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getRetryFileActivites(Long fileDefintionId)");
		LinkedHashMap<String, List<FileActivityBO>> response = null;
		try{
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response = restHandler.exchange(adminEndPoint+"/file/getfileactivities/"+fileDefintionId, HttpMethod.GET, entity, LinkedHashMap.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getRetryFileActivites(Long fileDefintionId)");
		return response;
	}
	
	public Map<String, String> getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName)");
		HashMap<String,String> columnsMap = new HashMap<String,String>();
		try{
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			PhysicalTableBO physicalTableBO = restHandler.exchange(adminEndPoint + "/physicalTables/findPhysicalTableByName/"+ baseTablePhysicalName,HttpMethod.GET,entity, PhysicalTableBO.class).getBody();
			List<PhysicalColumnBO> columns = physicalTableBO.getPhysicalColumns();
			for (PhysicalColumnBO physicalColumnBO : columns) {
				columnsMap.put(physicalColumnBO.getPhysicalColumnName(),physicalColumnBO.getColumnDefaultValue());
			}
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0004",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName)");
		return columnsMap;
	}
	
	private void initializeContext() throws Exception{
		this.adminEndPoint = ZetaUtil.getHelper().getEndpoint("admin");
	}
	
	/**
	 * 
	 * @param fileSourceName
	 * @return
	 * @throws DataImportException
	 */
	public FileSourceBO getFileSource(String fileSourceName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getFileSource(String fileSourceName)");
		FileSourceBO response = null;
		try {
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			logger.info("FileSource Name:: "+fileSourceName);
			response = restHandler.exchange(adminEndPoint+"/getFileSource/"+fileSourceName, HttpMethod.GET, entity, FileSourceBO.class).getBody();
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new DataImportException("DI0002",e);
		}
		logger.debug("End : "+getClass().getName()+" : getFileSource(String fileSourceName)");
		return response;
	}
	
	public Long updateFileActivity(FileActivityBO fileActivityBO,String userName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : updateFileActivity(FileActivityBO fileActivityBO,String userName)");
		Long response = null;
		try{
			initializeContext();
			fileActivityBO.setUpdatedBy(userName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(fileActivityBO);
			response=restHandler.exchange(adminEndPoint+"/file/saveFileActivity",HttpMethod.POST,entity,Long.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : updateFileActivity(FileActivityBO fileActivityBO,String userName)");
		return response;
	}
	
	public  FileDefinitionBO updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String messgage) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String messgage)");
		FileDefinitionBO response = null;
		Map<String,String> params=new HashMap<>();
		ObjectMapper objectMapper=new ObjectMapper();
		try{
			initializeContext();
			params.put("fileDefinitionId", dataImportDTO.getFileDefinitionId()+"");
			params.put("fileDefinitionStatus", status.toString());
			params.put("fileSummaryBO", objectMapper.writeValueAsString(dataImportDTO.getFileDefinitionBO().getFileSummaryBO()));
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(params);
			response=restHandler.exchange(adminEndPoint+"/file/updateFileDefinitionStatus",HttpMethod.POST,entity,FileDefinitionBO.class).getBody();
			if (dataImportDTO.getIsNotificationEnabled()){
				NotificationInputBO notificationInputBO=prepareNotifcationInput(dataImportDTO, status,dataImportDTO.getNotificationEmails(),ZetaUtil.getHelper().getCustomerID(),messgage);
				if (notificationInputBO != null)
					sendNotification(notificationInputBO);
			}
			
			try{
				if (status == DEConstants.ACTIVITY_ERRORED && (dataImportDTO.getFileActivityIds()!=null && dataImportDTO.getFileActivityIds().size()==0)) {
					sendAlert(dataImportDTO.getCustCode(), dataImportDTO, messgage);
				}
			}catch(Exception e){
				logger.error("An exception occured while sending Alert :: "+e.getMessage());
	    	}
			
		}catch(Exception exception){
    		logger.info("An exception occured while updating file definition status :: "+exception.getMessage());
    		throw new DataImportException("DI0005",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String messgage)");
		return response;
	}
	
	/**
	 * @param status
	 * @param customerCode
	 * @param fileDefinitionBO
	 * @param message
	 */
	private void sendAlert(String customerCode, DataImportDTO dataImportDTO, String message) {
		logger.debug("Start :" + getClass().getName() + " :sendAlert()");
		try {
			logger.debug("Sending JIRA Alert for FileDefId :: " + dataImportDTO.getFileDefinitionId());
			AlertBO alertBO = new AlertBO();
			alertBO.setFileDefinitionID(dataImportDTO.getFileDefinitionId());
			alertBO.setCustCode(dataImportDTO.getCustCode());
			alertBO.setCauseType(AlertStatus.ERROR.toString());
			alertBO.setCause(message);
			alertBO.setJobType(JobType.DATAIMPORT.toString());
			AlertingUtil alertingUtil = new AlertingUtil();
			alertingUtil.sendAlert(alertBO);
			logger.debug("Sent JIRA Alert for FileDefId :: " + dataImportDTO.getFileDefinitionId());
		} catch (Exception e) {
			logger.error("Error occurred while sending alert :: " + e.getMessage());
		}
		logger.debug("End :" + getClass().getName() + " :sendAlert()");
	}
	
	public DbSourceBO getDBSource(String dbSourceName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getDBSource(String dbSourceName)");
		DbSourceBO response = null;
		try{
			initializeContext();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response = restHandler.exchange(adminEndPoint+"/getDBSource/"+dbSourceName, HttpMethod.GET, entity, DbSourceBO.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0005",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getDBSource(String dbSourceName)");
		return response;
	}

	/**
	 * 
	 * Method Name 	: getAudienceId
	 * Description 	: The Method "getAudienceId" is used for 
	 * Date    		: Nov 4, 2016, 4:03:29 PM
	 * @param string
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public long getAudienceId(String audienceName) throws Exception {
			logger.debug("Begin : "+getClass().getName()+" : getAudienceId(String audienceName)");
			initializeContext();
			RestRequestHandler restHandler = new RestRequestHandler();
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity entity = new HttpEntity<>(headers);
			ResponseEntity<AudienceBO> boResponse = restHandler.exchange(adminEndPoint + "/audience/findAudienceByName/"+ audienceName,HttpMethod.GET,entity, AudienceBO.class);
			AudienceBO audience = boResponse.getBody();
			logger.debug("End : "+getClass().getName()+" : getAudienceId(String audienceName)");
			return audience.getAudienceId();
	}
	/**
	 * 
	 * Method Name 	: sendNotification
	 * Description 	: The Method "sending notifications " is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public void sendNotification(NotificationInputBO notificationInputBO) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : sendNotification(NotificationInputBO notificationInputBO)");
		try{
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(notificationInputBO);
			restHandler.exchange(adminEndPoint+"/notifications/sendnotification",HttpMethod.POST,entity,FileDefinitionBO.class);
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		logger.info("An exception occured while sending notifications :: "+exception.getMessage());
    	}
		logger.debug("End : "+getClass().getName()+" : sendNotification(NotificationInputBO notificationInputBO)");
	}
	/**
	 * 
	 * Method Name 	: prepareNotifcationInput
	 * Description 	: The Method "preparing notification input" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public NotificationInputBO prepareNotifcationInput(DataImportDTO dataImportDTO,Character status,Map<String,String> emailMap,String custCode,String message) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : prepareNotifcationInput(DataImportDTO dataImportDTO,Character status,Map<String,String> emailMap,String custCode,String message)");
		StringBuilder emailAddresses=new StringBuilder();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (emailMap.containsKey("default"))
			emailAddresses.append(emailMap.get("default"));
		NotificationInputBO notificationInputBO=new NotificationInputBO();
		Map<String,String> templateValues=new HashMap<>();
		if(status==PreProcessorConstants.STATUS_ERRORED.toString().charAt(0)){ 
			if(!emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()))
				return null;
			else if (!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()));
			}
			notificationInputBO.setTemplateCode(TemplateCodes.DATAIMPORT_ERROR.getValue());
			templateValues.put("status", "Errored");
			if (message != null)
				templateValues.put("message", message);
			else
				templateValues.put("message", "Unknown Exception occurred.");
		}else if(status==PreProcessorConstants.STATUS_COMPLETED.toString().charAt(0) ){
			if (!emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()))
				return null;
			else if(!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()));
			}
			notificationInputBO.setTemplateCode(TemplateCodes.DATAIMPORT_COMPLETE.getValue());
			templateValues.put("status", DIPreProcessConstants.NOTIFICATION_COMPLETE_MSG);
			templateValues.put("completedon", dateFormat.format(new Date(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()).getTime()))+" UTC");
			templateValues.put("processedCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount()));
			templateValues.put("rejectedCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount()));
			templateValues.put("duplicateCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getDuplicateRecordsCount()));
			templateValues.put("successCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getExistingRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount()));
			long totalCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount()
					+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getDuplicateRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getExistingRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount();
			if (dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount() != totalCount)
				logger.info("Some records are missed in summary report : "+(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount()-totalCount));
		}
		templateValues.put("value",String.valueOf(dataImportDTO.getFileDefinitionId()));
		if(dataImportDTO.getImportType().equalsIgnoreCase("ADHOCIMPORT")){
			templateValues.put("modulename","list");
			templateValues.put("type","List");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("BATCHIMPORT")){
			templateValues.put("modulename","file");
			templateValues.put("type","Base");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("DIMENTION")){
			templateValues.put("modulename","file");
			templateValues.put("type","Dimension");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("RESUB")){
			templateValues.put("modulename","file");
			templateValues.put("type","Resub");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("UNSUB")){
			templateValues.put("modulename","file");
			templateValues.put("type","Unsub");
		}
		templateValues.put("name",dataImportDTO.getFileDefinitionBO().getName());
		templateValues.put("customercode",custCode);
		templateValues.put("departmentId", String.valueOf(dataImportDTO.getFileDefinitionBO().getDepartmentID()));
		notificationInputBO.setTemplateValues(templateValues);
		notificationInputBO.setEmailAdresses(emailAddresses.toString());
		logger.debug("End : "+getClass().getName()+" : prepareNotifcationInput(DataImportDTO dataImportDTO,Character status,Map<String,String> emailMap,String custCode,String message)");
		return notificationInputBO;	
	}
	
	/**
	 * 
	 * Method Name 	: getNotificationsFromDepartment
	 * Description 	: The Method "getting notifications from departMent " is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DepartmentSettings getNotificationsFromDepartment(Long departmentId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId)");
		Map<String,Object> json=null;
		DepartmentSettings departmentSettings=null;
		try{
			json=new HashMap<>();
			json.put("departmentId", departmentId);
			json.put("propertyKey", "NOTIFICATIONS");
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(json);
			departmentSettings=restHandler.exchange(adminEndPoint+"/getDepartmentSpecificProperty",HttpMethod.POST,entity,DepartmentSettings.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		logger.info("An exception occured while sending notifications :: "+exception.getMessage());
    	}
		logger.debug("End : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId)");
		return departmentSettings;
	}
	
	/**
	 * @param fileDefinition
	 * @return
	 * @throws DataImportException
	 */
	public FileActivityBO createSkippedFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : createSkippedFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName)");
		Long response = null;
		FileActivityBO fileActivityBO=new FileActivityBO();
		try{
			initializeContext();
			fileActivityBO.setFileDefinitionID(fileDefinition.getFileDefinitionID());
			fileActivityBO.setStatus('U');
			fileActivityBO.setStartedOn(new Date());
			fileActivityBO.setMessage("File schedule skipped due to file not found in drop directory.");
			fileActivityBO.setBatchId(batchId);
			fileActivityBO.setIgnorefilePath(ignoreFilePath);
			fileActivityBO.setCreatedBy(fileDefinition.getUpdatedBy());
			fileActivityBO.setUpdatedBy(fileDefinition.getUpdatedBy());
			fileActivityBO.setFileName(fileName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(fileActivityBO);
			response=restHandler.exchange(adminEndPoint+"/file/saveFileActivity",HttpMethod.POST,entity,Long.class).getBody();
			fileActivityBO.setFileActivityID(response);
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : createSkippedFileActivity(FileDefinitionBO fileDefinition,Long batchId,String ignoreFilePath,String fileName)");
		return fileActivityBO;
	}
	
	/**
	 * 
	 * Method Name 	: getAudienceIdByName
	 * Description 		: The Method "getAudienceId" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param audienceName
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws Exception 
	 * @throws 		: 
	 */
	public long getAudienceIdByName(String audienceName) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : getAudienceIdByName(String audienceName)");
		initializeContext();
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity entity = new HttpEntity<>(headers);
		ResponseEntity<AudienceBO> boResponse = restHandler.exchange(adminEndPoint + "/audience/findAudienceByName/"+ audienceName,HttpMethod.GET,entity, AudienceBO.class);
		AudienceBO audience = boResponse.getBody();
		logger.debug("End : "+getClass().getName()+" : getAudienceIdByName(String audienceName)");
		return audience.getAudienceId();
	}
	
	/**
	 * 
	 * 
	 * Method Name 	: getListType
	 * Description 	: The Method "getListType" is used for to get adhoc list type (seed or general or test).
	 * Date    		: 14 Dec 2017, 15:51:56
	 * @param fileDefinitionId
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getListType(Long fileDefinitionId) throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : getListType(Long fileDefinitionid)");
		initializeContext();
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity<?> entity = new HttpEntity<>(headers);
		ResponseEntity<String> boResponse = restHandler.exchange(adminEndPoint + "/list/getListTypeByFileDefId/"+ fileDefinitionId,HttpMethod.GET,entity, String.class);
		String listType = boResponse.getBody();
		logger.debug("End : "+getClass().getName()+" : getListType(Long fileDefinitionid)");
		return listType;
	}
}

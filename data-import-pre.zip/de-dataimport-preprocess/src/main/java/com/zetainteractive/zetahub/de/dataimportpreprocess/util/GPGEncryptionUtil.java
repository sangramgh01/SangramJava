/*
 * @(#)GPGEncryptionUtil.java	 Created on Mar 28, 2008
 *
 * Copyright (c) 2005 Zeta Interactive.
 * 253/A, Venkateshwara Colony, Road No. 12, Banjara Hills, Hyderabad,
 * A.P, 500 034, India.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Zeta Interactive
 * Technologies. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Zeta Interactive.
 */
package com.zetainteractive.zetahub.de.dataimportpreprocess.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;


/**
 * @author ppandiri
 *
 *         This class is a util which provide methods for encryption and
 *         decryption purposes. It also contains methods for generating key and
 *         getting the appropriate keyids. All these are command line executable
 *         commands which can be executable on a linux machine.
 * 
 */
public class GPGEncryptionUtil {

	
	ZetaLogger logger = new ZetaLogger(GPGEncryptionUtil.class);
	
	private int gpg_exitCode = -1;
	private String gpg_err;
	private static final String kGnuPGCommand = "gpg --batch --armor --output -";

	/**
	 * This method is used to decrypt the file
	 * 
	 * @param inFile
	 *            represents the input file
	 * @param keyfile
	 *            represent the key file
	 * @param passphrase
	 *            is used to decrypt the file
	 * @param the
	 *            output file used to write the decrytped data
	 */
	public boolean decryptFile(String inFile, String keyFile, String passPhrase,String outFile) throws Exception {
		return decrypt(inFile, outFile,passPhrase);
		/*if (!success) {
			throw new Exception("Decryption process failed unexpectedly");
		}*/
	}

	/**
	 * Decrypt
	 *
	 * @param inStr
	 *            input string to decrypt
	 * @param passPhrase
	 *            passphrase for the personal private key to sign with
	 * @return true upon success
	 */
	public boolean decrypt(String inFile, String outFile, String passPhrase) throws Exception {

		return runGnuPG (kGnuPGCommand + " --passphrase-fd 0 --output "+outFile+" --decrypt " + inFile, passPhrase,'D');
	}

	/**
	 * Runs GnuPG external program
	 *
	 * @param commandArgs
	 *            command line arguments
	 * @param c
	 * @param inputStr
	 *            key ID of the key in GnuPG's key database
	 * @return true if success.
	 */
	public boolean runGnuPG (String commandArgs, String inputStr, char c) throws Exception
	{
		logger.debug("Begin : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
		Process		p;
		//String		fullCommand = kGnuPGCommand + " " + commandArgs;
		String		fullCommand = commandArgs;
		
		
		try
		{
			p = Runtime.getRuntime().exec(fullCommand);
		}
		catch(IOException io)
		{
			logger.error(io.getMessage(),io);
			logger.debug("End : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
			return false;
		}
		
		ProcessStreamReader psr_stdout = new ProcessStreamReader(p.getInputStream());
		ProcessStreamReader psr_stderr = new ProcessStreamReader(p.getErrorStream());
		psr_stdout.start();
		psr_stderr.start();
		if (inputStr != null)
		{			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
			try
			{
				if(c == 'E')
				{
					RandomAccessFile outFile = new RandomAccessFile(inputStr,"r");
					String line = null;
					while((line = outFile.readLine())!=null)
					{
						out.write(line);
						out.write(10);
					}					
					outFile.close();
					outFile = null;
				}
				if(c == 'D')
				{
					out.write(inputStr);				
				}
				out.close();
			}
			catch(IOException io)
			{
				logger.error("Exception at write! " + io.getMessage (),io);
				logger.debug("End : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
				return false;
			}
		}
		
		try
		{
			p.waitFor();
			
			psr_stdout.join();
			psr_stderr.join();
		}
		catch(InterruptedException i)
		{
			logger.error("Exception at waitfor! " + i.getMessage (),i);
			logger.debug("End : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
			return false;
		}
		
		try
		{
			//Retreving the error code from process
			gpg_exitCode = p.exitValue ();
			logger.debug("gpg_exitCode = "+gpg_exitCode);
			if(gpg_exitCode != 0)
			{
				gpg_err = psr_stderr.getString();
				
				if(gpg_err.contains("already in secret keyring"))
				{
					logger.error("gpg_err = "+gpg_err);
					logger.debug("End : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
					return false;
				}
				throw new Exception(fullCommand + gpg_err);
			}
		}
		catch (IllegalThreadStateException itse)
		{
			logger.error(itse.getMessage(),itse);
			return false;
		}
		
		gpg_err = psr_stderr.getString();
		logger.debug("End : "+getClass().getName()+" : runGnuPG (String commandArgs, String inputStr, char c)");
		return true;
	}

	/**
	 * Reads an output stream from an external process. Imeplemented as a thred.
	 */
	class ProcessStreamReader extends Thread {
		StringBuffer stream;
		InputStreamReader in;

		final static int BUFFER_SIZE = 1024;

		/**
		 * Creates new ProcessStreamReader object.
		 * 
		 * @param in
		 */
		ProcessStreamReader(InputStream in) {
			super();

			this.in = new InputStreamReader(in);

			this.stream = new StringBuffer();
		}

		public void run() {
			try {
				int read;
				char[] c = new char[BUFFER_SIZE];

				while ((read = in.read(c, 0, BUFFER_SIZE - 1)) > 0) {
					stream.append(c, 0, read);
					if (read < 4)
						break;
				}
			} catch (IOException io) {
				logger.error("Exception in class GPGEncryptionUtil ::"+io);
			}
		}

		String getString() {
			return stream.toString();
		}
	}

}

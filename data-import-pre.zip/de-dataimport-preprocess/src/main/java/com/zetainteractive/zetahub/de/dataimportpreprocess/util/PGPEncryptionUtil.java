/*
 * @(#)PGPEncryptionUtil.java	 Created on Mar 28, 2008
 *
 * Copyright (c) 2005 Zeta Interactive.
 * 253/A, Venkateshwara Colony, Road No. 12, Banjara Hills, Hyderabad,
 * A.P, 500 034, India.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Zeta Interactive
 * Technologies. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Zeta Interactive.
 */
package com.zetainteractive.zetahub.de.dataimportpreprocess.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Iterator;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;

/**
 * @author sveneer
 *
 *         This class is a util which provide methods for encryption and
 *         decryption purposes. This also contains private methods for reading
 *         public key and private keys
 * 
 */
public class PGPEncryptionUtil {

	
	ZetaLogger logger = new ZetaLogger(PGPEncryptionUtil.class);
	/**
	 * Search a secret key ring collection for a secret key corresponding to
	 * keyID if it exists.
	 * 
	 * @param pgpSec
	 *            a secret key ring collection.
	 * @param keyID
	 *            keyID we want.
	 * @param pass
	 *            passphrase to decrypt secret key with.
	 * @return
	 * @throws PGPException
	 * @throws NoSuchProviderException
	 */
	public PGPPrivateKey findSecretKey(PGPSecretKeyRingCollection pgpSec, long keyID, char[] pass)
			throws PGPException, NoSuchProviderException {
		logger.debug("Begin : "+getClass().getName()+" : findSecretKey(PGPSecretKeyRingCollection pgpSec, long keyID, char[] pass)");
		PGPSecretKey pgpSecKey = pgpSec.getSecretKey(keyID);

		if (pgpSecKey == null) {
			logger.debug("End : "+getClass().getName()+" : findSecretKey(PGPSecretKeyRingCollection pgpSec, long keyID, char[] pass)");
			return null;
		}
		logger.debug("End : "+getClass().getName()+" : findSecretKey(PGPSecretKeyRingCollection pgpSec, long keyID, char[] pass)");
		return pgpSecKey.extractPrivateKey(pass, "BC");
	}

	/**
	 * decrypt the passed in message stream
	 */
	private void decryptFile(InputStream in, InputStream keyIn, char[] passwd, String outFile) throws Exception {
		try {
			in = PGPUtil.getDecoderStream(in);
			PGPObjectFactory pgpF = new PGPObjectFactory(in);
			PGPEncryptedDataList enc;
			Object o = pgpF.nextObject();
			//
			// the first object might be a PGP marker packet.
			//
			if (o instanceof PGPEncryptedDataList) {
				enc = (PGPEncryptedDataList) o;
			} else {
				enc = (PGPEncryptedDataList) pgpF.nextObject();
			}
			// find the secret key
			Iterator it = enc.getEncryptedDataObjects();
			PGPPrivateKey sKey = null;
			PGPPublicKeyEncryptedData pbe = null;
			PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn));
			while (sKey == null && it.hasNext()) {
				pbe = (PGPPublicKeyEncryptedData) it.next();
				sKey = findSecretKey(pgpSec, pbe.getKeyID(), passwd);
			}
			if (sKey == null) {
				throw new IllegalArgumentException("secret key for message not found.");
			}
			InputStream clear = pbe.getDataStream(sKey, "BC");
			PGPObjectFactory plainFact = new PGPObjectFactory(clear);
			PGPCompressedData cData = (PGPCompressedData) plainFact.nextObject();
			InputStream compressedStream = new BufferedInputStream(cData.getDataStream());
			PGPObjectFactory pgpFact = new PGPObjectFactory(compressedStream);
			Object message = pgpFact.nextObject();
			if (message instanceof PGPLiteralData) {
				PGPLiteralData ld = (PGPLiteralData) message;
				// FileOutputStream fOut = new
				// FileOutputStream(ld.getFileame());
				FileOutputStream fOut = new FileOutputStream(outFile);
				BufferedOutputStream bOut = new BufferedOutputStream(fOut);
				InputStream unc = ld.getInputStream();
				int ch;
				while ((ch = unc.read()) >= 0) {
					bOut.write(ch);
				}
				bOut.close();
			} else if (message instanceof PGPOnePassSignatureList) {
				throw new PGPException("encrypted message contains a signed message - not literal data.");
			} else {
				throw new PGPException("message is not a simple encrypted file - type unknown.");
			}
			if (pbe.isIntegrityProtected()) {
				if (!pbe.verify()) {
					System.err.println("message failed integrity check");
				} else {
					System.err.println("message integrity check passed");
				}
			}
			/*
			 * else { System.err.println("no message integrity check"); }
			 */
		} catch (PGPException e) {
			System.err.println(e);
			if (e.getUnderlyingException() != null) {
				e.getUnderlyingException().printStackTrace();
			}
			throw e;
		} catch (NoSuchProviderException | IOException  e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
	}
	/**
	 * This is a public method and is exposed to call. This method calls
	 * internally another method which will actually decrypts the file
	 * 
	 * @param inFile
	 *            infile for decrypting
	 * @param keyFile
	 *            secret key file for decrypting
	 * @param passPhrase
	 *            password for recrypting
	 * @param outFile
	 *            output file.
	 * @throws Exception
	 */
	public void decryptFile(FileInputStream in, String keyFile, String passPhrase, String outFile)
			throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : decryptFile(FileInputStream in, String keyFile, String passPhrase, String outFile)");
		try {
			Security.addProvider(new BouncyCastleProvider());
			decryptFile(in, new FileInputStream(keyFile), passPhrase.toCharArray(), outFile);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw e;
		}
		logger.debug("End : "+getClass().getName()+" : decryptFile(FileInputStream in, String keyFile, String passPhrase, String outFile)");
	}
}

package com.zetainteractive.zetahub.de.dataimport.domain

import groovy.transform.Canonical
import groovy.transform.CompileStatic

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

/**
 * 
 * @author Munawwar.Syed
 *
 */
@Canonical
@CompileStatic
class ListEntry {
	Long listId
	List<ProfileProperty> profileProperties	
}

class ProfileProperty {
	String name
	String value
	   
}





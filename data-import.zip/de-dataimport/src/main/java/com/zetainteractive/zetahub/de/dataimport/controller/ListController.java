package com.zetainteractive.zetahub.de.dataimport.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.zetainteractive.tools.contentparser.tag.TagReplacement;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.ResponseObject;
import com.zetainteractive.zetahub.de.commons.domain.LoggerConstants;
import com.zetainteractive.zetahub.de.dataimport.domain.ListEntry;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimport.service.DataImportService;
import com.zetainteractive.zetahub.securityclient.authorize.AuthorizationUtil;

/**
 * 
 * @author Venu.Gudibena
 *
 */
@RestController
@RequestMapping("/lists")
public class ListController {
	Logger logger = LoggerFactory.getLogger(getClass().getName());
	TagReplacement replacement = new TagReplacement();
	@Autowired
	DataImportService dataImportService; 
	
	@Autowired
	MessageSource messageSource;
	
	@HystrixCommand(commandProperties={
			@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="120000")
	})
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteFromList(@RequestBody ListEntry listEntry, HttpServletRequest request,@RequestHeader HttpHeaders headers) throws Exception {
		logger.debug("----Delete Started------");
		Boolean deleteStatus = false;
		 ResponseObject response = new ResponseObject();
         try{
             // Authorization :START
	         if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_CAMPAIGN,
	                                         com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
	        	 response.addError("Unauthorized request ", messageSource.getMessage("E00007",
	                                                         new Object[] { "listAllCampaigns" }, LocaleContextHolder.getLocale()));
	        	 response.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
	                         return new ResponseEntity<ResponseObject>(response, HttpStatus.UNAUTHORIZED);
	         }
			String custCode=request.getHeader(BootStarterConstants.CUSTOMERCODE.toString());
			String userName=request.getHeader(BootStarterConstants.USERNAME.toString());
			 if(!ZetaUtil.getHelper().isLoggingContextDefined()){
                 Map<String, Object> loggerValues = prepareContextKey(headers, (listEntry.getListId() > 0 || listEntry.getListId()!=null) ? listEntry.getListId() : 0);
                 String contextKey=replacement.replace(LoggerConstants.LIST.toString(), loggerValues,"{","}");
                 ZetaUtil.getHelper().setLoggingContextKey(contextKey);
			 }
			deleteStatus = dataImportService.deleteFromList(listEntry,custCode,userName);
			return new ResponseEntity<Boolean>(deleteStatus, HttpStatus.OK);
		} catch (Exception ex) {
			logger.error("Error occurred while deleting from List", ex);
			ResponseObject resp = new ResponseObject();
			if(ex instanceof DataImportException){
				resp.addError("error", ((DataImportException) ex).getErrorCode());
				resp.setMessage(((DataImportException) ex).getErrorCode());
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			resp.setMessage("Unknow Error Occured");
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	@HystrixCommand(commandProperties={
			@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="120000")
	})
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<?> addToList(@RequestBody ListEntry listEntry,HttpServletRequest request,@RequestHeader HttpHeaders headers) throws Exception {
		
		logger.debug("----add Started------");
		Boolean addStatus = false;
		ResponseObject response = new ResponseObject();
        try{
            // Authorization :START
	         if (!AuthorizationUtil.authorize(headers, com.zetainteractive.zetahub.securityclient.constants.Constants.RESOURCE_CAMPAIGN,
	                                         com.zetainteractive.zetahub.securityclient.constants.Constants.ACCESSTYPE_READ)) {
	        	 response.addError("Unauthorized request ", messageSource.getMessage("E00007",
	                                                         new Object[] { "listAllCampaigns" }, LocaleContextHolder.getLocale()));
	        	 response.setHttpStatusCode(HttpStatus.UNAUTHORIZED.value());
	                         return new ResponseEntity<ResponseObject>(response, HttpStatus.UNAUTHORIZED);
	         }
			String custCode=request.getHeader(BootStarterConstants.CUSTOMERCODE.toString());
			String userName=request.getHeader(BootStarterConstants.USERNAME.toString());
			 if(!ZetaUtil.getHelper().isLoggingContextDefined()){
                 Map<String, Object> loggerValues = prepareContextKey(headers, (listEntry.getListId() > 0 || listEntry.getListId()!=null) ? listEntry.getListId() : 0);
                 String contextKey=replacement.replace(LoggerConstants.LIST.toString(), loggerValues,"{","}");
                 ZetaUtil.getHelper().setLoggingContextKey(contextKey);
			 }
			addStatus = dataImportService.addToList(listEntry,custCode,userName);
			return new ResponseEntity<Boolean>(addStatus, HttpStatus.OK);
		} catch (Exception ex) {
			logger.error("Error occurred while adding to List", ex);
			ResponseObject resp = new ResponseObject();
			if(ex instanceof DataImportException){
				resp.addError("error", ((DataImportException) ex).getErrorCode());
				resp.setMessage(((DataImportException) ex).getErrorCode());
				return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
			}
			resp.setHttpStatusCode(HttpStatus.BAD_REQUEST.value());
			resp.setMessage("Unknow Error Occured");
			return new ResponseEntity<ResponseObject>(resp, HttpStatus.BAD_REQUEST);
		}
	}
	private Map<String,Object> prepareContextKey(HttpHeaders  headers,Object idorName){
		Map<String,Object> loggerValues=null;
		loggerValues=new HashMap<>();
		loggerValues.put("CUSTCODE", headers.getFirst(BootStarterConstants.CUSTOMERCODE.toString()));
		loggerValues.put("UID",headers.getFirst(BootStarterConstants.USERID.toString()));
	    loggerValues.put("LISTID", idorName);
		return loggerValues;
	}


}

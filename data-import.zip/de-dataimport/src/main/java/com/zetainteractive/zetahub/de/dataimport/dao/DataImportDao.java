/**
 * DataImportDao.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:17:07 PM
 * @Version	   : 1.7
 * @Description: "DataImportDao" is used for 
 * 
 *
 */

public interface DataImportDao {


	/**
	 * 
	 * Method Name 	: getTableCount
	 * Description 	: The Method "getTableCount" is used for 
	 * Date    		: Sep 28, 2016, 5:23:39 PM
	 * @param duplicateQuery
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long getTableCount(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeUpdateQuery
	 * Description 	: The Method "executeUpdateQuery" is used for 
	 * Date    		: Sep 28, 2016, 5:28:08 PM
	 * @param updateQuery
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	int executeUpdateQuery(String updateQuery) throws SQLException;

	/**
	 * Method Name 	: executeDeleteQuery
	 * Description 	: The Method "executeDeleteQuery" is used for 
	 * Date    		: Sep 28, 2016, 6:52:12 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	boolean executeDeleteQuery(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeInsert
	 * Description 	: The Method "executeInsert" is used for 
	 * Date    		: Sep 28, 2016, 5:32:23 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	int executeInsert(String query) throws SQLException;

	/**
	 * Method Name 	: executeDDL
	 * Description 	: The Method "executeDDL" is used for 
	 * Date    		: Sep 28, 2016, 6:52:40 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		:
	 */
	boolean executeDDL(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: getTableColumnsInfo
	 * Description 	: The Method "getTableColumnsInfo" is used for 
	 * Date    		: Sep 28, 2016, 6:38:20 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws SQLException 
	 * @throws 		: 
	 */
	List<String> getTableColumnsInfo(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeEMAILQueries
	 * Description 	: The Method "executeEMAILQueries" is used for 
	 * Date    		: Sep 28, 2016, 8:30:19 PM
	 * @param column
	 * @param dataImportDTO
	 * @param emailColumn
	 * @param audTypeIdEmail
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn, long audTypeIdEmail,String processingTableName) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeSMSQueries
	 * Description 	: The Method "executeSMSQueries" is used for 
	 * Date    		: Sep 29, 2016, 1:32:29 PM
	 * @param column
	 * @param dataImportDTO
	 * @param smsColumn
	 * @param audTypeIdSMS
	 * @param processTableName
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,	String processTableName) throws SQLException;

	/**
	 * 
	 * Method Name 	: dropTempTables
	 * Description 	: The Method "dropTempTables" is used for 
	 * Date    		: Sep 29, 2016, 3:10:11 PM
	 * @param tempTableName
	 * @param smsProcessTable
	 * @param emailProcessTable
	 * @param  		:
	 * @return 		: void
	 * @throws 		: 
	 */
	void dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable,String viewName) throws SQLException;

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 	: The Method "deleteDuplicateRecords" is used for 
	 * Date    		: Sep 29, 2016, 4:07:56 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws DataImportException 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap) throws DataImportException, SQLException;

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 	: The Method "deleteDuplicateRecords" is used for 
	 * Date    		: Sep 29, 2016, 6:48:13 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param queryprepareArrayToCSV
	 * @return
	 * @param  		:
	 * @return 		: Object
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	void deleteDuplicateRecords(String[] notNullColumns, String tempTableName, String queryprepareArrayToCSV) throws DataImportException;

	/**
	 * 
	 * Method Name 	: executeEmailOrSMSQueries
	 * Description 	: The Method "executeEmailOrSMSQueries" is used for 
	 * Date    		: Oct 20, 2016, 3:41:39 PM
	 * @param audienceId 
	 * @param processTableName 
	 * @param categoryId 
	 * @param custCode 
	 * @param audienceType 
	 * @param type 
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void executeEmailOrSMSQueries(String audienceType, String custCode, int categoryId, String processTableName, long audienceId, int type) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertEmailUnsubs
	 * Description 	: The Method "insertEmailUnsubs" is used for 
	 * Date    		: Oct 21, 2016, 3:25:05 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		: 
	 */
	boolean insertEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException;

	/**
	 * 
	 * Method Name 	: deleteEmailUnsubs
	 * Description 	: The Method "deleteEmailUnsubs" is used for 
	 * Date    		: Oct 21, 2016, 3:27:07 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		: 
	 */
	boolean deleteEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertSmsUnsubs
	 * Description 	: The Method "insertSmsUnsubs" is used for 
	 * Date    		: Oct 21, 2016, 3:27:47 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		: 
	 */
	boolean insertSmsUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException;

	/**
	 * 
	 * Method Name 	: deleteSmsResubs
	 * Description 	: The Method "deleteSmsResubs" is used for 
	 * Date    		: Oct 21, 2016, 3:28:22 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: boolean
	 * @throws SQLException 
	 * @throws 		: 
	 */
	boolean deleteSmsResubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException;
	boolean deleteFromList(Long fileDefinitionID,Long audienceMemberId)throws SQLException;
	public Map<String,Long> checkEmailExist(String email) throws SQLException,Exception;
	/**
	 * Method Name : updateTriggers
	 * Description 	: The Method "updateTriggers" is used for updating schedulenextdue
	 * Date    		: Nov 24, 2016, 2:22:22 PM
	 * @param fileDefinitionID
	 * @return 
	 * @throws SQLException
	 */
	public boolean updateTriggers(Long fileDefinitionID) throws Exception;

	boolean addToList(String physicalTableName, Long audienceMemberId,Map<String,String> colNameAndValue,Map<String, String> columnAndTypes)throws SQLException,Exception;

	Map<String, Long> checkSMSExist(String string)throws SQLException,Exception;

	boolean checkTableExist(String phySicalTableName, String whSchemaName)throws SQLException,Exception;

	boolean checkAudienceMemberExist(String phySicalTableName, Long audienceMemeberId) throws SQLException, Exception;
	public Map<String,Long> checkRecordExist(Map<String, String> keyColumnAndValue, String email, Map<String, String> colNameAndTypeMap) throws SQLException,Exception;

	int deleteRecordFromAdhocTable(Map<String, String> keyColumnAndValue, String adhocTableName,
			Map<String, String> colNameAndTypeMap) throws Exception;
	
	/**
	 * 
	 * 
	 * Method Name 	: executeDefaultEntriesForInvalidSms
	 * Description 	: The Method "executeDefaultEntriesForInvalidSms" is used for inserting default entries for invalid sms for only custom audience. 
	 * Date    		: 4 Apr 2017, 15:40:14
	 * @param dataImportDTO
	 * @throws SQLException
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	void executeDefaultEntriesForInvalidSms(DataImportDTO dataImportDTO) throws SQLException;
	/**
	 * 
	 * 
	 * Method Name 	: executeDefaultEntriesForInvalidEmail
	 * Description 	: The Method "executeDefaultEntriesForInvalidEmail" is used for inserting default entries for invalid emails for only custom audience. 
	 * Date    		: 4 Apr 2017, 15:41:51
	 * @param dataImportDTO
	 * @throws SQLException
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	void executeDefaultEntriesForInvalidEmail(DataImportDTO dataImportDTO) throws SQLException;
	
}

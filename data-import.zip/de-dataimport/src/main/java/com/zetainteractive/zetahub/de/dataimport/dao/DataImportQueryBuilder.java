/**
 * DataImportQueryBuilder.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;

/**
 * 
 * @Author	     : Krishna.Polisetti
 * @Created On  : Sep 26, 2016 7:13:04 PM
 * @Version	     : 1.7 
 * @Description  : "DataImportQueryBuilder" is used for 
 * 
 **/

public class DataImportQueryBuilder {
	
	public static final String EMAIL_ADDRESS_DATATYPE="EMAIL_ADDRESS";
	public static final String SMSNBR_DATATYPE="SMS_NUMBER";
	private  ZetaLogger logger = new ZetaLogger(this.getClass());
	static String EMAIL_DATATYPE="EMAIL";
	static String SMS_DATATYPE="SMS";
	public static final String LINE_SEPERATOR_SYMBOL = "#$%$#";
	public static final String LINE_SEPERATOR_SYMBOL_PATTERN = "\\#\\$\\%\\$\\#";
	public static final String AUDIENCE_MEMBER_ID = "AUDIENCE_MEMBER_ID";
	 public static final String AUDIENCE_TYPE_ID = "AUDIENCE_TYPE_ID";
	 public static final String CREATION_DT = "CREATION_DT";
	 public static final String MODIFIED_DT = "MODIFIED_DT";
	 public static final String BATCH_ID = "BATCH_ID";
	 public static final String SRC_FILE_ID = "SRC_FILE_ID";
	 public static final String BATCHID = "!*BATCHID*!";
	/**
	 * Method Name 	: getCountQueryForEmail
	 * Description 	: The Method "getCountQueryForEmail" is used for 
	 * Date    		: Sep 26, 2016, 9:37:08 PM
	 * @param tempTableName
	 * @param emailColumn
	 * @param column
	 * @param invalidRecordsExist
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getCountQueryForEmail(String tempTableName, String emailColumn, Column column, boolean invalidRecordsExist) {
		logger.debug("Begin : "+getClass().getName()+" : getCountQueryForEmail(String tempTableName, String emailColumn, Column column, boolean invalidRecordsExist)");
		String countQuery ;
		if (invalidRecordsExist) {
			countQuery = "SELECT COUNT(*) FROM " + tempTableName + " STAGING INNER JOIN ADDRESS_EMAIL ON STAGING."
					+ emailColumn + " = ADDRESS_EMAIL." + EMAIL_ADDRESS_DATATYPE
					+ " LEFT OUTER JOIN TARGET ON ADDRESS_EMAIL.ADDRESS_ID = TARGET.ADDRESS_ID  AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND "
					+ "TARGET.ADDRESS_CATEGORY_ID   = " + column.getCategoryType()
					+ " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL AND STAGING.ISVALID IN ('Y','S')";
		}else{
			countQuery ="SELECT COUNT(*) FROM " + tempTableName + " STAGING INNER JOIN ADDRESS_EMAIL ON STAGING."
					+ emailColumn + " = ADDRESS_EMAIL." + EMAIL_ADDRESS_DATATYPE
					+ " LEFT OUTER JOIN TARGET ON ADDRESS_EMAIL.ADDRESS_ID = TARGET.ADDRESS_ID  AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND "
					+ "TARGET.ADDRESS_CATEGORY_ID   = " + column.getCategoryType()
					+ " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL ";
		}
		logger.debug("End : "+getClass().getName()+" : getCountQueryForEmail(String tempTableName, String emailColumn, Column column, boolean invalidRecordsExist)");
		return countQuery;
		
	}

	/**
	 * Method Name 	: getCountQueryForSMS
	 * Description 	: The Method "getCountQueryForSMS" is used for 
	 * Date    		: Sep 26, 2016, 9:36:04 PM
	 * @param tempTableName
	 * @param smsColumn
	 * @param column
	 * @param invalidRecordsExist
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String getCountQueryForSMS(String tempTableName, String smsColumn, Column column,boolean invalidRecordsExist) {
		logger.debug("Begin : "+getClass().getName()+" : getCountQueryForSMS(String tempTableName, String smsColumn, Column column,boolean invalidRecordsExist)");
		String countQuery = "SELECT COUNT(*) FROM " + tempTableName
				+ " STAGING INNER JOIN ADDRESS_SMS ON STAGING." + smsColumn + " = ADDRESS_SMS."
				+ SMSNBR_DATATYPE
				+ " LEFT OUTER JOIN TARGET ON ADDRESS_SMS.ADDRESS_ID = TARGET.ADDRESS_ID AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND "
				+ "TARGET.ADDRESS_CATEGORY_ID = " + column.getCategoryType()
				+ " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";

		if (invalidRecordsExist) {
			countQuery = "SELECT COUNT(*) FROM " + tempTableName
					+ " STAGING INNER JOIN ADDRESS_SMS ON STAGING." + smsColumn
					+ " = ADDRESS_SMS." + SMSNBR_DATATYPE
					+ " LEFT OUTER JOIN TARGET ON ADDRESS_SMS.ADDRESS_ID = TARGET.ADDRESS_ID AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND "
					+ "TARGET.ADDRESS_CATEGORY_ID = "
					+  column.getCategoryType()
					+ " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL AND STAGING.ISVALID IN ('Y','E')";
		}
		logger.debug("End : "+getClass().getName()+" : getCountQueryForSMS(String tempTableName, String smsColumn, Column column,boolean invalidRecordsExist)");
		return countQuery;
	}

	/**
	 * 
	 * Method Name 	: prepareArrayToCSVWithLower
	 * Description 	: The Method "prepareArrayToCSVWithLower" is used for 
	 * Date    		: Sep 26, 2016, 9:44:38 PM
	 * @param notNullKeyColumns
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareArrayToCSVWithLower(List<Column> notNullKeyColumns) {

		logger.debug("Begin : "+getClass().getName()+" : prepareArrayToCSVWithLower(List<Column> notNullKeyColumns)");
		
		String query="";
		
		for(int i=0; i < notNullKeyColumns.size();i++)
		{
			
			String value = notNullKeyColumns.get(i).getColumnName();
			
			if(value.contains("EMAIL_ADHOC")){
				int index = value.indexOf('_');
				if(index != -1){
					value = value.substring(index+1,value.length());
					
				}
			}
            if(value.contains("SMS_ADHOC")){
            	
            	int index = value.indexOf('_');
				if(index != -1){
					value = value.substring(index+1, value.length());
				}
				
			}
            
			if(notNullKeyColumns.size()-1==i){
				
				query+=value+"::VARCHAR";
			}
			else{
				query+=value+ "::VARCHAR,";
			}
			
		}
		logger.debug("End : "+getClass().getName()+" : prepareArrayToCSVWithLower(List<Column> notNullKeyColumns)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareFindDuplicateAudience
	 * Description 	: The Method "prepareFindDuplicateAudience" is used for 
	 * Date    		: Sep 26, 2016, 9:44:43 PM
	 * @param dataImportDTO
	 * @param columnsQuery
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareFindDuplicateAudience(String columnsQuery, String tempTableName) {
		return "SELECT COUNT(*) FROM (SELECT  1 FROM "+tempTableName+" GROUP BY "+columnsQuery+" HAVING   COUNT(*) > 1) DUP_CHECK";
	}

	/**
	 * 
	 * Method Name 	: prepareUpdateAudienceMemberNewOrUpdate
	 * Description 	: The Method "prepareUpdateAudienceMemberNewOrUpdate" is used for 
	 * Date    		: Sep 26, 2016, 9:44:55 PM
	 * @param dataImportDTO
	 * @param notNullKeyColumns
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareUpdateAudienceMemberNewOrUpdate(DataImportDTO dataImportDTO, List<Column> notNullKeyColumns,String tempTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareUpdateAudienceMemberNewOrUpdate(DataImportDTO dataImportDTO, List<Column> notNullKeyColumns,String tempTableName)");
		
		String query="UPDATE /*+ DIRECT */ "+tempTableName+" SET AUDIENCE_MEMBER_ID_2 = BASE.AUDIENCE_MEMBER_ID, ISNEW_2 = FALSE FROM "+dataImportDTO.getBaseTablePhysicalName()+" BASE INNER JOIN AUDIENCE_MEMBER ON BASE.AUDIENCE_MEMBER_ID = AUDIENCE_MEMBER.AUDIENCE_MEMBER_ID WHERE ";
		
		if(dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase("AUDIENCE_EMAIL")){
			query="UPDATE /*+ DIRECT */ "+tempTableName+" SET AUDIENCE_MEMBER_ID_2 = BASE.AUDIENCE_MEMBER_ID, ISNEW_2 = FALSE FROM "
					+ "(select a.AUDIENCE_MEMBER_ID,a.EMAIL_ADDRESS from "+dataImportDTO.getBaseTablePhysicalName()+" a join AUDIENCE_MEMBER b on a.AUDIENCE_MEMBER_ID=b.AUDIENCE_MEMBER_ID "
					+ "where a.EMAIL_ADDRESS in (select EMAIL_ADDRESS from "+tempTableName+")"
					+ ") BASE WHERE ";
		}
		for(int i=0;i<notNullKeyColumns.size();i++){
			String value = notNullKeyColumns.get(i).getColumnName();
			String keyValue=notNullKeyColumns.get(i).getColumnName();
			logger.info("Value :: "+ value);
			if(!(value.contains("EMAIL_ADHOC_")) && !(value.contains("SMS_ADHOC_"))){
				if(value.contains("ADHOC_")){
					value=value.substring(6);
				}
				if(keyValue.equalsIgnoreCase("AUDIENCE_MEMBER_ID")){
					keyValue="AUDIENCE_MEMBER_ID_2";
				}
				query+="BASE."+value+" = "+tempTableName+"."+keyValue;
				if(i<notNullKeyColumns.size()-1)
				{
					query+=" AND ";
				}
		   }else{
			   if(value.startsWith("EMAIL_")){
				   value=value.replace("EMAIL_", "").trim();
				   query+="BASE."+EMAIL_ADDRESS_DATATYPE+" = "+tempTableName+"."+value;
			   }else if(value.startsWith("SMS_")){
				   value=value.replace("SMS_", "").trim();
				   query+="BASE."+SMSNBR_DATATYPE+" ) = "+tempTableName+"."+value;
			   }
			   if(i<notNullKeyColumns.size()-1)
			   {
					query+=" AND ";
			   }
		   }
		}
		if(query.endsWith("AND ")){
			query   = query .substring( 0 , query .length() - 4);
		}
		logger.debug("End : "+getClass().getName()+" : prepareUpdateAudienceMemberNewOrUpdate(DataImportDTO dataImportDTO, List<Column> notNullKeyColumns,String tempTableName)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareDeleteTargetAudienceMembersToAddresses
	 * Description 	: The Method "prepareDeleteTargetAudienceMembersToAddresses" is used for 
	 * Date    		: Sep 26, 2016, 9:45:16 PM
	 * @param column
	 * @param dataImportDTO
	 * @param i
	 * @param emailColumn
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareDeleteTargetAudienceMembersToAddresses(Column column, DataImportDTO dataImportDTO, int type,String columnName) {

		logger.debug("Begin : "+getClass().getName()+" : prepareDeleteTargetAudienceMembersToAddresses(Column column, DataImportDTO dataImportDTO, int type,String columnName)");

		String query ;
		if (type == 1)
			query = "DELETE /*+ DIRECT */ FROM TARGET WHERE TARGET_ID IN (SELECT TARGET.TARGET_ID FROM " + dataImportDTO.getTempTableName()
					+ " STAGING INNER JOIN ADDRESS_EMAIL ON STAGING." + columnName
					+ " = ADDRESS_EMAIL.EMAIL_ADDRESS LEFT OUTER JOIN TARGET ON ADDRESS_EMAIL.ADDRESS_ID = TARGET.ADDRESS_ID  AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = "
					+ column.getCategoryType() + " AND TARGET.ACTIVE_IND = FALSE WHERE TARGET.TARGET_ID IS NOT NULL )";
		else
			query = "DELETE /*+ DIRECT */ FROM TARGET WHERE TARGET_ID IN (SELECT TARGET.TARGET_ID FROM " + dataImportDTO.getTempTableName()
					+ " STAGING INNER JOIN ADDRESS_SMS ON STAGING." + columnName
					+ " = ADDRESS_SMS.SMS_NUMBER LEFT OUTER JOIN TARGET ON ADDRESS_SMS.ADDRESS_ID = TARGET.ADDRESS_ID AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID = "
					+ column.getCategoryType() + " AND TARGET.ACTIVE_IND = FALSE WHERE TARGET.TARGET_ID IS NOT NULL)";
		logger.debug("End : "+getClass().getName()+" : prepareDeleteTargetAudienceMembersToAddresses(Column column, DataImportDTO dataImportDTO, int type,String columnName)");
		return query;

	}

	/**
	 * 
	 * Method Name 	: prepareInsertTargetAudienceMembersToAddresses
	 * Description 	: The Method "prepareInsertTargetAudienceMembersToAddresses" is used for 
	 * Date    		: Sep 26, 2016, 9:45:29 PM
	 * @param column
	 * @param i
	 * @param emailColumn
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertTargetAudienceMembersToAddresses(Column column, int type, DataImportDTO dataImportDTO, String tempTableName) {

		logger.debug("Begin : "+getClass().getName()+" : prepareInsertTargetAudienceMembersToAddresses(Column column, int type, DataImportDTO dataImportDTO, String tempTableName)");

		String query;
		if (type == 1){
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),"
					+ column.getCategoryType() + ",ADDRESS_EMAIL.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2," + dataImportDTO.getAudienceId()
					+ ",1,TRUE,NOW(),'1/1/1900' FROM " + tempTableName + " STAGING INNER JOIN ADDRESS_EMAIL ON STAGING."
					+ column.getColumnName()
					+ " = ADDRESS_EMAIL.EMAIL_ADDRESS LEFT OUTER JOIN TARGET ON ADDRESS_EMAIL.ADDRESS_ID = TARGET.ADDRESS_ID AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = "
					+ column.getCategoryType() + " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";
			if (dataImportDTO.getIsInvalidRecordsExist()) 
				query = query + "  AND STAGING.ISVALID IN ('Y','S')";
		}else{
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),"
					+ column.getCategoryType() + ",ADDRESS_SMS.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2," + dataImportDTO.getAudienceId()
					+ ",3,TRUE,NOW(),'1/1/1900' FROM " + tempTableName + " STAGING INNER JOIN ADDRESS_SMS ON STAGING."
					+ column.getColumnName()
					+ " = ADDRESS_SMS.SMS_NUMBER LEFT OUTER JOIN TARGET ON ADDRESS_SMS.ADDRESS_ID = TARGET.ADDRESS_ID AND STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = "
					+ column.getCategoryType() + " AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";
			if (dataImportDTO.getIsInvalidRecordsExist()) 
				query = query + "  AND STAGING.ISVALID IN ('Y','E')";
		}
		
		logger.debug("End : "+getClass().getName()+" : prepareInsertTargetAudienceMembersToAddresses(Column column, int type, DataImportDTO dataImportDTO, String tempTableName)");
		return query;

	}

	/**
	 * 
	 * Method Name 	: prepareInsertNewAudienceMember
	 * Description 	: The Method "prepareInsertNewAudienceMember" is used for 
	 * Date    		: Sep 27, 2016, 12:38:03 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertNewAudienceMember(DataImportDTO dataImportDTO, String tempTableName) {
		logger.info("Begin : "+getClass().getName()+" : prepareInsertNewAudienceMember(DataImportDTO dataImportDTO, String tempTableName)");
		return "INSERT /*+ DIRECT */ INTO AUDIENCE_MEMBER(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT,MODIFIED_DT) SELECT AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",NOW(),NOW() FROM "+tempTableName+" WHERE  ISNEW_2 = TRUE";
	}

	/**
	 * 
	 * Method Name 	: prepareInsertNewAudiencePerson
	 * Description 	: The Method "prepareInsertNewAudiencePerson" is used for 
	 * Date    		: Sep 27, 2016, 12:41:55 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertNewAudience(DataImportDTO dataImportDTO, String tempTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareInsertNewAudience(DataImportDTO dataImportDTO, String tempTableName)");
		
		String query;
		
		List<String> finalprofileColumnsList = new ArrayList<String>();
		for (Column profileColumn : dataImportDTO.getBaseTableColumns()) {
			if(!profileColumn.getColumnName().equalsIgnoreCase("CREATION_DT") && !profileColumn.getColumnName().equalsIgnoreCase("MODIFIED_DT") 
					&& !profileColumn.getColumnName().equalsIgnoreCase("AUDIENCE_MEMBER_ID") && !profileColumn.getColumnName().equalsIgnoreCase("ISNEW_2")){
				finalprofileColumnsList.add(profileColumn.getColumnName());
			}
		}
		String profileColumns = StringUtils.join(finalprofileColumnsList.toArray(),",");
		logger.info("  profileColumns::"+profileColumns);
		
		if(dataImportDTO.getBaseTablePhysicalName()!=null && dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_EMAIL"))		
			query="INSERT /*+ DIRECT */ INTO "+dataImportDTO.getBaseTablePhysicalName()+"(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,STATUS_ID,CONTACTABLE_IND,EMAIL_DOMAIN_NAME,"+profileColumns+",CREATION_DT,MODIFIED_DT) SELECT AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",0,'T',substring(EMAIL_ADDRESS,strpos(EMAIL_ADDRESS,'@')+1),"+profileColumns+",NOW(),NOW() FROM "+tempTableName+" WHERE  ISNEW_2 = TRUE";
		else if(dataImportDTO.getBaseTablePhysicalName()!=null && dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_SMS"))		
			query="INSERT /*+ DIRECT */ INTO "+dataImportDTO.getBaseTablePhysicalName()+"(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,STATUS_ID,CONTACTABLE_IND,"+profileColumns+",CREATION_DT,MODIFIED_DT) SELECT AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",0,'T',"+profileColumns+",NOW(),NOW() FROM "+tempTableName+" WHERE  ISNEW_2 = TRUE";
		else
			query="INSERT /*+ DIRECT */ INTO "+dataImportDTO.getBaseTablePhysicalName()+"(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,"+profileColumns+",CREATION_DT,MODIFIED_DT) SELECT AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+","+profileColumns+",NOW(),NOW() FROM "+tempTableName+" WHERE  ISNEW_2 = TRUE";
		if(query.contains(",,"))
			query = query.replaceAll(",,", ",");
		logger.debug("End : "+getClass().getName()+" : prepareInsertNewAudience(DataImportDTO dataImportDTO, String tempTableName)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareInsertDirectMailTarget
	 * Description 	: The Method "prepareInsertDirectMailTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:45:07 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertDirectMailTarget(DataImportDTO dataImportDTO, String tempTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareInsertDirectMailTarget(DataImportDTO dataImportDTO, String tempTableName)");
		
		String query;
		
		query="INSERT /*+ DIRECT */ INTO TARGET ( TARGET_ID , ADDRESS_CATEGORY_ID, ADDRESS_ID , AUDIENCE_MEMBER_ID , AUDIENCE_TYPE_ID , CHANNEL_TYPE_ID , ACTIVE_IND , CREATION_DT , INACTIVE_DT ) SELECT NEXTVAL('FORGEIDSEQUENCE'), 125 , 2 , AUDIENCE_MEMBER_ID_2 , "+dataImportDTO.getAudienceId()+" , 2 , TRUE , NOW() , '1/1/1900' FROM "+tempTableName+" WHERE ISNEW_2 = TRUE";
		
		if (dataImportDTO.getIsInvalidRecordsExist()) {
			query = query + "  AND ISVALID='Y'";
		}
		logger.debug("End : "+getClass().getName()+" : prepareInsertDirectMailTarget(DataImportDTO dataImportDTO, String tempTableName)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareInsertCallCentreTarget
	 * Description 	: The Method "prepareInsertCallCentreTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:51:00 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertCallCentreTarget(DataImportDTO dataImportDTO, String tempTableName) {
		logger.info("Begin : "+getClass().getName()+" : prepareInsertCallCentreTarget(DataImportDTO dataImportDTO, String tempTableName)");
		return "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID , ADDRESS_CATEGORY_ID, ADDRESS_ID , AUDIENCE_MEMBER_ID , AUDIENCE_TYPE_ID , CHANNEL_TYPE_ID , ACTIVE_IND , CREATION_DT , INACTIVE_DT ) SELECT NEXTVAL('FORGEIDSEQUENCE'), 125 , 4 , AUDIENCE_MEMBER_ID_2 , "+dataImportDTO.getAudienceId()+" , 4 , TRUE , NOW() , '1/1/1900' FROM "+tempTableName+" WHERE ISNEW_2 = TRUE";
	}

	/**
	 * 
	 * Method Name 	: prepareInsertExportChannelTarget
	 * Description 	: The Method "prepareInsertExportChannelTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:51:16 PM
	 * @param dataImportDTO
	 * @param i
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInsertExportChannelTarget(DataImportDTO dataImportDTO, int type, String tempTableName) {
		logger.info("Begin : "+getClass().getName()+" : prepareInsertExportChannelTarget(DataImportDTO dataImportDTO, int type, String tempTableName)");
		return "INSERT /*+ DIRECT */ INTO TARGET ( TARGET_ID , ADDRESS_CATEGORY_ID, ADDRESS_ID , AUDIENCE_MEMBER_ID , AUDIENCE_TYPE_ID , CHANNEL_TYPE_ID , ACTIVE_IND , CREATION_DT , INACTIVE_DT ) SELECT NEXTVAL('FORGEIDSEQUENCE'), 125 , 5 , AUDIENCE_MEMBER_ID_2 , "+dataImportDTO.getAudienceId()+" ,"+type+" , TRUE , NOW() , '1/1/1900' FROM "+tempTableName+" WHERE ISNEW_2 = TRUE";
	}

	/**
	 * 
	 * Method Name 	: prepareUpdateMemberAttributes
	 * Description 	: The Method "prepareUpdateMemberAttributes" is used for 
	 * Date    		: Sep 27, 2016, 12:51:40 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @param notNullKeyColumns
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareUpdateMemberAttributes(DataImportDTO dataImportDTO, String tempTableName,List<Column> notNullKeyColumns) {
		logger.debug("Begin : "+getClass().getName()+" : prepareUpdateMemberAttributes(DataImportDTO dataImportDTO, String tempTableName,List<Column> notNullKeyColumns)");
		
		String query;
		
		query="UPDATE /*+ DIRECT */ "+dataImportDTO.getBaseTablePhysicalName()+" SET ";
		List<Column> profileColumns= dataImportDTO.getBaseTableColumns();
		List<Column> columns=dataImportDTO.getColumns();
		for (Column profileColumn : profileColumns) {
			if(!(profileColumn.getColumnName().equalsIgnoreCase("CREATION_DT") || profileColumn.getColumnName().equalsIgnoreCase("MODIFIED_DT") || profileColumn.getColumnName().equalsIgnoreCase("ISNEW_2"))){
				if(!profileColumn.getIsKey())
					query+=profileColumn.getColumnName()+" = STAGING."+profileColumn.getColumnName() + ",";  
			}
		}
		String columnName="";
		for (Column column : columns) {
			if(column.isIsKey()){
				if(column.getColumnName().contains("ADHOC_")){
					columnName=column.getColumnName().replace("ADHOC_", "").trim();
		    	}else {
		    		columnName=column.getColumnName();
		    	}
				if(!column.getColumnName().equalsIgnoreCase("ISNEW_2"))
					query+=columnName+" = STAGING."+column.getColumnName() + ",";
			}
		}
		
		query+=" MODIFIED_DT = NOW() FROM "+tempTableName+" STAGING WHERE "+dataImportDTO.getBaseTablePhysicalName()+".AUDIENCE_MEMBER_ID = STAGING.AUDIENCE_MEMBER_ID_2 AND STAGING.ISNEW_2 = FALSE";
		logger.debug("End : "+getClass().getName()+" : prepareUpdateMemberAttributes(DataImportDTO dataImportDTO, String tempTableName,List<Column> notNullKeyColumns)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareInactiveOldTargets
	 * Description 	: The Method "prepareInactiveOldTargets" is used for 
	 * Date    		: Sep 27, 2016, 3:12:53 PM
	 * @param dataImportDTO
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareInactiveOldTargets(DataImportDTO dataImportDTO, String tempTableName) {
		logger.info("Begin : "+getClass().getName()+" : prepareInactiveOldTargets(DataImportDTO dataImportDTO, String tempTableName)");
		
		return "UPDATE /*+ DIRECT */ target SET ACTIVE_IND  = FALSE,INACTIVE_DT = NOW() FROM   ( SELECT target.AUDIENCE_MEMBER_ID,target.ADDRESS_CATEGORY_ID,target.CHANNEL_TYPE_ID,MAX(target.CREATION_DT) CREATION_DT FROM target INNER JOIN "+tempTableName+" STAGING  ON target.AUDIENCE_MEMBER_ID = STAGING.AUDIENCE_MEMBER_ID_2        GROUP BY   target.AUDIENCE_MEMBER_ID ,  target.ADDRESS_CATEGORY_ID, target.CHANNEL_TYPE_ID HAVING COUNT(*) > 1 ) TMP WHERE  target.AUDIENCE_MEMBER_ID  = TMP.AUDIENCE_MEMBER_ID AND    target.ADDRESS_CATEGORY_ID = TMP.ADDRESS_CATEGORY_ID AND    target.CHANNEL_TYPE_ID     = TMP.CHANNEL_TYPE_ID AND    target.CREATION_DT  < TMP.CREATION_DT";
	}

	/**
	 * 
	 * Method Name 	: prepareStageAlterTableQuery
	 * Description 	: The Method "prepareStageAlterTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:22:09 PM
	 * @param dataImportDTO
	 * @param columnsQuery
	 * @return
	 * @param  		:
	 * @return 		: String []
	 * @throws 		: 
	 */
	public String[] prepareStageAlterTableQuery(DataImportDTO dataImportDTO, String oldColumns,HashMap<String,String> dafaultValuesMap,String listTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareStageAlterTableQuery(DataImportDTO dataImportDTO, String oldColumns,HashMap<String,String> dafaultValuesMap,String listTableName)");
		String query;
		String querys[]=null;
		int count=0;
		if(oldColumns!=null && oldColumns.length()!=0){
			String[] columnsNames=oldColumns.split(","); 
			String[] dtsDefault=getDefaultvaluesForAdhocTable(dataImportDTO,dafaultValuesMap);
			String queryColumsVsDataType=prepareColumnsVsDataTypesToRemoveADHOC(dataImportDTO.getColumns(),dtsDefault);		
			if((queryColumsVsDataType!=null && queryColumsVsDataType.length() >0) && ( columnsNames !=null && columnsNames.length > 0))
			{
				String alterColumns=prepareAlterColumnsVsDataTypes(columnsNames,queryColumsVsDataType.split(","));
				if(alterColumns !=null && alterColumns.length() >0 && alterColumns.contains(LINE_SEPERATOR_SYMBOL)){
					String colNames[]=alterColumns.split(LINE_SEPERATOR_SYMBOL_PATTERN,-1);
					querys=new String[colNames.length];
					for(String colName : colNames){
						query="ALTER TABLE "+listTableName+" ADD COLUMN "+ colName+" ";
						querys[count]=query;
						count++;
					}
				}else if(alterColumns !=null && alterColumns.length() >0 ){
					querys=new String[1];
					query="ALTER TABLE "+listTableName+" ADD COLUMN "+ alterColumns+" ";
					querys[count]=query;
				}
			}
		}
		logger.debug("End : "+getClass().getName()+" : prepareStageAlterTableQuery(DataImportDTO dataImportDTO, String oldColumns,HashMap<String,String> dafaultValuesMap,String listTableName)");
		return querys;
	}
	/**
	 * Method Name 	: prepareAlterColumnsVsDataTypes
	 * Description 	: The Method "prepareAlterColumnsVsDataTypes" is used for 
	 * Date    		: Sep 30, 2016, 7:44:15 PM
	 * @param oldColumns
	 * @param newColumns
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	private String prepareAlterColumnsVsDataTypes(String[] oldColumns,String newColumns[])
	{
		String query = "";
		boolean isNewColumn;
		for(int i=0;i<newColumns.length;i++)
		{
			isNewColumn=true;
			for(int j=0;j<oldColumns.length;j++){
				if(oldColumns[j].equalsIgnoreCase(newColumns[i].split(" ")[0])){
					isNewColumn=false;
					break;
				}
			}
			if(isNewColumn){
				query+=newColumns[i]+" "+LINE_SEPERATOR_SYMBOL+" ";
			}
		}
		if(query != null && query.trim().length() >0){
			query=query.substring(0, query.lastIndexOf(LINE_SEPERATOR_SYMBOL));
		}
		return query;
		
	}
	/**
	 * Method Name 	: prepareColumnsVsDataTypesToRemoveADHOC
	 * Description 	: The Method "prepareColumnsVsDataTypesToRemoveADHOC" is used for 
	 * Date    		: Sep 30, 2016, 7:44:07 PM
	 * @param columns
	 * @param dataTypes
	 * @param audienceTableName
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	private String prepareColumnsVsDataTypesToRemoveADHOC(List<Column> columns,String dataTypes[])
	{
		String query="";
		String dataType="";
		
		for(int i=0;i<columns.size();i++){
			/*if(dataTypes[i].endsWith(EMAIL_DATATYPE))
				dataType="VARCHAR(1600) ENCODING GZIP_COMP";			
			else if(dataTypes[i].endsWith(SMS_DATATYPE))
				dataType="VARCHAR(250) ENCODING GZIP_COMP";
			else if(dataTypes[i].contains("DOUBLE"))
				dataType = dataTypes[i].replace("DOUBLE","DOUBLE PRECISION");
			else
				dataType=dataTypes[i];
			*/
			
			if(dataTypes[i].endsWith(EMAIL_DATATYPE) || dataTypes[i].endsWith(SMS_DATATYPE)	|| dataTypes[i].endsWith("VARCHAR"))
				dataType="VARCHAR("+columns.get(i).getLength()+") ENCODING GZIP_COMP";			
			else if (dataTypes[i].startsWith("VARCHAR"))
				dataType=dataTypes[i].replaceAll("VARCHAR", "VARCHAR("+columns.get(i).getLength()+") ");
			else if(dataTypes[i].contains("DOUBLE"))
				dataType = dataTypes[i].replace("DOUBLE","DOUBLE PRECISION");
			else
				dataType=dataTypes[i];
			
			
			
			String columnName="";
			
			if(columns.get(i).getColumnName().startsWith("ADHOC_"))
				columnName=columns.get(i).getColumnName().substring(6);
			else{
				columnName = columns.get(i).getColumnName();
			}
			if(columns.size()-1==i)
				query+=columnName+ " "+dataType;
			else
				query+=columnName+ " "+dataType+",";
		}
		return query;
		
	}
	/**
	 * Method Name 	: getDefaultvaluesForAdhocTable
	 * Description 	: The Method "getDefaultvaluesForAdhocTable" is used for 
	 * Date    		: Sep 27, 2016, 6:35:34 PM
	 * @param dafaultValuesMap 
	 * @param hubImportStaging
	 * @param hubListVo
	 * @return 		: String[]
	 */
	private String[] getDefaultvaluesForAdhocTable(DataImportDTO dataImportDTO, HashMap<String, String> dBColumnDefaultValues){
		
		String dtsDefault[]=new String[dataImportDTO.getColumns().size()];
		 int idx=0;
		 String defaultValue ;
		 if(!(dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_EMAIL") || dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_SMS"))){
			 for(Column hubListMapping : dataImportDTO.getColumns()) {
				 if(null != dBColumnDefaultValues.get(hubListMapping.getColumnName()) && dBColumnDefaultValues.containsKey(hubListMapping.getColumnName())){
					 defaultValue = dBColumnDefaultValues.get(hubListMapping.getColumnName());
					 if( hubListMapping.getDataType().equalsIgnoreCase("VARCHAR") && !defaultValue.equals("''") && !(defaultValue.startsWith("'")&& defaultValue.endsWith("'"))){
						 if(defaultValue.indexOf("'") != -1){
							defaultValue = defaultValue.replaceAll("'", "''");
						 }
					 }
					 if(defaultValue.equals("''") || (defaultValue.startsWith("'")&& defaultValue.endsWith("'"))){
						 dtsDefault[idx]=hubListMapping.getDataType()+" DEFAULT "+defaultValue+" ";
					 }else{
						 dtsDefault[idx]=hubListMapping.getDataType()+" DEFAULT '"+defaultValue+"' "; 
					 }
				 }else{
					 dtsDefault[idx]=hubListMapping.getDataType();
				 }
				 idx++;
			 }
			 
		 }else{
			 for(Column hubListMapping : dataImportDTO.getColumns()) {
				
				 if(hubListMapping.getDataType()!=null && hubListMapping.getDataType().equals(EMAIL_DATATYPE) ||  hubListMapping.getDataType()!=null && hubListMapping.getDataType().equals(SMS_DATATYPE)){
					 dtsDefault[idx]=hubListMapping.getDataType();
				 }else{
					 if(null != dBColumnDefaultValues.get(hubListMapping.getColumnName()) && dBColumnDefaultValues.containsKey(hubListMapping.getColumnName())){
						 defaultValue = dBColumnDefaultValues.get(hubListMapping.getColumnName());
						 if( hubListMapping.getDataType().equalsIgnoreCase("VARCHAR") && !defaultValue.equals("''")){
							 if(defaultValue.indexOf("'") != -1){
								defaultValue = defaultValue.replaceAll("'", "''");
							 }
						 }
						 if(defaultValue.equals("''")){
							 dtsDefault[idx]=hubListMapping.getDataType()+" DEFAULT "+defaultValue+" ";
						 }else{
							 dtsDefault[idx]=hubListMapping.getDataType()+" DEFAULT '"+defaultValue+"' "; 
						 }
					 }else{
					 dtsDefault[idx]=hubListMapping.getDataType();
					 }
				 }
				 idx++;
			 }
		 }
		 
	   return dtsDefault;
	}			
	/**
	 * 
	 * Method Name 	: prepareStageCreateTableQuery
	 * Description 	: The Method "prepareStageCreateTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:28:20 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareStageCreateTableQuery(DataImportDTO dataImportDTO,HashMap<String,String> defaultValuesMap,String listTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareStageCreateTableQuery(DataImportDTO dataImportDTO,HashMap<String,String>");
		
		String query;
		String[] dtsDefault=getDefaultvaluesForAdhocTable(dataImportDTO,defaultValuesMap);
		String queryColumsVsDataType=prepareColumnsVsDataTypesToRemoveADHOC(dataImportDTO.getColumns(),dtsDefault);		
		if(queryColumsVsDataType!=null && queryColumsVsDataType.length()>2)
			query="CREATE TABLE "+listTableName+"(AUDIENCE_MEMBER_ID BIGINT,"+queryColumsVsDataType+") ORDER BY AUDIENCE_MEMBER_ID";
		else
			query="CREATE TABLE "+listTableName+"(AUDIENCE_MEMBER_ID BIGINT) ORDER BY AUDIENCE_MEMBER_ID";
		logger.debug("End : "+getClass().getName()+" : prepareStageCreateTableQuery(DataImportDTO dataImportDTO,HashMap<String,String>");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareStageUpdateTableQuery
	 * Description 	: The Method "prepareStageUpdateTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:31:38 PM
	 * @param dataImportDTO
	 * @param processTableName 
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareStageUpdateTableQuery(DataImportDTO dataImportDTO, String processTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareStageUpdateTableQuery(DataImportDTO dataImportDTO, String processTableName)");
		
		String updateQuery;
		int channelTypeId = 1;
		String keyColumn = EMAIL_ADDRESS_DATATYPE;
		String templKeyColumn=EMAIL_ADDRESS_DATATYPE;
		String audience_table = "";
		if(dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase("AUDIENCE_EMAIL")){
			channelTypeId = 1;
			audience_table = "AUDIENCE_EMAIL";
			/*if(dataImportDTO.isSaveInputColumnsExist()){
				if(null!=hubListVo.getSaveInputColumnName()) templKeyColumn=hubListVo.getSaveInputColumnName();
			}
			else */templKeyColumn=EMAIL_ADDRESS_DATATYPE;
		}			
		else if(dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase("AUDIENCE_SMS")){
			channelTypeId = 3;
			keyColumn = SMSNBR_DATATYPE;
			audience_table = "AUDIENCE_SMS";
			/*if(hubListVo.isSaveInputColumnsExist()) {
				if(null!=hubListVo.getSaveInputColumnName()) templKeyColumn=hubListVo.getSaveInputColumnName();
				
			}
			else */templKeyColumn=SMSNBR_DATATYPE;
		}
			
		updateQuery = " UPDATE /*+ DIRECT */ "+dataImportDTO.getTempTableName() +" TEMP SET AUDIENCE_MEMBER_ID_2 = T.AUDIENCE_MEMBER_ID FROM "+processTableName+"  P , TARGET T ," + audience_table + " AE  WHERE P."+keyColumn+" = TEMP."+templKeyColumn+" AND P.ADDRESSID = T.ADDRESS_ID AND T.AUDIENCE_MEMBER_ID = AE.AUDIENCE_MEMBER_ID AND T.AUDIENCE_TYPE_ID = "+dataImportDTO.getAudienceId()+" AND  T.ADDRESS_CATEGORY_ID = 1 AND T.ACTIVE_IND  = TRUE AND T.CHANNEL_TYPE_ID =  "+channelTypeId;
		logger.debug("End : "+getClass().getName()+" : prepareStageUpdateTableQuery(DataImportDTO dataImportDTO, String processTableName)");
		return updateQuery;
	}

	/**
	 * 
	 * Method Name 	: prepareStageInsertTableQuery
	 * Description 	: The Method "prepareStageInsertTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:31:48 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareStageInsertTableQuery(DataImportDTO dataImportDTO,String listTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareStageInsertTableQuery(DataImportDTO dataImportDTO,String listTableName)");
		
		String query;		
		String prepareArrayToCSV=prepareArrayToCSV(dataImportDTO.getColumns());
		if(prepareArrayToCSV!=null && prepareArrayToCSV.length()>2)
			query="INSERT /*+ DIRECT */ INTO " + listTableName+" SELECT AUDIENCE_MEMBER_ID_2,"+prepareArrayToCSV+" from "+dataImportDTO.getTempTableName();
		else
			query="INSERT /*+ DIRECT */ INTO " + listTableName+"  SELECT AUDIENCE_MEMBER_ID_2 from "+dataImportDTO.getTempTableName();
		logger.debug("End : "+getClass().getName()+" : prepareStageInsertTableQuery(DataImportDTO dataImportDTO,String listTableName)");
		return query;
	}
	/**
	 * Method Name 	: prepareArrayToCSV
	 * Description 	: The Method "prepareArrayToCSV" is used for 
	 * Date    		: Sep 30, 2016, 7:43:53 PM
	 * @param columns
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String prepareArrayToCSV(List<Column> columns)
	{
		logger.debug("Begin : "+getClass().getName()+" : prepareArrayToCSV(List<Column> columns)");
		String query="";
		
		for(int i=0;i<columns.size();i++)
		{
			if(columns.size()-1==i)
				query+=columns.get(i).getColumnName();
			else
				query+=columns.get(i).getColumnName()+ ",";
		}
		logger.debug("End : "+getClass().getName()+" : prepareArrayToCSV(List<Column> columns)");
		return query;
	}
	/**
	 * 
	 * Method Name 	: prepareStageInsertTableQueryWithoutExisting
	 * Description 	: The Method "prepareStageInsertTableQueryWithoutExisting" is used for 
	 * Date    		: Sep 27, 2016, 3:31:57 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareStageInsertTableQueryWithoutExisting(DataImportDTO dataImportDTO,String listTableName) {
		logger.debug("Begin : "+getClass().getName()+" : prepareStageInsertTableQueryWithoutExisting(DataImportDTO dataImportDTO,String listTableName)");
		
		String query;
		boolean isNew=false;
		String prepareInsertNewCSV="";
		
		String prepareArrayToCSV=prepareArrayToCSV(dataImportDTO.getColumns());
		String[] prepareArrayInsertToCSV=prepareArrayToCSV.split(",");
		for(int i=0;i<prepareArrayInsertToCSV.length;i++){
			if(!(prepareArrayInsertToCSV[i].equals("ISNEW_2"))){
				if((prepareArrayInsertToCSV[i].contains("ADHOC_"))){
					prepareInsertNewCSV+=prepareArrayInsertToCSV[i].replace("ADHOC_", "").trim();
				}else{
					prepareInsertNewCSV+=prepareArrayInsertToCSV[i].trim();
				}
			}else{
				prepareInsertNewCSV+=prepareArrayInsertToCSV[i].trim();
			}
			if(i<prepareArrayInsertToCSV.length-1){
				prepareInsertNewCSV+=",";
			}
		}
		if(prepareArrayToCSV!=null && prepareArrayToCSV.length()>2){
			if(isNew){
				query="INSERT /*+ DIRECT */ INTO " + listTableName+" SELECT AUDIENCE_MEMBER_ID_2,"+prepareArrayToCSV+" from "+dataImportDTO.getTempTableName() ;
			}
			else {
				query="INSERT /*+ DIRECT */ INTO " + listTableName+"( AUDIENCE_MEMBER_ID,"+ prepareInsertNewCSV +" )"+" SELECT AUDIENCE_MEMBER_ID_2,"+prepareArrayToCSV+" from "+dataImportDTO.getTempTableName() +" STAGING WHERE NOT EXISTS (SELECT AUDIENCE_MEMBER_ID FROM " + listTableName+" C WHERE  C.AUDIENCE_MEMBER_ID= STAGING.AUDIENCE_MEMBER_ID_2)";
			}
		}
		else{
			query="INSERT /*+ DIRECT */ INTO " + listTableName+" SELECT AUDIENCE_MEMBER_ID_2 from "+dataImportDTO.getTempTableName()+" STAGING WHERE NOT EXISTS (SELECT AUDIENCE_MEMBER_ID FROM " +listTableName+" C WHERE  C.AUDIENCE_MEMBER_ID= STAGING.AUDIENCE_MEMBER_ID_2)";
		}
		logger.debug("End : "+getClass().getName()+" : prepareStageInsertTableQueryWithoutExisting(DataImportDTO dataImportDTO,String listTableName)");
		return query;
	}

	/**
	 * 
	 * Method Name 	: prepareProcessCreateTableQuery
	 * Description 	: The Method "prepareProcessCreateTableQuery" is used for 
	 * Date    		: Sep 28, 2016, 8:13:50 PM
	 * @param column
	 * @param dataImportDTO
	 * @param i
	 * @param string 
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareProcessCreateTableQuery(int type, String processingTableName,List<Column> columns) {

		logger.debug("Begin : "+getClass().getName()+" : prepareProcessCreateTableQuery(int type, String processingTableName,List<Column> columns)");
		
		String query;
		
		String queryColumsVsDataType = prepareColumnsVsDataTypes(columns);
		if(type==1)
			query="CREATE TABLE "+processingTableName+"("+queryColumsVsDataType+") ORDER BY "+EMAIL_ADDRESS_DATATYPE;
		else
			query="CREATE TABLE "+processingTableName+"("+queryColumsVsDataType+") ORDER BY "+SMSNBR_DATATYPE;
		logger.debug("End : "+getClass().getName()+" : prepareProcessCreateTableQuery(int type, String processingTableName,List<Column> columns)");
		return query;
	
		
	}
	/**
	 * Method Name 	: prepareColumnsVsDataTypes
	 * Description 	: The Method "prepareColumnsVsDataTypes" is used for 
	 * Date    		: Sep 30, 2016, 7:43:43 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	private String prepareColumnsVsDataTypes(List<Column> columns) {
		
		String query="";
		String dataType;
		for (int i=0;i<columns.size();i++) {
			Column column = columns.get(i);
			if(column.getDataType().endsWith(EMAIL_DATATYPE) || column.getDataType().endsWith(SMS_DATATYPE) || column.getDataType().endsWith("VARCHAR"))
				dataType="VARCHAR("+column.getLength()+") ENCODING GZIP_COMP";		
			else
				dataType=column.getDataType();
			
			if(columns.size()-1==i)
				query+=column.getColumnName()+ " "+dataType;
			else
				query+=column.getColumnName()+ " "+dataType+",";
		}
		return query;
	}
	/**
	 * 
	 * Method Name 	: prepareProcessQuery
	 * Description 	: The Method "prepareProcessQuery" is used for 
	 * Date    		: Sep 28, 2016, 8:16:50 PM
	 * @param column
	 * @param i
	 * @param emailColumn
	 * @param dataImportDTO
	 * @param string 
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws 		: 
	 */
	public String prepareProcessQuery(Column column, int type, String emailColumn, DataImportDTO dataImportDTO, String processTableName,List<Column> columns) {

		logger.debug("Begin : "+getClass().getName()+" : prepareProcessQuery(Column column, int type, String emailColumn, DataImportDTO dataImportDTO, String processTableName,List<Column> columns)");
		
		String query;
		
		String queryprepareArrayToCSV=prepareArrayToCSV(columns);
		String groupQuery = "GROUP BY SOURCE."+emailColumn+", ADDRESS.ADDRESS_ID ";
		
		if(type==1){
			if(dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase("AUDIENCE_EMAIL")){
				query="INSERT /*+ DIRECT */ INTO "+processTableName+"("+queryprepareArrayToCSV+") SELECT COALESCE(ADDRESS.ADDRESS_ID, NEXTVAL('FORGEIDSEQUENCE')),SOURCE."+emailColumn+",SUBSTRING(SOURCE."+emailColumn+", STRPOS(SOURCE."+emailColumn+", '@') + 1),CASE WHEN ADDRESS.ADDRESS_ID IS NULL THEN TRUE ELSE FALSE END FROM "+dataImportDTO.getTempTableName()+" SOURCE LEFT OUTER JOIN "
						+ "(select address_id,EMAIL_ADDRESS from ADDRESS_EMAIL  where EMAIL_ADDRESS in ( select email_address from "+dataImportDTO.getTempTableName()+")) ADDRESS "
						+ "ON SOURCE."+emailColumn+" = ADDRESS.EMAIL_ADDRESS LEFT OUTER JOIN "+processTableName+" PROCESSING  ON SOURCE."+emailColumn+" = PROCESSING.EMAIL_ADDRESS WHERE PROCESSING.EMAIL_ADDRESS IS NULL AND SOURCE."+emailColumn+" <> '' ";
			}else{
				query="INSERT /*+ DIRECT */ INTO "+processTableName+"("+queryprepareArrayToCSV+") SELECT COALESCE(ADDRESS.ADDRESS_ID, NEXTVAL('FORGEIDSEQUENCE')),SOURCE."+emailColumn+",SUBSTRING(SOURCE."+emailColumn+", STRPOS(SOURCE."+emailColumn+", '@') + 1),CASE WHEN ADDRESS.ADDRESS_ID IS NULL THEN TRUE ELSE FALSE END FROM "+dataImportDTO.getTempTableName()+" SOURCE LEFT OUTER JOIN ADDRESS_EMAIL ADDRESS ON SOURCE."+emailColumn+" = ADDRESS.EMAIL_ADDRESS LEFT OUTER JOIN "+processTableName+" PROCESSING  ON SOURCE."+emailColumn+" = PROCESSING.EMAIL_ADDRESS WHERE PROCESSING.EMAIL_ADDRESS IS NULL AND SOURCE."+emailColumn+" <> '' ";
			}
			if(dataImportDTO.getIsInvalidRecordsExist()){
				query = query +" AND SOURCE.ISVALID <> 'F' AND SOURCE.ISVALID <> 'E' ";
			}
			query = query + groupQuery;
		}else{
			query="INSERT /*+ DIRECT */ INTO "+processTableName+"("+queryprepareArrayToCSV+") SELECT COALESCE(ADDRESS.ADDRESS_ID, NEXTVAL('FORGEIDSEQUENCE')),SOURCE."+emailColumn+",CASE WHEN ADDRESS.ADDRESS_ID IS NULL THEN TRUE ELSE FALSE END FROM "+dataImportDTO.getTempTableName()+" SOURCE LEFT OUTER JOIN ADDRESS_SMS ADDRESS ON SOURCE."+emailColumn+" = ADDRESS.SMS_NUMBER LEFT OUTER JOIN "+processTableName+" PROCESSING ON SOURCE."+emailColumn+" = PROCESSING.SMS_NUMBER WHERE PROCESSING.SMS_NUMBER IS NULL AND SOURCE."+emailColumn+" <> '' ";
			if(dataImportDTO.getIsInvalidRecordsExist()){
				query = query +" AND SOURCE.ISVALID <> 'F' AND SOURCE.ISVALID <> 'S' ";
			}
			query = query + groupQuery;
		}
		logger.debug("End : "+getClass().getName()+" : prepareProcessQuery(Column column, int type, String emailColumn, DataImportDTO dataImportDTO, String processTableName,List<Column> columns)");
		return query;
	
		
	}
	
	/**
	 * Method Name 	: prepareSelectQueryWithDefaultValues
	 * Description 	: The Method "prepareSelectQueryWithDefaultValues" is used for 
	 * Date    		: Sep 30, 2016, 7:43:21 PM
	 * @param dataImportDTO
	 * @param defaultValuesMap
	 * @return
	 * @param  		:
	 * @return 		: Map<String,String>
	 * @throws 		:
	 */
	public Map<String ,String> prepareSelectQueryWithDefaultValues(DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap)
	{		
		logger.debug("Begin : "+getClass().getName()+" : prepareSelectQueryWithDefaultValues(DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap)");
		String returnQuery = "";		
		HashMap<String, String> DBColumnDefaultValues=defaultValuesMap;
		String defaultValue ;
		int i=0;
		String insertQuery="";
		Map<String ,String> queryMap=new HashMap<String,String>();
		if(!(dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_EMAIL") || dataImportDTO.getBaseTablePhysicalName().equals("AUDIENCE_SMS"))){
			for(;i<dataImportDTO.getColumns().size();i++){
				Column hubListMapping=dataImportDTO.getColumns().get(i);
				insertQuery+=hubListMapping.getColumnName()+",";
				if( hubListMapping.getDefaultValue()!=null && hubListMapping.getDefaultValue().trim().length()!=0 )
				{
					defaultValue = hubListMapping.getDefaultValue();	
					defaultValue=defaultValue.replaceAll("^\"|\"$","");
					defaultValue=defaultValue.replaceAll("^\'|\'$","");
					String str="";
					if( hubListMapping.getDataType().equalsIgnoreCase("BIGINT")  || hubListMapping.getDataType().equalsIgnoreCase("DATE")     || 
						hubListMapping.getDataType().equalsIgnoreCase("TIME")    || hubListMapping.getDataType().equalsIgnoreCase("BOOLEAN")  || 
						hubListMapping.getDataType().equalsIgnoreCase("DECIMAL") || hubListMapping.getDataType().equalsIgnoreCase("DOUBLE")   || 
						hubListMapping.getDataType().equalsIgnoreCase("TIMESTAMP"))
					{
						str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL ) THEN '"+defaultValue+"' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";	
					}
					else{						
						str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL OR "+hubListMapping.getColumnName()+"='') THEN '"+defaultValue+"' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
					}
					returnQuery+=str;
				}else{
					  if(null != DBColumnDefaultValues.get(hubListMapping.getColumnName()) && DBColumnDefaultValues.containsKey(hubListMapping.getColumnName())){
						    String str="";
						    if(hubListMapping.getDataType().equalsIgnoreCase("BIGINT")   || hubListMapping.getDataType().equalsIgnoreCase("DATE")     || 
							   hubListMapping.getDataType().equalsIgnoreCase("TIME")    || hubListMapping.getDataType().equalsIgnoreCase("BOOLEAN")  || 
							   hubListMapping.getDataType().equalsIgnoreCase("DECIMAL") || hubListMapping.getDataType().equalsIgnoreCase("DOUBLE")   || 
							   hubListMapping.getDataType().equalsIgnoreCase("TIMESTAMP"))
							{
								if(DBColumnDefaultValues.get(hubListMapping.getColumnName()).equals("''")){
									str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL ) THEN '' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
								}else{
									defaultValue = DBColumnDefaultValues.get(hubListMapping.getColumnName());
									defaultValue=defaultValue.replaceAll("^\"|\"$","");
									defaultValue=defaultValue.replaceAll("^\'|\'$","");
									str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL ) THEN '"+defaultValue+"' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
								}
							}
							else{
								if(DBColumnDefaultValues.get(hubListMapping.getColumnName()).equals("''")){
									str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL OR "+hubListMapping.getColumnName()+"='') THEN '' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
								}else{
									defaultValue = DBColumnDefaultValues.get(hubListMapping.getColumnName());
									defaultValue=defaultValue.replaceAll("^\"|\"$","");
									defaultValue=defaultValue.replaceAll("^\'|\'$","");									
									str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL OR "+hubListMapping.getColumnName()+"='') THEN '"+defaultValue+"' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
								}
							}
						    returnQuery+=str;
						 
					 }else{
						 returnQuery+=hubListMapping.getColumnName()+",";
					 }
				}				
			}
		}else{
			for(;i<dataImportDTO.getColumns().size();i++){
				Column hubListMapping=dataImportDTO.getColumns().get(i);
				insertQuery+=hubListMapping.getColumnName()+",";
				if(hubListMapping.getDefaultValue()!=null && !(hubListMapping.getDataType().equals(EMAIL_DATATYPE) || hubListMapping.getDataType().equals(SMS_DATATYPE)))
				{
					defaultValue=hubListMapping.getDefaultValue();
					defaultValue=defaultValue.replaceAll("^\"|\"$","");
					defaultValue=defaultValue.replaceAll("^\'|\'$","");
					String str="(CASE  WHEN ("+hubListMapping.getColumnName()+" IS NULL OR "+hubListMapping.getColumnName()+"='') THEN '"+defaultValue+"' ELSE "+hubListMapping.getColumnName()+" END) AS "+hubListMapping.getColumnName()+",";
					returnQuery+=str;
				}else{
					returnQuery+=hubListMapping.getColumnName()+",";
				}				
			}
		}
		/*returnQuery+=dataImportDTO.getColumns().get(i).getColumnName();
		insertQuery+=dataImportDTO.getColumns().get(i).getColumnName();*/
		returnQuery = returnQuery.replaceAll(",$", "");
		insertQuery = insertQuery.replaceAll(",$", "");

		if(dataImportDTO.getAudienceId() > 0 || dataImportDTO.getImportType().equals("RESUB") || dataImportDTO.getImportType().equals("UNSUB")){
			returnQuery+=",AUDIENCE_MEMBER_ID_2";
			if(insertQuery.endsWith(","))
				insertQuery+="AUDIENCE_MEMBER_ID_2";
			else
				insertQuery+=",AUDIENCE_MEMBER_ID_2";
		}
		if(dataImportDTO.getIsInvalidRecordsExist()){
			returnQuery+=",ISVALID";
			if(insertQuery.endsWith(","))
				insertQuery+="ISVALID";
			else
				insertQuery+=",ISVALID";
		}
		queryMap.put("insertQuery", insertQuery);
		queryMap.put("defaultValues", returnQuery);
		logger.debug("End : "+getClass().getName()+" : prepareSelectQueryWithDefaultValues(DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap)");
		return queryMap;
	}
	public  boolean checkAudienceMemeberId(String[] arr){
		logger.debug("Begin : "+getClass().getName()+" : checkAudienceMemeberId(String[] arr)");
        boolean isExistAudienceMemberId=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(AUDIENCE_MEMBER_ID) )){
        		isExistAudienceMemberId=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkAudienceMemeberId(String[] arr)");
        return isExistAudienceMemberId;
    }
 
    public  boolean checkAudienceTypeId(String[] arr){
    	logger.debug("Begin : "+getClass().getName()+" : checkAudienceTypeId(String[] arr)");
        boolean isExistAudienceTypeId=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(AUDIENCE_TYPE_ID) )){
        		isExistAudienceTypeId=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkAudienceTypeId(String[] arr)");
        return isExistAudienceTypeId;
    } 
    public  boolean checkBatchId(String[] arr){
    	logger.debug("Begin : "+getClass().getName()+" : checkBatchId(String[] arr)");
        boolean isExistBatchId=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(BATCH_ID) )){
        		isExistBatchId=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkBatchId(String[] arr)");
        return isExistBatchId;
    }
    public  boolean checkSrcFileId(String[] arr){
    	logger.debug("Begin : "+getClass().getName()+" : checkSrcFileId(String[] arr)");
        boolean isExistSrcFileId=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(SRC_FILE_ID) )){
        		isExistSrcFileId=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkSrcFileId(String[] arr)");
        return isExistSrcFileId;
    }
    public  boolean checkCreationDT(String[] arr){
    	logger.debug("Begin : "+getClass().getName()+" : checkCreationDT(String[] arr)");
        boolean isExistCreationDT=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(CREATION_DT) )){
        		isExistCreationDT=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkCreationDT(String[] arr)");
        return isExistCreationDT;
    }
    public  boolean checkModifiedDT(String[] arr){
    	logger.debug("Begin : "+getClass().getName()+" : checkModifiedDT(String[] arr)");
        boolean isExistModifiedDT=false;
        final int len = arr.length;
        for(int i = 0; i < len; i++){
        	if((arr[i].equalsIgnoreCase(MODIFIED_DT) )){
        		isExistModifiedDT=true;
        		break;
        	}
        }
        logger.debug("End : "+getClass().getName()+" : checkModifiedDT(String[] arr)");
        return isExistModifiedDT;
    }

	/**
	 * 
	 * Method Name 	: prepareInsertNonAudienceTableQuery
	 * Description 	: The Method "prepareInsertNonAudienceTableQuery" is used for 
	 * Date    		: Oct 15, 2016, 5:57:53 PM
	 * @param dataImportDTO
	 * @param isAudienceMemberIdExist
	 * @param isAudienceTypeIdExist
	 * @param isBatchIdExist
	 * @param isSrcFileIdExist
	 * @param isCreattionDTExist
	 * @param isModifiedDTExist
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	public String prepareInsertNonAudienceTableQuery(DataImportDTO dataImportDTO, boolean isAudienceMemberIdExist,
			boolean isAudienceTypeIdExist, boolean isBatchIdExist, boolean isSrcFileIdExist, boolean isCreattionDTExist,
			boolean isModifiedDTExist) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" :  prepareInsertNonAudienceTableQuery(DataImportDTO dataImportDTO, boolean isAudienceMemberIdExist,boolean isAudienceTypeIdExist, boolean isBatchIdExist, boolean isSrcFileIdExist, boolean isCreattionDTExist,boolean isModifiedDTExist)");
		
		StringBuilder sb = null;
		StringBuilder data=null;
		List<Column> columns = dataImportDTO.getColumns();
		
		String column="";
		String query=null;
		String tempTableName=null;
		try {
			/*
			 Different boolean support
			*/
			tempTableName=dataImportDTO.getTempTableName();

					sb=new StringBuilder();
					data=new StringBuilder();
					sb.append("INSERT /*+ DIRECT */ INTO "+dataImportDTO.getBaseTablePhysicalName());
					sb.append(" (");
					for(int i=0; i<columns.size(); i++) {
						Column columnObj = columns.get(i);
						if(columnObj.getColumnName()!=null) {
							sb.append(columnObj.getColumnName());
							if(i<columns.size()-1)
								sb.append(",");
						}
					}
					if(sb.charAt(sb.length()-1)==','){
						sb.replace(sb.length()-1, sb.length(), "");
					}
					if(isAudienceMemberIdExist){
						sb.append(",AUDIENCE_MEMBER_ID");
						data.append(",-1");
					}
					if(isAudienceTypeIdExist){
						sb.append(",AUDIENCE_TYPE_ID");
						data.append(",0");
					}
					if(isCreattionDTExist){
						sb.append(",CREATION_DT");
						data.append(",NOW()");
					}
					if(isModifiedDTExist){
						sb.append(",MODIFIED_DT");
						data.append(",NOW()");
					}
					if(isBatchIdExist){
						sb.append(",BATCH_ID");
					}
					if(isSrcFileIdExist){
						sb.append(",SRC_FILE_ID");
					}
					sb.append(") SELECT ");
					for(int i=0; i<columns.size(); i++) {
						Column columnObj = columns.get(i);
						if(columnObj.getColumnName()!=null ) {
							
							if(columnObj.getDefaultValue()!=null){
								if( (columnObj.getDefaultValue()!= null && columnObj.getDefaultValue().length()!=0 ) ){
									column="IsNull("+columnObj.getColumnName()+",'"+columnObj.getDefaultValue()+"') AS "+columnObj.getColumnName();
									 
								}else{
									column=columnObj.getColumnName();
								}
							}else{
								column=columnObj.getColumnName();
							}
							sb.append(column);
							if(i<columns.size()-1)
								sb.append(",");
						}
					}
					if(sb.charAt(sb.length()-1)==','){
						sb.replace(sb.length()-1, sb.length(), "");
					}
					if(data!=null && data.length()!=0){
						sb.append(data);
					}
					sb.append(",BATCH_ID");
					sb.append(",SRC_FILE_ID");
					sb.append(" FROM "+tempTableName+" ");
					logger.info("query is " + sb);
					query=sb.toString();
					logger.debug("End : "+getClass().getName()+" :  prepareInsertNonAudienceTableQuery(DataImportDTO dataImportDTO, boolean isAudienceMemberIdExist,boolean isAudienceTypeIdExist, boolean isBatchIdExist, boolean isSrcFileIdExist, boolean isCreattionDTExist,boolean isModifiedDTExist)");
					return query;
		} catch(Exception ebe) {
			logger.error(ebe.getMessage(),ebe);
			throw new DataImportException(ebe.getMessage(), ebe);
		}
	
    
	}
	/**
	 * 
	 * 
	 * Method Name 	: getCreateTableQuery
	 * Description 	: The Method "getCreateTableQuery" is used for 
	 * Date    		: Oct 20, 2016, 5:42:46 PM
	 * @param col
	 * @param tableName
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getCreateTableQuery(String col,String tableName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getCreateTableQuery(String col,String tableName)");
		String tableQuery=null;
		String columnName=getColumnName(col);
		tableQuery=" CREATE TABLE "+tableName +" ("+columnName+ " CHARACTER VARYING(400) ENCODING AUTO,AUDIENCE_MEM_ID BIGINT ,IS_NEW BOOLEAN ENCODING BLOCK_DICT) ORDER BY "+columnName+" SEGMENTED BY HASH ("+columnName+") ALL NODES " ;
		logger.debug("End : "+getClass().getName()+" : getCreateTableQuery(String col,String tableName)");
		return tableQuery;
	}
	/**
	 * 
	 * 
	 * Method Name 	: getColumnName
	 * Description 	: The Method "getColumnName" is used for 
	 * Date    		: Oct 20, 2016, 5:42:41 PM
	 * @param col
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: String
	 * @throws 		:
	 */
	public String getColumnName(String col) throws DataImportException{
		String VERTICA_EMAIL_IMPORT ="EMAIL_ADDRESS";
		String VERTICA_SMS_IMPORT ="SMS_NUMBER";
		if (col != null && !col.isEmpty()) {
			if (VERTICA_SMS_IMPORT.equalsIgnoreCase(col)) {
				return VERTICA_SMS_IMPORT;
			}
		} else{
			throw new DataImportException("FTP005",null,Level.ERROR);
		}
		return VERTICA_EMAIL_IMPORT;
	}
}

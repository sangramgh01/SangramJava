/**
 * DataImportDaoImpl.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.FileSchedule;
import com.zetainteractive.zetahub.commons.domain.Trigger;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.dao.DataImportDao;
import com.zetainteractive.zetahub.de.dataimport.dao.DataImportQueryBuilder;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimport.rowmapper.TriggerMapper;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:20:55 PM
 * @Version	   : 1.7
 * @Description: "DataImportDaoImpl" is used for 
 * 
 *
 */
@Component
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS)
public class DataImportDaoImpl implements DataImportDao {
	
	public static final String AUDIENCE_MEMBER_ID="AUDIENCE_MEMBER_ID";
	public static final String ADDRESS_ID="ADDRESS_ID";
	
	@Autowired
	@Qualifier("whJdbcTemplate")
	JdbcTemplate jdbcTemplate;
	
	
	@Autowired
	@Qualifier("JdbcTemplate")
	JdbcTemplate custJdbcTemplate;
	
	private ZetaLogger logger = new ZetaLogger(this.getClass());
	private DataImportQueryBuilder dataImportQueryBuilder = new DataImportQueryBuilder();
	/**
	 * Method Name 	: getTableCount
	 * Description 		: The Method "getTableCount" is used for 
	 * Date    			: Sep 29, 2016, 8:29:48 PM
	 * @param query
	 * @throws SQLException
	 */
	@Override
	public long getTableCount(String query) throws SQLException{
		return jdbcTemplate.queryForObject(query,Long.class);
	}

	/**
	 * Method Name 	: executeUpdateQuery
	 * Description 		: The Method "executeUpdateQuery" is used for 
	 * Date    			: Sep 29, 2016, 8:30:01 PM
	 * @param updateQuery
	 * @throws SQLException
	 */
	
	@Override
	public int executeUpdateQuery(String updateQuery) throws SQLException{
		return jdbcTemplate.update(updateQuery);
	}

	/**
	 * Method Name 	: executeDeleteQuery
	 * Description 		: The Method "executeDeleteQuery" is used for 
	 * Date    			: Sep 29, 2016, 8:30:11 PM
	 * @param query
	 * @throws SQLException
	 */
	
	@Override
	public boolean executeDeleteQuery(String query) throws SQLException{
		int result =  jdbcTemplate.update(query);
		return result>0;
	}

	/**
	 * Method Name 	: executeInsert
	 * Description 		: The Method "executeInsert" is used for 
	 * Date    			: Sep 29, 2016, 8:30:20 PM
	 * @param query
	 * @throws SQLException
	 */
	
	@Override
	public int executeInsert(String query) throws SQLException{
		return jdbcTemplate.update(query);
	}

	/**
	 * Method Name 	: executeDDL
	 * Description 		: The Method "executeDDL" is used for 
	 * Date    			: Sep 29, 2016, 8:30:30 PM
	 * @param query
	 * @throws SQLException
	 */
	
	@Override
	public boolean executeDDL(String query) throws SQLException{
		jdbcTemplate.execute(query);
		return true;
	}

	/**
	 * Method Name 	: getTableColumnsInfo
	 * Description 		: The Method "getTableColumnsInfo" is used for 
	 * Date    			: Sep 29, 2016, 8:30:39 PM
	 * @param query
	 * @throws SQLException
	 */
	
	@Override
	public List<String> getTableColumnsInfo(String query) throws SQLException{
		List<String> columns = (List<String>) jdbcTemplate.queryForList(query, String.class);
		return columns;
	}

	/**
	 * Method Name 	: executeEMAILQueries
	 * Description 		: The Method "executeEMAILQueries" is used for 
	 * Date    			: Sep 28, 2016, 8:31:18 PM
	 * @param column
	 * @param dataImportDTO
	 * @param emailColumn
	 * @param audTypeIdEmail
	 * @throws SQLException 
	 */
	
	@Override
	public void executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processTableName) throws SQLException {
		    logger.debug("Begin : "+getClass().getName()+" : executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processTableName)");
			String query;
			long listId = dataImportDTO.getListid();
			
			query="INSERT /*+ DIRECT */ INTO  s_d_email_domain(EMAIL_DOMAIN_ID,EMAIL_DOMAIN_NAME,creation_dt,modified_dt) SELECT NEXTVAL('FORGEIDSEQUENCE'),PROCESSING.DOMAIN AS PROCESSING_DOMAIN,now(),now() FROM "+processTableName+" PROCESSING LEFT OUTER JOIN s_d_email_domain DOMAINS ON PROCESSING.DOMAIN = DOMAINS.EMAIL_DOMAIN_NAME WHERE DOMAINS.EMAIL_DOMAIN_NAME IS NULL GROUP BY PROCESSING_DOMAIN";		
			
			logger.debug("List Id:: " +listId+"  prepareInsertNewDomainQuery::"+query);			
			jdbcTemplate.update(query);
			
			query="INSERT /*+ DIRECT */  INTO ADDRESS(ADDRESS_ID,CHANNEL_TYPE_ID,COUNTRY_ID,IMPLICIT_OPTIN_IND,EXPLICIT_OPTIN_IND,EXPLICIT_OPTIN_DT,OPERATIONAL_OPTOUT_IND,INVALID_ADDRESS_IND,UNDELIVERABLE_IND,MOB_OPTIN,CREATION_DT,MODIFIED_DT) SELECT ADDRESSID,1,0,False,True,NOW(),False,False,False,False,NOW(),NOW() FROM   "+processTableName+" WHERE  ISNEW_2 = TRUE";
			
			logger.debug("List Id:: " +listId+"  prepareInsertNewAddressQuery::"+query);
			jdbcTemplate.update(query);
			
			query="INSERT /*+ DIRECT */ INTO ADDRESS_EMAIL(ADDRESS_ID,CHANNEL_TYPE_ID,EMAIL_ADDRESS,EMAIL_DOMAIN_ID,CREATION_DT,MODIFIED_DT) SELECT PROCESSING.ADDRESSID,1,PROCESSING.EMAIL_ADDRESS,DOMAINS.EMAIL_DOMAIN_ID,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN s_d_email_domain DOMAINS ON PROCESSING.DOMAIN = DOMAINS.EMAIL_DOMAIN_NAME WHERE PROCESSING.ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareInsertNewEmailAddressQuery::"+query);
			jdbcTemplate.update(query);
			
			query="INSERT /*+ DIRECT */ INTO  TARGET(TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_ID,ADDRESS_CATEGORY_ID,AUDIENCE_MEMBER_ID ,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT   NEXTVAL('FORGEIDSEQUENCE'),1 AS CHANNEL_TYPE_ID,P.ADDRESSID,"+column.getCategoryType()+" AS ADDRESS_CATEGORY_ID,NEXTVAL('FORGEIDSEQUENCE'),"+audTypeIdEmail+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P WHERE P.ISNEW_2 = TRUE";	
			logger.debug("List Id:: " +listId+"  prepareInsertNewTargetExportQuery::"+query);
			jdbcTemplate.update(query);
	
			query="INSERT  /*+ DIRECT */ INTO TARGET (TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE') AS NEW_TARGET_ID,5 AS CHANNEL_TYPE_ID,125 AS ADDRESS_CATEGORY_ID,5 AS ADDRESS_ID,T.AUDIENCE_MEMBER_ID,"+audTypeIdEmail+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P INNER JOIN target T ON P.ADDRESSID = T.ADDRESS_ID WHERE P.ISNEW_2 = TRUE AND T.AUDIENCE_TYPE_ID = "+audTypeIdEmail+" AND T.CHANNEL_TYPE_ID = 1 AND T.ADDRESS_CATEGORY_ID  = "+column.getCategoryType();	
			logger.debug("List Id:: " +listId+"  prepareInsertNewTargetExportQuery2::"+query);
			jdbcTemplate.update(query);
	
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_MEMBER(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audTypeIdEmail+",NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audTypeIdEmail+" AND target.CHANNEL_TYPE_ID = 1 AND target.ADDRESS_CATEGORY_ID = "+column.getCategoryType()+" AND PROCESSING.ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareNewEmailAudienceMember::"+query);
			jdbcTemplate.update(query);
	
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_EMAIL(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,EMAIL_ADDRESS,EMAIL_DOMAIN_NAME,ACTIVE_IND,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audTypeIdEmail+",EMAIL.EMAIL_ADDRESS,DOMAIN.EMAIL_DOMAIN_NAME,True,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID INNER JOIN address ON address.ADDRESS_ID = target.ADDRESS_ID INNER JOIN address_email EMAIL ON address.ADDRESS_ID = EMAIL.ADDRESS_ID INNER JOIN s_d_email_domain DOMAIN ON DOMAIN.EMAIL_DOMAIN_ID = EMAIL.EMAIL_DOMAIN_ID WHERE target.AUDIENCE_TYPE_ID = "+audTypeIdEmail+" AND target.CHANNEL_TYPE_ID = 1 AND target.ADDRESS_CATEGORY_ID = "+column.getCategoryType()+" AND PROCESSING.ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareNewEmailAudience::"+query);
			jdbcTemplate.update(query);
			
			if(column.getCategoryType() != 1){
					query="INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),"+column.getCategoryType()+",ADDRESS_EMAIL.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",1,TRUE,NOW(),'1/1/1900' FROM "+dataImportDTO.getTempTableName()+" STAGING INNER JOIN ADDRESS_EMAIL ON STAGING."+emailColumn+" = ADDRESS_EMAIL.EMAIL_ADDRESS LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = "+column.getCategoryType()+" AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";		
					logger.debug("List Id:: " +listId+"  prepareInsertTargetAudienceMembersToAddresses_default::"+query);
					jdbcTemplate.update(query);
												
					query="INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),1,ADDRESS_EMAIL.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",1,TRUE,NOW(),'1/1/1900' FROM "+dataImportDTO.getTempTableName()+" STAGING INNER JOIN ADDRESS_EMAIL ON STAGING."+emailColumn+" = ADDRESS_EMAIL.EMAIL_ADDRESS LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 1 AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";		
					logger.debug("List Id:: " +listId+"  prepareInsertTargetAudienceMembersToAddresses_default::"+query);
					jdbcTemplate.update(query);
			}							
			query="UPDATE /*+ DIRECT */ TARGET SET ACTIVE_IND = FALSE,INACTIVE_DT = NOW() FROM "+dataImportDTO.getTempTableName()+" STAGING WHERE TARGET.AUDIENCE_MEMBER_ID= STAGING.AUDIENCE_MEMBER_ID_2 AND TARGET.ADDRESS_CATEGORY_ID = "+column.getCategoryType()+" AND TARGET.ACTIVE_IND = TRUE AND TARGET.CHANNEL_TYPE_ID= 1 AND STAGING."+emailColumn+" = ''";		
			logger.debug("List Id:: " +listId+"  prepareSetTargetInactive::"+query);
			jdbcTemplate.update(query);	
			 logger.debug("End : "+getClass().getName()+" : executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processTableName)");
	}
	
	@Override
	public void executeDefaultEntriesForInvalidEmail(DataImportDTO dataImportDTO) throws SQLException{
		logger.debug("Begin : "+getClass().getName()+" : executeDefaultEntriesForInvalidEmail(DataImportDTO dataImportDTO)");
		String query=null;
		long listId = dataImportDTO.getListid();
		String invalidDataCountQuery = "SELECT COUNT(*) FROM "+dataImportDTO.getTempTableName()+" WHERE ISNEW_2='TRUE' AND ISVALID IN('E','F')";
		long count = getTableCount(invalidDataCountQuery);
		if(count > 0){
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,2,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",2,TRUE,NOW(),'1/1/1900' FROM "+dataImportDTO.getTempTableName()+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=2 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID IN ('F','E') AND TARGET.TARGET_ID IS NULL";
			logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Direct mail::"+query);
			jdbcTemplate.update(query);
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,4,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",4,TRUE,NOW(),'1/1/1900' FROM "+dataImportDTO.getTempTableName()+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=4 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID IN ('F','E') AND TARGET.TARGET_ID IS NULL";
			logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Call center::"+query);
			jdbcTemplate.update(query);
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,5,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",5,TRUE,NOW(),'1/1/1900' FROM "+dataImportDTO.getTempTableName()+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=5 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID IN ('F','E') AND TARGET.TARGET_ID IS NULL";
			logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Export::"+query);
			jdbcTemplate.update(query);
		}
		logger.debug("End : "+getClass().getName()+" : executeDefaultEntriesForInvalidEmail(DataImportDTO dataImportDTO)");
	}

	/**
	 * 
	 * Method Name 	: executeSMSQueries
	 * Description 		: The Method "executeSMSQueries" is used for 
	 * Date    			: Sep 29, 2016, 1:32:55 PM
	 * @param column
	 * @param dataImportDTO
	 * @param smsColumn
	 * @param audTypeIdSMS
	 * @param processTableName
	 * @throws SQLException 
	 */
	
	@Override
	public void executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName) throws SQLException {
		    logger.debug("Begin : "+getClass().getName()+" : executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName)");
			String query;
			long listId = dataImportDTO.getListid();
			String tempTableName = dataImportDTO.getTempTableName();
			long categoryId = column.getCategoryType();
			query="INSERT /*+ DIRECT */ INTO ADDRESS(ADDRESS_ID,CHANNEL_TYPE_ID,COUNTRY_ID,IMPLICIT_OPTIN_IND,EXPLICIT_OPTIN_IND,EXPLICIT_OPTIN_DT,OPERATIONAL_OPTOUT_IND,INVALID_ADDRESS_IND,UNDELIVERABLE_IND,MOB_OPTIN,CREATION_DT,MODIFIED_DT) SELECT ADDRESSID,3,0,False,True,NOW(),False,False,False,True,NOW(),NOW() FROM   "+processTableName+" WHERE  ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareInsertNewAddressQuery::"+query);
			jdbcTemplate.update(query);	
			
			query="INSERT /*+ DIRECT */ INTO ADDRESS_SMS(ADDRESS_ID,CHANNEL_TYPE_ID,SMS_NUMBER,CREATION_DT,MODIFIED_DT) SELECT PROCESSING.ADDRESSID,3,PROCESSING.SMS_NUMBER,NOW(),NOW() FROM "+processTableName+" PROCESSING WHERE PROCESSING.ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareInsertNewEmailAddressQuery::"+query);
			jdbcTemplate.update(query);	
			
			query="INSERT /*+ DIRECT */ INTO  TARGET(TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_ID,ADDRESS_CATEGORY_ID,AUDIENCE_MEMBER_ID ,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT   NEXTVAL('FORGEIDSEQUENCE'),3 AS CHANNEL_TYPE_ID,P.ADDRESSID,"+categoryId+" AS ADDRESS_CATEGORY_ID,NEXTVAL('FORGEIDSEQUENCE'),"+audTypeIdSMS+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P WHERE P.ISNEW_2 = TRUE";		
			logger.debug("List Id:: " +listId+"  prepareInsertNewTargetExportQuery::"+query);
			jdbcTemplate.update(query);	
			
			query="INSERT  /*+ DIRECT */ INTO TARGET (TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE') AS NEW_TARGET_ID,5 AS CHANNEL_TYPE_ID,125 AS ADDRESS_CATEGORY_ID,5 AS ADDRESS_ID,T.AUDIENCE_MEMBER_ID,"+audTypeIdSMS+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P INNER JOIN target T ON P.ADDRESSID = T.ADDRESS_ID WHERE P.ISNEW_2 = TRUE AND T.AUDIENCE_TYPE_ID = "+audTypeIdSMS+" AND T.CHANNEL_TYPE_ID = 3 AND T.ADDRESS_CATEGORY_ID  = "+categoryId;		
			logger.debug("List Id:: " +listId+"  prepareInsertNewTargetExportQuery2::"+query);
			jdbcTemplate.update(query);
			
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_MEMBER(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audTypeIdSMS+",NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audTypeIdSMS+" AND target.CHANNEL_TYPE_ID = 3 AND target.ADDRESS_CATEGORY_ID = "+categoryId+" AND PROCESSING.ISNEW_2 = TRUE";	
			logger.debug("List Id:: " +listId+"  prepareNewEmailAudienceMember::"+query);
			jdbcTemplate.update(query);	

			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_SMS(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,SMS_NUMBER,ACTIVE_IND,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audTypeIdSMS+",SMS.SMS_NUMBER,True,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID INNER JOIN address ON address.ADDRESS_ID = target.ADDRESS_ID INNER JOIN address_sms SMS ON address.ADDRESS_ID = SMS.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audTypeIdSMS+" AND target.CHANNEL_TYPE_ID = 3 AND target.ADDRESS_CATEGORY_ID = "+column.getCategoryType()+" AND PROCESSING.ISNEW_2 = TRUE";
			logger.debug("List Id:: " +listId+"  prepareNewEmailAudience::"+query);
			jdbcTemplate.update(query);
			
			
			if(categoryId != 1){
				logger.debug("List Id:: " +listId+" prepareInsertTargetAudienceMembersToAddresses_default SMS for ADDRESS_CATEGORY_ID: "+categoryId);
				query="INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),"+categoryId+",ADDRESS_SMS.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",3,TRUE,NOW(),'1/1/1900' FROM "+tempTableName+" STAGING INNER JOIN ADDRESS_SMS ON STAGING."+smsColumn+" = ADDRESS_SMS.SMS_NUMBER LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = "+categoryId+" AND TARGET.CHANNEL_TYPE_ID=3  AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";		
				logger.debug("List Id:: " +listId+"  prepareInsertTargetAudienceMembersToAddresses_default::"+query);
				jdbcTemplate.update(query);	
				
				logger.debug("List Id:: " +listId+" prepareInsertTargetAudienceMembersToAddresses_default SMS for ADDRESS_CATEGORY_ID: 1 ");
				query="INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),1,ADDRESS_SMS.ADDRESS_ID,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",3,TRUE,NOW(),'1/1/1900' FROM "+tempTableName+" STAGING INNER JOIN ADDRESS_SMS ON STAGING."+smsColumn+" = ADDRESS_SMS.SMS_NUMBER LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 1 AND TARGET.CHANNEL_TYPE_ID=3  AND TARGET.ACTIVE_IND = TRUE WHERE TARGET.TARGET_ID IS NULL";		
				logger.debug("List Id:: " +listId+"  prepareInsertTargetAudienceMembersToAddresses_default::"+query);
				jdbcTemplate.update(query);	
			}
			query="UPDATE /*+ DIRECT */ TARGET SET ACTIVE_IND = FALSE,INACTIVE_DT = NOW() FROM "+tempTableName+" STAGING WHERE TARGET.AUDIENCE_MEMBER_ID= STAGING.AUDIENCE_MEMBER_ID_2 AND TARGET.ADDRESS_CATEGORY_ID = "+categoryId+" AND TARGET.ACTIVE_IND = TRUE AND TARGET.CHANNEL_TYPE_ID= 3 AND STAGING."+smsColumn+" = ''";
			logger.debug("List Id:: " +listId+"  prepareSetTargetInactive::"+query);
			jdbcTemplate.update(query);	
			logger.debug("End : "+getClass().getName()+" : executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName)");					
		
		
		
	}
	@Override
	public void executeDefaultEntriesForInvalidSms(DataImportDTO dataImportDTO) throws SQLException{
		logger.debug("Begin : "+getClass().getName()+" : executeDefaultEntriesForInvalidSms(DataImportDTO dataImportDTO)");
		String query=null;
		long listId = dataImportDTO.getListid();
		String tempTableName = dataImportDTO.getTempTableName();
		String invalidDataCountQuery = "SELECT COUNT(*) FROM "+tempTableName+" WHERE ISNEW_2='TRUE' AND ISVALID IN('S')";
		long count = getTableCount(invalidDataCountQuery);
		if(count > 0){
			query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,2,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",2,TRUE,NOW(),'1/1/1900' FROM "+tempTableName+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=2 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID = 'S' AND TARGET.TARGET_ID IS NULL";
				logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Direct mail::"+query);
				jdbcTemplate.update(query);
				query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,4,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",4,TRUE,NOW(),'1/1/1900' FROM "+tempTableName+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=4 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID = 'S' AND TARGET.TARGET_ID IS NULL";
				logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Call center::"+query);
				jdbcTemplate.update(query);
				query = "INSERT /*+ DIRECT */ INTO TARGET(TARGET_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CHANNEL_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE'),125,5,STAGING.AUDIENCE_MEMBER_ID_2,"+dataImportDTO.getAudienceId()+",5,TRUE,NOW(),'1/1/1900' FROM "+tempTableName+" STAGING LEFT OUTER JOIN TARGET ON STAGING.AUDIENCE_MEMBER_ID_2 = TARGET.AUDIENCE_MEMBER_ID AND TARGET.ADDRESS_CATEGORY_ID   = 125 AND TARGET.CHANNEL_TYPE_ID=5 AND TARGET.AUDIENCE_TYPE_ID="+dataImportDTO.getAudienceId()+" WHERE STAGING.ISNEW_2='TRUE' AND STAGING.ISVALID = 'S' AND TARGET.TARGET_ID IS NULL";
				logger.debug("List Id:: " +listId+"  prepareTargetInsertsForInvalidData Export::"+query);
				jdbcTemplate.update(query);
		}
		logger.debug("End : "+getClass().getName()+" : executeDefaultEntriesForInvalidSms(DataImportDTO dataImportDTO)");
	}

	/**
	 * 
	 * Method Name 	: dropTempTables
	 * Description 		: The Method "dropTempTables" is used for 
	 * Date    			: Sep 29, 2016, 3:10:40 PM
	 * @param tempTableName
	 * @param smsProcessTable
	 * @param emailProcessTable
	 * @throws SQLException
	 */
	
	@Override
	public void dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable,String viewName)throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable,String viewName)");
		if (viewName != null && viewName.length() > 0) {
			String[] views=viewName.split(",");
			for (String view : views){
				try {
					logger.debug("Drop query for EMAIL Processing Table:::::::::   DROP TABLE " + viewName);
					jdbcTemplate.execute("DROP VIEW IF EXISTS " + view);
				} catch (Exception e) {
					logger.error(e.getMessage(),e);
					logger.info("View is not exist to drop :: " + viewName);
				}
			}
		}
		if (emailProcessTable != null && !emailProcessTable.isEmpty()) {
			for (String tname : emailProcessTable) {
				try {
					logger.debug("Drop query for EMAIL Processing Table:::::::::   DROP TABLE " + tname);
					jdbcTemplate.execute("DROP TABLE IF EXISTS " + tname);
				} catch (Exception E) {
					logger.error(E.getMessage(),E);
					logger.info("Table is not exist to drop :: " + tname);
				}
			}
		}
		try {
			if (tempTableName != null && tempTableName.length() > 0) {
				logger.debug("Drop query for TEMP Table:::::::::   DROP TABLE " + tempTableName);
				jdbcTemplate.execute("DROP TABLE IF EXISTS " + tempTableName);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			logger.info("Table is not exist to drop :: " + tempTableName);
		}
		if (smsProcessTable != null && !smsProcessTable.isEmpty()) {
			for (String tname : smsProcessTable) {
				try {
					logger.debug("Drop query for SMS Processing Table:::::::::   DROP TABLE " + tname);
					jdbcTemplate.execute("DROP TABLE IF EXISTS " + tname);
				} catch (Exception E) {
					logger.error(E.getMessage(),E);
					logger.info("Table is not exist to drop :: " + tname);
				}
			}
		}
		
		
		logger.debug("End : "+getClass().getName()+" : dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable,String viewName)");
	}

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 		: The Method "deleteDuplicateRecords" is used for 
	 * Date    			: Sep 29, 2016, 4:08:06 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param dataImportDTO
	 * @throws DataImportException 
	 * @throws SQLException 
	 */
	
	@Override
	public long deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap) throws DataImportException, SQLException {

		logger.debug("Begin : "+getClass().getName()+" : deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap)");
		String transientTableName=tempTableName+"_TRANSIENT_"+System.currentTimeMillis();
		String notNullColumnsStr=notNullColumns[0]+"::VARCHAR";
		int insertedRecordsCount=0;
		int totalRecordsCount=0;
		Map<String, String> queryMap=null;
		
		try{
			try{
				executeDDL("DROP TABLE IF EXISTS "+transientTableName);
				
			}catch(Exception e){
				logger.error(e.getMessage(),e);
				logger.info("Table doesn't exist to drop");
			}
			
			/*Begin :: Prepare TRANSIENT Table*/
			logger.info("Begin :: Prepare TRANSIENT Table");
			logger.info("CREATE TABLE "+transientTableName+" AS SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName+" LIMIT 0");
			executeDDL("CREATE TABLE "+transientTableName+" AS SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName+" LIMIT 0");
			logger.info("INSERT /*+ DIRECT */ INTO "+transientTableName+" SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName);
			executeInsert("INSERT /*+ DIRECT */ INTO "+transientTableName+" SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName);
			/*End :: Prepare TRANSIENT Table*/
			
			/*Begin :: Truncate TEMPORARY Table*/
			logger.info("Begin :: Truncate TEMPORARY Table");
			logger.info("TRUNCATE TABLE "+tempTableName);
			executeUpdateQuery("TRUNCATE TABLE "+tempTableName);
			/*End :: Truncate TEMPORARY Table*/
			
			/*Begin :: Dump into TEMPORARY Table*/
			logger.info("Begin :: Dump into TEMPORARY Table");
			queryMap=dataImportQueryBuilder.prepareSelectQueryWithDefaultValues(dataImportDTO,defaultValuesMap);
			String columnsWithDefaultvalues =queryMap.get("defaultValues");
			String insertCols=queryMap.get("insertQuery");
			logger.info("INSERT /*+ DIRECT */ INTO "+tempTableName+" ("+insertCols+") SELECT "+columnsWithDefaultvalues+" FROM "+transientTableName+" WHERE ROW_NUM IN (SELECT MAX(ROW_NUM) FROM "+transientTableName+" GROUP BY "+notNullColumnsStr+")");
			insertedRecordsCount=executeUpdateQuery("INSERT /*+ DIRECT */ INTO "+tempTableName+" ("+insertCols+") SELECT "+columnsWithDefaultvalues+" FROM "+transientTableName+" WHERE ROW_NUM IN (SELECT MAX(ROW_NUM) FROM "+transientTableName+" GROUP BY "+notNullColumnsStr+")");
			/*End :: Dump into TEMPORARY Table*/

			/*Begin :: Find total numbers with duplicates*/
			logger.info("Begin :: Find total numbers with duplicates");
			logger.info("SELECT MAX(ROW_NUM) FROM "+transientTableName);
			totalRecordsCount=jdbcTemplate.queryForObject("SELECT MAX(ROW_NUM) FROM "+transientTableName,Integer.class);
			
			/*End :: Find total numbers with duplicates*/
			
		}
		catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException("Exception occured :: ",e);
		}
		finally{
				logger.debug("Drop query for TEMP Table:::::::::DROP TABLE "+transientTableName);
				executeDDL("DROP TABLE IF EXISTS "+transientTableName);
		}				
		logger.debug("End : "+getClass().getName()+" : deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap)");
		return totalRecordsCount-insertedRecordsCount;
		
	}

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 		: The Method "deleteDuplicateRecords" is used for 
	 * Date    			: Sep 29, 2016, 6:48:21 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param queryprepareArrayToCSV
	 * @throws DataImportException 
	 */
	
	@Override
	public void deleteDuplicateRecords(String[] notNullColumns, String tempTableName, String cols) throws DataImportException {

		logger.debug("Begin : "+getClass().getName()+" : deleteDuplicateRecords(String[] notNullColumns, String tempTableName, String cols)");		
		String transientTableName=tempTableName+"_TRANSIENT_"+System.currentTimeMillis();
		String notNullColumnsStr=notNullColumns[0]+"::VARCHAR";;
		int insertedRecordsCount=0;
		int totalRecordsCount=0;
		Map<String, String> queryMap=null;
		try{
			try{
				executeDDL("DROP TABLE IF EXISTS "+transientTableName);
				
			}catch(Exception e){
				logger.info("Table doesn't exist to drop");
			}
			/*Begin :: Prepare TRANSIENT Table*/			
			executeDDL("CREATE TABLE "+transientTableName+" AS SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName+" LIMIT 0");
			executeInsert("INSERT /*+ DIRECT */ INTO "+transientTableName+" SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tempTableName);
			/*End :: Prepare TRANSIENT Table*/
			
			/*Begin :: Truncate TEMPORARY Table*/
			executeUpdateQuery("TRUNCATE TABLE "+tempTableName);
			/*End :: Truncate TEMPORARY Table*/
			
			/*Begin :: Dump into TEMPORARY Table*/
			
			insertedRecordsCount=executeInsert("INSERT /*+ DIRECT */ INTO "+tempTableName+" ("+cols+") SELECT "+cols+" FROM "+transientTableName+" WHERE ROW_NUM IN (SELECT MAX(ROW_NUM) FROM "+transientTableName+" GROUP BY "+notNullColumnsStr+")");
			/*End :: Dump into TEMPORARY Table*/
			
			/*Begin :: Find total numbers with duplicates*/
			totalRecordsCount=jdbcTemplate.queryForObject("SELECT MAX(ROW_NUM) FROM "+transientTableName,Integer.class);
			
			/*End :: Find total numbers with duplicates*/
			
		}
		catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(), e);
		}
		finally{
			try{
				logger.debug("Drop query for TEMP Table:::::::::DROP TABLE "+transientTableName);
				executeDDL("DROP TABLE IF EXISTS "+transientTableName);
			}catch(Exception e){
				logger.info("Table is not exist to drop  ");
			}
			}				
		logger.debug("End : "+getClass().getName()+" : deleteDuplicateRecords(String[] notNullColumns, String tempTableName, String cols)");
		
	}

	/**
	 * 
	 * Method Name 	: executeEmailOrSMSQueries
	 * Description 		: The Method "executeEmailOrSMSQueries" is used for 
	 * Date    			: Oct 20, 2016, 3:43:20 PM
	 * @param audienceType
	 * @param custCode
	 * @param categoryId
	 * @param processTableName
	 * @param audienceId
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void executeEmailOrSMSQueries(String audienceType, String custCode, int categoryId, String processTableName,long audienceId,int type) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : executeEmailOrSMSQueries(String audienceType, String custCode, int categoryId, String processTableName,long audienceId,int type)");
		String query;
		if (type==1) {
			query="INSERT /*+ DIRECT */ INTO  s_d_email_domain(EMAIL_DOMAIN_ID,EMAIL_DOMAIN_NAME,creation_dt,modified_dt) SELECT NEXTVAL('FORGEIDSEQUENCE'),PROCESSING.DOMAIN AS PROCESSING_DOMAIN,now(),now() FROM "+processTableName+" PROCESSING LEFT OUTER JOIN s_d_email_domain DOMAINS ON PROCESSING.DOMAIN = DOMAINS.EMAIL_DOMAIN_NAME WHERE DOMAINS.EMAIL_DOMAIN_NAME IS NULL GROUP BY PROCESSING_DOMAIN";		
			executeInsert(query);
		}
				
		if(type==1) 
			query="INSERT /*+ DIRECT */  INTO ADDRESS(ADDRESS_ID,CHANNEL_TYPE_ID,COUNTRY_ID,IMPLICIT_OPTIN_IND,EXPLICIT_OPTIN_IND,EXPLICIT_OPTIN_DT,OPERATIONAL_OPTOUT_IND,INVALID_ADDRESS_IND,UNDELIVERABLE_IND,MOB_OPTIN,CREATION_DT,MODIFIED_DT) SELECT ADDRESSID,1,0,False,True,NOW(),False,False,False,False,NOW(),NOW() FROM   "+processTableName+" WHERE  IS_NEW = TRUE";
		else
			query="INSERT /*+ DIRECT */ INTO ADDRESS(ADDRESS_ID,CHANNEL_TYPE_ID,COUNTRY_ID,IMPLICIT_OPTIN_IND,EXPLICIT_OPTIN_IND,EXPLICIT_OPTIN_DT,OPERATIONAL_OPTOUT_IND,INVALID_ADDRESS_IND,UNDELIVERABLE_IND,MOB_OPTIN,CREATION_DT,MODIFIED_DT) SELECT ADDRESSID,3,0,False,True,NOW(),False,False,False,True,NOW(),NOW() FROM   "+processTableName+" WHERE  IS_NEW = TRUE";
		
		logger.debug(" prepareInsertNewAddressQuery::"+query);
		
		executeInsert(query);
		
		if(type==1)
			query="INSERT /*+ DIRECT */ INTO ADDRESS_EMAIL(ADDRESS_ID,CHANNEL_TYPE_ID,EMAIL_ADDRESS,EMAIL_DOMAIN_ID,CREATION_DT,MODIFIED_DT) SELECT PROCESSING.ADDRESSID,1,PROCESSING.EMAIL_ADDRESS,DOMAINS.EMAIL_DOMAIN_ID,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN s_d_email_domain DOMAINS ON PROCESSING.DOMAIN = DOMAINS.EMAIL_DOMAIN_NAME WHERE PROCESSING.IS_NEW = TRUE";
		else
			query="INSERT /*+ DIRECT */ INTO ADDRESS_SMS(ADDRESS_ID,CHANNEL_TYPE_ID,SMS_NUMBER,CREATION_DT,MODIFIED_DT) SELECT PROCESSING.ADDRESSID,3,PROCESSING.SMS_NUMBER,NOW(),NOW() FROM "+processTableName+" PROCESSING WHERE PROCESSING.IS_NEW = TRUE";
		
		logger.debug(" prepareInsertNewEmailAddressQuery::"+query);
		executeInsert(query);
		
		if(type==1)
			query="INSERT /*+ DIRECT */ INTO  TARGET(TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_ID,ADDRESS_CATEGORY_ID,AUDIENCE_MEMBER_ID ,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT   NEXTVAL('FORGEIDSEQUENCE'),1 AS CHANNEL_TYPE_ID,P.ADDRESSID,"+categoryId+" AS ADDRESS_CATEGORY_ID,NEXTVAL('FORGEIDSEQUENCE'),"+audienceId+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P WHERE P.IS_NEW = TRUE";
		else
			query="INSERT /*+ DIRECT */ INTO  TARGET(TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_ID,ADDRESS_CATEGORY_ID,AUDIENCE_MEMBER_ID ,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT   NEXTVAL('FORGEIDSEQUENCE'),3 AS CHANNEL_TYPE_ID,P.ADDRESSID,"+categoryId+" AS ADDRESS_CATEGORY_ID,NEXTVAL('FORGEIDSEQUENCE'),"+audienceId+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P WHERE P.IS_NEW = TRUE";
		
		logger.debug(" prepareInsertNewTargetExportQuery::"+query);
		executeInsert(query);
		if(type==1)
			query="INSERT  /*+ DIRECT */ INTO TARGET (TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE') AS NEW_TARGET_ID,5 AS CHANNEL_TYPE_ID,125 AS ADDRESS_CATEGORY_ID,5 AS ADDRESS_ID,T.AUDIENCE_MEMBER_ID,"+audienceId+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P INNER JOIN target T ON P.ADDRESSID = T.ADDRESS_ID WHERE P.IS_NEW = TRUE AND T.AUDIENCE_TYPE_ID = "+audienceId+" AND T.CHANNEL_TYPE_ID = 1 AND T.ADDRESS_CATEGORY_ID  = "+categoryId;
		else
			query="INSERT  /*+ DIRECT */ INTO TARGET (TARGET_ID,CHANNEL_TYPE_ID,ADDRESS_CATEGORY_ID,ADDRESS_ID,AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,ACTIVE_IND,CREATION_DT,INACTIVE_DT) SELECT NEXTVAL('FORGEIDSEQUENCE') AS NEW_TARGET_ID,5 AS CHANNEL_TYPE_ID,125 AS ADDRESS_CATEGORY_ID,5 AS ADDRESS_ID,T.AUDIENCE_MEMBER_ID,"+audienceId+",TRUE,NOW() AS CREATION_DT,'1/1/1900' AS INACTIVE_DT FROM "+processTableName+" P INNER JOIN target T ON P.ADDRESSID = T.ADDRESS_ID WHERE P.IS_NEW = TRUE AND T.AUDIENCE_TYPE_ID = "+audienceId+" AND T.CHANNEL_TYPE_ID = 3 AND T.ADDRESS_CATEGORY_ID  = "+categoryId;
		
		logger.debug(" prepareInsertNewTargetExportQuery2::"+query);
		executeInsert(query);
		if(type==1)
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_MEMBER(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audienceId+",NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audienceId+" AND target.CHANNEL_TYPE_ID = 1 AND target.ADDRESS_CATEGORY_ID = "+categoryId+" AND PROCESSING.IS_NEW = TRUE";
		else
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_MEMBER(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audienceId+",NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audienceId+" AND target.CHANNEL_TYPE_ID = 3 AND target.ADDRESS_CATEGORY_ID = "+categoryId+" AND PROCESSING.IS_NEW = TRUE";
			
		
		logger.debug(" prepareNewEmailAudienceMember::"+query);
		executeInsert(query);
		if(type==1)
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_EMAIL(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,EMAIL_ADDRESS,EMAIL_DOMAIN_NAME,ACTIVE_IND,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audienceId+",EMAIL.EMAIL_ADDRESS,DOMAIN.EMAIL_DOMAIN_NAME,True,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID INNER JOIN address ON address.ADDRESS_ID = target.ADDRESS_ID INNER JOIN address_email EMAIL ON address.ADDRESS_ID = EMAIL.ADDRESS_ID INNER JOIN s_d_email_domain DOMAIN ON DOMAIN.EMAIL_DOMAIN_ID = EMAIL.EMAIL_DOMAIN_ID WHERE target.AUDIENCE_TYPE_ID = "+audienceId+" AND target.CHANNEL_TYPE_ID = 1 AND target.ADDRESS_CATEGORY_ID = "+categoryId+" AND PROCESSING.IS_NEW = TRUE";
		else
			query="INSERT  /*+ DIRECT */ INTO AUDIENCE_SMS(AUDIENCE_MEMBER_ID,AUDIENCE_TYPE_ID,SMS_NUMBER,ACTIVE_IND,CREATION_DT,MODIFIED_DT) SELECT DISTINCT target.AUDIENCE_MEMBER_ID,"+audienceId+",SMS.SMS_NUMBER,True,NOW(),NOW() FROM "+processTableName+" PROCESSING INNER JOIN target ON PROCESSING.ADDRESSID = target.ADDRESS_ID INNER JOIN address ON address.ADDRESS_ID = target.ADDRESS_ID INNER JOIN address_sms SMS ON address.ADDRESS_ID = SMS.ADDRESS_ID WHERE target.AUDIENCE_TYPE_ID = "+audienceId+" AND target.CHANNEL_TYPE_ID = 3 AND target.ADDRESS_CATEGORY_ID = "+categoryId+" AND PROCESSING.IS_NEW = TRUE";
		
		logger.debug(" prepareNewEmailAudience::"+query);
		executeInsert(query);
		logger.debug("End : "+getClass().getName()+" : executeEmailOrSMSQueries(String audienceType, String custCode, int categoryId, String processTableName,long audienceId,int type)");
		
	}

	/**
	 * 
	 * Method Name 	: insertEmailUnsubs
	 * Description 		: The Method "insertEmailUnsubs" is used for 
	 * Date    			: Oct 24, 2016, 1:16:43 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public boolean insertEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : insertEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");
		String userName = dataImportDto.getFileDefinitionBO()!=null ? dataImportDto.getFileDefinitionBO().getUpdatedBy() : "dataimportuser" ;
		StringBuilder query=new StringBuilder();
		if (isIgnore)
			query.append("INSERT  /*+ DIRECT */ INTO UNSUBS ")
				.append("(DEPARTMENTID, EMAIL, UNSUBDATE, UNSUBTYPE, UNSUBSRCTYPE, PROCESSEDDATE, EMAILWITHOUTPERIODS, CUSTCODE, TRANSFERSTATUS,CREATEDBY,UPDATEDBY,CREATEDATE, UPDATEDATE) ")
				.append( " SELECT "+deptId+" AS DEPTID,EMAIL_ADDRESS,now() AS UNSUBDATE,'L' AS UNSUBTYPE,'LPE' AS UNSUBSRCTYPE,now() AS PROCESSEDDATE,REPLACE('EMAIL_ADDRESS', '.', ''),'"+dataImportDto.getCustCode()+"' AS CUSTCODE,'N' AS TRANSFERSTATUS,'"+userName+"' as CREATEDBY,'"+userName+"' as UPDATEDBY,")
				.append( "now() AS CREATEDATE,now() AS UPDATEDATE FROM "+importTempTable+" WHERE EMAIL_ADDRESS NOT IN  (SELECT EMAIL FROM UNSUBS WHERE DEPARTMENTID="+deptId+" INTERSECT SELECT EMAIL_ADDRESS from ").append(importTempTable).append(")  AND IS_NEW=false");
	
		else
			query.append("INSERT  /*+ DIRECT */ INTO UNSUBS ")
				.append("(DEPARTMENTID, EMAIL, UNSUBDATE, UNSUBTYPE, UNSUBSRCTYPE, PROCESSEDDATE, EMAILWITHOUTPERIODS, CUSTCODE, TRANSFERSTATUS,CREATEDBY,UPDATEDBY,CREATEDATE, UPDATEDATE) ")
				.append( " SELECT "+deptId+" AS DEPTID,EMAIL_ADDRESS,now() AS UNSUBDATE,'L' AS UNSUBTYPE,'LPE' AS UNSUBSRCTYPE,now() AS PROCESSEDDATE,REPLACE('EMAIL_ADDRESS', '.', ''),'"+dataImportDto.getCustCode()+"' AS CUSTCODE,'N' AS TRANSFERSTATUS,'"+userName+"' as CREATEDBY,'"+userName+"' as UPDATEDBY,")
				.append( "now() AS CREATEDATE,now() AS UPDATEDATE FROM "+importTempTable+" WHERE  EMAIL_ADDRESS NOT IN  (SELECT EMAIL FROM UNSUBS WHERE DEPARTMENTID="+deptId+" INTERSECT SELECT EMAIL_ADDRESS from  ").append(importTempTable).append(")");
		
		logger.debug("UNSUBS query ::: "+query.toString());
		logger.debug("End : "+getClass().getName()+" : insertEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");
		return executeInsert(query.toString())>0;
	}

	/**
	 * 
	 * Method Name 	: deleteEmailUnsubs
	 * Description 		: The Method "deleteEmailUnsubs" is used for 
	 * Date    			: Oct 24, 2016, 1:16:43 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public boolean deleteEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : deleteEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");
		String deleteQuery ;
		if (isIgnore)
			deleteQuery= "DELETE FROM UNSUBS WHERE EMAIL IN (SELECT EMAIL_ADDRESS FROM "+importTempTable+" WHERE IS_NEW=false) AND DEPARTMENTID="+deptId;
		else
			deleteQuery= "DELETE FROM UNSUBS WHERE EMAIL IN (SELECT EMAIL_ADDRESS FROM "+importTempTable+") AND DEPARTMENTID="+deptId;
		logger.debug("End : "+getClass().getName()+" : deleteEmailUnsubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");
		return executeDeleteQuery(deleteQuery);
	}

	/**
	 * 
	 * Method Name 	: deleteSmsResubs
	 * Description 		: The Method "deleteSmsResubs" is used for 
	 * Date    			: Oct 24, 2016, 1:16:43 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public boolean deleteSmsResubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : deleteSmsResubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");
		String deleteQuery;
		if (isIgnore)
			deleteQuery = "DELETE FROM SMS_UNSUBS WHERE MOBILENO IN (SELECT SMS_NUMBER FROM "+importTempTable+" WHERE IS_NEW=false) AND BUID="+deptId;
		else
			deleteQuery = "DELETE FROM SMS_UNSUBS WHERE MOBILENO IN (SELECT SMS_NUMBER FROM "+importTempTable+") AND BUID="+deptId;
		logger.debug("End : "+getClass().getName()+" : deleteSmsResubs(DataImportDTO dataImportDto, String importTempTable,int deptId,boolean isIgnore)");	
		return executeDeleteQuery(deleteQuery);
	}

	/**
	 * 
	 * Method Name 	: insertSmsUnsubs
	 * Description 		: The Method "insertSmsUnsubs" is used for 
	 * Date    			: Oct 24, 2016, 5:05:10 PM
	 * @param dataImportDto
	 * @param importTempTable
	 * @param deptId
	 * @param isIgnore
	 * 
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public boolean insertSmsUnsubs(DataImportDTO dataImportDto, String importTempTable, int deptId,boolean isIgnore) throws SQLException {
		logger.debug("Begin : "+getClass().getName()+" : insertSmsUnsubs(DataImportDTO dataImportDto, String importTempTable, int deptId,boolean isIgnore)");
		String userName = dataImportDto.getFileActivities()!=null&&!dataImportDto.getFileActivities().isEmpty()?dataImportDto.getFileActivities().get(0).getCreatedBy():"";
		StringBuilder query=new StringBuilder();
		if (isIgnore)
		query.append("INSERT  /*+ DIRECT */ INTO SMS_UNSUBS (MOBILENO, BUID, UNSUBDATE, UNSUBTYPE, ")
				.append( "UNSUBSRCTYPE, PROCESSEDDATE, TRANSFERSTATUS, CREATEDBY, UPDATEDBY, CREATEDATE, UPDATEDATE)")
				.append( " SELECT SMS_NUMBER,"+deptId+" AS BUID,now() AS UNSUBDATE,'L' AS UNSUBTYPE,'LPE' AS UNSUBSRCTYPE,now() AS PROCESSEDDATE,'N' AS TRANSFERSTATUS,'"+userName+"' AS CREATEDBY,")
						.append( "'"+userName+"' AS UPDATEDBY,now() AS CREATEDATE,now() AS UPDATEDATE FROM "+importTempTable+" WHERE  SMS_NUMBER  NOT IN (SELECT MOBILENO FROM SMS_UNSUBS WHERE BUID="+deptId+" INTERSECT SELECT SMS_NUMBER FROM  ").append(importTempTable).append( ") AND IS_NEW=false");
		else
			query.append("INSERT  /*+ DIRECT */ INTO SMS_UNSUBS (MOBILENO, BUID, UNSUBDATE, UNSUBTYPE, ")
			.append( "UNSUBSRCTYPE, PROCESSEDDATE, TRANSFERSTATUS, CREATEDBY, UPDATEDBY, CREATEDATE, UPDATEDATE)")
			.append( " SELECT SMS_NUMBER,"+deptId+" AS BUID,now() AS UNSUBDATE,'L' AS UNSUBTYPE,'LPE' AS UNSUBSRCTYPE,now() AS PROCESSEDDATE,'N' AS TRANSFERSTATUS,'"+userName+"' AS CREATEDBY,")
					.append( "'"+userName+"' AS UPDATEDBY,now() AS CREATEDATE,now() AS UPDATEDATE FROM "+importTempTable+" WHERE  SMS_NUMBER  NOT IN (SELECT MOBILENO FROM SMS_UNSUBS WHERE BUID="+deptId+" INTERSECT SELECT SMS_NUMBER FROM  ").append(importTempTable).append( ")");
		
		logger.debug("Unsub query :::: "+query.toString());
		logger.debug("End : "+getClass().getName()+" : insertSmsUnsubs(DataImportDTO dataImportDto, String importTempTable, int deptId,boolean isIgnore)");
		return executeInsert(query.toString())>0;
	}

	public boolean updateTriggers(Long fileDefinitionID) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : updateTriggers(Long fileDefinitionID)");
		List<Trigger> triggers = null;
		List<Long> triggerIds = new ArrayList<>();
		Map<Long,Long> relativeMap = new HashMap<>();
		ObjectMapper objectMapper = new ObjectMapper();	
		String triggerString = null;
		int updated = 0;
		try {
			triggers = custJdbcTemplate.query("SELECT * FROM CNV_TRIGGER WHERE triggertype = 'F' and filedefinitionid ="+fileDefinitionID, new TriggerMapper());
			if(triggers != null && triggers.size() > 0){
				for(Trigger trigger : triggers){
					FileSchedule fileSchedule = objectMapper.readValue(objectMapper.writeValueAsString(trigger.getScheduleJson()), FileSchedule.class);
					if(fileSchedule.getFrequency().equalsIgnoreCase("I")){
						triggerIds.add(trigger.getTriggerID());
						relativeMap.put(trigger.getTriggerID(), trigger.getConversationId());
					} else {
						logger.debug("There frequency for this filedefinitionId ::"+fileSchedule.getFrequency());
					}
				}
			} else {
				logger.debug("There are no triggers currently for this filedefinitionId ::"+fileDefinitionID);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error(e.getMessage(),e);
			logger.debug("There are no triggers currently for this filedefinitionId ::"+fileDefinitionID +"::"+e.getMessage());
		} catch (Exception ex) {
			logger.error(ex.getMessage(),ex);
			throw new Exception("Exception occured while fetching triggers :: "+ex.getMessage());
		}
		if(!triggerIds.isEmpty()){
			triggerString = triggerIds.stream().map(number -> String.valueOf(number)).collect(Collectors.joining(",", "(", ")"));
			logger.debug("update CNV_TRIGGER set schedulenextdue = UTC_TIMESTAMP where triggerid in "+triggerString + " :: for the filedefinitionid ::"+fileDefinitionID);
			try {
				updated = custJdbcTemplate.update("update CNV_TRIGGER set schedulenextdue = UTC_TIMESTAMP, status = 'W' where triggerid in "+triggerString);
				//rest call to update relative schedules
				updateRelativeSchedules(relativeMap);
				return updated > 0;
			} catch (Exception e) {
				logger.error("Exception occured while updating triggers for the filedefinitionId ::"+fileDefinitionID+" :: "+e.getMessage());
				throw e;
			}
		} else {
			logger.debug("There are no triggers with Immediate frequency for the filedefinitionid :: "+fileDefinitionID);
		}
		logger.debug("End : "+getClass().getName()+" : updateTriggers(Long fileDefinitionID)");
		return false;
	}

	private void updateRelativeSchedules(Map<Long, Long> relativeMap) {
		RestRequestHandler restHandler= new RestRequestHandler();
		ResponseEntity<?> response;
		try{
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(relativeMap,headers);
			response = restHandler.exchange(ZetaUtil.getHelper().getEndpoint("conversation")+"/Conversation/updateRelativeSchedules",HttpMethod.POST, entity, Object.class);
    	}catch(Exception e){
    		logger.error(e.getMessage(),e);
    		logger.debug("Expection occured while updating updateRelativeSchedules :: "+e.getMessage() +"For the input map "+relativeMap.toString());
    	}
		
	}

	public boolean deleteFromList(Long fileDefinitionID, Long audienceMemberId) throws SQLException {
		String query="DELETE FROM ADHOC_"+fileDefinitionID +"where AUDIENCE_MEMBER_ID ="+audienceMemberId;
		return executeDeleteQuery(query);
	}
	@Override
	public Map<String,Long> checkEmailExist(String email) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : checkEmailExist(String email)");
		String query="";
		Long audienceMemberID=0l;
		Long addressID=0l;
		Map<String,Long> audienceData=null;
		try {
			audienceData=new HashMap<>();
			query="SELECT AUDIENCE_MEMBER_ID FROM AUDIENCE_EMAIL WHERE EMAIL_ADDRESS='"+email+"'";
			audienceMemberID=jdbcTemplate.queryForObject(query, Long.class);
			/*if(audienceMemberID>0){
				query="SELECT ADDRESS_ID FROM ADDRESS_EMAIL WHERE EMAIL_ADDRESS='"+email+"'";
				addressID=jdbcTemplate.queryForObject(query, Long.class);		
			}*/
			
			audienceData.put(AUDIENCE_MEMBER_ID, audienceMemberID);
			//audienceData.put(ADDRESS_ID, addressID);
		} catch (EmptyResultDataAccessException ex) {
			logger.error(ex.getMessage(),ex);
			logger.debug("End : "+getClass().getName()+" : checkEmailExist(String email)");
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new Exception("Error while getting audienceId");
		}
		logger.debug("End : "+getClass().getName()+" : checkEmailExist(String email)");
		return audienceData;
	}

	@Override
	public boolean addToList(String adhocTableName, Long audienceMemberId,Map<String,String> colNameAndValue,Map<String,String> columnAndTypes) throws SQLException, Exception {
		logger.debug("Begin : "+getClass().getName()+" : addToList(String adhocTableName, Long audienceMemberId,Map<String,String> colNameAndValue,Map<String,String> columnAndTypes)");
		String columns="";
		String values="";
		String columnsAndValues="";
		String query="";
		logger.debug("colNameAndValue:"+colNameAndValue.toString() +", adhocTableName="+adhocTableName+", audienceMemberId="+audienceMemberId);
		if(checkAudienceMemberExist(adhocTableName, audienceMemberId))
		{
			for (Map.Entry<String, String> entry : colNameAndValue.entrySet())
			{
				if(columnsAndValues.length()>1){
					columnsAndValues=columnsAndValues+","+entry.getKey()+"="+getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
					//values=values+","+getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
				}else{
					columnsAndValues=entry.getKey()+"="+getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
					//values=getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
				}
			}
			query="UPDATE "+adhocTableName +" SET "+columnsAndValues +" where AUDIENCE_MEMBER_ID="+audienceMemberId;
			logger.info("Updatequery:--->"+query);
			
		}
		else{
			logger.debug("colNameAndValue:"+colNameAndValue.toString());
			for (Map.Entry<String, String> entry : colNameAndValue.entrySet())
			{
				logger.debug("entry:"+entry);
				logger.debug("columns:"+columns);
				if(columns.length()>1){
					columns=columns+","+entry.getKey();
					values=values+","+getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
				}else{
					columns=entry.getKey();
					values=getValueByType(columnAndTypes.get(entry.getKey()), entry.getValue());
				}
			}
			query="INSERT INTO "+adhocTableName +" ("+columns+",AUDIENCE_MEMBER_ID,ISNEW_2 )values("+values+","+audienceMemberId+",TRUE)";
		}
		try {
			logger.debug("End : "+getClass().getName()+" : addToList(String adhocTableName, Long audienceMemberId,Map<String,String> colNameAndValue,Map<String,String> columnAndTypes)");
			return executeDeleteQuery(query);
		} catch (Exception e) {
			logger.debug("Error occured while executing query:"+e);
			throw new DataImportException("Data type mismatch occured in the values provided.");
		}
		
	}

	@Override
	public Map<String, Long> checkSMSExist(String sms) throws SQLException, Exception {
		logger.debug("Begin : "+getClass().getName()+" : checkSMSExist(String sms)");
		String query="";
		Long audienceMemberID=0l;
		Map<String,Long> audienceData=null;
		try {
			audienceData=new HashMap<>();
			query="SELECT AUDIENCE_MEMBER_ID FROM AUDIENCE_SMS WHERE SMS_NUMBER='"+sms+"'";
			audienceMemberID=jdbcTemplate.queryForObject(query, Long.class);
						
			audienceData.put(AUDIENCE_MEMBER_ID, audienceMemberID);
		} catch (EmptyResultDataAccessException ex) {
			logger.error(ex.getMessage(),ex);
			logger.debug("End : "+getClass().getName()+" : checkSMSExist(String sms)");
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new Exception("Error while getting audienceId");
		}
		logger.debug("End : "+getClass().getName()+" : checkSMSExist(String sms)");
		return audienceData;
	}

	@Override
	public boolean checkTableExist(String TableName,String whSchemaName) throws SQLException, Exception {
		logger.debug("Begin : "+getClass().getName()+" : checkTableExist(String TableName,String whSchemaName)");
		try{
			String query="SELECT t.TABLE_NAME FROM v_catalog.tables AS t WHERE t.TABLE_SCHEMA ='"+whSchemaName+ 
					"'AND t.IS_SYSTEM_TABLE=false AND t.IS_TEMP_TABLE=false AND t.TABLE_NAME='"+TableName+"' ORDER BY t.TABLE_NAME";
			String result= (String)jdbcTemplate.queryForObject(	query,String.class);
			if(result==null||result.equals(""))
				return false;
		}
		catch (EmptyResultDataAccessException ex) {
			logger.error(ex.getMessage(),ex);
			logger.debug("End : "+getClass().getName()+" : checkTableExist(String TableName,String whSchemaName)");
			return false;
		}
		logger.debug("End : "+getClass().getName()+" : checkTableExist(String TableName,String whSchemaName)");
		return true;
	}
	
	@Override
	public boolean checkAudienceMemberExist(String phySicalTableName,Long audienceMemeberId) throws SQLException, Exception {
		logger.debug("Begin : "+getClass().getName()+" : checkAudienceMemberExist(String phySicalTableName,Long audienceMemeberId)");
		logger.info("phySicalTableName:"+phySicalTableName);
		boolean isExist = false;
		String query="select count(*) from "+phySicalTableName+" where AUDIENCE_MEMBER_ID="+audienceMemeberId;
		Integer result= (Integer)jdbcTemplate.queryForObject(query,Integer.class);
		
		if(result!=null && result!=0)
			isExist = true;
		logger.debug("End : "+getClass().getName()+" : checkAudienceMemberExist(String phySicalTableName,Long audienceMemeberId)");
		return isExist;
	}
	
	
	private String getValueByType(String columnType,String value){
		String columnValue = "";
		try{
			switch (columnType) {
			case "DOUBLE":
			case "DECIMAL":
			case "BIGINT":
			case "BOOLEAN":
				columnValue = value;
				break;
			default:
				columnValue = "'"+value+"'";
				break;
			}
		}catch(Exception e){
			
		}
		return columnValue;
	}
	
	@Override
	public Map<String,Long> checkRecordExist(Map<String, String> keyColumnAndValue, String physicalTableName,Map<String, String> colNameAndTypeMap) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : checkRecordExist(Map<String, String> keyColumnAndValue, String physicalTableName,Map<String, String> colNameAndTypeMap)");
		String query="";
		Long audienceMemberID=0l;
		Long addressID=0l;
		Map<String,Long> audienceData=null;
		try {
			audienceData=new HashMap<>();
			String condition = prepareCondition(keyColumnAndValue,colNameAndTypeMap);
			query="SELECT AUDIENCE_MEMBER_ID FROM "+physicalTableName+" WHERE "+condition;
			logger.info("Query for record existing in "+physicalTableName+" table :: "+query);
			audienceMemberID=jdbcTemplate.queryForObject(query, Long.class);
			audienceData.put(AUDIENCE_MEMBER_ID, audienceMemberID);
		} catch (EmptyResultDataAccessException ex) {
			logger.error(ex.getMessage(),ex);
			logger.debug("End : "+getClass().getName()+" : checkRecordExist(Map<String, String> keyColumnAndValue, String physicalTableName,Map<String, String> colNameAndTypeMap)");
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new Exception("Error while getting audienceId");
		}
		logger.debug("End : "+getClass().getName()+" : checkRecordExist(Map<String, String> keyColumnAndValue, String physicalTableName,Map<String, String> colNameAndTypeMap)");
		return audienceData;
	}

	private String prepareCondition(Map<String, String> keyColumnAndValue, Map<String, String> colNameAndTypeMap) {
		StringBuilder condition = new StringBuilder();
		Set<String> keys = keyColumnAndValue.keySet();
		for (String key : keys) {
			if(condition.length()>0){
				condition.append(" AND ");
			}
			condition.append(key+" = "+getValueByType(colNameAndTypeMap.get(key), keyColumnAndValue.get(key)));
		}
		return condition.toString();
	}

	@Override
	public int deleteRecordFromAdhocTable(Map<String, String> keyColumnAndValue, String adhocTableName,
			Map<String, String> colNameAndTypeMap) throws Exception{
		logger.debug("Begin : "+getClass().getName()+" : deleteRecordFromAdhocTable(Map<String, String> keyColumnAndValue, String adhocTableName,Map<String, String> colNameAndTypeMap)");
		String query="";
		int returnValue=0;
		try {
			if(keyColumnAndValue.size()>0){
				String condition = prepareCondition(keyColumnAndValue,colNameAndTypeMap);
				query="DELETE FROM "+adhocTableName+" WHERE "+condition;
				logger.info("Query for deleting record from adhoc table :: "+query);
				returnValue=jdbcTemplate.update(query);
			}
		} catch (EmptyResultDataAccessException ex) {
			
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new Exception("Error while getting audienceId");
		}
		logger.debug("End : "+getClass().getName()+" : deleteRecordFromAdhocTable(Map<String, String> keyColumnAndValue, String adhocTableName,Map<String, String> colNameAndTypeMap)");
		return returnValue;
	
	}

}


package com.zetainteractive.zetahub.de.dataimport.exception;

import org.apache.log4j.Level;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:27:12 PM
 * @Version	   : 1.7
 * @Description: "DataImportException" is used for 
 * 
 *
 */
public class DataImportException extends Exception
{
	
	private static final long serialVersionUID = 1L;
	String errorCode;
    String errorMessage;
    private String message;
    String dbMessage;
    Throwable exception;
    Object[] object;
    Level level=Level.ERROR;
    boolean flag = false;
    
    /**
	 * @return Returns the errorMessage.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage The errorMessage to set.
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * No argument constructor.
	 */
	public DataImportException() 
    {
		
    }
	/**
	 * @param errorCode error code
	 */
	public DataImportException(String errorCode) 
    {
		super(errorCode);
		this.errorCode = errorCode;
    }    
    
    /**
     * Constructor takes Error code and actual ex as arguments.
     * @param code Error code
     * @param ex Actual Exception occured.
     */
    public DataImportException(String code,Throwable ex)
    {
    	super(code, ex);
        this.errorCode = code;
        this.exception = ex;
        this.message = ex.getMessage();
    }
    
    /**
     * @param code
     * @param object
     */
    public DataImportException(String code,Object[] object)
    {
    	super(code);
        this.errorCode = code;
        this.object = object; 
    }
    
    /**
     * @param code
     * @param ex
     * @param object
     * @param flag
     */
    public DataImportException(String code,Throwable ex, Object[] object, boolean flag)
    {
    	super(code, ex);
        this.errorCode = code;
        this.exception = ex;
        this.object = object; 
        this.flag = flag;
    }
    
    /**
     * @param code
     * @param object
     * @param level
     * @param ex
     */
    public DataImportException(String code, Object[] object, Level level, Throwable ex)
    {
    	super(code, ex);
        this.errorCode = code;
        this.exception = ex;
        this.object = object; 
        this.level = level;
    }
    
    public DataImportException(String code,String locale, Object obj)
    {
    	super(code);
        this.errorCode = code;
    }
    /**
     * Returns the error code associated with the exception.
     * @return
     */
    public String getErrorCode() 
    {
        return this.errorCode;
    }
	/**
	 * @return Returns the dbMessage.
	 */
	public String getDbMessage() {
		return dbMessage;
	}
	/**
	 * @param dbMessage The dbMessage to set.
	 */
	public void setDbMessage(String dbMessage) {
		this.dbMessage = dbMessage;
	}
		   
    
    /**
     * @return Returns the object.
     */
    public Object[] getObject() {
        return object;
    }
    /**
     * @return Returns the exception.
     */
    public Throwable getException() {
        return exception;
    }
    /**
     * @return Returns the level.
     */
    public Level getLevel() {
        return level;
    }
    /**
     * @param level The level to set.
     */
    public void setLevel(Level level) {
        this.level = level;
    }
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}

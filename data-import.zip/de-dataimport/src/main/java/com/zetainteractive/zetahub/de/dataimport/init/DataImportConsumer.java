package com.zetainteractive.zetahub.de.dataimport.init;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData.Record;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.avro.AvroUtil;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.kafka.AvroSimpleConsumer;
import com.zetainteractive.kafka.AvroSimpleProducer;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.SpringApplicationContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.de.commons.BatchStatus;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.commons.DataImportProgress;
import com.zetainteractive.zetahub.de.commons.KafkaGroupNames;
import com.zetainteractive.zetahub.de.commons.KafkaTopicNames;
import com.zetainteractive.zetahub.de.dao.DataImportProgressDao;
import com.zetainteractive.zetahub.de.dataimport.process.FileDefinitionProcessor;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:32:25 PM
 * @Version	   : 1.7
 * @Description: "DataImportConsumer" is used for 
 * 
 *
 */
@Component
public class DataImportConsumer extends AvroSimpleConsumer {

	ZetaLogger logger = new ZetaLogger(this.getClass());
	
	@Autowired
	DataImportProgressDao dataImportProgressDao;
	AvroSimpleProducer producer = null;
	
	
	/**
	 * 
	 * @param group
	 * @param topic
	 * @param schemaStringConstructor "DataImportConsumer" is used for
	 * @throws Exception 
	 */
	public DataImportConsumer() throws Exception {
		super(ZetaUtil.getHelper().getTopicGroup(KafkaGroupNames.getDATAIMPORTGROUP()), ZetaUtil.getHelper().getTopic(KafkaTopicNames.getDATAIMPORTTOPIC()));
		try {
			//pollingInterval = ZetaUtil.getHelper().getConfig().getConfigValueInt("kafka-topic-poll-interval", 5000)
			pollingInterval =ZetaUtil.getHelper().getConfig().getConfigValueInt("dataimport-kafka-topic-pollinterval", 3600000);
		} catch (Exception e) {
			logger.error("Exception Occured while creating consumer : "+e.getMessage(),e);
		}
	}

	/* (non-Javadoc)
	 * @see com.zetainteractive.kafka.AvroSimpleConsumer#processMessage(org.apache.avro.generic.GenericRecord, java.util.List)
	 */
	@Override
	public boolean processMessage(ConsumerRecord<String, byte[]> consumerRecord, GenericRecord header, List<GenericRecord> records){
		logger.info("Got the processMessage call " + header.toString() + " : " + records.size());
		Thread newThread;
		boolean processCompleted = false;
		DataImportDTO dataImportDTO = new DataImportDTO();
		ApplicationContext applicationContext = SpringApplicationContext.getContext();
		DataImportProgress dataImportProgress=null;
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			logger.info("Message partition number :::"+consumerRecord.partition()+" and offset :: "+consumerRecord.offset());
			long dataProgressId=(Long)header.get("batch_progress_id");
			Integer userid = (Integer)header.get("userid");
			String customerCode=header.get("customer_code").toString();
			String userName=header.get("username").toString();
			initializeContext(customerCode);
			ZetaUtil.getHelper().setLoggingContextKey(header.get("context_key") !=null ? header.get("context_key").toString() :"");
			logger.info("Progress id ::"+dataProgressId);
			// Verifying internal message or not if internal getting dto from db.
			if (header.get("from_process").toString().equals("dataimport")){
				logger.info("Reprocess message received.");
				dataImportProgress=dataImportProgressDao.getDataImportProgress(dataProgressId);
				dataImportDTO=mapper.readValue(dataImportProgress.getRecordData(), DataImportDTO.class);
			}else{
				dataImportProgress=dataImportProgressDao.getDataImportProgress(dataProgressId);
				dataImportDTO = prepareDataImportDTO(header,records);
			}
			
			if(dataImportProgress !=null && dataImportProgress.getImportprocess_status() == BatchStatus.READY.getValue() ){
				//Verify with audience id if any in-progress or not
				DataImportProgress dataImportProgress2=null;
				//-1 is the non-audience import.There is no need to check duplicate for non-audience import  
				if (dataImportProgress.getAudienceId() != -1)
					dataImportProgress2=dataImportProgressDao.getDataImportProgressByAudience(dataImportProgress.getAudienceId(), BatchStatus.IN_PROGRESS.getValue());
				if (dataImportProgress2!=null){
					logger.info("Data import with audience id :: "+dataImportProgress.getAudienceId()+" is in-progress. Moving to re-proces.");
					dataImportDTO.setFileSummaryBO(mapper.readValue(records.get(0).get("file_summary").toString(),FileSummaryBO.class));
					
					String json=mapper.writeValueAsString(dataImportDTO);
					dataImportProgress.setRecordData(json);
					dataImportProgress.setImportprocess_status(BatchStatus.RE_PROCESS.getValue());
					dataImportProgressDao.updateDataImportStatus(dataImportProgress);
				}else{
					dataImportProgress.setImportprocess_status(BatchStatus.IN_PROGRESS.getValue());
					dataImportProgress.setImportprocess_offSet(consumerRecord.offset());
					dataImportProgress.setImportprocess_partition(consumerRecord.partition());
					dataImportProgressDao.updateDataImportStatus(dataImportProgress);
					dataImportDTO.setDataImportProgress(dataImportProgress);
					FileDefinitionProcessor fileDefinitionProcessor = applicationContext.getBean(FileDefinitionProcessor.class,customerCode,null,userName,userid,dataImportDTO,ZetaUtil.getHelper().getLoggingContextKey(),records.get(0));
					newThread=new Thread(fileDefinitionProcessor);
					newThread.start();
					newThread.join();
					dataImportProgressDao.updateDataImportStatus(dataImportProgress);
				}
				
				
			}else if (dataImportProgress != null){
				logger.info("Message already processed with offset :: "+dataImportProgress.getImportprocess_offSet()+" and partition :: "+dataImportProgress.getImportprocess_partition());
			}else{
				logger.info("No  records found in DE_DATAIMPORT_PROGRESS with progressid ::"+dataProgressId);
			}
			DataImportProgress dataImportProgress2=dataImportProgressDao.getReprocessDataImportProgress();
			if (dataImportProgress2 != null ){
				logger.info("Producing message to internal message to data-import and progressid is :::"+dataImportProgress2.getDataImportProgressID());
				dataImportProgress2.setImportprocess_status(BatchStatus.READY.getValue());
				dataImportProgressDao.updateDataImportStatus(dataImportProgress2);
				produceInternalMessage(customerCode,dataImportProgress2, userid);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}finally {
			try {
				ZetaUtil.getHelper().clearLoggingContextKey();
			} catch (Exception e2) {
				logger.error(e2.getMessage(),e2);
			}
		}
		return processCompleted;
	}

	
	/**
	 * 
	 * Method Name 	: prepareDataImportDTO
	 * Description 	: The Method "prepareDataImportDTO" is used for 
	 * Date    		: Sep 26, 2016, 2:53:32 PM
	 * @param records 
	 * @return
	 * @param  		:
	 * @return 		: DataImportDTO
	 * @throws Exception 
	 * @throws 		: 
	 */
	private DataImportDTO prepareDataImportDTO(GenericRecord header, List<GenericRecord> records) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : prepareDataImportDTO(GenericRecord header, List<GenericRecord> records)");	
		DataImportDTO dataImportDTO  = new DataImportDTO(); 
		ObjectMapper mapper = new ObjectMapper();
		GenericRecord data = records.get(0);
		if(data.get("file_definition_id")!=null)
			dataImportDTO.setFileDefinitionId((long) data.get("file_definition_id"));
		dataImportDTO.setImportType(data.get("import_type").toString());
		dataImportDTO.setAudienceType(data.get("audience_type").toString());
		dataImportDTO.setCustCode(header.get("customer_code").toString());
		dataImportDTO.setTempTableName(data.get("temp_table_name").toString());
		dataImportDTO.setBaseTablePhysicalName(data.get("base_table_name")!= null ? data.get("base_table_name").toString() : null);
		dataImportDTO.setIsWorkFlowAssociated((Boolean) data.get("is_workflow_associated"));
		dataImportDTO.setWorkFlowID((Long) data.get("workflow_associated"));
		dataImportDTO.setAudienceId((long) data.get("audience_id"));
		if(data.get("table_disposition")!=null)
			dataImportDTO.setTableDisposition(data.get("table_disposition").toString());
		else
			dataImportDTO.setTableDisposition(null);
		if(data.get("file_action")==null)
			dataImportDTO.setFileAction(null);
		else
			dataImportDTO.setFileAction(data.get("file_action").toString().charAt(0));
		List<Column> columnsList = mapper.readValue(data.get("columns").toString(), mapper.getTypeFactory().constructCollectionType(List.class, Column.class));
		List<Long> activityIds = mapper.readValue(data.get("file_activity_ids").toString(), mapper.getTypeFactory().constructCollectionType(List.class, Long.class));
		dataImportDTO.setFileActivityIds(activityIds);
		dataImportDTO.setColumns(columnsList);
		List<Column> baseTableColumns = new ArrayList<>();
		List<Column> customColumns = new ArrayList<>();
		for (Column column : columnsList) {
			if(!column.getIsCustomColumn()){
				baseTableColumns.add(column);
			}else{
				customColumns.add(column);
			}
		}
		dataImportDTO.setBaseTableColumns(baseTableColumns);
		dataImportDTO.setCustomColumns(customColumns);
		
		dataImportDTO.setIsNotificationEnabled((Boolean)data.get("isNotificationEnabled"));
		dataImportDTO.setNotificationEmails(AvroUtil.getStringAsMap(data.get("notificationEmails").toString()));
		dataImportDTO.setIsInvalidRecordsExist((Boolean)data.get("isInvalidRecordsExist"));
		
		if(data.get("listType") != null )
			dataImportDTO.setListType(data.get("listType").toString().charAt(0));
		logger.debug("End : "+getClass().getName()+" : prepareDataImportDTO(GenericRecord header, List<GenericRecord> records)");
		return dataImportDTO;
	}
	/**
	 * 
	 * Method Name 	: initializeContext
	 * Description 	: The Method "initializeContet" is used for 
	 * Date    		: Dec 9, 2016, 1:02:10 PM
	 * @param custCode
	 * @param  		:
	 * @return 		: void
	 * @throws Exception 
	 * @throws RestClientException 
	 * @throws 		: 
	 */
	private void initializeContext(String customerCode) throws RestClientException, Exception {
			
			if(ZetaUtil.getHelper().getCustomerID()==null || !ZetaUtil.getHelper().getCustomerID().equalsIgnoreCase(customerCode) ){
				ZetaUtil.getHelper(customerCode, null);
			}
			String userName = ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser","dataimportuser");

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), customerCode);
			httpHeaders.add(BootStarterConstants.USERNAME.toString(), userName);
			UserBO user = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("security") + "/getUserByName/" + userName, HttpMethod.GET,
							new HttpEntity<>(httpHeaders), UserBO.class).getBody();

			if (user != null) {
				ZetaUtil.getHelper().setUser(user);
			} else {
				throw new Exception("user not available with username :: " + userName);
			}
		
		
	}
	private boolean produceInternalMessage(String custCode,DataImportProgress dataImportProgress,int userid) throws Exception{
		Schema schema=SchemaBuilder.record("DataImportDTO").namespace("com.zetainteractive.avro").fields().endRecord();
		if(producer==null){
			producer = new AvroSimpleProducer(schema.toString());
			String brokerList = ZetaUtil.getHelper().getConfig().getConfigValueString("kafka-broker-list", null);
			producer.configure(brokerList);
			producer.start();
		}
		try{
			Record record=new Record(schema);
			producer.addHeader("meta", schema.toString());
	        producer.addHeader("from_process", "dataimport");
	        producer.addHeader("to_process",  "dataimport");
	        producer.addHeader("payload_type", "inline");
	        producer.addHeader("payload_location", "inline");
	        producer.addHeader("processing_behavior", "1");
	        producer.addHeader("batch_progress_id", -1L);
	        producer.addHeader("customer_code", custCode);
	        producer.addHeader("username", ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser", "dataimportuser"));
	        producer.addHeader("trigger_id", 0L);
	        producer.addHeader("conversation_id",  -1L);
	        producer.addHeader("wave_id", -1L);
	        producer.addHeader("campaign_id", -1L);
	        producer.addHeader("blast_id", -1L);
	        producer.addHeader("relative_blastid", -1L);
	        producer.addHeader("batch_id", -1L);
	        producer.addHeader("is_test", "N");
	        producer.addHeader("test_sample_id", 0L);
			producer.addHeader("batch_progress_id", dataImportProgress.getDataImportProgressID());
			producer.addHeader("userid", userid);
	        producer.addHeader("schema", schema.toString());
	        producer.addHeader("context_key", ZetaUtil.getHelper().getLoggingContextKey());
	        Future<RecordMetadata> reFuture = producer.produceMessage(ZetaUtil.getHelper().getTopic(KafkaTopicNames.getDATAIMPORTTOPIC()),record);
			if (reFuture != null) {
				RecordMetadata metadata = reFuture.get();
				logger.info("Message sent to Topic :: ["+metadata.topic()+"] Partition :: ["+metadata.partition()+"] Offset :: ["+metadata.offset()+"]");
			}
		}catch (InterruptedException ie) {
			logger.error("Producer failed to send message with InterruptedException :: "+ie.getMessage(), ie);
		} catch (ExecutionException ee) {
			logger.error("Producer failed to send message with ExecutionException :: "+ee.getMessage(), ee);
		} catch (TimeoutException te) {
		    logger.error("Producer failed to send message with TimeoutException :: "+te.getMessage(), te);
		} catch (KafkaException ke) {
			logger.error("Producer failed to send message with KafkaException :: "+ke.getMessage(), ke);
		}
		return true;
	}
	
	public void stopProducer(){
		if(producer != null)
			producer.stop();
	}

}

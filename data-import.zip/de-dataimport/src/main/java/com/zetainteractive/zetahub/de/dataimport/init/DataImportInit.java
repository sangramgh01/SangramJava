/**
 * 
 */
package com.zetainteractive.zetahub.de.dataimport.init;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.zetainteractive.zetahub.bootstarter.BootInitializer;
import com.zetainteractive.zetahub.bootstarter.SpringApplicationContext;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;

import ch.qos.logback.classic.Logger;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:28:10 PM
 * @Version	   : 1.7
 * @Description: "DataImportAppInit" is used for 
 * 
 *
 */
@SpringBootApplication
@EnableAutoConfiguration (exclude={DataSourceAutoConfiguration.class})
@Configuration
@ComponentScan(basePackages = { "com.zetainteractive.zetahub.de.*, com.zetainteractive.zetahub.commons.Util" })
public class DataImportInit {

	/**
	 * 
	 * 
	 * Method Name 	: main
	 * Description 	: The Method "main" is used for 
	 * Date    		: Aug 18, 2016, 12:30:20 PM
	 * @param args
	 * @throws Exception
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	 public static void main(String[] args) throws Exception {

		BootInitializer.runApp(DataImportInit.class, args);
		ApplicationContext context = SpringApplicationContext.getContext();
		//Now lets get an instance of the ZetaHelper
		ZetaUtil zetaUtil = new ZetaUtil();
		Logger logger = (Logger) LoggerFactory.getLogger(DataImportInit.class);
		logger.info("DE Data Import App Started...");

		String brokerList = zetaUtil.getHelper().getConfig().getConfigValueString("kafka-broker-list", null);
		
		DataImportConsumer consumer = context.getBean(DataImportConsumer.class);
		
		consumer.setBrokerList(brokerList);
		consumer.addBrokerConfig("admin-ga-app-client-id", zetaUtil.getHelper().getAppId());
		consumer.start();
		
		/* start an executor service */
		ExecutorService executor = Executors.newFixedThreadPool(1);
		executor.submit(consumer);

		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				executor.shutdown();
				try {
					executor.awaitTermination(5000, TimeUnit.MILLISECONDS);
					DataImportConsumer producer = SpringApplicationContext.getContext().getBean(DataImportConsumer.class);
					producer.stopProducer();
				} catch (InterruptedException e) {
					e.printStackTrace();
					logger.error("Exception occured in DE DataImport App :",e);
				}
			}
		});

	}

}

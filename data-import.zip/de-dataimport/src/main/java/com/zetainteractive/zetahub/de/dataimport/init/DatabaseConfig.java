/**
 * DatabaseConfig.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.init;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:27:40 PM
 * @Version	   : 1.7
 * @Description: "DatabaseConfig" is used for 
 * 
 *
 */
@Configuration
public class DatabaseConfig {
	/**
	 * This method will create jdbcTemplate bean which will be autowired.
	 *
	 * @param dataSource the data source
	 * @return the NamedParameterJdbcTemplate
	 * @throws Exception 
	 */
	@Bean(name = "whJdbcTemplate")
	@Scope("prototype")
	public JdbcTemplate whJdbcTemplate() throws Exception {
		return new JdbcTemplate(ZetaUtil.getHelper().getWarehouseDataSource());
	}
	
	/**
	 * This method will create jdbcTemplate bean which will be autowired.
	 *
	 * @param dataSource the data source
	 * @return the NamedParameterJdbcTemplate
	 * @throws Exception 
	 */
	@Bean(name = "JdbcTemplate")
	@Scope("prototype")
	public JdbcTemplate JdbcTemplate() throws Exception {
		return new JdbcTemplate(ZetaUtil.getHelper().getCustomerDataSource());
	}
	
	
}

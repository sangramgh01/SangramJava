/**
 * DataImportProcess.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.process;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.de.commons.BatchStatus;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DEConstants;
import com.zetainteractive.zetahub.de.commons.DataImportConstants;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.dao.DataImportQueryBuilder;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimport.service.DataImportService;
import com.zetainteractive.zetahub.de.dataimport.util.DataImportDependencyCalls;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 26, 2016 12:49:27 PM
 * @Version	   : 1.7
 * @Description: "DataImportProcess" is used for 
 * 
 *
 */
@Component
@Scope("prototype")
public class DataImportProcess {
	
	@Autowired
	DataImportService dataImportService;
	
	@Autowired
	DataImportDependencyCalls dependencyCalls;
	
	private static ZetaLogger logger = new ZetaLogger(DataImportProcess.class);
	
	public ThreadLocal<String> threadLocalProcessTableName = new ThreadLocal<String>();
	public static String EMAIL_DATATYPE="EMAIL";
	public static String SMS_DATATYPE="SMS";
	public static final String EMAIL_AUDIENCE="Email Address Audience";
	public static final String SMS_AUDIENCE="Sms Audience";
	public static final String BASE_EMAIL = "AUDIENCE_EMAIL";
	public static final String BASE_SMS = "AUDIENCE_SMS";
	public static final String EMAIL_ADDRESS_DATATYPE="EMAIL_ADDRESS";
	public static final String SMSNBR_DATATYPE="SMS_NUMBER";
	public final Lock queueLock = new ReentrantLock();	 
	public DataImportQueryBuilder dataImportQueryBuilder = new DataImportQueryBuilder();
	public List<String> emailProcessTable=new ArrayList<String>();
	public List<String> smsProcessTable=new ArrayList<String>();
	public final Character COMPLETED = 'C';
	public final Character ERROR = 'E';
	/**
	 * 
	 * Method Name 	: doImport
	 * Description 	: The Method "doImport" is used for 
	 * Date    		: Sep 26, 2016, 3:15:43 PM
	 * @param dataImportDTO
	 * @param  		:
	 * @return 		: void
	 * @throws DataImportException 
	 * @throws SQLException 
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DataImportDTO doImport(DataImportDTO dataImportDTO) throws DataImportException, SQLException, Exception {
		logger.debug("Begin : "+getClass().getName()+" : doImport(DataImportDTO dataImportDTO)");
		List<Column> columns  = dataImportDTO.getColumns();
		List<Column> keyColumns = new ArrayList<>();
		List<Column> notNullKeyColumns = new ArrayList<>();		
		long totalCount = 0L;
		boolean isNotNullUpdatedQuery = false;
		String query = null;
		String updateQuery = null;
		String tempTableName = null;
		boolean isNew = true;
		List<FileActivityBO> fileActivities = null;
		FileDefinitionBO fileDefintionBO = dataImportDTO.getFileDefinitionBO();
		boolean isErrored = false;
		String errMessage = null;
		try {
			fileActivities = dataImportDTO.getFileActivities();
			logger.info("Executing import for  File Definition :: "+dataImportDTO.getFileDefinitionId());
			tempTableName = dataImportDTO.getTempTableName();
			
			if(fileDefintionBO.getTableDisposition()!=null){
				isNew = !fileDefintionBO.getTableDisposition().equalsIgnoreCase("Append");
			}else{
				isNew =true;
			}
			
			
			
			totalCount = dataImportService.getTempTableCount(tempTableName);
			
			if(totalCount==0){
				throw new Exception("There is no data in temp table.");
			}
			// get key columns into  a list
			keyColumns = dataImportService.getKeyColumns(columns);
			// get not null key columns into a list
			if(!keyColumns.isEmpty())
				notNullKeyColumns = dataImportService.getNotNullKeyColumns(keyColumns);
				
			HashMap<String,String> defaultValuesMap = dataImportService.getPhysicalColumnsAndDefaultValues(dataImportDTO.getBaseTablePhysicalName());
			
			if (notNullKeyColumns.size() > 0) {

				String columnsQuery = dataImportQueryBuilder.prepareArrayToCSVWithLower(notNullKeyColumns);

				String duplicateQuery = dataImportQueryBuilder.prepareFindDuplicateAudience(columnsQuery, tempTableName);
				logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareFindDuplicateAudiencePerson::" + duplicateQuery);
				long duplicateCount = dataImportService.getDuplicateAudienceCount(duplicateQuery);

				if (duplicateCount>0) {
					totalCount=totalCount-duplicateCount;
				}
				isNotNullUpdatedQuery = true;
				updateQuery = dataImportQueryBuilder.prepareUpdateAudienceMemberNewOrUpdate(dataImportDTO,notNullKeyColumns, tempTableName);
				logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareUpdateAudienceMemberPersonNewOrUpdate::"+ updateQuery);
			} else {
				isNotNullUpdatedQuery = false;
				logger.info("List Id:: " + dataImportDTO.getListid()+ "  prepareUpdateAudienceMemberPersonNewOrUpdate Not Executed due to dont have key columns in mapped columns.hence duplicates may exist.");
			}

			String emailColumn = "", smsColumn = "";
			Column column = null;
			for (int i = 0; i < columns.size(); i++) {
				column = columns.get(i);
				if (column.getDataType().toLowerCase().contains(EMAIL_DATATYPE.toLowerCase())) {
					emailColumn = column.getColumnName();
					
					logger.info("List Id:: " + dataImportDTO.getListid()+ "  ===================================== EMAIL queries start =====================================");
					threadLocalProcessTableName.set("ADHOC_" + dataImportDTO.getListid() + "_"+ column.getCategoryType()+ "_IMPORT_STAGING_EMAILADDRESS_PROCESSING");
					
					long audTypeIdEmail = dataImportService.getAudienceId(EMAIL_AUDIENCE);
					logger.info("Audience type id for email aud :: "+audTypeIdEmail);
					queueLock.lock();
					try {
						if (isNotNullUpdatedQuery) {
							long existingCount=dataImportService.executeUpdateForDuplicateAudience(updateQuery);
							dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setExistingRecordsCount(existingCount);
							isNotNullUpdatedQuery=false;
						}
						emailProcessTable.add(threadLocalProcessTableName.get());
						dataImportService.executeEMAILQueries(column, dataImportDTO, emailColumn, audTypeIdEmail,threadLocalProcessTableName.get());
					} finally {
						queueLock.unlock();
					}

					if (!(dataImportDTO.getBaseTablePhysicalName().equals(BASE_EMAIL)|| dataImportDTO.getBaseTablePhysicalName().equals(BASE_SMS))) {
						query = dataImportQueryBuilder.prepareDeleteTargetAudienceMembersToAddresses(column, dataImportDTO, 1,emailColumn);
						logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareDeleteTargetAudienceMembersToAddresses::"+ query);
						dataImportService.deleteTargetAudienceMembersToAddresses(query);

						String countQuery = dataImportQueryBuilder.getCountQueryForEmail(tempTableName,emailColumn,column,dataImportDTO.getIsInvalidRecordsExist());
						long count = dataImportService.executeCountQuery(countQuery);
						if (count>0) {
							query = dataImportQueryBuilder.prepareInsertTargetAudienceMembersToAddresses(column,1,dataImportDTO,tempTableName);
							
							logger.info("List Id:: " + dataImportDTO.getListid()+ "  prepareInsertTargetAudienceMembersToAddresses::" + query);
							dataImportService.executeInsertToTarget(query);
						}
					}

				}
				if (column.getDataType().toLowerCase().contains(SMS_DATATYPE.toLowerCase())) {
					smsColumn = column.getColumnName();
					long audTypeIdSMS = dataImportService.getAudienceId(SMS_AUDIENCE);
					logger.info("Audience type id for sms aud :: "+audTypeIdSMS);
					logger.info("List Id:: " + dataImportDTO.getListid()+ "  ===================================== SMS queries start =====================================");
					
					threadLocalProcessTableName.set("ADHOC_" + dataImportDTO.getListid() + "_"+ column.getCategoryType()+ "_IMPORT_STAGING_SMSADDRESS_PROCESSING");
					
					queueLock.lock();
					try {
						if (isNotNullUpdatedQuery) {
							long existingCount=dataImportService.executeUpdateForDuplicateAudience(updateQuery);
							dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setExistingRecordsCount(existingCount);
							isNotNullUpdatedQuery=false;
						}
						smsProcessTable.add(threadLocalProcessTableName.get());
						dataImportService.executeSMSQueries(column, dataImportDTO, smsColumn, audTypeIdSMS,threadLocalProcessTableName.get());
					} finally {
						queueLock.unlock();
					}
					
					if (!(dataImportDTO.getBaseTablePhysicalName().equals(BASE_EMAIL)|| dataImportDTO.getBaseTablePhysicalName().equals(BASE_SMS))) {

						query = dataImportQueryBuilder.prepareDeleteTargetAudienceMembersToAddresses(column,dataImportDTO, 3,smsColumn);
						logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareDeleteTargetAudienceMembersToAddresses::"	+ query);
						dataImportService.deleteTargetAudienceMembersToAddresses(query);
						
						String countQuery = dataImportQueryBuilder.getCountQueryForSMS(tempTableName,smsColumn,column,dataImportDTO.getIsInvalidRecordsExist());
						long count = dataImportService.executeCountQuery(countQuery);
						if (count > 0) {
							query = dataImportQueryBuilder.prepareInsertTargetAudienceMembersToAddresses(column,3, dataImportDTO,tempTableName);
							
							logger.info("List Id:: " + dataImportDTO.getListid()+ "  prepareInsertTargetAudienceMembersToAddresses::" + query);
							dataImportService.executeInsertToTarget(query);
						}

					}
				}
			}
			queueLock.lock();
			try {
				if (isNotNullUpdatedQuery) {
					long existingCount=dataImportService.executeUpdateForDuplicateAudience(updateQuery);
					dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setExistingRecordsCount(existingCount);
					isNotNullUpdatedQuery=false;
				}
				logger.info("List Id:: " + dataImportDTO.getListid()+ "  ===================================== GENERAL queries start =====================================");
				query = dataImportQueryBuilder.prepareInsertNewAudienceMember(dataImportDTO, tempTableName);
				logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInsertNewAudienceMember::" + query);
				dataImportService.insertNewAudienceMember(query);
				
				if (!(dataImportDTO.getBaseTablePhysicalName().equals(BASE_EMAIL)|| dataImportDTO.getBaseTablePhysicalName().equals(BASE_SMS))) {
					query = dataImportQueryBuilder.prepareInsertNewAudience(dataImportDTO,tempTableName);
					logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInsertNewAudiencePerson::" + query);
					dataImportService.insertNewAudience(query);

					String seqCountQuery = "SELECT count(*) FROM " + tempTableName + " WHERE ISNEW_2 = TRUE";
					long count = dataImportService.getCountForNew(seqCountQuery);
					if (count > 0) {
						query = dataImportQueryBuilder.prepareInsertDirectMailTarget(dataImportDTO, tempTableName);
						
						logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInsertDirectMailTarget::" + query);
						dataImportService.insertDirectMailTarget(query);

						query = dataImportQueryBuilder.prepareInsertCallCentreTarget(dataImportDTO, tempTableName);
						if (dataImportDTO.getIsInvalidRecordsExist()) {
							query = query + "  AND ISVALID='Y'";
						}
						logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInsertCallCentreTarget::" + query);
						dataImportService.insertCallCentreTarget(query);
						query = dataImportQueryBuilder.prepareInsertExportChannelTarget(dataImportDTO, 5, tempTableName);
						if (dataImportDTO.getIsInvalidRecordsExist()) {
							query = query + "  AND ISVALID='Y'";
						}
						logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInsertExportChannelTarget::" + query);
						dataImportService.insertExportChannelTarget(query);
					}
				}
				if (notNullKeyColumns.size() > 0) {
					query = dataImportQueryBuilder.prepareUpdateMemberAttributes(dataImportDTO, tempTableName, notNullKeyColumns);
					logger.info("List Id:: " + dataImportDTO.getListid() + "   prepareUpdateMemberAttributes::" + query);
					String[] notNullColumns = { "AUDIENCE_MEMBER_ID_2" };
					long duplicate_count = dataImportService.deleteDuplicateRecords(notNullColumns, tempTableName, dataImportDTO,defaultValuesMap);
					logger.info("List Id:: " + dataImportDTO.getListid() + "   Duplicates Removed::" + duplicate_count);
					dataImportService.updateMemberAttributes(query);
				} else {
					logger.info("List Id:: " + dataImportDTO.getListid()+ "  prepareUpdateMemberAttributes Not Executed due to dont have key columns in mapped columns.hence duplicates may exist.");
				}

				query = dataImportQueryBuilder.prepareInactiveOldTargets(dataImportDTO, tempTableName);
				logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareInactiveOldTargets::" + query);
				dataImportService.inactiveOldTargets(query);
			}catch (Exception e) {
				logger.error(e.getMessage(),e);
				throw new DataImportException(e.getMessage(),e);
			} finally {
				queueLock.unlock();
			}
			if(dataImportDTO.getImportType().equalsIgnoreCase("ADHOCIMPORT")){
				boolean isTableExist = dataImportService.checkIsTableExist("ADHOC_"+dataImportDTO.getFileDefinitionId());
				isNew = !isTableExist;
				doListTableOperations(isNew,dataImportDTO,defaultValuesMap,"ADHOC_"+dataImportDTO.getFileDefinitionId()); 
			}
			if (columns != null && !columns.isEmpty()) {// unsub emails and sms.
				long unsubCount=0L;
				for (Column unsubColumn:columns) {
					if (unsubColumn.isIsUnsub()) {
						logger.info("Unsubscribing the list Start.");
						unsubCount=unsubCount+dataImportService.doUnsubResubColumn(dataImportDTO, unsubColumn, false);
						logger.info("Unsubscribing the list End.");
					}
				}
				dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setUnsubRecordsCount(unsubCount);
			}
			
			if(dataImportDTO.getFileAction()!=null && dataImportDTO.getFileAction().equals(DEConstants.FILE_ACTION_INSERT)){
				//DO IMPORT BY CREATING TABLE
				
				if(fileDefintionBO.getTableName() != null && !fileDefintionBO.getTableName().trim().isEmpty()){
					if(fileDefintionBO.getTableDisposition().equalsIgnoreCase("Append")){
						boolean isTableExist = dataImportService.checkIsTableExist(fileDefintionBO.getTableName());
						isNew = !isTableExist;
					}else{
						isNew = true;
					}
					
					doListTableOperations(isNew,dataImportDTO,defaultValuesMap,fileDefintionBO.getTableName().trim()); 
				}else{
					logger.info("Table name not specified for creation");
				}
			}
			String batchIds=null;
			for (FileActivityBO fileActivityBO : fileActivities) {
				fileActivityBO.setStatus(COMPLETED);
				fileActivityBO.setMessage("Activity Completed.");
				fileActivityBO.setCompletedOn(new Date());
				fileActivityBO.setUpdatedBy(dataImportDTO.getFileDefinitionBO().getUpdatedBy());
				batchIds=fileActivityBO.getBatchId()+"";
				logger.info("Updating File Activity :: "+fileActivityBO.getFileActivityID()+" with Status :: "+fileActivityBO.getStatus());
				this.updateFileActivity(fileActivityBO);
			}
			logger.info("Verifying workflow is associated or not in base mappings. Import Type :: "+dataImportDTO.getImportType()+" Workflow associated  ::"+dataImportDTO.getIsWorkFlowAssociated() );
			if(batchIds!=null && batchIds.trim().length()>0 && dataImportDTO.getImportType().equalsIgnoreCase(DataImportConstants.BATCH_IMPORT_TYPE.toString())){
				if(dataImportDTO.getIsWorkFlowAssociated() && dataImportDTO.getWorkFlowID()>0 && fileActivities.get(0).getStatus()==COMPLETED)
					dataImportService.insertWorkFlowActivity(dataImportDTO,batchIds);
				else
					logger.info("There is no work flow associated to process.");
			}else{
				logger.info("There is no batch ids for activity to trigger associated work flow.");
			}
			
			logger.info("Executing File Activities Completed for list : " + dataImportDTO.getListid());
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setNewRecordsCount(totalCount-dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getExistingRecordsCount());
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setTotalRecordsCount(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getTotalRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount());
			dependencyCalls.updateFileDefinitionStatus(COMPLETED,dataImportDTO,null);
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.COMPLETED.getValue());
			
			dataImportService.updateTriggers(fileDefintionBO.getFileDefinitionID());
		}catch(DataImportException die){	
			logger.error("Processing File Error  :-("+die.getMessage(), die);
			errMessage = die.getMessage();
			isErrored = true;
			throw die;
		} catch (NullPointerException ne) {
			logger.error("Processing large File Error in Vertica Level :-("+ne.getMessage(), ne);
			errMessage = ne.getMessage();
			isErrored = true;
			throw new DataImportException("Processing large File Error in Vertica Level"+ne.getMessage(), ne);
		} catch (Exception e) {
			logger.error(" Vertica DB Level Error - GEN Exception"+e.getMessage(), e);
			errMessage = e.getMessage();
			isErrored = true;
			throw new DataImportException("Vertica DB Level Error"+e.getMessage(), e);
		} finally {
			dataImportService.dropTempTables(tempTableName,smsProcessTable,emailProcessTable);
			
			
			if(isErrored){
				if(fileActivities!=null){
					for (FileActivityBO fileActivityBO : fileActivities) {
						fileActivityBO.setStatus(ERROR);
						fileActivityBO.setMessage(errMessage);
						fileActivityBO.setCompletedOn(new Date());
						fileActivityBO.setUpdatedBy(dataImportDTO.getFileDefinitionBO().getUpdatedBy());
						logger.info("Updating File Activity :: "+fileActivityBO.getFileActivityID()+" with Status :: "+fileActivityBO.getStatus());
						this.updateFileActivity(fileActivityBO);
					}
				}
				dependencyCalls.updateFileDefinitionStatus( 'E',dataImportDTO,errMessage);
				dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.ERRORED.getValue());
			}
		}
		logger.debug("End : "+getClass().getName()+" : doImport(DataImportDTO dataImportDTO)");
		return dataImportDTO;
	}
	/**
	 * 
	 * @param isNew
	 * @param dataImportDTO
	 * @param defaultValuesMap
	 * @throws SQLException
	 */
	private void doListTableOperations(boolean isNew,DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap,String listTableName) throws SQLException {
		String query = null;
		
		if (isNew == true) {
			try {
				dataImportService.dropListTable("DROP TABLE IF EXISTS "+listTableName);
			} catch (Exception e) {
				logger.info("Table is not exist to drop :: "+listTableName);
			}

			query = dataImportQueryBuilder.prepareStageCreateTableQuery(dataImportDTO,defaultValuesMap,listTableName);
			logger.debug("List Id:: " + dataImportDTO.getListid() + "  prepareCreateTableQuery::" + query);
			dataImportService.createListTable(query);
		} else {
			String columnsQuery = "";
			columnsQuery = dataImportService.getTableColumnsInfo("SELECT column_name FROM V_CATALOG.COLUMNS WHERE TABLE_NAME ='" + listTableName + "'");
				
			if (columnsQuery != null && columnsQuery.length() != 0 && columnsQuery.endsWith(",")){
				columnsQuery = columnsQuery.substring(0, columnsQuery.length() - 1);
			}
			
			String querys[] = dataImportQueryBuilder.prepareStageAlterTableQuery(dataImportDTO, columnsQuery,defaultValuesMap,listTableName);
			if (querys != null && querys.length > 0) {
				logger.info("List Id:: " + dataImportDTO.getListid() + "   Alter Temp Table ....................");
				try {
					dataImportService.executeAlterQueries(querys);
				} catch (Exception E) {
					logger.error("Error while alter temp table :: " + dataImportDTO.getTempTableName());
				}
			}
		}
		if (dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase(BASE_EMAIL) || dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase(BASE_SMS)) {
			query = dataImportQueryBuilder.prepareStageUpdateTableQuery(dataImportDTO,threadLocalProcessTableName.get());
			logger.debug("List Id:: " + dataImportDTO.getListid() + "  prepareStageUpdateTableQuery::" + query);
			dataImportService.stageUpdateTableQuery(query);
		}
		if (isNew == true) {
			query = dataImportQueryBuilder.prepareStageInsertTableQuery(dataImportDTO,listTableName);
			logger.debug("List Id:: " + dataImportDTO.getListid() + "  prepareStageInsertTableQuery::" + query);
			dataImportService.stageInsertTableQuery(query);
		} else {
			query="DELETE FROM "+listTableName+" WHERE AUDIENCE_MEMBER_ID IN ( SELECT AUDIENCE_MEMBER_ID  FROM "+listTableName+"  ADHOC INNER JOIN "+dataImportDTO.getTempTableName()+" STAGING ON STAGING.AUDIENCE_MEMBER_ID_2= ADHOC.AUDIENCE_MEMBER_ID)";
			logger.debug("Query for deleting data from adhoc table ::  "+query);
			long existingCount=dataImportService.executeUpdate(query);
			if(dataImportDTO.getImportType().equalsIgnoreCase("ADHOCIMPORT"))
				dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setExistingRecordsCount(existingCount);
			if(existingCount > 0)
				logger.debug("Sucessfully removed data from temp table");
			
			query = dataImportQueryBuilder.prepareStageInsertTableQueryWithoutExisting(dataImportDTO,listTableName);
			logger.debug("List Id:: " + dataImportDTO.getListid() + "  prepareStageInsertTableQueryWithoutExisting::" + query);
			int update = dataImportService.stageInsertTableQueryWithoutExisting(query);
			logger.info("List Id:: " + dataImportDTO.getListid() + "  prepareStageInsertTableQueryWithoutExisting update ::"+ update);
		}
		
	}

	/**
	 * 
	 * 
	 * Method Name 	: getFileActivity
	 * Description 	: The Method "getFileActivity" is used for 
	 * Date    		: Oct 13, 2016, 8:58:27 PM
	 * @param activityId
	 * @return
	 * @throws Exception
	 * @param  		:
	 * @return 		: FileActivityBO
	 * @throws 		:
	 */
	public FileActivityBO getFileActivity(long activityId) throws Exception {
		return dataImportService.getFileActivity(activityId);
	}
	/**
	 * 
	 * Method Name 	: updateFileActivity
	 * Description 	: The Method "updateFileActivity" is used for 
	 * Date    		: Sep 30, 2016, 6:51:40 PM
	 * @param fileActivity
	 * @param  		:
	 * @return 		: void
	 * @throws Exception 
	 * @throws 		: 
	 */
	public void updateFileActivity(FileActivityBO fileActivity) throws Exception {
		dataImportService.updateFileActivity(fileActivity);
		
	}

	/**
	 * 
	 * Method Name 	: doImportToNonAudience
	 * Description 	: The Method "doImportToNonAudience" is used for 
	 * Date    		: Oct 15, 2016, 4:54:16 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: DataImportDTO
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DataImportDTO doImportToNonAudience(DataImportDTO dataImportDTO) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : doImportToNonAudience(DataImportDTO dataImportDTO)");
		List<FileActivityBO> fileActivities = null;
		try{
			fileActivities = dataImportDTO.getFileActivities();
			String tempTableName = dataImportDTO.getTempTableName();
		    Long tempTableCount = dataImportService.getTempTableCount(tempTableName);
		    logger.info("Temp table count :: "+tempTableCount);
			if(tempTableCount==0){
				throw new Exception("There is no data in temp table.");
			}
			logger.info("Executing import for  File Definition :: "+dataImportDTO.getFileDefinitionId());
			logger.debug("Non Audience Data Import Start::::  " + new Date());
			String physicalTableName = dataImportDTO.getBaseTablePhysicalName();
			HashMap<String, String> physicalColumnsMap = dataImportService.getPhysicalColumnsAndDefaultValues(physicalTableName);
			Set<String> columnsSet = physicalColumnsMap.keySet();
			String[] physicalColumns = columnsSet.toArray(new String[columnsSet.size()]);
			boolean isAudienceMemberIdExist = dataImportQueryBuilder.checkAudienceMemeberId(physicalColumns);
			boolean isAudienceTypeIdExist = dataImportQueryBuilder.checkAudienceTypeId(physicalColumns);
			boolean isBatchIdExist = dataImportQueryBuilder.checkBatchId(physicalColumns);
			boolean isSrcFileIdExist = dataImportQueryBuilder.checkSrcFileId(physicalColumns);
			boolean isCreattionDTExist = dataImportQueryBuilder.checkCreationDT(physicalColumns);
			boolean isModifiedDTExist = dataImportQueryBuilder.checkModifiedDT(physicalColumns);
			logger.debug("Non Audience Data import start to base table::::  " + new Date());
			String insertQuery = dataImportQueryBuilder.prepareInsertNonAudienceTableQuery(dataImportDTO,isAudienceMemberIdExist,isAudienceTypeIdExist,isBatchIdExist,isSrcFileIdExist,isCreattionDTExist,isModifiedDTExist);
			logger.info("Non audience import query :: "+insertQuery);
			int result  = dataImportService.executeUpdate(insertQuery);
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setNewRecordsCount(Long.valueOf(result));
			dataImportDTO.getFileDefinitionBO().getFileSummaryBO().setTotalRecordsCount(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getTotalRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount());
			logger.info("Successfully inserted :: "+result+" rows in dimension table.");
			logger.debug("Non Audience Data Import result :: "+result+"end::::  " + new Date());
			for (FileActivityBO fileActivityBO : fileActivities) {
				fileActivityBO.setStatus(COMPLETED);
				fileActivityBO.setMessage("Activity Completed.");
				
			}
			dependencyCalls.updateFileDefinitionStatus(COMPLETED,dataImportDTO,null);
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.COMPLETED.getValue());
			return dataImportDTO;
		}catch(Exception de){
			logger.error(de.getLocalizedMessage(),de);
			if(fileActivities!=null){
				for (FileActivityBO fileActivityBO : fileActivities) {
					fileActivityBO.setStatus(ERROR);
					fileActivityBO.setMessage(de.getMessage());
				}
				
			}
			dependencyCalls.updateFileDefinitionStatus('E',dataImportDTO,de.getMessage());
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.ERRORED.getValue());
			throw new DataImportException(de.getMessage(),de);
		}finally {
			dataImportService.dropTempTables(dataImportDTO.getTempTableName(),smsProcessTable,emailProcessTable);
			if(fileActivities!=null){
				String batchIds = null;
				for (FileActivityBO fileActivityBO : fileActivities) {
					fileActivityBO.setCompletedOn(new Date());
					fileActivityBO.setUpdatedBy(dataImportDTO.getFileDefinitionBO().getUpdatedBy());
					logger.info("Updating File Activity :: "+fileActivityBO.getFileActivityID()+" with Status :: "+fileActivityBO.getStatus());
					this.updateFileActivity(fileActivityBO);
					batchIds = fileActivityBO.getBatchId()+"";
				}
				if(batchIds!=null && batchIds.trim().length()>0){
					if(dataImportDTO.getIsWorkFlowAssociated() && dataImportDTO.getWorkFlowID()>0 && fileActivities.get(0).getStatus()==COMPLETED)
						dataImportService.insertWorkFlowActivity(dataImportDTO,batchIds);
				}else{
					logger.info("There is no batch ids for activity to trigger associated work flow.");
				}
				
			}
			logger.debug("End : "+getClass().getName()+" : doImportToNonAudience(DataImportDTO dataImportDTO)");
		}
		
	}

	/**
	 * 
	 * Method Name 	: doUnsubResub
	 * Description 	: The Method "doUnsubResub" is used for 
	 * Date    		: Oct 20, 2016, 7:11:45 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: DataImportDTO
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DataImportDTO doUnsubResub(DataImportDTO dataImportDTO) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : doUnsubResub(DataImportDTO dataImportDTO)");
		List<FileActivityBO> fileActivities = null;
		List<Column> columns = dataImportDTO.getColumns();
		fileActivities = dataImportDTO.getFileActivities();
		try{
			fileActivities = dataImportDTO.getFileActivities();
			logger.info("Executing import for  File Definition :: "+dataImportDTO.getFileDefinitionId());
			if (columns != null && columns.size() > 0) {// unsub emails and sms.
				for (Column unsubColumn:columns) {
					if(unsubColumn.getDataType().equalsIgnoreCase("EMAIL") || unsubColumn.getDataType().equalsIgnoreCase("SMS")){
						if (dataImportDTO.getImportType().equals("UNSUB")) {
							logger.info("Unsubscribing the list Start.");
							dataImportService.doUnsubResubColumn(dataImportDTO, unsubColumn, false);
							logger.info("Unsubscribing the list End.");
						}else{
							logger.info("Resubscribing the list Start.");
							dataImportService.doUnsubResubColumn(dataImportDTO, unsubColumn, true);
							logger.info("Resubscribing the list End.");
						}
					}
					
				}
			}
			for (FileActivityBO fileActivityBO : fileActivities) {
				fileActivityBO.setStatus(COMPLETED);
				fileActivityBO.setMessage("Activity Completed.");
				fileActivityBO.setCompletedOn(new Date());
				fileActivityBO.setUpdatedBy(dataImportDTO.getFileDefinitionBO().getUpdatedBy());
				logger.info("Updating File Activity :: "+fileActivityBO.getFileActivityID()+" with Status :: "+fileActivityBO.getStatus());
				this.updateFileActivity(fileActivityBO);
			}
			logger.info("Executing File Activity Completed for list : " + dataImportDTO.getListid());
			dependencyCalls.updateFileDefinitionStatus(COMPLETED,dataImportDTO,null);
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.COMPLETED.getValue());
		}catch(DataImportException de){
			if(fileActivities!=null){
				for (FileActivityBO fileActivityBO : fileActivities) {
					fileActivityBO.setStatus(ERROR);
					fileActivityBO.setCompletedOn(new Date());
					fileActivityBO.setMessage(de.getMessage());
					fileActivityBO.setUpdatedBy(dataImportDTO.getFileDefinitionBO().getUpdatedBy());
					logger.info("Updating File Activity :: "+fileActivityBO.getFileActivityID()+" with Status :: "+fileActivityBO.getStatus());
					this.updateFileActivity(fileActivityBO);
				}
				
			}
			dependencyCalls.updateFileDefinitionStatus( 'E',dataImportDTO,de.getMessage());
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.ERRORED.getValue());
			throw de;
		}finally {
			dataImportService.dropTempTables(dataImportDTO.getTempTableName(),smsProcessTable,emailProcessTable);
		}
		logger.debug("End : "+getClass().getName()+" : doUnsubResub(DataImportDTO dataImportDTO)");
		return dataImportDTO;
	}

	public FileDefinitionBO getFileDefintion(long fileDefinitionId) throws DataImportException {
		
		return dataImportService.getFileDefintion(fileDefinitionId);
	}
	
}

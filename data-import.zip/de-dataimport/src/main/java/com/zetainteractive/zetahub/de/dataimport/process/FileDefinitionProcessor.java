/**
 * FileDefinitionProcessor.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.process;

import java.util.ArrayList;
import java.util.List;

import org.apache.avro.generic.GenericRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.SpringApplicationContext;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.ZetaThread;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.FileSummaryBO;
import com.zetainteractive.zetahub.de.commons.BatchStatus;
import com.zetainteractive.zetahub.de.commons.DataImportConstants;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimport.util.DataImportDependencyCalls;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * 
 * @Author	     : Krishna.Polisetti
 * @Created On  : Oct 14, 2016 8:34:38 PM
 * @Version	     : 1.7 
 * @Description  : "FileDefinitionProcessor" is used for 
 * 
 **/
@Component
@Scope("prototype")
public class FileDefinitionProcessor extends ZetaThread{
	
	private  DataImportDTO  dataImportDTO;
	private  GenericRecord data;
	private  ZetaLogger logger = new ZetaLogger(DataImportProcess.class);
	
	@Autowired
	DataImportDependencyCalls dependencyCalls;
	/**
	 * @param customerCode
	 * @param attribute
	 * @param userName
	 * @param userIdConstructor "FileDefinitionProcessor" is used for 
	 */
	public FileDefinitionProcessor(String customerCode, String attribute, String userName, int userId,DataImportDTO dataImportDTO,String contextkey,GenericRecord data) {
		super(customerCode, attribute, userName, userId);
		this.setDataImportDTO(dataImportDTO);
		this.setContextKey(contextkey);
		this.data=data;
	}

	/**
	 * 
	 * Method Name 	: doProcess
	 * Description 		: The Method "doProcess" is used for 
	 * Date    			: Oct 14, 2016, 8:57:29 PM
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	protected void doProcess() {
		logger.debug("Begin : "+getClass().getName()+" : doProcess()");
		ApplicationContext applicationContext = SpringApplicationContext.getContext();
		ObjectMapper objectMapper=new ObjectMapper();
		try {
			initializeContext(dataImportDTO.getCustCode());
			DataImportProcess dataImportProcess = applicationContext.getBean(DataImportProcess.class);
			List<FileActivityBO> fileActivitiesList = new ArrayList<>();
			for (Long id :dataImportDTO.getFileActivityIds()) {
				FileActivityBO fileActivity = dataImportProcess.getFileActivity(id);
				fileActivitiesList.add(fileActivity);
			}
			
			FileDefinitionBO fileDefinition = dataImportProcess.getFileDefintion(dataImportDTO.getFileDefinitionId());
			if(fileDefinition!=null){
				//For re-process internal message file summary details getting from dataimportdto object  
				fileDefinition.setFileSummaryBO(dataImportDTO.getFileSummaryBO() != null ? dataImportDTO.getFileSummaryBO()
						 : objectMapper.readValue(data.get("file_summary").toString(), FileSummaryBO.class));
				dataImportDTO.setFileDefinitionBO(fileDefinition);
			}else{
				logger.error("There is no file definition exists with id :: "+dataImportDTO.getFileDefinitionId());
				throw new DataImportException("There is no file definition exists with id :: "+dataImportDTO.getFileDefinitionId());
			}
				
			logger.info("File Activities size :: "+fileActivitiesList.size());
			if(!fileActivitiesList.isEmpty()){
				dataImportDTO.setFileDefinitionId(fileActivitiesList.get(0).getFileDefinitionID());
				dataImportDTO.setListid(fileActivitiesList.get(0).getFileDefinitionID());
				dataImportDTO.setFileActivities(fileActivitiesList);
				logger.info("Started processing for File Definition with id :: "+dataImportDTO.getFileDefinitionId());
				logger.info("Audience Id :: "+dataImportDTO.getAudienceId());
				if(dataImportDTO.getImportType().equalsIgnoreCase(DataImportConstants.ADHOC_IMPORT_TYPE.toString())){
					if(dataImportDTO.getListid()>0){
						logger.info("Adhoc data import is starting for List. :: "+dataImportDTO.getListid());
						dataImportDTO = dataImportProcess.doImport(dataImportDTO);
					}
					
				}else if(dataImportDTO.getImportType().equalsIgnoreCase(DataImportConstants.BATCH_IMPORT_TYPE.toString())){
					if(dataImportDTO.getFileDefinitionId()>0){
						logger.info("Batch data import is starting for File Definition ::"+dataImportDTO.getFileDefinitionId());
						dataImportDTO = dataImportProcess.doImport(dataImportDTO);
					}
				}else if(dataImportDTO.getImportType().equalsIgnoreCase("DIMENTION")){
					if(dataImportDTO.getFileDefinitionId()>0 && dataImportDTO.getAudienceId()==0){
						logger.info("Non Audience import is starting for File Definition ::"+dataImportDTO.getFileDefinitionId());
						dataImportDTO = dataImportProcess.doImportToNonAudience(dataImportDTO);
					}
				}else if(dataImportDTO.getImportType().equalsIgnoreCase("UNSUB") || dataImportDTO.getImportType().equalsIgnoreCase("RESUB")){
					if(dataImportDTO.getFileDefinitionId()>0 && dataImportDTO.getAudienceId()==0){
						logger.info(dataImportDTO.getImportType()+" is starting for File Definition ::"+dataImportDTO.getFileDefinitionId());
						dataImportDTO = dataImportProcess.doUnsubResub(dataImportDTO);
					}
				}else{
					logger.error("Import type is not specified for this file definition::"+dataImportDTO.getFileDefinitionId());
				}
			}else{
				logger.error("There are no file activities for file definition :: "+dataImportDTO.getFileDefinitionId());
			}
			
		}catch(DataImportException die){
			dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.ERRORED.getValue());
		} catch (Exception e) {
			logger.error("Exception occured while importing data for fileDefinition ::"+dataImportDTO.getFileDefinitionId(),e);
			try {
				dataImportDTO.getDataImportProgress().setImportprocess_status(BatchStatus.ERRORED.getValue());
				dependencyCalls.updateFileDefinitionStatus( 'E',dataImportDTO,e.getMessage());
			} catch (DataImportException e1) {
				logger.error("Unable to update filedefinition status."+e.getMessage(),e);
			}
		}
		logger.debug("End : "+getClass().getName()+" : doProcess()");
		
	}

	/**
	 * 
	 * Method Name 	: initializeContext
	 * Description 	: The Method "initializeContet" is used for 
	 * Date    		: Dec 9, 2016, 1:02:10 PM
	 * @param custCode
	 * @param  		:
	 * @return 		: void
	 * @throws Exception 
	 * @throws RestClientException 
	 * @throws 		: 
	 */
	private void initializeContext(String customerCode) throws RestClientException, Exception {
			
			if(ZetaUtil.getHelper().getCustomerID()==null || !ZetaUtil.getHelper().getCustomerID().equalsIgnoreCase(customerCode) ){
				ZetaUtil.getHelper(customerCode, null);
			}
			String userName = ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser","dataimportuser");

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), customerCode);
			httpHeaders.add(BootStarterConstants.USERNAME.toString(), userName);
			UserBO user = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("security") + "/getUserByName/" + userName, HttpMethod.GET,
							new HttpEntity<>(httpHeaders), UserBO.class).getBody();

			if (user != null) {
				ZetaUtil.getHelper().setUser(user);
			} else {
				throw new Exception("user not available with username :: " + userName);
			}
		
		
	}

	/**
	 * @return the dataImportDTO
	 */
	public DataImportDTO getDataImportDTO() {
		return dataImportDTO;
	}

	/**
	 * @param dataImportDTO the dataImportDTO to set
	 */
	public void setDataImportDTO(DataImportDTO dataImportDTO) {
		this.dataImportDTO = dataImportDTO;
	}

}

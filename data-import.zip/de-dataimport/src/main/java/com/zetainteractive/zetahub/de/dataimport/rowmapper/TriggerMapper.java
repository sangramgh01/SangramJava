package com.zetainteractive.zetahub.de.dataimport.rowmapper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.zetahub.commons.domain.FileSchedule;
import com.zetainteractive.zetahub.commons.domain.RelativeSchedule;
import com.zetainteractive.zetahub.commons.domain.Schedule;
import com.zetainteractive.zetahub.commons.domain.Trigger;

public class TriggerMapper implements RowMapper<Trigger>{
 
	@Override
	public Trigger mapRow(ResultSet rs, int rowNum) throws SQLException {
		Trigger trigger = new Trigger();
		ObjectMapper objMapper = new ObjectMapper();
		char triggerType = '\0';
			trigger.setTriggerID(rs.getLong("triggerid"));
			trigger.setConversationId(rs.getLong("conversationid"));
			trigger.setWaveId(rs.getLong("waveid"));
			if(rs.getString("triggertype") != null){
				triggerType = rs.getString("triggertype").charAt(0);
				trigger.setTriggerType(triggerType);
			}
			trigger.setTriggerType(triggerType);
			trigger.setFileDefinitionId(rs.getLong("filedefinitionid"));
			trigger.setParentTriggerId(rs.getInt("parenttriggerid"));
			trigger.setStatus(rs.getString("status"));
			trigger.setScheduleNextDue(rs.getTimestamp("schedulenextdue"));
			trigger.setCreatedBy(rs.getString("createdby"));
			trigger.setUpdatedBy(rs.getString("updatedby"));
			trigger.setCreateDate(rs.getTimestamp("createdate"));
			trigger.setUpdateDate(rs.getTimestamp("updatedate"));
			trigger.setLastRundate(rs.getTimestamp("lastrundate"));
			try {
				if(triggerType != '\0' && triggerType == 'R'){
						trigger.setScheduleJson(objMapper.readValue(rs.getString("triggerjson"),RelativeSchedule.class));
				}else if(triggerType != '\0' && triggerType == 'S'){
					trigger.setScheduleJson(objMapper.readValue(rs.getString("triggerjson"),Schedule.class));
				}else{
					trigger.setScheduleJson(objMapper.readValue(rs.getString("triggerjson"),FileSchedule.class));
				}
			}catch (IOException e) {
					e.printStackTrace();
				}
		return trigger;
	}
	

}

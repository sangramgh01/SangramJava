/**
 * DataImportService.java :
 * Copyright (c) 2016 Zeta Interactive.
 * #8-2-120/113,Plot No:99,Road No :2 ,Sanali Info Park,Ground Floor of B & C Block,
 * Banjara Hills, Hyderabad,T.S, 500 034, India.
 * All rights reserved.
 * This software is the confidential and proprietary information of Zeta Interactive Systems India Pvt.Ltd.,"Confidential Information". 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with Zeta Interactive.
 * 
 **/


package com.zetainteractive.zetahub.de.dataimport.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.domain.ListEntry;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:54:02 PM
 * @Version	   : 1.7
 * @Description: "DataImportService" is used for 
 * 
 *
 */
public interface DataImportService {

	/**
	 * 
	 * Method Name 	: getTempTableCount
	 * Description 	: The Method "getTempTableCount" is used for 
	 * Date    		: Sep 26, 2016, 9:44:22 PM
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long getTempTableCount(String tempTableName) throws SQLException;

	/**
	 * 
	 * Method Name 	: getKeyColumns
	 * Description 	: The Method "getKeyColumns" is used for 
	 * Date    		: Sep 26, 2016, 9:44:29 PM
	 * @param columns
	 * @return
	 * @param  		:
	 * @return 		: List<Column>
	 * @throws 		: 
	 */
	List<Column> getKeyColumns(List<Column> columns);

	/**
	 * 
	 * Method Name 	: getNotNullKeyColumns
	 * Description 	: The Method "getNotNullKeyColumns" is used for 
	 * Date    		: Sep 26, 2016, 9:44:35 PM
	 * @param keyColumns
	 * @return
	 * @param  		:
	 * @return 		: List<Column>
	 * @throws 		: 
	 */
	List<Column> getNotNullKeyColumns(List<Column> keyColumns);

	/**
	 * 
	 * Method Name 	: getDuplicateAudienceCount
	 * Description 	: The Method "getDuplicateAudienceCount" is used for 
	 * Date    		: Sep 26, 2016, 9:44:48 PM
	 * @param duplicateQuery
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long getDuplicateAudienceCount(String duplicateQuery) throws SQLException;

	/**
	 * 
	 * Method Name 	: getAudienceId
	 * Description 	: The Method "getAudienceId" is used for 
	 * Date    		: Sep 26, 2016, 9:45:00 PM
	 * @param emailAudience
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	long getAudienceId(String emailAudience) throws Exception;

	/**
	 * 
	 * Method Name 	: executeUpdateForDuplicateAudience
	 * Description 	: The Method "executeUpdateForDuplicateAudience" is used for 
	 * Date    		: Sep 26, 2016, 9:45:06 PM
	 * @param updateQuery
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	int executeUpdateForDuplicateAudience(String updateQuery) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeEMAILQueries
	 * Description 	: The Method "executeEMAILQueries" is used for 
	 * Date    		: Sep 26, 2016, 9:45:10 PM
	 * @param column
	 * @param dataImportDTO
	 * @param emailColumn
	 * @param audTypeIdEmail
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	void executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn, long audTypeIdEmail,String processingTableName) throws SQLException, DataImportException;

	/**
	 * 
	 * Method Name 	: deleteTargetAudienceMembersToAddresses
	 * Description 	: The Method "deleteTargetAudienceMembersToAddresses" is used for 
	 * Date    		: Sep 26, 2016, 9:45:21 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void deleteTargetAudienceMembersToAddresses(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeCountQuery
	 * Description 	: The Method "executeCountQuery" is used for 
	 * Date    		: Sep 26, 2016, 9:45:24 PM
	 * @param countQuery
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long executeCountQuery(String countQuery) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeInsertToTarget
	 * Description 	: The Method "executeInsertToTarget" is used for 
	 * Date    		: Sep 26, 2016, 9:45:33 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void executeInsertToTarget(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeSMSQueries
	 * Description 	: The Method "executeSMSQueries" is used for 
	 * Date    		: Sep 26, 2016, 9:45:40 PM
	 * @param column
	 * @param dataImportDTO
	 * @param smsColumn
	 * @param audTypeIdSMS
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	void executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName) throws SQLException, DataImportException;

	/**
	 * 
	 * Method Name 	: dropTempTables
	 * Description 	: The Method "dropTempTables" is used for 
	 * Date    		: Sep 26, 2016, 9:55:15 PM
	 * @param tempTableName
	 * @param smsProcessTable
	 * @param emailProcessTable
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertNewAudience
	 * Description 	: The Method "insertNewAudience" is used for 
	 * Date    		: Sep 27, 2016, 12:43:04 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void insertNewAudience(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: getCountForNew
	 * Description 	: The Method "getCountForNew" is used for 
	 * Date    		: Sep 27, 2016, 12:50:34 PM
	 * @param seqCountQuery
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		: 
	 */
	long getCountForNew(String seqCountQuery) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertDirectMailTarget
	 * Description 	: The Method "insertDirectMailTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:50:40 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void insertDirectMailTarget(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertCallCentreTarget
	 * Description 	: The Method "insertCallCentreTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:51:10 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void insertCallCentreTarget(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertExportChannelTarget
	 * Description 	: The Method "insertExportChannelTarget" is used for 
	 * Date    		: Sep 27, 2016, 12:51:21 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void insertExportChannelTarget(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 	: The Method "deleteDuplicateRecords" is used for 
	 * Date    		: Sep 27, 2016, 12:51:48 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	long deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap) throws DataImportException, SQLException;

	/**
	 * 
	 * Method Name 	: inactiveOldTargets
	 * Description 	: The Method "inactiveOldTargets" is used for 
	 * Date    		: Sep 27, 2016, 12:54:09 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void inactiveOldTargets(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: updateMemberAttributes
	 * Description 	: The Method "updateMemberAttributes" is used for 
	 * Date    		: Sep 27, 2016, 12:55:01 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void updateMemberAttributes(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: insertNewAudienceMember
	 * Description 	: The Method "insertNewAudienceMember" is used for 
	 * Date    		: Sep 27, 2016, 12:56:08 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void insertNewAudienceMember(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: getTableColumnsInfo
	 * Description 	: The Method "getTableColumnsInfo" is used for 
	 * Date    		: Sep 27, 2016, 3:19:13 PM
	 * @param string
	 * @return
	 * @param  		:
	 * @return 		: String
	 * @throws SQLException 
	 * @throws 		: 
	 */
	String getTableColumnsInfo(String string) throws SQLException;

	/**
	 * 
	 * Method Name 	: executeAlterQueries
	 * Description 	: The Method "executeAlterQueries" is used for 
	 * Date    		: Sep 27, 2016, 3:21:28 PM
	 * @param querys
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void executeAlterQueries(String[] querys) throws SQLException;

	/**
	 * 
	 * Method Name 	: dropListTable
	 * Description 	: The Method "dropListTable" is used for 
	 * Date    		: Sep 27, 2016, 3:28:14 PM
	 * @param string
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void dropListTable(String string) throws SQLException;

	/**
	 * 
	 * Method Name 	: createListTable
	 * Description 	: The Method "createListTable" is used for 
	 * Date    		: Sep 27, 2016, 3:28:26 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void createListTable(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: stageUpdateTableQuery
	 * Description 	: The Method "stageUpdateTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:31:41 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void stageUpdateTableQuery(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: stageInsertTableQuery
	 * Description 	: The Method "stageInsertTableQuery" is used for 
	 * Date    		: Sep 27, 2016, 3:31:53 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void stageInsertTableQuery(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: stageInsertTableQueryWithoutExisting
	 * Description 	: The Method "stageInsertTableQueryWithoutExisting" is used for 
	 * Date    		: Sep 27, 2016, 3:32:03 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: int
	 * @throws SQLException 
	 * @throws 		: 
	 */
	int stageInsertTableQueryWithoutExisting(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: getPhysicalColumnsAndDefaultValues
	 * Description 	: The Method "getPhysicalColumnsAndDefaultValues" is used for 
	 * Date    		: Sep 28, 2016, 1:14:42 PM
	 * @param baseTablePhysicalName
	 * @return
	 * @param  		:
	 * @return 		: HashMap<String,String>
	 * @throws Exception 
	 * @throws 		: 
	 */
	HashMap<String, String> getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName) throws Exception;

	/**
	 * 
	 * Method Name 	: dropProcessTable
	 * Description 	: The Method "dropProcessTable" is used for 
	 * Date    		: Sep 28, 2016, 8:14:39 PM
	 * @param string
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	boolean dropProcessTable(String string) throws SQLException;

	/**
	 * 
	 * Method Name 	: processCreateTableQuery
	 * Description 	: The Method "processCreateTableQuery" is used for 
	 * Date    		: Sep 28, 2016, 8:15:42 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void processCreateTableQuery(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: createProcessQuery
	 * Description 	: The Method "createProcessQuery" is used for 
	 * Date    		: Sep 28, 2016, 8:17:25 PM
	 * @param query
	 * @param  		:
	 * @return 		: void
	 * @throws SQLException 
	 * @throws 		: 
	 */
	void createProcessQuery(String query) throws SQLException;

	/**
	 * 
	 * Method Name 	: deleteDuplicateRecordsFromProcessTable
	 * Description 	: The Method "deleteDuplicateRecordsFromProcessTable" is used for 
	 * Date    		: Sep 28, 2016, 8:19:24 PM
	 * @param isNotNullArray
	 * @param string
	 * @param queryprepareArrayToCSV
	 * @param  		:
	 * @return 		: void
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	void deleteDuplicateRecordsFromProcessTable(String[] isNotNullArray, String string, String queryprepareArrayToCSV) throws DataImportException;

	/**
	 * 
	 * Method Name 	: getFileActivity
	 * Description 	: The Method "getFileActivity" is used for 
	 * Date    		: Sep 30, 2016, 6:52:44 PM
	 * @param activityId
	 * @return
	 * @param  		:
	 * @return 		: FileActivityBO
	 * @throws Exception 
	 * @throws 		: 
	 */
	FileActivityBO getFileActivity(long activityId) throws Exception;

	/**
	 * 
	 * Method Name 	: updateFileActivity
	 * Description 	: The Method "updateFileActivity" is used for 
	 * Date    		: Sep 30, 2016, 6:52:51 PM
	 * @param fileActivity
	 * @param  		:
	 * @return 		: void
	 * @throws Exception 
	 * @throws 		: 
	 */
	Long updateFileActivity(FileActivityBO fileActivity) throws Exception;
	
	/**
	 * @param dataImportDTO
	 * @return
	 * @throws Exception
	 */
	Long insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds) throws Exception;

	/**
	 * 
	 * Method Name 	: executeUpdate
	 * Description 	: The Method "executeUpdate" is used for 
	 * Date    		: Oct 15, 2016, 6:55:42 PM
	 * @param insertQuery
	 * @return
	 * @param  		:
	 * @return 		: int
	 * @throws SQLException 
	 * @throws 		: 
	 */
	int executeUpdate(String insertQuery) throws SQLException;
	/**
	 * 
	 * 
	 * Method Name 	: getEmailProcessingColumns
	 * Description 	: The Method "getEmailProcessingColumns" is used for 
	 * Date    		: Oct 20, 2016, 4:48:14 PM
	 * @return
	 * @param  		:
	 * @return 		: List<Column>
	 * @throws 		:
	 */
	public List<Column> getEmailProcessingColumns();
	/**
	 * 
	 * 
	 * Method Name 	: getSmsProcessingColumns
	 * Description 	: The Method "getSmsProcessingColumns" is used for 
	 * Date    		: Oct 20, 2016, 4:48:18 PM
	 * @return
	 * @param  		:
	 * @return 		: List<Column>
	 * @throws 		:
	 */
	public List<Column> getSmsProcessingColumns();
	/**
	 * 
	 * 
	 * Method Name 	: doUnsub
	 * Description 	: The Method "doUnsub" is used for 
	 * Date    		: Oct 20, 2016, 5:17:39 PM
	 * @param dataImportDto
	 * @param colName
	 * @param action
	 * @return
	 * @throws DataImportException
	 * @throws SQLException
	 * @param  		:
	 * @return 		: long
	 * @throws 		:
	 */
	public long doUnsubResubColumn(DataImportDTO dataImportDto, Column colName, boolean action) throws DataImportException, SQLException ;
	
	/**
	 * 
	 * @param fileDefinitionId
	 * @return
	 * @throws DataImportException
	 */
	FileDefinitionBO getFileDefintion(long fileDefinitionId) throws DataImportException;

	/**
	 * 
	 * @param tableName
	 * @return
	 */
	public boolean checkIsTableExist(String tableName);

	public void updateTriggers(Long fileDefinitionID);
	
	public boolean deleteFromList(ListEntry listEntry, String custCode,String userName) throws Exception;

	Boolean addToList(ListEntry listEntry, String custCode,String userName)throws Exception;
		
}

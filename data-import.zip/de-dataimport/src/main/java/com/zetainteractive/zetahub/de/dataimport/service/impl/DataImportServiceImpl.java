package com.zetainteractive.zetahub.de.dataimport.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.domain.AudienceBO;
import com.zetainteractive.zetahub.commons.domain.ColumnDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.CommonNotificationBO;
import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.FileActivityBO;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.ListDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.LogicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.NotificationBO;
import com.zetainteractive.zetahub.commons.domain.NotificationStatus;
import com.zetainteractive.zetahub.commons.domain.PhysicalColumnBO;
import com.zetainteractive.zetahub.commons.domain.PhysicalTableBO;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;
import com.zetainteractive.zetahub.commons.enums.NotificationStatusTypes;
import com.zetainteractive.zetahub.de.commons.Column;
import com.zetainteractive.zetahub.de.commons.DEConstants;
import com.zetainteractive.zetahub.de.commons.DataImportConstants;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.dao.DataImportDao;
import com.zetainteractive.zetahub.de.dataimport.dao.DataImportQueryBuilder;
import com.zetainteractive.zetahub.de.dataimport.domain.ListEntry;
import com.zetainteractive.zetahub.de.dataimport.domain.ProfileProperty;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;
import com.zetainteractive.zetahub.de.dataimport.service.DataImportService;
import com.zetainteractive.zetahub.de.dataimport.util.DataImportDependencyCalls;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;

/**
 * 
 * 
 * @Author	   : Krishna.Polisetti
 * @Created on : Sep 22, 2016 3:55:28 PM
 * @Version	   : 1.7
 * @Description: "DataImportServiceImpl" is used for 
 * 
 *
 */
@Component
public class DataImportServiceImpl implements DataImportService {

	
	ZetaLogger logger = new ZetaLogger(this.getClass());
	
	@Autowired
	DataImportDao dataImportDao;
	
	@Autowired
	DataImportDependencyCalls dataImportDependencyCalls;
	
	private DataImportQueryBuilder dataImportQueryBuilder= new DataImportQueryBuilder();
	public static final String VERTICA_EMAIL_IMPORT ="EMAIL_ADDRESS";
	public static final String VERTICA_SMS_IMPORT ="SMS_NUMBER";
	public static final String COL_EMAIL = "EMAIL_ADDRESS";
	public static final String COL_SMS = "SMS_NUMBER";
	public static final String TABLE_EMAIL = "AUDIENCE_EMAIL";
	public static final String TABLE_SMS = "AUDIENCE_SMS";
	public static final String TABLE_ADDRESS_EMAIL = "ADDRESS_EMAIL";
	public static final String TABLE_ADDRESS_SMS = "ADDRESS_SMS";
	public static final String CHANNEL_EMAIL_TYPE = "Email";
	public static final String CHANNEL_SMS_TYPE	= "SMS";
	public static final String EMAIL_AUDIENCE="Email Address Audience";
	public static final String SMS_AUDIENCE="Sms Audience";
	String mergeTableName;
	
	/**
	 * 
	 * Method Name 	: getTempTableCount
	 * Description 		: The Method "getTempTableCount" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param tempTableName
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public long getTempTableCount(String tempTableName) throws SQLException {
		String countQuery = "SELECT COUNT(1) FROM "+tempTableName;
		return dataImportDao.getTableCount(countQuery);
		
	}

	/**
	 * 
	 * Method Name 	: getKeyColumns
	 * Description 		: The Method "getKeyColumns" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param columns
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public List<Column> getKeyColumns(List<Column> columns) {
		List<Column> keyColumns = new ArrayList<>();
 		for (Column column : columns) {
			if(column.isIsKey()){
				keyColumns.add(column);
			}
		}
		return keyColumns;
	}

	/**
	 * 
	 * Method Name 	: getNotNullKeyColumns
	 * Description 		: The Method "getNotNullKeyColumns" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param keyColumns
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public List<Column> getNotNullKeyColumns(List<Column> keyColumns) {
		List<Column> notNullkeyColumns = new ArrayList<>();
 		for (Column column : keyColumns) {
			if(!column.isIsNullable() || column.getIsKey()){
				notNullkeyColumns.add(column);
			}
		}
		return notNullkeyColumns;
	}

	/**
	 * 
	 * Method Name 	: getDuplicateAudienceCount
	 * Description 		: The Method "getDuplicateAudienceCount" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param duplicateQuery
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public long getDuplicateAudienceCount(String duplicateQuery) throws SQLException {
		return dataImportDao.getTableCount(duplicateQuery);
	}

	/**
	 * 
	 * Method Name 	: getAudienceId
	 * Description 		: The Method "getAudienceId" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param emailAudience
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws Exception 
	 * @throws 		: 
	 */
	
	@Override
	public long getAudienceId(String audienceName) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : getAudienceId(String audienceName)");
		RestRequestHandler restHandler= new RestRequestHandler();
		String adminEndPoint=ZetaUtil.getHelper().getEndpoint("admin");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity entity = new HttpEntity<>(headers);
		ResponseEntity<AudienceBO> boResponse = restHandler.exchange(adminEndPoint + "/audience/findAudienceByName/"+ audienceName,HttpMethod.GET,entity, AudienceBO.class);
		AudienceBO audience = boResponse.getBody();
		logger.debug("End : "+getClass().getName()+" : getAudienceId(String audienceName)");
		return audience.getAudienceId();
	}

	/**
	 * 
	 * Method Name 	: executeUpdateForDuplicateAudience
	 * Description 		: The Method "executeUpdateForDuplicateAudience" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param updateQuery
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public int executeUpdateForDuplicateAudience(String updateQuery) throws SQLException {
		return dataImportDao.executeUpdateQuery(updateQuery);
	}

	/**
	 * 
	 * Method Name 	: executeEMAILQueries
	 * Description 		: The Method "executeEMAILQueries" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param column
	 * @param dataImportDTO
	 * @param emailColumn
	 * @param audTypeIdEmail
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	
	@Override
	public void executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processingTableName) throws SQLException, DataImportException {


		logger.debug("Begin : "+getClass().getName()+" : executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processingTableName)");
		String query = null;
		try
		{	
			List<Column> emailColumns = getEmailProcessingColumns();
			query=dataImportQueryBuilder.prepareProcessCreateTableQuery(1,processingTableName,emailColumns);		
			logger.debug("List Id:: " +dataImportDTO.getListid()+"  prepareProcessCreateTableQuery::"+query);
			
			try
			{
				dropProcessTable("DROP TABLE IF EXISTS "+processingTableName+"");
			}
			catch(Exception e)
			{
				logger.error(e.getMessage(),e);
				logger.info("Table is not exist to drop :: "+processingTableName);
			}
			
			processCreateTableQuery(query);
			
			
			query=dataImportQueryBuilder.prepareProcessQuery(column,1,emailColumn, dataImportDTO,processingTableName,emailColumns);		
			logger.debug("List Id:: " +dataImportDTO.getListid()+"  prepareProcessQuery::"+query);			
			createProcessQuery(query);
			
			String queryprepareArrayToCSV=dataImportQueryBuilder.prepareArrayToCSV(emailColumns);	
			queryprepareArrayToCSV = queryprepareArrayToCSV.toLowerCase();
			long ImportStagProcessCount=getTempTableCount(processingTableName);
			logger.info("List Id:: " +dataImportDTO.getListid()+"  ImportStagProcessCount::"+ImportStagProcessCount);

			if(ImportStagProcessCount >0 && !dataImportDTO.getBaseTablePhysicalName().equalsIgnoreCase("AUDIENCE_EMAIL")){
				String isNotNullArray[]={"EMAIL_ADDRESS"};
				deleteDuplicateRecordsFromProcessTable(isNotNullArray, processingTableName, queryprepareArrayToCSV);
			}
			if(ImportStagProcessCount!=0)
				dataImportDao.executeEMAILQueries(column, dataImportDTO, emailColumn,audTypeIdEmail,processingTableName);
			if (dataImportDTO.getIsInvalidRecordsExist())
				dataImportDao.executeDefaultEntriesForInvalidEmail(dataImportDTO);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.info("List Id:: " +dataImportDTO.getListid());
		logger.debug("End : "+getClass().getName()+" : executeEMAILQueries(Column column, DataImportDTO dataImportDTO, String emailColumn,long audTypeIdEmail,String processingTableName)");
	
		
		
		
	}

	/**
	 * 
	 * Method Name 	: deleteTargetAudienceMembersToAddresses
	 * Description 		: The Method "deleteTargetAudienceMembersToAddresses" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void deleteTargetAudienceMembersToAddresses(String query) throws SQLException {
		dataImportDao.executeDeleteQuery(query);		
	}

	/**
	 * 
	 * Method Name 	: executeCountQuery
	 * Description 		: The Method "executeCountQuery" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param countQuery
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public long executeCountQuery(String countQuery) throws SQLException {
		return dataImportDao.getTableCount(countQuery);
	}
	
	/**
	 * 
	 * Method Name 	: executeInsertToTarget
	 * Description 		: The Method "executeInsertToTarget" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void executeInsertToTarget(String query) throws SQLException {
		dataImportDao.executeInsert(query);
		
		
	}

	/**
	 * 
	 * Method Name 	: executeSMSQueries
	 * Description 		: The Method "executeSMSQueries" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param column
	 * @param dataImportDTO
	 * @param smsColumn
	 * @param audTypeIdSMS
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	
	@Override
	public void executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName) throws SQLException, DataImportException {

		logger.debug("Begin : "+getClass().getName()+" : executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName)");
		
		String query = null;
		try
		{	
			List<Column> smsColumns = getSmsProcessingColumns();
			query=dataImportQueryBuilder.prepareProcessCreateTableQuery(2,processTableName,smsColumns);	
			logger.debug("List Id:: " +dataImportDTO.getListid()+"  prepareProcessCreateTableQuery::"+query);
			
			try
			{
				dropProcessTable("DROP TABLE IF EXISTS "+processTableName+"");
			}
			catch(Exception e)
			{
				logger.error(e.getMessage(),e);
				logger.info("Table is not exist to drop :: "+processTableName);
			}
			
			processCreateTableQuery(query);
			
			query=dataImportQueryBuilder.prepareProcessQuery(column,2,smsColumn, dataImportDTO,processTableName,smsColumns);		
			logger.debug("List Id:: " +dataImportDTO.getListid()+"  prepareProcessQuery::"+query);			
			createProcessQuery(query);
			
			String queryprepareArrayToCSV=dataImportQueryBuilder.prepareArrayToCSV(smsColumns);	
			queryprepareArrayToCSV = queryprepareArrayToCSV.toLowerCase();

			long ImportStagProcessCount=getTempTableCount(processTableName);

			logger.info("List Id:: " +dataImportDTO.getListid()+"  ImportStagProcessCount::"+ImportStagProcessCount);

			if(ImportStagProcessCount!=0)
				dataImportDao.executeSMSQueries(column, dataImportDTO, smsColumn, audTypeIdSMS,processTableName);
			if (dataImportDTO.getIsInvalidRecordsExist())
				dataImportDao.executeDefaultEntriesForInvalidSms(dataImportDTO);
			
		}catch(Exception ex)
		{
			logger.error(ex.getMessage(),ex);
			throw new DataImportException("Exception while executing sms queries",ex);
		}
		logger.info("List Id:: " +dataImportDTO.getListid());
		logger.debug("End : "+getClass().getName()+" : executeSMSQueries(Column column, DataImportDTO dataImportDTO, String smsColumn, long audTypeIdSMS,String processTableName)");
		
		
	
		
		
		
	
	
	}

	/**
	 * 
	 * Method Name 	: dropTempTables
	 * Description 		: The Method "dropTempTables" is used for 
	 * Date    			: Sep 26, 2016, 9:57:31 PM
	 * @param tempTableName
	 * @param smsProcessTable
	 * @param emailProcessTable
	 * @param  		:
	 * @return 		: 
	 * @throws 		: 
	 */
	
	@Override
	public void dropTempTables(String tempTableName, List<String> smsProcessTable, List<String> emailProcessTable) throws SQLException{
		
		dataImportDao.dropTempTables(tempTableName,smsProcessTable,emailProcessTable,null);
		
	}

	/**
	 * 
	 * Method Name 	: insertNewAudience
	 * Description 		: The Method "insertNewAudience" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void insertNewAudience(String query) throws SQLException {
		dataImportDao.executeInsert(query);
	}

	/**
	 * 
	 * Method Name 	: getCountForNew
	 * Description 		: The Method "getCountForNew" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param seqCountQuery
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public long getCountForNew(String seqCountQuery) throws SQLException {
		return dataImportDao.getTableCount(seqCountQuery);
		
	}

	/**
	 * 
	 * Method Name 	: insertDirectMailTarget
	 * Description 		: The Method "insertDirectMailTarget" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void insertDirectMailTarget(String query) throws SQLException {
		dataImportDao.executeInsert(query);
		
	}

	/**
	 * 
	 * Method Name 	: insertCallCentreTarget
	 * Description 		: The Method "insertCallCentreTarget" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void insertCallCentreTarget(String query) throws SQLException {
		dataImportDao.executeInsert(query);
	}

	/**
	 * 
	 * Method Name 	: insertExportChannelTarget
	 * Description 		: The Method "insertExportChannelTarget" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void insertExportChannelTarget(String query) throws SQLException {
		dataImportDao.executeInsert(query);
		
	}


	/**
	 * 
	 * Method Name 	: inactiveOldTargets
	 * Description 		: The Method "inactiveOldTargets" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void inactiveOldTargets(String query) throws SQLException {
		dataImportDao.executeUpdateQuery(query);
	}

	/**
	 * 
	 * Method Name 	: updateMemberAttributes
	 * Description 		: The Method "updateMemberAttributes" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void updateMemberAttributes(String query) throws SQLException {
		dataImportDao.executeUpdateQuery(query);
	}

	/**
	 * 
	 * Method Name 	: insertNewAudienceMember
	 * Description 		: The Method "insertNewAudienceMember" is used for 
	 * Date    			: Sep 27, 2016, 3:10:57 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void insertNewAudienceMember(String query) throws SQLException {
		dataImportDao.executeInsert(query);		
	}

	/**
	 * 
	 * Method Name 	: getTableColumnsInfo
	 * Description 		: The Method "getTableColumnsInfo" is used for 
	 * Date    			: Sep 27, 2016, 3:19:26 PM
	 * @param string
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public String getTableColumnsInfo(String query) throws SQLException {
		List<String> colums = dataImportDao.getTableColumnsInfo(query);
		return StringUtils.join(colums, ',');
	}

	/**
	 * 
	 * Method Name 	: executeAlterQueries
	 * Description 		: The Method "executeAlterQueries" is used for 
	 * Date    			: Sep 27, 2016, 3:21:41 PM
	 * @param querys
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void executeAlterQueries(String[] querys) throws SQLException {
		for (String alterQuery : querys) {
			dataImportDao.executeUpdateQuery(alterQuery);
		}
	}

	/**
	 * 
	 * Method Name 	: dropListTable
	 * Description 		: The Method "dropListTable" is used for 
	 * Date    			: Sep 27, 2016, 3:55:17 PM
	 * @param string
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void dropListTable(String query) throws SQLException {
		dataImportDao.executeDDL(query);		
	}

	/**
	 * 
	 * Method Name 	: createListTable
	 * Description 		: The Method "createListTable" is used for 
	 * Date    			: Sep 27, 2016, 3:55:17 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void createListTable(String query) throws SQLException {
		dataImportDao.executeDDL(query);		
	}

	/**
	 * 
	 * Method Name 	: stageUpdateTableQuery
	 * Description 		: The Method "stageUpdateTableQuery" is used for 
	 * Date    			: Sep 27, 2016, 3:55:17 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void stageUpdateTableQuery(String updateQuery) throws SQLException {
		dataImportDao.executeUpdateQuery(updateQuery);
	}

	/**
	 * 
	 * Method Name 	: stageInsertTableQuery
	 * Description 		: The Method "stageInsertTableQuery" is used for 
	 * Date    			: Sep 27, 2016, 3:55:17 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void stageInsertTableQuery(String query) throws SQLException {
		dataImportDao.executeInsert(query);
	}

	/**
	 * 
	 * Method Name 	: stageInsertTableQueryWithoutExisting
	 * Description 		: The Method "stageInsertTableQueryWithoutExisting" is used for 
	 * Date    			: Sep 27, 2016, 3:55:17 PM
	 * @param query
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public int stageInsertTableQueryWithoutExisting(String query) throws SQLException {
		int result = dataImportDao.executeUpdateQuery(query);
		return result;
	}

	

	/**
	 * 
	 * Method Name 	: dropProcessTable
	 * Description 		: The Method "dropProcessTable" is used for 
	 * Date    			: Sep 28, 2016, 8:30:34 PM
	 * @param string
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public boolean dropProcessTable(String query) throws SQLException {
		return dataImportDao.executeDDL(query);
		
		
	}

	/**
	 * 
	 * Method Name 	: processCreateTableQuery
	 * Description 		: The Method "processCreateTableQuery" is used for 
	 * Date    			: Sep 28, 2016, 8:30:34 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void processCreateTableQuery(String query) throws SQLException {
		dataImportDao.executeDDL(query);
	}

	/**
	 * 
	 * Method Name 	: createProcessQuery
	 * Description 		: The Method "createProcessQuery" is used for 
	 * Date    			: Sep 28, 2016, 8:30:34 PM
	 * @param query
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public void createProcessQuery(String query) throws SQLException {
		dataImportDao.executeDDL(query);
		
	}

	/**
	 * 
	 * Method Name 	: getPhysicalColumnsAndDefaultValues
	 * Description 		: The Method "getPhysicalColumnsAndDefaultValues" is used for 
	 * Date    			: Sep 29, 2016, 3:31:21 PM
	 * @param baseTablePhysicalName
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws Exception 
	 * @throws 		: 
	 */
	
	@Override
	public HashMap<String, String> getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName)");
		HashMap<String,String> columnsMap = new HashMap<String,String>();
		RestRequestHandler restHandler= new RestRequestHandler();
		String adminEndPoint=ZetaUtil.getHelper().getEndpoint("admin");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity entity = new HttpEntity<>(headers);
		ResponseEntity<PhysicalTableBO> boResponse = restHandler.exchange(adminEndPoint + "/physicalTables/findPhysicalTableByName/"+ baseTablePhysicalName,HttpMethod.GET,entity, PhysicalTableBO.class);
		PhysicalTableBO physicalTableBO = boResponse.getBody();
		List<PhysicalColumnBO> columns = physicalTableBO.getPhysicalColumns();
		for (PhysicalColumnBO physicalColumnBO : columns) {
			columnsMap.put(physicalColumnBO.getPhysicalColumnName(),physicalColumnBO.getColumnDefaultValue());
		}
		logger.debug("End : "+getClass().getName()+" : getPhysicalColumnsAndDefaultValues(String baseTablePhysicalName)");
		return columnsMap;
	}
	
	/**
	 * 
	 * Method Name 	: deleteDuplicateRecords
	 * Description 		: The Method "deleteDuplicateRecords" is used for 
	 * Date    			: Sep 29, 2016, 3:31:21 PM
	 * @param notNullColumns
	 * @param tempTableName
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	
	@Override
	public long deleteDuplicateRecords(String[] notNullColumns, String tempTableName, DataImportDTO dataImportDTO,HashMap<String, String> defaultValuesMap) throws DataImportException, SQLException {
		return dataImportDao.deleteDuplicateRecords(notNullColumns,tempTableName,dataImportDTO, defaultValuesMap);
	}
	
	/**
	 * 
	 * Method Name 	: deleteDuplicateRecordsFromProcessTable
	 * Description 		: The Method "deleteDuplicateRecordsFromProcessTable" is used for 
	 * Date    			: Sep 29, 2016, 3:31:21 PM
	 * @param isNotNullArray
	 * @param string
	 * @param queryprepareArrayToCSV
	 * @param  		:
	 * @return 		: 
	 * @throws DataImportException 
	 * @throws 		: 
	 */
	
	@Override
	public void deleteDuplicateRecordsFromProcessTable(String[] notNullColumns, String tempTableName,String queryprepareArrayToCSV) throws DataImportException {
		dataImportDao.deleteDuplicateRecords(notNullColumns,tempTableName,queryprepareArrayToCSV);
	}

	/**
	 * 
	 * Method Name 	: getFileActivity
	 * Description 		: The Method "getFileActivity" is used for 
	 * Date    			: Sep 30, 2016, 6:53:34 PM
	 * @param dataImportDTO
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws Exception 
	 * @throws 		: 
	 */
	
	@Override
	public FileActivityBO getFileActivity(long id) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : getFileActivity(long id)");
		RestRequestHandler restHandler = new RestRequestHandler();
		String adminEndPoint=ZetaUtil.getHelper().getEndpoint("admin");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity entity = new HttpEntity<>(headers);
		ResponseEntity<FileActivityBO> boResponse = restHandler.exchange(adminEndPoint + "/file/getFileActivity/"+id,HttpMethod.GET,entity, FileActivityBO.class);
		FileActivityBO fileActivityBO = boResponse.getBody();
		logger.debug("End : "+getClass().getName()+" : getFileActivity(long id)");
		return fileActivityBO;
	}

	/**
	 * 
	 * Method Name 	: updateFileActivity
	 * Description 		: The Method "updateFileActivity" is used for 
	 * Date    			: Sep 30, 2016, 6:53:34 PM
	 * @param fileActivity
	 * @param  		:
	 * @return 		: 
	 * @throws Exception 
	 * @throws 		: 
	 */
	
	@Override
	public Long updateFileActivity(FileActivityBO fileActivity) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : updateFileActivity(FileActivityBO fileActivity)");
		RestRequestHandler restHandler = new RestRequestHandler();
		String adminEndPoint=ZetaUtil.getHelper().getEndpoint("admin");
		HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
		HttpEntity entity = new HttpEntity<>(fileActivity,headers);
		ResponseEntity<Long> response = restHandler.exchange(adminEndPoint+"/file/saveFileActivity", HttpMethod.POST, entity, Long.class);
		Long result = response.getBody();
		logger.debug("End : "+getClass().getName()+" : updateFileActivity(FileActivityBO fileActivity)");
		return result;
	}
	
	@Override
	public Long insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds)");
		List<WorkflowActivity> blockedWorkFlowActivities;
		List<WorkflowActivity> erroredWorkFlowActivities;
		Map<String,String> emailAddress=new HashMap<>();
		Boolean isNotificationEnabled=false;
		Long acitivityId;
		String userName=ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser", "dataimportuser");
		logger.info("Batch ids for work flow activity :: "+batchIds);
		DTWSearchCriteria searchCriteria = new DTWSearchCriteria();
		searchCriteria.setPagesize(1);
		searchCriteria.setSortorder(DTWSearchCriteria.SORT_ASC);
		searchCriteria.setPageno(1);
		searchCriteria.setSortby("workflowactivityid");
		
		WorkflowActivity activity=new WorkflowActivity();
		activity.setStartedOn(new Date());
		activity.setWorkflowId(dataImportDTO.getWorkFlowID());
		activity.setCreatedby(userName);
		activity.setUpdatedby(userName);
		String workflowName=null;
		Map<String,String> response=new HashMap<>();
		String isEnable="N";
		try{
			response=dataImportDependencyCalls.getNotificationWorkflowMappings(dataImportDTO.getWorkFlowID(), dataImportDTO.getCustCode(), userName);
			if (response != null && !response.isEmpty()){
				DepartmentSettings departmentSettings=dataImportDependencyCalls.getNotificationsFromDepartment(Long.parseLong(response.get("departmentId")), dataImportDTO.getCustCode(), userName);
				CommonNotificationBO commonNotificationBO=getNotificationStatus(departmentSettings, "Workflows");
				if (commonNotificationBO.getIsEnabled()){
					isNotificationEnabled=true;
					emailAddress=getDepartmentEmailDetails(commonNotificationBO, emailAddress);
				}
				workflowName=response.get("name");
				isEnable=response.get("isEnable");
			}
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		
		//Workflow is disabled, so cannot proceed
		if(workflowName==null || "N".equals(isEnable)){
			logger.warn("Workflow is disabled, hence cannot proceed to create workflow activity");
			logger.debug("End : "+getClass().getName()+" : insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds)");
			return 0L;
		}
		
		searchCriteria.setStatus(DEConstants.ACTIVITY_ERRORED);
		erroredWorkFlowActivities = dataImportDependencyCalls.getActivities(dataImportDTO.getCustCode(),userName,searchCriteria);
		if(erroredWorkFlowActivities!=null && erroredWorkFlowActivities.size()>0){
			activity.setMessage(DEConstants.ACTIVITY_BLOCKED_MSG);
			activity.setStatus(DEConstants.ACTIVITY_BLOCKED);
			activity.setBatchids(batchIds);
			if (emailAddress.containsKey(NotificationStatusTypes.NOTIFICATION_BLOCKED.getValue())){
				logger.debug("Blocked notification is enabled for workflow");
				acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,isNotificationEnabled,emailAddress,response);
			}else
				acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,false,emailAddress,response);
			logger.debug("End : "+getClass().getName()+" : insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds)");
			return acitivityId;
		}
		
		searchCriteria.setStatus(DEConstants.ACTIVITY_BLOCKED);
		blockedWorkFlowActivities = dataImportDependencyCalls.getActivities(dataImportDTO.getCustCode(),userName,searchCriteria);
		if(blockedWorkFlowActivities!=null && blockedWorkFlowActivities.size()>0){
			activity.setMessage(DEConstants.ACTIVITY_BLOCKED_MSG);
			activity.setStatus(DEConstants.ACTIVITY_BLOCKED);
			activity.setBatchids(batchIds);
			if (emailAddress.containsKey(NotificationStatusTypes.NOTIFICATION_BLOCKED.getValue())){
				logger.debug("Waiting notification is enabled for workflow");
				acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,true,emailAddress,response);
			}else
				acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,false,emailAddress,response);
			logger.debug("End : "+getClass().getName()+" : insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds)");
			return acitivityId;
		}
		
		activity.setMessage(DEConstants.ACTIVITY_SCHEDULED_MSG);
		activity.setStatus(DEConstants.ACTIVITY_WAITING);
		activity.setBatchids(batchIds);
		if (emailAddress.containsKey(NotificationStatusTypes.NOTIFICATION_WAITING.getValue()))
			acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,true,emailAddress,response);
		else
			acitivityId=dataImportDependencyCalls.saveWorkFlowActivity(dataImportDTO.getCustCode(),userName,activity,false,emailAddress,response);
		logger.info("Triggering workflow for Customer::"+dataImportDTO.getCustCode());
		dataImportDependencyCalls.triggerWorkFlowActivity(dataImportDTO.getCustCode(),userName);
		logger.debug("End : "+getClass().getName()+" : insertWorkFlowActivity(DataImportDTO dataImportDTO,String batchIds)");
		return acitivityId;
	}

	/**
	 * 
	 * Method Name 	: executeUpdate
	 * Description 		: The Method "executeUpdate" is used for 
	 * Date    			: Oct 15, 2016, 6:55:51 PM
	 * @param insertQuery
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws SQLException 
	 * @throws 		: 
	 */
	
	@Override
	public int executeUpdate(String insertQuery) throws SQLException {
		return dataImportDao.executeUpdateQuery(insertQuery);
	}
	/**
	 * 
	 * 
	 * Method Name 	: getEmailProcessingColumns
	 * Description 		: The Method "getEmailProcessingColumns" is used for 
	 * Date    			: Oct 16, 2016, 10:03:42 PM
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		:
	 */
	@Override
	public List<Column> getEmailProcessingColumns() {
		logger.debug("Begin : "+getClass().getName()+" : getEmailProcessingColumns()");
		List<Column> emailColumns = new ArrayList<>();
		Column column ;
		column = new Column();
		column.setColumnName("ADDRESSID");
		column.setDataType("BIGINT");
		emailColumns.add(column);
		column = new Column();
		column.setColumnName("EMAIL_ADDRESS");
		column.setDataType("VARCHAR");
		column.setLength(400);
		emailColumns.add(column);
		column = new Column();
		column.setColumnName("DOMAIN");
		column.setDataType("VARCHAR");
		column.setLength(255);
		emailColumns.add(column);
		column = new Column();
		column.setColumnName("ISNEW_2");
		column.setDataType("BOOLEAN");
		emailColumns.add(column);
		logger.debug("End : "+getClass().getName()+" : getEmailProcessingColumns()");
		return emailColumns;
	}
	/**
	 * 
	 * 
	 * Method Name 	: getSmsProcessingColumns
	 * Description 		: The Method "getSmsProcessingColumns" is used for 
	 * Date    			: Oct 16, 2016, 10:03:54 PM
	 * @return
	 * @param  		:
	 * @return 		: 
	 * @throws 		:
	 */
	@Override
	public List<Column> getSmsProcessingColumns() {
		List<Column> smsColumns = new ArrayList<>();
		Column column;
		column = new Column();
		column.setColumnName("ADDRESSID");
		column.setDataType("BIGINT");
		smsColumns.add(column);
		column = new Column();
		column.setColumnName("SMS_NUMBER");
		column.setDataType("VARCHAR");
		column.setLength(50);
		smsColumns.add(column);
		
		column = new Column();
		column.setColumnName("ISNEW_2");
		column.setDataType("BOOLEAN");
		smsColumns.add(column);
		return smsColumns;
	}
	/**
	 * Method Name 	: doUnsub
	 * Description 	: The Method "doUnsub" is used for 
	 * Date    		: Oct 20, 2016, 4:46:08 PM
	 * @param filePath
	 * @param dataImportDto
	 * @param tablenameAdhoc
	 * @param colName
	 * @param action
	 * @param logPath
	 * @throws DataImportException
	 * @throws SQLException
	 * @param  		:
	 * @return 		: long
	 * @throws 		:
	 */
	@Override
	public long doUnsubResubColumn(DataImportDTO dataImportDto, Column column, boolean isResub) throws DataImportException, SQLException {
		logger.debug("Begin : "+getClass().getName()+" : doUnsubResubColumn(DataImportDTO dataImportDto, String colName, boolean isResub)");
		logger.debug("isResub :: " + isResub);
		String tablePrefix=null;
		long iterationRecordsCount=0L;
		Map<String,Integer> countValues;
		if(isResub)
			tablePrefix = "RESUB_TEMP_IMPORT_";
		else 
			tablePrefix = "UNSUB_TEMP_IMPORT_";
		String importTempTable=tablePrefix+dataImportDto.getFileDefinitionId() ;
		String auditOptOutsImportTempTable=tablePrefix+"OPTOUTS_AUDIT_"+dataImportDto.getFileDefinitionId();
		String optOutsImportTempTable = tablePrefix+"OPTOUTS_"+dataImportDto.getFileDefinitionId();
		boolean isAdhoc = false;
		boolean result = false;
		boolean isIgnore=false;
		try{
			String colName=column.getColumnName();
			String departmentIds="";
			Map<String,String> unsubProperties=dataImportDto.getFileDefinitionBO().getUnsubResubProperties();
			if (unsubProperties != null && (dataImportDto.getImportType().equalsIgnoreCase("UNSUB") || dataImportDto.getImportType().equalsIgnoreCase("RESUB"))){
				if (unsubProperties.containsKey("global") && 
						unsubProperties.get("global").equalsIgnoreCase("Y")){
					departmentIds="0";
				}
				if (unsubProperties.containsKey("enabledepartment") && unsubProperties.get("enabledepartment").equalsIgnoreCase("Y")
						&& unsubProperties.containsKey("departments")){
					if (departmentIds.length()>0)
						departmentIds=departmentIds+","+dataImportDto.getFileDefinitionBO().getUnsubResubProperties().get("departments");
					else
						departmentIds=dataImportDto.getFileDefinitionBO().getUnsubResubProperties().get("departments");
				}
				if(unsubProperties.containsKey("ignoreEmail"))
					isIgnore=unsubProperties.get("ignoreEmail").equals("Y");
				
			}else if (dataImportDto.getImportType().equals(DataImportConstants.BATCH_IMPORT_TYPE.toString()) || 
					dataImportDto.getImportType().equals(DataImportConstants.ADHOC_IMPORT_TYPE.toString())){
				departmentIds="0";
				isAdhoc=true;
			}
			String audienceType="";
			String sourceType = dataImportDto.getAudienceType();
			if(sourceType.equalsIgnoreCase("EMAIL") || column.getDataType().equalsIgnoreCase("EMAIL")){
				audienceType=VERTICA_EMAIL_IMPORT;
			}else if(sourceType.equalsIgnoreCase("SMS") || column.getDataType().equalsIgnoreCase("SMS")){
				audienceType=VERTICA_SMS_IMPORT;
			}	
			String tableQuery = dataImportQueryBuilder.getCreateTableQuery(audienceType,importTempTable);
			logger.debug("Create table query :: "+tableQuery);
			dropListTable("DROP TABLE IF EXISTS "+importTempTable);
			
			createListTable(tableQuery);
			
			logger.info("Table is Created with name : " + importTempTable+" columnname "+colName);
			loadDataFromTempTable(importTempTable,dataImportDto.getTempTableName(),colName,audienceType);
			
			long duplicateCount=deleteDuplicateRecords(importTempTable,audienceType);
			logger.info("deleted duplicate count :: "+duplicateCount);
			logger.info("ImportTempTable :: "+importTempTable);
			countValues=processNotMatchingRecordsToUnSubOrResub(dataImportDto,importTempTable,audienceType,dataImportDto.getFileDefinitionId(),isAdhoc,dataImportDto.getCustCode(),optOutsImportTempTable,isIgnore);
			/** For temporary audit table **/
			auditOptOutsImportTempTable="TEMP_IMPORT_OPTOUTS_AUDIT_"+dataImportDto.getFileDefinitionId();
			createTemporaryImportauditTable(importTempTable,auditOptOutsImportTempTable,audienceType);
			//int unsubCount = unSubOrResubEmailOrSms(importTempTable,audienceType,isResub);
			
			
			String[] departmentValues=departmentIds.split(",");
			for(String departmentId : departmentValues){
				
				if (departmentId.length()>0){
					
					
					
					if(audienceType.equals(VERTICA_EMAIL_IMPORT)){
						if(!isResub){
							dataImportDao.insertEmailUnsubs(dataImportDto,importTempTable,Integer.parseInt(departmentId),isIgnore);
						}else{
							dataImportDao.deleteEmailUnsubs(dataImportDto,importTempTable,Integer.parseInt(departmentId),isIgnore);
						}
					}else if(audienceType.equals(VERTICA_SMS_IMPORT)){
						if(!isResub){
							dataImportDao.insertSmsUnsubs(dataImportDto,importTempTable,Integer.parseInt(departmentId),isIgnore);
						}else{
							dataImportDao.deleteSmsResubs(dataImportDto,importTempTable,Integer.parseInt(departmentId),isIgnore);
						}
						
					}
				}
			}
			// inserting into audit tables
			unSubOrResubEmailOrSmsRelationTables(importTempTable,auditOptOutsImportTempTable,audienceType,isResub,departmentIds);
			
			iterationRecordsCount=countValues.get("newRecordsCount")+countValues.get("existingRecordsCount");
			if(isResub)
				dataImportDto.getFileDefinitionBO().getFileSummaryBO().setResubRecordsCount(Long.valueOf(iterationRecordsCount));
			else
				dataImportDto.getFileDefinitionBO().getFileSummaryBO().setUnsubRecordsCount(Long.valueOf(iterationRecordsCount));
			dataImportDto.getFileDefinitionBO().getFileSummaryBO().setTotalRecordsCount(dataImportDto.getFileDefinitionBO().getFileSummaryBO().getTotalRecordsCount()+countValues.get("newRecordsCount"));
			if(dataImportDto.getImportType()!=null && !"ADHOCIMPORT".equalsIgnoreCase(dataImportDto.getImportType())){
				dataImportDto.getFileDefinitionBO().getFileSummaryBO().setNewRecordsCount(countValues.get("newRecordsCount"));
				dataImportDto.getFileDefinitionBO().getFileSummaryBO().setExistingRecordsCount(countValues.get("existingRecordsCount"));
			}
			result = true;
			//logger.info("temmimpCount :: "+tempimpCount+"unsubCount :: "+unsubCount+"updateCountRelationTablsCount :: "+updateCountRelationTablsCount);
		}catch(DataImportException ebiz){
			throw ebiz;
		}catch(Exception e){
			throw new DataImportException(e.getMessage(),e);
		}
		finally
		{
			dropTempTables(optOutsImportTempTable,importTempTable,auditOptOutsImportTempTable);
		}
		logger.debug("End : "+getClass().getName()+" : doUnsubResubColumn(DataImportDTO dataImportDto, String colName, boolean isResub)");
		return iterationRecordsCount;
	}

	/**
	 *  
	 * Method Name 	: loadDataFromTempTable
	 * Description 	: The Method "loadDataFromAdhocTable" is used for 
	 * Date    		: Oct 20, 2016, 1:05:32 PM
	 * @param tableName
	 * @param tempTableName
	 * @param colname
	 * @param audienceType
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: int
	 * @throws 		:
	 */
	public long loadDataFromTempTable(String tableName,String tempTableName,String colname,String audienceType) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : loadDataFromTempTable(String tableName,String tempTableName,String colname,String audienceType)");
		String query = null;
		long i=0;
		try{
				query = "insert /*+ DIRECT */ into "+tableName+" ("+audienceType+",AUDIENCE_MEM_ID,IS_NEW) select "+colname+",AUDIENCE_MEMBER_ID_2,ISNEW_2 from "+ tempTableName ;
			logger.info("Inserted query :"+query);
			dataImportDao.executeInsert(query);
			
			i = getTempTableCount(tableName);
			logger.info("No of records inserted :"+i);
			if (i<=0)
                throw new Exception("File contains invalid data or empty.");
		}catch(SQLException e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : loadDataFromTempTable(String tableName,String tempTableName,String colname,String audienceType)");
		return i;
	}
	/**
	 * Method Name 	: deleteDuplicateRecords
	 * Description 	: The Method "deleteDuplicateRecords" is used for 
	 * Date    		: Oct 20, 2016, 1:08:24 PM
	 * @param tableName
	 * @param audienceType
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: long
	 * @throws SQLException 
	 * @throws 		:
	 */
	public long deleteDuplicateRecords(String tableName, String audienceType) throws DataImportException, SQLException {
		logger.debug("Begin : "+getClass().getName()+" : deleteDuplicateRecords(String tableName, String audienceType)");
		String transientTableName=tableName+"_TRANSIENT";
		int insertedRecordsCount=0;
		long totalRecordsCount=0;
		try{
			String columnName = dataImportQueryBuilder.getColumnName(audienceType);
			//Do auto commit false imple
			
			/*Begin :: Prepare TRANSIENT Table*/			
			dataImportDao.executeDDL("CREATE TABLE "+transientTableName+" AS SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tableName +" LIMIT 0");
			dataImportDao.executeInsert("INSERT /*+ DIRECT */ INTO "+transientTableName+" SELECT ROW_NUMBER() OVER () AS ROW_NUM,* FROM "+tableName);
			/*End :: Prepare TRANSIENT Table*/
			
			/*Begin :: Truncate TEMPORARY Table*/
			dataImportDao.executeDeleteQuery("TRUNCATE TABLE "+tableName);
			/*End :: Truncate TEMPORARY Table*/
			
			/*Begin :: Dump into TEMPORARY Table*/
			
			insertedRecordsCount=dataImportDao.executeInsert("INSERT  /*+ DIRECT */  INTO "+tableName+" ("+columnName+",AUDIENCE_MEM_ID,IS_NEW) SELECT "+columnName+",AUDIENCE_MEM_ID,IS_NEW FROM "+transientTableName+" WHERE ROW_NUM IN (SELECT MAX(ROW_NUM) FROM "+transientTableName+" GROUP BY "+columnName+")");
			
			/*Begin :: Find total numbers with duplicates*/
			totalRecordsCount=dataImportDao.getTableCount("SELECT MAX(ROW_NUM) FROM "+transientTableName);
			
			/*End :: Find total numbers with duplicates*/
			
			/*Begin :: Drop TRANSIENT Table*/
			dataImportDao.executeDDL("DROP TABLE IF EXISTS "+transientTableName);
			/*End :: Drop TRANSIENT Table*/
			
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(), e);
		}
		finally{
			logger.debug("Drop query for TEMP Table:::::::::   DROP TABLE "+transientTableName);
			dataImportDao.executeDDL("DROP TABLE IF EXISTS "+transientTableName);
		}				
		logger.debug("End : "+getClass().getName()+" : deleteDuplicateRecords(String tableName, String audienceType)");
		return totalRecordsCount-insertedRecordsCount;
	}
	/**
	 * 
	 * Method Name 	: processNotMatchingRecordsToUnSubOrResub
	 * Description 	: The Method "processNotMatchingRecordsToUnSubOrResub" is used for 
	 * Date    		: Oct 20, 2016, 1:28:50 PM
	 * @param tableName
	 * @param audienceType
	 * @param jobid
	 * @param isAdhoc
	 * @param custCode
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: Map
	 * @throws 		:
	 */
	public Map<String,Integer> processNotMatchingRecordsToUnSubOrResub(DataImportDTO dataImportDTO,String tableName, String audienceType, long jobid, boolean isAdhoc,String custCode,String optOutsImportTempTable,boolean isIgnore) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : processNotMatchingRecordsToUnSubOrResub(String tableName, String audienceType, long jobid, boolean isAdhoc,String custCode,String optOutsImportTempTable,boolean isIgnore)");
		long isUpdated=0;
		Map<String,Integer> retValue=new HashMap<>();
		try{
			String colName = dataImportQueryBuilder.getColumnName(audienceType);
			logger.info(tableName +" of column name is : "+colName);
			String tableQuery = null;
			String insertStatementQry = null;
			String columnName = COL_EMAIL;
			String param = CHANNEL_EMAIL_TYPE;
			String tName = TABLE_ADDRESS_EMAIL;
			String createTableColumns = columnName+" CHARACTER VARYING(400) ENCODING GZIP_COMP,DOMAIN CHARACTER VARYING(255) ENCODING GZIP_COMP,ADDRESSID BIGINT,AUDIENCE_MEM_ID BIGINT,IS_NEW BOOLEAN ENCODING BLOCK_DICT";
			String columnString = "ADDRESSID,"+columnName+",DOMAIN,AUDIENCE_MEM_ID,IS_NEW";
			
			int categoryId = 1;
			if(colName.equalsIgnoreCase(VERTICA_SMS_IMPORT)){
				columnName = COL_SMS;
				tName = TABLE_ADDRESS_SMS;
				param = VERTICA_SMS_IMPORT;
				createTableColumns = columnName+" CHARACTER VARYING(400) ENCODING GZIP_COMP, ADDRESSID BIGINT, AUDIENCE_MEM_ID BIGINT, IS_NEW BOOLEAN ENCODING BLOCK_DICT";
				columnString = "ADDRESSID,"+columnName+", AUDIENCE_MEM_ID, IS_NEW";
			}
			tableQuery="CREATE TABLE "+optOutsImportTempTable+" ("+createTableColumns+") ORDER BY AUDIENCE_MEM_ID";
			if(VERTICA_EMAIL_IMPORT.equalsIgnoreCase(colName)){
				insertStatementQry="INSERT /*+ DIRECT */ INTO "+optOutsImportTempTable+"("+columnString+") SELECT nextval('FORGEIDSEQUENCE') AS ADDRESS_ID, SOURCE."+colName+" EMAIL,SUBSTRING(SOURCE."+colName+", STRPOS(SOURCE."+colName+", '@') + 1) AS DOMAIN,SOURCE.AUDIENCE_MEM_ID,CASE WHEN ADDRESS.ADDRESS_ID IS NULL THEN TRUE ELSE FALSE END FROM "+tableName+" SOURCE LEFT OUTER JOIN ADDRESS_EMAIL ADDRESS ON SOURCE."+colName+" = ADDRESS."+columnName+" LEFT OUTER JOIN "+optOutsImportTempTable+" PROCESSING  ON SOURCE."+colName+" = PROCESSING."+columnName+" WHERE PROCESSING."+columnName+" IS NULL AND SOURCE."+colName+" <> '' AND SOURCE.IS_NEW=TRUE ";
			}else{
				insertStatementQry="INSERT /*+ DIRECT */ INTO "+optOutsImportTempTable+"("+columnString+") SELECT nextval('FORGEIDSEQUENCE') AS ADDRESS_ID,SOURCE."+colName+" EMAIL,SOURCE.AUDIENCE_MEM_ID,CASE WHEN ADDRESS.ADDRESS_ID IS NULL THEN TRUE ELSE FALSE END FROM "+tableName+" SOURCE LEFT OUTER JOIN ADDRESS_SMS ADDRESS ON SOURCE."+colName+" = ADDRESS."+columnName+" LEFT OUTER JOIN "+optOutsImportTempTable+" PROCESSING  ON SOURCE."+colName+" = PROCESSING."+columnName+" WHERE PROCESSING."+columnName+" IS NULL AND SOURCE."+colName+" <> '' AND SOURCE.IS_NEW=TRUE ";
			}
			
			String updateQuery=prepareUpdateQuery(columnName, tableName,colName);
			logger.debug("Temp table update query:::::::::::"+updateQuery);			
			int existingRecordsCount=dataImportDao.executeUpdateQuery(updateQuery);
			retValue.put("existingRecordsCount", existingRecordsCount);
			
			if( !isAdhoc  && !isIgnore){
				logger.debug("Create Optout Table Query:::::"+tableQuery);
				dataImportDao.executeDDL(tableQuery);
				logger.info("Table "+optOutsImportTempTable+" is created");
				
				logger.debug("Optout table insert Query : "+insertStatementQry);
				int newRecordsCount=dataImportDao.executeInsert(insertStatementQry);
				retValue.put("newRecordsCount", newRecordsCount);
							
				isUpdated = getTempTableCount(optOutsImportTempTable);
				logger.info("In "+optOutsImportTempTable+" not mached recods "+isUpdated+" are inserted");
				if (isUpdated>0)
					executeEmailOrSmsQueriesGlobal(optOutsImportTempTable, param, custCode,categoryId);
			}else{
				retValue.put("newRecordsCount", 0);
			}
		}catch(DataImportException e){
			throw e;
		}catch(SQLException se){
			logger.error(se.getMessage(),se);
			throw new DataImportException(se.getMessage(),se);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : processNotMatchingRecordsToUnSubOrResub(String tableName, String audienceType, long jobid, boolean isAdhoc,String custCode,String optOutsImportTempTable,boolean isIgnore)");
		return retValue;
	}
	/**
	 * 
	 * Method Name 	: createTemporaryImportauditTable
	 * Description 	: The Method "createTemporaryImportauditTable" is used for 
	 * Date    		: Oct 20, 2016, 1:34:18 PM
	 * @param tableName
	 * @param newTableName
	 * @param audienceType
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: long
	 * @throws 		:
	 */
	public long createTemporaryImportauditTable(String tableName,String newTableName, String audienceType) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : createTemporaryImportauditTable(String tableName,String newTableName, String audienceType)");
		boolean isUpdated = false;
		try{
			String colName = dataImportQueryBuilder.getColumnName(audienceType);
			logger.info(tableName +" of column name is : "+colName);
			String tableQuery = null;
			
			String columnName = COL_EMAIL;
			String tName = TABLE_ADDRESS_EMAIL;
			if(colName.equalsIgnoreCase(VERTICA_SMS_IMPORT)){
				columnName = COL_SMS;
				tName = TABLE_ADDRESS_SMS;
			}
			tableQuery = "CREATE VIEW "+newTableName+" AS( SELECT DISTINCT AA.ADDRESS_ID AS ADDRESS_ID, AA.EXPLICIT_OPTIN_IND AS EXPLICIT_OPTIN_IND "
						+" FROM "+tableName+" TI INNER JOIN "+tName+" AE ON (TI."+colName+"= AE."+columnName+")"
						+" INNER JOIN ADDRESS AA ON AE.ADDRESS_ID=AA.ADDRESS_ID)";
			
			logger.info("tableQuery :: "+tableQuery);
			
			dataImportDao.executeDDL("DROP VIEW IF EXISTS "+newTableName);
			logger.info("Table "+newTableName+" is dropped");
			logger.info("Insert Query : "+tableQuery);
			isUpdated = dataImportDao.executeDDL(tableQuery);
			logger.info("table created flag :: "+isUpdated);
			
		}catch(DataImportException e){
			throw e;
		}catch (SQLException e) {
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : createTemporaryImportauditTable(String tableName,String newTableName, String audienceType)");
		return 0;
		
	}
	/**
	 * Method Name 	: unSubOrResubEmailOrSms
	 * Description 	: The Method "unSubOrResubEmailOrSms" is used for 
	 * Date    		: Oct 20, 2016, 2:20:26 PM
	 * @param tableName
	 * @param param
	 * @param isResub
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: int
	 * @throws 		:
	 */
	public int unSubOrResubEmailOrSms(String tableName, String param, boolean isResub) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : unSubOrResubEmailOrSms(String tableName, String param, boolean isResub)");
		int isUpdated=0;
		try{
			String colName = dataImportQueryBuilder.getColumnName(param);
			logger.info(tableName +" of column name is : "+colName);
			String columnName = COL_EMAIL;
			this.mergeTableName=tableName+"_MERGE";
			String tName = TABLE_ADDRESS_EMAIL;
			if(colName.equalsIgnoreCase(VERTICA_SMS_IMPORT)){
				columnName = COL_SMS;
				tName = TABLE_ADDRESS_SMS;
			}
			String createQuery="CREATE VIEW "+this.mergeTableName+" AS SELECT AE.ADDRESS_ID FROM "+tName+" AE, "+tableName+" TQEI WHERE AE."+colName+"=TQEI."+ colName;
			
			logger.info("createQuery for "+this.mergeTableName+" :: "+createQuery);
			
			dataImportDao.executeDDL(createQuery);
			
			long i = getTempTableCount(this.mergeTableName);
			
			String updateQuery = " UPDATE /*+ DIRECT */ TARGET  " 
					+ " SET ACTIVE_IND=" +isResub+", INACTIVE_DT = NOW()  WHERE ADDRESS_ID IN ( SELECT ADDRESS_ID FROM "+this.mergeTableName+")";
			
			logger.info("updateQuery for target :: "+updateQuery);
			
			if(i > 0){
				isUpdated = dataImportDao.executeUpdateQuery(updateQuery);
			}
			logger.info("No of Records updated  : " + isUpdated);
			logger.debug("Target table is updated successfully");
		}catch(DataImportException e){
			throw e;
		}catch(SQLException se){
			logger.error(se.getMessage(),se);
			throw new DataImportException(se.getMessage(),se);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : unSubOrResubEmailOrSms(String tableName, String param, boolean isResub)");
		return isUpdated;
	}
	/**
	 * 
	 * Method Name 	: unSubOrResubEmailOrSmsRelationTables
	 * Description 	: The Method "unSubOrResubEmailOrSmsRelationTables" is used for 
	 * Date    		: Oct 20, 2016, 2:45:31 PM
	 * @param tableName
	 * @param newTableName
	 * @param param
	 * @param isResub
	 * @param deptids 
	 * @return
	 * @throws DataImportException
	 * @param  		:
	 * @return 		: int
	 * @throws 		:
	 */
	public int unSubOrResubEmailOrSmsRelationTables(String tableName,String newTableName, String param, boolean isResub, String  deptids)throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : unSubOrResubEmailOrSmsRelationTables(String tableName,String newTableName, String param, boolean isResub)");
		int isUpdated = 0;
		try{
			String colName = dataImportQueryBuilder.getColumnName(param);
			logger.info(tableName +" of column name is : "+colName);
			String insertQuery = null;
			if(colName != null){
				String[] departments = deptids.split(",");
				if(departments!=null && departments.length>0){
					for (String departmentid : deptids.split(",")) {
						if(colName.equalsIgnoreCase(VERTICA_EMAIL_IMPORT)){
							if(!isResub){
								insertQuery = "insert /*+ DIRECT */  into address_audit (address_id, old_explicit_optin_ind, new_explicit_optin_ind, old_implicit_optin_ind, "
										 +"new_implicit_optin_ind, old_operational_optout_ind, new_operational_optout_ind, old_invalid_address_ind, new_invalid_address_ind," 
										 +"old_undeliverable_ind, new_undeliverable_ind, message, audit_dt, old_operational_optout_dt, new_operational_optout_dt ,departmentid) "  
										 +"select distinct address_id, false as explicit_optin_ind,false  AS new_explicit_optin_ind, false as old_implicit_optin_ind," 
										 +"false as new_implicit_optin_ind, false as old_operational_optout_ind, True as new_operational_optout_ind," 
										 +"false as old_invalid_address_ind, false as new_invalid_address_ind, false as old_undeliverable_ind, false as new_undeliverable_ind," 
										 +"'Unsubscribe status fix from data import' as message, NOW() as audit_dt, now() as old_operational_optout_dt , now() as new_operational_optout_dt, "+departmentid
										 + " from "+newTableName ;
							}else{
								 insertQuery = "insert /*+ DIRECT */  into address_audit (address_id, old_explicit_optin_ind, new_explicit_optin_ind, old_implicit_optin_ind, "
										 +"new_implicit_optin_ind, old_operational_optout_ind, new_operational_optout_ind, old_invalid_address_ind, new_invalid_address_ind," 
										 +"old_undeliverable_ind, new_undeliverable_ind, message, audit_dt, old_explicit_optin_dt, new_explicit_optin_dt,departmentid ) "  
										 +"select distinct address_id,false as explicit_optin_ind, true as new_explicit_optin_ind, false as old_implicit_optin_ind," 
										 +"false as new_implicit_optin_ind, false as old_operational_optout_ind, false as new_operational_optout_ind," 
										 +"false as old_invalid_address_ind, false as new_invalid_address_ind, false as old_undeliverable_ind, false as new_undeliverable_ind," 
										 +"'Resubscribe status fix from data import' as message, NOW() as audit_dt, NOW() as old_explicit_optin_dt, NOW() as new_explicit_optin_dt,"+departmentid
										 + " from "+newTableName ;
							}
						}
						else if(colName.equalsIgnoreCase(VERTICA_SMS_IMPORT)){
							if(!isResub){
								insertQuery = "insert /*+ DIRECT */  into address_audit (address_id, old_explicit_optin_ind, new_explicit_optin_ind, old_implicit_optin_ind, "
								 		 +"new_implicit_optin_ind, old_operational_optout_ind, new_operational_optout_ind, old_invalid_address_ind, new_invalid_address_ind," 
										 +"old_undeliverable_ind, new_undeliverable_ind, message, audit_dt, old_explicit_optin_dt, new_explicit_optin_dt,departmentid ) "  
										 +"select distinct address_id, explicit_optin_ind,false as new_explicit_optin_ind, false as old_implicit_optin_ind," 
										 +"false as new_implicit_optin_ind, false as old_operational_optout_ind, false as new_operational_optout_ind," 
										 +"false as old_invalid_address_ind, false as new_invalid_address_ind, false as old_undeliverable_ind, false as new_undeliverable_ind," 
										 +"'Unsubscribe status fix from data import' as message, NOW() as audit_dt, NOW() as old_explicit_optin_dt, NOW() as new_explicit_optin_dt,"+departmentid
										 + " from "+newTableName ;
							}else{
								insertQuery = "insert /*+ DIRECT */  into address_audit (address_id, old_explicit_optin_ind, new_explicit_optin_ind, old_implicit_optin_ind, "
										+" new_implicit_optin_ind, old_operational_optout_ind, new_operational_optout_ind, old_invalid_address_ind, new_invalid_address_ind," 
										+" old_undeliverable_ind, new_undeliverable_ind, message, audit_dt, old_explicit_optin_dt, new_explicit_optin_dt,departmentid ) "  
										+" select distinct address_id, explicit_optin_ind,true as new_explicit_optin_ind, false as old_implicit_optin_ind," 
										+" false as new_implicit_optin_ind, false as old_operational_optout_ind, false as new_operational_optout_ind," 
										+" false as old_invalid_address_ind, false as new_invalid_address_ind, false as old_undeliverable_ind, false as new_undeliverable_ind," 
										+" 'Resubscribe status fix from data import' as message, NOW() as audit_dt, NOW() as old_explicit_optin_dt, NOW() as new_explicit_optin_dt,"+departmentid
										+" from "+newTableName ;

							}
						}else{
							logger.info(" colName Not Found...");
						}
						
						logger.debug("insert Query  : " + insertQuery);
						isUpdated = dataImportDao.executeInsert(insertQuery);
						logger.info("No of Records updated in ADDRESS_AUDIT table are : " + isUpdated);
					}
				}
				
			}
			
		}catch(DataImportException e){
			throw e;
		}catch(SQLException se){
			logger.error(se.getMessage(),se);
			throw new DataImportException(se.getMessage(),se);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : unSubOrResubEmailOrSmsRelationTables(String tableName,String newTableName, String param, boolean isResub)");
		return isUpdated;
	}
	/**
	 * 
	 * 
	 * Method Name 	: dropTempTables
	 * Description 	: The Method "dropTempTables" is used for 
	 * Date    		: Oct 20, 2016, 2:37:02 PM
	 * @param optOutsImportTempTable
	 * @param ImportTempTable
	 * @param auditOptOutsImportTempTable
	 * @throws SQLException
	 * @param  		:
	 * @return 		: void
	 * @throws 		:
	 */
	private void dropTempTables(String optOutsImportTempTable,String importTempTable,String auditOptOutsImportTempTable) throws SQLException
	{
		logger.debug("Begin : "+getClass().getName()+" : dropTempTables(String optOutsImportTempTable,String ImportTempTable,String auditOptOutsImportTempTable)");
		List<String> smsProcessTable = new ArrayList<>();
		smsProcessTable.add(optOutsImportTempTable);
		String views=null;
		if (this.mergeTableName!=null && auditOptOutsImportTempTable != null)
			views=this.mergeTableName+","+auditOptOutsImportTempTable ;
		else if (this.mergeTableName!=null)
			views=this.mergeTableName;
		else if (auditOptOutsImportTempTable != null)
			views=auditOptOutsImportTempTable;
		
		dataImportDao.dropTempTables(importTempTable, smsProcessTable, null,views );
		this.mergeTableName = null;
		logger.debug("End : "+getClass().getName()+" : dropTempTables(String optOutsImportTempTable,String ImportTempTable,String auditOptOutsImportTempTable)");
	}	
	public void executeEmailOrSmsQueriesGlobal(String processTableName, String audienceType, String custCode, int categoryId) throws DataImportException {
		logger.debug("Begin : "+getClass().getName()+" : executeEmailOrSmsQueriesGlobal(String processTableName, String audienceType, String custCode, int categoryId)");
		long audienceId = 0;
		int type = (audienceType.equalsIgnoreCase("EMAIL"))? 1 : 3;
		try {
			if(type==1)
				audienceId=getAudienceId(EMAIL_AUDIENCE);
			else
				audienceId=getAudienceId(SMS_AUDIENCE);
			logger.info("Audience id for Unsub and Resub : "+ audienceId);
			long ImportStagProcessCount =dataImportDao.getTableCount("SELECT COUNT(*) FROM   "+processTableName);
			if(ImportStagProcessCount>0){
				dataImportDao.executeEmailOrSMSQueries(audienceType,custCode,categoryId,processTableName,audienceId,type);
			}
		} catch (DataImportException e) {
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			throw new DataImportException(e.getMessage());
		}		
		logger.debug("End : "+getClass().getName()+" : executeEmailOrSmsQueriesGlobal(String processTableName, String audienceType, String custCode, int categoryId)");
	}
	private String prepareUpdateQuery(String columnName,String tempTableName,String tempColName){
		String query="";
		if(columnName.equalsIgnoreCase(VERTICA_EMAIL_IMPORT)){
			 query="UPDATE /*+ DIRECT */ "+tempTableName+" SET AUDIENCE_MEM_ID = BASE.AUDIENCE_MEMBER_ID, IS_NEW = FALSE FROM AUDIENCE_EMAIL BASE INNER JOIN AUDIENCE_MEMBER ON BASE.AUDIENCE_MEMBER_ID = AUDIENCE_MEMBER.AUDIENCE_MEMBER_ID WHERE BASE."+columnName+" = "+tempTableName+"."+tempColName;
		}else{
			query="UPDATE /*+ DIRECT */ "+tempTableName+" SET AUDIENCE_MEM_ID = BASE.AUDIENCE_MEMBER_ID, IS_NEW = FALSE FROM AUDIENCE_SMS BASE INNER JOIN AUDIENCE_MEMBER ON BASE.AUDIENCE_MEMBER_ID = AUDIENCE_MEMBER.AUDIENCE_MEMBER_ID WHERE BASE."+columnName+" = "+tempTableName+"."+tempColName;
		}
		
		return query;
	}

	@Override
	public FileDefinitionBO getFileDefintion(long fileDefinitionId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getFileDefintion(long fileDefinitionId)");
		FileDefinitionBO fileDefinitionBO = null;
		try{
			RestRequestHandler restHandler = new RestRequestHandler();
			String adminEndPoint=ZetaUtil.getHelper().getEndpoint("admin");
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity entity = new HttpEntity<>(headers);
			fileDefinitionBO = restHandler.exchange(adminEndPoint+"/file/getFileDefinitionByID/"+fileDefinitionId, HttpMethod.GET, entity, FileDefinitionBO.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("DI0002",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getFileDefintion(long fileDefinitionId)");
		return fileDefinitionBO;
	}

	@Override
	public boolean checkIsTableExist(String tableName) {
		logger.debug("Begin : "+getClass().getName()+" : checkIsTableExist(String tableName)");
		String query = "select count(*) from tables where table_name='"+tableName+"'";
		boolean isExist=false;
		try {
			Long count = dataImportDao.getTableCount(query);
			isExist= count>0;
		} catch (SQLException e) {
			logger.info("Table doesn't exists to append Data");
		}
		logger.debug("End : "+getClass().getName()+" : checkIsTableExist(String tableName)");
		return isExist;
	}
	
	private CommonNotificationBO getNotificationStatus(DepartmentSettings departmentSettings,String notificationName){
		CommonNotificationBO commonNotificationBO=null;
		try {
			if (departmentSettings !=null ){
				ObjectMapper objectMapper=new ObjectMapper();
				NotificationBO notificationBO=objectMapper.convertValue(departmentSettings.getObjectValue(),NotificationBO.class);
				if (notificationBO !=null && notificationBO.getNotifications() !=null && !notificationBO.getNotifications().isEmpty()){
					for (CommonNotificationBO cmnNotificationBO: notificationBO.getNotifications()){
						if (cmnNotificationBO.getNotificationTypeName().equalsIgnoreCase(notificationName)){
							commonNotificationBO=cmnNotificationBO;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return commonNotificationBO;
	}
	/**
	 * 
	 * Method Name 	: getDepartmentEmailDetails
	 * Description 	: The Method "preparing department notification mails" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : Map<String,String>
	 * @param  		: Notifications
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	private Map<String,String> getDepartmentEmailDetails(CommonNotificationBO commonNotificationBO,Map<String,String> emailAddresses) throws Exception {
		if (commonNotificationBO.getDefaultEmailAddresses() != null && !emailAddresses.containsKey("default"))
			emailAddresses.put("default", commonNotificationBO.getDefaultEmailAddresses());
		List<NotificationStatus> notificationStatusList=commonNotificationBO.getNotificationStatuses();
		for (NotificationStatus notificationStatus :notificationStatusList){
			if (notificationStatus.getIsEnabled()){
				if(notificationStatus.getEmailAddresses() !=null 
					&& !emailAddresses.containsKey(notificationStatus.getName()))	
					emailAddresses.put(notificationStatus.getName(), notificationStatus.getEmailAddresses());
				else if(!emailAddresses.containsKey(notificationStatus.getName()))
					emailAddresses.put(notificationStatus.getName(), "-");
			}
		}
		return emailAddresses;	
	}

	@Override
	public void updateTriggers(Long fileDefinitionID) {
		logger.debug("Begin : "+getClass().getName()+" : updateTriggers(Long fileDefinitionID)");
		try {
			boolean updated = dataImportDao.updateTriggers(fileDefinitionID);
			logger.debug("Update triggers completed ::"+updated);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		logger.debug("End : "+getClass().getName()+" : updateTriggers(Long fileDefinitionID)");
	}

	@Override
	public boolean deleteFromList(ListEntry listEntry, String custCode,String userName) throws DataImportException,Exception {
		logger.debug("Begin : "+getClass().getName()+" : deleteFromList(ListEntry listEntry, String custCode,String userName)");
		boolean isDeleted = false;
		Long audienceMemberId = 0l;
		if(ZetaUtil.getHelper().getCustomerID()==null || !ZetaUtil.getHelper().getCustomerID().equalsIgnoreCase(custCode)){
		    ZetaUtil.getHelper(custCode,null);
		}
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), custCode);
		httpHeaders.add(BootStarterConstants.USERNAME.toString(),userName);
		UserBO user = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("security")+"/getUserByName/"+userName, HttpMethod.GET, new HttpEntity<>(httpHeaders), UserBO.class).getBody();
		ZetaUtil.getHelper().setUser(user);
		Long depId = ZetaUtil.getHelper().getUser().getDepartmentID();
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("listid", listEntry.getListId()+"");
		searchCriteria.put("departmentID",depId.toString());
		String whSchemaUrl = ZetaUtil.getHelper().getConfig().getConfigValueString("warehouse-db-url", "");
		String whSchemaName = null;
		boolean tableExists = false;
		List<ListDefinitionBO> listDef = new ArrayList<>();
		List<ColumnDefinitionBO> columnDefinitionList= null;
		String phySicalTableName = "";
		Map<String,String> phyColNameMapping = new HashMap<>();
		Map<String,String> colNameAndValueMap = new HashMap<>();
		Map<String,String> colNameAndTypeMap = new HashMap<>();
		Map<String,String> keyColumnAndValue = new HashMap<>();
		Map<String,Object> listsMap = new HashMap<>();
		String adhocTableName="";
		List<LogicalColumnBO> resultLogicalColumnBOList = null;

		try {
		/*	HttpEntity entity = new HttpEntity<Object>(searchCriteria,ZetaUtil.getHelper().getHeaders());
			ResponseEntity<HashMap<String, Object>> response = new RestTemplate().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/list/getAllLists", HttpMethod.POST, entity,new ParameterizedTypeReference<HashMap<String, Object>>() {});
			ObjectMapper obj = new ObjectMapper();
			obj.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map<String,Object> res = obj.convertValue(response.getBody(), HashMap.class);
			//Need to check table exist or not
*/			
			HttpEntity entity = new HttpEntity<Object>(ZetaUtil.getHelper().getHeaders());
			ResponseEntity<Object[]> response = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/list/getalllistsids/"+listEntry.getListId(), HttpMethod.GET, entity,Object[].class);
			logger.debug("getalllistsids -- response:"+Arrays.asList(response.getBody()));
			listsMap = (Map<String, Object>) (Arrays.asList(response.getBody()).get(0));
			ObjectMapper obj = new ObjectMapper();
			obj.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map<String,Object> res = obj.convertValue(listsMap, HashMap.class);
			logger.debug("getAllLists resultsize="+res.size());
			if(res!=null && !res.isEmpty())
			{
				/*List list = obj.convertValue(res.get("result"), List.class);
				if(list.size()==0)
					throw new DataImportException("Unable to fetch the list details");
				for(int i=0; i<list.size();i++){
					listDef.add( obj.convertValue(list.get(i), ListDefinitionBO.class));
				}*/
				listDef.add( obj.convertValue(res, ListDefinitionBO.class));
				ResponseEntity<LogicalColumnBO[]> boResponse =  new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/audience/getLogicalColumnsBaseByAudienceId/"+listDef.get(0).getAudienceID(), HttpMethod.GET,entity,LogicalColumnBO[].class );
				resultLogicalColumnBOList = Arrays.asList(boResponse.getBody());
			}else{
				throw new DataImportException("Unknow exception occured while fetching all lists");
			}
			ResponseEntity<List<LogicalColumnBO>> boResponse =  new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/audience/getLogicalColumnsBaseByAudienceId/"+listDef.get(0).getAudienceID(), HttpMethod.GET,entity,new ParameterizedTypeReference<List<LogicalColumnBO>>() {
			}  );
			resultLogicalColumnBOList = boResponse.getBody();
			if(listDef!=null && !listDef.isEmpty())
				columnDefinitionList = listDef.get(0).getColumnDefinitionList();
			if(columnDefinitionList!=null && !columnDefinitionList.isEmpty())
				phySicalTableName = getPhysicalTableName(columnDefinitionList);
			if (whSchemaUrl != null) {
				whSchemaName = whSchemaUrl.substring(whSchemaUrl.indexOf("=") + 1);
				logger.debug("whSchemaName ------->" + whSchemaName);
			}else{
				logger.error("Warehouse DB details not found");
			}
			adhocTableName="ADHOC_"+listDef.get(0).getFileDefinitionID();
			//table and column validations
			tableExists = dataImportDao.checkTableExist(adhocTableName,whSchemaName);
			logger.debug("tableExists---"+tableExists);
			if(tableExists){
				for (ColumnDefinitionBO colDefBO : columnDefinitionList) {
					/*if(colDefBO.getIsNullable() != null && ("n".equalsIgnoreCase(colDefBO.getIsNullable()+""))){
						if(!contains(listEntry.getProfileProperties(), colDefBO.getColumnName())){
							throw new DataImportException("Value for this column '"+colDefBO.getColumnName()+"' is required");
						}
					}*/ // commented as null validation is not required while deletion.
					phyColNameMapping.put(colDefBO.getColumnName(), colDefBO.getPhysicalColumnName());
					colNameAndTypeMap.put(colDefBO.getPhysicalColumnName(), colDefBO.getColumnType());
				}
				for (ProfileProperty item : listEntry.getProfileProperties()) {
					String colValue = item.getValue();
					String colName = phyColNameMapping.get(item.getName());
					colNameAndValueMap.put(colName, colValue);
			    }
				if(resultLogicalColumnBOList!=null && !resultLogicalColumnBOList.isEmpty())
				{
					for (LogicalColumnBO logicalColumnBO : resultLogicalColumnBOList) {
						if(logicalColumnBO.getIsKeyColumn() != 'N'){
							for (ColumnDefinitionBO colDefBO : columnDefinitionList) {
								if(colDefBO.getLogicalColumnName().equalsIgnoreCase(logicalColumnBO.getLogicalColumnName())){
									if(!contains(listEntry.getProfileProperties(), colDefBO.getColumnName())){
										throw new DataImportException("Value for this column '"+logicalColumnBO.getLogicalColumnName()+"' is required");
									}else{
										keyColumnAndValue.put(colDefBO.getPhysicalColumnName(), colNameAndValueMap.get(colDefBO.getPhysicalColumnName()));
									}
								}
							}
						}
					}
				}
				int returnValue = dataImportDao.deleteRecordFromAdhocTable(keyColumnAndValue,adhocTableName,colNameAndTypeMap);
				if(returnValue>0){
					isDeleted = true;
				}else{
					throw new DataImportException("Record does not exist");
				}
			}
			else{
				throw new DataImportException("Physical table does not exist.");
			}
		}catch (ArrayIndexOutOfBoundsException ae){
			logger.error("Got ArrayIndexOutOfBoundsException"+ae.getMessage(),ae);
			throw new DataImportException("List does not exist.");
		}catch (RestClientException e) {
			logger.error("Got RestClientException"+e.getMessage(),e);
			throw e;
		} catch (Exception e) {
			logger.error("Got Exception"+e.getMessage(),e);
			throw e;
		} 
		logger.debug("End : "+getClass().getName()+" : deleteFromList(ListEntry listEntry, String custCode,String userName)");
		return isDeleted;
	}

	@Override
	public Boolean addToList(ListEntry listEntry, String custCode,String userName) throws Exception {
		logger.debug("Begin : "+getClass().getName()+" : addToList(ListEntry listEntry, String custCode,String userName)");
		boolean isAdded = false;
		if(ZetaUtil.getHelper().getCustomerID()==null || !ZetaUtil.getHelper().getCustomerID().equalsIgnoreCase(custCode)){
		    ZetaUtil.getHelper(custCode,null);
		}
		logger.debug("listEntry="+listEntry.toString());
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), custCode);
		httpHeaders.add(BootStarterConstants.USERNAME.toString(),userName);
		UserBO user = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("security")+"/getUserByName/"+userName, HttpMethod.GET, new HttpEntity<>(httpHeaders), UserBO.class).getBody();
		Long audienceMemberId = 0l;
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("listid", listEntry.getListId()+"");
		searchCriteria.put("departmentID",user.getDepartmentID()+"");
		String whSchemaUrl = ZetaUtil.getHelper().getConfig().getConfigValueString("warehouse-db-url", "");
		String whSchemaName = null;
		boolean tableExists = false;
		List<ListDefinitionBO> listDef = new ArrayList<>();
		List<ColumnDefinitionBO> columnDefinitionList= null;
		String phySicalTableName = "";
		Map<String,String> phyColNameMapping = new HashMap<>();
		Map<String,String> colNameAndValueMap = new HashMap<>();
		Map<String,String> colNameAndTypeMap = new HashMap<>();
		Map<String,String> keyColumnAndValue = new HashMap<>();
		Map<String,Object> listsMap = new HashMap<>();

		String adhocTableName="";
		List<LogicalColumnBO> resultLogicalColumnBOList = null;
		ZetaUtil.getHelper().setUser(user);
		try {
			HttpEntity entity = new HttpEntity<Object>(ZetaUtil.getHelper().getHeaders());
			ResponseEntity<Object[]> response = new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/list/getalllistsids/"+listEntry.getListId(), HttpMethod.GET, entity,Object[].class);
			logger.debug("getalllistsbyid  response---"+Arrays.asList(response.getBody()));
			listsMap = (Map<String, Object>) (Arrays.asList(response.getBody()).get(0));
			ObjectMapper obj = new ObjectMapper();
			obj.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map<String,Object> res = obj.convertValue(listsMap, HashMap.class);
			
			//Need to check table exist or not
			if(res!=null && !res.isEmpty())
			{
				logger.debug("getAllLists resultsize="+res.size());
				//List list = obj.convertValue(res.get("result"), List.class);
				//if(list.size()==0)
				//	throw new DataImportException("Unable to fetch the list details");
				
				//for(int i=0; i<list.size();i++){
					listDef.add( obj.convertValue(res, ListDefinitionBO.class));
				//}
				logger.info("resultLogicalColumnBOList   API:"+ZetaUtil.getHelper().getEndpoint("admin")+"/audience/getLogicalColumnsBaseByAudienceId/"+listDef.get(0).getAudienceID());
				ResponseEntity<LogicalColumnBO[]> boResponse =  new RestRequestHandler().exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/audience/getLogicalColumnsBaseByAudienceId/"+listDef.get(0).getAudienceID(), HttpMethod.GET,entity,LogicalColumnBO[].class );
				resultLogicalColumnBOList = Arrays.asList(boResponse.getBody());
			}else{
				throw new DataImportException("Unknow exception occured while fetching all lists");
			}
			
			if(listDef!=null && !listDef.isEmpty())
				columnDefinitionList = listDef.get(0).getColumnDefinitionList();
			if(columnDefinitionList!=null && !columnDefinitionList.isEmpty())
				phySicalTableName = getPhysicalTableName(columnDefinitionList);
			if (whSchemaUrl != null) {
				whSchemaName = whSchemaUrl.substring(whSchemaUrl.indexOf("=") + 1);
				logger.debug("whSchemaName ------->" + whSchemaName);
			}else{
				logger.error("Warehouse DB details not found");
			}
			adhocTableName="ADHOC_"+listDef.get(0).getFileDefinitionID();
			//table and column validations
			tableExists = dataImportDao.checkTableExist(adhocTableName,whSchemaName);
			if(tableExists){
				for (ColumnDefinitionBO colDefBO : columnDefinitionList) {
					if(colDefBO.getIsNullable() != null && ("n".equalsIgnoreCase(colDefBO.getIsNullable()+""))){
						if(!contains(listEntry.getProfileProperties(), colDefBO.getColumnName())){
							throw new DataImportException("Value for this column '"+colDefBO.getColumnName()+"' is required");
						}
					}
					phyColNameMapping.put(colDefBO.getColumnName(), colDefBO.getPhysicalColumnName());
					colNameAndTypeMap.put(colDefBO.getPhysicalColumnName(), colDefBO.getColumnType());
				}
				for (ProfileProperty item : listEntry.getProfileProperties()) {
					String colValue = item.getValue();
					String colName = phyColNameMapping.get(item.getName());
					if(colName!=null && colValue!=null)
						colNameAndValueMap.put(colName, colValue);
			    }
				if(resultLogicalColumnBOList!=null && !resultLogicalColumnBOList.isEmpty())
				{
					for (LogicalColumnBO logicalColumnBO : resultLogicalColumnBOList) {
						if(logicalColumnBO.getIsKeyColumn() != 'N'){
							for (ColumnDefinitionBO colDefBO : columnDefinitionList) {
								if(colDefBO.getLogicalColumnName().equalsIgnoreCase(logicalColumnBO.getLogicalColumnName())){
									if(!contains(listEntry.getProfileProperties(), colDefBO.getColumnName())){
										throw new DataImportException("Value for this column '"+logicalColumnBO.getLogicalColumnName()+"'(Logical Column Name) ' is required");
									}else{
										keyColumnAndValue.put(colDefBO.getPhysicalColumnName(), colNameAndValueMap.get(colDefBO.getPhysicalColumnName()));
									}
								}
							}
						}
					}
					for (ColumnDefinitionBO colDefBO : columnDefinitionList) {
						if(colDefBO.getIsCustomColumn()=='Y' && colDefBO.getColumnType().equalsIgnoreCase("EMAIL")){
							Map<String,Long> isExist=dataImportDao.checkEmailExist(colNameAndValueMap.get(colDefBO.getPhysicalColumnName()));
							if(isExist== null){
								throw new DataImportException("Email doesn't exist ");
							}
						}
					}
				}
				Map<String,Long> audienceData = dataImportDao.checkRecordExist(keyColumnAndValue,phySicalTableName,colNameAndTypeMap);
				if(audienceData!=null && audienceData.containsKey("AUDIENCE_MEMBER_ID")){
					audienceMemberId =audienceData.get("AUDIENCE_MEMBER_ID");
					//if(dataImportDao.checkAudienceMemberExist(adhocTableName, audienceMemberId))
					//	throw new DataImportException("Audience already exists.");	
					isAdded=dataImportDao.addToList(adhocTableName,audienceMemberId,colNameAndValueMap,colNameAndTypeMap);
				}
				else{
					List<String> columns=new ArrayList<>();
					for (String columnName: keyColumnAndValue.keySet()){
						for (String listColumnName: phyColNameMapping.keySet()){
							if (phyColNameMapping.get(listColumnName).equals(columnName)){
								columns.add(listColumnName);
								break;
							}
						}
					}
					if(!columns.isEmpty()&& columns.size()>1)
						throw new DataImportException(org.apache.commons.lang3.StringUtils.join(columns, ",")+ " column values are not exist in base table");	
					else if (!columns.isEmpty())
						throw new DataImportException(org.apache.commons.lang3.StringUtils.join(columns, ",")+" does not exist");
				}
			}
			else{
				throw new DataImportException("Physical table does not exist.");
			}
		} catch (ArrayIndexOutOfBoundsException ae){
			logger.error("Got ArrayIndexOutOfBoundsException"+ae.getMessage(),ae);
			throw new DataImportException("List does not exist.");
		} catch (RestClientException e) {
			logger.error("Got RestClientException:"+e.getMessage(),e);
			throw e;
		} catch (Exception e) {
			logger.error("Got Exception:"+e.getMessage(),e);
			throw e;
		} 
		logger.debug("End : "+getClass().getName()+" : addToList(ListEntry listEntry, String custCode,String userName)");
		return isAdded;
	}

	boolean contains(List<ProfileProperty> list, String name) {
		for (ProfileProperty item : list) {
	        if (item.getName().equals(name)){
	        	if(item.getValue()!=null && !item.getValue().equals("")){
	        		return true;
	        	}
	        }
	    }
	    return false;
	}
	public String getPhysicalTableName(final List<ColumnDefinitionBO> list) {
		return list.stream().filter(rr -> rr.getPhysicalTableName()!= null).findFirst().get().getPhysicalTableName();
        
    }
}

package com.zetainteractive.zetahub.de.dataimport.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import com.zetainteractive.zetahub.de.util.RestRequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zetainteractive.foundation.domain.UserBO;
import com.zetainteractive.zetahub.bootstarter.BootStarterConstants;
import com.zetainteractive.zetahub.bootstarter.ZetaLogger;
import com.zetainteractive.zetahub.bootstarter.datasource.ZetaUtil;
import com.zetainteractive.zetahub.commons.Util.CommonUtil;
import com.zetainteractive.zetahub.commons.domain.DTWSearchCriteria;
import com.zetainteractive.zetahub.commons.domain.DTWWorkflow;
import com.zetainteractive.zetahub.commons.domain.DepartmentSettings;
import com.zetainteractive.zetahub.commons.domain.FileDefinitionBO;
import com.zetainteractive.zetahub.commons.domain.NotificationInputBO;
import com.zetainteractive.zetahub.commons.domain.ResponseStatus;
import com.zetainteractive.zetahub.commons.domain.WorkflowActivity;
import com.zetainteractive.zetahub.commons.enums.NotificationStatusTypes;
import com.zetainteractive.zetahub.commons.enums.TemplateCodes;
import com.zetainteractive.zetahub.de.commons.DEConstants;
import com.zetainteractive.zetahub.de.commons.DataImportDTO;
import com.zetainteractive.zetahub.de.dataimport.exception.DataImportException;

/**
 * @author lakshmi.medarametla
 *
 */
@Component
public class DataImportDependencyCalls {
	
	private String adminEndPoint;
	private String workflowEndPoint;
	private RestRequestHandler restHandler = new RestRequestHandler();
	ZetaLogger logger = new ZetaLogger(this.getClass());
	public final Character COMPLETED = 'C';
	public final Character ERROR = 'E';
	public static String NOTIFICATION_COMPLETE_MSG = "Completed";
	
	/**
	 * @param customerCode
	 * @param userName
	 * @param searchCriteria
	 * @return
	 * @throws DataImportException
	 */
	public List<WorkflowActivity> getActivities(String customerCode,String userName,DTWSearchCriteria searchCriteria) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getActivities(String customerCode,String userName,DTWSearchCriteria searchCriteria)");
		List<WorkflowActivity> response = null;
		try{
			initializeContext(customerCode,userName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(searchCriteria);
			response=restHandler.exchange(adminEndPoint+"/datatransforms/getWorkflowActivityForSearchCriteria",HttpMethod.POST,entity,List.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH001",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getActivities(String customerCode,String userName,DTWSearchCriteria searchCriteria)");
		return response;
	}
	
	public Long saveWorkFlowActivity(String customerCode,String userName,WorkflowActivity activity,Boolean isEnabled,Map<String,String> emailAddress,Map<String,String> workflowMappings) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : saveWorkFlowActivity(String customerCode,String userName,WorkflowActivity activity,Boolean isEnabled,Map<String,String> emailAddress,Map<String,String> workflowMappings)");
		ResponseStatus response = null;
		try{
			initializeContext(customerCode,userName);
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(activity);
			response=restHandler.exchange(adminEndPoint+"/datatransforms/createWorkflowActivity",HttpMethod.POST,entity,ResponseStatus.class).getBody();
    	    //Update workflow status
			Map<String,String> params=new HashMap<String,String>();
			params.put("workFlowId",activity.getWorkflowId().toString());
			params.put("status", "W");
			entity = ZetaUtil.getHelper().getRestEntity(params);
			restHandler.exchange(adminEndPoint+"/datatransforms/updateWorkFlowStatus",HttpMethod.POST,entity,Boolean.class).getBody();
			if(isEnabled){
				NotificationInputBO notificationInputBO=prepareWorkflowNotifcationInput(activity.getStatus(), emailAddress, customerCode, workflowMappings);
				sendNotification(notificationInputBO);
			}
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH002",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : saveWorkFlowActivity(String customerCode,String userName,WorkflowActivity activity,Boolean isEnabled,Map<String,String> emailAddress,Map<String,String> workflowMappings)");
		return response.getId();
	}
	
	public Boolean triggerWorkFlowActivity(String customerCode,String userName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : triggerWorkFlowActivity(String customerCode,String userName)");
		Boolean response = null;
		try{
			initializeContext(customerCode,userName);
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response = restHandler.exchange(workflowEndPoint+"/datatransforms/triggerWorkFlowActivity/"+customerCode, HttpMethod.GET, entity, Boolean.class).getBody();
    	}catch(Exception exception){
    		logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH003",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : triggerWorkFlowActivity(String customerCode,String userName)");
		return response;
	}
	
	/**
	 * @param fileDefintionId
	 * @param status
	 * @param customerCode
	 * @param userName
	 * @return
	 * @throws SchedulerException
	 */
	public  FileDefinitionBO updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String message) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String message)");
		ObjectMapper objectMapper=new ObjectMapper();
		FileDefinitionBO response = null;
		Map<String,String> params=new HashMap<>();
		try{
			params.put("fileDefinitionId", dataImportDTO.getFileDefinitionId()+"");
			params.put("fileDefinitionStatus", status.toString());
			params.put("fileSummaryBO", objectMapper.writeValueAsString(dataImportDTO.getFileDefinitionBO().getFileSummaryBO()));
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(params);
			response=restHandler.exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/file/updateFileDefinitionStatus",HttpMethod.POST,entity,FileDefinitionBO.class).getBody();
			if (dataImportDTO.getIsNotificationEnabled()){
				NotificationInputBO notificationInputBO=prepareNotifcationInput(dataImportDTO,  status,dataImportDTO.getNotificationEmails(),ZetaUtil.getHelper().getCustomerID(),message);
				if (notificationInputBO != null)
					sendNotification(notificationInputBO);
			}
		}catch(Exception exception){
    		logger.error("An exception occured while updating file definition status :: "+exception.getMessage(),exception);
    		throw new DataImportException("DI0002",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : updateFileDefinitionStatus(Character status,DataImportDTO dataImportDTO,String message)");
		return response;
	}
	
	private void initializeContext(String customerCode, String userName) throws Exception {
		
		if(ZetaUtil.getHelper().getCustomerID()==null || !ZetaUtil.getHelper().getCustomerID().equalsIgnoreCase(customerCode) ){
			ZetaUtil.getHelper(customerCode, null);
		}
		if (userName == null)
			userName = ZetaUtil.getHelper().getConfig().getConfigValueString("processuser-dataimportuser","dataimportuser");

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(BootStarterConstants.CUSTOMERCODE.toString(), customerCode);
		httpHeaders.add(BootStarterConstants.USERNAME.toString(), userName);
		UserBO user = new RestRequestHandler ().exchange(ZetaUtil.getHelper().getEndpoint("security") + "/getUserByName/" + userName, HttpMethod.GET,
						new HttpEntity<>(httpHeaders), UserBO.class).getBody();

		if (user != null) {
			ZetaUtil.getHelper().setUser(user);
		} else {
			throw new Exception("user not available with username :: " + userName);
		}

		this.adminEndPoint = ZetaUtil.getHelper().getEndpoint("admin");
		this.workflowEndPoint = ZetaUtil.getHelper().getEndpoint("workflow");
	}
	
	
	/**
	 * 
	 * Method Name 	: sendNotification
	 * Description 	: The Method "sending notifications " is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public void sendNotification(NotificationInputBO notificationInputBO) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : sendNotification(NotificationInputBO notificationInputBO)");
		try{
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(notificationInputBO);
			restHandler.exchange(ZetaUtil.getHelper().getEndpoint("admin")+"/notifications/sendnotification",HttpMethod.POST,entity,Object.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    	}
		logger.debug("End : "+getClass().getName()+" : sendNotification(NotificationInputBO notificationInputBO)");
	}
	
	/**
	 * 
	 * Method Name 	: getNotificationsFromDepartment
	 * Description 	: The Method "getting notifications from departMent " is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DepartmentSettings getNotificationsFromDepartment(Long departmentId) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId)");
		Map<String,Object> json=null;
		DepartmentSettings departmentSettings=null;
		try{
			json=new HashMap<>();
			json.put("departmentId", departmentId);
			json.put("propertyKey", "NOTIFICATIONS");
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(json);
			departmentSettings=restHandler.exchange(adminEndPoint+"/getDepartmentSpecificProperty",HttpMethod.POST,entity,DepartmentSettings.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId)");
		return departmentSettings;
	}
	
	/**
	 * 
	 * Method Name 	: prepareNotifcationInput
	 * Description 	: The Method "preparing notification input" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	private NotificationInputBO prepareNotifcationInput(DataImportDTO dataImportDTO,Character status,Map<String,String> emailMap,String custCode,String message) throws Exception {
		StringBuilder emailAddresses=new StringBuilder();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (emailMap.containsKey("default"))
			emailAddresses.append(emailMap.get("default"));
		NotificationInputBO notificationInputBO=new NotificationInputBO();
		Map<String,String> templateValues=new HashMap<>();
		if(status==ERROR ){
			if(!emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()))
				return null;
			else if (!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()));
			}
			notificationInputBO.setTemplateCode(TemplateCodes.DATAIMPORT_ERROR.getValue());
			templateValues.put("status", "Errored");
			templateValues.put("message", message);
			
		}else if(status==COMPLETED ) {
			if (!emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()))
				return null;
			else if(!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_COMPLETED.getValue()));
			}
			notificationInputBO.setTemplateCode(TemplateCodes.DATAIMPORT_COMPLETE.getValue());
			templateValues.put("status", NOTIFICATION_COMPLETE_MSG);
			templateValues.put("completedon", dateFormat.format(new Date(CommonUtil.toUTC(new Date().getTime(), Calendar.getInstance().getTimeZone()).getTime()))+" UTC");
			templateValues.put("processedCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount()));
			templateValues.put("rejectedCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount()));
			templateValues.put("duplicateCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getDuplicateRecordsCount()));
			templateValues.put("successCount", String.valueOf(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getExistingRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount()));
			long totalCount=dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInvalidRecordsCount()
					+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getDuplicateRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getExistingRecordsCount()+dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getNewRecordsCount();
			if (dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount() != totalCount)
				logger.info("Some records are missed in summary report : "+(dataImportDTO.getFileDefinitionBO().getFileSummaryBO().getInputRecordsCount()-totalCount));
		}
		templateValues.put("value",String.valueOf(dataImportDTO.getFileDefinitionId()));
		if(dataImportDTO.getImportType().equalsIgnoreCase("ADHOCIMPORT")){
			templateValues.put("modulename","list");
			templateValues.put("type","List");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("BATCHIMPORT")){
			templateValues.put("modulename","file");
			templateValues.put("type","Base");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("DIMENTION")){
			templateValues.put("modulename","file");
			templateValues.put("type","Dimension");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("RESUB")){
			templateValues.put("modulename","file");
			templateValues.put("type","Resub");
		}else if(dataImportDTO.getImportType().equalsIgnoreCase("UNSUB")){
			templateValues.put("modulename","file");
			templateValues.put("type","Unsub");
		}
		templateValues.put("name",dataImportDTO.getFileDefinitionBO().getName());
		templateValues.put("customercode",custCode);
		templateValues.put("departmentId", String.valueOf(dataImportDTO.getFileDefinitionBO().getDepartmentID()));
		notificationInputBO.setTemplateValues(templateValues);
		notificationInputBO.setEmailAdresses(emailAddresses.toString());
		return notificationInputBO;	
	}
	
	/**
	 * 
	 * Method Name 	: getWorkflowById
	 * Description 	: The Method "getting workflow by id " is used for 
	 * Date    		: Nov 17, 2016, 4:03:29 PM
	 * @param string
	 * @return      : DTWWorkflow
	 * @param  		: workflowId
	 * @param  		: userName
	 * @param  		: customerCode
	 * @return 		: long
	 * @throws Exception 
	 */
	public DTWWorkflow getWorkflowById(Long workflowId,String customerCode,String userName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getWorkflowById(Long workflowId,String customerCode,String userName)");
		DTWWorkflow dtwWorkflow=null;
		try{
			initializeContext(customerCode,userName);
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			dtwWorkflow=restHandler.exchange(adminEndPoint+"/datatransforms/getWorkflowById/"+workflowId, HttpMethod.GET,entity,DTWWorkflow.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH007",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getWorkflowById(Long workflowId,String customerCode,String userName)");
		return dtwWorkflow;
	}
	
	/**
	 * 
	 * Method Name 	: getNotificationWorkflowMappings
	 * Description 	: The Method "getting workflow by id " is used for 
	 * Date    		: Nov 17, 2016, 4:03:29 PM
	 * @param string
	 * @return      : DTWWorkflow
	 * @param  		: workflowId
	 * @param  		: userName
	 * @param  		: customerCode
	 * @return 		: long
	 * @throws Exception 
	 */
	public Map<String,String> getNotificationWorkflowMappings(Long workflowId,String customerCode,String userName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getNotificationWorkflowMappings(Long workflowId,String customerCode,String userName)");
		Map<String,String> response=null;
		try{
			initializeContext(customerCode,userName);
			HttpHeaders headers = ZetaUtil.getHelper().getHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			response=restHandler.exchange(adminEndPoint+"/datatransforms/getNotificationWorkflowMappings/"+workflowId, HttpMethod.GET,entity,Map.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH007",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getNotificationWorkflowMappings(Long workflowId,String customerCode,String userName)");
		return response;
	}
	
	/**
	 * 
	 * Method Name 	: prepareNotifcationInput
	 * Description 	: The Method "preparing notification input" is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		:
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	private NotificationInputBO prepareWorkflowNotifcationInput(Character status,Map<String,String> emailMap,String custCode,Map<String,String> templateValues) throws Exception {
		StringBuilder emailAddresses=new StringBuilder();
		if (emailMap.containsKey("default"))
			emailAddresses.append(emailMap.get("default"));
		NotificationInputBO notificationInputBO=new NotificationInputBO();
		if(status==DEConstants.ACTIVITY_ERRORED){ 
			if(emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()) && 
					!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_ERROR.getValue()));
				notificationInputBO.setTemplateCode(TemplateCodes.WORKFLOW_ERROR.getValue());
			}
			templateValues.put("status", "Errored");
			templateValues.put("erroredon", new Date().toString());
			templateValues.put("message", "Workflow Errored.");
		}else if(status==DEConstants.ACTIVITY_BLOCKED ){
			if(emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_BLOCKED.getValue()) && 
					!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_BLOCKED.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_BLOCKED.getValue()));
				notificationInputBO.setTemplateCode(TemplateCodes.WORKFLOW_BLOCKED.getValue());
			}
			templateValues.put("status","Blocked" );
			templateValues.put("blockedon", new Date().toString());
			templateValues.put("message", DEConstants.ACTIVITY_BLOCKED_MSG);
		}else if(status==DEConstants.ACTIVITY_WAITING ){
			if(emailMap.containsKey(NotificationStatusTypes.NOTIFICATION_WAITING.getValue()) && 
					!"-".equals(emailMap.get(NotificationStatusTypes.NOTIFICATION_WAITING.getValue()))){
				if (emailAddresses.toString().length()>0)
					emailAddresses.append(",");
				emailAddresses.append(emailMap.get(NotificationStatusTypes.NOTIFICATION_WAITING.getValue()));
				notificationInputBO.setTemplateCode(TemplateCodes.WORKFLOW_READY.getValue());
			}
			templateValues.put("status","Waiting" );
		}
		templateValues.put("type","Workflow");
		templateValues.put("customercode",custCode);
		
		notificationInputBO.setTemplateValues(templateValues);
		notificationInputBO.setEmailAdresses(emailAddresses.toString());
		return notificationInputBO;	
	}
	/**
	 * 
	 * Method Name 	: getNotificationsFromDepartment
	 * Description 	: The Method "getting notifications from departMent " is used for 
	 * Date    		: Nov 15, 2016, 4:03:29 PM
	 * @param string
	 * @return      : NotificationInputBO
	 * @param  		: departmentId
	 * @param  		: userName
	 * @param  		: customerCode
	 * @return 		: long
	 * @throws Exception 
	 * @throws 		: 
	 */
	public DepartmentSettings getNotificationsFromDepartment(Long departmentId,String customerCode,String userName) throws DataImportException{
		logger.debug("Begin : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId,String customerCode,String userName)");
		Map<String,Object> json=null;
		DepartmentSettings departmentSettings=null;
		try{
			initializeContext(customerCode,userName);
			json=new HashMap<>();
			json.put("departmentId", departmentId);
			json.put("propertyKey", "NOTIFICATIONS");
			HttpEntity<?> entity = ZetaUtil.getHelper().getRestEntity(json);
			departmentSettings=restHandler.exchange(adminEndPoint+"/getDepartmentSpecificProperty",HttpMethod.POST,entity,DepartmentSettings.class).getBody();
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
    		throw new DataImportException("SCH005",exception);
    	}
		logger.debug("End : "+getClass().getName()+" : getNotificationsFromDepartment(Long departmentId,String customerCode,String userName)");
		return departmentSettings;
	}
	
	
}
